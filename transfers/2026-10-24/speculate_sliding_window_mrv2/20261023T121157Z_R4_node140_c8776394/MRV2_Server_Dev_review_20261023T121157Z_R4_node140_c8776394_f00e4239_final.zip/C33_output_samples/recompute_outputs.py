from pathlib import Path
import json,hashlib,struct,math
p=Path(__file__).resolve().parent;d=json.loads((p/'SAMPLE_INDEX.json').read_text());a=[]
for row in d['samples']:
 for name,ref in row['tensors'].items():
  b=(p/ref['local_path']).read_bytes();assert len(b)==ref['bytes'] and hashlib.sha256(b).hexdigest()==ref['sha256']
 ref=row['tensors']['graph'];b=(p/ref['local_path']).read_bytes();v=[struct.unpack('<f',struct.pack('<I',n<<16))[0] for n, in struct.iter_unpack('<H',b)];assert all(math.isfinite(x) for x in v)
 assert b==(p/row['tensors']['reference']['local_path']).read_bytes();a.append(b)
 print('generation',row['generation'],'BF16 finite/exact output match; inputs hashed; full KV/model reference not rerun')
assert a[0]!=a[1] and a[0]==a[2];print('A/B distinguishable, A-prime restores output. This is only a small raw-output recomputation; consult full execution/joint/source evidence.')
