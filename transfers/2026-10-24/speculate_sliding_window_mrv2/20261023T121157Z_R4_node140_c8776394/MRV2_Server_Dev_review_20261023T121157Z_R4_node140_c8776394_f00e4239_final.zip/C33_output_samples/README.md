# C33本轮真实输出小样本

这3份原始sample manifest与BF16图输出/独立eager输出及输入张量来自140 C33完整NUMERIC_TARGET4的A/B/A′。使用Python标准库运行recompute_outputs.py可核对bytes/hash、finite、逐元素精确一致及ABA输出区分/恢复。

**这不等于重跑完整模型参考**。完整层输入、必要KV前态/后态与真实调用关联由服务器numeric-joint、原producer/launcher/plan和源码检查；巨大KV chunk未附。本包不靠一个相同hash证明参考独立。content-addressed store会让两个相同的实际计算结果共用同一个blob，参考的独立调用需要审阅ContinuousReference的独立canonical oracle和实际_run_model调用证据。

原来源和完整SHA保留于SAMPLE_INDEX.json，不能归给C34新NPU执行。服务器自检已执行；接收端校验未执行。
