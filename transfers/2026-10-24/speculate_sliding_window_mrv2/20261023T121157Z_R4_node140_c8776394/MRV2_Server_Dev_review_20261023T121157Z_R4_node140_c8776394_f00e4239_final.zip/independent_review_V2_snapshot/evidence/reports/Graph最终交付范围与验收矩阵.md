# Graph 最终交付范围与验收矩阵

不缩减原定MRV2 Sliding Window Graph整体交付目标；DSpark Target4仅第一阶段。更新时间2026-10-23T18:44:18.927283+00:00；活动node-25-140，同一R4，deadline不变。

分类：1=必须且有对应限定证据，2=必须仍有缺口，3=明确forced-OFF/不支持合同，4=具体Graph产品组合需owner决定。历史明确非Graph必需不被抹去；不把Graph设计冻结解读为永久产品不支持。类别1也不代表整个功能已发布。

|项目|类别|当前证据/缺口|合同依据|下一步|
|---|---|---|---|---|
|DSpark static K7, sample_from_anchor=true, dense GQA/FIA TP1, FULL_DECODE_ONLY Target4|2|第一阶段已有C28/101完整数值12/Target12/LIFE21历史；140 C29锚点/ABA前哨新通过，C30锚点通过。自然请求、性能、产品入口、完整平台门槛未齐|现有明确主线；不是整体完成|继续C30三臂/自然请求与metadata异常，保留不同机器/SHA身份|
|DFlash static K+1 dense FIA Graph|2|共享capture/graph manager实现，但不能由DSpark数值替代；本轮未新增DFlash设备证据|Frozen static DFlash；Graph blueprint Base DFlash|核对独立checkpoint、causal/query宽度/层集合/Target与生命周期差异，再独立候选验证|
|eligible DSpark sample_from_anchor=false / query K+1|2|共享基础但当前冻结fixture只sample_from_anchor=true；没有本轮K+1实测|Graph blueprint Eligible DSpark明确两宽度分别验|定位合法checkpoint并新增独立profile；不可用时记录模型依赖|
|static Eagle3 autoregressive Graph|2|不经过DFlash helper，多step carrier/reader；当前base characterization不接Eagle3|Frozen methods及Graph Eagle3 design|实现/审查AR专用adapter及step bank；不能标unsupported掩盖缺口|
|TP16 replicated / GLM必要backend路径|2|Graph TP16 design明确mandatory，typed rank contract与全rank设备证据未完成；PR TP16非Graph不能代替|Graph Feature Dependency Graph 114–120、Graph TP16 Design|先rank-aware实现/Host前置，再请求完整合法16片；前八仍他用，不以TP8替代|
|FULL Graph模式 vs FULL_DECODE_ONLY|4|实验base代码允许FULL/FULL_DECODE_ONLY，但真实验证集中后者；公共Gate均冻结|Frozen49/Graph master30|需owner确认最终两种模式是否均为发布必需，保持两者既有拒绝直到审查|
|PIECEWISE Graph|4|当前实验base拒绝PIECEWISE；历史仅明确冻结，未证明最终产品永久不支持|Frozen49、characterization validate_base_graph_characterization_context|需owner明确模式范围；不自行改成永久unsupported|
|async × Graph (DFlash/DSpark；Eagle3/DSA差异)|4|非Graph明确必需；Graph另有lane/event/completion设计，当前base准入拒绝async；缺实现不称产品不支持|Frozen31–43、P7X_Graph_Async_Design.md|列出Graph lane bank与最后consumer合同差异，请owner确认必需组合；继续独立sync主线|
|prefix × Graph|4|非Graph明确必需；Graph resident epoch/evict hold设计待接入；base拒绝prefix|Frozen37、P7X_Graph_Prefix_Design.md|需确认Graph prefix交付组合；不能复用eager前态当Graph PASS|
|chunked pure prefill→decode / mixed prefill-decode / general multi-request|2|原定生命周期/phase合同必需；Graph base只有pure-prefill bypass，mixed分类仍拒绝，正式组合缺口|Frozen38–40/85–89；P7X_Graph_Chunked_Mixed_Multi_Design.md|本轮自然长短/替换/active3先验，mixed/抢占/rowreuse单独列缺口，不能silent fallback|
|SP/FlashComm × Graph|4|原有非Graph拓扑应保留；Graph fingerprint有字段但base明确拒绝，需具体组合边界|validate_base_graph_characterization_context 839–844、Graph TP design|核对MRV1/PR真实支持与owner确定Graph需验证组合，不扩成全Cartesian|
|DSA / DSA-CP / required GLM backend Graph|4|非Graph uncompressed DSA-CP必需；Graph derived bank/CP carrier未就绪，不能由dense FIA替代|Frozen35/41–43/76–83、P7X_Graph_DSA_DSACP_Design.md|明确实际模型/backend组后完成derived-state adapter；Graph组合范围请owner确认|
|compressed DSA/QLI, SFA/indexer, MLA, heterogeneous multi-group|4|历史为runtime-dependent/source-blocked，有Graph专属设计；不是已支持或永久不支持|Frozen82–83、P7X_Graph_Complex_Backends_Design.md|先从真实必须模型/backend库存确定必要子集，不能仅凭模型名推断|
|MTP / DeepSeek-V4 co-trained DSpark Window ON|3|warning-once FORCED_OFF，数字校验/Window分配之前生效；OFF不回退|Frozen45–46及现有policy|按变更影响保留forced-OFF合同，不人为启用Graph Window|
|plain Eagle / DFlash2 / dynamic-K Eagle3|4|原定非主发布blocker；ON必须明确gated且OFF不回退。DFlash2 Graph方法自身前置缺失|Frozen46–50、Graph dependency46|维持明确拒绝/既有语义；如owner扩范围再列新工作，不能silent fallback|
|Window OFF / eager既有产品合同|1|C29/C30 A0实测；eager广范围由PR原证据声明，Graph改动只tools且production未变；仍需最终集成回归|本轮A0/C29+C30、PR_SOURCE_DECLARED_READONLY.json|按共享代码影响复用历史，集成基线确认后独立回归，不能拼成整体PASS|

## 准确的阶段/整体裁决

DSpark TP1 Target4阶段仍在推进，不能记成完整阶段完成。原定Graph整体范围未完成：DFlash独立宽度、Eagle3 AR、TP16 rank合同与设备验证等明确缺口尚存；其他具体Graph组合须结合上述原件逐项裁决。性能达标阈值、安装平台适用性、execution occurrence/operand、physical-read门槛均没有被本次答复豁免。

原件路径与hash见同名JSON；原件不修改。本轮不以重新冻结范围代替实现，不启动未具备adapter的TP16来凑覆盖。
