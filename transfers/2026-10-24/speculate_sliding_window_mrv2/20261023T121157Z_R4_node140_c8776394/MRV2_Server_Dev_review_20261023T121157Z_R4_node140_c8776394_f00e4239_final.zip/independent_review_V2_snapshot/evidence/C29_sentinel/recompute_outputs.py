from pathlib import Path
import json,numpy as np
p=Path(__file__).parent
s=[]
for i in range(3):
 g=np.load(p/f"{i}_graph.float32.npy");r=np.load(p/f"{i}_reference.float32.npy")
 assert np.isfinite(g).all() and np.isfinite(r).all()
 s.append(g)
 print(i,"max_abs",float(np.max(np.abs(g-r))),"exact_equal",np.array_equal(g,r))
print("A/B distinguishable",not np.array_equal(s[0],s[1]))
print("A-prime restores A",np.array_equal(s[0],s[2]))
