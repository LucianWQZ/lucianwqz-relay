#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Opt-in Python exception at the real metadata-publish boundary.

Only legal materialization precedes injection. Afterwards this probe permits
Host export and the Host next-scope guard; it refuses clear/replay submissions.
No native partial failure, completion, recovery or physical-read claim is made.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from types import MethodType

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair5_evidence import audit_execution
from tools.p7x_graph_repair6_storage import atomic_json, require
from tools.p7x_graph_repair9_materialize_fault import MaterializeUnwindProbe


class InjectedMetadataPublishUnwindError(RuntimeError):
    """Known Python boundary; not a native exception."""


class MetadataPublishUnwindProbe(MaterializeUnwindProbe):
    def __enter__(self):
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe

        require(not self.spec._draft_window_graph_characterization.recorder.enabled, "fault requires observer OFF")
        probe = self
        runtime = self.spec._draft_window_runtime_state
        workspace = runtime.workspace

        def publish(_runtime, inputs, metadata, *, target_metadata):
            require(probe.record is None, "first actual publish boundary only")
            context = probe.spec._require_current_draft_window_proposal()
            require(
                probe.spec._draft_window_live_inputs is inputs and runtime._active_inputs is inputs,
                "live typed ownership must precede publish",
            )
            require(context.mapping_epoch == inputs.identity.mapping_epoch, "current publish epoch")
            require(metadata is not target_metadata, "Draft must not alias Target metadata")
            probe.record = dict(
                injected_point="metadata_before_publish",
                ns=time.monotonic_ns(),
                generation_identity=_json_safe(inputs.identity),
                generation=inputs.identity.generation_id,
                epoch=inputs.identity.mapping_epoch,
                request_ids=list(context.ordered_request_ids),
                device=str(workspace.window_block_table.device),
                backing_storage=workspace.window_block_table.untyped_storage().data_ptr(),
                active=inputs.identity.actual_request_count,
                padded=inputs.identity.padded_request_count,
                lease_registered=runtime._lease_pool._current is inputs.lease,
                live_registered=True,
                publish_called=False,
                target_separate=True,
            )
            probe.poisoned = True
            raise InjectedMetadataPublishUnwindError("REPAIR10_METADATA_UNWIND:before_publish")

        def forbidden_clear(*args, **kwargs):
            probe.post_fault_clears.append(dict(ns=time.monotonic_ns()))
            raise RuntimeError("post-fault workspace clear refused before device submission")

        original_clear = workspace._zero_all

        def clear(_workspace, *args, **kwargs):
            if probe.poisoned:
                return forbidden_clear()
            return original_clear(*args, **kwargs)

        try:
            self._wrap(runtime, "publish_metadata", MethodType(publish, runtime))
            self._wrap(workspace, "_zero_all", MethodType(clear, workspace))
            for graph in self.spec.query_cudagraph_manager.graphs.values():
                original = graph.replay

                def replay(_graph, *args, original=original, **kwargs):
                    if probe.poisoned:
                        probe.replays_after_record += 1
                        raise RuntimeError("post-publish-fault replay refused before submission")
                    return original(*args, **kwargs)

                self._wrap(graph, "replay", MethodType(replay, graph))
            return self
        except BaseException:
            self._restore()
            raise

    def __exit__(self, exc_type, exc, tb):
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe

        # Restoration changes Host method bindings only, never device state.
        self._restore()
        runtime = self.spec._draft_window_runtime_state
        inputs, lease = runtime._active_inputs, runtime._lease_pool._current
        state = dict(
            quarantined_identity=_json_safe(runtime.quarantined_identity),
            lease_retained=lease is not None,
            lease_identity=_json_safe(lease.identity) if lease else None,
            active_inputs_retained=inputs is not None,
            active_identity=_json_safe(inputs.identity) if inputs else None,
            owner_live_inputs_absent=self.spec._draft_window_live_inputs is None,
            proposal_context_absent=self.spec._draft_window_proposal_context is None,
            graph_submission_uncertain=bool(getattr(self.spec, "_draft_window_graph_submission_uncertain", False)),
        )
        guard = dict(ns=time.monotonic_ns(), body_entered=False, rejected=False)
        if self.poisoned:
            try:
                with self.spec._draft_window_proposal_scope(self.spec.input_batch, dummy_run=False, is_profile=False):
                    guard["body_entered"] = True
                    raise RuntimeError("refuse actual device reuse in diagnostic")
            except RuntimeError as error:
                guard.update(rejected=not guard["body_entered"], error=str(error))
        atomic_json(
            self.output,
            dict(
                schema="repair10-metadata-unwind-v1",
                identity=self.identity,
                record=self.record,
                state=state,
                next_scope_guard=guard,
                poisoned=self.poisoned,
                post_fault_clear_attempts=self.post_fault_clears,
                replays_after_record=self.replays_after_record,
                isolated_exit_required=74,
                native_partial_submission="NOT_SIMULATED",
                post_fault_device_operations="NONE_BY_PROBE",
                scope="PYTHON_AT_REAL_METADATA_PUBLISH_BEFORE_PUBLICATION",
            ),
        )


def check(document, campaign, launcher, expected, artifact):
    result = audit_execution(document, campaign, launcher, expected, artifact, unwind=True)
    if result["status"] != "EXECUTION_ASSOCIATED":
        return result
    try:
        require(expected["unwind_point"] == "metadata_before_publish", "fault plan point")
        require(document["schema"] == "repair10-metadata-unwind-v1" and document["poisoned"] is True, "fault schema")
        require(
            campaign["exception_type"] == "InjectedMetadataPublishUnwindError"
            and campaign["exception_message"] == "REPAIR10_METADATA_UNWIND:before_publish",
            "fault earliest cause",
        )
        record, state, guard = document["record"], document["state"], document["next_scope_guard"]
        identity = record["generation_identity"]
        require(launcher["host_start_ns"] <= record["ns"] <= guard["ns"] <= launcher["host_end_ns"], "fault interval")
        require(
            record["injected_point"] == expected["unwind_point"]
            and record["device"].startswith("npu")
            and record["backing_storage"] > 0
            and 0 < record["active"] <= record["padded"] <= 4,
            "actual publish device/generation geometry",
        )
        require(
            record["lease_registered"]
            and record["live_registered"]
            and record["target_separate"]
            and not record["publish_called"],
            "actual typed ownership before publish",
        )
        require(
            record["generation"] == identity["generation_id"] and record["epoch"] == identity["mapping_epoch"],
            "publish generation/epoch",
        )
        require(
            state["quarantined_identity"] == state["lease_identity"] == state["active_identity"] == identity,
            "quarantine/lease/active identity",
        )
        require(
            state["lease_retained"]
            and state["active_inputs_retained"]
            and state["owner_live_inputs_absent"]
            and state["proposal_context_absent"]
            and state["graph_submission_uncertain"],
            "exception cleanup ownership",
        )
        require(
            guard["rejected"] and not guard["body_entered"] and "quarantined" in guard["error"],
            "Host next-scope refusal",
        )
        require(
            not document["post_fault_clear_attempts"] and document["replays_after_record"] == 0, "post-fault operation"
        )
        result.update(
            status="PASS_SCOPED_METADATA_PUBLISH_UNWIND",
            normal_reuse="NOT_PROVEN",
            native_partial_submission="NOT_SIMULATED",
            scope=document["scope"],
        )
    except (KeyError, ValueError, TypeError, IndexError) as error:
        result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("artifact", "campaign", "launcher", "plan", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    data = [json.loads(p.read_text()) for p in (args.artifact, args.campaign, args.launcher)]
    result = check(*data, json.loads(args.plan.read_text())["cases"][args.case_id], args.artifact)
    atomic_json(args.output, result)
    return 0 if result["status"] == "PASS_SCOPED_METADATA_PUBLISH_UNWIND" else 4


if __name__ == "__main__":
    raise SystemExit(main())
