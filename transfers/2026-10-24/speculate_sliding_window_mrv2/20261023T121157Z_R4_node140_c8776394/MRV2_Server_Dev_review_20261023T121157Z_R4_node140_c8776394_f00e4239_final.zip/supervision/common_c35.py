import os,json,hashlib
from pathlib import Path
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID='20261023T121157Z_R4_node140_c8776394'
ROOT=R/'runs'/SID
RUN=ROOT/'raw'
SOURCE=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/candidates/node140/C35_f00e4239/vllm-ascend')
VLLM=R/'candidates/C2_303ef7fe/vllm'
PYTHON='/usr/local/python3.11.10/bin/python'
SHA='f00e423936c23b0710fc2b5cd367d34ec7736d26'
TREE='5383f503852c3e520bd10442ed7562e1df5a9a04'
PLAN=RUN/'C35_prepare_01/case-plan.json'
AUTH=R/'state/R4_USER_AUTHORIZATION_RECORD.json'
PHY=8
PCI='0000:8D:00.0'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def environment():
 e=os.environ.copy();c=ROOT/'cache';e.update(ASCEND_RT_VISIBLE_DEVICES=str(PHY),PYTHONPATH=f'{SOURCE}:{VLLM}:/usr/local/Ascend/ascend-toolkit/latest/python/site-packages:/usr/local/Ascend/ascend-toolkit/latest/opp/built-in/op_impl/ai_core/tbe',PYTHONDONTWRITEBYTECODE='1',VLLM_VERSION='0.28.1',VLLM_USE_V2_MODEL_RUNNER='1',VLLM_ENABLE_V1_MULTIPROCESSING='0',TORCH_DEVICE_BACKEND_AUTOLOAD='1',VLLM_CACHE_ROOT=str(c/'vllm'),TORCH_NPU_CACHE_DIR=str(c/'torch_npu'),ASCEND_CACHE_PATH=str(c/'ascend'),HF_HOME=str(c/'hf'),TMPDIR='/tmp/mrv2_graph_20261023T121157Z_R4_node140_c8776394/tmp',TRITON_CACHE_DIR='/tmp/mrv2_graph_20261023T121157Z_R4_node140_c8776394/triton_cache');e.pop('ASCEND_VISIBLE_DEVICES',None)
 for k in ['VLLM_CACHE_ROOT','TORCH_NPU_CACHE_DIR','ASCEND_CACHE_PATH','HF_HOME','TMPDIR','TRITON_CACHE_DIR']:Path(e[k]).mkdir(parents=True,exist_ok=True)
 return e
