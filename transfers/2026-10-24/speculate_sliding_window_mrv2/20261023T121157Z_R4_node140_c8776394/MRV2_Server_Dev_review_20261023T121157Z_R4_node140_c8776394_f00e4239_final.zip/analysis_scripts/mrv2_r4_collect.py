from pathlib import Path
import json,csv,statistics,hashlib,datetime,collections,math
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');SID='20261023T121157Z_R4_node140_c8776394';RAW=R/'runs'/SID/'raw';O=R/'reports'/SID
NA='NOT_AVAILABLE'
def load(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];fails=[]
for casepath in sorted((RAW/'C33_prepare_01').glob('*')):
 if not casepath.is_dir() or not casepath.name.startswith(('PERF10_','PROFILE10_')):continue
 joint=casepath/'performance-joint.json';cp=casepath/'campaign.json';pp=casepath/'profile.json'
 if not joint.exists():continue
 j=load(joint)
 if j.get('status')!='PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE':fails.append(dict(case=casepath.name,result=j));continue
 c,p=load(cp),load(pp);plan=load(RAW/'C33_prepare_01/case-plan.json')['cases'][casepath.name]
 for cell,output in zip(j['cells'],c['outputs']):
  counts=cell['acceptance'];proposed=sum(x['proposed_draft_tokens'] for x in counts);accepted=sum(x['accepted_draft_tokens'] for x in counts);n=sum(x['verification_request_steps'] for x in counts);a=[x for x in p['calls'] if x['active'] and x['request_group']==cell['label']];hist=collections.Counter(x['label'] for x in a)
  positions=[]
  for k in range(7):
   dd=sum(x['proposed_per_position'][k] for x in counts);aa=sum(x['accepted_per_position'][k] for x in counts);positions.append(dict(position=k+1,proposed=dd,accepted=aa,rate=aa/dd if dd else NA))
  row={k:v for k,v in cell.items() if k!='acceptance'};row.update(case=casepath.name,source_sha=c['identity']['source_sha'],source_tree=c['identity']['source_tree'],profile='TARGET4',arm=j['arm'],workload=plan['performance_workload'],repeat=plan.get('performance_repetition'),profiler=casepath.name.startswith('PROFILE10_'),proposed_draft_tokens=proposed,accepted_draft_tokens=accepted,verification_request_steps=n,acceptance_rate=accepted/proposed,mean_acceptance_length_with_bonus=1+accepted/n,accepted_per_position=positions,draft_replays=hist['Draft_REPLAY_SUBMIT'],target_replays=hist['Target_REPLAY_SUBMIT'],draft_propose_host_calls=hist['Draft_propose'],actual_draft_capture_descriptor_histogram=dict(collections.Counter(str(x.get('descriptor')) for x in a if x['label']=='Draft_REPLAY_SUBMIT')),actual_target_capture_descriptor_histogram=dict(collections.Counter(str(x.get('descriptor')) for x in a if x['label']=='Target_REPLAY_SUBMIT')),per_replay_actual_active=NA,final_host_window_identity=output.get('window_runtime_after_request',NA),actual_graph_window_crop=j['actual_graph_window_crop'],actual_eager_window_crop=j['actual_eager_window_crop'],TTFT=NA,TPOT=NA,ITL=NA,source_joint=str(joint),source_joint_sha256=digest(joint),request_hash=c['request_manifest']['sha256'],config_hash=c['config_sha256'],output_token_sha256=[hashlib.sha256(json.dumps(t).encode()).hexdigest() for t in output['token_ids']],environment='node140 Phy8 TP1; other front8 workloads exist; nonexclusive diagnostic measurements',detailed_request_counts=[x['speculative_decoding'] for x in output['performance_metrics']]);rows.append(row)
groups={}
for row in rows:
 if row['profiler']:continue
 groups.setdefault((row['workload'],row['label'],row['arm']),[]).append(row)
aggregates=[]
for key,a in groups.items():
 a.sort(key=lambda x:x['repeat']);t=[x['elapsed_seconds'] for x in a];aggregates.append(dict(workload=key[0],label=key[1],arm=key[2],n=len(t),all_elapsed_seconds=t,median_seconds=statistics.median(t),min_seconds=min(t),max_seconds=max(t),median_output_tokens_per_second=statistics.median(x['output_tokens_per_second'] for x in a),all_acceptance_rates=[x['acceptance_rate'] for x in a],all_mean_acceptance_lengths=[x['mean_acceptance_length_with_bonus'] for x in a],repeated_output_trajectory_identical=len({tuple(x['output_token_sha256']) for x in a})==1))
comparisons=[]
for workload,label in sorted({(x['workload'],x['label']) for x in aggregates}):
 g={x['arm']:x for x in aggregates if x['workload']==workload and x['label']==label}
 if set(g)=={'G_OFF','G_ON','E_ON'}:
  comparisons.append(dict(workload=workload,label=label,minimum_repeats=min(x['n'] for x in g.values()),window_on_elapsed_change_percent=(g['G_ON']['median_seconds']/g['G_OFF']['median_seconds']-1)*100,graph_vs_same_window_eager_elapsed_change_percent=(g['G_ON']['median_seconds']/g['E_ON']['median_seconds']-1)*100,scope='median finite repetitions, nonexclusive node140, same output length; acceptance/workload reported, not a product threshold verdict'))
result=dict(session=SID,updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha='1d246b8f154e2dc5327d1924b7d7c078ca81d09b',cells=rows,aggregates=aggregates,comparisons=comparisons,failed_or_invalid=fails,acceptance_definition_source=str(O/'PERFORMANCE10_ACCEPTANCE_DEFINITIONS.json'),scope='C33 new140 measurements only; C32 pilot/R3 history excluded; no producer relabel to C34; final delivery target not reduced')
pairs=[]
for workload,label,repeat in sorted({(x['workload'],x['label'],x['repeat']) for x in rows if not x['profiler']}):
 armrows={x['arm']:x for x in rows if not x['profiler'] and x['workload']==workload and x['label']==label and x['repeat']==repeat}
 for other in ['E_ON','G_OFF']:
  if 'G_ON' not in armrows or other not in armrows:continue
  a,b=armrows['G_ON'],armrows[other]
  pairs.append(dict(workload=workload,label=label,repeat=repeat,arms=['G_ON',other],same_frozen_requests=a['request_hash']==b['request_hash'],equal_complete_output_token_sequences=a['output_token_sha256']==b['output_token_sha256'],scope='same declared prompts/greedy seed/output length end-to-end serving comparison only; not paired intermediate KV or continuous numeric proof',source_cases=[a['case'],b['case']]))
result['normal_output_comparisons']=pairs
(O/'MRV2_性能与接受率_Summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
fields=['case','source_sha','profile','arm','workload','label','repeat','profiler','requests','input_tokens','output_tokens','elapsed_seconds','output_tokens_per_second','proposed_draft_tokens','accepted_draft_tokens','acceptance_rate','mean_acceptance_length_with_bonus','verification_request_steps','draft_replays','target_replays','actual_graph_window_crop','actual_eager_window_crop','TTFT','TPOT','ITL','request_hash','config_hash','source_joint']
with (O/'MRV2_性能逐cell原始计数.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
print(json.dumps(dict(cells=len(rows),aggregates=aggregates,comparisons=comparisons,failed=len(fails)),ensure_ascii=False))
