from pathlib import Path
import json,csv,collections,statistics,hashlib
from decimal import Decimal
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');SID='20261023T121157Z_R4_node140_c8776394';RAW=R/'runs'/SID/'raw/C33_prepare_01';O=R/'reports'/SID
D=Decimal

def intervals(rows):
 if not rows:return dict(count=0,span_us='NOT_AVAILABLE',union_us='NOT_AVAILABLE')
 rows=sorted(rows);a,b=rows[0];start=a;union=D(0);over=0
 for x,y in rows[1:]:
  if x>b:union+=b-a;a,b=x,y
  else:over+=1;b=max(b,y)
 union+=b-a
 return dict(count=len(rows),span_us=float(b-start),union_us=float(union),uncovered_export_interval_us=float(b-start-union),overlapping_interval_count=over)

cases=[]
for name in ['PROFILE10_G_OFF_long','PROFILE10_G_ON_long','PROFILE10_E_ON_long']:
 root=RAW/name;profile=json.loads((root/'profile.json').read_text());flow=json.loads((O/'profiling'/name/'flow_analysis.json').read_text());joint=json.loads((root/'performance-joint.json').read_text());stats={}
 for c in profile['calls']:
  if c['active']:stats.setdefault(c['label'],[]).append((c['end_ns']-c['start_ns'])/1e6)
 stats={k:dict(n=len(a),mean_ms=statistics.mean(a),p50_ms=statistics.median(a),p95_nearest_rank_ms=sorted(a)[max(0,__import__('math').ceil(.95*len(a))-1)],sum_ms=sum(a)) for k,a in stats.items()}
 trace=next((root/'trace').rglob('trace_view.json'));raw=json.loads(trace.read_text());ev=raw['traceEvents'] if isinstance(raw,dict) else raw;types=collections.Counter();special=collections.defaultdict(list);copy_examples=[]
 for e in ev:
  n=str(e.get('name',''));low=n.lower()
  if any(x in low for x in ['memcpy','synchronize','event_wait','event_record','event_reset']):
   types[n]+=1
   if e.get('ph')=='X':special[n].append(e.get('dur'))
   if 'memcpy' in low and len(copy_examples)<8:copy_examples.append(e)
 kernels=next((root/'trace').rglob('kernel_details.csv'));kr=list(csv.DictReader(kernels.open()));kt=collections.Counter();kb=collections.defaultdict(list);fia=[]
 for row in kr:
  kt[row['Type']]+=1
  start=D(row['Start Time(us)']);duration=D(row['Duration(us)']);kb[row['Device_id']].append((start,start+duration))
  if 'fusedinferattention' in (row['Name']+row['Type']).lower().replace('_',''):fia.append(row)
 tasks=next((root/'trace').rglob('task_time.csv'));tr=list(csv.DictReader(tasks.open()));streams=collections.defaultdict(list);alltasks=collections.defaultdict(list);tasktypes=collections.Counter();bad=0
 for row in tr:
  a,b=D(row['task_start(us)']),D(row['task_stop(us)']);tasktypes[row['kernel_type']]+=1
  if b<a:bad+=1;continue
  key=(row['Device_id'],row['stream_id']);streams[key].append((a,b));alltasks[row['Device_id']].append((a,b))
 stream_stats={str(k):intervals(v) for k,v in streams.items()};all_stats={str(k):intervals(v) for k,v in alltasks.items()};overlap={device:sum(x['union_us'] for key,x in stream_stats.items() if key.startswith("('"+device+"',"))-all_stats[device]['union_us'] for device in all_stats}
 fragment={'scope':'Explicit exported flow IDs and enclosing Host intervals only; no generation-bound execution operand', 'replay':flow.get('replays',[None])[0] if flow.get('replays') else None,'trace_excerpt':flow.get('fragment',[])[:60]}
 if fragment['replay']:
  indexes=fragment['replay'].get('replay_plus_update_flow_indices',[])[:5];fragment['explicit_flow_examples']=[flow['flows'][i] for i in indexes]
 (O/'profiling'/name/'typical_replay_fragment.json').write_text(json.dumps(fragment,ensure_ascii=False,indent=2)+'\n')
 doc=dict(case=name,source_sha='1d246b8f154e2dc5327d1924b7d7c078ca81d09b',profile='TARGET4',status=joint['status'],cells=joint['cells'],host_statistics_all_ranges=stats,host_subrange_coverage=profile['host_subrange_coverage'],flow_counts=flow['flow_counts'],replay_flow_coverage=flow['coverage'],classified_coverage=flow['classified_coverage'],kernel_types=dict(kt),kernel_interval_coverage={k:intervals(v) for k,v in kb.items()},FIA_literal_name_count=len(fia),FIA_literal_duration_us_sum=sum(float(x['Duration(us)']) for x in fia),FIA_examples=[{k:x[k] for k in ['Name','Type','Duration(us)']} for x in fia[:3]],task_type_counts=dict(tasktypes),exported_task_interval_stats=all_stats,per_stream_exported_task_intervals=stream_stats,overlap_of_exported_stream_task_union_us=overlap,invalid_task_interval_rows=bad,trace_sync_copy_name_counts=dict(types),exported_special_duration_us_sum={k:sum(x for x in a if isinstance(x,(int,float))) for k,a in special.items()},copy_trace_examples=copy_examples,directional_copy_counts='NOT_AVAILABLE_UNLESS_EXPLICIT_DIRECTION_IN_RAW_EVENT; HostToDevice flow category is NOT a memcpy count',device_idle='NOT_ESTABLISHED: uncovered exported kernels/tasks do not prove whole-device idle',target_draft_device_FIA_attribution='UNRESOLVED_NO_GENERATION_BOUND_EXECUTION_FLOW',task_operand='NOT_EXPOSED',physical_read='NOT_EXPOSED',timing_contract='Host nested range sums overlap; device export union stays in its own CSV time domain, never subtracted from Host timestamps; concurrent duration sum is not elapsed',collection_impact='Host wrappers/record_function in all controls; profiler has extra CPU/device collection and final export/drain effects; no added per-generation LIFE sync in normal profile',raw=dict(trace=str(trace),trace_bytes=trace.stat().st_size,trace_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),kernel_csv=str(kernels),task_csv=str(tasks),flow_analysis=str(O/'profiling'/name/'flow_analysis.json')))
 cases.append(doc)
result=dict(session=SID,new_collection_node='node-25-140',new_source_sha='1d246b8f154e2dc5327d1924b7d7c078ca81d09b',new_profiles=cases,historical_R3='background only, no cross-machine speed ratio',normal_update_contract='SOURCE_SUPPORTED_CONTRACT pending applicability/review, not inferred from profiling',formal_release='NOT_DECIDED',public_gate='FROZEN')
(O/'MRV2_Profiling_Summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('profiles',len(cases));print([(x['case'],x['FIA_literal_name_count'],x['replay_flow_coverage']) for x in cases])
