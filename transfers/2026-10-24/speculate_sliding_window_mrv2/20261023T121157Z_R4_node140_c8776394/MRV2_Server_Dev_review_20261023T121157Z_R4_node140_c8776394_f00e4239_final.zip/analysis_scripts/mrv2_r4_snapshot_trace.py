from pathlib import Path
import json,collections,bisect,statistics,math,sys,hashlib
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');SID='20261023T121157Z_R4_node140_c8776394';RAW=R/'runs'/SID/'raw';O=R/'reports'/SID
case=sys.argv[1];trace=next((RAW/'C33_prepare_01'/case/'trace').rglob('trace_view.json'));doc=json.loads(trace.read_text());ev=doc['traceEvents'] if isinstance(doc,dict) else doc
bounds=[e for e in ev if e.get('ph')=='X' and e.get('name')=='repair5/Draft_materialize_exact_length_snapshot'];nested=collections.defaultdict(list);fragments=[]
for b in bounds:
 start=float(b['ts']);end=start+float(b['dur']);inside=[e for e in ev if e.get('ph')=='X' and e.get('pid')==b.get('pid') and e.get('tid')==b.get('tid') and float(e['ts'])>=start and float(e['ts'])+float(e.get('dur',0))<=end and e is not b]
 for e in inside:nested[e['name']].append(float(e['dur']))
 if not fragments:fragments=[b]+inside
summary={k:dict(n=len(a),sum_trace_us=sum(a),mean_trace_us=statistics.mean(a),max_trace_us=max(a)) for k,a in nested.items()};names=collections.Counter(str(e.get('name')) for e in ev if any(v in str(e.get('name','')).lower() for v in ['memcpy','synchronize','streamwait','eventwait','eventrecord']))
d=dict(source_trace=str(trace),bytes=trace.stat().st_size,sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),trace_snapshot_range_count=len(bounds),nested_same_host_thread_statistics=summary,trace_sync_copy_name_counts=dict(names),first_range_original_events=fragments,scope='Only exact containment in same exported Host pid/tid; nested durations overlap and cannot be summed as elapsed. No Host-device clock subtraction. Sync name presence is not identification of the last consumer or generation occurrence.')
o=O/'profiling'/case;o.mkdir(parents=True,exist_ok=True);(o/'snapshot_nested_host_calls.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print('ranges',len(bounds),'nested',summary)
