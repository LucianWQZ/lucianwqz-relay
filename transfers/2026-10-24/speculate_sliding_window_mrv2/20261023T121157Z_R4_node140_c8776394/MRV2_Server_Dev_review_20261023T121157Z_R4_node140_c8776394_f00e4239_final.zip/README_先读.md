# R4 C35审查包

先读reports/MRV2_持续开发阶段总结.md、MRV2_候选与证据对应表.md、MRV2_性能与接受率报告.md。完整产品目标未完成，公开Gate冻结。

source_C35为当前固定代码；independent_review_V2_snapshot保留原C32/历史证据技术评审快照，不改写producer身份。C32至C35生产子树相同，工具/source SHA仍分开。execution保留本轮真实launcher/plan/原件和checker，C33_output_samples可用Python标准库离线重算；仅输出/输入小样本，不重跑完整KV/模型参考。大tensor/trace留服务器，RAW_EVIDENCE_INDEX给索引，profiling_excerpt附可核查原始片段和字段。

Git bundle仅源码，C28为前置，已实际恢复验证；模型/native/JIT cache不在bundle。环境和worker来源独立记录。服务器CRC/hash/JSON自检见外部PACKAGE_SELF_CHECK与DOWNLOAD_MANIFEST，不代表用户接收校验。网页GPT意见仅独立技术意见，不是发布批准。
