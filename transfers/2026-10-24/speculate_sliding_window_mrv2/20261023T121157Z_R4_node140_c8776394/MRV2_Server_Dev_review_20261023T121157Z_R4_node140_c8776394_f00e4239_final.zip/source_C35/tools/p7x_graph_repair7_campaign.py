#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Repair7 scoped plan. No publication or device authorization is inferred."""

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair6_campaign import build_plan as previous
from tools.p7x_graph_repair6_storage import atomic_json


def add_warm_performance_cases(cases, inputs, output):
    """An explicitly supplied, separately hashed workload adds opt-in cases.

    Frozen Base/Target4 requests and existing cases keep their original bytes.
    No model-free or historical result is promoted to a new device result.
    """
    request = inputs / "requests/performance-long.json"
    if not request.exists():
        return
    data = json.loads(request.read_text())
    if not data or any(not row.get("prompts") or row.get("max_tokens") != 16 for row in data):
        raise ValueError("bounded performance workload requires nonempty groups and sixteen output tokens")
    if len({row["label"] for row in data}) != len(data):
        raise ValueError("performance request labels must be unique")
    for arm in ("OFF", "ON"):
        for index in range(4):
            source = (f"PERF_{arm}_long_{index + 1:02}" if index < 3 else
                      "PROFILE_OFF_long_normal" if arm == "OFF" else "PROFILE_ON_long_materialize")
            # Retain the established _ON_long_ crop-admission predicate.
            name = f"PERF_WARM_{arm}_long_{index + 1:02}" if index < 3 else f"PROFILE_WARM_{arm}_long_normal"
            old = cases[source]

            def replace(value, source=source, name=name, request_path=old["request_path"]):
                if isinstance(value, str):
                    return value.replace(source, name).replace(request_path, str(request))
                if isinstance(value, list):
                    return [replace(v) for v in value]
                if isinstance(value, dict):
                    return {k: replace(v) for k, v in value.items()}
                return value

            case = replace(copy.deepcopy(old))
            for field in ("argv", "launch_argv"):
                case[field].append("--repair9-warmup-all")
            case.update(requests_sha256=hashlib.sha256(request.read_bytes()).hexdigest(),
                        selection="OPT_IN_ALL_GROUP_WARMUP_INDEPENDENT_PERFORMANCE_PROFILE",
                        outputs=str(output / name), warmup_policy="ALL_DECLARED_GROUPS")
            cases[name] = case


def add_counter_length_cases(cases, inputs, output, repo, python):
    """Separate Target4 experiment; a verify certificate gates every reuse case."""
    request = inputs / "requests/counter-lengths.json"
    if not request.exists():
        return
    data = json.loads(request.read_text())
    if (
        not data
        or {len(r["prompts"]) for r in data} != {1, 2, 3, 4}
        or any(r["max_tokens"] != 16 or not r["prompts"] for r in data)
    ):
        raise ValueError("counter workload requires active 1/2/3/4 and sixteen output tokens")
    modes = [("COUNTER_LENGTH_VERIFY", "verify", "none")]
    for arm in ("LEGACY", "REUSE"):
        modes += [
            (f"PERF_COUNTER_{arm}_ON_long_{i:02}", "off" if arm == "LEGACY" else "reuse", "control")
            for i in range(1, 4)
        ]
        modes.append((f"PROFILE_COUNTER_{arm}_ON_long_normal", "off" if arm == "LEGACY" else "reuse", "normal"))
    for name, mode, profile in modes:
        source = "PROFILE_ON_long_materialize" if profile == "normal" else "PERF_ON_long_01"
        old = cases[source]

        def replace(value, source=source, name=name, request_path=old["request_path"]):
            if isinstance(value, str):
                return value.replace(source, name).replace(request_path, str(request))
            if isinstance(value, list):
                return [replace(v) for v in value]
            if isinstance(value, dict):
                return {k: replace(v) for k, v in value.items()}
            return value

        case = replace(copy.deepcopy(old))
        for field in ("argv", "launch_argv"):
            argv = case[field]
            argv[argv.index("--repair5-profile") + 1] = profile
            argv += ["--repair5-capture-profile", "target4"]
            if profile != "none":
                argv += ["--repair9-warmup-all"]
            if mode != "off":
                argv += ["--repair9-counter-lengths", mode]
            if mode == "reuse":
                argv += ["--repair9-counter-verify", str(output / "COUNTER_LENGTH_VERIFY/counter-joint.json")]
        if mode == "verify":
            # Only the independently associated normal requests + length equivalence are assessed here.
            case["validation_commands"] = case["validation_commands"][:1]
            case.pop("require_host_subrange_coverage", None)
        if mode != "off":
            case["validation_commands"].append(
                dict(
                    kind="read_only_acceptance",
                    timeout=120,
                    argv=[
                        python,
                        str(repo / "tools/p7x_graph_repair9_host_lengths.py"),
                        "--artifact",
                        str(output / name / "counter-length-trial.json"),
                        "--campaign",
                        str(output / name / "campaign.json"),
                        "--launcher",
                        str(output / "launchers" / name / "launcher.json"),
                        "--plan",
                        str(output / "case-plan.json"),
                        "--case-id",
                        name,
                        "--output",
                        str(output / name / "counter-joint.json"),
                    ],
                )
            )
        if mode == "reuse":
            case["dependencies"] = list(dict.fromkeys([*case["dependencies"], "COUNTER_LENGTH_VERIFY"]))
        case.pop("check_argv", None)
        case.pop("additional_checks", None)
        case.update(
            requests_sha256=hashlib.sha256(request.read_bytes()).hexdigest(),
            selection="EXPERIMENTAL_CURRENT_CPU_COUNTER_LENGTH_SOURCE",
            outputs=str(output / name),
            counter_length_mode=mode,
            acceptance="same-source current length experiment; NOT continuous output numeric or Graph gate",
        )
        cases[name] = case


def build_plan(repo, inputs, output, vllm, python, sha, tree, run_id):
    plan = previous(repo, inputs, output, vllm, python, sha, tree, run_id)
    cases = plan["cases"]
    sentinel = copy.deepcopy(cases["NUMERIC_TARGET4"])
    for field in ("argv", "launch_argv"):
        sentinel[field] = [v.replace("NUMERIC_TARGET4", "NUMERIC_SENTINEL") for v in sentinel[field]]
        sentinel[field] += ["--repair6-target-prefix", "3"]
    sentinel["outputs"] = str(output / "NUMERIC_SENTINEL")
    sentinel["case_id"] = sentinel["acceptance_identity"]["case_id"] = "NUMERIC_SENTINEL"
    sentinel["numeric_samples"] = 3
    sentinel["validation_commands"] = [copy.deepcopy(sentinel["validation_commands"][0])]
    sentinel["validation_commands"][0]["argv"] = [
        v.replace("NUMERIC_TARGET4", "NUMERIC_SENTINEL") for v in sentinel["validation_commands"][0]["argv"]
    ]
    sentinel["check_argv"] = sentinel["validation_commands"][0]["argv"]
    sentinel["additional_checks"] = []
    sentinel["dependencies"] = ["B0"]
    sentinel["resource_policy"]["geometry_preflight"] = "THREE_SAMPLE_TARGET_PLUS_DRAFT"
    cases["NUMERIC_SENTINEL"] = sentinel
    cases["NUMERIC_TARGET4"]["dependencies"] = ["NUMERIC_SENTINEL"]
    name = "LIFE_TASK_DUMP"
    case = copy.deepcopy(cases["LIFE"])
    for field in ("argv", "launch_argv"):
        case[field] = [v.replace("LIFE", name) for v in case[field]] + ["--repair8-task-dump"]
    for command in case["validation_commands"]:
        command["argv"] = [v.replace("LIFE", name) for v in command["argv"]]
    case.update(case_id=name, outputs=str(output / name), selection="BOUNDED_NATIVE_JSON_AFTER_SERIALIZED_LIFE")
    case["acceptance_identity"]["case_id"] = name
    case["validation_commands"].append(dict(kind="read_only_acceptance", timeout=120, argv=[
        python, str(repo / "tools/p7x_graph_repair8_task_dump.py"),
        "--artifact", str(output / name / "task-dump-index.json"),
        "--campaign", str(output / name / "campaign.json"),
        "--launcher", str(output / "launchers" / name / "launcher.json"),
        "--plan", str(output / "case-plan.json"), "--case-id", name,
        "--output", str(output / name / "task-dump-joint.json"),
    ]))
    case.pop("check_argv", None)
    case.pop("additional_checks", None)
    cases[name] = case
    name = "LIFE_TASK_BIND"
    case = copy.deepcopy(cases["LIFE_TASK_DUMP"])
    for field in ("argv", "launch_argv"):
        case[field] = [v.replace("LIFE_TASK_DUMP", name) for v in case[field]] + ["--repair8-task-bindings"]
    for command in case["validation_commands"]:
        command["argv"] = [v.replace("LIFE_TASK_DUMP", name) for v in command["argv"]]
    command = copy.deepcopy(case["validation_commands"][-1])
    command["argv"] = [v.replace("task-dump-joint.json", "native-bindings-joint.json") for v in command["argv"]]
    command["argv"].append("--native-bindings")
    case["validation_commands"].append(command)
    case.update(case_id=name, outputs=str(output / name), selection="POST_DRAIN_HOST_TO_NATIVE_PARAMETER_BINDING")
    case["acceptance_identity"]["case_id"] = name
    cases[name] = case
    # Finite, predeclared OFF/ON control repetitions. No retrospective fastest
    # sample selection; each entry retains its own source/config/launcher.
    for arm in ("OFF", "ON"):
        source = "PROFILE_" + arm + "_long_control"
        for repetition in range(1, 4):
            name = f"PERF_{arm}_long_{repetition:02}"
            case = copy.deepcopy(cases[source])
            for field in ("argv", "launch_argv"):
                case[field] = [v.replace(source, name) for v in case[field]]
            for command in case["validation_commands"]:
                command["argv"] = [v.replace(source, name) for v in command["argv"]]
            case.update(case_id=name, outputs=str(output / name), performance_repetition=repetition,
                        selection="FINITE_UNCOLLECTED_CONTROL_NOT_SPEEDUP_PROOF")
            case["acceptance_identity"]["case_id"] = name
            case.pop("check_argv", None)
            case.pop("additional_checks", None)
            cases[name] = case
    name, source = "PROFILE_ON_long_materialize", "PROFILE_ON_long_normal"
    case = copy.deepcopy(cases[source])
    for field in ("argv", "launch_argv"):
        case[field] = [v.replace(source, name) for v in case[field]] + ["--repair8-materialize-ranges"]
    for command in case["validation_commands"]:
        command["argv"] = [v.replace(source, name) for v in command["argv"]]
    case.update(case_id=name, outputs=str(output / name), selection="BOUNDED_NORMAL_MATERIALIZE_HOST_RANGES")
    case["acceptance_identity"]["case_id"] = name
    case.pop("check_argv", None)
    case.pop("additional_checks", None)
    cases[name] = case
    add_warm_performance_cases(cases, inputs, output)
    add_counter_length_cases(cases, inputs, output, repo, python)
    # Explicit Python exceptions exercise the real C1 finally; unlike ABORT's
    # os._exit, these must export quarantine + next-scope Host guard evidence.
    for point in ("before_replay", "after_replay", "after_update", "after_completion"):
        name = "UNWIND_" + point
        case = copy.deepcopy(cases["O0"])
        for field in ("argv", "launch_argv"):
            case[field] = [v.replace("O0", name) for v in case[field]] + ["--repair8-unwind-at", point]
        case.update(case_id=name, outputs=str(output / name), unwind_point=point,
                    dependencies=["CONFIG", "B0", "C2"], selection="REQUIRED_REAL_C1_PYTHON_UNWIND")
        case["acceptance_identity"]["case_id"] = name
        case["validation_commands"] = [dict(kind="read_only_acceptance", timeout=120, argv=[
            python, str(repo / "tools/p7x_graph_repair8_unwind.py"),
            "--artifact", str(output / name / "python-unwind.json"),
            "--campaign", str(output / name / "campaign.json"),
            "--launcher", str(output / "launchers" / name / "launcher.json"),
            "--plan", str(output / "case-plan.json"), "--case-id", name,
            "--output", str(output / name / "unwind-joint.json"),
        ])]
        case.pop("check_argv", None)
        case.pop("additional_checks", None)
        cases[name] = case
    name = "UNWIND_materialize_after_copy"
    case = copy.deepcopy(cases["O0"])
    for field in ("argv", "launch_argv"):
        case[field] = [v.replace("O0", name) for v in case[field]] + ["--repair9-materialize-unwind"]
    case.update(case_id=name, outputs=str(output / name), dependencies=["CONFIG", "B0"],
                selection="REAL_MATERIALIZE_PYTHON_UNWIND_BEFORE_TYPED_INPUTS",
                unwind_point="materialize_after_table_copy")
    case["acceptance_identity"]["case_id"] = name
    case["validation_commands"] = [dict(kind="read_only_acceptance", timeout=120, argv=[
        python, str(repo / "tools/p7x_graph_repair9_materialize_fault.py"),
        "--artifact", str(output / name / "materialize-unwind.json"),
        "--campaign", str(output / name / "campaign.json"),
        "--launcher", str(output / "launchers" / name / "launcher.json"),
        "--plan", str(output / "case-plan.json"), "--case-id", name,
        "--output", str(output / name / "materialize-unwind-joint.json"),
    ])]
    case.pop("check_argv", None)
    case.pop("additional_checks", None)
    cases[name] = case
    config_argv = [
        python,
        str(repo / "tools/p7x_graph_repair7.py"),
        "config-check",
        "--framework",
        "--plan",
        str(output / "case-plan.json"),
        "--output",
        str(output / "Config_Contract_Matrix.json"),
    ]
    cases["CONFIG"] = dict(
        argv=config_argv,
        timeout_seconds=300,
        dependencies=[],
        validation_commands=[],
        selection="MODEL_FREE_FRAMEWORK_CONFIG",
    )
    name = "UNWIND_metadata_before_publish"
    source = "UNWIND_materialize_after_copy"
    case = copy.deepcopy(cases[source])
    for field in ("argv", "launch_argv"):
        case[field] = [v.replace(source, name).replace("--repair9-materialize-unwind", "--repair10-metadata-unwind")
                       for v in case[field]]
    case.update(case_id=name, outputs=str(output / name), unwind_point="metadata_before_publish",
                selection="OPT_IN_REAL_METADATA_PUBLICATION_PYTHON_UNWIND")
    case["acceptance_identity"]["case_id"] = name
    for command in case["validation_commands"]:
        command["argv"] = [v.replace(source, name)
                           .replace("p7x_graph_repair9_materialize_fault.py", "p7x_graph_repair10_metadata_fault.py")
                           .replace("materialize-unwind", "metadata-publish-unwind") for v in command["argv"]]
    cases[name] = case
    internal_name = "UNWIND_metadata_store_publish"
    internal = copy.deepcopy(case)
    for field in ("argv", "launch_argv"):
        internal[field] = [v.replace(name, internal_name).replace("--repair10-metadata-unwind",
                                                               "--repair10-metadata-store-unwind")
                           for v in internal[field]]
    internal.update(case_id=internal_name, outputs=str(output / internal_name), unwind_point="metadata_store_publish")
    internal["acceptance_identity"]["case_id"] = internal_name
    for command in internal["validation_commands"]:
        command["argv"] = [v.replace(name, internal_name) for v in command["argv"]]
    cases[internal_name] = internal
    from tools.p7x_graph_repair10_performance import add_cases

    add_cases(cases, inputs, output, repo, python)
    from tools.p7x_graph_repair11_method_anchor import add_cases as add_method_cases

    add_method_cases(cases, inputs, output, repo, python)
    for name, case in cases.items():
        model = "run" in case["argv"] and any(Path(a).name in ("p7x_graph_repair2.py",
                                                       "p7x_graph_repair11_method_anchor.py") for a in case["argv"])
        case["requires_device_admission"] = model or name in ("P0", "C2", "CONFIG", "CONFIG_DFLASH")
        if model:
            case["dependencies"] = list(dict.fromkeys(["CONFIG", *case["dependencies"]]))
        if name in ("G4F_COMPARE", "TARGET4_COMPARE"):
            prefix = name.removesuffix("_COMPARE")
            case["attempt_dependencies"] = [prefix + "_OFF", prefix + "_ON"]
    ordered = {}
    while len(ordered) < len(cases):
        ready = {
            name: case
            for name, case in cases.items()
            if name not in ordered and all(dep in ordered for dep in case.get("dependencies", []))
        }
        if not ready:
            raise ValueError("cyclic Repair7 dependency")
        ordered.update(ready)
    plan["cases"] = ordered
    plan.update(
        schema="repair7-case-plan-v1",
        publication_status="NOT_PUBLISHED",
        authorized_host_phy_ids=list(range(8)),
        tp=1,
        device_admission_receipt=None,
        device_admission_sha256=None,
        resume_policy="new attempt; no inherited success without exact source/run evidence",
        readiness="PRE_PUBLICATION; model-free CONFIG still requires authorized runtime mapping",
    )
    return plan


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "inputs", "output", "vllm"):
        p.add_argument("--" + name, type=Path, required=True)
    for name in ("python", "sha", "tree", "run-id"):
        p.add_argument("--" + name, required=True)
    a = p.parse_args()
    plan = build_plan(a.repo, a.inputs, a.output, a.vllm, a.python, a.sha, a.tree, a.run_id)
    atomic_json(a.output / "case-plan.json", plan)


if __name__ == "__main__":
    main()
