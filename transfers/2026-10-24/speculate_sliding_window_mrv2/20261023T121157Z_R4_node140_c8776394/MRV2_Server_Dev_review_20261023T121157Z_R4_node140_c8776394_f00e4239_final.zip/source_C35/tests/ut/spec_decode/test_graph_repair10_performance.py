# SPDX-License-Identifier: Apache-2.0
"""Separate performance workload; no relaxation of the frozen sixteen-token joint."""

import copy
import hashlib
import json
from types import SimpleNamespace

import pytest
from vllm.v1.metrics.stats import RequestSpecDecodeMetrics

from tools.p7x_graph_repair10_performance import acceptance_counts, add_cases, check, configure, request_metrics


def real_metrics():
    metrics = RequestSpecDecodeMetrics.new(7)
    for proposed, accepted in [(7, 0), (5, 3), (7, 7)]:
        metrics.observe(proposed, accepted, detailed=True)
    return metrics


@pytest.mark.parametrize("arm", ["G_OFF", "G_ON", "E_ON"])
def test_only_draft_execution_changes_and_metrics_use_existing_pinned_interface(arm):
    config = dict(enforce_eager=False, speculative_config={}, additional_config={})
    args = SimpleNamespace(
        repair10_performance_arm=arm,
        case="A0" if arm == "G_OFF" else "B-observer-off",
        repair5_capture_profile="target4",
        repair5_profile="control",
        repair10_max_model_len=12288,
    )
    configure(config, args)
    assert config["enforce_eager"] is False
    assert config["speculative_config"]["enforce_eager"] is (arm == "E_ON")
    assert config["per_request_spec_decode_metrics"] == "detailed"
    result = SimpleNamespace(
        request_id="r",
        finished=True,
        metrics=None,
        outputs=[SimpleNamespace(finish_reason="length", spec_decode_metrics=real_metrics())],
    )
    counts = acceptance_counts(request_metrics([result])[0]["speculative_decoding"])
    assert counts["proposed_draft_tokens"] == 19  # actual 5, not padded 7, at step two.
    assert counts["accepted_draft_tokens"] == 10  # bonus excluded, not generated-token count.
    assert counts["verification_request_steps"] == 3
    assert counts["proposed_per_position"] == [3, 3, 3, 3, 3, 2, 2]
    assert counts["accepted_per_position"] == [2, 2, 2, 1, 1, 1, 1]


@pytest.mark.parametrize(
    "field",
    [
        "num_draft_tokens",
        "num_accepted_draft_tokens",
        "num_spec_steps",
        "draft_acceptance_rate",
        "mean_acceptance_length",
    ],
)
def test_rejects_wrong_counts_and_bonus_definition(field):
    data = real_metrics().to_dict()
    data[field] += 1
    with pytest.raises(ValueError):
        acceptance_counts(data)


def specimen(tmp_path):
    from tools.p7x_graph_repair5_evidence import file_sha

    identity = dict(
        run_id="run",
        case_id="PERF10_G_ON_long_01",
        attempt_id="1",
        source_sha="a" * 40,
        source_tree="b" * 40,
        driver_mode="B-observer-off",
        process_id=12,
        engine_id=13,
    )
    request = [dict(label="long", prompts=["natural prompt"], max_tokens=256)]
    request_path = tmp_path / "requests.json"
    request_path.write_text(json.dumps(request))
    checksum = file_sha(request_path)
    argv = ["python", "run", "--repair10-performance-arm", "G_ON"]
    expected = dict(
        acceptance_identity=identity,
        argv=argv,
        launch_argv=["launch", "--", *argv],
        requests_sha256=checksum,
        request_path=str(request_path),
        outputs=str(tmp_path),
        performance_arm="G_ON",
        performance_workload="long",
    )
    launcher = dict(
        identity,
        pid=12,
        argv=argv,
        requests_sha256=checksum,
        host_start_ns=1,
        host_end_ns=100,
        status="EXITED",
        returncode=0,
        signal=None,
        timeout=False,
    )
    profile = dict(
        identity=identity,
        calls=[
            dict(active=True, label="Target_REPLAY_SUBMIT"),
            dict(active=True, label="Draft_REPLAY_SUBMIT"),
            dict(
                active=True,
                label="Draft_REPLAY_PLUS_UPDATE",
                window_descriptors=[dict(source_start_column=1, first_token_offset=0)],
            ),
        ],
    )
    artifact = tmp_path / "profile.json"
    artifact.write_text(json.dumps(profile))
    campaign = dict(
        identity=identity,
        startup_complete=True,
        status="OK",
        request_manifest=dict(sha256=checksum, entries=request),
        llm_kwargs=dict(
            enforce_eager=False,
            speculative_config=dict(enforce_eager=False),
            compilation_config=dict(cudagraph_capture_sizes=[7, 14, 28, 32]),
            additional_config=dict(draft_window_size=1024),
        ),
        observer_installation=dict(recorder_enabled=False),
        warmup=dict(policy="ALL_DECLARED_GROUPS", groups=[{}]),
        diagnostic_artifacts={artifact.name: dict(bytes=artifact.stat().st_size, sha256=file_sha(artifact))},
        outputs=[
            dict(
                label="long",
                prompts=request[0]["prompts"],
                host_start_ns=2,
                host_end_ns=90,
                prompt_token_ids=[[1] * 1201],
                token_ids=[[2] * 256],
                performance_metrics=[dict(finished=True, speculative_decoding=real_metrics().to_dict())],
            )
        ],
    )
    return campaign, launcher, profile, expected, artifact


@pytest.mark.parametrize(
    "damage",
    [
        None,
        "source",
        "argv",
        "hash",
        "arm",
        "target",
        "count",
        "length",
        "crop",
        "observer",
        "warmup",
        "timeout",
        "pid",
        "histogram",
    ],
)
def test_actual_pinned_metrics_and_full_execution_join_reject_damage(tmp_path, damage):
    args = list(specimen(tmp_path))
    campaign, launcher, profile, expected, artifact = args
    if damage == "source":
        campaign["identity"] = dict(campaign["identity"], source_sha="c" * 40)
    elif damage == "argv":
        launcher["argv"] = ["other"]
    elif damage == "hash":
        artifact.write_text("changed")
    elif damage == "arm":
        campaign["llm_kwargs"]["speculative_config"]["enforce_eager"] = True
    elif damage == "target":
        profile["calls"][0]["label"] = "other"
    elif damage == "count":
        campaign["outputs"][0]["performance_metrics"][0]["speculative_decoding"]["num_draft_tokens"] += 1
    elif damage == "length":
        campaign["outputs"][0]["token_ids"][0].pop()
    elif damage == "crop":
        profile["calls"][2]["window_descriptors"][0]["source_start_column"] = 0
    elif damage == "observer":
        campaign["observer_installation"]["recorder_enabled"] = True
    elif damage == "warmup":
        campaign["warmup"]["groups"] = []
    elif damage == "timeout":
        launcher["timeout"] = True
    elif damage == "pid":
        launcher["pid"] += 1
    elif damage == "histogram":
        campaign["outputs"][0]["performance_metrics"][0]["speculative_decoding"]["acceptance_histogram"][0] += 1
    result = check(*args)
    assert (result["status"] == "PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE") is (damage is None), result


def test_opt_in_plan_is_independent_and_freezes_argv_hashes(tmp_path):
    (tmp_path / "requests").mkdir()
    path = tmp_path / "requests/performance10-long.json"
    cases = {}
    for arm in ("OFF", "ON"):
        name = f"PROFILE_{arm}_long_control"
        cases[name] = dict(
            case_id=name,
            request_path="old.json",
            outputs=name,
            acceptance_identity=dict(case_id=name),
            dependencies=["CONFIG", "B0"],
            argv=[name, "--repair5-profile", "control", "--requests", "old.json"],
            launch_argv=[name, "--repair5-profile", "control", "--requests", "old.json"],
            check_argv=[],
            additional_checks=[],
        )
    before = copy.deepcopy(cases)
    add_cases(cases, tmp_path, tmp_path, tmp_path, "python")
    assert cases == before
    path.write_text(json.dumps([dict(label="long", prompts=["x"], max_tokens=256)]))
    add_cases(cases, tmp_path, tmp_path, tmp_path, "python")
    assert all(cases[k] == v for k, v in before.items())
    assert len(cases) == 14
    for name, case in cases.items():
        if name in before:
            continue
        assert case["acceptance_identity"]["case_id"] == case["case_id"] == name
        assert case["requests_sha256"] == hashlib.sha256(path.read_bytes()).hexdigest()
        assert case["dependencies"] == ["CONFIG", "B0"]
        assert "--repair9-warmup-all" in case["argv"]


@pytest.mark.parametrize("cropped", [False, True])
def test_eager_long_requires_actual_materialized_host_crop(tmp_path, cropped):
    args = list(specimen(tmp_path))
    campaign, launcher, profile, expected, artifact = args
    expected["performance_arm"] = "E_ON"
    campaign["llm_kwargs"]["speculative_config"]["enforce_eager"] = True
    profile["calls"] = [
        dict(active=True, label="Target_REPLAY_SUBMIT"),
        dict(
            active=True,
            label="Draft_retire_host",
            request_group="long",
            generation=7,
            mapping_epoch=9,
            start_ns=3,
            end_ns=89,
        ),
    ]
    campaign["outputs"][0]["window_runtime_after_request"] = dict(
        evidence_kind="HOST_MATERIALIZED_IDENTITY_NOT_DEVICE_COMPLETION",
        generation=7,
        epoch=9,
        active=1,
        padded=1,
        read_descriptors=[dict(source_start_column=1 if cropped else 0, first_token_offset=0)],
    )
    result = check(*args)
    assert (result["status"] == "PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE") is cropped, result


def test_host_materialized_identity_never_reads_device_tensors():
    from dataclasses import dataclass

    from tools.p7x_graph_repair10_performance import final_window_state

    @dataclass(frozen=True)
    class Descriptor:
        source_start_column: int = 3
        first_token_offset: int = 0

    identity = SimpleNamespace(
        generation_id=5,
        mapping_epoch=9,
        actual_request_count=3,
        padded_request_count=4,
        read_descriptor_fingerprint=(Descriptor(),),
    )
    owner = SimpleNamespace(_draft_window_runtime_state=SimpleNamespace(_last_retired_identity=identity))
    state = final_window_state(owner)
    assert state["generation"] == 5 and state["epoch"] == 9
    assert state["read_descriptors"][0]["source_start_column"] == 3
    assert final_window_state(SimpleNamespace()) is None


def test_eager_long_rejects_stale_identity_from_warmup(tmp_path):
    args = list(specimen(tmp_path))
    campaign, launcher, profile, expected, artifact = args
    expected["performance_arm"] = "E_ON"
    campaign["llm_kwargs"]["speculative_config"]["enforce_eager"] = True
    profile["calls"] = [
        dict(active=True, label="Target_REPLAY_SUBMIT"),
        dict(
            active=False,
            label="Draft_retire_host",
            request_group="warmup/long",
            generation=7,
            mapping_epoch=9,
            start_ns=3,
            end_ns=89,
        ),
    ]
    campaign["outputs"][0]["window_runtime_after_request"] = dict(
        evidence_kind="HOST_MATERIALIZED_IDENTITY_NOT_DEVICE_COMPLETION",
        generation=7,
        epoch=9,
        active=1,
        padded=1,
        read_descriptors=[dict(source_start_column=2, first_token_offset=0)],
    )
    result = check(*args)
    assert result["status"] == "INVALID_EVIDENCE"
    assert "not from this measured request" in result["error"]
