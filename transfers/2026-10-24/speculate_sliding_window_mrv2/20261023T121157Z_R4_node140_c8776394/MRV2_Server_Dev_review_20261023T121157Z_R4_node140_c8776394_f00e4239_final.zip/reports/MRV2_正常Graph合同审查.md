# R4 正常 Graph 合同核对（进行中）

本轮继承 R3 的 SOURCE_SUPPORTED_CONTRACT，不重复相同 dump。固定 production 与 C28 相同；140 新 C29 已完成真实 probe、CONFIG/A0/A1/B0、C2 与连续数值前哨。

|问题|依据与本轮变化|剩余裁决|
|---|---|---|
|A 最后 consumer 后再写 backing|R3 Runtime9.1 capture added-stream tail notify 合流 → Stars RI endGraphNotify → current FIFO 的具体源码推导保留。140 实际 worker 加载 libruntime_v100.so，版本/关键库hash与既有lineage匹配。|SOURCE_SUPPORTED_CONTRACT；平台维护者确认本安装分支无额外consumer或补丁例外，不能由同版号推导全部分支。|
|B UPDATE 生效代际|单 update stream、wait-current前缀、ExternalEvent wait/reset/UPDATE/record，同流FIFO；FIA Host长度vector拥有拷贝。production成功路径未改变。|SOURCE_SUPPORTED_CONTRACT；task-group与event适用性由维护者审查。未增加逐代sync。|
|实际执行occurrence|C19 native15只为post-drain exported parameters；本轮不重采同字段。|OBSERVABILITY_LIMIT；无真实版本occurrence关联，不用合成ts/dur硬配generation。|
|physical read-set|数学、输出、参数绑定、实际地址读取、性能收益分别报告。旧G3门槛保留。|ACCEPTANCE_SCOPE_DECISION；已提出follow-up，owner未回复不视为降低门槛。|

证据：`140_WORKER_APPLICABILITY.json`及其worker provenance引用；完整具体源码链位于`../../return/20261022T193442Z_R3/MRV2_正常Graph合同审查.md`和R2平台源码实际位于 reports/20261022T132626Z_R2/platform_sources（不是return下）。本报告不声称normal device completion实测或正式Gate开放。

## R4最终140适用性补证

本轮进一步只读运行npu-smi info -t board -i4 -c0：NPU Name9382、ChipAscend910/V1、Board0xb1、PCI0000:8D:00.0、Firmware9.0.0.0.205；管理版本26.0.rc1。product查询虽然rc0，却明确输出不支持，不能记为取得product资料。原件在environment/npu_smi_phy8_board_final.txt，最小字段在PHY8_HARDWARE_APPLICABILITY_FINAL.json。

新C35实际worker再次实载libruntime_v100.so及匹配的torch_npu/native库，PID/start_ticks和SHA256见C35_WORKER_APPLICABILITY.json。已有CANN9.1/torch_npu/op-plugin源码、FIA Host vector复制、五步依赖推导继续有效作为SOURCE_SUPPORTED_CONTRACT；没有重新称为“完全没有API证据”。已保存源码/公开头文件未找到9382到CHIP_910_B_93注册的直接映射，不代表不支持，也不能按数字相似直接认定适用。

平台维护者（负责人待确认）的具体问题：上述9382/V1/firmware/driver/runtime_v100组合是否适用当前版本的attached-stream endGraphNotify最后消费者合流及task-group UPDATE/ExternalEvent序列保证？请给版本范围/API保证或对应源码映射。若这些已满足公开使用合同，工程审查应在明确前提下认可推导，不无限要求每个二进制分支反编译；执行occurrence/physical-read的取证方式与最终验收仍需分别裁决。
