# 方法差异与最小扩展顺序

本轮以完整产品目标为最终目标。下面是实际代码/工具缺口，不能转换为产品不支持；具体Graph叠加组合仍按最终范围矩阵逐项澄清。当前只完成DSpark阶段实验，不把剩余事项隐藏为后续可选功能。

## DFlash：已有parallel Graph候选接入，尚无本轮方法设备验收

C34 `draft_window_graph_characterization.py:849` 的source builder明确接受dflash或dspark、static K、STANDARD dense/FIA single direct-prefix group；:818限制TP/DP/PP/PCP/DCP=1、FULL/FULL_DECODE_ONLY、async/prefix/SP/DSA-CP/FlashComm关闭。这是当前实验接入边界，不能推断最终产品范围永久只支持TP1。

`dflash/speculator.py:100` 按`num_query_per_req`建立metadata；:234进入proposal scope。与DSpark sample_from_anchor=true的Q=K不同，DFlash应核对实际Q=K+1及sample offset。当前真实可见Qwen3-8B-DFlash-b16配置由OTHER_METHOD_MODEL_PREFLIGHT_READONLY.json记录，但模型可见不等于Graph已运行。当前committed campaign的冻结模型/fixture和numeric producer仍是DSpark Q7合同，不能直接替换checkpoint冒用fixture身份。

最小方法扩展：建立独立DFlash模型/config/fixture manifest，先真实CLI/framework和capture库存；由实际K/Q推导capture，不复制[7,14,28,32]；验证K15/Q16与active3/padded4、同Window独立eager参考、Target full write/slot/positions、生命周期与异常；随后才做正常请求和性能接受率。C32 continuing-prefill修复与DFlash共用manager，原Host反例只覆盖Q7/8，Q16是需要补的独立几何，不能声称已被原测试覆盖。

## Eagle3：autoregressive step消费者与parallel proposal不同

实际文件是`worker/v2/spec_decode/eagle/speculator.py`和`draft_window_eagle3.py`，不是不存在的eagle3/speculator.py。后者显式保存first pass、last identity、next step、static K、step-one exact等状态。当前parallel characterization builder不接Eagle3，已有非GraphAR adapter不能当作Graph持久carrier/update完成合同已经接入。

最小工作：沿真实AR capture/每step replay入口补Graph read-view与精确长度/epoch绑定；明确一次proposal内多step消费者最后使用backing的顺序，建立成功/异常分支反例；在单独固定候选和合法模型拓扑上验证。不得把DSpark一次parallel replay的LIFE或参数快照直接归给AR多step。

## 必需拓扑与叠加合同

历史Graph dependency文档将TP16列mandatory；当前source明确只开放单卡实验，仍是实现/验证缺口。不能用TP8/TP1替代。模型可见性、资源授权、各rank拓扑和backend必须重新准入。模式和async/prefix/SP/DSA-CP/FlashComm并非任意笛卡尔积；已向用户请求具体最终Graph组合清单/负责人，潜在必须项仍OPEN。MRV1/Frozen明确forced-OFF的MTP/DeepSeek-V4保持原语义，不能为跑矩阵硬启用。

## 与非Graph PR的关系

保持用户已确认的执行顺序：独立Graph先继续，最终集成要求不取消。PR固定测试C10 commit7b2ac4737b0dfe62fb99459e2ef815f8956c8461、vLLM a98247ab4db686ee03c66d5feb3c761e52a2f8ab不是已批准最终基线，handoff明确NOT_READY。Graph仍84030bbe pin，C34与C33生产子树相同。未来应在双方确认的固定pair上建立独立集成分支，不能复制活动PR或更换共享Python。详细接口和必需重验见MRV2_PR集成准备与必需回归.md。

上述是剩余实现清单与可执行顺序，不是宣布原定整体适配完成。
