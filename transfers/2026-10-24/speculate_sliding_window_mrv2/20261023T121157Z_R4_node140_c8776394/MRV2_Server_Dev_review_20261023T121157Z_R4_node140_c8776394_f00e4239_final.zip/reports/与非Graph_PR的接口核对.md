# R4 非Graph PR只读核对

PR声明状态记录于PR_SOURCE_DECLARED_READONLY.json：Ascend 7b2ac4737b0dfe62fb99459e2ef815f8956c8461，vLLM a98247ab4db686ee03c66d5feb3c761e52a2f8ab；Graph仍为84030bbe3d74d99bad477a3d2e37a973ccd8865c / Python3.11。该声明不是用户批准的集成基线。未导入PR工作树、未cherry-pick、未复制其Python3.12环境。

|接口|Graph当前|集成应保留|
|---|---|---|
|exact/read-view|本代prepared exact snapshot、immutable generation/epoch/descriptor|只能使用认证本代拥有CPU exact，不能以upper或旧缓存替代|
|metadata selector|explicit CPU lengths与Draft独立metadata|PR owned-read selector需接收Graph认证桥，不能污染Target|
|generation/lease|持久carrier、single active lease、proposal scope|精确身份与reader完成独立，不以Host return代替|
|异常隔离|quarantine、Host guard、子进程退出|未知native部分提交不清零/恢复/再用|
|产品配置|实验Gate默认关闭、Base与Target4独立|最终固定pin/范围审查后才建立独立集成候选|

等待用户确认正式固定基线；独立Graph与PR各自PASS不能拼成产品集成PASS。
