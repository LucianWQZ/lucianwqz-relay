# Graph支持范围与发布条件

## 当前可提交审查的阶段范围

Qwen3-8B+dspark_qwen3_8b_block7，static K7、sample_from_anchor=true、TP/DP/PP/PCP/DCP1、STANDARD dense GQA/FIA，W1024/block128。当前真实引擎为FULL_DECODE_ONLY（runtime identity.topology_fingerprint与LLM kwargs均确认），decode capture descriptor为FULL；Target4 [7,14,28,32]为完整active1/2/3→padded4/4的阶段配置；Draft实际捕获(1,7)/(2,14)/(4,28)。Base [7,14,28]缺Target(4,32)是已知范围，不eager回退、不将Target4归成Base PASS。完整逐case证据见矩阵，允许同生产子树的明确历史引用，producer SHA绝不改写。

**模式边界**：Full Target指完整Target语义验证，不代表引擎FULL模式。当前没有本轮FULL/PIECEWISE独立设备验收。

## 真实入口与默认行为

additional_config.draft_window_size为产品配置入口；public Graph Window ON仍按GRAPH_FROZEN拒绝，A1核验具体原因。内部experimental候选路径可关闭heavy observer，同时保留provider/session与generation/quarantine保护。属性含characterization不表示保护只由observer开启；也不能把私有路径通过等同公开产品可用。公开Gate没有删除或开放。本轮C32修改只针对真实all-continuing-prefill的原定full-read baseline，decode缺桶仍拒绝。

## 完整产品目标仍未完成

见Graph最终交付范围与验收矩阵和MRV2_方法差异与最小扩展顺序。DFlash方法专用设备证据、Eagle3 AR Graph适配、原设计必需拓扑及明确的模式/特性组合、最终非Graph PR固定源码组合兼容性，仍有实现或验证缺口。不能将这些改成unsupported以缩减目标；MRV1原来明确forced-OFF的组合保持原语义，不无限扩展任意笛卡尔积。

## 发布前尚需满足

1. 对最终完整范围给出明确源码组合、实际配置入口、每方法/必要拓扑/组合的实现与设备覆盖，未覆盖不能从DSpark TP1外推。
2. 正常UPDATE/backing SOURCE_SUPPORTED_CONTRACT的140适用前提经审查；执行occurrence/operand与physical-read要求来源和可补证方案经独立技术评审及相应维护者/验收负责人确认。正确性要求没有被豁免；替代证明方案尚未批准。
3. 自然请求、替换、非对齐、padding/bucket切换和有界稳定性覆盖，不能将少量成功请求当普遍保证。未知native部分提交仍仅Host导出与进程隔离，未模拟破坏性故障。
4. 性能与接受率按同机G_OFF/G_ON/E_ON、有效工作量与有限重复给真实结果；性能测完不等性能达标，尚无已确认阈值。不同Window可能改变接受率，Graph/eager同Window对照单独评价。
5. 与最终获用户确认的PR commit/pin独立集成并重验受影响路径；当前PR测试C10 NOT_READY，不等批准基线，两份独立PASS不能拼整体PASS。
6. 具名发布/合入决定仍需相应授权；当前只本地commit，REMOTE_PUBLICATION=NOT_PERFORMED，不push/merge，不自行解冻Gate。

阶段材料具备可独立技术审查价值；原定完整MRV2 Sliding Window Graph发布审查条件目前尚未全部满足。
