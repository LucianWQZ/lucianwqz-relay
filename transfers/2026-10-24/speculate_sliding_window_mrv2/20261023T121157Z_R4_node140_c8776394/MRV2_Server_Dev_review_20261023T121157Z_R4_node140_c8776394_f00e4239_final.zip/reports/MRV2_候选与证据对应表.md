# 候选与证据对应表

|候选|完整SHA|证据|影响与限制|
|---|---|---|---|
|C28|c877639472386aedeb7df11f15b6bf75c078261c|迁移基线，原101历史证据|本轮以C29工具准入后测同生产子树，未把C29数据改成C28|
|C29|4087ff473aa560497de64dc6ecd13880f4648898|140真实配置/B0/前哨|production同C28；工具后8授权修复|
|C30|7fb3b55bd86e099abd5095766b1e155054bf2bcc|8K真实失败3次|2个NFS临时目录错误、1个continuing-prefill production调用链错误，全部保留|
|C31|8f60998084b1374a2ba5c126a15bd26b706fcffa|metadata before工具Host|未单独NPU|
|C32|45cd0e0296cd0ff64f30cc75d3e8a37805b8a71c|prefill修复、真实锚点/前哨/8K三臂pilot|pilot不是正式三次矩阵|
|C33|1d246b8f154e2dc5327d1924b7d7c078ca81d09b|完整12数值/ABA、Target4双臂12对、LIFE21、自然/性能/profiling|本轮完整阶段证据主体，serial诊断与正常采集分开|
|C34|d14317c6fc5cdd6be11cdf1ca80f2e3f85332706|metadata before/store实际Python异常|实际内部failure handler与外层quarantine，未知native未模拟|
|C35|f00e423936c23b0710fc2b5cd367d34ec7736d26|独立DFlash锚点与有界异构请求|具体结果见最新矩阵；production同C32/C33/C34，不将C33原件改SHA|

C32/C33/C34/C35生产子树精确相同7f8bd00506f1896233d9d3d1cddbc0c5b68ad1dd，csrc子树未变。C28生产子树b568bdc5b88bc5b87ff2938d1961b97107d8952b；本轮只两处生产文件作continuing-prefill phase修复。C35只是保存本地候选，REMOTE_PUBLICATION=NOT_PERFORMED，设备验证逐run/profile标明。

C19 native15与四ABORT/四Python unwind、C28原101完整数据仍为历史范围；C32改动时序/phase相关处按影响分析，不伪称这些旧证据为140/C35新跑。最终PR固定组合尚未集成。
