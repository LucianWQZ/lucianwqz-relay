# Graph 与非Graph PR 集成准备（固定身份只读核对）

用户明确当前先保持独立Graph候选，最终集成要求未取消。当前没有批准更换正式vLLM pin，也没有集成候选。

## 身份

Graph C32：45cd0e0296cd0ff64f30cc75d3e8a37805b8a71c / fc4d682b4aad954c9aee7b2d0755636801537ec6，vLLM84030bbe3d74d99bad477a3d2e37a973ccd8865c，Python3.11.10。

PR开发HEAD与固定测试C10 checkout均为7b2ac4737b0dfe62fb99459e2ef815f8956c8461 / b9091ce545e582f728df2c20f002d039372bf516，配套vLLM a98247ab4db686ee03c66d5feb3c761e52a2f8ab / 7f2a24a827bbbb2f211e02031f9d4d0d556d536c。只读git核验双仓干净。最新handoff/20261023T174408+0800_7b2ac473_101_tp16_6h明确“架构BLOCKED，A01 PARTIAL，PR NOT_READY”；它是固定测试/可恢复候选，不是已批准待合入基线。

## 接口与预计冲突

|接口|Graph当前|PR固定C10|移植/冲突处理|
|---|---|---|---|
|配置入口/forced-OFF|早期policy与experimental Graph内部flag，public Gate冻结|新版draft_window_policy/runtime；MTP forced-OFF保留|保留一套真实用户配置契约，不能两个policy各自产生不同判断；Graph默认拒绝和非Graph强制OFF均回归|
|exact/read-view|本代prepared seq_lens精确CPU snapshot、generation/epoch认证|DraftReadView.exact_cpu_for校验四个operand对象身份，_select_seq_lens消费owned view|移植认证桥而非直接复制旧CPU值；不能upper替exact；不能将Draft view附到Target|
|metadata|Graph持久carrier/capture identity+专用私有metadata|每代common metadata上apply owned read，DSA builder callback|Graph adapter需把持久carrier与PR新read-view统一；metadata字段/签名随pin不同必须逐项适配|
|generation/lease/reader|P3 lease+Graph provider、源码支持的current/update完成边|PR lifetime pool拥有read view、reader事件与跨流合同|不能用PR eager event代替Graph最后consumer；逐代/逐step retained对象与quarantine边界统一|
|异常|C28早期保留修复+C31发布异常工具+C32prefillphase flag|PR generation owner/pool异常路径，完整跨流late-reader仍有缺口|逐fault原路径反例移植；未知native部分提交只Host导出和隔离|
|prefill/decode|C32真实all-continuing prefill baseline，decode Graph；mixed仍缺适配|PR continuing/terminal/mixed row-phase projection|移植phase语义并保留Graph dispatch差异，不把mixed单一scalar裁剪|
|运行环境|Python3.11、native donor hash固定|PR独立Python3.12/native build|独立集成runtime按确认的pin构建，不覆盖任一共享安装|

## 集成后必需回归

1. 用户CLI→EngineArgs→platform/factory、默认OFF、非法值/字符串bool、Graph Gate预期拒绝、forced-OFF和原unsupported语义。
2. 实际capture inventory、DSpark K/K+1、DFlash/Eagle3不同consumer；受影响拓扑逐rank身份，不把TP1外推TP16。
3. 连续数值/ABA完整层、输入与KV前态、Target独立双臂Full-write/slot/positions。
4. 同一最终源码组合的LIFE诊断、正常依赖审查、metadata/早期materialize/Python/native隔离；请求替换、chunked/mixed/前缀/async按最终范围回归。
5. 同机G_OFF/G_ON/E_ON控制/预热/有限重复、接受率真实计数、正常profiling；PR非Graph性能不能代替Graph。

可引用：原始数学设计、匹配且未变的平台API合同、旧失败反例及未影响路径历史测试，均保留原SHA/设备身份。必须重验：更换pin/metadata/lifetime/capture adapter后相关设备数值、Target隔离、完整请求与生命周期，以及最终同机性能。两边独立PASS不能拼成集成PASS。

建议：继续本窗口Graph第一阶段；等待PR完成已声明A01/架构缺口并给明确最终pair后，带准确pair/差异一次性请求用户确认。当前不要求用户把尚NOT_READY的测试HEAD批准成最终基线。
