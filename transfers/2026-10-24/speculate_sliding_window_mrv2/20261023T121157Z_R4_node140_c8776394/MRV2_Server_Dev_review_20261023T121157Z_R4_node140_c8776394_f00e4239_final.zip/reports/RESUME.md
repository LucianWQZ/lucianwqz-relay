# R4最小恢复说明

当前node-25-140，SESSION 20261023T121157Z_R4_node140_c8776394；源C35 f00e423936c23b0710fc2b5cd367d34ec7736d26/tree 5383f503852c3e520bd10442ed7562e1df5a9a04，clean。本轮设备工作已结束，进程/租约0；当前CLI SQLite实开本机/tmp，101退出用户已确认。详见FINAL_PROCESS_RESOURCE_AUDIT.json。

原deadline 2026-10-23T22:11:57.418651+00:00，北京时间2026-10-24T06:11:57.418651+08:00；恢复不续期。不要自动启动旧commands.sh或重做C19/C33全部campaign。新会话先查state/R4_SESSION_STATE、progress.log、实际进程和租约，只有新的有效窗口且fresh映射/准入后才可设备派发。

## 已有真实证据

- C33：140完整12连续数值/ABA、Target4完整12对、LIFE21串行诊断、短/8K三次三臂性能、自然请求、三份正常profiling。
- C34：metadata before与store内Python异常真实调用链/handler/quarantine/Host下一scope拒绝。
- C35：DSpark实际CONFIG/A0/A1/B0；DFlash K15/Q16 G_OFF/E_ON/G_ON锚点；DSpark18组30请求/7680输出tokens稳定性。强度/限制按逐SHA表，不把C33原件改为C35NPU。
- C32–C35生产子树相同7f8bd00506f1896233d9d3d1cddbc0c5b68ad1dd；R4 production diff只continuing-prefill phase fix。

## 下一项最小实作

DFlash anchor不是完整方法验证。现有numeric诊断工厂只接DSpark、producer/checker Q7合同不可全局替换。需在真实DFlash capture output处建立默认关闭、generation/epoch强关联输出保留，并设计Q16的独立canonical Window eager参考，按完整层/KV前态、input_ids int32/positions int64/active3-padded4/slot语义补三样本，再12场景和独立Target双臂。模型/fixture已精确记录在inputs/20261023T121157Z_R4_node140_c8776394/dflash-k15-q16-fixture.json及raw/C35_prepare_01。

Eagle3 AR Graph、必需TP16/相关模式特性组合仍有实现与验收缺口，按最终范围矩阵推进，不缩减为DSpark完成。PR固定测试C10/vLLM a982仍NOT_READY，未经用户批准不切pin/集成；准备表已完成。

## 平台与性能

normal UPDATE/backing有具版本源码推导；140 Board9382、runtime_v100实际加载已记录，需匹配保证审查；execution operand/physical-read仍OPEN，post-drain参数/队列event流不能替代。V2独立技术评审包保留，不等正式批准。Window ON当前相对OFF短/8K回退，Graph同Window较eager有有限收益；阈值建议尚待答复，不自行判发布达标。

源码恢复使用本目录C28→C35 bundle，已在仅C28前置的新bare仓实际verify/fetch。环境/native/模型不在bundle；按runtime manifest与140环境报告恢复。当前Graph UUID01a161fb-8dba-7ae3-a260-abdee005da7a仅表示对话，不代表新宿主环境/设备授权。
