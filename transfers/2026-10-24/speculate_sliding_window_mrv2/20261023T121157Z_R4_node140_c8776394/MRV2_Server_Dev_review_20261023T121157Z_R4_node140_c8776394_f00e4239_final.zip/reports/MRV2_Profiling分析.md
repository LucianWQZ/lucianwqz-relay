# MRV2 Profiling分析

本轮新采集三份：C33 1d246b8f154e2dc5327d1924b7d7c078ca81d09b，node-25-140，Phy8，Target4；不是101旧trace的新命名。

|case|literal FIA kernel|Draft replay|direct replay flow|exact snapshot均值ms|Host H2D API|Host D2H API|
|---|---|---|---|---|---|---|
|PROFILE10_G_OFF_long|1640|40|0|NOT_APPLICABLE|911|120|
|PROFILE10_G_ON_long|1599|37|0|7.3652|887|117|
|PROFILE10_E_ON_long|1599|0|0|NOT_APPLICABLE|850|117|

## 采集窗口与观测影响

初始化/capture和完整请求组预热在开始采集之前，采集有界请求阶段。关闭heavy tensor observer、Target dump、numeric reference、逐代LIFE同步和native verbose；保留真实Graph dispatch，未使用业务is_profile=True。源probe/启动/配置/原件与解析器命令和hash均有索引。前序设备尾部与profiler停止/导出行为不能据Host边界自动证明完全排除，profiling有自身开销，结束可能drain，不用其证明正常backing完成。

## A. 真实Graph与工作量

独立performance-joint核验实际Draft/Target Graph。OFF Draft40/Target37，ON Draft37/Target36，E_ON Draft0/Target36；E_ON为实际Draft eager，Target仍Graph。literal FIA为1640/1599/1599。prefill不一定Graph，模型层数与调用计数只作工作量背景，不据同shape/同名硬配具体task。接受率及输出tokens在性能报告，不能用并行kernel duration之和当elapsed。

## B/C. Target、Draft、FIA与Host/task/stream/flow

Host角色由实际manager绑定区分；device FIA按CSV显式Name/Type识别其family，无法可靠将每个FIA task绑定Target/Draft某层及generation。flow解析使用真实ID、scope、pid/tid和显式起止，direct replay关联均0。replay+UPDATE父范围可见Host queue/event和device event flow，不能简称执行关联通过。generation_bound_execution_flow=NOT_AVAILABLE_NO_NATIVE_OCCURRENCE_ID。旧LIFE direct_matched=21/21也是event/queue口径，未升级为执行operand证据。POST_DRAIN native快照只用于最终参数，不使用其合成ts/dur作timeline。

## D. materialize与Host子范围

ON37份materialize均值约8.847ms、exact_length_snapshot约7.365ms；workspace约0.497ms、runtime约0.784ms。原字段host_statistics未列所有子范围，已从calls按active与label重新统计，保留脚本和原始Host区间。nested same-thread trace显示37份aten::to/copy_，copy_均值约7.256ms；这是现有seq_lens.to(cpu,int32,copy=True)的Host耗时，含等当前流既有生产/前序工作，不能全部归为小payload带宽。

C33首次未采控制的OFF每proposal两次metadata builder、ON/eager一次；按同线程精确区间并集，平均metadata约23.106/24.891/23.887ms。两次调用均值与一次均值不可直接混比，materialize本身也嵌套在其他范围，不能把这些sum相加。源码表明OFF builder也需精确CPU长度，等待可能出现在其他位置。未发现可证明等价且有端到端收益的删除项，没有将upper或旧代缓存替exact。

## E. 拷贝与同步

Host bare acl_memcpy_host_to_device API计数911/887/850；device_to_host120/117/117；未重复相加Enqueue/Dequeue。Host Event::synchronize80/78/78，具体导出duration另见JSON，均为API/导出范围而非某个Graph最后consumer证明。device MEMCPY_ASYNC任务3367/3501/3316，无方向字段；设备H2D/D2H/D2D分类NOT_AVAILABLE，不能将HostToDevice flow类别当H2D拷贝。各类EVENT_WAIT/RECORD、MEM_WAIT/WRITE、NOTIFY、MODEL_EXECUTE实际task数量和流分布保留于JSON。

## F. 空档与跨stream

按task_time.csv显式device/stream与同一导出时间域做区间并集、交叠统计；sum跨流duration不等elapsed。另给kernel导出未覆盖区间，它不证明整卡idle，可能是未导出任务或等待。没有校准Host monotonic_ns与设备clock，不直接相减。存在跨stream导出区间重叠，不等于证明某个generation最后消费者；归因仍需真实execution ID。

## G/H/I. 性能、观测成本与边界

OFF/ON和Graph/eager分别比较，控制有3次，profile各1次。profile与控制elapsed、有效tokens、replay、接受率逐cell保存；采集额外开销及共享整机背景限制结论。不同机器的snapshot时长变化不算代码加速。当前Window仍有回退，Graph同Window有有限收益，不宣称性能达标。正常UPDATE代际与backing复用依据是独立源码合同审查，profiling不补齐execution operand/physical read-set。

## 可复核入口

MRV2_Profiling_Summary.json逐case.raw给trace/CSV/DB索引；profiling/<case>/flow_analysis.json、csv_analysis.json、snapshot_nested_host_calls.json、typical_replay_fragment.json与PARSER_EXECUTION.json记录原字段、片段、脚本和退出码。完整raw在本轮runs目录。review包含关键小片段/源代码/统计及索引，非只给截图或自报PASS。

