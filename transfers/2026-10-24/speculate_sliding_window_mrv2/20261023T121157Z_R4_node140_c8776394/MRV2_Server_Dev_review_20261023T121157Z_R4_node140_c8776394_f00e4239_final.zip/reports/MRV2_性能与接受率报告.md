# MRV2 性能与接受率报告

节点node-25-140，生产数据SHA 1d246b8f154e2dc5327d1924b7d7c078ca81d09b，更新时间2026-10-23T21:42:39.890362+00:00。当前C35生产子树相同，仍保留C33 producer身份，不叫C35新跑。

## 两个分别的问题

G_ON/G_OFF测Window在Graph下的变化；G_ON/E_ON测相同Window语义下Graph相对Draft eager的变化。Target策略保持Graph，E_ON只令Draft enforce_eager。实际引擎FULL_DECODE_ONLY，capture descriptor FULL。

## 三次交错未采profiler控制

|组|重复/臂|G_OFF中位秒|G_ON中位秒|E_ON中位秒|ON相对OFF elapsed|Graph相对同Window eager elapsed|
|---|---|---|---|---|---|---|
|short-1-257|3|0.697976|0.810960|0.972752|+16.19%|-16.63%|
|short-3-257|3|0.812098|0.908368|1.064195|+11.85%|-14.64%|
|long-1-8193|3|1.528133|1.613384|1.788194|+5.58%|-9.78%|

负数表示该比较下elapsed更短。完整每次样本、min/max、输出tok/s、配置/请求hash与接受率在MRV2_性能与接受率_Summary.json和MRV2_性能逐cell原始计数.csv，未剔除慢样本。

Window ON在这些短/8K工作负载均有回退，未证明Window净加速。Graph在相同Window下有本组收益；不是所有模型/长度/拓扑的结论。当前没有批准的产品性能阈值，已提出待审建议，PERFORMANCE_THRESHOLD_PROPOSAL.json是建议而非团队既定标准或批准。性能回退保持OPEN。

## 工作量、预热与背景

模型Qwen3-8B+dspark_qwen3_8b_block7，K7、W1024、block128、TP1；max_model_len12288、max_num_batched_tokens4096、max_num_seqs4，Target4[7,14,28,32]。短输入257，batch1与3；长输入8193，batch1；均256输出、greedy seed0、ignore_eos。所有声明请求组均以同样256输出完整预热，再测请求阶段，初始化/capture另记。不是旧16-token正确性合同，也不是16K/128K矩阵。Graph长臂实际S>0；eager长臂用本请求内同generation/epoch的Host identity+retire关联确认S>0，不只按prompt推定。

Graph batch3可能padded4，eager不保证相同padding；真实capture descriptor直方图与最后Host identity另列，不把请求数等同全程active。per-replay实际active没有可靠字段时写NOT_AVAILABLE。Target batched replay与per-request verification steps是不同计数。

前八卡有其他任务；本任务仅Phy8。性能期避免本任务重Host测试、权重哈希与大trace解析，无法排除整机共享CPU/I/O/功耗背景，属于非独占诊断测量。不能当严格独占服务基准或跨机代码收益。三次重复有限，未做总体置信度保证。控制仍有轻量Host wrapper/record_function，未加设备操作；正式profiler在独立臂，不能把其elapsed当零开销控制。

## 接受率定义与实测

来自pinned scheduler的per_request_spec_decode_metrics=detailed，保存逐步drafted/accepted、histogram和各位置计数。proposed是实际scheduled长度，排除padding；accepted排除bonus；平均接受长度=1+accepted/verification_request_steps，包含bonus。统计在最终max_tokens裁剪前，末轮可能已验证但不返回；返回输出tokens另计。不是从输出量或greedy一致倒算。此采集复用已有CPU响应数据，未新增D2H或同步；仍有CPU统计成本，各臂相同配置。定义/源码见PERFORMANCE10_ACCEPTANCE_DEFINITIONS.json。

8K合成token组G_OFF每次proposed259/accepted220、接受率84.9421%、平均6.94595；G_ON和E_ON每次252/219、86.9048%、7.08333。请求输出都是256，接受率变化使实际验证工作量不同，不能只用总时间称Window算法加速。短合成重复token接受率约99.55%，不能外推真实业务质量。

真实文本natural组包含科学观察问题、不同长度河流研究段落、长后短替换；不是独立质量数据集。逐组接受率原值保留，例如G_ON科学问题约26.65%，与重复token测试明显不同。三臂均有有限完整请求结果；同冻结请求/greedy输出合同的逐组轨迹比较在normal_output_comparisons。该比较是端到端服务结果，不强配中间KV，不替代12场景连续数值。

TTFT/TPOT/ITL：实际RequestOutput.metrics为None，NOT_AVAILABLE；没有填0，也没有用elapsed反算这些分位数。当前elapsed含prefill+decode，输出tok/s按该整组请求耗时计算，不称纯稳态decode吞吐。

## profiling与下一步

三份正常long profiler分别分析，raw/CSV/DB/典型flow片段见MRV2_Profiling分析.md。snapshot含当前流前序工作等待，不可把其全部归传输带宽。OFF在metadata路径承担同类CPU长度准备；两边metadata调用次数不同，已按Host区间并集审查。没有发现可直接删除且保持本代exact/epoch/所有权合同的冗余，未启用R3仅约0.59%噪声收益的counter复用原型。下一步需要可审查的owned exact CPU来源/依赖方案与端到端对照，不能用upper bound、旧缓存或挪动等待凑加速。

