# R4资源记录

node140只使用Phy8，PCI0000:8D:00.0，mask8→logical0，TP1。共同目录的atomic-mkdir-v1已由本Graph采用并每段验证同挂载互斥；没有伪造其他任务确认或管理员owner。R3 node101的双方协议/TP16窗口是历史，本R4未继承其租约或窗口。前八他人任务保留，未抢占/kill/reset。资源授权来自本次用户，映射来自系统inspect/probe/管理PID。

七段租约实际起止与持有秒数见RESOURCE_LEASE_TIMELINE.json；持有含模型hash/加载与检查，不等NPU kernel时间。当前本任务进程和租约0，实查见FINAL_PROCESS_RESOURCE_AUDIT.json。初期CLI/容量中断与准备无法准确拆分为纯等待，不编造统计；所有时间计入R4。正常性能在非独占整机，背景与局限已记录。
