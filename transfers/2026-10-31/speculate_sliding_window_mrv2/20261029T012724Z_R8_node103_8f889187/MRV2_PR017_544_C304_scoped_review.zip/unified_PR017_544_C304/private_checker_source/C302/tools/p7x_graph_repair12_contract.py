# SPDX-License-Identifier: Apache-2.0
"""Named diagnostic method contracts, never inferred from tensors or outputs."""

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class ParallelMethodContract:
    name: str
    method: str
    k: int
    draft_query: int
    target_query: int
    sample_from_anchor: bool
    sample_offset: int
    causal: bool = False
    window: int = 1024
    block: int = 128

    def document(self):
        return asdict(self)

    def validate_owner(self, owner):
        if (
            owner.num_query_per_req != self.draft_query
            or owner.sample_from_anchor is not self.sample_from_anchor
            or owner.num_speculative_steps != self.k
        ):
            raise ValueError("runtime method/query/sampling contract mismatch")


def method_for_profile(profile):
    if profile in ("base", "target4"):
        return ParallelMethodContract("dspark_k7_anchor_q7", "dspark", 7, 7, 8, True, 0)
    if profile == "dflash_k15_q16":
        return ParallelMethodContract("dflash_k15_q16", "dflash", 15, 16, 16, False, 1)
    if profile == "dspark_k7_noanchor_q8":
        return ParallelMethodContract("dspark_k7_noanchor_q8", "dspark", 7, 8, 8, False, 1)
    if profile in ("glm52_dspark_k8_q8_sfa", "glm52_dspark_k8_q8_sfa_cp"):
        return ParallelMethodContract(profile, "dspark", 8, 8, 9, True, 0)
    if profile == "glm52_dflash_k15_q16_sfa":
        return ParallelMethodContract(profile, "dflash", 15, 16, 16, False, 1)
    raise ValueError("unknown named parallel method profile")


def validate_method_document(profile, document):
    expected = method_for_profile(profile).document()
    if (
        not isinstance(document, dict)
        or document != expected
        or set(document) != set(expected)
        or any(type(document[k]) is not type(v) for k, v in expected.items())
    ):
        raise ValueError("named method contract changed or missing")
    return method_for_profile(profile)


def add_cases(cases, inputs, output, repo, python):
    """Explicit Q16 cases on the committed producer, launcher and joint path."""
    import copy
    import hashlib
    import json

    fixture = inputs / "dflash-k15-q16-fixture.json"
    if not fixture.exists():
        return
    content = json.loads(fixture.read_text())
    fixture_sha = hashlib.sha256(fixture.read_bytes()).hexdigest()
    profile = "dflash_k15_q16"
    selections = [
        ("NUMERIC_SENTINEL", "DFLASH_NUMERIC_SENTINEL", ["CONFIG_DFLASH"]),
        ("NUMERIC_TARGET4", "NUMERIC_DFLASH", ["DFLASH_NUMERIC_SENTINEL"]),
        ("TARGET4_OFF", "DFLASH_OFF", ["DFLASH_NUMERIC_SENTINEL"]),
        ("LIFE", "DFLASH_LIFE", ["NUMERIC_DFLASH"]),
    ]
    for kind in ("ABORT", "UNWIND"):
        for point in ("before_replay", "after_replay", "after_update", "after_completion"):
            source = f"{kind}_{point}"
            if source in cases:
                selections.append((source, f"{kind}_DFLASH_{point}", ["DFLASH_LIFE"]))
    for source, name, dependencies in selections:
        case = copy.deepcopy(cases[source])
        for field in ("argv", "launch_argv"):
            argv = [x.replace(source, name) for x in case[field]]
            for option, value in (
                ("--draft-model", content["draft_model"]),
                ("--fixture-manifest", str(fixture)),
                ("--repair5-capture-profile", profile),
            ):
                if option in argv:
                    argv[argv.index(option) + 1] = value
                else:
                    argv += [option, value]
            request = (
                inputs / "requests" / (
                    "dflash-lifecycle.json"
                    if name == "DFLASH_LIFE" or name.startswith(("ABORT_", "UNWIND_"))
                    else "dflash-controlled.json"
                )
            )
            argv[argv.index("--requests") + 1] = str(request)
            case[field] = argv
        for command in case["validation_commands"]:
            command["argv"] = [x.replace(source, name) for x in command["argv"]]
        case.pop("check_argv", None)
        case.pop("additional_checks", None)
        case.update(
            case_id=name,
            outputs=str(output / name),
            dependencies=dependencies,
            capture_profile=profile,
            method_contract=method_for_profile(profile).document(),
            fixture_sha256=fixture_sha,
            request_path=str(request),
            requests_sha256=hashlib.sha256(request.read_bytes()).hexdigest(),
            selection="OPT_IN_INDEPENDENT_DFLASH_CONTROLLED_CONTRACT",
        )
        case["acceptance_identity"]["case_id"] = name
        if name == "DFLASH_LIFE":
            case["lifecycle_coverage"]["descriptors"] = [[n, n * 16] for n in (1, 2, 4)]
            case["normal_request_contract"] = "dflash_k15_q16_lifecycle_64"
        cases[name] = case


def verify_fixture_receipt(args, fixtures):
    """Reuse an explicit immutable prepare receipt; never silently trust a path."""
    import hashlib
    import json
    from pathlib import Path

    path = args.repair12_fixture_verification
    if path is None or args.repair12_fixture_verification_sha256 is None:
        raise ValueError("DFlash requires its frozen prepare fixture verification")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != args.repair12_fixture_verification_sha256:
        raise ValueError("method fixture receipt hash changed")
    proof = json.loads(raw)
    if (
        proof["source_sha"] != args.expected_sha
        or proof["fixture_sha256"] != hashlib.sha256(args.fixture_manifest.read_bytes()).hexdigest()
        or len(proof["files"]) != len(fixtures["files"])
    ):
        raise ValueError("method fixture receipt source/manifest mismatch")
    for expected, observed in zip(fixtures["files"], proof["files"]):
        file = Path(expected["path"])
        st = file.stat()
        if (
            str(file) != observed["path"]
            or expected["sha256"] != observed["sha256"]
            or st.st_size != observed["size"]
            or st.st_mtime_ns != observed["mtime_ns"]
        ):
            raise ValueError("fixture file changed since fixed preparation")
    return proof


def attach_fixture_verification(cases, receipt_path, receipt_sha):
    """Only the controlled producer accepts this CLI, not same-profile anchors."""
    from pathlib import Path

    for case in cases.values():
        argv = case["argv"]
        controlled_driver = any(Path(value).name == "p7x_graph_repair2.py" for value in argv)
        if case.get("capture_profile") == "dflash_k15_q16" and controlled_driver and "run" in argv:
            for field in ("argv", "launch_argv"):
                case[field] += [
                    "--repair12-fixture-verification",
                    str(receipt_path),
                    "--repair12-fixture-verification-sha256",
                    receipt_sha,
                ]
