# SPDX-License-Identifier: Apache-2.0
"""Explicit GLM TP16 K8 numerical/Target diagnostics and independent CPU joins.

Uses the established all-rank worker/process/device, submission-isolation and
chunked-storage chain with a separate named SFA/indexer payload contract. Dense
Qwen defaults are unchanged. Every rank must finish, not just the coordinator.
"""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
import json
import multiprocessing
from pathlib import Path
import sys
import time

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch

from tools.p7x_graph_repair4_target import _snapshot_value
from tools.p7x_graph_repair5_target import _tensor_equal, case_plan, logical_kv, sample_identity
from tools.p7x_graph_repair6_storage import CollectionReader
from tools.p7x_graph_repair12_contract import method_for_profile
from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair25_rank_numeric import (
    RankControlledTarget, RankNumericWorker, build_parser, check_external as common_check_external,
    check_rank_payload as common_check_payload, run_controlled,
    _initialize_cpu_payload_worker,
)
from tools.p7x_graph_repair32_glm_rank import (
    GLMRankWorker, TARGET, DRAFT, TARGET_CONFIG_SHA, DRAFT_CONFIG_SHA, build_glm_kwargs,
    profile_identity, validate_glm_worker, validate_model_configs,
)
from tools.p7x_graph_repair37_glm_target import (
    COMPONENTS, PROFILE, GLMControlledTarget, GLMTargetAdapter, isolation_errors, validate_record,
)


def build_kwargs(arm, tp):
    require(arm in ("ON", "OFF") and tp == 16 and type(tp) is int, "GLM numerical ABI is explicit complete TP16")
    kwargs = build_glm_kwargs(tp, window_on_review=arm == "ON")
    kwargs["worker_extension_cls"] = "tools.p7x_graph_repair38_glm_numeric.GLMNumericWorker"
    if arm == "ON":
        kwargs["additional_config"]["draft_window_graph_numeric_diagnostic"] = True
    return kwargs


def validate_fixture(plan_path, fixture):
    """Immutable small config/index identities, not a fictitious full weight hash."""
    plan, manifest = (json.loads(Path(p).read_text()) for p in (plan_path, fixture))
    require(plan["schema"] == "glm38-frozen-diagnostic-plan-v1"
            and manifest["schema"] == "glm38-model-identity-v1"
            and plan["fixture_sha256"] == digest(fixture)
            and plan["fixture_manifest"] == str(fixture), "GLM diagnostic fixture/plan identity mismatch")
    from tools.p7x_graph_local_candidate import _identity, BASE_SHA
    _identity(Path(plan["source"]),plan["source_sha"],plan["source_tree"],ancestor=BASE_SHA)
    identity = profile_identity()
    require(manifest["profile_identity"] == identity and plan["profile_identity"] == identity,
            "actual GLM config/quant/index identity differs from independently reconstructed profile")
    require(plan["source_sha"] and len(plan["source_sha"]) == 40 and len(plan["source_tree"]) == 40,
            "fixed diagnostic source identity required")
    return dict(plan=str(plan_path), plan_sha256=digest(plan_path), fixture_sha256=digest(fixture),
                source_sha=plan["source_sha"], source_tree=plan["source_tree"], profile_identity=identity,
                scope="HASHED_GLM_CONFIG_QUANT_WEIGHT_INDEX; original weight shards retained, no new full hash")


def model_contract(fixture, kwargs):
    manifest = json.loads(Path(fixture).read_text())
    require(manifest["profile_identity"] == profile_identity(), "independent GLM fixture changed")
    require(kwargs["model"] == str(TARGET) and kwargs["speculative_config"]["model"] == str(DRAFT), "GLM model pair changed")
    target, draft = (json.loads((p/"config.json").read_text()) for p in (TARGET,DRAFT))
    validate_model_configs(target,draft)
    cfg=draft["transformer_layer_config"]
    return dict(target=dict(path=str(TARGET/"config.json"),sha256=TARGET_CONFIG_SHA,layers=99,
                            decoder_layers=78,indexer_owners=21,backend="SFA_PLUS_INDEXER"),
                draft=dict(path=str(DRAFT/"config.json"),sha256=DRAFT_CONFIG_SHA,layers=cfg["num_hidden_layers"],
                           kv_heads=cfg["num_key_value_heads"],head_size=cfg["head_dim"]))


class GLMRankControlledTarget(RankControlledTarget, GLMControlledTarget):
    """Keep the real completed-sample Host barrier and GLM-specific cache ABI."""


class GLMNumericWorker(RankNumericWorker, GLMRankWorker):
    diagnostic_profile = PROFILE
    controlled_type = GLMRankControlledTarget

    def _validate_method_owner(self, spec):
        require(spec.method == "dspark", "GLM named numerical method is DSpark")
        method_for_profile(PROFILE).validate_owner(spec)
        require(spec.requires_non_causal is True, "actual normalized dense Draft mask differs")

    def _target_adapter(self, current, contract, **kwargs):
        return GLMTargetAdapter(current, rank_contract=contract, actual_rank=self.rank, **kwargs)


def component_keys(sample):
    inputs = _snapshot_value(sample["checkpoint"]["inputs"])
    return {name+"/"+kind for name,m in inputs["layers"].items() for kind,_ in COMPONENTS[m["metadata_class"]]}


def check_payload(path,payload,worker):
    validate_glm_worker(worker,16)
    require(payload["profile"] == PROFILE and payload["world_size"] == 16, "wrong GLM rank/profile")
    return common_check_payload(path,payload,worker,profile=PROFILE,record_validator=validate_record,
                                isolation_validator=isolation_errors,component_keys=component_keys)


def check_external(planned,execution):
    result=common_check_external(planned,execution,profile=PROFILE,kwargs_factory=build_kwargs,
        model_contract_factory=model_contract,fixture_validator=validate_fixture,payload_checker=check_payload,
        extra_worker_validator=validate_glm_worker,allow_external_only=True)
    if result["status"].startswith("PASS_SCOPED_"):
        try:
            declared=json.loads(Path(planned).read_text())
            parsed=build_parser().parse_args(declared["argv"][2:])
            proof=validate_fixture(parsed.fixture_plan,parsed.fixture)
            require(proof["source_sha"] == declared["source_sha"]
                    and proof["source_tree"] == declared["source_tree"],"GLM fixture source is not this producer")
        except (ValueError,KeyError,TypeError,OSError) as error:
            result.update(status="INVALID_EVIDENCE",error=str(error))
    result.update(glm_checker_tool_sha256=digest(__file__),profile=PROFILE,
                  target_binding_scope="SOURCE_OWNED_SFA_INPUTS_NOT_NATIVE_EXECUTION_OPERANDS")
    return result


def compare_rank(off_path,on_path, *, progress, profile=PROFILE, record_validator=validate_record,
                 isolation_validator=isolation_errors, sample_limit=None, case_selection=None):
    readers=[CollectionReader(off_path),CollectionReader(on_path)]
    headers=[reader.header for reader in readers]
    from tools.p7x_graph_repair25_rank_numeric import diagnostic_cases

    cases=diagnostic_cases(profile, case_selection)
    require(case_selection is None or sample_limit is None, "selected Target cases cannot also be a prefix")
    require(sample_limit is None or type(sample_limit) is int and sample_limit == 3,
            "only the explicitly named three-sample Target prefix is allowed")
    require([h["arm"] for h in headers] == ["OFF","ON"]
            and all(h["capture_profile"] == profile and h["cases"] == cases for h in headers), "GLM complete pair profiles differ")
    for key in ("run_id","source_sha","source_tree"):
        require(headers[0]["identity"][key] == headers[1]["identity"][key], "cross-source/campaign GLM pair")
    require(headers[0]["fixture_id"] == headers[1]["fixture_id"]
            and headers[0]["inventory"] == headers[1]["inventory"], "GLM fixture/ownership pair differs")
    require(all(reader.execution == "EXECUTED_SCOPED_NOT_GATE_CLOSURE"
                and (len(reader.samples) == len(cases) if sample_limit is None
                     else len(reader.samples) in (3, len(cases)))
                for reader in readers), "incomplete GLM full Target arm")
    selected = cases if sample_limit is None else cases[:sample_limit]
    result=dict(status="IN_PROGRESS",pairs=[],normal_overlap="UNPROVEN",physical_read="UNPROVEN",
                comparison_scope=("DSPARK_CP_0_10_2_ONLY_NOT_COMPLETE_TARGET14"
                                  if case_selection is not None and profile == "glm52_dspark_k8_q8_sfa_cp" else
                                  "MULTIROW_7_10_11_ONLY_NOT_COMPLETE_TARGET14" if case_selection is not None else
                                  "COMPLETE_TARGET_CASES" if sample_limit is None else "PREFIX3_ONLY_NOT_COMPLETE_TARGET14"),
                collected_samples=[len(reader.samples) for reader in readers])
    for i,case in enumerate(selected):
        require(all(not reader.incomplete(i) for reader in readers), "partial GLM sample")
        records=[reader.record(i) for reader in readers]
        require(all(record["identity"] == sample_identity(case,headers[0]["fixture_id"])
                    and record["status"] == "CAPTURED_COMPLETE" for record in records), "GLM sample identity/state mismatch")
        semantics=[record_validator(record) for record in records]
        require(semantics[0] == semantics[1], "GLM Target logical read/query preconditions differ")
        for record in records:
            require(_tensor_equal(logical_kv(record["checkpoint"]["kv_before"],record["block_owners"]),record["logical_pre_kv"])
                    and _tensor_equal(logical_kv(record["checkpoint"]["kv_after"],record["block_owners"]),record["logical_post_kv"]),
                    "forged derived logical Target cache")
            require(not isolation_validator(record), "Draft changed GLM Target state")
        require(_tensor_equal(records[0]["logical_pre_kv"],records[1]["logical_pre_kv"]), "GLM Target pre-state alignment failed")
        errors=[key for key in ("hidden","logits","logical_post_kv") if not _tensor_equal(records[0][key],records[1][key])]
        pair = dict(identity=records[0]["identity"],status="FAIL" if errors else "PASS",errors=errors)
        if case_selection is not None:
            pair["scenario_index"] = case["step"]
        result["pairs"].append(pair)
        write(progress,dict(**result,last_progress_epoch=time.time()))
    result["status"]=("FAIL" if any(row["status"] == "FAIL" for row in result["pairs"])
                      else "PASS_SELECTED_CASES" if case_selection is not None else
                      "PASS" if sample_limit is None else "PASS_PREFIX3")
    return result


def _compare_target_task(item):
    compare, task = item
    return compare(**task)


def ordered_target_comparisons(tasks, *, cpu_workers=1, compare=compare_rank):
    """Same complete comparisons in input order; each rank owns its progress file."""
    require(type(cpu_workers) is int and 1 <= cpu_workers <= 4, 'bounded explicit Target CPU worker count required')
    items = [(compare,task) for task in tasks]
    if cpu_workers == 1:
        yield from map(_compare_target_task,items)
        return
    functions = [compare]+[task['record_validator'] for task in tasks]+[task['isolation_validator'] for task in tasks]
    require(all(callable(fn) and '<' not in getattr(fn,'__qualname__','<unknown>') for fn in functions),
            'spawned Target comparisons require importable named validators')
    with ProcessPoolExecutor(max_workers=cpu_workers,mp_context=multiprocessing.get_context('spawn'),
                             initializer=_initialize_cpu_payload_worker) as pool:
        yield from pool.map(_compare_target_task,items)


def join_arms(args, *, profile=PROFILE, external_checker=check_external, validator_for_rank=None,
              isolation_validator=isolation_errors, cpu_workers=1):
    result=dict(status="INVALID_EVIDENCE",profile=profile,ranks=[],physical_read="UNPROVEN",normal_overlap="UNPROVEN")
    try:
        externals=[external_checker(args.off_planned,args.off_execution),external_checker(args.on_planned,args.on_execution)]
        result["external_arms"]=externals
        require(all(x["status"] == "PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC" and x["ranks"] == 16
                    and x["samples_per_rank"] == len(case_plan(profile)) for x in externals), "complete GLM all-rank arms required")
        plans=[json.loads(Path(p).read_text()) for p in (args.off_planned,args.on_planned)]
        parsed=[build_parser().parse_args(plan["argv"][2:]) for plan in plans]
        require([p.arm for p in parsed] == ["OFF","ON"] and all(p.repair6_target_prefix is None for p in parsed),"cannot join prefixes as complete")
        require(all(plans[0][k] == plans[1][k] for k in ("source_sha","source_tree")),"GLM pair source differs")
        parents=[json.loads((p.output/'parent-execution.json').read_text()) for p in parsed]
        require(parents[0]["payload"]["run_id"] == parents[1]["payload"]["run_id"]
                and parents[0]["payload"]["nonce"] != parents[1]["payload"]["nonce"]
                and parents[0]["payload"]["model_configs"] == parents[1]["payload"]["model_configs"],"GLM arms not independent same-campaign/model attempts")
        tasks = []
        for rank in range(16):
            workers=[next(row for row in p["workers"] if row["rank"] == rank) for p in parents]
            require(workers[0]["runtime_versions"] == workers[1]["runtime_versions"]
                    and workers[0]["loaded_native_hashes"] == workers[1]["loaded_native_hashes"],"rank runtime/native changed across GLM arms")
            tasks.append(dict(off_path=parsed[0].output/f'rank-{rank}'/'controlled-target.json',
                              on_path=parsed[1].output/f'rank-{rank}'/'controlled-target.json',
                              progress=args.output.with_name(f'glm-rank-{rank}-target-pairs-progress.json'),
                              profile=profile,record_validator=(validate_record if validator_for_rank is None
                                                               else validator_for_rank(rank)),
                              isolation_validator=isolation_validator))
        for rank,comparison in enumerate(ordered_target_comparisons(tasks,cpu_workers=cpu_workers)):
            result["ranks"].append(dict(rank=rank,comparison=comparison))
            write(args.output,result)
            require(comparison["status"] == "PASS", "GLM Target numerical pair failure")
        result.update(status="PASS_SCOPED_GLM_TP16_COMPLETE_TARGET_14_PAIRS_PER_RANK",producer_commit=plans[0]["source_sha"], profile=profile)
    except (ValueError,KeyError,TypeError,OSError,IndexError,RuntimeError) as error:
        result["error"]=f"{type(error).__name__}: {error}"
    return result


def main():
    args=build_parser().parse_args()
    if args.command in ("check","join"):
        torch.set_num_threads(2)
        result=check_external(args.planned,args.execution) if args.command == "check" else join_arms(args)
        write(args.output,result)
        return 0 if result["status"].startswith("PASS_SCOPED_") else 4
    require(args.tp == 16,"this named GLM ABI requires TP16")
    proof=validate_fixture(args.fixture_plan,args.fixture)
    require(proof["source_sha"] == args.expected_sha,"GLM fixture is not the fixed run producer")
    return run_controlled(args,profile=PROFILE,kwargs_factory=build_kwargs,model_contract_factory=model_contract,
                          fixture_validator=validate_fixture,payload_checker=check_payload,
                          extra_worker_validator=validate_glm_worker,producer_path=__file__,
                          defer_payload_validation=args.external_payload_check_only)


if __name__ == "__main__":
    raise SystemExit(main())
