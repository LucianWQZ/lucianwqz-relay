# SPDX-License-Identifier: Apache-2.0
"""Scalar canonical Full-context oracle for the fixed 544 staged-context diagnostic only.

No tensor/framework import. This reconstructs valid context positions and Full
slots from the original Target identity and canonical Draft Full table. It does
not accept a Graph Window table or infer semantics from claimed output values.
"""
SCHEMA = "544-captured-staged-context-prefix-before-query-v2"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical_context(case, full, *, k, target_query, padded, num_context,
                      max_num_tokens, num_target_tokens, dcp_size, groups):
    require(type(k) is int and k > 0 and type(target_query) is int
            and target_query == k + 1, "context Target query is not the fixed actual K+1 ABI")
    active = case["active"]
    require(type(active) is int and type(padded) is int and 0 < active <= padded
            and case["padded"] == padded, "context active/padded identity differs")
    require(type(max_num_tokens) is int and max_num_tokens >= padded * target_query
            and type(num_context) is int and num_context == padded * target_query,
            "captured context bucket/span differs from fixed 544 callback")
    require(type(num_target_tokens) is int and num_target_tokens == active * target_query,
            "context actual Target token span differs from fixed fixture")
    require(type(dcp_size) is int and dcp_size == 1 and type(groups) is int and groups == 1,
            "only the fixed replicated Draft Full context mapping is admitted")
    require(case["query_layout"] == [i * target_query for i in range(padded + 1)]
            and len(case["positions"]) == active
            and case["logical_requests"] == ["row-" + str(i) for i in range(active)],
            "original Target query/request identity differs")
    require(type(full) is list and len(full) == padded and full
            and len({len(row) for row in full}) == 1, "canonical context Full table geometry differs")
    positions, slots = [], []
    for row, values in enumerate(case["positions"]):
        require(type(values) is list and len(values) == target_query
                and all(type(p) is int and p >= 0 for p in values)
                and values == list(range(values[0], values[0] + target_query)),
                "valid Target context positions differ")
        for pos in values:
            column, offset = divmod(pos, 128)
            require(column < len(full[row]) and type(full[row][column]) is int
                    and full[row][column] > 0, "valid context is outside canonical resident Full table")
            positions.append(pos)
            slots.append(full[row][column] * 128 + offset)
    return dict(schema=SCHEMA, active=active, padded=padded, k=k,
                target_query=target_query, num_target_tokens=num_target_tokens,
                num_context=num_context, max_num_tokens=max_num_tokens,
                dcp_size=dcp_size, groups=groups, valid_positions=positions,
                full_slots=slots + [-1] * (num_context - num_target_tokens),
                pad_positions="UNCONSUMED_STALE_ALLOWED_WITH_PAD_SLOT_ONLY")


def validate_context_observation(contract, positions, slots, *, prefix_executed=True):
    require(type(prefix_executed) is bool and prefix_executed,
            "eager reference omitted the captured context prefix")
    require(type(positions) is list and len(positions) == contract["num_context"]
            and all(type(p) is int for p in positions), "context positions shape/type differs")
    require(positions[:contract["num_target_tokens"]] == contract["valid_positions"],
            "actual valid context positions differ from canonical Target positions")
    require(type(slots) is list and len(slots) == 1 and slots[0] == contract["full_slots"]
            and all(type(v) is int for v in slots[0]),
            "actual context slots differ from canonical Full/PAD writes")
