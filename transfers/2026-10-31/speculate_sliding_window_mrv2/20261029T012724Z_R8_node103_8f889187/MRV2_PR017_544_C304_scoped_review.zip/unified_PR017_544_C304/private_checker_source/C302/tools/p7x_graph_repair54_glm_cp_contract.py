# SPDX-License-Identifier: Apache-2.0
"""Exact Host oracle for a completed legacy DSA-CP metadata snapshot.

This is an additional diagnostic contract. It neither admits a serving route
nor reads a live device tensor. The caller must establish a normal completed
diagnostic boundary before collecting these CPU snapshots.
"""
from collections.abc import Mapping

import torch

from tools.p7x_graph_repair21_rank import require

SFA_CP = "vllm_ascend.attention.context_parallel.sfa_cp.AscendSFADSACPMetadata"
CONTEXT_FIELDS = (
    "num_tokens", "num_tokens_pad", "local_start", "local_end", "local_end_with_pad",
    "slot_mapping_cp", "actual_seq_lengths_query", "actual_seq_lengths_key",
)
V544_METADATA_SCHEMA = 'PR017_V544_TARGET_METADATA_V1'
V544_CONTEXT_FIELDS = CONTEXT_FIELDS + ('query_start_loc',)

# Ascend BlockTables and both legacy-CP builders use the native int32 ABI.
# In particular, indexer._build_dsa_cp_slot_mapping also pads to TP size.
SLOT_DTYPE = torch.int32


def cpu_tensor(value, dtype, length, label):
    require(isinstance(value, torch.Tensor) and value.device.type == "cpu"
            and value.dtype == dtype and value.ndim == 1 and value.numel() == length,
            "completed CPU snapshot dtype/shape differs: " + label)
    return value.tolist()


def validate_cp_full_slots(value, *, canonical_slots, actual_tokens, num_blocks, tp=16, query_width=9):
    """Check every actual and padded Full slot, without casting either input.

    Both SFA and indexer receive the global TP-aligned view. Only the separate
    CP preprocessing context is rank-local; it is checked below.
    """
    require(type(tp) is int and tp == 16 and type(actual_tokens) is int,
            "named TP16 completed slot contract required")
    require(isinstance(canonical_slots, torch.Tensor) and canonical_slots.ndim == 1,
            "canonical Full slot vector required")
    tokens = canonical_slots.numel()
    require(type(query_width) is int and query_width in (9, 16), "named Target Q9/Q16 required")
    padded_rows = (2, 4) if query_width == 9 else (1, 2, 4)
    require(tokens in tuple(rows * query_width for rows in padded_rows)
            and 0 < actual_tokens <= tokens and actual_tokens % query_width == 0,
            "Target actual/padded slot geometry differs")
    slots = cpu_tensor(canonical_slots, SLOT_DTYPE, tokens, "canonical Full slots")
    require(type(num_blocks) is int and num_blocks > 0, "actual cache block count required")
    require(all(0 <= item < num_blocks * 128 for item in slots[:actual_tokens]),
            "effective canonical slot outside actual Full KV capacity")
    require(slots[actual_tokens:] == [-1] * (tokens - actual_tokens),
            "padded Target query can write Full KV")
    aligned = ((tokens + tp - 1) // tp) * tp
    expected = slots + [-1] * (aligned - tokens)
    observed = cpu_tensor(value, SLOT_DTYPE, aligned, "TP-aligned Full slots")
    require(observed == expected, "CP Full slot values differ from canonical/padding")
    return dict(dtype=str(SLOT_DTYPE), tokens=tokens, aligned=aligned, actual_tokens=actual_tokens)


def validate_cp_context(context, *, canonical_slots, query_layout, exact_lengths,
                        actual_tokens, rank, tp=16, query_width=9, metadata_schema=None):
    """Independently derive TP shard bounds, Full slots and Q/K lengths.

    Full KV storage remains canonical after the native path's KV all-gather.
    The local slot view is used by initial token-sharded preprocessing only.
    Both contracts are retained; neither is inferred from final output values.
    """
    require(type(tp) is int and tp == 16 and type(rank) is int and 0 <= rank < tp,
            "actual complete TP16 rank required")
    require(metadata_schema in (None, V544_METADATA_SCHEMA), "unknown fixed Target metadata schema")
    context_fields = V544_CONTEXT_FIELDS if metadata_schema == V544_METADATA_SCHEMA else CONTEXT_FIELDS
    require(isinstance(context, Mapping) and set(context) == set(context_fields),
            "complete explicit legacy DSA-CP context required")
    require(type(query_width) is int and query_width in (9, 16), "named Target Q9/Q16 required")
    require(isinstance(query_layout, list) and len(query_layout) >= 2
            and all(type(value) is int for value in query_layout)
            and query_layout[0] == 0
            and all(right - left == query_width for left, right in zip(query_layout, query_layout[1:])),
            "declared Target query layout differs")
    padded_rows, tokens = len(query_layout) - 1, query_layout[-1]
    allowed_rows = (2, 4) if query_width == 9 else (1, 2, 4)
    require(padded_rows in allowed_rows and type(actual_tokens) is int
            and 0 < actual_tokens <= tokens and actual_tokens % query_width == 0,
            "SP active/padded Target token contract differs")
    require(isinstance(exact_lengths, list) and len(exact_lengths) == padded_rows
            and all(type(value) is int and value >= 0 for value in exact_lengths),
            "exact per-row lengths required")
    slots = cpu_tensor(canonical_slots, SLOT_DTYPE, tokens, "canonical Full slots")
    require(all(value == -1 for value in slots[actual_tokens:]), "padding row can write KV")
    aligned = ((tokens + tp - 1) // tp) * tp
    width = aligned // tp
    start, end_with_pad = rank * width, (rank + 1) * width
    expected_headers = dict(num_tokens=tokens, num_tokens_pad=aligned, local_start=start,
                            local_end=min(end_with_pad, actual_tokens), local_end_with_pad=end_with_pad)
    require(all(type(context[key]) is int and context[key] == value
                for key, value in expected_headers.items()), "legacy DSA-CP rank/token shard changed")
    full_slots = slots + [-1] * (aligned - tokens)
    actual_local = cpu_tensor(context["slot_mapping_cp"], SLOT_DTYPE, width, "CP local slots")
    require(actual_local == full_slots[start:end_with_pad], "CP local slots differ from canonical Full shard")
    query, keys, cumulative = [], [], 0
    for left, right, exact in zip(query_layout, query_layout[1:], exact_lengths):
        local_count = max(0, min(right, end_with_pad) - max(left, start))
        cumulative += local_count
        query.append(cumulative)
        keys.append(max(0, exact - max(0, right - end_with_pad)) if local_count else 0)
    require(cpu_tensor(context["actual_seq_lengths_query"], torch.int32, padded_rows, "CP Q lengths") == query,
            "CP query cumulative lengths differ")
    require(cpu_tensor(context["actual_seq_lengths_key"], torch.int32, padded_rows, "CP K lengths") == keys,
            "CP exact key lengths differ")
    if metadata_schema == V544_METADATA_SCHEMA:
        require(cpu_tensor(context["query_start_loc"], torch.int32, padded_rows + 1, "CP local query starts")
                == [0] + query, "CP local query starts differ from exact cumulative lengths")
    return dict(rank=rank, tp=tp, **expected_headers,
                query_lengths=query, key_lengths=keys,
                scope="COMPLETED_METADATA_SEMANTICS_NOT_EXECUTION_OPERAND_OR_PHYSICAL_READ")
