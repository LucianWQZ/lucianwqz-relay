# SPDX-License-Identifier: Apache-2.0
"""Same-Window continuous reference on an EXCLUSIVE disposable MRV2 fixture.

This is deliberately serialized, not normal-overlap evidence. It restores all
Draft query read/write blocks before an eager backbone reference, then restores
the actual Graph post-state before returning. Target state is never restored or
swapped. No sampling route is changed. The original manager still returns None.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict
from types import MethodType, SimpleNamespace

import torch

from tools.p7x_graph_repair6_storage import atomic_json, require
from tools.p7x_graph_repair6_submission import CompletedDiagnosticContractError, NumericMismatch, SubmissionState

from tools.r8_c255_context_contract import (
    SCHEMA as CONTEXT_SCHEMA, canonical_context, validate_context_observation,
)

REFERENCE_METADATA_SCHEMA = "544-fresh-canonical-padded-metadata-v3"


def snapshot_target_reference_state(owner):
    """Read only the pre-Graph Target source, never the tested carrier."""
    values = owner.model_state.attn_metadata
    require(isinstance(values, Mapping) and values, "reference requires pre-Graph Target metadata")
    states = [(name, getattr(value, "attn_state", None)) for name, value in values.items()
              if value is not None and getattr(value, "attn_state", None) is not None]
    require(states and all(state is states[0][1] for _, state in states),
            "reference Target attention states disagree")
    state = states[0][1]
    require(type(state).__module__ == "vllm_ascend.attention.attention_v1"
            and type(state).__name__ == "AscendAttentionState"
            and state.name in ("DecodeOnly", "PrefillCacheHit", "ChunkedPrefill", "SpecDecoding"),
            "reference requires a cached-read Target state, not query-only PrefillNoCache")
    return state, dict(source="PRE_GRAPH_TARGET_METADATA", state=state.name,
        state_type=type(state).__module__ + "." + type(state).__qualname__,
        layers=sorted(name for name, _ in states))


def draft_factory_default_state(method, factory, builder, owner_builder):
    """Independent Source API contract, never read the tested Graph carrier."""
    import inspect
    module = "vllm_ascend.worker.v2.attn_utils"
    expected_owner = {
        "dspark": "vllm_ascend.worker.v2.spec_decode.dspark.speculator.AscendDSparkSpeculator._build_attn_metadata",
        "dflash": "vllm_ascend.worker.v2.spec_decode.dflash.speculator.AscendDFlashSpeculator._build_attn_metadata",
    }
    require(method in expected_owner, "fresh reference has no named Draft factory state contract")
    factory = inspect.unwrap(factory)
    builder = inspect.unwrap(builder)
    owner_builder = inspect.unwrap(owner_builder)
    require(factory.__module__ + "." + factory.__qualname__ == module + ".build_attn_metadata_factory"
            and builder.__module__ + "." + builder.__qualname__ == module + ".build_attn_metadata"
            and owner_builder.__module__ + "." + owner_builder.__qualname__ == expected_owner[method],
            "fresh reference Draft factory/builder Source changed")
    for function in (factory, builder):
        parameter = inspect.signature(function).parameters.get("attn_state")
        require(parameter is not None and parameter.default is None,
                "fresh reference Draft factory default is not the fixed explicit None contract")
    return None, dict(source="FIXED_ASCEND_DRAFT_FACTORY_DEFAULT", state=None, state_type=None,
        method=method, factory=module + ".build_attn_metadata_factory",
        builder=module + ".build_attn_metadata", owner_builder=expected_owner[method],
        default_source="FACTORY_AND_ASCEND_BUILDER_SIGNATURES")


def snapshot_draft_reference_state(owner, method):
    from vllm_ascend.worker.v2.attn_utils import build_attn_metadata_factory, build_attn_metadata
    return draft_factory_default_state(method.method, build_attn_metadata_factory,
        build_attn_metadata, owner._build_attn_metadata.__func__)


def fresh_reference_header(metadata):
    metadata_class = type(metadata).__module__ + "." + type(metadata).__qualname__
    require(metadata_class == "vllm_ascend.attention.attention_v1.AscendMetadata",
            "fresh reference header requires the actual named AscendMetadata")
    state = metadata.attn_state  # Missing field is not equivalent to an explicit None.
    require(metadata.uses_pcp_sharded_layout is False, "fresh Draft reference does not cover PCP-sharded execution")
    state_type = None if state is None else type(state).__module__ + "." + type(state).__qualname__
    require(state is None or state_type == "vllm_ascend.attention.attention_v1.AscendAttentionState"
            and state.name in ("PrefillNoCache", "PrefillCacheHit", "DecodeOnly", "ChunkedPrefill", "SpecDecoding"),
            "fresh reference header attention state type differs")
    return dict(metadata_class=metadata_class, uses_pcp_sharded_layout=False, state=None if state is None else state.name,
        state_type=state_type, state_is_none=state is None, model_runner_type=metadata.model_runner_type,
        num_actual_tokens=metadata.num_actual_tokens, max_query_len=metadata.max_query_len,
        num_decodes=metadata.num_decodes, num_prefills=metadata.num_prefills,
        num_decode_tokens=metadata.num_decode_tokens, query=list(metadata.actual_seq_lengths_q),
        causal=metadata.causal)


def build_canonical_reference_metadata(owner, method, full, exact, table, lengths, active, padded, tokens, draft_state):
    """Execute the actual Ascend builder using independent canonical value owners."""
    from vllm_ascend.worker.v2.attn_utils import build_attn_metadata_wrapper, build_attn_metadata_factory
    from vllm_ascend.worker.v2.spec_decode.draft_window_eager import AscendDraftAttentionReadInputs
    require(owner.dcp_size == owner.block_tables.cp_size == 1
            and owner.draft_kv_cache_group_ids == [0]
            and owner.num_query_per_req == method.draft_query and tokens == padded * method.draft_query,
            "fresh reference supports only the fixed replicated single-group padded query")
    query = method.draft_query
    # All writes use the original canonical Full table, never the Window table.
    full_slots = []
    for row in range(padded):
        full_slots.extend([int(full[row, position // 128]) * 128 + position % 128
                           for position in range(exact[row] - query, exact[row])]
                          if row < active else [-1] * query)
    slots = torch.tensor(full_slots, dtype=owner.block_tables.slot_mappings.dtype, device=owner.device)
    full_slot_mappings = owner.block_tables.slot_mappings[:, :tokens].clone()
    full_slot_mappings[0].copy_(slots)
    query_gpu = torch.arange(padded + 1, dtype=torch.int32, device=owner.device) * query
    # The already independent Window table is passed separately; no carrier field is copied.
    table = table.to(owner.device)
    global_tables = tuple(table if gid == 0 else source[:padded].clone()
                          for gid, source in enumerate(owner.block_tables.input_block_tables))
    exact_cpu = torch.tensor(lengths, dtype=torch.int32)
    exact_device = exact_cpu.to(owner.device)
    upper_cpu = exact_cpu.clone()
    read = AscendDraftAttentionReadInputs(global_tables, exact_device, exact_cpu, upper_cpu, max(lengths))
    value_owner = SimpleNamespace(arange_np=owner.arange_np, num_query_per_req=query,
        input_buffers=SimpleNamespace(query_start_loc=query_gpu),
        block_tables=SimpleNamespace(input_block_tables=global_tables, slot_mappings=full_slot_mappings, cp_size=1),
        attn_groups=owner.attn_groups, kv_cache_config=owner.kv_cache_config,
        _call_ascend_draft_attn_metadata_builder=owner._call_ascend_draft_attn_metadata_builder)
    builder = owner._build_ascend_draft_attn_metadata.__func__
    require(builder.__module__ == "vllm_ascend.worker.v2.spec_decode.draft_window_eager"
            and builder.__qualname__ == "DraftWindowEagerMixin._build_ascend_draft_attn_metadata",
            "fresh reference actual Ascend builder changed")
    # Positions are the independently checked Full input producer; no Graph metadata is reused.
    with build_attn_metadata_wrapper(), build_attn_metadata_factory(
            owner.input_buffers.positions, tokens, torch.zeros(padded, dtype=torch.bool), attn_state=draft_state):
        result = builder(value_owner, num_reqs=padded, num_reqs_padded=padded, num_tokens_padded=tokens,
            read_inputs=read, causal=False, query_start_loc_np=None, dcp_local_seq_lens=None)
    require(set(result) == set(owner.draft_attn_layer_names), "fresh reference layer inventory differs")
    for metadata in result.values():
        require(metadata.seq_lens_gpu.data_ptr() == exact_device.data_ptr()
                and metadata.seq_lens_cpu.data_ptr() == exact_cpu.data_ptr()
                and metadata.block_tables.data_ptr() == table.data_ptr(),
                "fresh builder replaced canonical read owners")
        metadata.seq_lens = exact_device
    return result, full_slot_mappings


ATOL = 0.0
RTOL = 0.0


def snapshot_context_prefix(owner, method, case, full, desc):
    """Save actual pre-Graph Target features, independently audit Full writes.

    This is only the fixed empty-engine diagnostic with zero rejected tokens;
    active Target rows are verified from the actual input batch, not K's name.
    Legacy Target DSA-CP is distinct from this replicated Draft DCP-size-one
    mapping. All real Draft model layers are still called by upstream's helper.
    """
    prepare = owner._prepare_graph_forward.__func__
    require(prepare.__module__ == "vllm.v1.worker.gpu.spec_decode.dflash.speculator"
            and prepare.__qualname__ == "DFlashSpeculator._prepare_graph_forward",
            "reference requires the fixed 544 staged-context Graph preparation helper")
    count = owner._num_graph_context_tokens(desc.num_reqs)
    slots = owner._context_slot_mappings
    require(slots.ndim == 2 and slots.shape[0] == 1
            and len(owner.draft_kv_cache_group_ids) == 1,
            "context diagnostic requires the actual single Draft KV group")
    contract = canonical_context(
        case, full.tolist(), k=method.k, target_query=method.target_query,
        padded=desc.num_reqs, num_context=count, max_num_tokens=owner.max_num_tokens,
        num_target_tokens=owner.input_batch.num_tokens, dcp_size=owner.dcp_size,
        groups=slots.shape[0])
    require(owner.input_batch.num_reqs == contract["active"],
            "actual Target request span differs from context case")
    actual = dict(hidden=owner.hidden_states[:count].clone(),
                  positions=owner.context_positions[:count].clone(),
                  slots=slots[:, :count].clone())
    # core544 combines staged Target auxiliary features inside the Graph's
    # prepare_forward. Derive the reference from an independent pre-Graph
    # staging snapshot, not stale hidden_states or any Graph output/carrier.
    staging = getattr(owner, "_aux_staging", None)
    aux = None if staging is None else staging[:count].clone()
    canonical_hidden = actual["hidden"].clone() if aux is None else owner.model.combine_hidden_states(aux).clone()
    require(canonical_hidden.shape == actual["hidden"].shape
            and canonical_hidden.dtype == actual["hidden"].dtype,
            "544 canonical staged context feature shape/dtype differs")
    validate_context_observation(contract, actual["positions"].detach().cpu().tolist(),
                                 actual["slots"].detach().cpu().tolist())
    layer_groups = owner._layer_group_idx
    require(layer_groups is None or len(layer_groups) > 0 and all(index == 0 for index in layer_groups),
            "context model layer/group ownership differs")
    function = owner._precompute_context_kv.__func__
    require(function.__module__ == "vllm.v1.worker.gpu.spec_decode.dflash.speculator"
            and function.__qualname__ == "DFlashSpeculator._precompute_context_kv",
            "reference requires the actual fixed upstream context helper")
    reference = dict(hidden=canonical_hidden, positions=actual["positions"].clone(),
                     slots=torch.tensor([contract["full_slots"]], dtype=slots.dtype, device=slots.device))
    # Explicit value owner for the real upstream function, with the same real
    # model/all-layer KV caches. No Graph window table, carrier or output is used.
    reference_owner = SimpleNamespace(
        model=owner.model, hidden_states=reference["hidden"],
        context_positions=reference["positions"], _context_slot_mappings=reference["slots"],
        _layer_group_idx=layer_groups)
    ownership = dict(source="V544_PRE_GRAPH_TARGET_AUX_OR_DIRECT_FEATURES_AND_ORIGINAL_TARGET_POSITIONS",
                     feature_source="INDEPENDENT_STAGED_AUX_COMBINE" if aux is not None else "PRE_GRAPH_DIRECT_HIDDEN",
                     graph_prepare_helper="vllm.v1.worker.gpu.spec_decode.dflash.speculator.DFlashSpeculator._prepare_graph_forward",
                     model_owner=id(owner.model), actual_speculator_owner=id(owner),
                     context_helper=function.__module__ + "." + function.__qualname__,
                     layer_group_idx=layer_groups,
                     source_ptrs=dict(hidden=owner.hidden_states.data_ptr(),
                                      positions=owner.context_positions.data_ptr(), slots=slots.data_ptr()),
                     saved_ptrs={name: value.data_ptr() for name, value in actual.items()},
                     reference_ptrs={name: value.data_ptr() for name, value in reference.items()})
    return dict(contract=contract, actual=actual, reference=reference, ownership=ownership,
                pre_graph_hidden=actual["hidden"].clone(), pre_graph_aux=aux,
                reference_prefix_executed=False), reference_owner, function


def independent_window(full, exact, valid, active, padded, width, *, query=7):
    require(full.ndim == 2 and len(exact) == len(valid) == active and active <= padded, "invalid canonical geometry")
    table = torch.zeros((padded, width), dtype=full.dtype, device=full.device)
    lengths, rows = [], []
    for r, end in enumerate(exact):
        require(
            type(end) is int and end >= query and type(valid[r]) is int and valid[r] > 0,
            "invalid canonical exact/valid",
        )
        start = max(end - 1024, 0) // 128
        stop = (end + 127) // 128
        require(0 <= start <= stop <= valid[r] <= full.shape[1] and stop - start <= width, "canonical shortage")
        table[r, : stop - start] = full[r, start:stop]
        lengths.append(end - start * 128)
        rows.append(dict(S=start * 128, E=end, V=lengths[-1], columns=[start, stop]))
    return table, lengths + [0] * (padded - active), rows


def retained_hidden_contract(owner, sink, *, query):
    """Inspect output headers from the actual capture inventory, without reads.

    The smallest SP bucket can be two padded requests. The per-request query
    width is not an output dictionary key in that inventory. Every retained
    output still has to match its real FULL descriptor and method query.
    """
    require(type(query) is int and query > 0, "exact method query width required")
    inventory = []
    require({descriptor.num_tokens for descriptor in owner.query_cudagraph_manager.graphs}
            == set(sink.outputs), "retained output inventory differs from actual capture inventory")
    for descriptor in owner.query_cudagraph_manager.graphs:
        tokens, requests = descriptor.num_tokens, descriptor.num_reqs
        uniform = descriptor.uniform_token_count
        require(descriptor.cg_mode.name == "FULL"
                and type(tokens) is int and type(requests) is int and requests > 0
                and tokens == requests * query
                and (uniform is None or type(uniform) is int and uniform == query),
                "captured descriptor differs from the method query contract")
        output = sink.get(owner, tokens)
        require(isinstance(output, torch.Tensor) and output.ndim == 2
                and output.shape[0] == tokens and output.shape[1] > 0,
                "retained output differs from its actual capture descriptor")
        inventory.append(dict(tokens=tokens, requests=requests, query=query,
                              width=output.shape[1], dtype=str(output.dtype)))
    require(inventory and len({(item["width"], item["dtype"]) for item in inventory}) == 1,
            "actual captured hidden geometries are missing or inconsistent")
    representative = inventory[0]
    return dict(width=representative["width"], dtype=representative["dtype"]), sorted(
        inventory, key=lambda item: item["tokens"])


class ContinuousReference:
    def __init__(self, runner, scheduler, output, identity, *, provenance=None):
        require(
            not scheduler.requests and not scheduler.running and not scheduler.waiting,
            "exclusive empty engine required",
        )
        self.runner, self.owner = runner, runner.speculator
        self.manager = self.owner.query_cudagraph_manager
        self.sink = getattr(self.owner, "_draft_graph_output_references", None)
        require(self.sink is not None and self.sink.frozen, "capture output sink not installed before capture")
        self.output, self.identity, self.records = output, identity, []
        self.original = self.manager.run_fullgraph
        self.saved = ("run_fullgraph" in vars(self.manager), vars(self.manager).get("run_fullgraph"))
        self.poisoned = False
        self.failed = False
        self.submission = SubmissionState()
        self.provenance = provenance or {}
        from tools.p7x_graph_repair12_contract import method_for_profile

        self.method = method_for_profile(self.provenance.get("profile", "target4"))
        self.current_case = None

    def __enter__(self):
        from tools.p7x_graph_repair6_storage import CHUNK, CollectionWriter, require_space

        context = self.runner.compilation_config.static_forward_context
        hidden_contract, hidden_capture_inventory = retained_hidden_contract(
            self.owner, self.sink, query=self.method.draft_query)
        self.provenance = dict(
            self.provenance,
            draft_layers=sorted(self.owner.draft_attn_layer_names),
            kv_inventory={
                f"{n}/{i}": dict(shape=list(t.shape), dtype=str(t.dtype))
                for n in sorted(self.owner.draft_attn_layer_names)
                for i, t in enumerate(context[n].kv_cache)
            },
            hidden_contract=hidden_contract,
            hidden_capture_inventory=hidden_capture_inventory,
            context_prefix_schema=CONTEXT_SCHEMA,
            reference_metadata_schema=REFERENCE_METADATA_SCHEMA,
        )
        if self.method.name not in ("dspark_k7_anchor_q7",):
            self.provenance["method_contract"] = self.method.document()
        # Independent branch budget, computed from the real Draft cache geometry.
        # Four snapshots plus inputs/output; no assumed compression or dedup.
        from tools.p7x_graph_repair25_rank_numeric import diagnostic_cases

        selection = self.provenance.get("case_selection")
        cases = diagnostic_cases(self.provenance.get("profile", "target4"), selection)
        limit = self.provenance.get("sample_limit")
        require(selection is None or limit is None, "selected numeric cases cannot also be a prefix")
        if limit is not None:
            require(limit == 3, "numeric sentinel must cover A/B/A_prime")
            cases = cases[:limit]
        bytes_per_block = sum(
            t[0].numel() * t.element_size()
            for n in sorted(self.owner.draft_attn_layer_names)
            for t in context[n].kv_cache
        )
        samples = [
            dict(
                scenario=c["scenario"],
                bytes=4 * bytes_per_block * (1 + sum((e + self.method.draft_query + 127) // 128 for e in c["ends"]))
                + CHUNK,
            )
            for c in cases
        ]
        required = sum(c["bytes"] for c in samples) + CHUNK
        self.output.parent.mkdir(parents=True, exist_ok=True)
        atomic_json(
            self.output.with_name("numeric-resource-plan.json"),
            dict(
                samples=samples,
                required_free_bytes=required,
                scope="NUMERIC_ADDITIONAL_TO_TARGET_ARM",
                device_snapshot_limit=1 << 30,
                compression_assumed=False,
            ),
        )
        require_space(self.output.parent, required)
        self.writer = CollectionWriter(
            self.output,
            dict(
                numeric_schema="repair6-continuous-v2",
                identity=self.identity,
                provenance=self.provenance,
                scope="DIAGNOSTIC_SERIALIZED_BACKBONE_REFERENCE",
                normal_overlap="UNPROVEN",
                physical_read="OPEN",
                tolerance=dict(atol=ATOL, rtol=RTOL),
            ),
            max_bytes=required,
        )
        probe = self

        def run(_manager, desc):
            require(not probe.failed, "diagnostic branch already failed; no next generation")
            try:
                return probe._run(desc)
            except BaseException as error:
                probe.failed = True
                probe.submission.failed(error)
                probe.poisoned = probe.submission.pending
                try:
                    atomic_json(
                        probe.output.with_name("numeric-failure.json"),
                        dict(identity=probe.identity, submission=probe.submission.snapshot()),
                    )
                except Exception as export_error:
                    error.add_note(f"Host failure export also failed: {export_error!r}")
                if not probe.poisoned and isinstance(error, ValueError):
                    raise CompletedDiagnosticContractError(str(error)) from error
                raise

        self.manager.run_fullgraph = MethodType(run, self.manager)
        return self

    def _run(self, desc):
        from vllm.config.compilation import CUDAGraphMode
        from vllm.v1.worker.gpu.attn_utils import build_slot_mappings_by_layer

        s = self.owner
        self.method.validate_owner(s)
        require(desc.cg_mode == CUDAGraphMode.FULL, "continuous reference requires actual FULL Draft replay")
        query = self.method.draft_query
        nr = s.input_batch.num_reqs
        require(
            self.current_case is not None and self.current_case["active"] == nr, "numeric fixture case not associated"
        )
        # Complete query pre-state, after eager context-KV production, before
        # Graph submit. This D2H is diagnostic and never between replay/UPDATE.
        self.submission.submit("PRESTATE_DRAIN_PENDING")
        self.manager.update_stream.synchronize()
        torch.npu.current_stream().synchronize()
        self.submission.complete("PRESTATE_DRAIN_COMPLETE")
        self.submission.submit("PRESTATE_SNAPSHOT_PENDING")
        full = s.block_tables.input_block_tables[0][: desc.num_reqs].detach().cpu().clone()
        exact = s.input_buffers.seq_lens[:nr].detach().cpu().tolist()
        mapping = torch.as_tensor(s.input_batch.idx_mapping_np[:nr], dtype=torch.int64)
        valid = s.block_tables.num_blocks.cpu[0].index_select(0, mapping).tolist()
        context = self.runner.compilation_config.static_forward_context
        caches = {
            f"{name}/{i}": kv
            for name in sorted(s.draft_attn_layer_names)
            for i, kv in enumerate(context[name].kv_cache)
        }
        slots = s.block_tables.slot_mappings[0, : desc.num_tokens].detach().cpu().clone()
        selected = sorted(
            set(full[r, : valid[r]].tolist()[c] for r in range(nr) for c in range(valid[r]))
            | {int(v) // 128 for v in slots.tolist() if v >= 0}
            | {0}
        )
        size = sum(len(selected) * t[0].numel() * t.element_size() for t in caches.values())
        require(size * 2 <= 1 << 30, "BLOCKED_RESOURCE: numeric pre/post device snapshots exceed 1 GiB")
        indices = torch.tensor(selected, dtype=torch.int64, device=s.device)
        before = {k: t.index_select(0, indices) for k, t in caches.items()}
        inputs = {k: getattr(s.input_buffers, k)[: desc.num_tokens].clone() for k in ("input_ids", "positions")}
        inputs["slot_mapping"] = slots
        inputs["query_start_loc"] = s.input_buffers.query_start_loc[: desc.num_reqs + 1].detach().cpu().clone()
        context_prefix, reference_context_owner, context_function = snapshot_context_prefix(
            s, self.method, self.current_case, full, desc)
        target_reference_state, target_reference_state_proof = snapshot_target_reference_state(s)
        draft_reference_state, draft_reference_state_proof = snapshot_draft_reference_state(s, self.method)
        self.submission.submit("GRAPH_REPLAY_UPDATE_PENDING")
        returned = self.original(desc)
        require(returned is None, "Graph manager return contract changed")
        self.manager.update_stream.synchronize()
        torch.npu.current_stream().synchronize()
        self.submission.complete("GRAPH_DIAGNOSTIC_COMPLETE")
        context_count = context_prefix["contract"]["num_context"]
        if context_prefix["pre_graph_aux"] is not None:
            require(torch.equal(s._aux_staging[:context_count].view(torch.uint8),
                                context_prefix["pre_graph_aux"].view(torch.uint8)),
                    "captured Graph mutated its staged Target auxiliary input")
        # Save the completed actual Graph context feature output separately
        # from both the pre-Graph observation and independent canonical value.
        context_prefix["actual"]["hidden"] = s.hidden_states[:context_count].clone()
        context_prefix["ownership"]["saved_ptrs"]["hidden"] = context_prefix["actual"]["hidden"].data_ptr()
        require(torch.equal(context_prefix["actual"]["hidden"].view(torch.uint8),
                            context_prefix["reference"]["hidden"].view(torch.uint8))
                and torch.equal(s.context_positions[:context_prefix["contract"]["num_context"]],
                                context_prefix["actual"]["positions"])
                and torch.equal(s._context_slot_mappings[:, :context_prefix["contract"]["num_context"]],
                                context_prefix["actual"]["slots"]),
                "captured Graph mutated its canonical context inputs")
        live = s._draft_window_live_inputs
        require(live is not None, "generation retired before numeric observation")
        graph_hidden = self.sink.get(s, desc.num_tokens).detach().cpu().clone()
        require(graph_hidden.dtype in (torch.float16, torch.bfloat16), "continuous reference dtype not declared")
        self.submission.submit("POSTGRAPH_OBSERVATION_PENDING")
        after = {k: t.index_select(0, indices) for k, t in caches.items()}
        # consume_metadata is a one-shot BOUND -> SUBMITTED transition. The
        # reference must inspect that exact submitted carrier, not consume twice.
        carriers = s._draft_window_graph_characterization.provider.submitted_carriers
        require(
            len(carriers) == 1
            and s._draft_window_graph_characterization.provider.require_runtime_identity(live.identity) is carriers[0],
            "missing exact submitted generation for reference",
        )
        actual = carriers[0].metadata
        width = next(iter(actual.values())).block_tables.shape[1]
        table, lengths, rows = independent_window(full, exact, valid, nr, desc.num_reqs, width, query=query)
        for m in actual.values():
            require(torch.equal(m.block_tables.detach().cpu(), table) and m.seq_lens_list == lengths,
                    "production Window differs from independent canonical oracle")
        metadata, reference_full_slot_mappings = build_canonical_reference_metadata(
            s, self.method, full, exact, table, lengths, nr, desc.num_reqs, desc.num_tokens,
            draft_reference_state)

        def metadata_snapshot(values):
            return {
                name: dict(
                    table=m.block_tables.detach().cpu().clone(),
                    table_ptr=m.block_tables.data_ptr(),
                    exact_ptr=m.seq_lens.data_ptr(),
                    exact=m.seq_lens.detach().cpu().clone(),
                    upper=list(m.seq_lens_list),
                    query=list(m.actual_seq_lengths_q),
                    slot=m.slot_mapping.detach().cpu().clone(),
                    causal=m.causal,
                    reference_branch=fresh_reference_header(m),
                )
                for name, m in values.items()
            }

        actual_snapshot = metadata_snapshot(actual)
        reference_snapshot = metadata_snapshot(metadata)
        self.submission.submit("REFERENCE_RESTORE_AND_FORWARD_PENDING")
        for key, t in caches.items():
            t.index_copy_(0, indices, before[key])
        reference_before = {k: t.index_select(0, indices) for k, t in caches.items()}
        reference_inputs = {
            k: getattr(s.input_buffers, k)[: desc.num_tokens].clone() for k in ("input_ids", "positions")
        }
        reference_inputs["slot_mapping"] = reference_full_slot_mappings[0].clone()
        reference_inputs["query_start_loc"] = s.input_buffers.query_start_loc[: desc.num_reqs + 1].clone()
        # The fixed 544 Graph prepares the context prefix before query. Reproduce that
        # actual helper on independent Target-feature/position/Full-slot owners
        # after canonical KV restore; query backbone alone is not equivalent.
        context_function(reference_context_owner, 0, context_prefix["contract"]["num_context"])
        reference = s._run_model(
            desc.num_tokens,
            metadata,
            build_slot_mappings_by_layer(reference_full_slot_mappings, s.kv_cache_config),
            None,
            CUDAGraphMode.NONE,
        )
        torch.npu.current_stream().synchronize()
        self.submission.complete("REFERENCE_DIAGNOSTIC_COMPLETE")
        # Both prefix and query execute in the same diagnostic stream. This
        # flag is recorded only after its explicit completion, never Host return.
        context_prefix["reference_prefix_executed"] = True
        reference = reference.detach().cpu().clone()
        reference_after = {k: t.index_select(0, indices) for k, t in caches.items()}
        # No unconditional finally restore: a partially submitted native failure
        # must leave the disposable child quarantined, without further device work.
        self.submission.submit("GRAPH_POSTSTATE_RESTORE_PENDING")
        for key, t in caches.items():
            t.index_copy_(0, indices, after[key])
        torch.npu.current_stream().synchronize()
        self.submission.complete("GRAPH_POSTSTATE_RESTORE_COMPLETE")
        self.submission.submit("POSTSTATE_VALIDATION_AND_EXPORT_PENDING")
        require(
            all(
                torch.equal(getattr(s.input_buffers, k)[: desc.num_tokens], inputs[k])
                for k in ("input_ids", "positions")
            ),
            "reference mutated input/positions",
        )
        from tools.p7x_graph_repair6 import metrics

        a, b = graph_hidden[: nr * query], reference[: nr * query]
        measured = metrics(a, b)
        measured.update(atol=ATOL, rtol=RTOL)
        record = dict(
            generation=live.identity.generation_id,
            epoch=live.identity.mapping_epoch,
            case_identity=dict(self.current_case),
            descriptor=[desc.num_reqs, desc.num_tokens],
            active=nr,
            canonical_table=full.tolist(),
            exact=exact,
            valid=valid,
            oracle=rows,
            selected_blocks=selected,
            pre_kv=before,
            graph_post_kv=after,
            reference_post_kv=reference_after,
            reference_pre_kv=reference_before,
            reference_inputs=reference_inputs,
            context_prefix=context_prefix,
            reference_metadata_proof=dict(schema=REFERENCE_METADATA_SCHEMA,
                source="ACTUAL_ASCEND_BUILDER_INDEPENDENT_CANONICAL_READS",
                target_state=target_reference_state_proof, draft_state=draft_reference_state_proof),
            idx_mapping=mapping.tolist(),
            actual_metadata=actual_snapshot,
            reference_metadata=reference_snapshot,
            inventory={k: dict(shape=list(t.shape), dtype=str(t.dtype)) for k, t in caches.items()},
            hidden_contract=dict(width=self.sink.get(s, desc.num_tokens).shape[1], dtype=str(graph_hidden.dtype)),
            target_descriptor=[self.current_case["padded"], self.current_case["padded"] * self.method.target_query],
            provider=id(s._draft_window_graph_characterization.provider),
            backing=asdict(carriers[0].capture_identity.backing_identity),
            inputs=inputs,
            graph=graph_hidden,
            reference=reference,
            metrics=measured,
            status="PASS_SCOPED_CONTINUOUS"
            if measured["finite"]
            and torch.allclose(a, b, atol=ATOL, rtol=RTOL)
            and all(torch.equal(after[k], reference_after[k]) for k in caches)
            else "NUMERIC_MISMATCH",
        )
        if not self.method.sample_from_anchor:
            record["sampling_state"] = {
                name: getattr(s, name)[: nr * self.method.k].detach().cpu().clone()
                for name in ("sample_indices", "sample_pos", "sample_idx_mapping")
            }
        record["identity"] = dict(self.identity, generation=record["generation"], epoch=record["epoch"])
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe

        record["runtime_identity"] = _json_safe(live.identity)
        self.writer.start(record["identity"])
        self.writer.finish(record)
        # Writer's blocking CPU copies have completed; drain the diagnostic
        # current stream before classifying a mismatch as safe Host-only exit.
        torch.npu.current_stream().synchronize()
        self.submission.complete("EVIDENCE_EXPORT_COMPLETE")
        self.records.append({k: record[k] for k in ("generation", "epoch", "status", "metrics", "case_identity")})
        if record["status"] == "NUMERIC_MISMATCH":
            raise NumericMismatch("NUMERIC_MISMATCH: durable completed sample; stop dependent branch")
        return returned

    def __exit__(self, kind, *_):
        if self.saved[0]:
            self.manager.run_fullgraph = self.saved[1]
        else:
            delattr(self.manager, "run_fullgraph")
        self.writer.close("EXECUTION_FAILED" if self.failed or kind else "COMPLETE")
        atomic_json(
            self.output.with_name("numeric-summary.json"),
            dict(
                samples=len(self.records),
                identity=self.identity,
                numeric_schema="repair6-continuous-v2",
                submission=self.submission.snapshot(),
                execution=self.writer.manifest["execution"],
                statuses=[r["status"] for r in self.records],
                normal_overlap="UNPROVEN",
                device_execution="EXECUTED",
            ),
        )
