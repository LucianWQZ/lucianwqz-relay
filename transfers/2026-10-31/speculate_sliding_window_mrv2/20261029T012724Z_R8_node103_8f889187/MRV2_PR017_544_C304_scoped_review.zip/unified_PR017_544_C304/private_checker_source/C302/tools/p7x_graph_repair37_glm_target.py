# SPDX-License-Identifier: Apache-2.0
"""Named GLM5.2 W4A8 Target SFA/indexer and dense DSpark K8 diagnostics.

This explicitly serialized disposable-engine adapter is distinct from the dense
Qwen/FIA Target ABI. SFA does not publish FIA task-update tuples. The metadata
and cache-owner checks below establish a source-level boundary, not a physical
read set or the operands of an individually observed device execution.
"""
from __future__ import annotations

from collections.abc import Mapping
from math import prod

import torch

from tools.p7x_graph_repair4_target import (
    LiveTargetAdapter, _class_path, _differences, _snapshot_value, _validate_read_coverage,
    _validate_snapshot, _view, _write_coverage, select_mapped_blocks, target_inventory,
)
from tools.p7x_graph_repair5_target import ControlledTarget, case_plan, require
from tools.p7x_graph_repair6_storage import CHUNK
from tools.p7x_graph_repair12_contract import method_for_profile
from tools.p7x_graph_repair32_glm_rank import DRAFT, TARGET
from tools.r8_c255_tool_binding import BINDING
from tools.p7x_graph_repair54_glm_cp_contract import (
    V544_CONTEXT_FIELDS, V544_METADATA_SCHEMA, CONTEXT_FIELDS, SFA_CP, SLOT_DTYPE,
    validate_cp_context, validate_cp_full_slots,
)

PROFILE = "glm52_dspark_k8_q8_sfa"
ORIGIN = "LIVE_ASCEND_GLM_SFA_INDEXER_TARGET_FULL_GRAPH"
CP_PROFILE = "glm52_dspark_k8_q8_sfa_cp"
DFLASH_PROFILE = "glm52_dflash_k15_q16_sfa"
CP_ORIGIN = "LIVE_ASCEND_GLM_LEGACY_DSA_CP_INDEXER_TARGET_FULL_GRAPH"
SFA = "vllm_ascend.attention.sfa_v1.AscendSFAMetadata"
INDEXER = "vllm_ascend.attention.indexer.AscendSFAIndexerMetadata"
COMPONENTS = {SFA: (("Ckv", 512), ("Krope", 64)), INDEXER: (("Kindex", 128),)}
COMMON_FIELDS = (
    "num_actual_tokens", "slot_mapping", "seq_lens", "cum_query_lens", "block_table",
    "sin", "cos", "block_size", "group_len", "group_key_idx", "group_key_cache_idx",
)
SFA_FIELDS = (
    "seq_lens_cpu", "num_input_tokens", "head_dim", "attn_mask", "attn_state", "num_decodes",
    "num_decode_tokens", "num_prefills", "positions", "query_start_loc", "max_query_len",
    "max_seq_len", "smla_metadata", "smla_topk_length",
)
INDEXER_FIELDS = ("actual_seq_lengths_query", "actual_seq_lengths_key", "num_decode_tokens")


LEGACY_METADATA_PIN = "84030bbe3d74d99bad477a3d2e37a973ccd8865c"
V544_METADATA_PIN = "544f182d9f0c9bfe8bd7645525951d5e3692a542"
V544_COMMON_FIELDS = tuple(key for key in COMMON_FIELDS if key not in (
    "group_len", "group_key_idx", "group_key_cache_idx")) + ("uses_pcp_sharded_layout",)
V544_SFA_FIELDS = SFA_FIELDS + ("smla_valid_mask", "smla_sinks")
V544_INACTIVE_FIELDS = ("pcp_prolog_local_slots", "pcp_prolog_global_slots", "pcp_has_global_prefill",
    "req_ids_tensor", "token_to_req", "reshape_cache_event")
V544_NOPE_SCHEMA = "PR017_V544_TARGET_NOPE_LOCAL_V1"
V544_NOPE_FIELDS = ("num_actual_tokens", "num_input_tokens", "query_start_loc", "cum_query_lens",
    "seq_lens", "seq_lens_cpu", "positions", "block_size", "block_table", "smla_metadata",
    "smla_topk_length", "smla_valid_mask", "smla_sinks", "uses_pcp_sharded_layout")


def _tensor_header_or_none(value):
    if value is None:
        return None
    require(isinstance(value, torch.Tensor), "typed inactive/cache metadata Tensor required")
    return dict(device=str(value.device), data_ptr=value.data_ptr(), shape=list(value.shape),
                stride=list(value.stride()), storage_offset=value.storage_offset(), dtype=str(value.dtype))


def _tensor_descriptor_or_none(value):
    header = _tensor_header_or_none(value)
    return None if header is None else {key: header[key] for key in (
        "shape", "stride", "storage_offset", "dtype")}


def _v544_inactive_metadata(metadata):
    # These paths are outside the admitted PCP1/DCP1, no-offload Target profile.
    # The common builder still retains a canonical PCP mapping even at PCP1;
    # only its header is meaningful here, not a second read/write consumer.
    state = {key: getattr(metadata, key) for key in V544_INACTIVE_FIELDS}
    require(state["pcp_has_global_prefill"] is False and all(value is None for key, value in state.items()
            if key != "pcp_has_global_prefill"), "unqualified PCP/offload/event metadata path")
    state["pcp_slot_mapping_descriptor"] = _tensor_descriptor_or_none(metadata.pcp_slot_mapping)
    return state


def _v544_slot_cache(metadata):
    cached = getattr(metadata, "kv_slots_i64", None)
    if cached is None:
        return None
    require(isinstance(cached, tuple) and len(cached) == 2
            and all(isinstance(value, torch.Tensor) for value in cached)
            and cached[0].dtype == torch.int32 and cached[1].dtype == torch.int64
            and cached[0].shape == cached[1].shape, "unqualified per-step int64 slot cache")
    # The first object is consumed by a Host `is` identity test; the second is
    # the actual kernel operand. Preserve its bytes, including an explicit
    # empty-Tensor header when there are no elements to copy.
    converted = cached[1] if cached[1].numel() else {"empty_tensor_descriptor": _tensor_descriptor_or_none(cached[1])}
    return dict(source_descriptor=_tensor_descriptor_or_none(cached[0]), converted=converted)


def _v544_nope_values(metadata):
    if metadata is None:
        return None
    require(_class_path(metadata) == SFA_CP and metadata.nope_metadata is None,
            "unsupported nested or cyclic NoPE metadata")
    # NoPE receives a local read context, not another KV-write invocation.
    # Global Full slots remain covered by the outer metadata/original oracle.
    return dict(metadata_schema=V544_NOPE_SCHEMA, metadata_class=SFA_CP,
                **{key: getattr(metadata, key) for key in V544_NOPE_FIELDS})


def _validate_metadata_schema(values):
    schema = values.get("metadata_schema")
    require(schema in (None, V544_METADATA_SCHEMA), "unknown saved Target metadata schema")
    if schema is None:
        kind = values["metadata_class"]
        fields = COMMON_FIELDS + (INDEXER_FIELDS if kind == INDEXER else SFA_FIELDS)
        expected = {"metadata_class", *fields}
        if kind == SFA_CP:
            expected.add("dsa_cp_context")
        # Older producers may have retained their redundant exact-length label;
        # the actual seq_lens/identity oracle below remains authoritative.
        require(set(values) in (expected, expected | {"declared_exact_lengths"}),
                "missing legacy schema fields or untagged new Target metadata")
        return None
    kind = values["metadata_class"]
    fields = V544_COMMON_FIELDS + (INDEXER_FIELDS if kind == INDEXER else V544_SFA_FIELDS)
    expected = {"metadata_schema", "metadata_class", *fields}
    expected.update(("inactive_topk_selector",) if kind == INDEXER else ("inactive_metadata", "kv_slots_i64"))
    if kind == SFA_CP:
        expected.update(("dsa_cp_context", "nope_metadata", "nope_required"))
    require(set(values) == expected, "incomplete/extra v544 Target metadata fields")
    require(values["uses_pcp_sharded_layout"] is False, "unqualified Target PCP-sharded execution layout")
    if kind == INDEXER:
        require(values["inactive_topk_selector"] is None, "unqualified saved top-k callback")
    else:
        state = values["inactive_metadata"]
        require(isinstance(state, Mapping) and set(state) == {*V544_INACTIVE_FIELDS, "pcp_slot_mapping_descriptor"}
                and state["pcp_has_global_prefill"] is False and all(value is None for key, value in state.items()
                if key not in ("pcp_has_global_prefill", "pcp_slot_mapping_descriptor")),
                "unqualified saved PCP/offload/event path")
    return schema


def _validate_v544_nope(values, *, positions, actual_tokens, rank):
    local = values["nope_metadata"]
    require(type(values["nope_required"]) is bool and values["nope_required"] is (local is not None),
            "saved NoPE requirement/local context differs")
    if local is None:
        return
    require(local["metadata_schema"] == V544_NOPE_SCHEMA and local["metadata_class"] == SFA_CP
            and set(local) == {"metadata_schema", "metadata_class", *V544_NOPE_FIELDS},
            "incomplete/unknown saved local NoPE inputs")
    require(local["uses_pcp_sharded_layout"] is False, "unqualified local NoPE PCP layout")
    context = values["dsa_cp_context"]
    start, stop = context["local_start"], context["local_end_with_pad"]
    expected_positions = positions + [0] * (context["num_tokens_pad"] - len(positions))
    require(local["num_input_tokens"] == stop - start
            and local["num_actual_tokens"] == max(context["local_end"] - start, 0)
            and local["seq_lens_cpu"] is None and local["block_size"] == values["block_size"]
            and torch.equal(local["query_start_loc"], context["query_start_loc"])
            and torch.equal(local["cum_query_lens"], context["actual_seq_lengths_query"])
            and torch.equal(local["seq_lens"], context["actual_seq_lengths_key"])
            and torch.equal(local["block_table"], values["block_table"])
            and local["positions"].dtype == torch.int64
            and local["positions"].tolist() == expected_positions[start:stop],
            "NoPE local read/query/position context differs from canonical CP shard")


def component_contract(cp=False):
    require(type(cp) is bool, "explicit completed CP diagnostic contract required")
    return {SFA_CP: COMPONENTS[SFA], INDEXER: COMPONENTS[INDEXER]} if cp else COMPONENTS


def validate_components(rows, *, require_npu=False, cp=False):
    """Every owner/component is independently checked; no homogeneous shortcut."""
    require(rows and len(rows) == 99, "GLM requires complete 78 SFA + 21 indexer owners")
    components = component_contract(cp)
    main_kind = SFA_CP if cp else SFA
    result, counts, owners, addresses = {}, {main_kind: 0, INDEXER: 0}, set(), set()
    block_counts = set()
    for row in rows:
        name, kind, caches = row["name"], row["metadata_class"], row["caches"]
        require(type(name) is str and name not in owners and kind in components, "duplicate/unknown Target cache owner")
        owners.add(name)
        counts[kind] += 1
        require(type(row["global_group_id"]) is int and row["global_group_id"] == 0,
                "this installed GLM diagnostic admits only observed global group zero")
        require(isinstance(caches, (list, tuple)) and len(caches) == len(components[kind]),
                "GLM cache component inventory differs (scaled/C8 layouts are not this contract)")
        for tensor, (label, dim) in zip(caches, components[kind]):
            require(isinstance(tensor, torch.Tensor) and tensor.ndim == 4 and tensor.shape[0] > 0
                    and list(tensor.shape[1:]) == [128, 1, dim] and tensor.dtype == torch.bfloat16
                    and tensor.is_contiguous() and tensor.storage_offset() == 0,
                    "GLM component dtype/shape/stride/storage layout differs")
            require(not require_npu or tensor.device.type == "npu", "live GLM cache must be on NPU")
            signature = (str(tensor.device), tensor.untyped_storage().data_ptr())
            require(signature not in addresses, "aliased Target component ownership")
            addresses.add(signature)
            block_counts.add(tensor.shape[0])
            result[name + "/" + label] = tensor
    require(counts == {main_kind: 78, INDEXER: 21} and len(block_counts) == 1, "incomplete or inconsistent GLM Target inventory")
    return result


def heterogeneous_resource_plan(cases, components, *, hidden_size, vocab_size, metadata_bytes, sample_limit=None,
                                target_query=9):
    require(sample_limit is None or type(sample_limit) is int and 0 < sample_limit <= len(cases), "invalid GLM prefix")
    require(type(metadata_bytes) is int and metadata_bytes >= 0, "metadata byte bound required")
    require(all(type(v) is int and v > 0 for v in (hidden_size, vocab_size)), "actual model output dimensions required")
    require(type(target_query) is int and target_query in (9, 16), "named GLM Target query required")
    bytes_per_block = sum(prod(t.shape[1:]) * t.element_size() for t in components.values())
    require(bytes_per_block > 0 and len(components) == 177, "complete heterogeneous component budget required")
    samples = []
    for case in cases[:sample_limit]:
        require(case["query_width"] == target_query and case["padded"] in (1, 2, 4), "named Target query cases required")
        # Include block zero even when no padded row: reserve an extra block.
        blocks = 1 + sum((end + 127) // 128 for end in case["ends"])
        kv = blocks * bytes_per_block
        outputs = case["padded"] * target_query * (hidden_size * 8 + vocab_size) * 4
        checkpoint = 2 * kv + metadata_bytes + outputs + CHUNK
        samples.append(dict(scenario=case["scenario"], blocks=blocks, kv_one_copy=kv,
                            checkpoint=checkpoint, sample_bound=4 * kv + 3 * metadata_bytes + outputs + CHUNK))
    total = sum(row["sample_bound"] for row in samples)
    return dict(samples=samples, bytes_per_block=bytes_per_block, component_count=len(components),
                metadata_bytes=metadata_bytes, metadata_snapshot_count=3,
                one_arm_bytes=total, required_free_bytes=total + CHUNK, compression_assumed=False,
                content_dedup_assumed=False, declared_samples=len(cases),
                execution_scope="ONE_ARM_PREFIX" if sample_limit else "ONE_ARM_FULL",
                phases=dict(single_arm=total + CHUNK, both_arms_retained=2 * total + CHUNK,
                            comparison_additional=CHUNK, raw_pack_additional=0),
                host_temporary_bytes=CHUNK, device_copy_temporary_bytes=CHUNK,
                scope="HETEROGENEOUS_TARGET_ONLY; independent numeric resource plan is additional")


def metadata_values(metadata, *, cp=False):
    kind = _class_path(metadata)
    require(kind in component_contract(cp), "unknown actual SFA/indexer metadata class")
    pin = BINDING["vllm_sha"]
    require(pin in (LEGACY_METADATA_PIN, V544_METADATA_PIN), "unsupported fixed Target metadata version")
    if pin == LEGACY_METADATA_PIN:
        fields = COMMON_FIELDS + (INDEXER_FIELDS if kind == INDEXER else SFA_FIELDS)
        values = dict(metadata_class=kind, **{key: getattr(metadata, key) for key in fields})
        context_fields = CONTEXT_FIELDS
    else:
        fields = V544_COMMON_FIELDS + (INDEXER_FIELDS if kind == INDEXER else V544_SFA_FIELDS)
        values = dict(metadata_schema=V544_METADATA_SCHEMA, metadata_class=kind,
                      **{key: getattr(metadata, key) for key in fields})
        require(values["uses_pcp_sharded_layout"] is False, "unqualified Target PCP-sharded execution layout")
        if kind == INDEXER:
            require(metadata.topk_selector is None, "unqualified Target top-k selector callback")
            values["inactive_topk_selector"] = None
        else:
            values["inactive_metadata"] = _v544_inactive_metadata(metadata)
            values["kv_slots_i64"] = _v544_slot_cache(metadata)
        context_fields = V544_CONTEXT_FIELDS
    if kind == SFA_CP:
        context = metadata.dsa_cp_context
        require(context is not None, "actual legacy DSA-CP context missing")
        values["dsa_cp_context"] = {key: getattr(context, key) for key in context_fields}
        if pin == V544_METADATA_PIN:
            values["nope_required"] = metadata.sin is None and metadata.cos is None
            require(values["nope_required"] is (metadata.nope_metadata is not None),
                    "v544 NoPE builder/local metadata presence differs")
            values["nope_metadata"] = _v544_nope_values(metadata.nope_metadata)
    return values


class LiveTargetMetadata(Mapping):
    """Re-read the actual Target owner at each explicit completed snapshot.

    Holding a dict of previously extracted Tensor fields would miss later
    rebindings. No Tensor values, device queries or synchronization here.
    """
    def __init__(self, runner, names, *, cp=False):
        self.cp = cp
        component_contract(cp)
        self.runner, self.names = runner, tuple(names)
        self.root = runner.model_state.attn_metadata
        require(self.names and len(set(self.names)) == len(self.names), "unique Target owner names required")

    def __iter__(self):
        return iter(self.names)

    def __len__(self):
        return len(self.names)

    def __getitem__(self, name):
        require(name in self.names and self.runner.model_state.attn_metadata is self.root,
                "Target metadata root replaced or unowned layer requested")
        values = (metadata_values(self.root[name], cp=True) if self.cp else metadata_values(self.root[name]))
        return values

    def identities(self):
        result = {}
        for name in self.names:
            require(self.runner.model_state.attn_metadata is self.root, "Target metadata root replaced")
            values = (metadata_values(self.root[name], cp=True) if self.cp else metadata_values(self.root[name]))
            result[name] = dict(metadata_object_id=id(self.root[name]), metadata_class=values["metadata_class"],
                tensors={key:dict(device=str(t.device),data_ptr=t.data_ptr(),shape=list(t.shape),
                                  stride=list(t.stride()),storage_offset=t.storage_offset(),dtype=str(t.dtype))
                         for key,t in values.items() if isinstance(t,torch.Tensor)})
            if values.get("metadata_schema") == V544_METADATA_SCHEMA:
                from tools.p7x_graph_repair4_target import _flatten
                tensors, _ = _flatten(values)
                result[name]["nested_tensor_headers"] = {
                    key: _tensor_header_or_none(value) for key, value in tensors.items()}
                if values["metadata_class"] != INDEXER:
                    result[name]["inactive_pcp_slot_mapping_header"] = _tensor_header_or_none(
                        self.root[name].pcp_slot_mapping)
                    cached = getattr(self.root[name], "kv_slots_i64", None)
                    result[name]["slot_cache_headers"] = (None if cached is None else
                        [_tensor_header_or_none(value) for value in cached])
                if values["metadata_class"] == SFA_CP:
                    local = self.root[name].nope_metadata
                    result[name]["nope_metadata_object_id"] = None if local is None else id(local)
            if values["metadata_class"] == SFA_CP:
                context = self.root[name].dsa_cp_context
                result[name]["cp_context_object_id"] = id(context)
                result[name]["cp_tensors"] = {key: dict(device=str(t.device), data_ptr=t.data_ptr(),
                    shape=list(t.shape), stride=list(t.stride()), storage_offset=t.storage_offset(), dtype=str(t.dtype))
                    for key, t in values["dsa_cp_context"].items() if isinstance(t, torch.Tensor)}
        return result


class GLMTargetAdapter(LiveTargetAdapter):
    def __init__(self, runner, *, rank_contract, actual_rank, cp=False, method_profile=None, **kwargs):
        component_contract(cp)
        self.cp = cp
        self.method_profile = (CP_PROFILE if cp else PROFILE) if method_profile is None else method_profile
        require(self.method_profile in (PROFILE, CP_PROFILE, DFLASH_PROFILE)
                and ((self.method_profile == CP_PROFILE) is cp or self.method_profile == DFLASH_PROFILE),
                "named GLM method/CP contract differs")
        self.method = method_for_profile(self.method_profile)
        if self.method_profile == DFLASH_PROFILE:
            from tools.p7x_graph_repair62_glm_dflash_anchor import DRAFT as dflash_model
            self.expected_draft_model = dflash_model
        else:
            self.expected_draft_model = DRAFT
        self.rank_contract, self.actual_rank = rank_contract, actual_rank
        super().__init__(runner, **kwargs)

    def _validate_runner(self):
        r, spec = self.runner, self.runner.speculator
        require(_class_path(r) == "vllm_ascend.worker.v2.model_runner.NPUModelRunner"
                and _class_path(r.cudagraph_manager) == "vllm_ascend.worker.v2.aclgraph_utils.ModelAclGraphManager",
                "actual Ascend Target graph owner required")
        require(r.vllm_config.model_config.model == str(TARGET)
                and r.vllm_config.model_config.hf_config.architectures == ["GlmMoeDsaForCausalLM"]
                and spec.draft_model_config.model == str(self.expected_draft_model), "named GLM model pair required")
        require(torch.device(r.device).type == "npu", "live GLM adapter requires NPU")
        if BINDING["vllm_sha"] == V544_METADATA_PIN:
            require(r.vllm_config.parallel_config.prefill_context_parallel_size == 1
                    and r.vllm_config.parallel_config.decode_context_parallel_size == 1,
                    "v544 Target adapter only covers named PCP1/DCP1 layout")
        self.rank_contract.validate(r.vllm_config.parallel_config, self.actual_rank)
        require(self.rank_contract.world_size == 16
                and spec.speculative_config.draft_parallel_config.tensor_parallel_size == 16,
                "GLM diagnostic requires complete Target/Draft TP16")
        require((self.cp or not r.vllm_config.scheduler_config.async_scheduling) and not r.uses_inputs_embeds
                and r.model_state.rope_state is None and r.lora_config is None and r.adaptive_verification is None
                and r.pcp_manager is None and r.kvpp.scheduler is None,
                "uninventoried async/embeddings/positions/LoRA/adaptive/CP/KVPP layout")
        require(r.cudagraph_manager.model_runner is r and r.cudagraph_manager.graphs and r.update_stream is not None,
                "Target capture/update owner missing")
        require(r.vllm_config.quant_config is not None, "this GLM Target is W4A8, not dense Qwen")
        if self.cp:
            from vllm_ascend.ascend_config import get_ascend_config
            from vllm_ascend.utils import enable_sp
            additional = r.vllm_config.additional_config or {}
            require(r.vllm_config.scheduler_config.async_scheduling is True
                    and r.vllm_config.scheduler_config.enable_chunked_prefill is True
                    and r.vllm_config.cache_config.enable_prefix_caching is True
                    and get_ascend_config().enable_dsa_cp is True
                    and enable_sp(r.vllm_config) is True
                    and additional.get("enable_flashcomm1") is True,
                    "named completed CP diagnostic requires actual joint-feature configuration")
        require(spec.method == self.method.method, "actual GLM speculator method differs")
        self.method.validate_owner(spec)
        inventory = target_inventory(r)
        require(len(inventory["draft_layers"]) == 5, "complete five Draft layers required")
        self._component_inventory(inventory)

    def _component_inventory(self, inventory):
        r = self.runner
        context, metadata = r.compilation_config.static_forward_context, r.model_state.attn_metadata
        gids = {name: gid for gid, group in enumerate(r.kv_cache_config.kv_cache_groups) for name in group.layer_names}
        rows = [dict(name=name, metadata_class=_class_path(metadata[name]),
                     global_group_id=gids[name], caches=context[name].kv_cache)
                for name in inventory["target_layers"]]
        return validate_components(rows, require_npu=True, cp=self.cp)

    def _boundary(self, desc, batch):
        r = self.runner
        require(desc.cg_mode.name == "FULL" and desc in r.cudagraph_manager.graphs
                and desc.num_active_loras == 0 and desc.num_ubatches == 1, "actual captured FULL Target descriptor required")
        require(batch is not None and not batch.is_dummy
                and batch.num_tokens_after_padding == desc.num_tokens
                and batch.num_reqs_after_padding == desc.num_reqs and batch.num_tokens > 0,
                "fresh actual batch/descriptor mismatch")
        n, padded = desc.num_tokens, desc.num_reqs
        query = self.method.target_query
        require(n == padded * query and padded in (1, 2, 4), "captured named Target query bucket required")
        for field in ("input_ids", "positions", "is_padding"):
            require(_view(getattr(batch, field)) == _view(getattr(r.input_buffers, field)[:n]),
                    f"{field} is not the actual captured input-buffer view")
        inventory = target_inventory(r)
        components = self._component_inventory(inventory)
        slots, blocks, reads, layers = {}, {}, {}, {}
        canonical = r.block_tables.slot_mappings[0, :n]
        if self.cp:
            # Explicit serial diagnostic only. Save decisive completed CPU
            # values before checking them; no post-error device recovery/RPC.
            canonical_cpu = canonical.detach().cpu()
            self.completed_boundary_evidence = dict(
                scope="SERIAL_PRE_FORWARD_METADATA_NOT_NORMAL_ASYNC_COMPLETION",
                rank=self.actual_rank, tokens=n, actual_tokens=batch.num_tokens,
                canonical=dict(dtype=str(canonical.dtype), shape=list(canonical.shape),
                               values=canonical_cpu.tolist()), representatives={})
        for name in inventory["target_layers"]:
            metadata = r.model_state.attn_metadata[name]
            values = metadata_values(metadata, cp=self.cp)
            require(metadata.num_actual_tokens == batch.num_tokens and metadata.block_size == 128,
                    "SFA/indexer actual token/block contract differs")
            if self.cp:
                # CP legitimately pads/owns a separate Full slot tensor. This
                # completed diagnostic validates exact values, not false aliasing.
                observed = metadata.slot_mapping.detach().cpu()
                evidence = dict(name=name, dtype=str(metadata.slot_mapping.dtype),
                    shape=list(metadata.slot_mapping.shape), stride=list(metadata.slot_mapping.stride()),
                    storage_offset=metadata.slot_mapping.storage_offset(),
                    data_ptr=metadata.slot_mapping.data_ptr(), values=observed.tolist())
                self.completed_boundary_evidence["checking_layer"] = evidence
                self.completed_boundary_evidence["representatives"].setdefault(values["metadata_class"], evidence)
                validate_cp_full_slots(observed, canonical_slots=canonical_cpu,
                    actual_tokens=batch.num_tokens, num_blocks=next(iter(components.values())).shape[0],
                    query_width=query)
            else:
                require(_view(metadata.slot_mapping[:batch.num_tokens]) == _view(canonical[:batch.num_tokens]),
                        "SFA/indexer writes do not alias canonical Full slots")
            require(bool((canonical[batch.num_tokens:] == -1).all()), "padded Target row can write KV")
            # Explicitly completed serialized boundary; fresh exact device data,
            # never the CPU upper bound. No operation is inserted into replay -> UPDATE.
            lengths = metadata.seq_lens[:padded].detach().cpu().tolist()
            require(len(lengths) == padded and all(type(e) is int and e > 0 for e in lengths), "actual SFA read lengths missing")
            values["declared_exact_lengths"] = lengths
            for label, _ in component_contract(self.cp)[values["metadata_class"]]:
                key = name + "/" + label
                tensor = components[key]
                slots[key] = canonical
                blocks[key] = select_mapped_blocks(metadata.block_table, lengths, canonical,
                                                   num_blocks=tensor.shape[0], block_size=128)
                reads[key] = dict(table=metadata.block_table, lengths=lengths)
            layers[name] = values
        live_metadata = LiveTargetMetadata(r, inventory["target_layers"], cp=self.cp)
        inputs = dict(input_ids=batch.input_ids, positions=batch.positions, query_start_loc=batch.query_start_loc,
                      seq_lens=batch.seq_lens, is_padding=batch.is_padding, idx_mapping=batch.idx_mapping,
                      req_ids=tuple(batch.req_ids), num_tokens=batch.num_tokens, num_reqs=batch.num_reqs,
                      descriptor=(n, padded, desc.uniform_token_count, desc.max_query_len),
                      num_computed_tokens=torch.as_tensor(batch.num_computed_tokens_np), layers=live_metadata,
                      selected_block_ids=blocks, target_layer_names=inventory["target_layers"], inventory=inventory,
                      target_binding_scope="SOURCE_OWNED_SFA_INPUTS_NOT_NATIVE_EXECUTION_OPERANDS")
        if self.cp:
            inputs["completed_cp_rank"] = self.actual_rank
        return inputs, lambda: components, slots, blocks, reads


class GLMControlledTarget(ControlledTarget):
    def _checkpoint_origin(self):
        return CP_ORIGIN if self.probe.cp else ORIGIN

    def _target_slots_by_layer(self, slots):
        metadata = self.runner.model_state.attn_metadata
        return {name: slots[name + "/" + component_contract(self.probe.cp)[_class_path(metadata[name])][0][0]]
                for name in self.inventory["target_layers"]}

    def _execute_draft_after_target(self, **kwargs):
        # The Target Graph has already been explicitly drained by the generic
        # checkpointer. Snapshot its actual post-forward metadata before Draft.
        record, inputs = kwargs["record"], kwargs["inputs"]
        view = inputs["layers"]
        require(isinstance(view, LiveTargetMetadata), "live Target metadata view required")
        record["target_post_forward_inputs"] = self.probe.snapshot(inputs, [self.probe.max_bytes])
        record["target_metadata_owner_after_target"] = view.identities()
        super()._execute_draft_after_target(**kwargs)
        # super completed the diagnostic Draft paths and saved fresh view data.
        # If propose failed/was uncertain, this point is never reached.
        record["target_metadata_owner_after_draft"] = view.identities()

    def _resource_plan(self):
        components = self.probe._component_inventory(self.inventory)
        # The complete metadata snapshot is separately bounded. Count by actual
        # unique views; aliases across layers do not create additional storage.
        from tools.p7x_graph_repair4_target import _flatten
        values = {name: metadata_values(self.runner.model_state.attn_metadata[name], cp=self.probe.cp)
                  for name in self.inventory["target_layers"]}
        tensors, _ = _flatten(values)
        unique = {_view(t): t for t in tensors.values()}
        metadata_bytes = sum(t.numel() * t.element_size() for t in unique.values()) + CHUNK
        cfg = self.runner.model.config
        return heterogeneous_resource_plan(self.cases, components, hidden_size=cfg.hidden_size,
                                           vocab_size=cfg.vocab_size, metadata_bytes=metadata_bytes,
                                           sample_limit=self.sample_limit, target_query=self.method.target_query)


def validate_record(record, *, cp_rank=None, profile=None):
    """Read actual payloads; self-reported CAPTURED alone is never sufficient."""
    cp = cp_rank is not None
    profile = (CP_PROFILE if cp else PROFILE) if profile is None else profile
    require(profile in (PROFILE, CP_PROFILE, DFLASH_PROFILE)
            and ((profile == CP_PROFILE) is cp or profile == DFLASH_PROFILE),
            "saved GLM method/CP contract differs")
    query = method_for_profile(profile).target_query
    components = component_contract(cp)
    require(not cp or type(cp_rank) is int and 0 <= cp_rank < 16, "actual TP16 checker rank required")
    checkpoint, identity = record["checkpoint"], record["identity"]
    require(checkpoint["origin"] == (CP_ORIGIN if cp else ORIGIN) and checkpoint["status"] == "CAPTURED", "wrong/incomplete GLM checkpoint")
    for name in ("inputs", "output", "kv_before", "kv_after", "write_slots", "declared_reads"):
        _validate_snapshot(checkpoint[name])
    _validate_read_coverage(checkpoint)
    data, writes, reads = (_snapshot_value(checkpoint[k]) for k in ("inputs", "write_slots", "declared_reads"))
    active, padded = identity["active"], identity["padded"]
    if cp:
        require(data["completed_cp_rank"] == cp_rank and type(data["completed_cp_rank"]) is int
                and padded in (2, 4), "completed CP rank/SP padded identity differs")
    require(record["generation"] == identity["step"] and identity["query_layout"] == [query*i for i in range(padded+1)],
            "GLM generation/query plan mismatch")
    require(data["num_reqs"] == active and data["num_tokens"] == active * query
            and data["descriptor"][:2] == [padded * query, padded], "GLM actual Target geometry mismatch")
    require(list(data["req_ids"]) == identity["logical_requests"]
            and data["query_start_loc"].tolist() == identity["query_layout"], "request/query identity mismatch")
    expected_positions = sum(identity["positions"], []) + [0] * ((padded-active)*query)
    require(data["positions"].dtype == torch.int64 and data["positions"].tolist() == expected_positions
            and data["input_ids"].dtype == torch.int32
            and data["input_ids"][:active*query].tolist() == [17+row for row in range(active) for _ in range(query)],
            "actual input dtype/tokens/absolute positions differ")
    require(data["is_padding"].tolist() == [False]*(active*query) + [True]*((padded-active)*query), "Target padding differs")
    owners = record["block_owners"]
    require(len({tuple(v) for v in owners.values()}) == len(owners), "aliased logical block owner")
    require(set(data["layers"]) == set(data["target_layer_names"]) and len(data["layers"]) == 99,
            "missing GLM Target layer metadata")
    main_kind = SFA_CP if cp else SFA
    counts, semantics, expected_keys = {main_kind: 0, INDEXER: 0}, {}, set()
    lengths = [positions[-1]+1 for positions in identity["positions"]] + [1]*(padded-active)
    for name, m in data["layers"].items():
        kind = m["metadata_class"]
        metadata_schema = _validate_metadata_schema(m)
        require(kind in components, "unknown Target metadata schema")
        counts[kind] += 1
        require(m["num_actual_tokens"] == active*query and m["block_size"] == 128
                and m["seq_lens"][:padded].tolist() == lengths
                and m["cum_query_lens"][:padded].tolist() == identity["query_layout"][1:],
                "actual SFA/indexer read/query operands differ")
        table, logical, expected_slots = m["block_table"], [], []
        for row, end in enumerate(lengths):
            physical = table[row, :(end+127)//128].tolist()
            logical_row = [tuple(owners[p]) for p in physical]
            require(logical_row == ([(f"row-{row}", col) for col in range(len(physical))]
                                    if row < active else [("padding", 0)]), "SFA logical read ownership differs")
            logical.append(logical_row)
            expected_slots += ([physical[pos//128]*128 + pos%128 for pos in identity["positions"][row]]
                               if row < active else [-1]*query)
        metadata_slots = expected_slots
        if cp:
            aligned = ((padded * query + 15) // 16) * 16
            metadata_slots = expected_slots + [-1] * (aligned - len(expected_slots))
            if kind == SFA_CP:
                validate_cp_context(m["dsa_cp_context"], canonical_slots=torch.tensor(expected_slots, dtype=SLOT_DTYPE),
                    query_layout=identity["query_layout"], exact_lengths=lengths,
                    actual_tokens=active * query, rank=cp_rank, query_width=query,
                    metadata_schema=metadata_schema)
                if metadata_schema == V544_METADATA_SCHEMA:
                    _validate_v544_nope(m, positions=expected_positions, actual_tokens=active * query, rank=cp_rank)
        require(m["slot_mapping"].dtype == SLOT_DTYPE
                and m["slot_mapping"].tolist() == metadata_slots, "metadata canonical slots differ")
        for label, dim in components[kind]:
            key = name + "/" + label
            expected_keys.add(key)
            require(writes[key].tolist() == expected_slots and torch.equal(reads[key]["table"], table)
                    and reads[key]["lengths"] == lengths, "Target component read/write binding differs")
            escaped = "/" + key.replace("~", "~0").replace("/", "~1")
            for stage in ("kv_before", "kv_after"):
                entry = checkpoint[stage]["tensors"][escaped]
                require(list(entry["source_shape"])[1:] == [128, 1, dim]
                        and entry["dtype"] == "torch.bfloat16", "Target component layout differs")
        semantics[name] = dict(kind=kind, table=logical, lengths=lengths, query=identity["query_layout"])
    require(counts == {main_kind: 78, INDEXER: 21} and set(checkpoint["kv_keys"]) == expected_keys,
            "incomplete heterogeneous Target inventory")
    outputs = checkpoint["output"]["tensors"]
    entry = outputs.get("") or outputs.get("/0")
    require(entry is not None and torch.equal(entry["data"][:active*query], record["hidden"]),
            "saved hidden is not the current actual Target output")
    require(bool(torch.isfinite(record["hidden"]).all()) and bool(torch.isfinite(record["logits"]).all())
            and record["logits"].shape[0] == active*query, "incomplete/nonfinite Target output")
    require(record["outside_before"] == record["outside_after"], "Target changed unselected blocks")
    coverage = _write_coverage(checkpoint["kv_before"], checkpoint["kv_after"], checkpoint["write_slots"])
    require(not any(row["changed_outside_write_slots"] for row in coverage.values()), "Target changed outside Full write slots")
    return semantics


def isolation_errors(record, *, profile=PROFILE):
    require(profile in (PROFILE, CP_PROFILE, DFLASH_PROFILE), "named GLM isolation method required")
    query = method_for_profile(profile).draft_query
    after, checkpoint = record["target_after_draft"], record["checkpoint"]
    errors = []
    if not after["root_same"] or after["outside"] != record["outside_after"] or _differences(checkpoint["kv_after"], after["kv"]):
        errors.append("Draft polluted GLM Target cache or ownership")
    require(record["target_metadata_owner_after_target"] == record["target_metadata_owner_after_draft"],
            "Draft rebound Target metadata object or Tensor header")
    before_inputs, after_inputs = (_snapshot_value(x) for x in (record["target_post_forward_inputs"], after["inputs"]))
    require(set(before_inputs["layers"]) == set(after_inputs["layers"]), "Draft changed Target metadata inventory")
    from tools.p7x_graph_repair5_target import _tensor_equal
    for name, metadata in before_inputs["layers"].items():
        current = after_inputs["layers"][name]
        require(set(metadata) == set(current), "Draft changed Target metadata fields")
        for field in metadata:
            if field != "slot_mapping":
                require(_tensor_equal(metadata[field], current[field]), "Draft changed Target metadata " + field)
    # Full slot contents are intentionally rewritten by the baseline Draft
    # preparation; canonical absolute semantics are independently checked below.
    for key in ("input_ids", "positions", "query_start_loc"):
        require(torch.equal(before_inputs[key], after_inputs[key]), "Draft changed GLM Target " + key)
    table = next(iter(before_inputs["layers"].values()))["block_table"]
    expected_slots, positions = [], []
    for row, target_positions in enumerate(record["identity"]["positions"]):
        query_positions = list(range(target_positions[-1]+1, target_positions[-1]+1+query))
        positions += query_positions
        expected_slots += [int(table[row, p//128])*128 + p%128 for p in query_positions]
    require(after["draft_slots"].tolist() == expected_slots and after["draft_positions"].tolist() == positions
            and after["draft_query"].tolist() == [query*i for i in range(record["identity"]["active"]+1)],
            "named Draft canonical absolute write contract failed")
    return errors
