# SPDX-License-Identifier: Apache-2.0
"""Named completed GLM TP16 legacy-CP diagnostic, separate from serving.

Uses the actual joint-feature configuration with an empty disposable scheduler.
Serial completion, full KV snapshots and independent Draft eager forwards are
diagnostic overhead. No normal Async overlap, operand or physical-read claim is
made by this producer/checker. Historical non-CP contracts remain strict.
"""
from __future__ import annotations

import json
from functools import partial
from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from tools.r8_c255_tool_binding import bootstrap_paths, require_dispatch_enabled
    bootstrap_paths()
    if len(sys.argv) > 1 and sys.argv[1] == "run":
        require_dispatch_enabled()

import torch

from tools.p7x_graph_repair4_target import _snapshot_value
from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair25_rank_numeric import (
    build_parser, check_external as common_check_external,
    check_rank_payload, run_controlled, diagnostic_cases, glm_dspark_cp_return_selection,
    validate_dspark_cp_join_metadata,
)
from tools.p7x_graph_repair32_glm_rank import SP_CAPTURE, SP_CAPTURE_CONTRACT, validate_glm_worker
from tools.p7x_graph_repair37_glm_target import (
    CP_PROFILE as PROFILE, GLMTargetAdapter, component_contract, isolation_errors, validate_record,
)
from tools.p7x_graph_repair38_glm_numeric import (
    GLMNumericWorker, build_kwargs as base_kwargs, join_arms, compare_rank, model_contract, validate_fixture,
)


def build_kwargs(arm, tp):
    kwargs = base_kwargs(arm, tp)
    kwargs.update(async_scheduling=True, enable_prefix_caching=True, enable_chunked_prefill=True)
    kwargs["compilation_config"]["cudagraph_capture_sizes"] = SP_CAPTURE.copy()
    kwargs["additional_config"].update(enable_dsa_cp=True, enable_flashcomm1=True,
                                         multistream_overlap_shared_expert=True)
    kwargs["worker_extension_cls"] = "tools.p7x_graph_repair55_glm_cp_numeric.GLMCPNumericWorker"
    return kwargs


class GLMCPNumericWorker(GLMNumericWorker):
    diagnostic_profile = PROFILE

    def _target_adapter(self, current, contract, **kwargs):
        return GLMTargetAdapter(current, rank_contract=contract, actual_rank=self.rank, cp=True, **kwargs)


def validate_worker(worker, tp):
    return validate_glm_worker(worker, tp, capture_contract=SP_CAPTURE_CONTRACT)


def component_keys(sample):
    inputs = _snapshot_value(sample["checkpoint"]["inputs"])
    components = component_contract(True)
    return {name + "/" + kind for name, metadata in inputs["layers"].items()
            for kind, _ in components[metadata["metadata_class"]]}


def check_payload(path, payload, worker):
    validate_worker(worker, 16)
    require(payload["profile"] == PROFILE and payload["world_size"] == 16, "wrong completed CP rank/profile")
    return check_rank_payload(path, payload, worker, profile=PROFILE,
        record_validator=lambda record: validate_record(record, cp_rank=worker["rank"]),
        isolation_validator=isolation_errors, component_keys=component_keys)


def check_external(planned, execution):
    result = common_check_external(planned, execution, profile=PROFILE,
        kwargs_factory=build_kwargs, model_contract_factory=model_contract,
        fixture_validator=validate_fixture, payload_checker=check_payload,
        extra_worker_validator=validate_worker, allow_external_only=True)
    if result["status"].startswith("PASS_SCOPED_"):
        try:
            declared = json.loads(Path(planned).read_text())
            parsed = build_parser().parse_args(declared["argv"][2:])
            proof = validate_fixture(parsed.fixture_plan, parsed.fixture)
            require(all(proof[key] == declared[key] for key in ("source_sha", "source_tree")),
                    "completed CP fixture is not this producer")
        except (ValueError, KeyError, TypeError, OSError) as error:
            result.update(status="INVALID_EVIDENCE", error=str(error))
    result.update(glm_cp_checker_tool_sha256=digest(__file__), profile=PROFILE,
        target_binding_scope="COMPLETED_CP_METADATA_AND_FULL_WRITE_NOT_EXECUTION_OPERANDS",
        async_scope="ASYNC_CONFIGURED_EMPTY_DISPOSABLE_ENGINE_NOT_NORMAL_OVERLAP")
    return result



def join_cp_return_subset(args):
    """All16 exact Target joins for original DSpark CP0/10/2, never full14."""
    selection = glm_dspark_cp_return_selection(PROFILE)
    result = dict(status="INVALID_EVIDENCE", profile=PROFILE, ranks=[], case_selection=selection,
                  comparison_scope="DSPARK_CP_0_10_2_ONLY_NOT_COMPLETE_TARGET14",
                  physical_read="NOT_OBSERVED", normal_overlap="NOT_INFERRED_FROM_SERIAL_DIAGNOSTIC")
    try:
        externals = [check_external(args.off_planned, args.off_execution),
                     check_external(args.on_planned, args.on_execution)]
        result["external_arms"] = externals
        plans = [json.loads(Path(path).read_text()) for path in (args.off_planned, args.on_planned)]
        parsed = [build_parser().parse_args(plan["argv"][2:]) for plan in plans]
        parents = [json.loads((value.output / "parent-execution.json").read_text()) for value in parsed]
        validate_dspark_cp_join_metadata(plans, parsed, parents, externals, PROFILE)
        for rank in range(16):
            workers = [next(row for row in parent["workers"] if row["rank"] == rank) for parent in parents]
            require(workers[0]["runtime_versions"] == workers[1]["runtime_versions"]
                    and workers[0]["loaded_native_hashes"] == workers[1]["loaded_native_hashes"],
                    "rank runtime/native changed across selected CP pair")
            comparison = compare_rank(
                parsed[0].output / f"rank-{rank}/controlled-target.json",
                parsed[1].output / f"rank-{rank}/controlled-target.json",
                progress=args.output.with_name(f"cp-return-rank-{rank}-target-pairs-progress.json"),
                profile=PROFILE, record_validator=partial(validate_record, cp_rank=rank),
                isolation_validator=isolation_errors, case_selection=selection)
            result["ranks"].append(dict(rank=rank, comparison=comparison))
            write(args.output, result)
            require(comparison["status"] == "PASS_SELECTED_CASES"
                    and [row["scenario_index"] for row in comparison["pairs"]] == [0, 10, 2]
                    and len(comparison["pairs"]) == 3,
                    "selected CP Target values, scenario order or coverage failed")
        result.update(status="PASS_SCOPED_GLM_DSPARK_CP_TP16_TARGET_RETURN_0_10_2_48_PAIRS",
                      producer_commit=plans[0]["source_sha"],
                      numeric_aba="ON_ARM_EXTERNAL_CHECK_REQUIRED_PASS_SCOPED")
    except (ValueError, KeyError, TypeError, OSError, IndexError, RuntimeError) as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result


def main():
    args = build_parser().parse_args()
    if args.command in ("check", "join"):
        torch.set_num_threads(2)
        result = (check_external(args.planned, args.execution) if args.command == "check" else
                  join_cp_return_subset(args) if args.glm_dspark_cp_return_subset else
                  join_arms(args, profile=PROFILE, external_checker=check_external,
                            validator_for_rank=lambda rank: lambda record: validate_record(record, cp_rank=rank)))
        write(args.output, result)
        return 0 if result["status"].startswith("PASS_SCOPED_") else 4
    require(args.tp == 16, "named completed CP diagnostic requires TP16")
    proof = validate_fixture(args.fixture_plan, args.fixture)
    require(proof["source_sha"] == args.expected_sha, "completed CP fixture is not the fixed producer")
    return run_controlled(args, profile=PROFILE, kwargs_factory=build_kwargs,
        model_contract_factory=model_contract, fixture_validator=validate_fixture,
        payload_checker=check_payload, extra_worker_validator=validate_worker,
        producer_path=__file__, defer_payload_validation=args.external_payload_check_only)


if __name__ == "__main__":
    raise SystemExit(main())
