# SPDX-License-Identifier: Apache-2.0
"""Named GLM DFlash K15/Q16 continuous reference and heterogeneous Target join.

Reuses the actual rank RPC, capture-output sink, canonical-prestate eager
reference and chunked artifact/checker path. This serial diagnostic is separate
from required-feature service, normal lifecycle and performance acceptance.
"""
from __future__ import annotations

import argparse
import json
from functools import partial
from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from tools.r8_c255_tool_binding import bootstrap_paths, require_dispatch_enabled
    bootstrap_paths()
    if len(sys.argv) > 1 and sys.argv[1] == "run":
        require_dispatch_enabled()

import torch

from tools.p7x_graph_repair12_contract import method_for_profile
from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair25_rank_numeric import (
    RankControlledTarget, RankNumericWorker, build_parser, check_external as common_check,
    check_rank_payload, diagnostic_cases, glm_dflash_multirow_selection, run_controlled,
)
from tools.p7x_graph_repair37_glm_target import (
    DFLASH_PROFILE as PROFILE, GLMControlledTarget, GLMTargetAdapter,
    isolation_errors as glm_isolation, validate_record as glm_record,
)
from tools.p7x_graph_repair38_glm_numeric import component_keys, compare_rank, join_arms
from tools.p7x_graph_repair37_glm_target import component_contract
from tools.p7x_graph_repair4_target import _snapshot_value
from tools.p7x_graph_repair62_glm_dflash_anchor import (
    DRAFT, DRAFT_CONFIG_SHA, TARGET, TARGET_CONFIG_SHA, GLMDFlashWorker,
    build_kwargs as anchor_kwargs, profile_identity, validate_worker as anchor_validate_worker,
)


REQUIRED_NUMERIC_PROFILE = "GLM_DFLASH_REQUIRED_CP_SP_Q16_SELECTED7_10_11_V1"


def required_numeric(args):
    required = getattr(args, "glm_dflash_required_features", False)
    require(type(required) is bool, "typed DFlash required-feature numeric switch")
    if required:
        require(args.tp == 16 and args.glm_dflash_multirow and args.repair6_target_prefix is None,
                "required-feature numeric is only the original three TP16 canaries")
    return required


def build_kwargs(arm, tp, *, required_features=False):
    require(arm in ("ON", "OFF"), "explicit GLM DFlash Window arm required")
    require(type(required_features) is bool, "typed DFlash required-feature numeric context")
    result = anchor_kwargs(tp, window_on_review=arm == "ON")
    result["worker_extension_cls"] = "tools.p7x_graph_repair66_glm_dflash_numeric.GLMDFlashNumericWorker"
    if arm == "ON":
        result["additional_config"]["draft_window_graph_numeric_diagnostic"] = True
    if required_features:
        result.update(async_scheduling=True, enable_prefix_caching=True, enable_chunked_prefill=True,
                      max_model_len=24576, max_num_batched_tokens=256)
        result["additional_config"].update(enable_dsa_cp=True, enable_flashcomm1=True,
                                             multistream_overlap_shared_expert=True)
        result["worker_extension_cls"] = (
            "tools.p7x_graph_repair66_glm_dflash_numeric.GLMDFlashRequiredNumericWorker")
    return result


def validate_fixture(plan_path, fixture):
    plan, manifest = (json.loads(Path(p).read_text()) for p in (plan_path, fixture))
    require(plan["schema"] == "glm66-frozen-diagnostic-plan-v1"
            and manifest["schema"] == "glm66-model-identity-v1"
            and plan["fixture_manifest"] == str(fixture)
            and plan["fixture_sha256"] == digest(fixture)
            and plan["profile"] == manifest["profile"] == PROFILE,
            "named DFlash source/model plan differs")
    from tools.p7x_graph_local_candidate import BASE_SHA, _identity
    _identity(Path(plan["source"]), plan["source_sha"], plan["source_tree"], ancestor=BASE_SHA)
    expected = profile_identity()
    require(plan["profile_identity"] == manifest["profile_identity"] == expected,
            "actual GLM DFlash config/header identity differs")
    return dict(plan=str(plan_path), plan_sha256=digest(plan_path), fixture_sha256=digest(fixture),
                source_sha=plan["source_sha"], source_tree=plan["source_tree"], profile_identity=expected,
                scope="FIXED_CONFIG_INDEX_AND_DFLASH_WEIGHT_HEADER_NOT_NEW_FULL_WEIGHT_HASH")


def model_contract(fixture, kwargs):
    manifest = json.loads(Path(fixture).read_text())
    require(manifest["profile"] == PROFILE and manifest["profile_identity"] == profile_identity()
            and kwargs["model"] == str(TARGET) and kwargs["speculative_config"]["model"] == str(DRAFT),
            "actual model pair differs from the named GLM DFlash fixture")
    return dict(target=dict(path=str(TARGET / "config.json"), sha256=TARGET_CONFIG_SHA,
                            layers=99, decoder_layers=78, indexer_owners=21, backend="SFA_PLUS_INDEXER"),
                draft=dict(path=str(DRAFT / "config.json"), sha256=DRAFT_CONFIG_SHA,
                           layers=5, kv_heads=64, head_size=64, k=15, query=16, sample_offset=1))


class GLMDFlashRankControlledTarget(RankControlledTarget, GLMControlledTarget):
    """Reuse all completed-sample barriers, Full slots and Target ownership."""


class GLMDFlashNumericWorker(RankNumericWorker, GLMDFlashWorker):
    diagnostic_profile = PROFILE
    controlled_type = GLMDFlashRankControlledTarget

    def _validate_method_owner(self, spec):
        require(spec.method == "dflash" and spec.requires_non_causal is True,
                "actual noncausal DFlash method required")
        require(type(spec.draft_kv_cache_group_id) is int and spec.draft_kv_cache_group_id == 0,
                "this controlled fixture requires the observed unified group0; do not write another group's state")
        method_for_profile(PROFILE).validate_owner(spec)

    def _target_adapter(self, current, contract, **kwargs):
        return GLMTargetAdapter(current, rank_contract=contract, actual_rank=self.rank,
                                method_profile=PROFILE, **kwargs)


class GLMDFlashRequiredNumericWorker(GLMDFlashNumericWorker):
    """Completed Q16 canaries in the actual feature configuration, not overlap proof."""

    def _target_adapter(self, current, contract, **kwargs):
        return GLMTargetAdapter(current, rank_contract=contract, actual_rank=self.rank,
                                cp=True, method_profile=PROFILE, **kwargs)

    def mrv2_rank_snapshot(self):
        from vllm_ascend.ascend_config import get_ascend_config
        from vllm_ascend.utils import enable_sp

        row = super().mrv2_rank_snapshot()
        config = self.vllm_config
        additional = config.additional_config or {}
        row["required_numeric_context"] = dict(profile=REQUIRED_NUMERIC_PROFILE,
            async_scheduling=config.scheduler_config.async_scheduling,
            prefix_caching=config.cache_config.enable_prefix_caching,
            chunked_prefill=config.scheduler_config.enable_chunked_prefill,
            SP=enable_sp(config), legacy_dsa_cp=get_ascend_config().enable_dsa_cp,
            FlashComm=additional.get("enable_flashcomm1"),
            shared_expert=additional.get("multistream_overlap_shared_expert"),
            max_model_len=config.model_config.max_model_len,
            max_num_batched_tokens=config.scheduler_config.max_num_batched_tokens,
            capture_sizes=list(config.compilation_config.cudagraph_capture_sizes),
            scope="CONFIGURED_COMPLETED_EMPTY_SCHEDULER_NOT_NORMAL_ASYNC_OR_PREFIX_HIT")
        return row


def validate_required_worker(worker, tp):
    validate_worker(worker, tp)
    context = worker["required_numeric_context"]
    require(context["profile"] == REQUIRED_NUMERIC_PROFILE
            and all(context[key] is True for key in ("async_scheduling", "prefix_caching", "chunked_prefill",
                "SP", "legacy_dsa_cp", "FlashComm", "shared_expert"))
            and type(context["max_model_len"]) is int and context["max_model_len"] == 24576
            and type(context["max_num_batched_tokens"]) is int and context["max_num_batched_tokens"] == 256
            and context["capture_sizes"] == [16, 32, 64]
            and context["scope"] == "CONFIGURED_COMPLETED_EMPTY_SCHEDULER_NOT_NORMAL_ASYNC_OR_PREFIX_HIT",
            "actual completed DFlash required-feature configuration differs")
    return worker


def required_component_keys(sample):
    inputs = _snapshot_value(sample["checkpoint"]["inputs"])
    components = component_contract(True)
    return {name + "/" + kind for name, metadata in inputs["layers"].items()
            for kind, _ in components[metadata["metadata_class"]]}


def check_required_payload(path, payload, worker):
    validate_required_worker(worker, 16)
    require(payload["profile"] == PROFILE and payload["world_size"] == 16
            and payload.get("required_feature_numeric") is True
            and payload.get("case_selection") == glm_dflash_multirow_selection(PROFILE),
            "named complete DFlash required-feature three-canary context required")
    return check_rank_payload(path, payload, worker, profile=PROFILE,
        record_validator=partial(validate_record, cp_rank=worker["rank"]),
        isolation_validator=isolation_errors, component_keys=required_component_keys)


def validate_record(record, *, cp_rank=None):
    return glm_record(record, profile=PROFILE, cp_rank=cp_rank)


def isolation_errors(record):
    return glm_isolation(record, profile=PROFILE)


def validate_worker(worker, tp):
    anchor_validate_worker(worker, tp)
    groups = worker["glm_profile"]["draft_groups"] + worker["glm_profile"]["target_groups"]
    require(all(type(group["global_group_id"]) is int and group["global_group_id"] == 0 for group in groups),
            "this named controlled fixture requires actual unified group0; anchor supports a wider inventory")


def check_payload(path, payload, worker):
    validate_worker(worker, 16)
    require(payload["profile"] == PROFILE and payload["world_size"] == 16,
            "named complete GLM DFlash rank/profile required")
    return check_rank_payload(path, payload, worker, profile=PROFILE,
        record_validator=validate_record, isolation_validator=isolation_errors, component_keys=component_keys)


def check_external(planned, execution):
    try:
        declared = json.loads(Path(planned).read_text())
        parsed = build_parser().parse_args(declared["argv"][2:])
        required = required_numeric(parsed)
    except (ValueError, KeyError, TypeError, OSError):
        # The shared checker rejects malformed/missing plans before model/config
        # comparison; retain its default failure fields and validation order.
        required = False
    result = common_check(planned, execution, profile=PROFILE,
        kwargs_factory=partial(build_kwargs, required_features=required),
        model_contract_factory=model_contract, fixture_validator=validate_fixture,
        payload_checker=check_required_payload if required else check_payload,
        extra_worker_validator=validate_required_worker if required else validate_worker, allow_external_only=True,
        cpu_workers=4)
    if result["status"].startswith("PASS_SCOPED_"):
        try:
            expected = json.loads(Path(planned).read_text())
            args = build_parser().parse_args(expected["argv"][2:])
            proof = validate_fixture(args.fixture_plan, args.fixture)
            require(all(proof[k] == expected[k] for k in ("source_sha", "source_tree")),
                    "DFlash fixture is not this producer")
        except (ValueError, KeyError, TypeError, OSError) as error:
            result.update(status="INVALID_EVIDENCE", error=str(error))
    result.update(profile=PROFILE, glm_dflash_numeric_tool_sha256=digest(__file__),
                  normal_overlap="UNPROVEN", physical_read="NOT_OBSERVED",
                  target_binding_scope=("COMPLETED_CP_Q16_METADATA_AND_FULL_WRITE_NOT_EXECUTION_OPERANDS" if required else
                                        "COMPLETED_SFA_INDEXER_METADATA_NOT_EXECUTION_OPERANDS"))
    if required:
        result["required_feature_numeric"] = REQUIRED_NUMERIC_PROFILE
    return result


def join_prefix3(args):
    """A named48-pair regression for changed load weights, never a full14 PASS."""
    result = dict(status="INVALID_EVIDENCE", profile=PROFILE, ranks=[],
                  comparison_scope="PREFIX3_ONLY_NOT_COMPLETE_TARGET14", physical_read="NOT_OBSERVED")
    try:
        externals = [check_external(args.off_planned, args.off_execution),
                     check_external(args.on_planned, args.on_execution)]
        result["external_arms"] = externals
        require(all(row["status"] == "PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC"
                    and row["ranks"] == 16 and row["samples_per_rank"] == 3 for row in externals),
                "two actual complete16-rank prefix3 arms required")
        plans = [json.loads(Path(p).read_text()) for p in (args.off_planned, args.on_planned)]
        parsed = [build_parser().parse_args(plan["argv"][2:]) for plan in plans]
        require([p.arm for p in parsed] == ["OFF", "ON"]
                and all(p.repair6_target_prefix == 3 for p in parsed), "named OFF/ON prefix3 required")
        require(all(plans[0][k] == plans[1][k] for k in ("source_sha", "source_tree")), "cross-source prefix pair")
        parents = [json.loads((p.output / "parent-execution.json").read_text()) for p in parsed]
        require(parents[0]["payload"]["run_id"] == parents[1]["payload"]["run_id"]
                and parents[0]["payload"]["nonce"] != parents[1]["payload"]["nonce"]
                and parents[0]["payload"]["model_configs"] == parents[1]["payload"]["model_configs"],
                "prefix attempts must be independent same-campaign/model")
        for rank in range(16):
            workers = [next(row for row in p["workers"] if row["rank"] == rank) for p in parents]
            require(workers[0]["runtime_versions"] == workers[1]["runtime_versions"]
                    and workers[0]["loaded_native_hashes"] == workers[1]["loaded_native_hashes"],
                    "rank runtime/native changed")
            comparison = compare_rank(
                parsed[0].output / f"rank-{rank}/controlled-target.json",
                parsed[1].output / f"rank-{rank}/controlled-target.json",
                progress=args.output.with_name(f"prefix3-rank-{rank}-target-pairs-progress.json"),
                profile=PROFILE, record_validator=validate_record,
                isolation_validator=isolation_errors, sample_limit=3)
            result["ranks"].append(dict(rank=rank, comparison=comparison))
            write(args.output, result)
            require(comparison["status"] == "PASS_PREFIX3" and len(comparison["pairs"]) == 3,
                    "prefix Target numerical pair failed")
        result.update(status="PASS_SCOPED_GLM_DFLASH_TP16_TARGET_PREFIX3_48_PAIRS",
                      producer_commit=plans[0]["source_sha"], normal_overlap="NOT_INFERRED_FROM_SERIAL_DIAGNOSTIC")
    except (ValueError, KeyError, TypeError, OSError, IndexError, RuntimeError) as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result


def join_multirow(args):
    """Independent Target join of exactly the three original multirow cases."""
    selection = glm_dflash_multirow_selection(PROFILE)
    cases = diagnostic_cases(PROFILE, selection)
    result = dict(status="INVALID_EVIDENCE", profile=PROFILE, ranks=[], case_selection=selection,
                  comparison_scope="MULTIROW_7_10_11_ONLY_NOT_COMPLETE_TARGET14",
                  aba="NOT_ASSESSED_SELECTED_CASES", physical_read="NOT_OBSERVED")
    try:
        externals = [check_external(args.off_planned, args.off_execution),
                     check_external(args.on_planned, args.on_execution)]
        result["external_arms"] = externals
        require(all(row["status"] == "PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC"
                    and row["ranks"] == 16 and row["samples_per_rank"] == len(cases)
                    and row.get("case_selection") == selection for row in externals),
                "two exact named multirow16-rank arms required")
        plans = [json.loads(Path(p).read_text()) for p in (args.off_planned, args.on_planned)]
        parsed = [build_parser().parse_args(plan["argv"][2:]) for plan in plans]
        require([p.arm for p in parsed] == ["OFF", "ON"]
                and all(p.glm_dflash_multirow and p.repair6_target_prefix is None for p in parsed),
                "named multirow OFF/ON CLI identities required")
        required = [required_numeric(p) for p in parsed]
        require(required[0] is required[1], "cross-context multirow feature pair")
        require(all(plans[0][k] == plans[1][k] for k in ("source_sha", "source_tree")),
                "cross-source multirow pair")
        parents = [json.loads((p.output / "parent-execution.json").read_text()) for p in parsed]
        require(all(p["payload"].get("case_selection") == selection for p in parents),
                "parent multirow indices/order/identity differ")
        require(parents[0]["payload"]["run_id"] == parents[1]["payload"]["run_id"]
                and parents[0]["payload"]["nonce"] != parents[1]["payload"]["nonce"]
                and parents[0]["payload"]["model_configs"] == parents[1]["payload"]["model_configs"],
                "multirow attempts must be independent same-campaign/model")
        for rank in range(16):
            workers = [next(row for row in p["workers"] if row["rank"] == rank) for p in parents]
            require(workers[0]["runtime_versions"] == workers[1]["runtime_versions"]
                    and workers[0]["loaded_native_hashes"] == workers[1]["loaded_native_hashes"],
                    "rank runtime/native changed")
            comparison = compare_rank(
                parsed[0].output / f"rank-{rank}/controlled-target.json",
                parsed[1].output / f"rank-{rank}/controlled-target.json",
                progress=args.output.with_name(f"multirow-rank-{rank}-target-pairs-progress.json"),
                profile=PROFILE, record_validator=(partial(validate_record, cp_rank=rank) if required[0] else validate_record),
                isolation_validator=isolation_errors, case_selection=selection)
            result["ranks"].append(dict(rank=rank, comparison=comparison))
            write(args.output, result)
            require(comparison["status"] == "PASS_SELECTED_CASES"
                    and [row["scenario_index"] for row in comparison["pairs"]] == [7, 10, 11]
                    and len(comparison["pairs"]) == len(cases), "multirow Target numerical pair failed")
        result.update(status="PASS_SCOPED_GLM_DFLASH_TP16_TARGET_MULTIROW_7_10_11_48_PAIRS",
                      producer_commit=plans[0]["source_sha"], normal_overlap="NOT_INFERRED_FROM_SERIAL_DIAGNOSTIC")
        if required[0]:
            result["required_feature_numeric"] = REQUIRED_NUMERIC_PROFILE
    except (ValueError, KeyError, TypeError, OSError, IndexError, RuntimeError) as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result


def main():
    if len(sys.argv) > 1 and sys.argv[1] in ("join-prefix3", "join-multirow"):
        parser = argparse.ArgumentParser(description="Named DFlash Target subset regression, not complete14")
        for name in ("off-planned", "off-execution", "on-planned", "on-execution", "output"):
            parser.add_argument("--" + name, type=Path, required=True)
        args = parser.parse_args(sys.argv[2:])
        torch.set_num_threads(2)
        result = join_multirow(args) if sys.argv[1] == "join-multirow" else join_prefix3(args)
        write(args.output, result)
        return 0 if result["status"] in ("PASS_SCOPED_GLM_DFLASH_TP16_TARGET_PREFIX3_48_PAIRS",
                                        "PASS_SCOPED_GLM_DFLASH_TP16_TARGET_MULTIROW_7_10_11_48_PAIRS") else 4
    args = build_parser().parse_args()
    if args.command in ("check", "join"):
        torch.set_num_threads(2)
        result = (check_external(args.planned, args.execution) if args.command == "check" else
                  join_arms(args, profile=PROFILE, external_checker=check_external,
                            validator_for_rank=lambda rank: validate_record, isolation_validator=isolation_errors,
                            cpu_workers=4))
        write(args.output, result)
        return 0 if result["status"].startswith("PASS_SCOPED_") else 4
    require(args.tp == 16 and validate_fixture(args.fixture_plan, args.fixture)["source_sha"] == args.expected_sha,
            "fixed complete TP16 GLM DFlash producer required")
    required = required_numeric(args)
    return run_controlled(args, profile=PROFILE, kwargs_factory=partial(build_kwargs, required_features=required),
        model_contract_factory=model_contract, fixture_validator=validate_fixture,
        payload_checker=check_required_payload if required else check_payload,
        extra_worker_validator=validate_required_worker if required else validate_worker, producer_path=__file__,
        defer_payload_validation=args.external_payload_check_only)


if __name__ == "__main__":
    raise SystemExit(main())
