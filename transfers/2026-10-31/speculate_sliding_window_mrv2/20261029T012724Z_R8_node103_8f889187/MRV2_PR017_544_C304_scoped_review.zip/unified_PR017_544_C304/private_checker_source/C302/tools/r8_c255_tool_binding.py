# SPDX-License-Identifier: Apache-2.0
"""Private tools colocated with one fixed Git candidate, not an overlay package.

Source identity is actual Git + CLI + the existing external runtime admission.
The recorded original C254/prepared paths are provenance only, never imports.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from types import MappingProxyType

TOOL_ROOT = Path(__file__).resolve().parents[1]
SOURCE = TOOL_ROOT
ORIGINS_PATH = SOURCE / 'tools/r8_c255_tool_origins.json'


def _git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()


def _origins():
    return json.loads(ORIGINS_PATH.read_text())


def _source_binding():
    origin = _origins()
    return MappingProxyType(dict(source=str(SOURCE), source_sha=_git('rev-parse', 'HEAD'),
        source_tree=_git('rev-parse', 'HEAD^{tree}'),
        production_tree=_git('rev-parse', 'HEAD:vllm_ascend'),
        base_ascend_sha=origin['base_ascend_sha'], vllm_sha=origin['vllm_sha'],
        vllm_tree=origin['vllm_tree'], vllm_source=origin['vllm_source'],
        tool_origin_source=origin['tool_origin_source'],
        tool_origin_sha=origin['tool_origin_sha'], tool_origin_tree=origin['tool_origin_tree']))


BINDING = _source_binding()
VLLM_SOURCE = Path(BINDING['vllm_source'])


def bootstrap_paths():
    # One tools package and its own Source; never either historical prepared
    # tools root or the C254 Python production source ahead of this candidate.
    origin = _origins()
    rejected = {str(SOURCE / 'tools'), origin['tool_origin_source'], *origin['prepared_roots']}
    ordered = [str(SOURCE), str(VLLM_SOURCE)]
    sys.path[:] = ordered + [p for p in sys.path
        if str(Path(p or '.').resolve()) not in rejected | set(ordered)]


def validate_identity_admission(receipt, runtime, *, expected_sha, binding=BINDING):
    if not (receipt['source_sha'] == expected_sha == binding['source_sha']
            and receipt['source_tree'] == binding['source_tree']
            and Path(receipt['vllm_checkout']).resolve() == Path(binding['vllm_source']).resolve()
            and runtime['source_sha'] == expected_sha
            and runtime['source_tree'] == binding['source_tree']
            and runtime['production_tree'] == binding['production_tree']
            and runtime['paired_vllm'] == binding['vllm_sha']
            and Path(runtime['paired_vllm_source']).resolve() == Path(binding['vllm_source']).resolve()):
        raise ValueError('actual Git/CLI/external admission/runtime Source or pin mismatch')


def tool_bundle_proof():
    """Actual tracked bytes and tool-only commit/tree; not an inherited PASS."""
    origin = _origins()
    identity = (_git('rev-parse', 'HEAD'), _git('rev-parse', 'HEAD^{tree}'))
    if identity != (BINDING['source_sha'], BINDING['source_tree']):
        raise ValueError('tool Source changed after module import')
    index = {}
    for entry in subprocess.check_output(['git', '-C', str(SOURCE), 'ls-tree', '-rz', 'HEAD', '--', 'tools']).split(b'\0'):
        if entry:
            header, path = entry.split(b'\t', 1)
            index[path.decode()] = header.split()[2].decode()
    paths = [row['relative_path'] for row in origin['selected_files']]
    paths += ['tools/r8_c255_tool_binding.py', 'tools/r8_c255_tool_origins.json']
    records = []
    for relative in sorted(set(paths)):
        data = (SOURCE / relative).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if index.get(relative) != blob:
            raise ValueError('uncommitted or modified private tool: ' + relative)
        records.append(dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    return dict(schema='FIXED_GIT_COLOCATED_PRIVATE_TOOLS_V1', source=str(SOURCE),
        commit=identity[0], tree=identity[1], files=records,
        origin_sha=BINDING['tool_origin_sha'], origin_tree=BINDING['tool_origin_tree'],
        modified_external_tools=False, source_colocated=True,
        scope='ACTUAL_TOOL_IDENTITY_NOT_RUNTIME_DEVICE_OR_NUMERICAL_ACCEPTANCE')


def _cli_value(flag):
    positions = [i for i, value in enumerate(sys.argv) if value == flag]
    if len(positions) != 1 or positions[0] + 1 >= len(sys.argv):
        raise ValueError('one explicit runtime admission CLI value required: ' + flag)
    return sys.argv[positions[0] + 1]


def require_dispatch_enabled():
    # Existing Root lease/health/expiry checks remain in validate_admission;
    # this narrow pre-import guard requires its actual fixed runtime receipt.
    tool_bundle_proof()
    receipt = json.loads(Path(_cli_value('--admission')).read_text())
    proof = receipt['runtime_manifest']
    data = Path(proof['path']).read_bytes()
    if hashlib.sha256(data).hexdigest() != proof['sha256']:
        raise ValueError('external runtime manifest changed')
    validate_identity_admission(receipt, json.loads(data), expected_sha=_cli_value('--expected-sha'))
