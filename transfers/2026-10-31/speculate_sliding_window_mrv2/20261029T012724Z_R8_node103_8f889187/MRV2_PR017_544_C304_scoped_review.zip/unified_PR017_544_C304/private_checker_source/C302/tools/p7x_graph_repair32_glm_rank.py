# SPDX-License-Identifier: Apache-2.0
"""Named GLM W4A8 / separate dense DSpark K8 TP16 Graph review anchor.

This is a new model/backend profile, not evidence inherited from Qwen. Existing
admission, request workload and external management/process join are reused.
No numerical, Target KV, native completion or physical-read verdict is implied.
"""
from __future__ import annotations

import argparse
from collections.abc import Mapping
import json
from pathlib import Path
import sys
import time

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair21_rank import RankWorkerExtension, digest, require, run_anchor, write

PROFILE = "GLM52_W4A8_DSPARK_K8_FULL_NONCAUSAL_TP16_FDO_REVIEW_V2"
TARGET = Path("/mnt/share/weights/GLM-5.2-w4a8")
DRAFT = Path("/mnt/share/l00887471/graph_vllm/dspark_test/sw-aspark/GLM5.2_dspark")
TARGET_CONFIG_SHA = "817f5fb39ca5d4c4b5648de89ca00deaea7537d8c2f130172a459252a05c1073"
DRAFT_CONFIG_SHA = "730803ab71b25b7ef38008024afef60fcfffeb6279db30732068eb668e218961"
QUANT_SHA = "fe2531095c6ff6e674c8f5e4a21c7ec354dd6d003e60aaf4450087a0e4344b70"
CAPTURE = [8, 16, 32, 36]
SP_CAPTURE_CONTRACT = "GLM_TP16_SP_PADDED_1_TO_4_V1"
SP_CAPTURE = [16, 32, 48]


def validate_model_configs(target, draft):
    require(target["architectures"] == ["GlmMoeDsaForCausalLM"] and target["model_type"] == "glm_moe_dsa"
            and target["num_hidden_layers"] == 78 and target["hidden_size"] == 6144,
            "actual GLM Target architecture/layers differ")
    require(draft["architectures"] == ["DSparkDraftModel"] and draft["block_size"] == 8
            and draft["sample_from_anchor"] is True and draft["sliding_window_non_causal"] is False,
            "separate DSpark K8/Q8/raw checkpoint sampling contract differs")
    cfg = draft["transformer_layer_config"]
    require(cfg["model_type"] == "qwen3" and cfg["num_hidden_layers"] == 5 and cfg["hidden_size"] == 6144
            and cfg["num_attention_heads"] == cfg["num_key_value_heads"] == 64 and cfg["head_dim"] == 192,
            "actual dense Draft geometry differs from declared GLM profile")
    require(target["max_position_embeddings"] >= 4096 and cfg["max_position_embeddings"] >= 4096,
            "declared length exceeds original model capability")


def profile_identity():
    require(digest(TARGET / "config.json") == TARGET_CONFIG_SHA and digest(DRAFT / "config.json") == DRAFT_CONFIG_SHA,
            "fixed model config hash changed")
    require(digest(TARGET / "quant_model_description.json") == QUANT_SHA, "Target quantization identity changed")
    validate_model_configs(json.loads((TARGET / "config.json").read_text()),
                           json.loads((DRAFT / "config.json").read_text()))
    paths = [TARGET / "config.json", TARGET / "quant_model_description.json",
             TARGET / "quant_model_weights.safetensors.index.json", TARGET / "tokenizer_config.json",
             DRAFT / "config.json"]
    return dict(profile=PROFILE, files=[dict(path=str(p), bytes=p.stat().st_size, sha256=digest(p)) for p in paths],
                scope="Config, quantization and weight-index identities; not a new full weight hash or PR pin approval")


def build_glm_kwargs(tp, *, window_on_review=False):
    require(type(tp) is int and tp == 16 and type(window_on_review) is bool,
            "this independent named GLM review profile requires actual TP16")
    kwargs = dict(model=str(TARGET), tensor_parallel_size=16, data_parallel_size=1,
                  distributed_executor_backend="mp", enable_expert_parallel=True,
                  worker_extension_cls="tools.p7x_graph_repair32_glm_rank.GLMRankWorker",
                  speculative_config=dict(method="dspark", model=str(DRAFT), num_speculative_tokens=8,
                                          enforce_eager=False, enable_adaptive_verification=False),
                  additional_config={}, quantization="ascend", trust_remote_code=True,
                  hf_overrides=dict(use_index_cache=True), async_scheduling=False, enable_prefix_caching=False,
                  compilation_config=dict(cudagraph_capture_sizes=CAPTURE.copy(), cudagraph_mode="FULL_DECODE_ONLY"),
                  enforce_eager=False, gpu_memory_utilization=0.6, max_model_len=4096,
                  max_num_batched_tokens=4096, max_num_seqs=4, seed=0, disable_log_stats=True)
    if window_on_review:
        kwargs["additional_config"].update(draft_window_size=1024, draft_window_graph_replicated_tp_review=True)
    return kwargs


def actual_draft_mask(spec, draft_groups):
    """Read the effective full-attention model masks, not the SWA-only flag.

    The actual checkpoint has five full_attention layers and no SWA. The
    training contract and pinned model keep full attention bidirectional even
    when the raw sliding_window_non_causal flag is False. Never change model
    inputs/configuration to satisfy this observer.
    """
    cfg = spec.draft_model_config.hf_config
    layers = getattr(cfg, "layer_types", None)
    require(layers == ["full_attention"] * 5,
            "actual GLM Draft normalized full-attention layer inventory differs")
    options = getattr(cfg, "dflash_config", None)
    require(options is None or isinstance(options, dict), "normalized Draft attention config must be a mapping")
    override = (options or {}).get("causal")
    require(override is None and getattr(cfg, "is_causal", None) is None,
            "this fixed full-attention profile cannot add a global causal override")
    require(spec.requires_non_causal is True, "actual GLM full-attention Draft must retain noncausal capability")
    model_masks = spec.model.get_draft_attn_causal()
    require(len(model_masks) == 5 and all(value is False for value in model_masks),
            "actual built Draft layer masks differ from full-attention semantics")
    causal = spec._group_causal
    rows = []
    for group in draft_groups:
        gid = group["global_group_id"]
        value = causal.get(gid) if isinstance(causal, Mapping) else causal
        require(type(gid) is int and value is False, "actual dense Draft global group must remain noncausal")
        rows.append(dict(global_group_id=gid, causal=value))
    require(rows, "actual Draft causal group inventory missing")
    return dict(noncausal=spec.requires_non_causal, normalized_layer_types=layers,
                normalized_causal_override=override, actual_layer_causal=list(model_masks),
                group_causal=rows, mask_source="NORMALIZED_CONFIG_ACTUAL_MODEL_AND_SPECULATOR_GROUP_MASKS")


def cache_headers(value, depth=0):
    """Bounded logical tensor headers only: never read, copy or sync data.

    These headers help plan an independent GLM Target/KV experiment. They do
    not establish a write set, native format, completion or physical read set.
    """
    import torch
    if isinstance(value, torch.Tensor):
        return dict(kind="TENSOR_HEADER_ONLY", shape=list(value.shape), dtype=str(value.dtype),
                    device=str(value.device), stride=list(value.stride()), storage_offset=value.storage_offset(),
                    data_ptr=value.data_ptr(), storage_data_ptr=value.untyped_storage().data_ptr(),
                    storage_bytes=value.untyped_storage().nbytes(), element_bytes=value.element_size(),
                    native_format="NOT_QUERIED_NO_ADDITIONAL_DEVICE_API")
    if value is None:
        return dict(kind="NONE")
    if depth < 4 and isinstance(value, (list, tuple)) and len(value) <= 16:
        return dict(kind=type(value).__name__, items=[cache_headers(x, depth+1) for x in value])
    if depth < 4 and isinstance(value, dict) and len(value) <= 32:
        return dict(kind="dict", items={str(k):cache_headers(v, depth+1) for k,v in value.items()})
    return dict(kind="NOT_AVAILABLE", reason="UNSUPPORTED_OR_UNBOUNDED_HOST_CONTAINER",
                python_type=type(value).__module__+"."+type(value).__qualname__)


def target_cache_headers(runner, groups):
    context = runner.compilation_config.static_forward_context
    metadata = runner.model_state.attn_metadata
    rows = []
    for group in groups:
        gid = group["global_group_id"]
        for name in group["layers"]:
            row = dict(layer=name, global_group_id=gid, backend=group["backend"])
            try:
                owner = context[name]
                size = runner.block_tables.kernel_block_sizes[gid]
                require(type(size) is int and size > 0, "kernel block size must be an existing Host integer")
                row.update(owner_class=type(owner).__module__+"."+type(owner).__qualname__,
                           kv_cache=cache_headers(getattr(owner,"kv_cache",None)),
                           kernel_block_size=size)
                item = metadata.get(name) if isinstance(metadata, dict) else None
                row["metadata_class"] = type(item).__module__+"."+type(item).__qualname__
                row["metadata_tensor_headers"] = {
                    key: cache_headers(getattr(item,key)) for key in
                    ("block_table_tensor","slot_mapping","positions","query_start_loc","seq_lens")
                    if hasattr(item,key)
                }
            except (AttributeError,KeyError,IndexError,RuntimeError,TypeError,ValueError) as error:
                row.update(status="NOT_AVAILABLE_HOST_INSPECTION", error=repr(error))
            rows.append(row)
    return dict(observed_host_monotonic_ns=time.monotonic_ns(), layers=rows,
                scope="POST_REQUEST_HOST_HEADERS_ONLY_NOT_TARGET_KV_NUMERIC_ISOLATION_OR_COMPLETION")


class GLMRankWorker(RankWorkerExtension):
    """Inspect actual per-group backends and method configuration using Host metadata."""

    def mrv2_rank_snapshot(self):
        row = super().mrv2_rank_snapshot()
        runner, spec = self.model_runner, self.model_runner.speculator
        groups, draft_groups = [], []
        draft = set(spec.draft_attn_layer_names)
        for members in runner.attn_groups:
            for group in members:
                draft_names = sorted(set(group.layer_names) & draft)
                if draft_names:
                    draft_groups.append(dict(global_group_id=group.kv_cache_group_id, layers=draft_names,
                                             backend=group.backend.__module__ + "." + group.backend.__qualname__))
                names = sorted(set(group.layer_names) - draft)
                if names:
                    groups.append(dict(global_group_id=group.kv_cache_group_id, layers=names,
                                       backend=group.backend.__module__ + "." + group.backend.__qualname__,
                                       cache_spec=type(group.kv_cache_spec).__module__ + "."
                                       + type(group.kv_cache_spec).__qualname__))
        row["glm_profile"] = dict(profile=PROFILE, target_groups=groups, draft_groups=draft_groups, k=spec.num_speculative_steps,
                                  draft_query=spec.num_query_per_req, sample_from_anchor=spec.sample_from_anchor,
                                  **actual_draft_mask(spec, draft_groups),
                                  target_model=self.vllm_config.model_config.model,
                                  draft_model=spec.draft_model_config.model)
        row["target_cache_host_headers"] = target_cache_headers(runner, groups)
        return row


def validate_glm_worker(worker, tp, *, draft_graph=True, capture_contract=None):
    require(tp == 16, "GLM all-rank profile is TP16")
    require(type(draft_graph) is bool, "explicit Draft execution mode required")
    profile = worker["glm_profile"]
    require(profile["profile"] == PROFILE and profile["k"] == profile["draft_query"] == 8
            and profile["sample_from_anchor"] is True and profile["noncausal"] is True
            and profile["target_model"] == str(TARGET) and profile["draft_model"] == str(DRAFT),
            "worker actual method/model contract mismatch")
    layers = worker["draft_layers"]
    require(len(layers) == len(set(layers)) == 5 and set(worker["draft_backend"]) == set(layers),
            "complete actual five dense Draft layers required")
    require(all(name.endswith("attention_v1.AscendAttentionBackend") for name in worker["draft_backend"].values()),
            "GLM profile declares separate dense FIA Draft, not Target SFA")
    require(set(worker["draft_kv_geometry"]) == {name + "/" + str(i) for name in layers for i in (0, 1)},
            "actual per-layer K/V inventory incomplete")
    for geometry in worker["draft_kv_geometry"].values():
        shape = geometry["shape"]
        require(len(shape) == 4 and shape[0] > 0 and shape[1:] == [128, 4, 192]
                and geometry["dtype"] == "torch.bfloat16", "GLM Draft per-rank K/V geometry differs")
    declared = profile["draft_groups"]
    require(len(declared) == 1 and set(declared[0]["layers"]) == set(layers)
            and declared[0]["backend"].endswith("attention_v1.AscendAttentionBackend"),
            "actual dense Draft global group ownership required")
    gid = declared[0]["global_group_id"]
    require(type(gid) is int and gid >= 0, "explicit actual Draft global group ID required")
    require(profile["normalized_layer_types"] == ["full_attention"] * 5
            and profile["normalized_causal_override"] is None
            and len(profile["actual_layer_causal"]) == 5
            and all(value is False for value in profile["actual_layer_causal"])
            and profile["group_causal"] == [dict(global_group_id=gid, causal=False)]
            and all(type(row["global_group_id"]) is int and row["causal"] is False for row in profile["group_causal"])
            and profile["mask_source"] == "NORMALIZED_CONFIG_ACTUAL_MODEL_AND_SPECULATOR_GROUP_MASKS",
            "normalized config, actual model and group masks disagree")

    if worker["window_size"] is not None:
        require(all(item["global_group_id"] == gid for item in worker["window_generations"])
                and all(item["global_group_id"] == gid for item in worker["window_graph_bindings"]),
                "Window generations/bindings use another global cache group")
    groups = profile["target_groups"]
    main = [g for g in groups if g["backend"].endswith("sfa_v1.AscendSFABackend")]
    indexer = [g for g in groups if g["backend"].endswith("indexer.AscendSFAIndexerBackend")]
    target_layers = [name for group in groups for name in group["layers"]]
    main_layers = [name for group in main for name in group["layers"]]
    indexer_layers = [name for group in indexer for name in group["layers"]]
    # The frozen GLM config has 78 attention layers and 21 full indexers.
    # Indexer cache layers are separate AttentionLayerBase owners, not extra
    # decoder layers and not part of the dense Draft cache group.
    require(len(groups) == len(main) + len(indexer)
            and len(main_layers) == len(set(main_layers)) == 78
            and len(indexer_layers) == len(set(indexer_layers)) == 21
            and len(target_layers) == len(set(target_layers)) == 99
            and not set(target_layers) & set(layers),
            "complete actual Target SFA main and independent indexer owners required")
    draft_inventory = {(r["requests"], r["tokens"]) for r in worker["draft_graph_inventory"] if r["mode"] == "FULL"}
    target_inventory = {(r["requests"], r["tokens"]) for r in worker["target_graph_inventory"] if r["mode"] == "FULL"}
    require(capture_contract in (None, SP_CAPTURE_CONTRACT), "unknown GLM capture contract")
    # SP filters raw sizes to multiples of TP16. Uniform decode then rounds
    # to Q8/Q9: active1 pads to two rows and active3 pads to four rows.
    # Keep the historical non-SP inventory exact, and require both serving
    # buckets for the separate SP profile; a missing large bucket is fatal.
    draft_required = {(1, 8), (2, 16), (4, 32)} if capture_contract is None else {(2, 16), (4, 32)}
    target_required = {(1, 9), (2, 18), (4, 36)} if capture_contract is None else {(2, 18), (4, 36)}
    require(((draft_required <= draft_inventory) if draft_graph else not draft_inventory)
            and target_required <= target_inventory,
            "actual K8 Draft and Target Q9 capture inventory missing")


def check_glm(planned, execution):
    from tools.p7x_graph_repair28_rank_anchor_check import check
    result = check(planned, execution, kwargs_factory=build_glm_kwargs, worker_validator=validate_glm_worker,
                   entrypoint_name=Path(__file__).name)
    if result["status"] != "INVALID_EVIDENCE":
        try:
            expected = json.loads(Path(planned).read_text())
            argv = expected["argv"]
            campaign = json.loads((Path(argv[argv.index("--output") + 1]) / "campaign.json").read_text())
            require(expected["profile_identity"] == campaign["profile_identity"] == profile_identity(),
                    "declared and actual independent GLM profile identities differ")
            result.update(profile=PROFILE, status=result["status"] + "_GLM_K8_SFA_TARGET_DENSE_DRAFT")
        except (ValueError, KeyError, OSError, TypeError) as error:
            result.update(status="INVALID_EVIDENCE", error=f"{type(error).__name__}: {error}")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run")
    for name in ("admission", "output"):
        run.add_argument("--" + name, type=Path, required=True)
    run.add_argument("--expected-sha", required=True)
    run.add_argument("--tp", type=int, choices=(16,), required=True)
    run.add_argument("--window-on-review", action="store_true")
    check = commands.add_parser("check")
    for name in ("planned", "execution", "output"):
        check.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    if args.command == "run":
        return run_anchor(args, profile_kwargs=build_glm_kwargs(args.tp, window_on_review=args.window_on_review),
                          profile_identity=profile_identity(), producer_path=__file__)
    result = check_glm(args.planned, args.execution)
    write(args.output, result)
    return 0 if result["status"].startswith("PASS_SCOPED_ALL_RANK_") else 4


if __name__ == "__main__":
    raise SystemExit(main())
