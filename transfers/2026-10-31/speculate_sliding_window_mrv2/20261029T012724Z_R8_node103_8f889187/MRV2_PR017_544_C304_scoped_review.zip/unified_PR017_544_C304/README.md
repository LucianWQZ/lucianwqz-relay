# PR017/544 + C304统一候选审查包：固定代码与限定结果（整体未验收）

本包已收录完整C302 OFF/ON Target48最终联合PASS及执行/清理原件。16rank×3=48对；CPU退出0/2184.841360秒。统一017/544候选仍NOT_READY，未push、未更新公开PR；具体缺项见下文与handoff。

## 身份与恢复顺序

- 最终纯生产 C304：`f25dce7e7f4f31ec2d0057257fca5d805e2ad70c`；tree `38e19e4be80b11c232bd52e3fbc7f381ec566025`；production `6c82f991116dbb36df8b195cd725dc7253cb2020`。相对 PR017 共 8 个 DCO 提交。
- 前置基线必须是 PR017：`017cfca1c74c2e0b9984876bd4250593ed681908`。增量 bundle 不含该基线；21 MB 基线 pack 已独立恢复校验，但不纳入本小包。
- 配套 vLLM：`544f182d9f0c9bfe8bd7645525951d5e3692a542`。该源码、CP312/CANN 环境、原始模型和 native 二进制不在 bundle 内，需按实际运行身份另行绑定。
- 在 017 上依次应用 C300 六提交 mbox、C301 一提交 mbox、C304 一提交 mbox，或逐一 fetch 三个增量 bundle。每层恢复 receipt 记录实际 prerequisite、tree 和 hash；git-am 后 commit SHA 可因 committer 不同，须核对完整 tree、production tree 与 native Source tree。
- C300、C301 历史恢复材料及 C301 首次验证脚本错误的 FAIL 原件保留。Source 恢复 PASS 仅证明可恢复性，不构成新组合的设备、质量、性能、发布或 public Gate 批准。

## 当前证据与适用边界

| 原件 / 工作项 | 已成立的结论 | 边界与未完成项 |
|---|---|---|
| `qualification/C304` | 实际纯生产 Source/native 导入及 37 项有限 guard 控制通过；包含源提交、定向 Host 检查和运行身份白名单 | Host / 导入证据，不是 C304 模型设备 PASS |
| `validation/C296_failed_ON` | 保存 rank13 config-context 断言、实际执行和退出时间线 | 原 FAIL 保留；不归责外部，不改写为通过 |
| `validation/C302_ON` | ON 的 16 rank × 3 样本可比数值、Full 写与 ABA 严格检查 PASS | 仅 `0/10/2` 串行诊断范围，不是完整 14 场景、正常 Async 重叠或硬件读取证明 |
| `validation/C302_OFF` | OFF Target-only 检查及其实际执行、清理 / 释放记录已完成 | 不写成 OFF Draft Graph/eager 数值通过；跨OFF/ON完整Target联合见下项 |
| C302 完整 Target48 联合检查 | 16 rank / 48 对联合 PASS | CPU退出0/2184.841360秒；完整JSON见validation/C302_Target48，excerpt不可替代 |
| `historical_performance/C273` | 保留 16K / 32K / 64K / 128K 三臂共 12 格完整 CSV 和原计数 | 仅属于 PR534 / vLLM a982 的历史组合，不是 PR017 / vLLM544 或 C304 性能 |

C302 producer / checker 的实际身份保持为 `1fd6da87ae146cd87cff35bee9c9f0011372da04`，production 为 `b10f59bc6700c995e6531c09cd5a13f92a8ef908`，未重标为 C304。C304 相对该生产底座只增加 Eagle 普通入口未资格保护；未改变的 DSpark 计算属性按现有影响审阅限定复用。两臂单独joint保留原SINGLE_ARM状态；另附独立完整Target48联合终态。

Source/API 与已保存数值材料支持各自登记范围的工程审阅；本包不宣称已直接观测逐次执行 operand 或硬件 physical read-set。Host 返回、HTTP 完成、进程退出和清理记录均不单独证明最后设备 reader 完成。

## 新组合仍未关闭的交付项

- **GLM DFlash（017/544）**：普通服务有效完成数仍为 0；受影响的 eager 资格、Graph 普通路径资格及新配对性能未完成。旧加载或数值证据保持其原候选身份，不作为新组合的完整 PASS。
- **Full8 普通服务**：新组合单请求普通资格尚未完成，当前入口保持拒绝；未因已有局部数值或工具修复而开放。私有数值诊断与独立 typed eager 按各自合同处理。
- **精确 SWA DFlash checkpoint**：Draft Graph 暂不开放，Window OFF 也不绕过保护；原调用异常、API 适用性和归属未决记录保留，不套用 Q017。
- **Eagle 普通服务**：C304 对新 PR017/544 有限单请求普通入口临时 fail closed，等待该组合实际资格；原 active/padded、first/AR、静态 K 与零提议保护保留。旧 a982 资格不作为 544 通过；显式私有数值诊断和独立 typed eager 路线保留。
- **性能与发布**：没有新 PR017/544 配对性能验收；旧 C273 四档结果只作历史参考。public Gate 默认冻结，本包不批准发布、质量或业务验收。

当前已保存的 PR017 CI 记录为 FAIL：未修改的 KVPool mypy 调用错误在独立原基线亦复现，下游 CPU/NPU 项为 SKIPPED，不是 PASS。已保存远端状态为 `mergeable=false`，不推断当前可合并。本轮未 push、未修改原 PR 或其交付分支。

## 原件与文件表范围

- `source_restore/C300`、`C301`、`C304`：真实 bundle / mbox 与独立恢复 receipt 链；明确前置 017，不打包配套 544、环境或基线大 pack。
- `private_checker_source/C302`：从实际 `checker_tool_bundle` 逐文件核 hash 的 20 个审查所需 Source / 身份文件子集。不是全部 82 文件，也不是独立可运行的完整工具发布包；完整复算仍使用原固定 C302 工具与共享原始 payload。私有 checker 不进入公开生产 patch。
- `excerpts/EXCERPT_rank0_A_mixed_outputs01`：原 excerpt 完整副本，保留 index、metadata、tensor、重算结果与脚本，仅证明其实际覆盖范围，不替代完整 Target48。
- `historical_performance/C273`：保留完整 12 格 metrics CSV 及简要 metadata / counts JSON；未复制 1.8 MB rollup 或大 SSE。

`STAGING_FILES.tsv`记录原件来源、大小和SHA256；最终payload以REVIEW_INDEX.json为准。未复制完整runtime env、凭据、权重、native或大trace。

## 最终检查与恢复边界

- 完整Target48 JSON：252163 bytes，SHA256 fe89893165f255f1ffcaaa9e2a7568063fdb653f00206cccfcb63f8ce623189e；Source C3021fd6，原工具a6df26d0，CPU rc0/2184.841360秒。原0/10/2子集，不是14场景或正常Async服务。
- 原20小时设备hard2026-10-30T20:39:27.210402Z，设备进程提前释放；CPU联合20:40:21完成，两PID亦退出。两份release审查保留，清理不是reader完成证明。
- handoff/NEXT_SESSION_HANDOFF.json与reports为本次状态副本。大tensor/trace在原服务器；必要小样本明确EXCERPT，标准库重算已独立通过，不冒充完整Target checker输入。
- Source恢复已独立验证：精确017前置，C300→C301→C304三段bundle或mbox；最终tree38e19e4b、production6c82f991、csrc19b96b8a。环境、模型、完整私有工具、native二进制不在Source包中。
- 最终payload逐项hash见REVIEW_INDEX.json；ZIP CRC/内容hash结果见外部DOWNLOAD_MANIFEST_PR017_544_C304.json。接收方未实际验证。
- 新544 GLM DFlash正常/零提议、eager及新性能，Eagle first/AR普通资格仍需新设备窗口。原保护与全部FAIL保留。未push、未更新发布分支/公开PR。
