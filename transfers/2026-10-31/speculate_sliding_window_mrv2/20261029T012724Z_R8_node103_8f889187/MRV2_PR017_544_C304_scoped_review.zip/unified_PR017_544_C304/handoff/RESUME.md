<!-- R8_CURRENT_BEGIN -->
更新时间：2026-10-30T20:42:27.864127+00:00（UTC）  
主机：**node-25-140**  
当前状态：**设备窗口已结束；C302新017/544限定数值/Full写/ABA及完整Target48联合通过，交接已保存，设备任务停止。**  
当前动作：CPU联合已于20:40:21 UTC退出0，用时2184.841360秒；16rank×3对全部通过。没有模型、worker、checker或后续派发器运行；本次代码/证据收尾已完成，等待后续指令。  
设备：**本任务NPU进程及租约已释放；本窗口不再派发**。CPU wrapper2112418/checker2112420亦已退出；完整清理审查见 `C304_final_release_audit02.json`。不宣称整机没有其他任务。  
候选：开发/纯生产 **C304 f25dce7e7f4f31ec2d0057257fca5d805e2ad70c**，tree **38e19e4be80b11c232bd52e3fbc7f381ec566025**；实际producer/checker **C302 1fd6da87ae146cd87cff35bee9c9f0011372da04**，生产仍C301 b10f59bc。C304仅新增Eagle普通入口未验拒绝，不改DSpark/DFlash/DFlash2；原结果不重标SHA。底座 **017cfca1 / vLLM544f182d**。  
截止：T0 **2026-10-30 00:39:27 UTC**；派发收尾 **19:54:27 UTC**；硬截止 **20:39:27 UTC / 10月31日04:39:27 +08:00**，均已到期，不重新计时。CPU联合按明确授权在设备截止后完成。

**整体管理进度95%，可信度中等；统一017/544候选仍 NOT_READY。** 这是原权重累计证据覆盖，不是544验收通过率；本次复验不重复加分。

当前主要缺口：①新544的GLM DFlash正常Graph/零提议及受影响eager资格未测；②新组合真实服务/正常reader适用性仍需受影响路径定向核验；③新544性能未测，完整旧C273四档12格仍仅属534/a982。Full8/Eagle新544普通入口及精确SWA checkpoint Graph关闭，原失败保留。

下一项可验收结果：新的有效设备授权后，先执行已准备且禁用派发的C303 GLM DFlash G_ON正常功能/零提议资格（TP16，约35–45分钟/臂）；随后受影响eager与必要匹配性能。当前不启动它。完整Target48：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261029T012724Z_R8_node103_8f889187/node140_return_20261029T0150Z/reanalysis/C302_CP_Target48_readonly_01/C302_OFF_ON_Target48.json`，SHA256 **fe89893165f255f1ffcaaa9e2a7568063fdb653f00206cccfcb63f8ce623189e**。
<!-- R8_CURRENT_END -->

恢复必须先核实际PID与plan/result。C283/C285/C286均已有终态，不得重派旧队列；本轮只有明确新资格计划可由唯一控制者启动。下方C237/R7及旧节点区块均为历史，不控制当前派发。





<!-- C237_CURRENT_NOTE_BEGIN -->
当前补充（2026-10-29T02:43:32.614991+08:00，node-25-140，20261028T023750Z_R7_node140_06fafe0d）：开发C237 `8f889187b33b719290e40342ca020b46c61244bc`，工具首轮eager query按真实CPU输入/metadata核对，生产与C236相同，固定源码/overlay：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/candidates/node140/C237_eagle_actual_eager_query_layout/vllm-ascend`。132相关Host通过、旧C190真实原件重算及4损坏关联验证完成；不是新NPU通过。待设备仍C231 GLM G_ON/C232 Full8原生最小对照；具名Eagle TP4计划`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/state/R7_C237_QWEN36_EAGLE_TP4_PLAN_01.json`关闭派发。实际资源等待器PID3670715/start_ticks79153086存活，最多一次派发，截止2026-10-28T19:36:32.235445Z；核对其identity/exit后方可人工启动，不能重复控制。原R7收尾/硬截止不变。
<!-- C237_CURRENT_NOTE_END -->

<!-- R7_CURRENT_BEGIN -->
更新时间 2026-10-29T00:21:08.677828+08:00；node-25-140；SESSION `20261028T023750Z_R7_node140_06fafe0d`。当前 WAIT_RESOURCE：当前16卡均有约58GiB非本任务进程；C234四rank数值链Host准备与旧真实TP2离线复算已完成，等待一片后卡做C232，完整16空闲则优先C231 GLM G_ON。NPU当前未使用，本任务无模型/worker/supervisor/租约；只有有限只读资源观察，不会自动派发或写全局状态。

最新开发/只读checker C237 `8a0f15d8e80211aad7719121dd9cea2c361ce28a`，tree `eccd1516bfa5e99c6b75a326eccec68d04ef9b78`，干净；固定 `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/candidates/node140/C236_eagle_tp4_three_arm_entry/vllm-ascend`。C236已补Tool46独立TP4 E_ON身份及实际eager consumer/generation关联，旧真实原件和损坏反例/冻结绑定核对通过，尚无设备结果；准备计划`state/R7_C236_QWEN36_EAGLE_TP4_PLAN_01.json`不自动派发，DFlash优先。C235仅增加受控具名TP4/K3/W1024 causal eager Source准入，原4正例拒绝→69相关Host通过，无设备结果；C234数值程序准备保留。C233 Eagle受控TP4准入/真实QKV分片后，C234仅工具数值链增量；115 Host检查及C190旧真实原件CPU复算通过，TP4设备NOT_RUN，未修复C203/C213/C216原数值问题，W1035尚未适配。待设备producer维持C231/C232固定源码，不热改。

C232 attempt02准备脚本的实际工具路径已纠正为`p7x_graph_repair83_saved_eagle_fia.py --full8-active8`，Source/checker/input仍固定C232；以计划当前script_sha256为准。已真实导入wrapper验证绑定/依赖，无main/无GPU。C204→C236 DSpark增量分类及9核心/1223 native连续性核对完成，复用旧范围，无本次新DSpark设备结果。

当前有界一次派发等待器PID3670715/start_ticks79153086，只等待至2026-10-28T19:36:32.235445+00:00，不重置资源窗口；identity `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261028T023750Z_R7_node140_06fafe0d/orchestration/C231_glm_dflash_G_ON_audit/one_prepared_case_wait_identity.json`，原始等待日志 `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261028T023750Z_R7_node140_06fafe0d/orchestration/C231_glm_dflash_G_ON_audit/one-case-wait.stdout.log`。资源等待期间无设备租约，完整16可用优先C231 G_ON，否则后卡C232；最多派发一个现成case，失败不重试、结束不串发第二项。恢复时先读该identity和实际PID/child，存在健康任务时不得重复派发。取消等待可将identity的cancel_requested置true；如已经DISPATCHING/RUNNING，按对应现有监督器核查并处理，只管理本任务。

下一项：完整16卡实际可用时 `state/R7_C231_GLM_DFLASH_HTTP_PLAN_01.json` 单个GLM G_ON实例（25–40分钟、hard4500秒）；只有后卡时 `state/R7_C232_SAVED_FULL8_PLAN_02.json` 一次保存输入native对照（1–3分钟、hard600秒）。均需新鲜准入，不复用首次资源拒绝的非空attempt。已有准备不重建；C231 Q精确但attention有效行1/6不同的FAIL保留，详见 `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261028T023750Z_R7_node140_06fafe0d/reanalysis/C231_active8_first_attention01`。

证据：C227 TP4/DP1首三consumer数值/Full写PASS，C225三臂测量及20/24自然同token/4差异保留质量限制，C222服务/限定reader；C147/C151/C185和C205/C208按未变范围复用。Full8自然合同已答，不重复问；SWA/Eagle准确API归属及最终PR组合未定，public Gate冻结。

原T0 `2026-10-28T02:37:50.031917Z`；收尾 `2026-10-29T13:52:50.031917Z`；硬截止 `2026-10-29T14:37:50.031917Z`。资源可用性修订 `state/R7_RESOURCE_AVAILABILITY_AMENDMENT_20261028T1515Z.json`，不是新窗口。

管理进度65/NOT_READY（8+44+10+2+1），Host/工具/资源不加分。固定观察入口 `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/all` 下adapt五文件；人工原答与实施 `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/manual_review/adapt_人工后续核查.md`。PR只读。
<!-- R7_CURRENT_END -->

以下为历史恢复记录；本轮仅以顶部R8活动控制者/实际PID与20小时合同为准。

<!-- NODE101_CURRENT_BEGIN -->
更新时间：2026-10-28T11:16:16.136588+08:00  
主机：**node-25-140**  
当前状态：**模型启动中：C204 GLM TP16 32K E_ON；并行轻量Host准备**  
当前动作：只补32K同Window Draft eager缺臂；真实准入已通过，16rank设备context已观察，Target捕获已有输出，尚未取得正式组结果。开发树C205仅移植必要DFlash QuaRot加载兼容，11CPU检查通过，等当前实验结束再固定/设备验证。  
设备：Phy0–15按共同协议完整持有；supervisor1721864/start_ticks73852828，producer1722038，server1722167；case `C204_R7_product32k_E_ON_missing_arm_03_node140`。预计03:38–03:58 UTC结束，硬超时约04:13 UTC；实时事实以JSON/原始日志为准。  
候选：开发C205 `062ccf3d8ff01c2fa477b8e729760bf68a3ed86d`/tree `69c674fdeaafb5a56f48c3e1cca967da62184a48` 干净；**当前受测/producer/checker仍C204** `06fafe0da5f690bbd7accb21984063b53fb60031`，pin84030bbe/native不变；旧数值C147、C159/C164、C195/C196及完整性能C185保持身份，C203有效输出FAIL保留。  
新窗口：T0北京时间 **2026-10-28 10:37:50.031917**（接收近似）；收尾 **2026-10-29 21:52:50.031917**；硬截止 **2026-10-29 22:37:50.031917**，不重置。SESSION `20261028T023750Z_R7_node140_06fafe0d`。

**整体管理进度58%，可信度中低；NOT_READY。** 公共8/10＋DSpark39/65＋DFlash8/12＋Eagle2/8＋最终交付1/5。C205只有代码/Host，当前E_ON尚无完整结果，均未提前计分。

主要阻塞：①DSpark正常Graph证据适用性与C151可比差异待裁决/最小补证；②DFlash新加载底座待真实Graph验证、Full8 Target/reader、SWA API来源D；③指定Eagle有效输出差异与最终PR固定组合。

下一项可验收结果：本次32K E_ON的3组原始耗时/接受计数、实际Target模式及16rank关联，约45–65分钟/case（已在运行），不是跨窗口平衡性能PASS。当前原始日志：[实时入口](adapt_live.log)；完整case `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261028T023750Z_R7_node140_06fafe0d/raw/C204_R7_product32k_E_ON_missing_arm_03_node140`。
<!-- NODE101_CURRENT_END -->

<!-- HISTORICAL_C154_CHECKPOINT_BEGIN -->
## 历史恢复快照（已由顶部最终交接取代，不再控制派发）
- **当前优先恢复事实 2026-10-27T23:36:14.043349+08:00**：C199 `d19b88bd587d88736f3429afa211a9fc62fe1649`/tree`cb496692a0427a1213a79e848e8c8ad4be725b8c`，固定`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/candidates/node140/C199_eagle_numeric_admission/vllm-ascend`，runtime`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runtime/node140/C199_eagle_numeric_admission/runtime_manifest.json` SHA`6440d3d4601c91c27c52fed159ab52f4d405eb78600637c80815851b19be04ae`；源码/native冻结。控制器`state/C199_EAGLE_NUMERIC_ACTIVE_CONTROLLER.json` PID1003402/ticks69769493，15:32:35.500015Z启动，Phy14–15/TP2，hard1800s；plan`state/C199_NODE140_QWEN36_EAGLE_NUMERIC_PLAN_01.json`。先核对进程、raw/result/lease，禁止重复启动。C198普通锚点guard错误已保留且全部退出；没有数值样本。83 Host及C198实际EngineArgs配置AST复用通过，非设备PASS。


## 历史检查点（2026-10-27T22:38:13.790031+08:00，node-25-140）

- 最新开发/固定/当前producer C195 `fbf9d89ed47400dbe5099ef246ef96033fd4c079`，tree`cd9215b9c0948e613cc5a99510cc3ff37e0173c9`，干净；production`d967b1263c961bf10210616c09248430575325a1`与C194相同，C195仅工具。source`candidates/node140/C195_full8_actual_eager_reference/vllm-ascend`，runtime同名`runtime_manifest.json` SHA`ac95cffbd03bc7dd921df24593b87c0946a2244e4dc8b0ef9624e65a1f4d7576`。vLLM固定84030bbe/f3e320f8；native/generated C161 lineage1223/69,262,708 bytes继承，未改底层。
- 已结束控制者`state/C195_FULL8_NUMERIC3_ACTIVE_CONTROLLER.json`，PID978126/ticks69512502，case`C195_qwen36_Full8_actual_eager_numeric3_01_node140`，Phy8–11/TP4，2026-10-27T14:49:45.522686Z启动。先查PID/ticks/结果/log/lease，不重复派发。Plan`state/C195_NODE140_FULL8_NUMERIC3_PLAN_01.json`。硬2700秒＋45分钟收尾；模型源码/native冻结。
- 当前修工具关键：C191复制Graph carrier的Target阶段态作eager参考，会让PrefillNoCache选择query-only K/V，而真实Draft builder选择cache/table/exact。已用实际backend CPU分支证明这不是等价参考。C195用canonical独立table/exact送实际eager builder，保留旧参考同前态反事实与双正确参考/首层Q/FIA；设备已确认：all4正确参考hidden与16路KV零差，双正确参考一致，旧参考精确复现31.75/16370差；独立CPU verdict在`reanalysis/C195_Full8_reference_origin_01/verdict.json`。源数据原FAIL不改。当前继续无owned的三样本前哨。53定向Host通过。工件先落已完成阶段，excerpt不是主artifact。
- C194实际执行但额外工具guard失败，主sample PREPARING/path=null；原result误记raw-ready，纠正在`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261024T195020Z_R6_node140_3bf24139/node140_return_C144_20261026T1425Z/raw/C194_qwen36_Full8_first_attention_repeat_probe_02_node140/raw_completion_correction.json`，没有数值结论。自身进程/lease已释放。不重跑C194，不回退C191；C193为配置前置失败，无NPU。
- C190指定Qwen3.6 Eagle TP2 OFF/ON均已完成；producer C190 `4e0ca43a7086d65f187ceaf11631a19b70074ff0`，C192 checker `f137a81aa0f9a341d5070d24290b37aef5ad22c9`。各5×32、actual2rank/Host first+AR Graph/ON裁窗/device join接受；接受率响应缺失NOT_AVAILABLE，不是数值/Target/正常reader/性能。OFF外部`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261024T195020Z_R6_node140_3bf24139/node140_return_C144_20261026T1425Z/reanalysis/C190_Eagle_OFF_external_C192_01/joint.json`；ON raw相应result。计划disabled，不能重复恢复旧OFF/ON。
- C185六段测量完成：每臂2独立服务×3同实例重复，72组108正式请求，cached_tokens0。Window短/8K/16K/混合耗时节省0.49%/−21.59%/+18.18%/−11.97%；同Window Graph3.71–8.83%。`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261024T195020Z_R6_node140_3bf24139/node140_return_C144_20261026T1425Z/reanalysis/C185_matched_performance/summary.json`、samples.csv、workload_split.json。短慢例97验证步vs其余中位55；相同全计数短例ON仍慢5.17%/6.78%。仍DIAGNOSTIC，非AISBench/32–128K主负载或发布验收，不重启旧性能队列。
- C184/C186/C188有界来源调查已结束：正请求functional OFF与current Window均异常，但准确API/完整官方模型仍未确认，D分类、SWA原FAIL保留。原目录已有canonical_pair_results.json、版本/hash/source proof及单命令复现；不重复native探针/不追CANN内部。实际加载batch_invariant vendor不等于FIA解析到它，不能擅自禁用。
- C195无owned三样本已完成producer0/289.697秒；C196离线checker修复Window exact/Full endpoint误关联后4rank×3通过，原INVALID保留，结论`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261024T195020Z_R6_node140_3bf24139/node140_return_C144_20261026T1425Z/reanalysis/C195_Full8_numeric3_external_C196_01/joint.json`。当前CPU准备指定Eagle TP2逐consumer数值。之后推进指定Eagle逐consumer数值/Target与剩余DFlash/policy。未决DSpark R6-C151-TOKEN-01、正常Graph reader合同适用性及最终PR固定pair维持原问，不自动豁免/换pin。
- 58%管理估算、NOT_READY（8+39+8+2+1），未因Host修工具加分。T0 2026-10-26T07:21:18.369Z；收尾2026-10-27T18:36:18.369Z，硬截止19:21:18.369Z不延长。只改adapt，PR/pr_*只读，Gate冻结，不push/merge。
- 五观察入口dev/all adapt_*，活动JSON/live/原progress由唯一监督器写；root写DEV和当前Markdown，避免双写。人工原答/执行`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/manual_review/adapt_人工后续核查.md`。下方历史队列/旧next_resume_action不得控制派发。
<!-- HISTORICAL_C154_CHECKPOINT_END -->

## 历史记录（以下不控制当前派发）

以下保留原时点与产物；其中旧“当前/下一步”不是活动指令。


---

---

---

## R6恢复检查点（2026-10-26T17:52:31.984758+08:00）

更新时间：2026-10-26T17:52:31.984758+08:00；node-25-140；SESSION `20261024T195020Z_R6_node140_3bf24139`。

- 当前 `WAIT_RESOURCE / HOST_ANALYSIS`；16卡按用户要求让给同事，Graph无活动进程或租约，不会自动派发。
- 开发/只读checker为C134 `d3032810…`；设备producer仍为C133 `5ee6c354…`，二者不得混记。
- C133/C134启动与配对Host预检通过；Graph/PR共同DP1 SP谓词只读核对完成。两边pin不同、无批准集成pair，Gate仍冻结。
- 资源归还后执行C133 G_OFF→G_ON→C134离线联合checker；不重启C131中断attempt。
- 新截止：UTC `2026-10-27T19:21:18.369Z`，北京时间 `2026-10-28T03:21:18.369+08:00`。旧截止和旧候选段均为历史快照。
- 恢复入口：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/state/C133_DEVICE_PLAN_01.json`；启动预检：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/reports/20261024T195020Z_R6_node140_3bf24139/C133_C134_launch_pair_preflight_01.json`。

---

## 本轮继续检查点 C131 / 2026-10-26

更新时间：2026-10-26T16:59:54.439626+08:00；node-25-140；SESSION 20261024T195020Z_R6_node140_3bf24139。

- 开发与固定候选C131：e8b4c010b4cdfb13f29bac36795eee2dc329a18c，tree 7fadc3e3ef7c276c6ca32f97352804d9504f9ecc，干净。C131只改工具；production继承C129 prefix接线。
- C128真实TP16三臂首周期全部联合接受：G_OFF 26.415682s、G_ON 18.564209s、E_ON 20.430217s；各512输出。首周期Window耗时下降29.72%、同Window Graph下降9.13%，不是>=5次完整性能判定。
- C127已取得GLM官方HTTP/SSE、真实Draft/Target capture/replay、16rank设备关联；这不是全特性或新数值证明。
- C126 before_replay/after_update两rank真实sample_tokens异常展开、quarantine和Host guard均联合接受；旧R41无导出失败保留。
- C130 prefix_01/02均在模型前因Host导入问题失败，未计模型启动；C131改为worker内延迟导入，62定向检查通过。新C131服务有限队列正在执行，实际case/PID以current_status.json与adapt_日志入口.json为准，禁止重复启动。
- 下一独立分支：Window OFF真实Async/prefix/FlashComm/SP/legacyDSA-CP/chunked底座；随后Window ON按实际缺口适配。不能把底座通过算Window ON全特性通过。
- GLM关键连续数值/Target仍为C106；>=5次OFF/ON完整性能为C110，保留来源SHA。C129 prefix分支尚无设备数值验收。
- 新授权T0=2026-10-26T07:21:18.369Z；硬截止2026-10-27T19:21:18.369Z（北京10月28日03:21:18.369），最后45分钟收尾，不重置。
- dev/all五入口已建立：adapt_progress.log、adapt_live.log、adapt进度.md、adapt_任务总报告.md、adapt_日志入口.json；原journal/progress.log只追加，inode未更换。
- 人工核查：/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/manual_review/adapt_人工后续核查.md；PR工作树和pr_*入口只读。DSpark→DFlash→Eagle3，完整交付NOT_READY，public Gate冻结。

---

## 2026-10-26T08:19:04.506366+00:00 当前权威续跑点

本任务adapt/Graph，node-25-140，不是PR/139；误发未执行。资源T0=2026-10-26T07:21:18.369Z，新硬截止2026-10-27T19:21:18.369Z（北京10月28日03:21:18.369），最后45分钟收尾；合同state/R6_RESOURCE_RENEWAL_20261026T072118Z_CORRECTED.json。
开发HEAD C128 3676632185fbd869774ddc2c1478ea9ea44947e1/tree16e61e8b49bba733ee85ca6b61a7624207fa028a；有未提交parallel-prefix生产改动和测试，不能reset。C127官方GLM TP16服务10HTTP/16rank真实Graph和外部卡PID联合接受；C126两个TP2故障点通过并释放。
当前活动有限队列state/C128_FIRST_THREE_ARM_CYCLE_01.json，三个case仅首周期，顺序G_OFF→G_ON→E_ON、16K/512，全部固定C128；不能重复启动，不当作六周期性能通过。检查队列PID/starttime、current_status和租约后恢复。
Host下一项：prefix Graph定向检查→独立C129；之后按真实资源/依赖启动prefix hit和数值/生命周期复验，不删除Async/SP/DSA-CP保护。Graph/eager standalone source已由真实P7 Host反例证明已有rank能力，已撤下不必要的未提交新flag方案，保留reports/20261024T195020Z_R6_node140_3bf24139/C128_eager_source_counterexample_01。
旧rank0导出原JSON截断，02仅完整725494事件前缀，174个Host scope；无设备task/flow，不能当全trace。五个观察入口仍dev/all/adapt_*；原journal/progress.log仅追加，人工核查dev/manual_review/adapt_人工后续核查.md。
以下为历史快照，不得恢复旧全部队列或旧截止。

## 2026-10-26T15:19:33.932909+08:00 恢复实际开发（当前权威增量）

node-25-140；20261024T195020Z_R6_node140_3bf24139；原截止15:50:20+08不变。开发C125工作树正在修R41；当前无NPU/worker/租约，不恢复旧队列。最新GLM数值C106、性能C110分别保留身份。五个固定观察入口位于 /mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/all：adapt_progress.log、adapt_live.log、adapt进度.md、adapt_任务总报告.md、adapt_日志入口.json。原journal/progress.log仅追加，inode保持。Eagle3最后做，不取消；DSpark阶段一全部必需特性不推迟到阶段二。下一步：R41双入口定向检查→本地提交→固定候选；设备只在有效窗口和收尾预算内启动。

# R6 当前进展（2026-10-26T09:48:10.789426+08:00）

- 活动节点：node-25-140；SESSION：20261024T195020Z_R6_node140_3bf24139。
- 原36小时截止：2026-10-26 07:50:20.891980 UTC／北京时间15:50:20；本次恢复不重置。
- 开发HEAD：C125 `15d428d9f3d270e8b5adcae7930d51d42af76c4c`；tree `e83764853a5e2a6a834ece72abb320dd03aee9ab`；工作区干净。C125179定向Host及9个真实旧artifact/27损坏反例复核完成，仅工具证据合同改变，production与C124相同。C125尚未新NPU。
- 当前设备阶段：`NUMERIC_MEMO_SENTINEL`，运行候选 `771aed7526c55a5a8f807cc258c357048140e4d6`；最近外部监控 `2026-10-26T01:47:59.784769+00:00`。这是C118正确性链，不是正常性能测量。监督器/模型/设备观测/验收四者分别见current_status与原始case；不由Host return推导设备完成。
- 想解决的问题：混合请求有长先结束、短后结束时，不能用最终一代active/S代表整个测量组。C125保存实际框架分配的external/internal request-ID对应及测量区间内所有Host retire身份；不增加设备query、同步或D2H。旧合同和失败保留。
- 刚完成：C101原12对Target双臂由C102只读显式联合复核通过（producer仍C101、checkerC102，新增NPU0）；C112 Q8全部36正常控制+独立long profile完成。Q8短/16K Window ON回退13.996%/7.876%，同Window Graph快17.680%/13.193%；不写性能达标。
- Q8模型问题：现有fixture是原Q7权重仅配置改no-anchor；短/16K接受率0.893%/0.373%。已提出原生Q8 checkpoint问题，不能未经证据断言训练不兼容首因，更不更换模型伪装优化。
- GLM TP16既有24正常cell完整：短ON慢6.217%；16K耗时减少27.854%，接受9.153%→24.928%、验证295→173。长profile已采全16rank raw，正在对rank0副本做安装版本官方离线导出，原raw不修改；尚未把导出存在当分析完成。
- 当前队列：post07继续C118→多rank异常→DFlash短profile→Eagle原生chat六次对照；新priority随后实际Eagle TP2 OFF/ON→原生长/中/短混合三臂；post08_04随后六官方服务→GLM短ON profile→owned-pinned默认OFF优化的正确性/Target/性能（按预算）。所有旧等待器有精确无子进程/无租约退役记录，没有停止有效模型。
- 最后关键独立正确性证据仍按producer分别记录：Eagle C91完整42consumer/Target14；Q8 C70数值/Target14与LIFE582；Qwen C99/C105 TP16每rank12；GLM C106 TP16每rank14/177Target组件。它们不是C125全矩阵通过。
- 仍缺：C124实际TP2锚点后完整数值/Target/LIFE、C125混合设备结果、优化启用后的闭包与收益、新服务join、最终PR集成pair；正常合同安装适用前提和execution occurrence/operand/physical-read直接证据未自动关闭。完整Graph目标未完成，Gate冻结。

日志：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/journal/progress.log`（只追加，inode13416539200）。
详细记录：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/journal/20261024T195020Z_R6_node140_3bf24139`。
raw：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261024T195020Z_R6_node140_3bf24139/raw`。
人工问题原文：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/manual_review/adapt_人工后续核查.md`。

## 下一条恢复动作

1. 读取本checkpoint和三个当前队列状态，核对PID/starttime与租约，不重复模型派发。
2. 开发和固定候选分开；C125固定 `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/candidates/node140/C125_window_history/vllm-ascend`，runtime `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runtime/node140/C125_window_history/runtime_manifest.json`；运行中候选仍按实际case，禁止改其源码/overlay。
3. GLM离线导出只接受副本路径，校验实际trace/CSV而非rc或analyse.done；正常性能阶段避免本任务重I/O。C122六服务结束后运行join_c122_method_services_01.py。
4. 当前工具失败已保留：C125预检01顺序位错误（02已正确通过）；GLM导出01结果键错误（02正在副本导出）。都没有启动新模型或修改原raw。
5. 07:20 UTC停止新长派发，07:50前释放本任务设备。最终包/bundle尚未生成，return/LATEST仍指上轮已验证包。

checkpoint：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/reports/20261024T195020Z_R6_node140_3bf24139/checkpoints/20261026T014810Z/CHECKPOINT.json`。


进度页维护约定：dev/all/adapt进度.md只保留当前状态/原权重阶段条目；后续定点更新，禁止用多文件摘要循环重写该页或追加旧快照；兼容NODE101_CURRENT锚点仅供定位，不代表执行主机。旧格式一次归档见reports/20261024T195020Z_R6_node140_3bf24139/adapt进度_旧格式归档.md。
