#!/usr/bin/env python3
"""Recompute only this labelled excerpt. No framework, device or full checker."""
import argparse
from array import array
import hashlib
import json
import math
from pathlib import Path
import struct
import sys

HERE = Path(__file__).resolve().parent
SHA = '1fd6da87ae146cd87cff35bee9c9f0011372da04'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def decode_metadata(value):
    if isinstance(value, dict) and set(value) == {'mapping'}:
        return {k: decode_metadata(v) for k, v in value['mapping']}
    if isinstance(value, dict) and set(value) in ({'list'}, {'tuple'}):
        return [decode_metadata(v) for v in next(iter(value.values()))]
    return value

def local_path(value):
    p = (HERE / value).resolve()
    assert p.is_relative_to(HERE), 'excerpt path escapes directory'
    return p

def tensor_bytes(index, name):
    ref = index['tensor_refs'][name]
    data = local_path(ref['local_path']).read_bytes()
    assert len(data) == ref['bytes'] and digest(data) == ref['sha256']
    for chunk in ref['chunks']:
        part = data[chunk['offset']:chunk['offset'] + chunk['bytes']]
        assert len(part) == chunk['bytes'] and digest(part) == chunk['sha256']
    return data, ref

def bf16_array(data):
    out = array('H')
    out.frombytes(data)
    if sys.byteorder != 'little':
        out.byteswap()
    return out

def bf16_float(bits):
    return struct.unpack('<f', struct.pack('<I', bits << 16))[0]

def compare(index, entry):
    left, lref = tensor_bytes(index, entry['left'])
    right, rref = tensor_bytes(index, entry['right'])
    assert lref['dtype'] == rref['dtype'] == 'torch.bfloat16'
    assert lref['shape'] == rref['shape'] == entry['shape']
    assert len(left) == len(right) == 2 * math.prod(entry['shape'])
    if entry['kind'] == 'BF16_VALID_PREFIX_EXACT_NUMERIC':
        assert len(entry['shape']) == 2 and 0 < entry['valid_rows'] <= entry['shape'][0]
        count = entry['valid_rows'] * entry['shape'][1]
    else:
        assert entry['kind'] == 'WHOLE_SAVED_BF16_COMPONENT_EXACT'
        count = math.prod(entry['shape'])
    a, b = bf16_array(left[:2 * count]), bf16_array(right[:2 * count])
    nonfinite_left = sum((v & 0x7f80) == 0x7f80 for v in a)
    nonfinite_right = sum((v & 0x7f80) == 0x7f80 for v in b)
    assert nonfinite_left == nonfinite_right == 0, 'nonfinite selected numeric values'
    max_abs = 0.0
    mismatch = bit_different = 0
    first = None
    for i, (x, y) in enumerate(zip(a, b)):
        if x == y:
            continue
        bit_different += 1
        fx, fy = bf16_float(x), bf16_float(y)
        delta = abs(fx - fy)
        max_abs = max(max_abs, delta)
        if delta > entry['atol'] + entry['rtol'] * abs(fy):
            mismatch += 1
            if first is None:
                first = dict(flat_index=i, left=fx, right=fy, absolute_difference=delta)
    assert mismatch == 0, 'original tolerance violated in selected excerpt'
    return dict(name=entry['name'], status='PASS_SELECTED_EXCERPT_COMPARISON_ONLY',
                dtype=lref['dtype'], stored_shape=lref['shape'], compared_elements=count,
                valid_rows=entry.get('valid_rows'), atol=entry['atol'], rtol=entry['rtol'],
                max_abs=max_abs, outside_tolerance=mismatch, different_bf16_bits=bit_different,
                nonfinite_left=nonfinite_left, nonfinite_right=nonfinite_right,
                first_bad=first, original_graph_reference_same_content_address=entry['left'] == entry['right'])

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=HERE / 'recompute-result.json')
    args = parser.parse_args()
    index_path = HERE / 'index.json'
    index_data = index_path.read_bytes()
    index = json.loads(index_data)
    assert index['label'] == 'EXCERPT_NOT_COMPLETE_ARTIFACT_NOT_FULL_CHECKER_INPUT'
    assert index['source_sha'] == SHA and index['arm'] == 'ON' and index['rank'] == 0
    checked_files = []
    for row in index['copied_originals']:
        data = local_path(row['local_path']).read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256'], row['local_path']
        checked_files.append(dict(path=row['local_path'], bytes=len(data), sha256=digest(data)))
    root = json.loads((HERE / 'original_metadata/numeric-reference.json').read_text())
    assert root['header']['identity']['source_sha'] == SHA
    assert root['header']['tolerance'] == index['tolerance'] == {'atol': 0.0, 'rtol': 0.0}
    for i, step in enumerate((0, 10)):
        selected = index['samples'][i]
        data = local_path(selected['original_metadata']).read_bytes()
        bound = root['samples'][selected['original_sample']]
        assert digest(data) == selected['original_metadata_sha256'] == bound['sha256']
        assert len(data) == bound['bytes']
        original = decode_metadata(json.loads(data))
        assert original['status'] == 'PASS_SCOPED_CONTINUOUS'
        assert original['case_identity']['step'] == step and original['active'] == selected['active']
        assert original['descriptor'] == selected['descriptor']
        assert original['graph']['tensor_ref']['path'] == selected['graph']['tensor_ref']['path']
        assert original['reference']['tensor_ref']['path'] == selected['reference']['tensor_ref']['path']
        assert selected['valid_hidden_rows'] == original['active'] * root['header']['provenance']['method_contract']['draft_query']
    comparisons = [compare(index, item) for item in index['comparisons']]
    result = dict(status='PASS_SELECTED_EXCERPT_HASH_AND_NUMERIC_ONLY',
                  source_sha=SHA, rank=0, original_scenarios=[0, 10], arm='ON',
                  index_sha256=digest(index_data), hash_verified_files=len(checked_files),
                  hash_verified_original_bytes=sum(row['bytes'] for row in checked_files),
                  comparisons=comparisons, Target_comparison='NOT_INCLUDED_NOT_RECOMPUTED',
                  original_tolerance=index['tolerance'], dependency='Python3 standard library; no torch/PTA/CANN/NPU',
                  scope='Only two rank0 valid hidden prefixes, their staged-context hidden prefixes, and one saved K component pre-restore/post Graph-reference equality. Does not prove full KV write set, full Target, all16 ranks, ABA, normal reader, quality, performance or release. Complete joint originals remain authoritative.')
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))

if __name__ == '__main__':
    main()
