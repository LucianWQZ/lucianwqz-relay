#!/usr/bin/env python3
"""Single CPU-only Target48 join; disabled unless Root passes --execute."""
import argparse, datetime, hashlib, importlib.util, json, os, signal, subprocess, time
from pathlib import Path
BASE = Path(__file__).resolve().parents[1].parent
CONTROL = BASE / 'orchestration/integration_PR017_544_20261030T1750Z/C302_dspark_cp_subset017544'
OUT = Path(__file__).resolve().parent
SHA = '1fd6da87ae146cd87cff35bee9c9f0011372da04'
TREE = '787780c7a55bf0568a16590ad05ba805d53e9b5c'
TOOL_SHA = 'a6df26d0734d2711610b6570599399230c4d610a8d4099197970c9c7d04b0f0b'
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p, value):
    tmp = p.with_suffix(p.suffix + '.tmp'); tmp.write_text(json.dumps(value, indent=2) + '\n'); os.replace(tmp, p)
def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--execute', action='store_true'); args = parser.parse_args()
    if not args.execute: print('PREPARED_DISABLED_CPU_ONLY_NOT_EXECUTED'); return 2
    spec = importlib.util.spec_from_file_location('owned_c302_cpu_common', CONTROL / 'common_c302_dspark_cp20h.py')
    c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
    assert c.SHA == SHA and c.TREE == TREE and not (OUT / 'join-start.json').exists()
    arms = [BASE / 'raw' / ('C302_R8_GLM_DSpark_TP16_CP_return_0_10_2_' + arm + '_01_node140') for arm in ('OFF', 'ON')]
    for arm, raw in zip(('OFF', 'ON'), arms):
        assert (CONTROL / (arm + '-supervisor-exit.json')).is_file(), 'wait for whole arm supervisor terminal'
        e = json.loads((raw / 'execution.json').read_text())['execution']
        assert e['returncode'] == 0 and e['timeout'] is False and e['signal'] is None
        assert json.loads((raw / 'own_cleanup_exit_audit.json').read_text())['remaining_owned_pids'] == []
        assert json.loads((raw / 'lease_release.json').read_text())['status'] == 'RELEASED'
    tool = c.SOURCE / 'tools/p7x_graph_repair55_glm_cp_numeric.py'
    assert subprocess.check_output(['git', '-C', str(c.SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == SHA and digest(tool) == TOOL_SHA
    argv = [c.PYTHON, '-P', str(tool), 'join', '--glm-dspark-cp-return-subset']
    for arm, raw in zip(('off', 'on'), arms): argv += ['--' + arm + '-planned', str(raw / 'planned_case.json'), '--' + arm + '-execution', str(raw / 'execution.json')]
    argv += ['--output', str(OUT / 'C302_OFF_ON_Target48.json')]
    env = c.environment('C302_CPU_Target48_readonly_01'); env.update(TORCH_DEVICE_BACKEND_AUTOLOAD='0', ASCEND_RT_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2')
    cwd = env['MRV2_OWN_PROCESS_CWD']; started = time.time(); utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
    binding = json.loads((CONTROL / 'runtime-binding.placeholder.json').read_text())
    receipt = dict(kind='READONLY_CPU_JOIN_NOT_MODEL', wrapper_pid=os.getpid(), wrapper_start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19], argv=argv, started_at=utc(), timeout_seconds=3600, source_sha=SHA, source_tree=TREE, tool_sha256=digest(tool), runtime_manifest=binding['runtime_manifest'], runtime_manifest_sha256=digest(binding['runtime_manifest']), cwd=cwd, stdout=str(OUT / 'join.stdout.log'), stderr=str(OUT / 'join.stderr.log'), npu_deadline_applies=False)
    with (OUT / 'join.stdout.log').open('xb') as out, (OUT / 'join.stderr.log').open('xb') as err:
        p = subprocess.Popen(argv, env=env, cwd=cwd, stdout=out, stderr=err, start_new_session=True)
        receipt.update(pid=p.pid, process_start_ticks=Path('/proc', str(p.pid), 'stat').read_text().rsplit(')', 1)[1].split()[19]); write(OUT / 'join-start.json', receipt)
        timed_out = False
        try: rc = p.wait(timeout=3600)
        except subprocess.TimeoutExpired:
            timed_out = True; os.killpg(p.pid, signal.SIGTERM)
            try: rc = p.wait(timeout=15)
            except subprocess.TimeoutExpired: os.killpg(p.pid, signal.SIGKILL); rc = p.wait()
    receipt.update(returncode=rc, signal=-rc if rc < 0 else None, timeout=timed_out, elapsed_seconds=time.time()-started, ended_at=utc()); write(OUT / 'join-exit.json', receipt)
    return 124 if timed_out else rc
if __name__ == '__main__': raise SystemExit(main())
