# MRV2 持续开发查看入口

当前开发候选 **C12** `d15a510c2afba62b8a0e37aa574550852079fd13`（Host验证，未设备验证）；当前设备候选 **C8** `2c550f267484360802578f340429f95f95299e33`。只本地提交，没有发布/合并。public Graph Gate保持冻结。

先看：

1. [当前进展](journal/00_当前进展.md)：当前模型/进度、失败与下一步。
2. [持续开发阶段总结](reports/MRV2_持续开发阶段总结.md)：分项结论和明确支持范围。
3. [Profiling分析](reports/MRV2_Profiling分析.md)：真实正常路径采集及限制。

实时命令：

```sh
tail -f /mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/journal/progress.log
```

机器状态：[current_status.json](journal/current_status.json)。迭代记录：[时间线](journal/01_迭代时间线.md)。恢复：[RESUME](reports/RESUME.md) / [handoff](reports/NEXT_SESSION_HANDOFF.json)。完整实验与来源：[矩阵](reports/MRV2_实验矩阵与结论.csv) / [分项裁决](reports/ACCEPTANCE_VERDICTS.json)。

代码：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/work/vllm-ascend`。大raw：`/mnt/wenqing/mrv2_graph_server_dev/20261022T0640Z_C2_recovery`。存储绑定：[STORAGE_BINDING](state/STORAGE_BINDING.json)。

原预约截止 **2026-10-22 10:04:38 UTC / 北京18:04:38**；恢复不自动续期。截止后只离线分析，设备新实验需要新有效预约。旧C2检查点记录“无设备/未运行”已被本轮真实NPU证据更新，原检查点保留供溯源。

小型交付：[return](return/DOWNLOAD_MANIFEST.json)。大tensor、trace、完整flow表留服务器；bundle需精确Repair7基线，恢复说明见[提交与Bundle恢复](reports/04_提交与Bundle恢复_持续开发.md)。
