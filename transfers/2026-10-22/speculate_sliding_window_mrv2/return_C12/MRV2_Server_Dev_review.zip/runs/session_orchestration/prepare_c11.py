import json,shutil,subprocess,hashlib
from pathlib import Path
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');S=R/'candidates/C11_runtime/vllm-ascend';D=R/'candidates/C8_runtime/vllm-ascend';V=R/'candidates/C2_303ef7fe/vllm';RAW=Path('/mnt/wenqing/mrv2_graph_server_dev/20261022T0640Z_C2_recovery')
shutil.copytree(D/'vllm_ascend/_cann_ops_custom',S/'vllm_ascend/_cann_ops_custom',dirs_exist_ok=True)
for n in ['_build_info.py','libvllm_ascend_kernels.so','vllm_ascend_C.cpython-311-aarch64-linux-gnu.so']:
 shutil.copy2(D/'vllm_ascend'/n,S/'vllm_ascend'/n)
assert not subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True)
e=json.loads((R/'state/C8_HOST_EVIDENCE.json').read_text());p=R/'reports/C11_fixture_host_tests.log';e.append(dict(label='fixture_bootstrap',status='PASS',path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_sha='8bdc2e2f20ac8d71aecacfe8567ae695681a797b',scope='HOST_ONLY_62_PASSED_DEVICE_FIXTURE_PENDING'))
(R/'state/C11_HOST_EVIDENCE.json').write_text(json.dumps(e,indent=2)+'\n')
h=R/'runs/session_orchestration/admit_case_c8.py';s=h.read_text().replace('C8_runtime','C11_runtime').replace('C8_prepare_01','C11_prepare_01').replace('C8_campaign_01','C11_campaign_01').replace('admission_c8_attempt01','admission_c11_attempt01').replace('c8f9a4bbddf33bc4cc02fdfe39f6aad75c6cad4a','8bdc2e2f20ac8d71aecacfe8567ae695681a797b').replace('固定C8','固定C11').replace('固定 C8','固定 C11');(h.parent/'admit_case_c11.py').write_text(s)
print('C11 runtime and wrapper prepared')
