import json,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');RAW=Path('/mnt/wenqing/mrv2_graph_server_dev/20261022T0640Z_C2_recovery');P=json.loads((RAW/'C11_prepare_01/case-plan.json').read_text());log=R/'journal/progress.log';results=[]
for case in ['P0','C2','CONFIG','A0','A1','B0','LIFE','ABORT_after_replay','ABORT_after_update','ABORT_before_replay','ABORT_after_completion']:
 now=datetime.now(timezone.utc)
 if now>=datetime(2026,10,22,10,2,tzinfo=timezone.utc):
  with log.open('a') as f:f.write(now.isoformat()+'：不再启动新case；保留至少156秒至原设备授权截止，余项NOT_RUN。\n')
  break
 missing=[]
 for dep in P['cases'][case]['dependencies']:
  p=RAW/'C11_campaign_01'/dep/'runner-result.json'
  if not p.exists() or not json.loads(p.read_text()).get('dependency_satisfied'):missing.append(dep)
 if missing:
  results.append(dict(case=case,status='NOT_RUN_DEPENDENCY',missing=missing));continue
 a=['/usr/local/python3.11.10/bin/python',str(R/'runs/session_orchestration/admit_case_c11.py'),'--case',case]
 start=time.time_ns();x=subprocess.run(a);results.append(dict(case=case,argv=a,returncode=x.returncode,start_ns=start,end_ns=time.time_ns()))
 (R/'state/C11_CASE_CHAIN.json').write_text(json.dumps(results,indent=2)+'\n')
