import json,os,subprocess
from pathlib import Path
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');S=R/'candidates/C6_1c920c36/vllm-ascend';B=Path('/mnt/wenqing/mrv2_graph_server_dev/20261022T0640Z_C2_recovery/C6_prepare_04b')
for p in sorted(B.glob('PROFILE_*_normal')):
 t=list((p/'trace').rglob('trace_view.json'));o=R/'reports/profiling_C6_short'/p.name;o.mkdir(parents=True,exist_ok=True)
 if len(t)!=1 or (o/'flow-analysis-module.json').exists():continue
 a=['/usr/local/python3.11.10/bin/python','-m','tools.p7x_graph_repair6_trace','--trace',str(t[0]),'--output',str(o/'flow-analysis-module.json')]
 with (o/'parser_module.log').open('w') as f:x=subprocess.run(a,cwd=S,env=dict(os.environ,PYTHONPATH=str(S)),stdout=f,stderr=subprocess.STDOUT,timeout=180)
 (o/'parser_execution.json').write_text(json.dumps(dict(argv=a,returncode=x.returncode,cwd=str(S)),indent=2)+'\n')
 if x.returncode==0:
  d=json.loads((o/'flow-analysis-module.json').read_text());(o/'typical_replay_fragment.json').write_text(json.dumps(dict(flow_counts=d['flow_counts'],coverage=d['coverage'],replays=d['replays'][:2]),indent=2)+'\n')
 print(p.name,x.returncode)
