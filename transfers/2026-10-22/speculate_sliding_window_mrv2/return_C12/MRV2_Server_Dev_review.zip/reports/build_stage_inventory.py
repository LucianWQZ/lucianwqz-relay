"""Index completed attempts without turning exit zero into acceptance."""
import csv
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
RAW = Path('/mnt/wenqing/mrv2_graph_server_dev/20261022T0640Z_C2_recovery')


def load(path):
    return json.loads(path.read_text())


def main():
    rows = []
    for path in sorted(RAW.glob('admission*/*/attempt*/execution.json')):
        document = load(path)
        if 'runner' not in document:
            continue
        case = document['case']
        runner = document['runner']
        result_path = Path(document['runner_result'])
        result = load(result_path) if result_path.exists() else {}
        plan_path = path.with_name('admitted-plan.json')
        plan = load(plan_path) if plan_path.exists() else {}
        expected = plan.get('cases', {}).get(case, {})
        artifact_root = Path(expected.get('outputs', path.parent))
        campaign_path = artifact_root/'campaign.json'
        campaign = load(campaign_path) if campaign_path.exists() else {}
        first = campaign.get('exception_message')
        if not first:
            for name in ('numeric-joint.json', 'joint.json', 'profile-joint.json'):
                target = artifact_root/name
                if target.exists():
                    joined = load(target)
                    if joined.get('evidence_errors') or joined.get('error'):
                        first = str(joined.get('evidence_errors') or joined.get('error'))
                        break
        if not first and result.get('primary_failure'):
            failure = result['primary_failure']
            first = f"command {failure.get('command_index')} {failure.get('status')} rc={failure.get('returncode')}"
        if not result and runner['returncode']:
            first = 'Runner failed before durable runner-result; see runner.stderr.log'
        rows.append(dict(record_kind='ATTEMPT', case_id=case, source_sha=document['source_sha'],
                         source_tree=document['source_tree'], checker_sha=document['source_sha'],
                         profile=expected.get('capture_profile','CASE_ARGV'),
                         config_or_requests_hash=expected.get('requests_sha256','NOT_AVAILABLE'),
                         device_segment='node-39-101 / host Phy0 / logical npu:0 / TP1',
                         runner_pid=runner.get('pid','NOT_RECORDED'), model_pid=campaign.get('identity',{}).get('process_id','NOT_CREATED_OR_NOT_RECORDED'),
                         start_utc=datetime.fromtimestamp(runner['start_ns']/1e9,timezone.utc).isoformat(),
                         elapsed_seconds=round(runner.get('elapsed_seconds',(runner['end_ns']-runner['start_ns'])/1e9),3), returncode=runner['returncode'],
                         producer=result.get('producer_status','NOT_AVAILABLE'),
                         artifact=result.get('artifact_status','NOT_AVAILABLE'),
                         checker=result.get('acceptance_status','NOT_AVAILABLE'),
                         runner=result.get('status','MISSING_RESULT'), dependency_satisfied=result.get('dependency_satisfied',False),
                         first_cause=first or '', evidence=str(path), result_scope='CURRENT_SOURCE_ATTEMPT'))
    for candidate, sha, directory in [('C7','810b85a5b1d494fe83a686951ef1b6ecc5288c6d','reanalysis_C7_dtype_01'),
                                      ('C8','2c550f267484360802578f340429f95f95299e33','reanalysis_C8_contract_01'),
                                      ('C10','c8f9a4bbddf33bc4cc02fdfe39f6aad75c6cad4a','reanalysis_C10_full_01')]:
        path=ROOT/'reports'/directory/'numeric-joint.json'
        if not path.exists():
            continue
        result=load(path)
        row={key:'' for key in rows[0]}
        row.update(record_kind='READ_ONLY_REANALYSIS',case_id='C8_NUMERIC_TARGET4' if candidate=='C10' else 'C6_NUMERIC_SENTINEL',
                   source_sha='2c550f267484360802578f340429f95f95299e33' if candidate=='C10' else '1c920c3669b76f301ff9472650ceb0e842ccf03c',checker_sha=sha,profile='target4',
                   device_segment='C6 historical current-session Phy0 original artifacts',checker=result['status'],
                   first_cause=str(result.get('evidence_errors',[])),evidence=str(path),
                   result_scope='OLD_DEVICE_ARTIFACTS_NEW_CHECKER_REANALYSIS_NOT_NEW_NPU')
        rows.append(row)
    target_join=ROOT/'reports/reanalysis_C10_target4_01/target-join.json'
    if target_join.exists():
        result=load(target_join); row={key:'' for key in rows[0]}
        row.update(record_kind='READ_ONLY_TARGET_JOIN',case_id='C8_TARGET4_OFF_vs_NUMERIC_TARGET4_ON',source_sha='2c550f267484360802578f340429f95f95299e33',checker_sha='c8f9a4bbddf33bc4cc02fdfe39f6aad75c6cad4a',profile='target4',device_segment='node-39-101 / Phy0 / npu:0 / TP1; independent admission receipts',checker=result['status'],evidence=str(target_join),result_scope='ORIGINAL_C8_ARMS_C10_JOIN_NOT_C10_NPU')
        rows.append(row)
    target=ROOT/'reports/MRV2_实验矩阵与结论.csv'
    historical=ROOT/'reports/MRV2_实验矩阵_C2历史.csv'
    if target.exists() and not historical.exists():
        shutil.copy2(target,historical)
    with target.open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    state=ROOT/'state/EXPERIMENTS.jsonl'
    known=set()
    if state.exists():
        for line in state.read_text().splitlines():
            try:known.add(json.loads(line).get('evidence'))
            except (json.JSONDecodeError,AttributeError):pass
    with state.open('a') as stream:
        for row in rows:
            if row['evidence'] not in known:
                stream.write(json.dumps(row,ensure_ascii=False)+'\n')
    campaigns=[]
    for path in RAW.glob('*prepare*/*/campaign.json'):
        document=load(path)
        identity=document.get('identity',{})
        if identity.get('process_id'):
            campaigns.append(dict(identity=identity,status=document.get('status'),startup_complete=document.get('startup_complete'),
                                  exception_type=document.get('exception_type'),exception_message=document.get('exception_message'),path=str(path)))
    index=dict(updated_at=datetime.now(timezone.utc).isoformat(),completed_attempt_records=len(rows),
               formal_model_campaigns=len(campaigns),campaigns=campaigns,source_run_root=str(RAW),
               scope='Model process created; expected A1 rejection is counted as a startup attempt, never as successful initialization')
    (ROOT/'reports/MODEL_CAMPAIGN_INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(matrix=str(target),rows=len(rows),formal_model_campaigns=len(campaigns))))


if __name__ == '__main__':
    main()
