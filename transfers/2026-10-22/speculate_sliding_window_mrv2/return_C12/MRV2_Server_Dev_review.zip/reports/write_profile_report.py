import json
from pathlib import Path
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');d=json.loads((R/'reports/MRV2_Profiling_Summary.json').read_text());C=d['cases']
s=['# MRV2 正常路径 Profiling 分析','', '源码：C6 `1c920c3669b76f301ff9472650ceb0e842ccf03c`，TP1，node-39-101 / Phy0 / logical npu:0。C7–C10仅改检查器与测试，以下仍是C6采集，不能合并成新SHA的设备PASS。','', '原始根：`/mnt/wenqing/mrv2_graph_server_dev/20261022T0640Z_C2_recovery`。以下 `C6_prepare_04b/...` 均相对此根；报告脚本和联合检查路径可据此复查。','', '## 采集和有效工作量','', '已完成 OFF/ON × short/long 四个正常采集和四个无profiler控制。全部初始化/capture与warmup在采集前；采集覆盖有界请求阶段。使用当前torch_npu.profiler，不叠加msprof、不改业务is_profile；record_shapes/stack/memory关闭。重型observer、完整Target dump、连续数值reference、逐代LIFE同步关闭。每组仅一次campaign，不能作统计显著性或加速承诺。','', '| case | requests / generated tokens | Draft / Target Graph calls | request groups elapsed ms | runtime最大S列 |','|---|---:|---:|---:|---:|']
for n,c in C.items():
 crop=c['actual_window_crop']['max_source_start_column'];s.append(f"| {n} | {c['completed_requests']} / {c['generated_tokens']} | {c['observed_draft_graph_replays']} / {c['observed_target_graph_replays']} | {c['active_group_elapsed_ms']:.3f} | {crop} |")
s+=['', '证据：每个case的 `campaign.json:outputs/initialization_seconds/warmup` 与 `profile.json:groups/calls/profiler_enabled/profile_configuration`；汇总对应 `MRV2_Profiling_Summary.json:cases`。elapsed为各独立请求组Host区间之和，不含初始化；kernel duration另算，不混为端到端。short有3个active请求组，long另含边界长度请求；详细prompt token长度、group label和时间均在汇总，不凭文本字符数估算context。','', 'ON-long `profile.json:calls[].window_descriptors[].source_start_column` 最大8，对应S=1024 token，直接确认发生真实Window裁剪；short最大0。descriptor是已有不可变Host状态，无额外D2H或设备query。OFF没有Window descriptor，标NOT_AVAILABLE/不适用。Target verification总数和acceptance未导出，均为NOT_AVAILABLE，不能拿Target Graph calls替代所有验证。','', '## A–C：Graph、FIA 与 Host/task/stream 关联','', '正常Graph replay有实际 `Draft_REPLAY_SUBMIT`/`Target_REPLAY_SUBMIT` Host范围及native MODEL_EXECUTE导出。short各21次Draft/12次Target，long各47/30。Host Target/Draft范围可区分，FIA名称只识别算子族，不能凭同名、shape或数量关联真实层/代际。','', '完整flow解析使用固定C6 `python -m tools.p7x_graph_repair6_trace`，避免直接脚本触发stdlib bisect影子模块问题。实际命令/退出码见 `profiling_C6_short/<case>/parser_execution.json`，典型片段见同目录 `typical_replay_fragment.json`。完整flow表留服务器，不进小包。','']
for n,c in C.items():
 if not c['profiler_enabled']:continue
 t=c['trace'];f=t['flow_analysis'];tab=t['task_table'];s.append(f"- `{n}`：flow {f.get('counts') if isinstance(f,dict) else f}；{f.get('coverage') if isinstance(f,dict) else ''}；task rows={tab['rows']}，FIA命名kernel={tab['fia_named_kernel_count']}。证据 `{c['evidence_relative_path']}/trace/.../task_time.csv`、上述完整flow表。")
s+=['', '直接replay flow关联数为0；父 replay+UPDATE 范围有关联，但无法将二者device task拆开，因此UPDATE生效代际、最后consumer仍UNRESOLVED。关联依据flow ID及其方向、pid/tid、范围包含关系；不以相邻行为证据。task表的(Device_id,stream_id,task_id)有重复，必须带时间与模型上下文，不能单独当全局唯一键。Host monotonic_ns与trace导出时间域不直接相减。','', '## D：四个Host子范围','', '| case | materialize p50/p95 ms | metadata p50/p95 | UPDATE p50/p95 | retire p50/p95 |','|---|---:|---:|---:|---:|']
for n,c in C.items():
 if not c['profiler_enabled']:continue
 vals=[]
 for k in ['Draft_materialize','Draft_metadata_bind','Draft_UPDATE_CALL','Draft_retire_host']:
  x=c['host_statistics'].get(k);vals.append(f"{x['p50_ms']:.4f}/{x['p95_ms']:.4f}" if x else 'NOT_APPLICABLE')
 s.append('| '+n+' | '+' | '.join(vals)+' |')
s+=['', '证据：`profile.json:host_statistics/host_subrange_coverage`。ON四范围short各21、long各47，OFF materialize/retire不适用。范围嵌套，不把各sum相加当elapsed。ON-long materialize均值约11.90ms、p50约9.33ms，是明确的Host时间候选；源码 `_snapshot_prepared_draft_seq_lens` 含既有CPU拷贝，但trace同线程包含法未归入该range的copy/sync，当前不能将全部开销归因D2H。保留精确长度校验，不能用upper_bound替代来追求性能。','', '## E–F：拷贝、等待、设备空档与重叠','']
for n in ['PROFILE_OFF_long_normal','PROFILE_ON_long_normal']:
 c=C[n];t=c['trace'];s.append('### '+n);s.append('')
 for k,v in t['selected_event_statistics'].items():
  if isinstance(v,dict):s.append(f"- `{k}`：count={v['count']}，duration sum={v['summed_duration_us']:.3f}us，中位数={v['median_duration_us']:.3f}us。")
  else:s.append(f'- `{k}`：{v}。')
 tab=t['task_table'];s+=['',f"命名kernel sum={tab['summed_named_kernel_duration_us']:.3f}us；这些kernel区间union={tab['named_kernel_interval_union_us']:.3f}us；首尾span={tab['named_kernel_span_us']:.3f}us。以上是所选kernel集合的统计，不代表所有设备活动。",'']
s+=['证据：`trace_view.json`中显式方向label与`task_time.csv`实际start/stop/stream；解析脚本`analyze_profile_campaign.py`。H2D/D2H统计为导出API范围，MEMCPY_ASYNC并非全都能确定方向。显式D2D方向未导出，填NOT_AVAILABLE。wait/sync包含Host与设备不同类别，sum会重叠，不能直接相加成停顿。命名kernel间空隙不等于全设备idle；跨stream数据缺少完备任务语义，设备全空档及重叠效益为NOT_AVAILABLE。','', '## G–H：可比单位工作与采集影响','']
for x in d['profiler_controls']:
 s.append('- '+str(x))
s+=['', '每组requests/tokens/Graph calls计数相同，可展示每generated token的描述性耗时（汇总`per_generated_token_ms`）。但没有acceptance和全部Target verification，不宣称完全相同有效工作。OFF-long控制5152.6ms而采集1712.8ms，明显存在单次运行波动；不能由此称profiler加速，也不能直接作Window加速率。ON-long控制1743.3ms、采集1906.6ms，同样只描述此两次运行。未采用诊断同步trace估计正常性能。初始化/capture、prefill和decode的精确device时间拆分仍NOT_AVAILABLE：目前请求组包含prefill+decode，Host Graph范围主要覆盖decode，缺完整逐阶段device归属。','', '## I：仍不能证明的事项','', '1. UPDATE(N)究竟影响哪次replay；父范围flow不能拆分参数更新与执行。','2. backing最后真实device consumer完成、下一代同址覆盖的安全时点。','3. task内部operand地址、KV实际物理read-set；profiler不暴露这些字段。','4. 不同clock domain的精确跨域时差与完整设备idle。','', '这些缺口已写入DECISION_QUEUE.md，需平台维护者合同或审定native证据方案。本次真实正常采集与分析完成，不代表production Graph正式支持；public Graph Gate保持冻结。','']
(R/'reports/MRV2_Profiling分析.md').write_text('\n'.join(s))
