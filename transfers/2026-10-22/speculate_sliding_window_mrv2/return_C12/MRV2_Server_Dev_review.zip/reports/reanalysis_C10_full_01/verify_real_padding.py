import copy,json
from pathlib import Path
from tools.p7x_graph_repair6_storage import CollectionReader
from tools.p7x_graph_repair6_numeric_check import validate_sample
from tools.p7x_graph_repair5_target import case_plan
import importlib.util
root=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
raw=Path('/mnt/wenqing/mrv2_graph_server_dev/20261022T0640Z_C2_recovery/C8_prepare_01/NUMERIC_TARGET4')
r=CollectionReader(raw/'numeric-reference.json');s=r.record(10)
p=root/'candidates/C8_runtime/vllm-ascend/tools/p7x_graph_repair6_numeric_check.py'
spec=importlib.util.spec_from_file_location('old_c8_check',p);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
result=dict(producer_commit='2c550f267484360802578f340429f95f95299e33',checker_commit='c8f9a4bbddf33bc4cc02fdfe39f6aad75c6cad4a',scope='READ_ONLY_ORIGINAL_C8_SAMPLE',input_query=s['inputs']['query_start_loc'].tolist(),FIA_queries={n:m['query'] for n,m in s['actual_metadata'].items()},negative_checks={})
try:
 old.validate_sample(s,r.header,case_plan('target4')[10]);raise AssertionError('old checker accepted')
except ValueError as e:result['old_checker_rejection']=str(e)
checked=validate_sample(s,r.header,case_plan('target4')[10])
result['new_checker']={k:checked[k] for k in ('status','metrics','kv_equal')}
for damage in ('padded_input_both_arms','padded_FIA_both_arms'):
 b=copy.deepcopy(s)
 if damage=='padded_input_both_arms':
  for f in ('inputs','reference_inputs'):b[f]['query_start_loc'][-1]=28
 else:
  for f in ('actual_metadata','reference_metadata'):
   for m in b[f].values():m['query'][-1]=21
 try:
  validate_sample(b,r.header,case_plan('target4')[10]);raise AssertionError('corruption accepted')
 except ValueError as e:result['negative_checks'][damage]=dict(status='REJECTED',reason=str(e))
Path(__file__).with_name('real_padding_regression.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
