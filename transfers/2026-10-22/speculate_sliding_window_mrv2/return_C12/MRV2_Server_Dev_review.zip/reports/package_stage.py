"""Small review package; raw tensors/profiles remain server-only."""
import hashlib,json,shutil,zipfile
from pathlib import Path
from datetime import datetime,timezone
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');RAW=Path('/mnt/wenqing/mrv2_graph_server_dev/20261022T0640Z_C2_recovery');O=R/'return';O.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4<<20),b''):h.update(b)
 return h.hexdigest()
def entry(p,scope):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p),transfer_scope=scope)
files=['MRV2_持续开发阶段总结.md','MRV2_五小时开发总结.md','MRV2_实验矩阵与结论.csv','MRV2_Profiling分析.md','MRV2_Profiling_Summary.json','NEXT_SESSION_HANDOFF.json','RESUME.md','DECISION_QUEUE.md','ACCEPTANCE_VERDICTS.json','ACCEPTANCE_VERDICTS.csv','MODEL_CAMPAIGN_INDEX.json','REFERENCE_VALIDATION.json','执行环境恢复说明.md','存储与运行路径说明.md','C7_dtype修复与复核.md','C10_真实padding合同与复核.md','正常生命周期源码审计.md','04_提交与Bundle恢复_持续开发.md','01_接收与源码身份复核.md']
checkpoint=O/'checkpoint_C2_0547';checkpoint.mkdir(exist_ok=True)
for n in ['MRV2_Server_Dev_review.zip','DOWNLOAD_MANIFEST.json','MRV2_五小时开发总结.md','NEXT_SESSION_HANDOFF.json','RESUME.md']:
 p=O/n
 if p.exists() and not (checkpoint/n).exists():shutil.copy2(p,checkpoint/n)
for n in files:
 p=R/'reports'/n
 if p.exists():shutil.copy2(p,O/n)
shutil.copy2(R/'state/STORAGE_BINDING.json',O/'STORAGE_BINDING.json')
# Small file hashes and every raw path/size; large data use the durable stores and trace hashes.
raw_index=[]
for base in [*RAW.glob('*prepare*'),*RAW.glob('admission*')]:
 for p in sorted(base.rglob('*')):
  if not p.is_file():continue
  size=p.stat().st_size;raw_index.append(dict(path=str(p.relative_to(RAW)),bytes=size,sha256=sha(p) if size<=2<<20 else None,large_hash_source='tensor store references / MRV2_Profiling_Summary trace SHA256' if size>2<<20 else None))
idx=dict(raw_root=str(RAW),files=raw_index,total_bytes=sum(x['bytes'] for x in raw_index),scope='No cache/tmp/model directories; large raw retained server-only; null SHA is NOT hash verification')
(R/'reports/RAW_ARTIFACT_INDEX.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n');shutil.copy2(R/'reports/RAW_ARTIFACT_INDEX.json',O/'RAW_ARTIFACT_INDEX.json')
selected={}
def add(p,n=None):
 if p.is_file():selected[n or str(p.relative_to(R))]=p
for n in files+['STORAGE_BINDING.json','RAW_ARTIFACT_INDEX.json','MRV2_C12_local_commits.bundle','COMMIT_LIST.txt','C12_vs_Repair7.patch']:
 add(O/n,'delivery/'+n)
for pattern in ['reports/*host_tests.log','reports/reanalysis_C7_dtype_01/*.json','reports/reanalysis_C8_contract_01/*.json','reports/reanalysis_C10*/*.json','reports/reanalysis_C10*/*.py','reports/profiling_C6_short/*/native_flow_excerpt.json','reports/profiling_C6_short/*/typical_replay_fragment.json','reports/profiling_C6_short/*/parser_execution.json','reports/*profile*.py','reports/analyze_profile_campaign.py','reports/build_stage_inventory.py','reports/build_stage_summary.py','reports/package_stage.py','START_HERE.md','journal/*.md','journal/current_status.json','journal/progress.log','state/*C10*.json','state/*C11*.json','state/*C12*.json','state/RECEIVE_AUDIT.json','state/C8_HOST_EVIDENCE.json','state/C2_HOST_EVIDENCE.json','runs/C2_303ef7fe/*host.log','state/C8_WORKER_LIVE_PROVENANCE.json','state/SESSION_STATE.json','state/USER_AUTHORIZATION_RECORD.json','state/FINAL_PROCESS_AUDIT.json','state/FINAL_NPU_SMI.txt','state/TARGET4_OFF_RESOURCE_BUDGET.json','state/STORAGE_BINDING.json','state/CANDIDATES.jsonl','runs/session_orchestration/*.py']:
 for p in R.glob(pattern):add(p)
# External evidence: identities, outcomes and per-sample manifests, no tensor chunks or trace payload.
for base in [RAW/'C8_prepare_01',RAW/'C8_campaign_01',RAW/'admission_c8_attempt01',RAW/'C11_prepare_01',RAW/'C11_campaign_01',RAW/'admission_c11_attempt01',RAW/'C6_prepare_04b',RAW/'C6_campaign_04']:
 if not base.exists():continue
 for p in base.rglob('*'):
  if not p.is_file() or p.stat().st_size>2<<20:continue
  if any(part in ('controlled-target-tensors','numeric-reference-tensors','trace') for part in p.parts):continue
  if p.suffix in ('.json','.log','.txt'):
   if p.name.startswith('npu-smi-heartbeat'):continue
   add(p,'server_evidence/'+str(p.relative_to(RAW)))
for p in [RAW/'C6_RUNTIME_OVERLAY_MANIFEST.json',RAW/'probe_phy0_01/probe_result.json',RAW/'probe_phy0_01/npu_smi_06.txt']:add(p,'server_evidence/'+str(p.relative_to(RAW)))
index=[dict(member=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(selected.items())]
zip_path=O/'MRV2_Server_Dev_review.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(selected.items()):z.write(p,n)
 z.writestr('PACKAGE_INDEX.json',json.dumps(index,ensure_ascii=False,indent=2)+'\n')
assert zip_path.stat().st_size<20<<20,zip_path.stat().st_size
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 for n in z.namelist():
  if n.endswith('.json'):json.loads(z.read(n))
 required=['delivery/'+n for n in files[:8]]
 assert all(n in z.namelist() for n in required)
 validation=dict(checked_at=datetime.now(timezone.utc).isoformat(),status='SERVER_SELF_CHECK_PASSED_NOT_USER_RECEIPT',zip=entry(zip_path,'CHAT_SUITABLE'),members=len(z.namelist()),crc='PASS',required_json='PARSED',member_hashes_verified=True)
 for item in index:assert hashlib.sha256(z.read(item['member'])).hexdigest()==item['sha256']
(O/'REVIEW_ZIP_VALIDATION.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
manifest=dict(generated_at=datetime.now(timezone.utc).isoformat(),server_self_check_only=True,delivery_root=str(O),files=[entry(O/n,'CHAT_SUITABLE') for n in files+['STORAGE_BINDING.json','RAW_ARTIFACT_INDEX.json','MRV2_C12_local_commits.bundle','COMMIT_LIST.txt','C12_vs_Repair7.patch','MRV2_Server_Dev_review.zip','REVIEW_ZIP_VALIDATION.json'] if (O/n).exists()],server_only=dict(raw_root=str(RAW),index=str(O/'RAW_ARTIFACT_INDEX.json'),excluded='tensor chunks, profiler raw/trace/DB/CSV, full flow association tables, runtime binaries, models, old archive'),no_credentials_or_models_in_package=True)
(O/'DOWNLOAD_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(O/'DOWNLOAD_MANIFEST.sha256').write_text(sha(O/'DOWNLOAD_MANIFEST.json')+'  DOWNLOAD_MANIFEST.json\n')
print(json.dumps(validation,ensure_ascii=False));print(json.dumps(entry(O/'DOWNLOAD_MANIFEST.json','CHAT_SUITABLE')))
