# 待决事项

## 公开中转仓库

- 需要谁决定：仓库所有者/用户。
- 问题：接收报告称 `LucianWQZ/private-file-relay` 实际为 public。
- 证据：接收目录 `MRV2_服务器资料接收报告.md`；`state/RECEIVE_AUDIT.json` 已核对 transfer release 身份，公开状态沿用接收报告所见。
- 建议：所有者确认并处理可见性；本轮不上传新增日志、模型、内部路径清单或原始实验包。
- 不决定阻塞：向该仓库传递新材料。
- 可继续：服务器本地源码开发与设备验证。

## 当前执行容器的 NPU 节点与映射

- 需要谁决定：平台/容器提供方。用户本轮已授权 Phy-ID 0–15，其中 0–7 为优先范围；无需再次询问相同授权。
- 具体问题：容器 `/dev` 未提供 `/dev/davinci*`，`npu-smi info`/`info -m` 初始化失败（-8005），无法核对逻辑设备至宿主 Phy-ID 或运行 committed probe。
- 证据：`runs/host_baseline_01/device-inspect.json`，本轮 boot ID、容器 cgroup 与设备节点清单保存在同一 Host 基线记录；历史 campaign 的 `env_repair6.sh` 只设置环境变量，aisbench 是现有服务的压测客户端。
- 建议：平台提供可见授权 NPU 节点且可核对物理映射的执行容器；重新进行 inspect → probe → BIND_DEVICE → 单 case。不得以旧环境的 `npu:0=Phy-ID8` 代入当前容器。
- 不决定阻塞：真实 CONFIG/模型启动、连续数值、生命周期、profiling 及多卡设备验收。
- 可继续：精确源码、Host 反例与修复、固定本地候选、接收复核、代码与平台 API 审计、可恢复交接。

## UPDATE 代际与 backing 最后消费合同

- 需要谁决定：torch_npu/CANN Graph API 维护方与项目验收负责人。
- 具体问题：`graph_task_update_begin/end` 与 `ExternalEvent` 的已安装版本接口文档没有给出 UPDATE(N) 对哪次 replay 生效、设备最后消费者完成或 backing 可覆盖的可引用合同。
- 证据：`state/PROFILE_CAPABILITY.json` 中本机 2.10.0.post4 API 签名和文档；Repair6 历史 trace 只能作为定位参考，当前没有新设备 trace。
- 建议：在设备环境恢复后做有区分性的代际/覆写实验，同时请平台确认 native 部分提交、完成事件与 backing 生命周期语义；不能用 Python return 或进程退出替代完成证明。
- 不决定阻塞：正常异步 backing 安全复用与正式 Graph 验收。
- 可继续：异常路径保守隔离、Host 反例、诊断接口与正常 profiling 计划。

## 正常 Graph 成功路径的 lease 退休时机

- 需要谁决定：项目 Graph 设计负责人及 torch_npu/CANN Graph API 维护方。
- 具体问题：现源码的 Graph proposal scope 成功后调用 `retire_generation`；若 lease 仍是 `ACQUIRED`，`_DraftWindowLeasePool.retire` 立即 `workspace.reset`，未绑定实际最后 reader 的 completion token。`record_parallel_graph_retirement` 明确只记 Host 退休。这条路径的正常 backing 复用安全性尚无证明。
- 证据：本轮源码 `vllm_ascend/worker/v2/spec_decode/draft_window_eager.py` 的 `_draft_window_proposal_scope`、`draft_window.py` 的 `_DraftWindowLeasePool.retire/_finish_retirement` 和 `draft_window_graph_characterization.py` 的 `record_parallel_graph_retirement`；本轮源码审计记录将在报告中列明精确行号。
- 建议：先在可用设备上取得 UPDATE/replay/consumer 的真实 stream、event 和代际关系，并获得完成语义合同；若无法建立正确异步 completion token，考虑显式串行诊断路径，同时继续冻结正常 Graph 支持。
- 不决定阻塞：正常异步 backing 复用、正常路径性能结论及 production Graph 审查。
- 可继续：异常路径隔离的 Host 验证、实际配置路径和 profiler 能力预检。

## 共享 run 分区水位

- 需要谁决定：平台/存储资源负责方与下一轮实验负责人。
- 具体问题：NFS run 根余量从接管时约 1.4 TiB 降至 05:45 的约 317 GiB，低于本轮预设 500 GiB 水位；`/mnt/wenqing` 本地 ext4 仅约 21 GiB。
- 证据：`state/PATH_BINDING.json`、`state/RESOURCE_PREFLIGHT.json`、`journal/progress.log`。
- 建议：大型 Target tensor/trace 采集前确认新鲜空间、HBM、单样本 geometry 与临时峰值预算，必要时由平台提供合适的独立存储；不删除旧输出或他人文件。
- 不决定阻塞：新的大型数值/Target/profiling 原始产物。
- 可继续：小型报告、源码审查、现有证据分析和后续设备准入设计。

## 候选运行时二进制来源

- 需要谁决定：项目构建/运行环境负责人；可在具设备的固定候选预检中验证。
- 具体问题：C2 checkout 的 `_build_info.py` 与两个 `.so` 是从已安装 vllm-ascend 0.23.0rc2.dev141 复制的忽略生成物；源码 commit 是本地 Repair7 后裔。当前无设备，不能确认 ABI 和实际 worker 导入。
- 证据：`state/C2_CANDIDATE.json` 的 donor 路径/哈希；`state/C1_IMPORT_PROVENANCE.json` 和 `runs/C1_949afbd07/host_preview_01/import_trace.log`。
- 建议：设备可用后先核对 worker 及子进程的 Python 文件和关键扩展 SHA/路径，必要时用该 pinned 栈重建二进制或给出兼容证据；不得把主进程 `__file__` 当作 worker 证明。
- 不决定阻塞：模型启动与设备验收来源裁决。
- 可继续：Host schema、clean commit/tree、模型文件和本地准入合同核对。
