# Graph 异常路径修复与剩余合同

production 修复首先提交为 C1 `949afbd07c21133cd76cef43365a700cb46de3fb`，tree `9fd864d170666b510eeeac701c01854f0f017202`，基于已发布 Repair7 `7a9f4aae`；最新本地候选 C2 `303ef7fe117d372d5f9463d3d79b90e56b9e695d` 继承该修复并增加本地准入工具。两者均 `REMOTE_PUBLICATION=NOT_PERFORMED`、`DEVICE_VALIDATION=NOT_RUN`。production 变更原文为 `C1_quarantine_change.patch`。

## 首因与修复

旧 Graph proposal 在异常退出时调用 `abort_generation`，该调用经 lease pool 的 `_finish_retirement` 清零 workspace。若 `run_fullgraph`/UPDATE 在抛错前已部分提交，Python 清理会写入设备可能仍读的 backing。修复前 Host 反例 `runs/host_baseline_01/quarantine_red.log` 失败，显示 `workspace.bound_identity` 已变成 `None`。

现在 Graph 异常且已有 live inputs 时，`draft_window_eager.py:369-375` 先标记 `graph_submission_uncertain`，调用 `draft_window.py:2196` 的 `quarantine_generation`。此方法只丢弃 Host metadata，保留 lease 和 workspace 内容；materialize、retire、poll、abort 和新的 proposal 拒绝复用。诊断 driver `tools/p7x_graph_repair2.py:1273` 识别标记并以 74 退出隔离子进程，不进入正常 engine teardown。这是保守 Host 隔离，不声称 native work 已完成或可安全恢复。

Host 证据：`quarantine_green.log` 75 passed，`quarantine_driver.log` 31 passed，最终受影响 3 项 `quarantine_final.log` passed；`related_regression.log` 为 950 passed、2 failed。那两项是上游 AST drift guard，在干净 Repair7 checkout 单独复测同样失败，见 `baseline_drift_guards.log`，因此是既有基线失败而非 C1 引入。`git diff --check` 与 compileall 通过。真实 NPU 最小反例尚未运行。

## 正常成功路径仍未闭环

`draft_window_eager.py:361` 在 Graph proposal 成功后直接 `retire_generation`；`draft_window.py:1964` 在 lease 为 `ACQUIRED` 时立即调用 `_finish_retirement`，其中 `draft_window.py:2001` 会 `workspace.reset`。`draft_window_graph_characterization.py:1290` 的退休记录明确写明只是 Host proposal owner 退休，不能证明设备完成。此处没有绑定实际最后 reader 的 completion token。现有源码和已安装 torch_npu API 不能证明 UPDATE(N) 的生效代际、最后设备消费者、同址 backing 下代复用时机、task 内部 operand 或 physical read-set。不能以 proposal/UPDATE/Python return 或进程退出填补。

当前 C1 只关闭“已发生异常且 live inputs 可识别时，Host 清理立即改写 backing”的明确风险；正常成功路径与未知 native 部分提交的设备语义仍需实际 NPU 区分实验及平台合同。平台若无法给出异步完成依据，需要定义隔离/串行诊断方案及其性能边界；不得据此宣布正常重叠路径安全。

## 当前环境边界

本轮容器没有 `/dev/davinci*`，`npu-smi` 不可用，见 `state/DEVICE_ENVIRONMENT.json` 和 `runs/host_baseline_01/device-inspect.json`。未获得当前容器逻辑设备到 Phy-ID 的映射，未运行 probe、模型、数值、ABORT 或 profiler。C1 checkout 是干净 commit；Host import 的 `_build_info.py` 是从已安装包复制的忽略生成文件，哈希及来源另见 `state/C1_IMPORT_PROVENANCE.json`。实际模型 worker 的 import 来源尚未验证。
