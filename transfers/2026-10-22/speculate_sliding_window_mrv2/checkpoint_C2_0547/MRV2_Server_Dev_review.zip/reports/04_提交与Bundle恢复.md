# 本轮提交与 Bundle 恢复

开发分支：`dev/mrv2-graph-server-20261022T050438Z`。批准 Repair7 基线 `7a9f4aae1ebe5c5f3d4876ec9b49926949dfae14` / tree `6dd40a67a500480556068be8b6ebcd977e3cc3e8`，parent 为 Repair6 `fd0716c59562f64262672de12e4ae26259908d0b`。

1. C1 `949afbd07c21133cd76cef43365a700cb46de3fb` / tree `9fd864d170666b510eeeac701c01854f0f017202`：Graph 可能部分提交后的异常路径隔离 backing；对应 `C1_quarantine_change.patch`。Host 反例先红后绿，设备未验证。
2. C2 `303ef7fe117d372d5f9463d3d79b90e56b9e695d` / tree `a8cdb7a4793022e880bce1e7c591dd30b79f7a94`：为本地干净候选增加 Host prepare、逐 case bind 和 runner 校验；对应 `C2_local_admission_change.patch`。不把本地 commit 写成远端发布。

两个提交均为本地提交，`REMOTE_PUBLICATION=NOT_PERFORMED`；未 push、未创建 PR、未合入。最新候选 C2 包含 C1 production 修复。

`../return/MRV2_C2_from_Repair6.bundle` 包含 Repair7 与 C1/C2 两个本轮/基线后提交，以 `fd0716...` 为 prerequisite。已在独立验证仓库中 `git bundle verify`，fetch 后得到 C2 SHA/tree，见 `../state/BUNDLE_VERIFY_C2.json`。恢复时先取得精确 Repair6 parent checkout，再执行：

```sh
git -C /path/to/repair6-base bundle verify /path/to/MRV2_C2_from_Repair6.bundle
git -C /path/to/repair6-base fetch /path/to/MRV2_C2_from_Repair6.bundle refs/heads/dev/mrv2-graph-server-20261022T050438Z:refs/heads/dev/mrv2-graph-server-20261022T050438Z
git -C /path/to/repair6-base rev-parse dev/mrv2-graph-server-20261022T050438Z dev/mrv2-graph-server-20261022T050438Z^{tree}
```

预期 C2 SHA/tree 为上文数值。Bundle 只含 Git 跟踪源码；候选目录中忽略的 `_build_info.py`、两个安装包二进制扩展不在其中。其来源和 SHA256 须按 `../state/C1_CANDIDATE.json` 及后续 C2 manifest 重新核对；模型权重也不在 bundle。
