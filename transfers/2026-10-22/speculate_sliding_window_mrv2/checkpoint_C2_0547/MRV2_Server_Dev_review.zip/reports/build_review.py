#!/usr/bin/env python3
"""生成本轮小型审查包并逐成员 CRC/JSON/引用自检。"""
import csv
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
reports = root / 'reports'
returns = root / 'return'
returns.mkdir(exist_ok=True)
primary = [
    'MRV2_五小时开发总结.md',
    'MRV2_实验矩阵与结论.csv',
    'MRV2_Profiling分析.md',
    'MRV2_Profiling_Summary.json',
    'NEXT_SESSION_HANDOFF.json',
    'RESUME.md',
    '01_接收与源码身份复核.md',
    '02_Graph异常路径修复与剩余合同.md',
    '03_环境准入与本地候选.md',
    '04_提交与Bundle恢复.md',
    'C1_quarantine_change.patch',
    'C2_local_admission_change.patch',
]
for name in primary:
    shutil.copy2(reports / name, returns / name)

members = [
    'START_HERE.md',
    'journal/00_当前进展.md',
    'journal/01_迭代时间线.md',
    'journal/progress.log',
    'journal/DECISION_QUEUE.md',
    'state/SESSION_STATE.json',
    'state/PATH_BINDING.json',
    'state/CANDIDATES.jsonl',
    'state/EXPERIMENTS.jsonl',
    'state/RECEIVE_AUDIT.json',
    'state/DEVICE_ENVIRONMENT.json',
    'state/RESOURCE_PREFLIGHT.json',
    'state/FIXTURE_HASHES.json',
    'state/PROFILE_CAPABILITY.json',
    'state/C1_CANDIDATE.json',
    'state/C1_IMPORT_PROVENANCE.json',
    'state/C2_CANDIDATE.json',
    'state/C2_HOST_EVIDENCE.json',
    'state/BUNDLE_VERIFY_C2.json',
    'state/EXIT_AUDIT.json',
    'inputs/handoff.json',
    'inputs/SHA256SUMS',
    'runs/host_baseline_01/device-inspect.json',
    'runs/host_baseline_01/quarantine_red.log',
    'runs/host_baseline_01/quarantine_final.log',
    'runs/host_baseline_01/related_regression.log',
    'runs/host_baseline_01/baseline_drift_guards.log',
    'runs/C2_303ef7fe/quarantine_host.log',
    'runs/C2_303ef7fe/local_admission_host.log',
    'runs/C2_303ef7fe/local_prepare.log',
    'runs/C2_303ef7fe/local_prepare_01/config-schema.json',
    'runs/C2_303ef7fe/local_prepare_01/local-candidate-manifest.json',
    'runs/C2_303ef7fe/local_prepare_01/case-plan.json',
    'runs/C2_303ef7fe/admission_negative_01/CONFIG/runner-result.json',
    'reports/build_review.py',
    'reports/profile_history_extract.py',
    'reports/PROFILE_HISTORY_REFERENCE.json',
    'return/MRV2_C2_from_Repair6.bundle',
]
members += ['reports/' + name for name in primary]

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

# Verify every evidence path named in the CSV exists in the server workspace.
with (reports / 'MRV2_实验矩阵与结论.csv').open(encoding='utf-8-sig', newline='') as stream:
    rows = list(csv.DictReader(stream))
for row in rows:
    for rel in row['证据相对路径'].split(';'):
        if not (root / rel).is_file():
            raise RuntimeError('missing matrix evidence: ' + rel)

index = {
    'schema': 'mrv2-review-index-v1',
    'scope': 'small reports and excerpts only; no model, raw tensors or raw profiler',
    'candidate_sha': '303ef7fe117d372d5f9463d3d79b90e56b9e695d',
    'members': {rel: {'bytes': (root / rel).stat().st_size, 'sha256': sha(root / rel)} for rel in members},
}
index_path = reports / 'review_index.json'
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
members.append('reports/review_index.json')
zip_path = returns / 'MRV2_Server_Dev_review.zip'
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for rel in members:
        archive.write(root / rel, arcname=rel)
if zip_path.stat().st_size >= 20 * 1024 * 1024:
    raise RuntimeError('review zip exceeds 20 MiB')
with zipfile.ZipFile(zip_path) as archive:
    if archive.testzip() is not None:
        raise RuntimeError('review ZIP CRC failure')
    if set(archive.namelist()) != set(members) or len(archive.namelist()) != len(members):
        raise RuntimeError('review ZIP member list mismatch')
    for rel in members:
        if rel.endswith('.json'):
            pairs = []
            def check(items):
                keys = [key for key, _ in items]
                if len(keys) != len(set(keys)):
                    raise RuntimeError('duplicate JSON key in ' + rel)
                return dict(items)
            json.loads(archive.read(rel), object_pairs_hook=check)
    included = json.loads(archive.read('reports/review_index.json'))['members']
    for rel, entry in included.items():
        data = archive.read(rel)
        if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise RuntimeError('review index mismatch: ' + rel)

validation = {
    'status': 'SERVER_SELF_CHECK_PASS_NOT_RECEIVER_VERIFIED',
    'zip': str(zip_path),
    'bytes': zip_path.stat().st_size,
    'sha256': sha(zip_path),
    'members': len(members),
    'crc': 'PASS',
    'json_parse_duplicate_keys': 'PASS',
    'index_hashes': 'PASS',
    'matrix_references': 'PASS',
}
(reports / 'REVIEW_ZIP_VALIDATION.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(validation, ensure_ascii=False))
