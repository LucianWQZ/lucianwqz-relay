#!/usr/bin/env python3
"""只读提取旧 Repair5 四格 profiling 的少量字段，不替代本轮采集。"""
import hashlib
import json
from pathlib import Path

root = Path('/mnt/wenqing/mrv2_graph_repair5_verify/20261020T144145Z_d0a3fc3d/review_input/cases')
out = {'scope': 'HISTORICAL_REFERENCE_ONLY', 'new_candidate_sha': '303ef7fe117d372d5f9463d3d79b90e56b9e695d', 'cases': []}
for name in ('PROFILE_OFF_short_normal', 'PROFILE_ON_short_normal', 'PROFILE_OFF_long_normal', 'PROFILE_ON_long_normal'):
    profile_path = root / name / 'profile.json'
    trace_path = root / name / 'trace-analysis.json'
    profile = json.loads(profile_path.read_text())
    trace = json.loads(trace_path.read_text())
    stats = profile.get('host_statistics', {})
    selected = {key: {'samples': val.get('samples'), 'p50_ms': val.get('p50_ms'), 'p95_ms': val.get('p95_ms'), 'scope': val.get('scope')} for key, val in stats.items()}
    out['cases'].append({'case_id': name, 'source_sha': profile['identity']['source_sha'], 'source_tree': profile['identity']['source_tree'], 'profile_path': str(profile_path), 'profile_sha256': hashlib.sha256(profile_path.read_bytes()).hexdigest(), 'trace_analysis_path': str(trace_path), 'trace_analysis_sha256': hashlib.sha256(trace_path.read_bytes()).hexdigest(), 'status': profile.get('status'), 'draft_replay_count': selected.get('Draft_REPLAY_SUBMIT', {}).get('samples'), 'target_replay_count': selected.get('Target_REPLAY_SUBMIT', {}).get('samples'), 'host_statistics': selected, 'physical_read': profile.get('physical_read'), 'completion': profile.get('completion'), 'clock_domain': profile.get('clock_domain'), 'kernel_attribution': trace.get('target_draft_kernel_attribution'), 'device_idle': trace.get('device_idle'), 'long_window_cropped_S_gt_0': 'NOT_PROVEN_BY_THIS_SUMMARY'})
Path('reports/PROFILE_HISTORY_REFERENCE.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
