# MRV2 Profiling 分析

本轮候选 `303ef7fe117d372d5f9463d3d79b90e56b9e695d` 的正常 profiling **未采集**。当前容器没有 `/dev/davinci*`，实际物理芯片映射未知；`state/DEVICE_ENVIRONMENT.json` 和 `runs/host_baseline_01/device-inspect.json` 记录了只读准入失败。没有运行 Graph 模型、调用 profiler 或生成本轮 trace。四格 OFF/ON × short/long 与对应未采集控制组均为 `NOT_RUN_NO_DEVICE`；数值指标均为 `NOT_AVAILABLE`，不能填 0 或计算 Window 加速率。机器可用 API 的签名、torch_npu 版本和 ExternalEvent 文档见 `../state/PROFILE_CAPABILITY.json`；API 预检状态是 `APIS_AVAILABLE_DEVICE_NOT_RUN`。

## 旧 SHA 的有限参考

`PROFILE_HISTORY_REFERENCE.json` 从 `/mnt/wenqing/mrv2_graph_repair5_verify/20261020T144145Z_d0a3fc3d/review_input/cases/` 的四份 `profile.json` 和 `trace-analysis.json` 只读提取字段和原文件 SHA256。它们的源码是 Repair5 `d0a3fc3d42d7d97e5e7da3890d2710263a097e63`，逻辑设备字符串是 `npu:0`，不是本轮 C2，也没有当前容器物理 Phy-ID 映射。因此以下数字只说明旧采集工具曾能留下哪些字段：

| 旧 case | Draft replay 样本 | Target replay 样本 | Draft replay+UPDATE Host p50 (ms) |
| --- | ---: | ---: | ---: |
| OFF short | 21 | 12 | 1.42336 |
| ON short | 21 | 12 | 2.83588 |
| OFF long | 47 | 30 | 1.59553 |
| ON long | 47 | 30 | 2.79848 |

这些是旧 SHA 的 Host 提交范围，不是设备完成时间或端到端延迟。旧 ON-long 的 `trace-analysis.json` 有 `kernel_details.csv`、`operator_details.csv`、`task_time.csv` 字段清单，但 `target_draft_kernel_attribution=UNRESOLVED_UNLESS_EXPLICIT_FLOW_ASSOCIATION`，`device_idle=UNRESOLVED_WITHOUT_CALIBRATED_TIMELINE`；旧 profile 明确 `physical_read=NOT_PROVEN`、`completion=NOT_PROVEN`。这个四格 summary 也没有 runtime S>0 证据，不能把 long prompt 直接判成真实 Window 裁剪。旧目录原始 trace 保持原位，没有复制入本轮 run。

## 本轮问题与证据状态

| 问题 | 本轮结论 | 需要的可区分证据 |
| --- | --- | --- |
| A. Graph replay 是否真实发生及次数 | `NOT_AVAILABLE` | C2 实际 request 阶段 replay ID、source SHA、case/attempt、设备 segment |
| B. Target、Draft、FIA 是否可分 | `NOT_AVAILABLE` | 显式 flow/context/stream 与层身份，不能按同名或邻行归因 |
| C. Host API 到 task/stream/flow | `NOT_AVAILABLE` | 同一 trace 中校准的 ID、时间域和上下文关系 |
| D. materialize、metadata、UPDATE、retire Host 开销 | `NOT_AVAILABLE` | C1 正常 observer-off 范围及逐 replay 样本；范围缺失时先判定执行/开关/采集/导出原因 |
| E. H2D/D2H/D2D、wait/sync | `NOT_AVAILABLE` | 请求窗口内操作表及耗时；诊断同步另列 |
| F. Host 下发、设备空档与跨 stream 重叠 | `NOT_AVAILABLE` | 校准 timeline 和 stream flow；并行 duration 不可直接相加为 elapsed |
| G. OFF/ON 单位有效工作量 | `NOT_AVAILABLE` | 请求与生成 token、Target 验证、Draft replay、active/padded、acceptance、上下文和 S>0 |
| H. profiler/诊断本身开销 | `NOT_AVAILABLE` | 四格未采集控制组与同 workload 配对；诊断 LIFE profile 另列 |
| I. UPDATE 代际、backing 复用、physical read | `NOT_PROVEN` | 平台 Graph/ExternalEvent 语义合同及可区分的代际/读集合设备实验；普通 trace 不能单独证明 |

## 恢复采集顺序

在能看到授权设备节点的执行容器中，先保存新鲜 `npu-smi`、设备节点、namespace/boot ID、宿主和容器 PID、逻辑到宿主 Phy-ID 映射与现有占用；完成 committed inspect/probe/check 和逐 case `BIND_DEVICE`。以 C2 固定 checkout、相同 fixture/profile、独立 attempt 进行初始化/capture/预热后采集有界请求阶段；正常采集关闭重型 observer、Target dump、连续数值 reference 和 LIFE 逐代同步，不改业务 `is_profile` dispatch。不同时叠加两套 profiler。采集四格及未采集控制组，确认 ON-long 实际 S>0。先比较有效工作量，再分析 Host 范围、关联表、设备空档和独立同步成本。当前阶段不得将旧 Repair5 trace 升级为 C1 结果。
