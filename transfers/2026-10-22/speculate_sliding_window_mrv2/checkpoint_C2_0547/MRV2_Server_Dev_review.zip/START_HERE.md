# MRV2 Graph 服务器开发入口

本轮 session：`20261022T050438Z`；授权窗口 2026-10-22 05:04:38–10:04:38 UTC。因当前容器无 NPU 节点且共享 NFS 低于 500 GiB 水位，本轮已提前停止大型实验。public Graph Gate 冻结。

- **先看总结**：[reports/MRV2_五小时开发总结.md](reports/MRV2_五小时开发总结.md)
- **再看状态**：[journal/00_当前进展.md](journal/00_当前进展.md)
- **按此恢复**：[reports/RESUME.md](reports/RESUME.md)
- 实验矩阵：[reports/MRV2_实验矩阵与结论.csv](reports/MRV2_实验矩阵与结论.csv)
- Profiling：[reports/MRV2_Profiling分析.md](reports/MRV2_Profiling分析.md)
- 待决事项：[journal/DECISION_QUEUE.md](journal/DECISION_QUEUE.md)
- 实时日志：`tail -f /mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/journal/progress.log`
- 交付索引：[return/DOWNLOAD_MANIFEST.json](return/DOWNLOAD_MANIFEST.json)

开发源码 `work/vllm-ascend`，固定 C2 候选 `candidates/C2_303ef7fe/vllm-ascend`，run 根 `runs`。当前最佳本地候选 `303ef7fe117d372d5f9463d3d79b90e56b9e695d`；本轮无关键设备通过候选。当前容器未准入 NPU，尚无真实 Graph 数值/生命周期/profiling 结果。
