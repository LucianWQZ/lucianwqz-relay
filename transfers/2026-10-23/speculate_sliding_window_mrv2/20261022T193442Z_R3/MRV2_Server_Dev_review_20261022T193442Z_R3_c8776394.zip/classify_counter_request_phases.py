"""Offline CPU-state grouping by exact epoch and current post-Target counts.

Does not assign device tasks or compare different clocks.
"""
import collections
import hashlib
import json
from pathlib import Path
import statistics

R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID='20261022T193442Z_R3';BASE=R/'runs'/SID/'raw/C28_prepare_01/PROFILE_COUNTER_REUSE_ON_long_normal'

def stats(values):return dict(n=len(values),mean_ms=statistics.mean(values),median_ms=statistics.median(values),all_ms=values)

def main():
 profile=json.loads((BASE/'profile.json').read_text());campaign=json.loads((BASE/'campaign.json').read_text());trial=json.loads((BASE/'counter-length-trial.json').read_text())
 assert trial['identity']==profile['identity']==campaign['identity']
 assert not trial['poisoned'] and not trial['errors']
 by_epoch={r['mapping_epoch']:r for r in trial['records']}
 calls=[x for x in profile['calls'] if x['active'] and x['label']=='Draft_materialize']
 groups={x['label']:[len(t) for t in x['prompt_token_ids']] for x in campaign['outputs']}
 request_prompts={};seen_groups=set();phases={};rows=[]
 for call in sorted(calls,key=lambda x:x['start_ns']):
  epoch=call['mapping_epoch'];row=by_epoch[epoch];group=call['request_group']
  counts=row['post_target_counts'];ids=row['request_ids'];new=[i not in request_prompts for i in ids]
  if group not in seen_groups:
   assert all(new) and sorted(counts)==sorted(groups[group]), 'first current counts do not match actual prompt lengths'
   for key,value in zip(ids,counts):request_prompts[key]=value
   seen_groups.add(group)
  flags=[value==request_prompts[key] for key,value in zip(ids,counts)]
  assert all(value>=request_prompts[key] for key,value in zip(ids,counts))
  phase='CURRENT_POST_TARGET_EQUALS_PROMPT' if all(flags) else 'CURRENT_POST_TARGET_AFTER_PROMPT' if not any(flags) else 'MIXED'
  phases[epoch]=phase;rows.append(dict(group=group,epoch=epoch,phase=phase,request_ids=ids,computed=counts,prompt=[request_prompts[i] for i in ids],active=row['active'],padded=row['padded']))
 buckets=collections.defaultdict(lambda:collections.defaultdict(list))
 for call in profile['calls']:
  epoch=call.get('mapping_epoch',call.get('proposal_mapping_epoch'))
  if not call['active'] or epoch not in phases:continue
  if call['label'] in ('Draft_materialize','Draft_materialize_exact_length_snapshot','Draft_materialize_workspace','Draft_build_attn_metadata','Draft_UPDATE_CALL','Draft_retire_host'):
   buckets[phases[epoch]][call['label']].append((call['end_ns']-call['start_ns'])/1e6)
 result=dict(status='CPU_COUNTER_PHASES_JOINED',source_sha=trial['identity']['source_sha'],producer_pid=trial['identity']['process_id'],
  phase_meaning=dict(CURRENT_POST_TARGET_EQUALS_PROMPT='Host current-count evidence for terminal prefill, with actual prompt length match',CURRENT_POST_TARGET_AFTER_PROMPT='Host current-count evidence for subsequent decode'),
  rows=rows,phase_counts=dict(collections.Counter(phases.values())),statistics={k:{label:stats(values) for label,values in v.items()} for k,v in buckets.items()},
  inputs=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [BASE/'profile.json',BASE/'campaign.json',BASE/'counter-length-trial.json']],
  analysis_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Only this experimental counter-reuse profile; exact Host epoch/current counter/request group association; no native task phase or device completion inference')
 out=R/'reports'/SID/'C28_counter阶段CPU状态归因.json';assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(result['phase_counts'])

if __name__=='__main__':main()
