"""Bounded /proc provenance reader for the first actual C28 correctness worker.

No accelerator queries, tensor reads or injected code. Library hashing happens
in A0/B0/LIFE correctness cases, before the declared performance comparisons.
"""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import time

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
E = R / 'runs/20261022T193442Z_R3/environment'
SOURCE = R / 'candidates/C28_graph_failure/vllm-ascend'
SHA = 'c877639472386aedeb7df11f15b6bf75c078261c'
END = dt.datetime.fromisoformat('2026-10-22T23:55:00+00:00').timestamp()
TOKENS = ('libvllm_ascend_kernels', 'vllm_ascend_C', 'libcust_opapi', 'libtorch_npu',
          'libacl_rt.so', 'libacl_rt_impl.so', 'libascendcl.so', 'libruntime.so',
          'libruntime_common.so', 'libruntime_v100.so')
KEYS = ('PYTHONPATH', 'VLLM_VERSION', 'ASCEND_RT_VISIBLE_DEVICES', 'ASCEND_VISIBLE_DEVICES',
        'LD_LIBRARY_PATH', 'VLLM_USE_V2_MODEL_RUNNER', 'VLLM_ENABLE_V1_MULTIPROCESSING',
        'ASCEND_LAUNCH_BLOCKING', 'TASK_QUEUE_ENABLE', 'COMBINED_ENABLE', 'MULTI_STREAM_MEMORY_REUSE',
        'TORCH_DEVICE_BACKEND_AUTOLOAD', 'PYTORCH_NPU_ALLOC_CONF', 'ASCEND_CUSTOM_OPP_PATH')


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


identity = dict(pid=os.getpid(), start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(), started_at=now(),
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                role='HOST_ONLY_ACTUAL_WORKER_PROVENANCE_READER', deadline_utc='2026-10-22T23:55:00+00:00')
(E / 'C28_provenance_monitor_identity.json').write_text(json.dumps(identity, indent=2) + '\n')
while time.time() < END:
    status = json.loads((R / 'journal/current_status.json').read_text())
    if status.get('current_case') in ('A0', 'B0', 'LIFE'):
        for pid in status.get('model_worker_pids', []):
            p = Path('/proc') / str(pid)
            try:
                argv = [x.decode() for x in (p / 'cmdline').read_bytes().split(b'\0') if x]
                if str(SOURCE / 'tools/p7x_graph_repair2.py') not in argv:
                    continue
                start_ticks = (p / 'stat').read_text().rsplit(')', 1)[1].split()[19]
                maps = (p / 'maps').read_text()
                libs = sorted({line.split()[-1] for line in maps.splitlines()
                               if any(token in line for token in TOKENS) and line.split()[-1].startswith('/')})
                if not all(any(token in name for name in libs) for token in TOKENS):
                    continue
                env = dict(x.split('=', 1) for x in (p / 'environ').read_text().split('\0') if '=' in x)
                result = dict(pid=pid, start_ticks=start_ticks, observed_at=now(), source_sha=SHA,
                              case=status['current_case'], argv=argv, exe=os.readlink(p / 'exe'),
                              cwd=os.readlink(p / 'cwd'), pid_namespace=os.readlink(p / 'ns/pid'),
                              mount_namespace=os.readlink(p / 'ns/mnt'), cgroup=(p / 'cgroup').read_text(),
                              environment={k: env.get(k, 'UNSET') for k in KEYS},
                              device_observation=status.get('npu_observation'), required_library_tokens=TOKENS,
                              scope='actual same-process worker; root imports/class checked separately in campaign; no device reads')
                (E / 'C28_actual_worker_maps.txt').write_text(maps)
                loaded = []
                for name in libs:
                    with Path(name).open('rb') as f:
                        value = hashlib.file_digest(f, 'sha256').hexdigest()
                    loaded.append(dict(path=name, bytes=Path(name).stat().st_size, sha256=value))
                result['loaded_libraries'] = loaded
                result['library_hashes_finished_at'] = now()
                (E / 'C28_actual_worker_provenance_complete.json').write_text(json.dumps(result, indent=2) + '\n')
                identity.update(ended_at=now(), result='CAPTURED_COMPLETE_10_REQUIRED_TOKENS', worker_pid=pid)
                (E / 'C28_provenance_monitor_end.json').write_text(json.dumps(identity, indent=2) + '\n')
                print('captured actual worker', pid, 'case', result['case'], 'libraries', len(loaded), flush=True)
                raise SystemExit(0)
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
    time.sleep(5)
identity.update(ended_at=now(), result='NOT_CAPTURED_NO_QUALIFYING_WORKER')
(E / 'C28_provenance_monitor_end.json').write_text(json.dumps(identity, indent=2) + '\n')
raise SystemExit(2)
