"""Explicit CPU-only UT bootstrap; no actual NPU discovery or initialization."""
import os,runpy,subprocess,sys
from pathlib import Path
from unittest.mock import patch
os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD']='0'
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
repo=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/candidates/C19_native_tensor/vllm-ascend')
os.chdir(repo)
sys.path[:0]=[str(repo),'/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/candidates/C2_303ef7fe/vllm']
original=subprocess.run
def cpu_discovery(argv,*args,**kwargs):
    if argv==['npu-smi','info']:
        raise subprocess.CalledProcessError(1,argv,output='CPU_ONLY_TEST_NO_DEVICE_QUERY')
    return original(argv,*args,**kwargs)
with patch('subprocess.run',side_effect=cpu_discovery):
    runpy.run_path(str(repo/'tests/ut/conftest.py'),run_name='_cpu_ut_bootstrap')
import pytest
raise SystemExit(pytest.main(['--noconftest','-q',*sys.argv[1:]]))
