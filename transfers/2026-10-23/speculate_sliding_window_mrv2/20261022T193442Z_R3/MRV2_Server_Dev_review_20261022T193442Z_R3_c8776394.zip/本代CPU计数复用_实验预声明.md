# 本代CPU精确计数复用：先核验，再量化原型

假设：现有NPUModelRunner.postprocess_sampled已经把rejection后的num_computed_tokens.gpu拷到固定pinnedCPU staging，并记录普通num_computed_tokens_event；正常DSpark TP1里Draft seq_lens=min(current_postcomputed+7,max_model_len)。可以在不使用upper/旧代缓存的前提下复用该拷贝，减少一次prepared-seq D2H。

源码依据：pinned GPUModelRunner.sample_tokens:1971–2060在postprocess后propose；NPUModelRunner:741–773调用原有异步counter拷贝；pinned input_batch.post_update:590–602加query_len-num_rejected；DFlash prepare:567/662使用last_valid_pos+1+query_width。连续绝对positions在冻结TP1/非prefix/nonasync入口是必要前提。

第一步仅做默认关闭的工具实验：verify模式保留原legacy D2H，并将本代已有counterCPU+K与它逐项严格比较，包含active/padded、请求映射、mapping_epoch及postprocess ticket；实际请求/Graph链走正常MRV2，额外普通event等待必须标为诊断。没有先验设备PASS。

第二步仅在同SHA/config/request的verify联合核验通过后，开启独立实验reuse模式，用已有counter event同步后读取CPU并构造独立int32快照；不再prepared-seq D2H。不改变replay→UPDATE顺序，不创建新event或copy，不查询ExternalEvent，不改Target/positions/slot_mapping。默认关闭，不等同已实施production优化。

比较同为Window ON、同Target4配置、同请求的LEGACY与COUNTER_REUSE，各少量交错控制及代表性profile。现有Window OFF/ON Base采集仍由C21独立进行，不拼成同一个性能矩阵。

重点反例：上一代ticket、请求映射不一致、padded非零、dtype错误、counter越界、event失败、不完整请求或未走Graph均拒绝。发生未知event/native失败只Host错误记录与隔离，禁止再用/补D2H/清零取证。

重要备选解释：下一处CPU→Device window length.copy_默认blocking，会再次等待current；去掉snapshot等待可能主要移动到runtime H2D，而非降低materialize或端到端。必须同时比较snapshot、runtime/outer与elapsed。若只有子范围缩短，保留生产C19，不以此宣布性能改进。

只有真实数据支持收益且同代/所有权合同成立，再决定最小production补丁及相关数值/ABA/Target验证。原型本身不关闭连续数值、正常复用、task operand或physical read验收。PR21:00–23:30窗口内只轻量代码与定向Host检查，不加载模型/重编译/大I/O。

## 2026-10-22T22:54:36.070903+00:00 执行前补充

拟实际执行候选统一为C28 c877639472386aedeb7df11f15b6bf75c078261c，含Graph早期异常保护；原C24工具提交和C21准备保留但不运行旧异常实现。

首个实际阻塞点的源码细化：workspace在table D2D之前先valid_num_blocks.copy_(cpu_valid_num_blocks)，随后还有device_window_exact.copy_(cpu_window_exact)；两者均默认blocking。初版以后一处length copy举例说明等待转移，现在补充更早的valid-count H2D。实验仍同时比较snapshot、workspace/runtime、整个materialize及同工作量端到端，不改变判据。prepared长度复制的原始payload为4×padded bytes，冻结桶上限16 bytes；其10ms Host范围不能直接称带宽成本。

Target4独立请求SHA256=8209a74fd590609263535bc641b213577f9792b013241b1bfbafe616a2357dd3，包含1/2/3/4请求短组和2049/3072单请求，共12请求、192个有效输出tokens（每请求16）；全部预热再活跃测量。预声明控制顺序LEGACY01→REUSE01→REUSE02→LEGACY02→LEGACY03→REUSE03，之后各一有界profile，保留所有结果。无安静条件仅各一次诊断，不作正式加速结论。verify先通过同SHA/config/request严格联合核验才准入reuse；reuse是实验长度来源，不是production默认。
