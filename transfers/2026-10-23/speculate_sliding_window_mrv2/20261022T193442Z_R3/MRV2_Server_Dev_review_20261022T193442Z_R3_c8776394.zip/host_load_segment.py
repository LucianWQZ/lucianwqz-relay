"""Bounded external Host sampling, enabled only by this Graph segment's lease."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import time

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID = '20261022T193442Z_R3'
E = R / 'runs' / SID / 'environment'
RAW = R / 'runs' / SID / 'raw'
LATEST_START = dt.datetime.fromisoformat('2026-10-22T23:46:00+00:00').timestamp()
HARD_END = dt.datetime.fromisoformat('2026-10-23T00:31:00+00:00').timestamp()
identity = dict(pid=os.getpid(), start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                pid_namespace=os.readlink('/proc/self/ns/pid'), role='EXTERNAL_HOST_LOAD_ONLY_NO_NPU',
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                started_at=dt.datetime.now(dt.timezone.utc).isoformat())
(E / 'host_load_monitor_identity.json').write_text(json.dumps(identity, indent=2) + '\n')
samples = 0
while time.time() < HARD_END:
    acquired = (RAW / 'lease-acquisition-after-pr.json').exists()
    if not acquired:
        if time.time() > LATEST_START:
            break
        time.sleep(30)
        continue
    status = json.loads((R / 'journal/current_status.json').read_text())
    row = dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(), monotonic_ns=time.monotonic_ns(),
               case=status.get('current_case'), status=status.get('status'),
               loadavg=Path('/proc/loadavg').read_text().strip(),
               cpu_stat=Path('/proc/stat').read_text().splitlines()[0],
               mem_available=[s for s in Path('/proc/meminfo').read_text().splitlines()
                              if s.startswith('MemAvailable:')],
               scope='whole-host coarse counters; no per-kernel or generation attribution')
    with (E / 'host_load_samples.jsonl').open('a') as f:
        f.write(json.dumps(row, ensure_ascii=False) + '\n')
    samples += 1
    if (RAW / 'lease-release-after-pr.json').exists():
        break
    time.sleep(30)
identity.update(ended_at=dt.datetime.now(dt.timezone.utc).isoformat(), samples=samples,
                result='COLLECTED_COARSE_HOST_SAMPLES' if samples else 'NOT_COLLECTED_NO_SEGMENT',
                source_sha256_at_exit=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(E / 'host_load_monitor_end.json').write_text(json.dumps(identity, indent=2) + '\n')
