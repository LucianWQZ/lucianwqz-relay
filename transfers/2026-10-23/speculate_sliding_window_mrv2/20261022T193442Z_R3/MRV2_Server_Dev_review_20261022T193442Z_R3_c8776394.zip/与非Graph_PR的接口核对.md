# 与非Graph PR的只读接口核对

核对时点：2026-10-22约20:10UTC。PR工作树未修改；没有cherry-pick或接管其任务。

|身份|Graph|非Graph PR当前已声明/核对|
|---|---|---|
|Ascend|C19 production，C23仅tools/tests后续|f0fcc9543b0a1b6891aeb8a566d95ae40e1b0fcd，tree1ac949276f836d75d8ad7e1246507dc3d834e515，clean|
|vLLM|84030bbe3d74d99bad477a3d2e37a973ccd8865c|a98247ab4db686ee03c66d5feb3c761e52a2f8ab，tree7f2a24a827bbbb2f211e02031f9d4d0d556d536c|
|准备运行|Python3.11.10及已验证C19 ignored原生overlay|PR隔离Python3.12及native build；不等同Graph runtime|

PR当前commit `perf: reuse owned draft window lengths in parallel GQA`新增：

- `vllm_ascend/worker/v2/spec_decode/draft_window_read.py::DraftReadView.apply`向新Draft common metadata附加 `_draft_window_read`。
- `DraftReadView.exact_cpu_for`校验Device/CPU精确长度、_seq_lens_cpu、block_table四个对象身份未被替换，再返回拥有的本代CPU精确长度。
- `vllm_ascend/attention/utils.py::_select_seq_lens`优先消费该read view，避免parallel GQA又选Device再tolist；未经认证的基线路径保持原分派。

Graph C19已有不同的桥：`draft_window_eager.py::_validated_draft_attention_read_inputs`及`_build_ascend_draft_attn_metadata`通过拥有的CPU精确长度与generation/epoch/lease传递；`attention_v1.py::AscendMetadataBuilder.build`在parallel_drafting时依据 `seq_lens_cpu_is_explicit`消费该CPU精确值。两者目标相容，结构与vLLM pin不同。

## 集成风险与顺序建议

1. 先待非Graph PR接口/基线提交明确并通过自身审查，再在独立集成候选上适配Graph的generation/lease/固定carrier。当前不复制PR正在变化的源码到Graph候选。
2. 合并metadata selector时保留Graph本代精确CPU值的认证入口。仅迁移PR的 `_select_seq_lens` 而遗漏Graph的explicit/owned桥，会让Qwen parallel draft重新走Device.tolist并增加同步；不能因为有CPU字段就盲信未经认证的镜像。
3. 如统一为 `exact_cpu_for` 协议，Graph adapter仍须同时验证实际generation/epoch/descriptor/持久carrier；不能用一个新标签绕过原有lease校验，也不能将Target metadata附上Draft read view。
4. 保持Target/Full的canonical table、绝对positions、slot_mapping；读投影不得改写这些所有者。
5. pin/运行ABI发生变化后，C19证据不能直接升级为新集成候选PASS。需按实际diff重验配置/B0、数值/ABA/Target隔离和受影响生命周期，原有失败仍保留。

本轮正常合同与性能结论只绑定Graph原pin；没有宣称PR代码与Graph已经集成验证。

## 2026-10-22T23:54:27.692436+00:00 再核对PR已声明的固定C08

PR SOURCE_STATE与只读git一致：Ascend 60da9fb9f4a8b455bc93a8d291a69528885db4b1/tree5225f1e92d56f6e8380195e5d8b5a799a84a1295，vLLM a98247ab4db686ee03c66d5feb3c761e52a2f8ab，clean，frozen_pair=checkouts/c08_capacity。较首次记录f0fcc954，production变更位于attention/attention_v1.py、worker/v2/spec_decode/draft_window_dense.py、draft_window_runtime.py；新增短上下文scratch容量上界。upper只用于容量，不替代device exact读视图；这不是Graph可以直接替换exact snapshot的依据。

接口仍需显式集成适配：DraftReadView.exact_cpu_for校验common metadata与精确CPU所有权；DraftWindowLifetime/Owner保留所有reader并处理完成。Graph当前frozen pin与早期runtime不同，不直接cherry-pick或导入PR工作树。建议先冻结非Graph规范接口和基线，再独立Graph集成候选，对上述attention/runtime接口与reader完成合同做定向集成及数值/Target验证。当前没有集成候选，不能把PR TP8非Graph数据记成Graph PASS，也不复制其Python3.12安装到当前Python3.11环境。

PR正式TP16请求状态FORMAL_WINDOW_NOT_USED_GATES_INCOMPLETE；back8预约/现场确认仍pending。约定时段已避让，不声称PR取得过全部16片或完成正式TP16性能。实际后段对照以PR ACK和本任务租约原件为准。
