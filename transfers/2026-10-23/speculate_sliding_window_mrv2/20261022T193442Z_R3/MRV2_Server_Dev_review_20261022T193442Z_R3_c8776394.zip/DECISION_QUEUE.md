# 待决事项（未自动发送）

|责任方|具体问题/已有证据|建议与缺失条件|阻塞范围/还能继续|
|---|---|---|---|
|CANN/torch_npu维护者|正常A/B五步依赖已有匹配版本源码、capture多流合流和v100实际加载/hash；是否有具体补丁/未登记consumer/事件复用例外？|认可适用前提或指出具名反例；不再笼统索取同样dump/完整二进制重建|正式平台适用性审阅；代码/限定数值与性能材料已完成|
|验收owner，平台供能力|原G3 physical-read/task执行operand仍无实际occurrence/read-set；C19 native15仅post-drain绑定，四新trace无代际执行flow|保持原标准并提供安全能力；或正式审查原Repair7提出的替代证据路线；或保持实验/Gate冻结。本Agent不选择降标|公开支持；无新能力停止重复末值dump，继续文档审查。outside-only非干扰反事实未新做，不把ABA改名|
|产品/发布owner|Target4十二数值/十二Target对、LIFE/隔离已验证；Base缺(4,32)固定事实|审冻结DSpark TP1 Target4配置、最大active/padded及缺桶明确拒绝；Base不得升级为全4请求支持。额外桶精确HBM未暴露，两位小数相同不填0|产品入口/发布范围；不阻塞本轮可审代码与证据|
|平台维护者|native task update有部分失败计数但无整组rollback合同|明确各失败阶段和允许Host隔离边界；当前保守quarantine/进程隔离，不做设备/KV恢复|恢复能力承诺；不制造共享硬件故障，现隔离范围已有真实Python证据|
|Graph/非Graph接口维护者|PR固定C08 Ascend60da9fb9、vLLMa982与Graph pin840不同；owned exact/read-view接口和reader owner不同|先固定接口/基线，再独立集成候选；CPU counter原型仅小差异，不能直接导入缓存或改变Host缓冲生命周期|后续集成/优化；本轮不改PR树，默认长度路径保留|
|资料仓库owner|历史接收报告称LucianWQZ/private-file-relay实际public，当前可见性本轮未重查|由owner处理资料仓库问题；本轮没有上传日志、路径清单、模型数据或实验包，也没改可见性|不阻塞本地开发/交付；禁止擅自上传公开仓|

public Graph Gate保持冻结。正式性能最低阈值本轮未收到，不发明新门槛；现有无加速/小差异由owner结合范围审阅。metadata发布异常单独NPU注入未做，已有Host反例与共享quarantine策略；不把未测分支写通过。
