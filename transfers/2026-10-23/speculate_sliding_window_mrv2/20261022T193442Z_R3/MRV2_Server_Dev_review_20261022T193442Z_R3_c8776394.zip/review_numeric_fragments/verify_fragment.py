"""Standard-library-only output fragment check. This is not a full Graph gate."""
import hashlib
import json
import math
from pathlib import Path
import struct

ROOT=Path(__file__).resolve().parent

def require(v,message):
 if not v:raise ValueError(message)
def pairs(items):
 d={}
 for k,v in items:
  require(k not in d,'duplicate JSON key: '+str(k));d[k]=v
 return d

def tensor(ref,expected,endian):
 require(ref['dtype']==expected,'exact field dtype mismatch')
 name=ref['path'];require(Path(name).name==name,'unsafe tensor path');p=ROOT/'data'/name
 require(p.resolve().parent==(ROOT/'data').resolve(),'tensor escaped root')
 b=p.read_bytes();require(len(b)==ref['bytes'],'tensor byte mismatch');require(hashlib.sha256(b).hexdigest()==ref['sha256'],'tensor hash mismatch')
 sizes={'torch.bfloat16':2,'torch.int32':4,'torch.int64':8};shape=ref['shape'];require(all(type(x) is int and x>0 for x in shape),'invalid shape')
 require(math.prod(shape)*sizes[expected]==len(b),'dtype/shape/bytes contradiction')
 offset=0
 for c in ref['chunks']:
  require(c['offset']==offset and c['bytes']>0,'chunk coverage mismatch');part=b[offset:offset+c['bytes']];require(hashlib.sha256(part).hexdigest()==c['sha256'],'chunk hash mismatch');offset+=c['bytes']
 require(offset==len(b),'incomplete chunks')
 fmt={'torch.bfloat16':'H','torch.int32':'i','torch.int64':'q'}[expected]
 values=[x[0] for x in struct.iter_unpack(endian+fmt,b)]
 if expected=='torch.bfloat16':values=[struct.unpack(endian+'f',struct.pack(endian+'I',x<<16))[0] for x in values]
 return values

def main():
 d=json.loads((ROOT/'fragment.json').read_text(),object_pairs_hook=pairs);require(d['schema']=='mrv2-review-numeric-fragment-v1','fragment schema')
 require(d['full_joint_recomputable_from_this_fragment'] is False,'fragment scope changed');require(d['atol']==d['rtol']==0.0,'frozen tolerance changed')
 endian={'little':'<','big':'>'}[d['byte_order']];outputs=[];results=[]
 for row in d['rows']:
  manifest=ROOT/row['original_manifest_copy'];require(hashlib.sha256(manifest.read_bytes()).hexdigest()==row['source_sample']['sha256'],'original sample manifest changed')
  for key,dtype in [('input_ids','torch.int32'),('positions','torch.int64'),('slot_mapping','torch.int32')]:
   require(row['refs'][key]['shape']==[7],key+' query shape');tensor(row['refs'][key],dtype,endian)
  for key in ('graph','reference'):require(row['refs'][key]['shape']==[7,4096],'output shape')
  a=tensor(row['refs']['graph'],'torch.bfloat16',endian);b=tensor(row['refs']['reference'],'torch.bfloat16',endian)
  require(all(math.isfinite(v) for v in a+b),'non-finite output');maximum=max(abs(x-y) for x,y in zip(a,b));require(maximum==0.0,'strict output mismatch')
  outputs.append(a);results.append(dict(scenario=row['scenario'],generation=row['generation'],epoch=row['epoch'],finite=True,max_abs=maximum))
 require([x['scenario'] for x in d['rows']]==['A','B','A_prime'],'sample set/order')
 require(outputs[0]!=outputs[1],'B output not distinguishable');require(outputs[0]==outputs[2],'A-prime output did not restore')
 print(json.dumps(dict(status='PASS_OUTPUT_FRAGMENT_RECALC_ONLY',samples=results,aba_output_discrimination_and_restoration=True,full_joint_requires_server_artifacts=True,scope='Not independent oracle execution, complete layer/KV/Target/lifecycle or Graph gate validation'),indent=2))

if __name__=='__main__':main()
