# C28全组预热后的有限OFF/ON控制

生成于2026-10-22T23:56:13.696337+00:00。正常profile仍在运行，本文件仅归约未采集控制。

|臂|01 ms|02 ms|03 ms|中位 ms|
|---|---:|---:|---:|---:|
|OFF|1093.05655|1121.69816|1127.67033|1121.69816|
|ON|1169.67386|1164.88487|1193.23759|1169.67386|

固定Source C28 c877639472386aedeb7df11f15b6bf75c078261c，Base profile[7,14,28]；独立请求SHA c61948898fa304a418eb600921eea02a1604fe4867f278a7649cd02a092f66d9。全组warmup含smoke1/2/4、2049和3072名义长度，实际token长度见R3_实际执行与性能归约.json。活动请求均9个、144有效输出tokens。

ON中位请求组elapsed比OFF高4.277%；该固定工作负载未显示加速。OFF每组Host Draft/Target replay提交31/20，ON30/19；它们不是可靠的native执行occurrence或acceptance指标，不能直接按总耗时宣称每次FIA的速度。

输出序列hash种类数=1，只说明这些正常请求的greedy结果相同，不替代连续数值。ON每组9条实际Host Window descriptor有source_start_column>0，支持真实裁剪计划，不证明physical read-set。

全部重复保留；不采设备profiler的控制仍有一致的轻量Host wrapper。Source/plan/launcher/config/request关联以各case runner和joint为准。时段23:35–00:30双方有安静确认，最终仍核对资源心跳/设备观察/Host负载，不预设整段无外界干扰。

与旧C15约2K/15请求240输出的数据不同，不计算新旧总耗时加速率；不能把旧5152ms异常未重现归因为某一个未经隔离的原因。Base缺Target(4,32)仍按已知支持范围处理，不从性能请求升级成Full Target4 PASS。

证据：本轮raw/C28_prepare_01/PERF_WARM_{OFF,ON}_long_{01,02,03}/{campaign.json,profile.json,joint.json,profile-joint.json}与各launcher及C28_campaign_01/runner-result；小型归约R3_实际执行与性能归约.json逐case引用绝对路径/hash。
