# SPDX-License-Identifier: Apache-2.0
"""Bounded Python unwind after a legal backing copy, before live inputs exist.

No hardware fault is manufactured. After injection only Host metadata/export
and a Host-only next-scope guard are allowed. This is not a native failure or
normal backing completion proof.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from types import MethodType

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair6_storage import atomic_json, require


class InjectedMaterializeUnwindError(RuntimeError):
    """Python exception after successful copy return, not a native API error."""


class MaterializeUnwindProbe:
    def __init__(self, spec, output, identity):
        self.spec, self.output, self.identity = spec, Path(output), identity
        self.workspace = spec._draft_window_runtime_state.workspace
        self.saved, self.record, self.poisoned = [], None, False
        self.post_fault_clears, self.replays_after_record = [], 0

    def _wrap(self, owner, name, value):
        self.saved.append((owner, name, name in vars(owner), vars(owner).get(name)))
        setattr(owner, name, value)

    def __enter__(self):
        import torch

        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe

        require(not self.spec._draft_window_graph_characterization.recorder.enabled, "fault requires observer OFF")
        probe = self
        original_materialize = self.workspace.materialize
        original_copy, original_zero = torch.Tensor.copy_, torch.Tensor.zero_
        pointer = self.workspace.window_block_table.untyped_storage().data_ptr()
        pointers = {
            tensor.untyped_storage().data_ptr()
            for tensor in (
                self.workspace.window_block_table,
                self.workspace.valid_num_blocks,
                self.workspace.device_window_exact,
                self.workspace.cpu_window_exact,
                self.workspace.cpu_window_upper,
            )
        }

        def materialize(_workspace, **kwargs):
            require(probe.record is None, "fault must target first real materialize")
            context = probe.spec._require_current_draft_window_proposal()
            identity = kwargs["identity"]
            require(identity.mapping_epoch == context.mapping_epoch, "fault proposal/identity epoch")
            probe.record = dict(
                before_materialize_ns=time.monotonic_ns(),
                generation=identity.generation_id,
                epoch=identity.mapping_epoch,
                generation_identity=_json_safe(identity),
                request_ids=list(context.ordered_request_ids),
                backing=dict(
                    table_storage=pointer,
                    table_data_ptr=probe.workspace.window_block_table.data_ptr(),
                    shape=list(probe.workspace.window_block_table.shape),
                    dtype=str(probe.workspace.window_block_table.dtype),
                    device=str(probe.workspace.window_block_table.device),
                ),
                preserve_on_failure=kwargs.get("preserve_on_failure", False),
                active=identity.actual_request_count,
                padded=identity.padded_request_count,
            )
            return original_materialize(**kwargs)

        def copy(tensor, *args, **kwargs):
            result = original_copy(tensor, *args, **kwargs)
            if probe.record is not None and tensor.untyped_storage().data_ptr() == pointer and not probe.poisoned:
                probe.record.update(
                    copy_return_ns=time.monotonic_ns(),
                    injected_point="materialize_after_table_copy",
                    copied_shape=list(tensor.shape),
                )
                probe.poisoned = True
                raise InjectedMaterializeUnwindError("REPAIR9_MATERIALIZE_UNWIND:after_table_copy")
            return result

        def zero(tensor, *args, **kwargs):
            if probe.poisoned and tensor.untyped_storage().data_ptr() in pointers:
                # An old unsafe implementation must fail without actually
                # submitting its post-fault clear to a shared device.
                probe.post_fault_clears.append(dict(ns=time.monotonic_ns(), device=str(tensor.device)))
                raise RuntimeError("post-fault workspace clear refused by diagnostic guard")
            return original_zero(tensor, *args, **kwargs)

        try:
            self._wrap(self.workspace, "materialize", MethodType(materialize, self.workspace))
            self._wrap(torch.Tensor, "copy_", copy)
            self._wrap(torch.Tensor, "zero_", zero)
            for graph in self.spec.query_cudagraph_manager.graphs.values():
                original_graph_replay = graph.replay

                def one_replay(_graph, *args, original=original_graph_replay, **kwargs):
                    if probe.record is not None:
                        probe.replays_after_record += 1
                        raise RuntimeError("replay after materialize fault refused")
                    return original(*args, **kwargs)

                self._wrap(graph, "replay", MethodType(one_replay, graph))
            return self
        except BaseException:
            self._restore()
            raise

    def _restore(self):
        for owner, name, existed, value in reversed(self.saved):
            if existed:
                setattr(owner, name, value)
            else:
                delattr(owner, name)
        self.saved.clear()

    def __exit__(self, exc_type, exc, tb):
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe

        self._restore()  # Host-only restoration; no device recovery.
        runtime = self.spec._draft_window_runtime_state
        lease = runtime._lease_pool._current
        state = dict(
            quarantined_identity=_json_safe(runtime.quarantined_identity),
            lease_retained=lease is not None,
            lease_identity=_json_safe(lease.identity) if lease else None,
            live_inputs_absent=self.spec._draft_window_live_inputs is None and runtime._active_inputs is None,
            proposal_context_absent=self.spec._draft_window_proposal_context is None,
            graph_submission_uncertain=bool(getattr(self.spec, "_draft_window_graph_submission_uncertain", False)),
        )
        guard = dict(ns=time.monotonic_ns(), body_entered=False, rejected=False)
        if self.poisoned:
            try:
                with self.spec._draft_window_proposal_scope(self.spec.input_batch, dummy_run=False, is_profile=False):
                    guard["body_entered"] = True
                    raise RuntimeError("diagnostic refuses to actually reuse a failed generation")
            except RuntimeError as error:
                guard.update(rejected=not guard["body_entered"], error=str(error))
        atomic_json(
            self.output,
            dict(
                schema="repair9-materialize-unwind-v1",
                identity=self.identity,
                record=self.record,
                state=state,
                next_scope_guard=guard,
                post_fault_clear_attempts=self.post_fault_clears,
                replays_after_record=self.replays_after_record,
                poisoned=self.poisoned,
                isolated_exit_required=74,
                normal_reuse="NOT_PROVEN",
                native_partial_submission="NOT_SIMULATED",
                scope="PYTHON_AFTER_LEGAL_COPY_BEFORE_TYPED_INPUTS",
                post_fault_device_operations="NONE_BY_PROBE; clear/replay attempts are refused before submission",
            ),
        )


def check(document, campaign, launcher, expected, artifact):
    from tools.p7x_graph_repair5_evidence import audit_execution

    result = dict(status="INVALID_EVIDENCE", native_partial_submission="NOT_SIMULATED", normal_reuse="NOT_PROVEN")
    try:
        execution = audit_execution(document, campaign, launcher, expected, artifact, unwind=True)
        result["execution"] = execution
        require(execution["status"] == "EXECUTION_ASSOCIATED", "fault external execution association")
        require(document["schema"] == "repair9-materialize-unwind-v1" and document["poisoned"] is True, "fault schema")
        require(
            campaign["exception_type"] == "InjectedMaterializeUnwindError"
            and campaign["exception_message"] == "REPAIR9_MATERIALIZE_UNWIND:after_table_copy",
            "fault first cause",
        )
        record, state, guard = document["record"], document["state"], document["next_scope_guard"]
        require(
            launcher["host_start_ns"]
            <= record["before_materialize_ns"]
            < record["copy_return_ns"]
            <= guard["ns"]
            <= launcher["host_end_ns"],
            "fault/launcher interval",
        )
        require(
            record["injected_point"] == "materialize_after_table_copy" and record["preserve_on_failure"] is True,
            "wrong materialize fault/policy",
        )
        require(
            0 < record["active"] <= record["padded"] <= 4 and record["backing"]["device"].startswith("npu"),
            "not actual authorized device materialization",
        )
        backing, shape = record["backing"], record["copied_shape"]
        require(
            backing["dtype"] == "torch.int32"
            and len(backing["shape"]) == 2
            and backing["shape"][0] >= record["padded"]
            and len(shape) == 1
            and 0 < shape[0] <= backing["shape"][1],
            "fault backing/copy geometry",
        )
        require(
            all(type(backing[k]) is int and backing[k] > 0 for k in ("table_storage", "table_data_ptr")),
            "fault backing address missing",
        )
        require(
            len(record["request_ids"]) == len(set(record["request_ids"])) == record["active"]
            and record["request_ids"] == record["generation_identity"]["ordered_request_fingerprint"],
            "fault request/generation association",
        )
        require(
            document["isolated_exit_required"] == 74 and expected["unwind_point"] == "materialize_after_table_copy",
            "wrong declared isolation/point",
        )
        require(
            state["quarantined_identity"] == state["lease_identity"] == record["generation_identity"],
            "failed generation lease not retained",
        )
        require(
            record["generation_identity"]["generation_id"] == record["generation"]
            and record["generation_identity"]["mapping_epoch"] == record["epoch"],
            "fault generation mismatch",
        )
        require(
            state["lease_retained"]
            and state["live_inputs_absent"]
            and state["proposal_context_absent"]
            and state["graph_submission_uncertain"],
            "fault runtime state",
        )
        require(
            guard["rejected"] and not guard["body_entered"] and "backing is quarantined" in guard["error"],
            "next proposal Host guard did not reject",
        )
        require(
            not document["post_fault_clear_attempts"] and document["replays_after_record"] == 0,
            "post-fault clear/replay was attempted",
        )
        result.update(status="PASS_SCOPED_MATERIALIZE_UNWIND_ISOLATION", generation=record["generation"])
    except (KeyError, TypeError, ValueError, OSError) as error:
        result["error"] = str(error)
    return result


def main():
    from tools.p7x_graph_repair9_host_lengths import load_json

    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("artifact", "campaign", "launcher", "plan", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    try:
        result = check(
            load_json(args.artifact),
            load_json(args.campaign),
            load_json(args.launcher),
            load_json(args.plan)["cases"][args.case_id],
            args.artifact,
        )
    except (KeyError, TypeError, ValueError, OSError) as error:
        result = dict(status="INVALID_EVIDENCE", error=str(error))
    atomic_json(args.output, result)
    return 0 if result["status"] == "PASS_SCOPED_MATERIALIZE_UNWIND_ISOLATION" else 2


if __name__ == "__main__":
    raise SystemExit(main())
