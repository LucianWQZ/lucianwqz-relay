# SPDX-License-Identifier: Apache-2.0
"""Opt-in Host counter experiment; never a production or Graph support gate.

Verify keeps the original prepared-length D2H. Reuse requires its independently
joined certificate, waits the existing ordinary counter-copy event, and reads
only the current CPU staging tensor. No new copy/event-record/query is added.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import MethodType

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def load_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result

    return json.loads(Path(path).read_text(), object_pairs_hook=pairs)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_records(document):
    """CPU metadata equivalence only; not continuous model-output validation."""
    require(document["schema"] == "repair9-host-counter-v1", "counter artifact schema")
    mode, rows = document["mode"], document["records"]
    require(
        mode in ("verify", "reuse") and rows and not document["errors"] and document["poisoned"] is False,
        "empty/failed counter collection",
    )
    epochs, tickets, descriptors = [], [], set()
    for index, row in enumerate(rows):
        require(row["sequence"] == index, "missing/repeated counter record")
        nr, padded = row["active"], row["padded"]
        require(type(nr) is int and type(padded) is int and 0 < nr <= padded <= 4, "counter geometry")
        require(row["dtype"] == "torch.int32" and row["counter_dtype"] == "torch.int32", "exact dtype mismatch")
        require(row["postprocess_mapping_same_object"] is True, "postprocess mapping association")
        require(len(row["request_ids"]) == len(set(row["request_ids"])) == nr, "request identity")
        require(len(row["mapping"]) == len(set(row["mapping"])) == nr, "request mapping")
        require(all(type(v) is int and 0 <= v < document["counter_capacity"] for v in row["mapping"]), "mapping bounds")
        counts = row["post_target_counts"]
        require(
            len(counts) == nr and all(type(v) is int and 0 <= v <= row["max_model_len"] for v in counts),
            "invalid post-target counts",
        )
        require(row["query_width"] == 7, "frozen DSpark query width")
        derived = [min(v + 7, row["max_model_len"]) for v in counts] + [0] * (padded - nr)
        require(row["derived_full_exact"] == derived, "counter arithmetic/padding mismatch")
        if mode == "verify":
            require(
                row["legacy_full_exact"] == derived and row["legacy_d2h_called"] is True,
                "legacy prepared lengths disagree",
            )
        else:
            require(
                row["legacy_full_exact"] is None and row["legacy_d2h_called"] is False,
                "reuse unexpectedly called legacy D2H",
            )
        epochs.append(row["mapping_epoch"])
        tickets.append(row["target_copy_sequence"])
        descriptors.add((padded, padded * 7))
    require(all(type(v) is int for v in epochs + tickets), "invalid epoch/ticket type")
    require(all(a < b for a, b in zip(epochs, epochs[1:])), "stale/repeated proposal epoch")
    require(all(a < b for a, b in zip(tickets, tickets[1:])), "stale/repeated target-copy ticket")
    replays = document["replays"]
    require([r["mapping_epoch"] for r in replays] == epochs, "snapshot/Graph replay set mismatch")
    require(
        all(
            r["descriptor"] == [row["padded"], row["padded"] * 7] and r["return_is_none"] is True
            for r, row in zip(replays, rows)
        ),
        "replay/length geometry or None return mismatch",
    )
    require(
        all(r["mode"] == "FULL" and r["descriptor"] in ([1, 7], [2, 14], [4, 28]) for r in replays),
        "actual full Graph descriptor mismatch",
    )
    require({(1, 7), (2, 14), (4, 28)} <= descriptors, "missing real request buckets")
    require(any(r["active"] == 3 and r["padded"] == 4 for r in rows), "missing active3/padded4")
    return "PASS_SCOPED_HOST_LENGTH_EQUIVALENCE" if mode == "verify" else "SCOPED_EXPERIMENTAL_COUNTER_REUSE"


def check_joint(artifact, campaign_path, launcher_path, plan_path, case_id):
    from tools.p7x_graph_repair5_evidence import audit_execution, audit_normal_requests

    document = load_json(artifact)
    campaign, launcher, plan = [load_json(p) for p in (campaign_path, launcher_path, plan_path)]
    expected = plan["cases"][case_id]
    execution = audit_execution(document, campaign, launcher, expected, artifact)
    result = dict(status="INVALID_EVIDENCE", execution=execution)
    try:
        require(execution["status"] == "EXECUTION_ASSOCIATED", "external execution association failed")
        requests = audit_normal_requests(campaign, launcher, expected)
        require(requests["status"] == "PASS", "normal requests incomplete")
        require(document["config_sha256"] == campaign["config_sha256"], "counter config mismatch")
        require(document["request_sha256"] == expected["requests_sha256"], "counter workload mismatch")
        require(
            campaign.get("observer_enabled") is False and campaign.get("capture_profile") == "target4",
            "counter experiment requires observer-OFF Target4",
        )
        result.update(
            status=check_records(document),
            requests_status=requests["status"],
            execution_status=execution["status"],
            artifact=str(Path(artifact).resolve()),
            artifact_sha256=digest(artifact),
            case_id=case_id,
            linked_inputs={
                name: dict(path=str(Path(path).resolve()), sha256=digest(path))
                for name, path in [("campaign", campaign_path), ("launcher", launcher_path), ("plan", plan_path)]
            },
            scope="EXPERIMENTAL_LENGTH_SOURCE; NOT_CONTINUOUS_OUTPUT_NUMERIC_OR_GATE_ACCEPTANCE",
        )
    except (KeyError, ValueError, TypeError, OSError, IndexError) as error:
        result["error"] = str(error)
    return result


def validate_certificate(path, identity, config_sha, request_sha):
    certificate = load_json(path)
    require(certificate["status"] == "PASS_SCOPED_HOST_LENGTH_EQUIVALENCE", "unaccepted verify certificate")
    artifact = Path(certificate["artifact"])
    require(digest(artifact) == certificate["artifact_sha256"], "verify artifact changed")
    linked = certificate["linked_inputs"]
    for name in ("campaign", "launcher", "plan"):
        require(digest(linked[name]["path"]) == linked[name]["sha256"], "verify linked input changed: " + name)
    checked = check_joint(
        artifact, linked["campaign"]["path"], linked["launcher"]["path"], linked["plan"]["path"], certificate["case_id"]
    )
    require(checked == certificate, "verify joint no longer valid")
    document = load_json(artifact)
    require(check_records(document) == certificate["status"], "verify artifact no longer valid")
    require(document["mode"] == "verify", "reuse certificate is not verification")
    require(
        document["identity"]["source_sha"] == identity["source_sha"]
        and document["identity"]["source_tree"] == identity["source_tree"],
        "verify source mismatch",
    )
    require(
        document["config_sha256"] == config_sha and document["request_sha256"] == request_sha,
        "verify workload/config mismatch",
    )
    return dict(path=str(Path(path).resolve()), sha256=digest(path), source_run=document["identity"])


class CounterLengthTrial:
    """Instance-owned normal-request experiment, restored before child exit."""

    def __init__(self, runner, output, identity, config_sha, request_sha, *, mode, certificate=None):
        import torch

        self.torch, self.runner, self.spec = torch, runner, runner.speculator
        self.output, self.identity = Path(output), dict(identity)
        self.config_sha, self.request_sha, self.mode = config_sha, request_sha, mode
        require(mode in ("verify", "reuse"), "unknown counter mode")
        self.certificate = (
            validate_certificate(certificate, identity, config_sha, request_sha) if mode == "reuse" else None
        )
        self.counter, self.event = runner.num_computed_tokens_cpu, runner.num_computed_tokens_event
        require(self.counter.device.type == "cpu" and self.counter.dtype == torch.int32, "counter is not CPU int32")
        self.saved, self.records, self.replays, self.errors = [], [], [], []
        self.ticket = self.consumed = 0
        self.pending = None
        self.poisoned = False

    def _replace(self, owner, name, function):
        self.saved.append((owner, name, name in vars(owner), vars(owner).get(name)))
        original = getattr(owner, name)
        setattr(owner, name, MethodType(function, owner))
        return original

    def __enter__(self):
        probe = self

        def postprocess(_owner, *args, **kwargs):
            result = original_postprocess(*args, **kwargs)
            probe.ticket += 1
            # Actual caller passes the SAME InputBatch.idx_mapping to postprocess and propose.
            probe.pending = (probe.ticket, args[0] if args else kwargs["idx_mapping"])
            return result

        def snapshot(_owner, padded):
            require(not probe.poisoned, "counter experiment is poisoned")
            spec, batch = probe.spec, probe.spec.input_batch
            context = spec._require_current_draft_window_proposal()
            require(probe.pending is not None and probe.pending[0] > probe.consumed, "missing/stale target-copy ticket")
            ticket, idx = probe.pending
            require(idx is batch.idx_mapping, "postprocess/proposal mapping object changed")
            nr = batch.num_reqs
            mapping = [int(v) for v in batch.idx_mapping_np[:nr]]
            require(0 < nr <= padded <= 4 and len(set(mapping)) == nr, "counter active/padded extent")
            require(all(0 <= v < probe.counter.numel() for v in mapping), "counter index out of bounds")
            require(spec.num_query_per_req == 7, "counter experiment requires frozen DSpark K7")
            try:
                legacy = original_snapshot(padded) if probe.mode == "verify" else None
                # The existing Target postprocess-copy event, never ExternalEvent/query.
                probe.event.synchronize()
            except BaseException:
                probe.poisoned = True
                spec._draft_window_graph_submission_uncertain = True
                raise
            counts = [int(probe.counter[v]) for v in mapping]  # CPU only, after existing copy completion.
            require(all(0 <= v <= spec.max_model_len for v in counts), "invalid current computed count")
            derived = probe.torch.zeros(padded, dtype=probe.torch.int32, device="cpu")
            derived[:nr] = probe.torch.tensor([min(v + 7, spec.max_model_len) for v in counts], dtype=probe.torch.int32)
            if legacy is not None:
                require(legacy.device.type == "cpu" and legacy.dtype == probe.torch.int32, "legacy exact dtype")
                require(probe.torch.equal(legacy, derived), "postprocess count differs from actual prepared lengths")
            require(len(probe.records) < 512, "counter experiment record budget")
            probe.records.append(
                dict(
                    sequence=len(probe.records),
                    target_copy_sequence=ticket,
                    mapping_epoch=context.mapping_epoch,
                    request_ids=list(context.ordered_request_ids),
                    mapping=mapping,
                    active=nr,
                    padded=padded,
                    query_width=7,
                    max_model_len=spec.max_model_len,
                    post_target_counts=counts,
                    derived_full_exact=derived.tolist(),
                    legacy_full_exact=None if legacy is None else legacy.tolist(),
                    legacy_d2h_called=legacy is not None,
                    dtype=str(derived.dtype),
                    counter_dtype=str(probe.counter.dtype),
                    postprocess_mapping_same_object=True,
                    ordinary_copy_event_id=id(probe.event),
                )
            )
            probe.consumed = ticket
            return legacy if legacy is not None else derived

        def replay(_owner, descriptor):
            context = getattr(probe.spec, "_draft_window_proposal_context", None)
            result = original_replay(descriptor)
            if context is not None:
                probe.replays.append(
                    dict(
                        mapping_epoch=context.mapping_epoch,
                        descriptor=[descriptor.num_reqs, descriptor.num_tokens],
                        mode=descriptor.cg_mode.name,
                        return_is_none=result is None,
                    )
                )
            return result

        try:
            original_postprocess = self._replace(self.runner, "postprocess_sampled", postprocess)
            original_snapshot = self._replace(self.spec, "_snapshot_prepared_draft_seq_lens", snapshot)
            original_replay = self._replace(self.spec.query_cudagraph_manager, "run_fullgraph", replay)
            return self
        except BaseException:
            self._restore()
            raise

    def _restore(self):
        for owner, name, existed, value in reversed(self.saved):
            if existed:
                setattr(owner, name, value)
            else:
                delattr(owner, name)
        self.saved.clear()

    def __exit__(self, exc_type, exc, tb):
        if exc is not None:
            self.errors.append(repr(exc))
        self._restore()
        document = dict(
            schema="repair9-host-counter-v1",
            mode=self.mode,
            identity=self.identity,
            config_sha256=self.config_sha,
            request_sha256=self.request_sha,
            counter_capacity=self.counter.numel(),
            records=self.records,
            replays=self.replays,
            errors=self.errors,
            poisoned=self.poisoned,
            verify_certificate=self.certificate,
            scope="EXPERIMENTAL_LENGTH_SOURCE_ONLY_NOT_PRODUCTION_OR_CONTINUOUS_OUTPUT_NUMERIC",
            synchronization="existing ordinary Target counter-copy event wait; verify also retains original seq D2H",
            normal_backing_reuse="NOT_PROVEN",
            physical_read="NOT_PROVEN",
        )
        try:
            document["status"] = check_records(document)
        except (KeyError, TypeError, ValueError) as error:
            document.update(status="INVALID_EVIDENCE", check_error=str(error))
        (self.output / "counter-length-trial.json").write_text(json.dumps(document, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("artifact", "campaign", "launcher", "plan", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    try:
        result = check_joint(args.artifact, args.campaign, args.launcher, args.plan, args.case_id)
    except (KeyError, ValueError, TypeError, OSError, IndexError) as error:
        result = dict(status="INVALID_EVIDENCE", error=str(error))
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    return 0 if result["status"] in ("PASS_SCOPED_HOST_LENGTH_EQUIVALENCE", "SCOPED_EXPERIMENTAL_COUNTER_REUSE") else 2


if __name__ == "__main__":
    raise SystemExit(main())
