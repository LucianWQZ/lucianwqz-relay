# SPDX-License-Identifier: Apache-2.0
"""All-shape warmup stays outside collection and preserves the actual workload."""

import hashlib
import json
from contextlib import contextmanager
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair5_profile import warmup_requests
from tools.p7x_graph_repair7_campaign import add_warm_performance_cases


@pytest.mark.parametrize("all_groups", [False, True])
def test_warmup_preserves_lengths_batches_and_output_limit(all_groups):
    requests = [
        dict(label="short-1", prompts=[[1] * 32], max_tokens=16),
        dict(label="long-padded", prompts=[[2] * 2049] * 3, max_tokens=24),
    ]
    calls, labels = [], []

    class Probe:
        active = False

        @contextmanager
        def group(self, label):
            assert not self.active
            labels.append(label)
            yield

    def generate(prompts, params, **kwargs):
        assert kwargs == {"use_tqdm": False}
        calls.append((prompts, vars(params)))
        return [SimpleNamespace(outputs=[SimpleNamespace(token_ids=[7] * params.max_tokens)]) for _ in prompts]

    probe = Probe()
    result = warmup_requests(SimpleNamespace(generate=generate), SimpleNamespace, requests,
                             probe, all_groups=all_groups)
    expected = requests if all_groups else requests[:1]
    assert labels == ["warmup/" + r["label"] for r in expected]
    assert [c[0] for c in calls] == [r["prompts"] for r in expected]
    assert [c[1]["max_tokens"] for c in calls] == ([16, 24] if all_groups else [16])
    assert all(c[1]["temperature"] == 0.0 and c[1]["ignore_eos"] is True for c in calls)
    if all_groups:
        assert result["policy"] == "ALL_DECLARED_GROUPS"
        assert [len(g["token_ids"]) for g in result["groups"]] == [1, 3]
    else:
        assert result == dict(label="short-1", token_ids=[[7] * 16])


def test_new_workload_has_independent_hash_and_keeps_dependencies(tmp_path):
    (tmp_path / "requests").mkdir()
    path = tmp_path / "requests/performance-long.json"
    path.write_text(json.dumps([dict(label="long", prompts=["text"], max_tokens=16)]))
    cases = {}
    for arm in ("OFF", "ON"):
        for name in [f"PERF_{arm}_long_{i:02}" for i in range(1, 4)] + [
            "PROFILE_OFF_long_normal" if arm == "OFF" else "PROFILE_ON_long_materialize"
        ]:
            cases[name] = dict(case_id=name, request_path="old/combined.json", requests_sha256="old-hash",
                               argv=[name, "--requests", "old/combined.json"],
                               launch_argv=[name, "--requests", "old/combined.json"],
                               acceptance_identity=dict(case_id=name),
                               validation_commands=[dict(argv=[name, "old/combined.json"])],
                               dependencies=["CONFIG", "B0"])
    before = json.dumps(cases, sort_keys=True)
    add_warm_performance_cases(cases, tmp_path, tmp_path / "out")
    originals = {k: v for k, v in cases.items() if "WARM" not in k}
    assert json.dumps(originals, sort_keys=True) == before
    new = {k: v for k, v in cases.items() if "WARM" in k}
    assert len(new) == 8
    for name, row in new.items():
        assert row["acceptance_identity"]["case_id"] == row["case_id"] == name
        assert row["requests_sha256"] == hashlib.sha256(path.read_bytes()).hexdigest()
        assert row["dependencies"] == ["CONFIG", "B0"]
        assert row["argv"][-1] == row["launch_argv"][-1] == "--repair9-warmup-all"
        assert row["validation_commands"][0]["argv"] == [name, str(path)]
        if "_ON_" in name:
            assert "_ON_long_" in name  # Existing diagnostic checker requires actual S>0.


def test_missing_opt_in_and_bad_workload_do_not_add_cases(tmp_path):
    cases = {}
    add_warm_performance_cases(cases, tmp_path, tmp_path)
    assert cases == {}
    (tmp_path / "requests").mkdir()
    (tmp_path / "requests/performance-long.json").write_text('[{"prompts": ["x"], "max_tokens": 15}]')
    with pytest.raises(ValueError, match="sixteen"):
        add_warm_performance_cases(cases, tmp_path, tmp_path)
