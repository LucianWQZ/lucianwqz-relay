# SPDX-License-Identifier: Apache-2.0
"""Queue/event flow must not be promoted to model or generation proof."""
import json
import subprocess
import sys
from pathlib import Path

import pytest

from tools.p7x_graph_repair6_trace import analyze


@pytest.mark.parametrize("leaf,flow_name,kind", [
    ("EVENT_RECORD", "torch_to_npu", "DEVICE_EVENT_FLOW"),
    ("EVENT_WAIT", "torch_to_npu", "DEVICE_EVENT_FLOW"),
    ("dequeue@record", "enqueue_to_dequeue", "HOST_QUEUE_EVENT_FLOW"),
    ("MODEL_EXECUTE", "torch_to_npu", "MODEL_EXECUTION_CONTEXT_FLOW"),
    ("unknown-task", "torch_to_npu", "OTHER_EXPLICIT_FLOW"),
])
def test_flow_endpoint_classification_and_missing_generation(leaf, flow_name, kind):
    events = [
        dict(ph="X", name="repair5/Draft_REPLAY_SUBMIT", pid=1, tid=1, ts=0, dur=5,
             args=dict(generation=123)),  # Host value cannot label native occurrence.
        dict(ph="s", name=flow_name, cat="flow", id=9, pid=1, tid=1, ts=1),
        dict(ph="f", name=flow_name, cat="flow", id=9, pid=2, tid=3, ts=11),
        dict(ph="X", name=leaf, pid=2, tid=3, ts=10, dur=3),
    ]
    # A broad enclosing model cannot convert its nested EVENT_RECORD into execution flow.
    if leaf != "MODEL_EXECUTE":
        events.append(dict(ph="X", name="MODEL_EXECUTE", pid=2, tid=3, ts=9, dur=10))
    result = analyze(events)
    assert result["replays"][0]["direct_flow_kinds"] == {kind: 1}
    classified = result["classified_coverage"]
    assert classified["any_flow_replays"] == 1
    assert classified["model_execution_context_flow_replays"] == (kind == "MODEL_EXECUTION_CONTEXT_FLOW")
    assert classified["generation_bound_execution_flow"].startswith("NOT_AVAILABLE")
    damaged = analyze(events + [events[2]])
    assert damaged["flow_counts"] == {"AMBIGUOUS": 1}
    assert damaged["classified_coverage"]["any_flow_replays"] == 0


@pytest.mark.parametrize("entry", ["direct", "module"])
def test_real_trace_cli_does_not_import_tools_bisect(tmp_path, entry):
    repo = Path(__file__).resolve().parents[3]
    events = [
        dict(ph="X", name="repair5/Draft_REPLAY_SUBMIT", pid=1, tid=1, ts=0, dur=5),
        dict(ph="s", name="torch_to_npu", cat="flow", id=1, pid=1, tid=1, ts=1),
        dict(ph="f", name="torch_to_npu", cat="flow", id=1, pid=2, tid=2, ts=11),
        dict(ph="X", name="EVENT_RECORD", pid=2, tid=2, ts=10, dur=3),
    ]
    trace, output = tmp_path / "trace.json", tmp_path / "result.json"
    trace.write_text(json.dumps(events))
    command = ([sys.executable, str(repo / "tools/p7x_graph_repair6_trace.py")] if entry == "direct" else
               [sys.executable, "-m", "tools.p7x_graph_repair6_trace"])
    result = subprocess.run(command + ["--trace", str(trace), "--output", str(output)],
                            cwd=repo, capture_output=True, text=True, timeout=15)
    assert result.returncode == 0, result.stderr
    assert json.loads(output.read_text())["classified_coverage"]["device_event_flow_replays"] == 1
