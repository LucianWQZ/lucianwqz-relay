# SPDX-License-Identifier: Apache-2.0
"""Fail inside actual materialize, before typed live inputs exist (CPU only)."""

import hashlib
import json
import os
from types import SimpleNamespace

import pytest
import torch

from tests.ut.spec_decode.test_draft_window_eager import _harness
from tools.p7x_graph_repair9_materialize_fault import InjectedMaterializeUnwindError, MaterializeUnwindProbe, check


def test_graph_exception_before_live_inputs_blocks_next_proposal():
    owner, batch = _harness(query_width=7)
    owner._draft_window_graph_characterization = SimpleNamespace()
    with (
        pytest.raises(RuntimeError, match="before live"),
        owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False),
    ):
        raise RuntimeError("before live")
    assert owner._draft_window_graph_submission_uncertain
    assert owner._draft_window_live_inputs is owner._draft_window_proposal_context is None
    with (
        pytest.raises(RuntimeError, match="backing is quarantined"),
        owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False),
    ):
        pytest.fail("failed Graph owner must not enter another proposal")


@pytest.mark.parametrize("graph", [False, True])
def test_partial_materialize_preserves_graph_lease_and_does_no_post_fault_clear(monkeypatch, graph):
    owner, batch = _harness(query_width=7)
    if graph:
        owner._draft_window_graph_characterization = SimpleNamespace()
    workspace = owner._draft_window_runtime_state.workspace
    pointer = workspace.window_block_table.untyped_storage().data_ptr()
    original_copy, original_zero = torch.Tensor.copy_, torch.Tensor.zero_
    fired, clears = [], []

    def copy(tensor, *args, **kwargs):
        result = original_copy(tensor, *args, **kwargs)
        if tensor.untyped_storage().data_ptr() == pointer and not fired:
            fired.append(True)
            raise RuntimeError("after legal table copy")
        return result

    def zero(tensor):
        if fired and tensor.untyped_storage().data_ptr() == pointer:
            clears.append(True)
        return original_zero(tensor)

    monkeypatch.setattr(torch.Tensor, "copy_", copy)
    monkeypatch.setattr(torch.Tensor, "zero_", zero)
    runtime = owner._draft_window_runtime_state
    with (
        pytest.raises(RuntimeError, match="after legal table copy"),
        owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False),
    ):
        owner._materialize_draft_window_read_inputs(num_reqs=2, num_reqs_padded=4)
    assert fired
    if graph:
        assert not clears
        assert runtime.quarantined_identity is not None
        assert runtime._lease_pool._current is not None
        assert runtime._active_inputs is None  # failure precedes build_inputs.
        assert owner._draft_window_graph_submission_uncertain
        with (
            pytest.raises(RuntimeError, match="backing is quarantined"),
            owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False),
        ):
            pytest.fail("must refuse reuse at Host guard")
    else:
        assert clears and runtime.quarantined_identity is None
        assert runtime._lease_pool._current is None
        # Existing non-Graph CPU cleanup/recovery contract is retained.
        with owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False):
            inputs = owner._materialize_draft_window_read_inputs(num_reqs=2, num_reqs_padded=4)
            owner._draft_window_live_inputs = inputs


def actual_fault_artifact(tmp_path):
    owner, batch = _harness(query_width=7)
    owner._draft_window_graph_characterization = SimpleNamespace(recorder=SimpleNamespace(enabled=False))
    owner.query_cudagraph_manager = SimpleNamespace(graphs={})
    identity = dict(
        run_id="cpu-only",
        case_id="UNWIND_materialize_after_copy",
        attempt_id="1",
        source_sha="a" * 40,
        source_tree="b" * 40,
        driver_mode="B-observer-off",
        process_id=os.getpid(),
        engine_id=123,
    )
    path = tmp_path / "materialize-unwind.json"
    probe = MaterializeUnwindProbe(owner, path, identity)
    original_copy, original_zero = torch.Tensor.copy_, torch.Tensor.zero_
    with (
        pytest.raises(InjectedMaterializeUnwindError),
        probe,
        owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False),
    ):
        owner._materialize_draft_window_read_inputs(num_reqs=2, num_reqs_padded=4)
    assert torch.Tensor.copy_ is original_copy and torch.Tensor.zero_ is original_zero
    assert not probe.saved
    return path, json.loads(path.read_text())


@pytest.mark.parametrize("damage", [None, "identity", "guard", "clear", "replay", "device", "exit", "timeout"])
def test_actual_fault_probe_and_external_joint_reject_damaged_evidence(tmp_path, damage):
    artifact, document = actual_fault_artifact(tmp_path)
    identity = document["identity"]
    # CPU fixture tests the checker structure; this is never published as NPU evidence.
    document["record"]["backing"]["device"] = "npu:0"
    argv = ["python", "run"]
    expected = dict(
        acceptance_identity=identity,
        argv=argv,
        launch_argv=["launch", "--", *argv],
        outputs=str(tmp_path),
        requests_sha256="c" * 64,
        unwind_point="materialize_after_table_copy",
    )
    launcher = dict(
        identity,
        pid=identity["process_id"],
        argv=argv,
        requests_sha256="c" * 64,
        host_start_ns=document["record"]["before_materialize_ns"] - 1,
        host_end_ns=document["next_scope_guard"]["ns"] + 1,
        status="EXITED",
        returncode=74,
        signal=None,
        timeout=False,
    )
    campaign = dict(
        identity=identity,
        status="EXCEPTION",
        startup_complete=True,
        diagnostic_quarantine="PROCESS_EXIT_74_NO_REUSE",
        exception_type="InjectedMaterializeUnwindError",
        exception_message="REPAIR9_MATERIALIZE_UNWIND:after_table_copy",
        request_manifest=dict(sha256="c" * 64),
    )
    if damage == "identity":
        document["state"]["lease_identity"]["mapping_epoch"] += 1
    elif damage == "guard":
        document["next_scope_guard"]["body_entered"] = True
    elif damage == "clear":
        document["post_fault_clear_attempts"].append(dict(ns=1))
    elif damage == "replay":
        document["replays_after_record"] = 1
    elif damage == "device":
        document["record"]["backing"]["device"] = "cpu"
    elif damage == "exit":
        launcher["returncode"] = 0
    elif damage == "timeout":
        launcher["timeout"] = True
    artifact.write_text(json.dumps(document))
    campaign["diagnostic_artifacts"] = {
        artifact.name: dict(bytes=artifact.stat().st_size, sha256=hashlib.sha256(artifact.read_bytes()).hexdigest())
    }
    result = check(document, campaign, launcher, expected, artifact)
    assert (result["status"] == "PASS_SCOPED_MATERIALIZE_UNWIND_ISOLATION") is (damage is None), result


@pytest.mark.parametrize("damage", [None, "checker", "exit", "point", "timeout"])
def test_runner_requires_materialize_checker_and_exact_expected_exit(damage):
    from tools.p7x_graph_repair6_runner import adjudicate_records

    name = "UNWIND_materialize_after_copy"
    plan = dict(cases={name: dict(unwind_point="materialize_after_table_copy")})
    records = [
        dict(argv=["launch"], returncode=74, timeout=False, kind="launch", status="EXECUTION_FAILED"),
        dict(
            argv=["python", "/fixed/tools/p7x_graph_repair9_materialize_fault.py"],
            returncode=0,
            timeout=False,
            kind="read_only_acceptance",
            status="COMMAND_COMPLETED_NOT_GATE_PASS",
        ),
    ]
    if damage == "checker":
        records[1]["argv"][-1] = "/fixed/tools/p7x_graph_repair8_unwind.py"
    elif damage == "exit":
        records[0]["returncode"] = -9
    elif damage == "point":
        plan["cases"][name]["unwind_point"] = "after_update"
    elif damage == "timeout":
        records[0]["timeout"] = True
    assert adjudicate_records(plan, name, records)["dependency_satisfied"] is (damage is None)


def test_graph_metadata_publication_failure_keeps_live_lease(monkeypatch):
    owner, batch = _harness(query_width=7)
    owner._draft_window_graph_characterization = SimpleNamespace()
    runtime = owner._draft_window_runtime_state
    clears = []
    original = runtime.workspace._zero_all

    def clear():
        clears.append(True)
        original()

    monkeypatch.setattr(runtime.workspace, "_zero_all", clear)
    with (
        pytest.raises((ValueError, RuntimeError)),
        owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False),
    ):
        inputs = owner._materialize_draft_window_read_inputs(num_reqs=2, num_reqs_padded=4)
        owner._draft_window_live_inputs = inputs
        metadata = owner.model_state.attn_metadata
        runtime.publish_metadata(inputs, metadata, target_metadata=metadata)
    assert not clears
    assert runtime.quarantined_identity == inputs.identity
    assert runtime._active_inputs is inputs and runtime._lease_pool._current is inputs.lease
