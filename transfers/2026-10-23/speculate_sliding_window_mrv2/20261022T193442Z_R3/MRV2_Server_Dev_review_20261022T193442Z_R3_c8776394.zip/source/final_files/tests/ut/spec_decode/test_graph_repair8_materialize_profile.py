# SPDX-License-Identifier: Apache-2.0
"""Profile existing materialization on CPU without adding a device operation."""

import json
from types import SimpleNamespace

import pytest
import torch

from tests.ut.spec_decode.test_draft_window_eager import _harness
from tools.p7x_graph_repair5_profile import RequestProfiler


@pytest.mark.parametrize("nested", [False, True])
@pytest.mark.parametrize("counter_experiment", [False, True])
def test_exact_materialize_ranges_and_restore(monkeypatch, tmp_path, nested, counter_experiment):
    owner, batch = _harness(query_width=7)
    owner.propose = lambda: None
    manager = SimpleNamespace(graphs={}, run_fullgraph=lambda desc: None, _update_full_graph_params=lambda: None)
    owner.query_cudagraph_manager = manager
    runner = SimpleNamespace(speculator=owner, cudagraph_manager=SimpleNamespace(graphs={}, run_fullgraph=lambda: None))
    monkeypatch.setattr(torch.npu, "Event", lambda: pytest.fail("profiling must not add a completion event"))
    path = tmp_path / "profile.json"
    probe = RequestProfiler(
        runner, tmp_path, {}, enabled=False, materialize_ranges=nested, counter_length_experiment=counter_experiment
    )
    pointer = owner._draft_window_runtime_state.workspace.storage_pointers
    with probe:
        probe.begin_active()
        with owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False):
            inputs = owner._materialize_draft_window_read_inputs(num_reqs=2, num_reqs_padded=4)
            owner._draft_window_live_inputs = inputs
    result = json.loads(path.read_text())
    assert result["materialize_subranges"] is nested
    assert result["counter_length_experiment"] is counter_experiment
    assert result["scope"] == (
        "EXPERIMENTAL_COUNTER_REUSE_NORMAL_DISPATCH_OBSERVER_OFF" if counter_experiment else "NORMAL_OBSERVER_OFF"
    )
    if nested:
        assert (
            "Target counter-copy event wait" in result["materialize_timing_contract"]["snapshot"]
        ) is counter_experiment
    assert owner._draft_window_runtime_state.workspace.storage_pointers == pointer
    assert not probe.saved and not probe.call_stack
    assert "_snapshot_prepared_draft_seq_lens" not in vars(owner)
    total = next(c for c in result["calls"] if c["label"] == "Draft_materialize")
    children = [c for c in result["calls"] if c["label"].startswith("Draft_materialize_")]
    if nested:
        assert {c["label"] for c in children} == {
            "Draft_materialize_exact_length_snapshot",
            "Draft_materialize_epoch_validate",
            "Draft_materialize_runtime",
            "Draft_materialize_workspace",
            "Draft_materialize_build_inputs",
        }
        assert len({c["call_id"] for c in result["calls"]}) == len(result["calls"])
        assert all(total["start_ns"] <= c["start_ns"] < c["end_ns"] <= total["end_ns"] for c in children)
        assert all(c["proposal_context_id"] == total["proposal_context_id"] for c in children)
        assert all(c["proposal_mapping_epoch"] == total["proposal_mapping_epoch"] for c in children)
        runtime = next(c for c in children if c["label"] == "Draft_materialize_runtime")
        workspace = next(c for c in children if c["label"] == "Draft_materialize_workspace")
        assert workspace["parent_call_id"] == runtime["call_id"]
    else:
        assert not children and "call_id" not in total
