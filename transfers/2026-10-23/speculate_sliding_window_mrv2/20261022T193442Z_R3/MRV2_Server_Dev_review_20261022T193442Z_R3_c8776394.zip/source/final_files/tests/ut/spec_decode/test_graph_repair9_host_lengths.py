# SPDX-License-Identifier: Apache-2.0
"""CPU-only counter ownership/equivalence tests, never a device completion test."""

import json
from copy import deepcopy
from types import SimpleNamespace

import pytest
import torch

from tools.p7x_graph_repair9_host_lengths import (
    CounterLengthTrial,
    check_joint,
    check_records,
    digest,
    load_json,
    validate_certificate,
)


def harness(tmp_path, mode="verify", fail_event=False, mismatch=False):
    counter = torch.full((4,), -1, dtype=torch.int32)
    events, legacy_calls = [], []
    batch = SimpleNamespace(idx_mapping=object(), idx_mapping_np=[1, 0, 2, 3], num_reqs=2)
    context = SimpleNamespace(mapping_epoch=1, ordered_request_ids=["r1", "r0"])

    def synchronize():
        events.append("ordinary_counter_event_wait")
        if fail_event:
            raise RuntimeError("native wait failed")
        counter.copy_(torch.tensor([4094, 20, 30, 40], dtype=torch.int32))

    def snapshot(padded):
        legacy_calls.append(padded)
        values = [27, 4096] + [0] * (padded - 2)
        if mismatch:
            values[0] -= 1
        return torch.tensor(values, dtype=torch.int32)

    spec = SimpleNamespace(
        input_batch=batch,
        num_query_per_req=7,
        max_model_len=4096,
        _draft_window_proposal_context=context,
        _require_current_draft_window_proposal=lambda: context,
        _snapshot_prepared_draft_seq_lens=snapshot,
        query_cudagraph_manager=SimpleNamespace(run_fullgraph=lambda desc: None),
    )
    runner = SimpleNamespace(
        speculator=spec,
        num_computed_tokens_cpu=counter,
        num_computed_tokens_event=SimpleNamespace(synchronize=synchronize),
        postprocess_sampled=lambda *args: None,
    )
    # Constructor's certificate check is tested separately against actual joint inputs.
    trial = CounterLengthTrial(runner, tmp_path, {}, "cfg", "req", mode="verify")
    trial.mode = mode
    return runner, spec, trial, events, legacy_calls


@pytest.mark.parametrize("mode", ["verify", "reuse"])
def test_owned_current_counter_wait_mapping_padding_and_clamp(tmp_path, mode):
    runner, spec, trial, events, legacy = harness(tmp_path, mode)
    with trial:
        runner.postprocess_sampled(spec.input_batch.idx_mapping)
        result = spec._snapshot_prepared_draft_seq_lens(4)
        assert result.tolist() == [27, 4096, 0, 0] and result.dtype == torch.int32
        # CPU result owns its storage and cannot become next-generation staging data.
        runner.num_computed_tokens_cpu.zero_()
        assert result.tolist() == [27, 4096, 0, 0]
        with pytest.raises(ValueError, match="stale"):
            spec._snapshot_prepared_draft_seq_lens(4)
    assert events == ["ordinary_counter_event_wait"]
    assert legacy == ([4] if mode == "verify" else [])
    assert not trial.saved and runner.postprocess_sampled(spec.input_batch.idx_mapping) is None


@pytest.mark.parametrize("damage", ["mapping_object", "mapping_bounds", "counter_dtype", "mismatch"])
def test_refuses_bad_mapping_dtype_and_real_length_disagreement(tmp_path, damage):
    runner, spec, trial, _, _ = harness(tmp_path, mismatch=damage == "mismatch")
    if damage == "counter_dtype":
        runner.num_computed_tokens_cpu = torch.zeros(4, dtype=torch.int64)
        with pytest.raises(ValueError, match="CPU int32"):
            CounterLengthTrial(runner, tmp_path, {}, "cfg", "req", mode="verify")
        return
    with trial:
        runner.postprocess_sampled(object() if damage == "mapping_object" else spec.input_batch.idx_mapping)
        if damage == "mapping_bounds":
            spec.input_batch.idx_mapping_np[0] = 4
        with pytest.raises(ValueError):
            spec._snapshot_prepared_draft_seq_lens(4)
    assert not trial.records


def test_failed_existing_event_poisoned_host_export_without_second_device_operation(tmp_path):
    runner, spec, trial, events, legacy = harness(tmp_path, "reuse", fail_event=True)
    with pytest.raises(RuntimeError, match="native wait failed"), trial:
        runner.postprocess_sampled(spec.input_batch.idx_mapping)
        spec._snapshot_prepared_draft_seq_lens(4)
    assert trial.poisoned and spec._draft_window_graph_submission_uncertain
    document = load_json(tmp_path / "counter-length-trial.json")
    assert document["status"] == "INVALID_EVIDENCE" and document["errors"]
    assert events == ["ordinary_counter_event_wait"] and not legacy and not trial.saved


def complete_document():
    rows, replays = [], []
    for index, nr in enumerate((1, 2, 3, 4)):
        padded = 4 if nr == 3 else nr
        rows.append(
            dict(
                sequence=index,
                target_copy_sequence=index + 1,
                mapping_epoch=index + 10,
                request_ids=[f"r{i}" for i in range(nr)],
                mapping=list(range(nr)),
                active=nr,
                padded=padded,
                dtype="torch.int32",
                counter_dtype="torch.int32",
                postprocess_mapping_same_object=True,
                post_target_counts=[1024] * nr,
                max_model_len=4096,
                query_width=7,
                derived_full_exact=[1031] * nr + [0] * (padded - nr),
                legacy_full_exact=[1031] * nr + [0] * (padded - nr),
                legacy_d2h_called=True,
            )
        )
        replays.append(
            dict(mapping_epoch=index + 10, mode="FULL", descriptor=[padded, padded * 7], return_is_none=True)
        )
    return dict(
        schema="repair9-host-counter-v1",
        mode="verify",
        records=rows,
        replays=replays,
        errors=[],
        poisoned=False,
        counter_capacity=4,
    )


@pytest.mark.parametrize("damage", [None, "padded", "dtype", "epoch", "replay", "missing", "poisoned"])
def test_complete_strict_geometry_and_generation_coverage(damage):
    d = complete_document()
    if damage == "padded":
        d["records"][2]["derived_full_exact"][-1] = 1
    elif damage == "dtype":
        d["records"][0]["dtype"] = "torch.int64"
    elif damage == "epoch":
        d["records"][1]["mapping_epoch"] = d["records"][0]["mapping_epoch"]
    elif damage == "replay":
        d["replays"][0]["descriptor"] = [4, 28]
    elif damage == "missing":
        d["records"].pop(2)
        d["replays"].pop(2)
    elif damage == "poisoned":
        d["poisoned"] = True
    if damage is None:
        assert check_records(d) == "PASS_SCOPED_HOST_LENGTH_EQUIVALENCE"
    else:
        with pytest.raises(ValueError):
            check_records(d)


def joint_fixture(tmp_path):
    requests = [dict(label="r", prompts=["Hello"], max_tokens=16)]
    rp = tmp_path / "requests.json"
    rp.write_text(json.dumps(requests))
    identity = dict(
        run_id="host-only",
        case_id="COUNTER_LENGTH_VERIFY",
        attempt_id="1",
        source_sha="a" * 40,
        source_tree="b" * 40,
        process_id=123,
        engine_id=456,
        driver_mode="B-observer-off",
    )
    argv = ["python", "run"]
    expected = dict(
        acceptance_identity=identity,
        argv=argv,
        launch_argv=["launch", "--", *argv],
        outputs=str(tmp_path),
        request_path=str(rp),
        requests_sha256=digest(rp),
    )
    launcher = dict(
        identity,
        pid=123,
        argv=argv,
        requests_sha256=digest(rp),
        host_start_ns=1,
        host_end_ns=100,
        status="EXITED",
        signal=None,
        timeout=False,
        returncode=0,
    )
    document = dict(complete_document(), identity=identity, config_sha256="cfg", request_sha256=digest(rp))
    artifact = tmp_path / "counter-length-trial.json"
    artifact.write_text(json.dumps(document))
    campaign = dict(
        identity=identity,
        status="OK",
        startup_complete=True,
        observer_enabled=False,
        capture_profile="target4",
        config_sha256="cfg",
        request_manifest=dict(sha256=digest(rp), entries=requests),
        diagnostic_artifacts={artifact.name: dict(sha256=digest(artifact), bytes=artifact.stat().st_size)},
        outputs=[
            dict(
                label="r",
                prompts=["Hello"],
                prompt_token_ids=[[1]],
                token_ids=[[2] * 16],
                host_start_ns=2,
                host_end_ns=99,
            )
        ],
    )
    paths = [tmp_path / name for name in ("campaign.json", "launcher.json", "plan.json")]
    for p, d in zip(paths, (campaign, launcher, dict(cases={identity["case_id"]: expected}))):
        p.write_text(json.dumps(d))
    return artifact, paths, document


@pytest.mark.parametrize("damage", [None, "artifact", "launcher", "plan", "config", "source", "request"])
def test_certificate_rechecks_all_external_inputs_and_source_identity(tmp_path, damage):
    artifact, paths, document = joint_fixture(tmp_path)
    result = check_joint(artifact, *paths, document["identity"]["case_id"])
    assert result["status"] == "PASS_SCOPED_HOST_LENGTH_EQUIVALENCE", result
    certificate = tmp_path / "certificate.json"
    certificate.write_text(json.dumps(result))
    identity = deepcopy(document["identity"])
    config, request = "cfg", document["request_sha256"]
    if damage in ("artifact", "launcher", "plan"):
        p = artifact if damage == "artifact" else paths[1 if damage == "launcher" else 2]
        p.write_text(p.read_text() + " ")
    elif damage == "config":
        config = "wrong"
    elif damage == "source":
        identity["source_sha"] = "c" * 40
    elif damage == "request":
        request = "wrong"
    if damage is None:
        assert validate_certificate(certificate, identity, config, request)["sha256"] == digest(certificate)
    else:
        with pytest.raises(ValueError):
            validate_certificate(certificate, identity, config, request)


def test_duplicate_json_keys_refused(tmp_path):
    path = tmp_path / "bad.json"
    path.write_text('{"status": "PASS", "status": "FAIL"}')
    with pytest.raises(ValueError, match="duplicate JSON"):
        load_json(path)


def test_experiment_default_off_and_incompatible_modes_refused():
    from tools.p7x_graph_repair2 import parse_args

    argv = [
        "run",
        "--case",
        "B-observer-off",
        "--run-id",
        "r",
        "--attempt",
        "1",
        "--expected-sha",
        "a" * 40,
        "--vllm-repo",
        "/pin",
        "--target-model",
        "/target",
        "--draft-model",
        "/draft",
        "--fixture-manifest",
        "/fixture",
        "--output",
        "/out",
    ]
    assert parse_args(argv).repair9_counter_lengths == "off"
    with pytest.raises(SystemExit):
        parse_args(argv + ["--repair9-counter-lengths", "verify"])  # Target4 required.
    argv += ["--repair5-capture-profile", "target4"]
    assert parse_args(argv + ["--repair9-counter-lengths", "verify"]).repair9_counter_lengths == "verify"
    with pytest.raises(SystemExit):
        parse_args(argv + ["--repair9-counter-lengths", "reuse"])  # Joint certificate required.
    with pytest.raises(SystemExit):
        parse_args(argv + ["--repair9-counter-lengths", "verify", "--repair5-profile", "normal"])


def test_counter_plan_retains_exact_dependencies_and_independent_workload(tmp_path):
    from tools.p7x_graph_repair7_campaign import add_counter_length_cases

    (tmp_path / "requests").mkdir()
    request = tmp_path / "requests/counter-lengths.json"
    request.write_text(json.dumps([dict(label=str(n), prompts=["hello"] * n, max_tokens=16) for n in (1, 2, 3, 4)]))
    cases = {}
    for source in ("PERF_ON_long_01", "PROFILE_ON_long_materialize"):
        cases[source] = dict(
            argv=[
                "python",
                source,
                "--requests",
                "old.json",
                "--repair5-profile",
                "normal" if source.startswith("PROFILE") else "control",
            ],
            launch_argv=[
                "launch",
                source,
                "--requests",
                "old.json",
                "--repair5-profile",
                "normal" if source.startswith("PROFILE") else "control",
            ],
            request_path="old.json",
            validation_commands=[dict(argv=[source]), dict(argv=[source])],
            acceptance_identity=dict(case_id=source),
            dependencies=["CONFIG", "B0"],
            outputs="old",
            require_host_subrange_coverage=True,
        )
    original = deepcopy(cases)
    add_counter_length_cases(cases, tmp_path, tmp_path / "out", tmp_path / "repo", "python")
    assert {k: cases[k] for k in original} == original
    assert len(cases) == 11
    for name, case in cases.items():
        if name in original:
            continue
        assert case["requests_sha256"] == digest(request)
        assert case["acceptance_identity"]["case_id"] == name
        assert case["dependencies"][:2] == ["CONFIG", "B0"]
        assert case["argv"][case["argv"].index("--repair5-capture-profile") + 1] == "target4"
        if case["counter_length_mode"] == "reuse":
            assert case["dependencies"][-1] == "COUNTER_LENGTH_VERIFY"
            assert case["argv"][-2:] == [
                "--repair9-counter-verify",
                str(tmp_path / "out/COUNTER_LENGTH_VERIFY/counter-joint.json"),
            ]
            assert len(case["validation_commands"]) == 3
        elif case["counter_length_mode"] == "verify":
            assert len(case["validation_commands"]) == 2
