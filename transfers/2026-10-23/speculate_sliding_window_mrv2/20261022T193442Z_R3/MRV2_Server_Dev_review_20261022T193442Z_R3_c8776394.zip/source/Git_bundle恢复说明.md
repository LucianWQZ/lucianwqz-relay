# Git bundle恢复说明

本包包含Repair7之后至C28的28个本地提交，R3新增9个提交；不是GitHub发布包。前置commit `7a9f4aae1ebe5c5f3d4876ec9b49926949dfae14`（tree6dd40a67a500480556068be8b6ebcd977e3cc3e8）及其可达对象必须存在；vLLM另用固定pin84030bbe3d74d99bad477a3d2e37a973ccd8865c，不含权重、凭据和native overlay。

在已核验Repair7基线的独立仓库中执行：

```bash
git bundle verify /实际下载路径/MRV2_Graph_R3_after_Repair7.bundle
git fetch /实际下载路径/MRV2_Graph_R3_after_Repair7.bundle refs/heads/dev/mrv2-graph-server-20261022T050438Z:refs/heads/recovered-c28-r3
git rev-parse refs/heads/recovered-c28-r3 refs/heads/recovered-c28-r3^{tree}
```

预期SHA c877639472386aedeb7df11f15b6bf75c078261c，tree 729a2d3bc76ac814d1555cb4a457b513bb0b413f。服务器在新bare仓中只取Repair7，确认C28对象事前不存在，再verify/fetch并核对SHA/tree，结果见bundle_restore_verification.json；不等同用户接收端已校验。运行需恢复已验证的overlay/env、独立candidate及有效新资源授权，不自动续用旧设备窗口。
