# 团队工具适用性（本轮只读）

读取README.zh.md、config.py及aisbench_test.py/save_file.py实际入口。本工具面向已启动HTTP服务（默认GLM配置），生成长度数据集、调用vendor ais_bench 3.1.20260630，再提取TTFT/TPOT等；临时API配置和软链写回自身目录。当前Graph工具直接LLM.generate并要求逐代Graph、Window裁剪、连续数值和source/launcher关联，接口不同。

本轮继续已验证campaign，不自动启动未知服务，不启用Prefix，不改共享工具。可在将来独立副本复用HTTP统计，但不能拿HTTP吞吐替代Graph合同。本轮未运行aisbench，未解析其历史结果冒充新性能。

只读原件SHA256：
- `README.zh.md`：`f6fcd230e479e5f5efb2e9c26ad065dde5a6ded785c41e6a177a88fc202a7ab7`
- `config.py`：`d3a16a6959aa23b1270ec7b2b30066130d87eb712283cbb10db7eb3381494cae`
- `aisbench_test.py`：`a373b11174cdc0e57fae8f64b7b8650fc4f5f1e78e4730e7c5cdc053252b051d`
- `save_file.py`：`f611857756e626179efb1f172f9eb45434a3d49c8034295a6d192bd6eeb3f366`
