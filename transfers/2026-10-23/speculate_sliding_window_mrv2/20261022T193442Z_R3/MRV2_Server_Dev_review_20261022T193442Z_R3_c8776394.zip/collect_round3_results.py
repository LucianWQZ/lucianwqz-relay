"""Small read-only reductions; do not parse large traces during performance runs."""
import csv
from collections import Counter
import datetime as dt
import hashlib
import json
from pathlib import Path
import statistics

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID = '20261022T193442Z_R3'
OUT = R/'reports'/SID
RAW = R/'runs'/SID/'raw'

def read(p):
    def unique(pairs):
        result={}
        for k,v in pairs:
            if k in result: raise ValueError('duplicate key '+k)
            result[k]=v
        return result
    return json.loads(p.read_text(), object_pairs_hook=unique)

def save(p,d):
    t=p.with_suffix(p.suffix+'.collect.tmp')
    t.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n'); t.replace(p)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def percentile(values,q):
    if not values:return 'NOT_AVAILABLE'
    a=sorted(values); pos=(len(a)-1)*q;i=int(pos)
    return a[i]+(a[min(i+1,len(a)-1)]-a[i])*(pos-i)

def collect():
    rows=[]
    for f in sorted(RAW.glob('admission_C*_attempt*/*/attempt*/execution.json')):
        e=read(f); case=e['case']; rr=Path(e.get('runner_result',''))
        if not rr.is_file(): continue
        r=read(rr); source=e['source_sha']; source_tree=e['source_tree']
        launchers=[]
        # Do not infer model execution from outer process or runner exit alone.
        for record in r.get('records',[]):
            a=record.get('argv',[])
            if '--launcher-record' in a:
                lp=Path(a[a.index('--launcher-record')+1])
                if lp.is_file(): launchers.append((lp,read(lp)))
        if not launchers:
            for lp in RAW.glob('C*_prepare_*/launchers/'+case+'/launcher.json'):
                d=read(lp)
                if d.get('source_sha')==source and d.get('source_tree')==source_tree:
                    launchers.append((lp,d))
        launchers=list({str(p):(p,d) for p,d in launchers}.values())
        row=dict(case_id=case, source_sha=source, source_tree=source_tree,
          kind='HOST_FRAMEWORK' if case in ('CONFIG','P0') else 'FIXTURE' if case=='C2' else 'MODEL',
          execution=str(f), execution_sha256=sha(f), orchestrator_rc=e.get('orchestrator_rc'),
          runner_process_rc=e.get('runner_process_rc'), runner_status=r.get('status'),
          producer_status=r.get('producer_status'), artifact_status=r.get('artifact_status'),
          checker_status=r.get('acceptance_status'), dependency_satisfied=r.get('dependency_satisfied'),
          primary_failure=r.get('primary_failure'), runner_records=r.get('records',[]),
          launchers=[dict(path=str(p),sha256=sha(p),**d) for p,d in launchers])
        rows.append(row)
    profiles=[]
    for p in sorted(RAW.glob('C*_prepare_*/*/profile.json')):
        c=p.parent/'campaign.json'
        if not c.is_file():continue
        profile,campaign=read(p),read(c)
        groups=[g for g in profile.get('groups',[]) if g.get('active')]
        calls=[g for g in profile.get('calls',[]) if g.get('active')]
        case=p.parent.name
        accepted=[x for x in rows if x['case_id']==case and x['source_sha']==campaign['identity']['source_sha']]
        profiles.append(dict(case_id=case, path=str(p),sha256=sha(p),campaign=str(c),
          source_sha=campaign['identity']['source_sha'],config_hash=campaign['config_sha256'],
          request_hash=campaign['request_manifest']['sha256'],
          producer_status=campaign['status'],runner_dependency_satisfied=any(x['dependency_satisfied'] for x in accepted),
          profiler_enabled=profile['profiler_enabled'],scope=profile.get('scope'),
          snapshot_contract=profile.get('materialize_timing_contract'),
          initialization_seconds=campaign.get('initialization_seconds'),
          warmup=profile.get('warmup'),warmup_groups=profile.get('warmup_groups'),
          group_elapsed_ms=[dict(label=g['label'],elapsed_ms=(g['end_ns']-g['start_ns'])/1e6) for g in groups],
          total_request_group_elapsed_ms=sum(g['end_ns']-g['start_ns'] for g in groups)/1e6,
          actual_prompt_lengths=[len(t) for x in campaign.get('outputs',[]) for t in x['prompt_token_ids']],
          completed_requests=sum(len(x['token_ids']) for x in campaign.get('outputs',[])),
          output_token_sequences_sha256=hashlib.sha256(json.dumps([x['token_ids'] for x in campaign.get('outputs',[])],separators=(',',':')).encode()).hexdigest(),
          capture_profile=campaign.get('capture_profile'),
          observer_configured=campaign.get('observer_enabled'),
          provider_installed=campaign.get('provider_installed'),
          observer_installation=campaign.get('observer_installation'),
          draft_host_descriptor_counts=dict(Counter(str(x.get('descriptor')) for x in calls if x['label']=='Draft_REPLAY_SUBMIT')),
          crop_descriptor_samples=sum(any(z.get('source_start_column',0)>0 for z in x.get('window_descriptors',[])) for x in calls),
          crop_scope='Runtime immutable Host descriptor; not device address read evidence',
          generated_tokens=sum(len(t) for x in campaign.get('outputs',[]) for t in x['token_ids']),
          draft_host_replay_submissions=sum(x['label']=='Draft_REPLAY_SUBMIT' for x in calls),
          target_host_replay_submissions=sum(x['label']=='Target_REPLAY_SUBMIT' for x in calls),
          actual_device_execution_occurrences='NOT_AVAILABLE',
          acceptance='NOT_AVAILABLE', target_verification_count='NOT_AVAILABLE',
          host_statistics=profile.get('host_statistics'),
          crop_evidence_contract='Use recorded runtime S>0 evidence; prompt length alone is insufficient',
          trace_files=[str(t) for t in (p.parent/'trace').rglob('trace_view.json')]))
    controls={}
    for name,prefix in [('WINDOW_OFF','PERF_WARM_OFF_'),('WINDOW_ON','PERF_WARM_ON_'),
                        ('COUNTER_LEGACY_ON','PERF_COUNTER_LEGACY_ON_'),('COUNTER_REUSE_ON','PERF_COUNTER_REUSE_ON_')]:
        samples=[p for p in profiles if p['case_id'].startswith(prefix)]
        valid=[p for p in samples if p['producer_status']=='OK' and p['runner_dependency_satisfied']]
        elapsed=[p['total_request_group_elapsed_ms'] for p in valid]
        controls[name]=dict(all_cases=[p['case_id'] for p in samples],accepted_cases=[p['case_id'] for p in valid],
          all_elapsed_ms=elapsed, median_ms=statistics.median(elapsed) if elapsed else 'NOT_AVAILABLE',
          min_ms=min(elapsed) if elapsed else 'NOT_AVAILABLE',max_ms=max(elapsed) if elapsed else 'NOT_AVAILABLE',
          p95_ms=percentile(elapsed,.95),sample_count=len(elapsed),
          scope='Finite repeats; elapsed is sum of sequential bounded request groups, not kernel durations')
    probes=[]
    for p in RAW.glob('probe_phy0_C*/*'):
        if p.is_file() and p.suffix=='.json':
            # Store index only: no guessed probe count based on artifact filenames.
            probes.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
    result=dict(schema='mrv2-r3-small-results-v1',generated_at=dt.datetime.now(dt.timezone.utc).isoformat(),
      cases=rows,profiles=profiles,finite_control_series=controls,probe_artifact_index=probes,
      public_graph_gate='FROZEN',performance_claim='PENDING_WORK_AND_INTERFERENCE_REVIEW')
    save(OUT/'R3_实际执行与性能归约.json',result)
    print(json.dumps(dict(completed_cases=len(rows),profile_cases=len(profiles),control_counts={k:v['sample_count'] for k,v in controls.items()})))

if __name__=='__main__': collect()
