# materialize早期异常边界：先反例，再最小Graph修复

本轮要验证的假设是：C1只在live inputs形成后隔离，Graph proposal中prepared长度快照或workspace部分写入抛出异常时，可能继续清零并允许下次进入。

源码链：draft_window_eager.py proposal finally只在live_inputs非None时quarantine；DraftWindowWorkspace.materialize except调用_zero_all；DraftWindowRuntimeState._materialize_identity except retire lease又reset。部分合法copy_已返回、build_inputs尚未形成时均会走到这里。native API异常不表示没有部分提交，原有用户合同要求这类未知状态仅Host导出与进程隔离。

Host反例使用真实方法，CPU tensor代替设备；在首次合法Window table copy_返回后抛Python异常，记录是否清零/退租/允许再次进入。另测在typed inputs形成前抛异常是否阻止下一proposal。原有nonGraph清理/恢复另设正例保留。

若成立：只为opt-in Graph materialize启用失败保留，不改默认nonGraph cleanup。Graph scope任何未成功异常保守标记uncertain并阻止下次进入；workspace跳过故障后清零，runtime保留失败代lease/identity，driver既有74隔离。正常成功路径不改stream、copy、同步或retirement。预validation也可能被保守隔离，不为减少保留而猜测native状态。

设备故障实验只在合法copy返回后注入Python异常，不制造hardware故障，不伪装native错误；Host guard验证拒绝第二次，不进行第二次设备复用。故障后任何zero_都由实验保护器拒绝，禁止追加D2H/sync/恢复。该设备实验只能证明实际Python边界与隔离，不能证明真实native部分提交内部行为。

若改动production，需对新固定候选补受影响B0、数值/ABA/Target隔离以及生命周期/异常的相关验证；不直接把C19结果改名为新SHA通过。当前尚未修复或设备验收。

## 实际反例与修复进展

- 原C24真实方法反例：`C25_red_materialize.log`，2 failed/1 passed。Graph首次合法table copy后实际清零2次；早期异常未禁止再次进入；nonGraph恢复正例通过。
- 在补materialize保护后，再发现publish_metadata内部abort提前清零，`C25_red_publication.log` 1 failed（中间工作区版本，非C24或最终候选）。已将同一Graph lease的失败保留策略带到发布/generation_guard；默认eager仍清理。
- 目前`C25_final_affected_host.log`99 passed；补强几何/声明点checker后正在独立02日志复验。
- 新工具`p7x_graph_repair9_materialize_fault.py`在合法table copy返回后注入Python异常；禁止故障后zero/replay，Host检查失败代lease和下次scope拒绝；不是native故障仿真。
- 正常成功分支没有增加event、同步、D2H或改变replay/UPDATE顺序。
- production已修改，不能再把C19设备结果直接覆盖新SHA。后续固定候选需B0、连续数值/ABA、Target4隔离、LIFE及新的早期异常边界验证。
