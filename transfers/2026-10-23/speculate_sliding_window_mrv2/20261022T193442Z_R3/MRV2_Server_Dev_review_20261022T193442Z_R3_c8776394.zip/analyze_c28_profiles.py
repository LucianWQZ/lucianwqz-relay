"""Bounded offline trace reduction; never initializes an NPU or joins unlike clocks."""
import collections
from decimal import Decimal as D
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import time

R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID='20261022T193442Z_R3'; RAW=R/'runs'/SID/'raw'; OUT=RAW/'profile_analysis_C28_01'
SOURCE=R/'candidates/C28_graph_failure/vllm-ascend/tools/p7x_graph_repair6_trace.py'
CASES=('PROFILE_WARM_OFF_long_normal','PROFILE_WARM_ON_long_normal','PROFILE_COUNTER_LEGACY_ON_long_normal','PROFILE_COUNTER_REUSE_ON_long_normal')

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def interval(e):
 a=D(str(e['ts'])); return a,a+D(str(e.get('dur',0)))
def union(rows):
 if not rows:return D(0)
 rows=sorted(rows);a,b=rows[0];total=D(0)
 for c,d in rows[1:]:
  if c<=b:b=max(b,d)
  else:total+=b-a;a,b=c,d
 return total+b-a

def stats(values):
 return dict(n=len(values),sum_us=float(sum(values,D(0))),median_us=float(statistics.median(values)),max_us=float(max(values))) if values else dict(n=0,scope='no visible matching exported record, not proof no operation')

def main():
 start_sha=digest(Path(__file__));OUT.mkdir(exist_ok=False)
 spec=importlib.util.spec_from_file_location('fixed_c28_flow',SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 rows=[]
 for case in CASES:
  paths=list((RAW/'C28_prepare_01'/case/'trace').rglob('trace_view.json'));assert len(paths)==1
  p=paths[0];assert p.stat().st_size<512<<20
  started=time.time();doc=json.loads(p.read_text());es=doc['traceEvents'] if isinstance(doc,dict) else doc
  f=m.analyze(es); flow=OUT/(case+'-flow.json');write(flow,f)
  hardware={e['pid'] for e in es if e.get('ph')=='M' and e.get('name')=='process_name' and e.get('args',{}).get('name')=='Ascend Hardware'}
  xs=[e for e in es if e.get('ph')=='X' and 'ts' in e and 'dur' in e]
  hw=[e for e in xs if e.get('pid') in hardware]
  kernels=[e for e in hw if str(e.get('args',{}).get('Task Type','')).startswith('KERNEL')]
  span=max(interval(e)[1] for e in hw)-min(interval(e)[0] for e in hw)
  busy=union([interval(e) for e in hw]);kb=union([interval(e) for e in kernels])
  label_names=('Draft_materialize_exact_length_snapshot','Draft_materialize_workspace','Draft_materialize','Draft_build_attn_metadata','Draft_context_KV')
  range_index=m.Intervals(es,lambda e:e.get('name') in ['repair5/'+x for x in label_names])
  scoped=collections.defaultdict(lambda:collections.defaultdict(list));fragments=[]
  for i,e in enumerate(es):
   if e.get('ph')!='X' or e.get('cat')!='cpu_op' or not any(s in e.get('name','').lower() for s in ('synchronize','memcpy','tolist','copy_')):continue
   for j in range_index.containing(e):
    parent=es[j]
    if interval(e)[1]<=interval(parent)[1]:scoped[parent['name']][e['name']].append(D(str(e['dur'])))
  for label in label_names:
   picked=next(((i,e) for i,e in enumerate(es) if e.get('ph')=='X' and e.get('name')=='repair5/'+label),None)
   if not picked:continue
   i,parent=picked;a,b=interval(parent)
   children=[dict(original_event_index=j,event=e) for j,e in enumerate(es) if e.get('ph')=='X' and (e.get('pid'),e.get('tid'))==(parent.get('pid'),parent.get('tid')) and a<=interval(e)[0] and interval(e)[1]<=b]
   fragments.append(dict(label=label,parent=dict(original_event_index=i,event=parent),same_thread_children=children[:100],retained=len(children[:100]),available=len(children)))
  per_stream={}
  for stream in sorted({e.get('args',{}).get('Physic Stream Id',e['tid']) for e in hw}):
   group=[e for e in hw if e.get('args',{}).get('Physic Stream Id',e['tid'])==stream]
   per_stream[str(stream)]=dict(exported_tasks=len(group),union_us=float(union([interval(e) for e in group])),task_types=dict(collections.Counter(e.get('args',{}).get('Task Type') for e in group)))
  cpu_ops=collections.defaultdict(list)
  for e in xs:
   if e.get('cat')=='cpu_op' and any(s in e.get('name','').lower() for s in ('synchronize','memcpy','tolist')):cpu_ops[e['name']].append(D(str(e['dur'])))
  row=dict(case=case,trace=str(p),trace_bytes=p.stat().st_size,trace_sha256=digest(p),flow_tool=str(SOURCE),flow_tool_sha256=digest(SOURCE),parser_sha256=start_sha,
   elapsed_analysis_seconds=time.time()-started,event_count=len(es),classified_flow=f['classified_coverage'],flow_counts=f['flow_counts'],flow_output=str(flow),
   host_scoped_records={k:{n:stats(v) for n,v in names.items()} for k,names in scoped.items()},
   host_copy_wait_named_records={k:stats(v) for k,v in cpu_ops.items()},
   hardware=dict(exported_tasks=len(hw),kernel_tasks=len(kernels),task_types=dict(collections.Counter(e.get('args',{}).get('Task Type') for e in hw)),
    observed_export_span_us=float(span),all_exported_task_union_us=float(busy),kernel_task_union_us=float(kb),kernel_duration_sum_us=float(sum((D(str(e['dur'])) for e in kernels),D(0))),
    kernel_uncovered_export_span_us=float(span-kb),per_stream=per_stream,
    name_counts=dict(collections.Counter(e['name'] for e in hw).most_common(25)),
    memcpy_directions='NOT_AVAILABLE_FROM_PCIE_DMA_SQE_RECORDS',target_draft_fia_assignment='NOT_ESTABLISHED_BY_NAME_SHAPE_OR_MODEL_ID_ALONE',
    scope='Same-device export clock only; kernel-uncovered is not whole-device idle; parallel duration sum is not elapsed'),
   native_execution_generation='NOT_AVAILABLE',task_operand='NOT_EXPOSED',physical_read='NOT_EXPOSED',
   association_scope='Flow IDs and exact same-thread containment only; no host-monotonic/device-clock subtraction')
  write(OUT/(case+'-scope-fragments.json'),dict(source_trace=str(p),fragments=fragments,flow_fragment=f['fragment'],scope='Exact event indices/explicit flows; fragments are not complete traces'))
  rows.append(row);write(OUT/'summary.json',dict(schema='mrv2-c28-trace-analysis-v1',rows=rows,complete=len(rows)==len(CASES)))
  print(case,'events',len(es),'flow',f['classified_coverage'],flush=True)
 assert digest(Path(__file__))==start_sha
 write(OUT/'parser-integrity.json',dict(start_sha256=start_sha,exit_sha256=digest(Path(__file__)),source_sha='c877639472386aedeb7df11f15b6bf75c078261c',scope='NEW_C28_PROFILER_TRACES_OFFLINE_ANALYSIS_NOT_NEW_DEVICE_EXECUTION'))

if __name__=='__main__':main()
