"""Read-only derived flow labels. Original parser verdicts remain unchanged."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def classify(flow, events):
    if flow['status'] != 'MATCHED':
        return 'UNRESOLVED'
    # The saved indices are duration ordered by the committed interval parser.
    # An event nested inside a large MODEL_EXECUTE does not become model flow.
    destinations = [events[i] for i in flow.get('destination_intervals', [])]
    if not destinations:
        return 'UNKNOWN_DESTINATION'
    leaf = destinations[0].get('name', '')
    if leaf in ('EVENT_RECORD', 'EVENT_WAIT', 'EVENT_RESET'):
        return 'DEVICE_EVENT_FLOW'
    if 'enqueue_to_dequeue' in flow['key']:
        return 'HOST_QUEUE_EVENT_FLOW'
    if leaf == 'MODEL_EXECUTE':
        return 'MODEL_EXECUTION_CONTEXT_FLOW'
    return 'OTHER_EXPLICIT_FLOW'


def analyze(flow_path, trace_path):
    raw = json.loads(flow_path.read_text())
    doc = json.loads(trace_path.read_text())
    events = doc['traceEvents'] if isinstance(doc, dict) else doc
    counts, rows = Counter(), []
    for replay in raw['replays']:
        classes = []
        for index in replay['direct_flow_indices']:
            f = raw['flows'][index]
            label = classify(f, events)
            counts[label] += 1
            classes.append(dict(flow_index=index, classification=label,
                                original_event_indices=f['event_indices'], flow_key=f['key'],
                                destination_intervals=[dict(event_index=i, name=events[i].get('name'),
                                                            category=events[i].get('cat'))
                                                       for i in f.get('destination_intervals', [])]))
        rows.append(dict(replay_event_index=replay['event_index'], flows=classes))
    return dict(original_parser_coverage=raw['coverage'], direct_flow_classification=dict(counts),
                any_flow_replay_count=sum(bool(r['flows']) for r in rows),
                model_execution_context_replay_count=sum(any(f['classification'] == 'MODEL_EXECUTION_CONTEXT_FLOW'
                                                            for f in r['flows']) for r in rows),
                generation_bound_execution_flow='NOT_AVAILABLE_NO_NATIVE_OCCURRENCE_ID',
                source_flow=str(flow_path), source_trace=str(trace_path),
                source_flow_sha256=hashlib.sha256(flow_path.read_bytes()).hexdigest(),
                replays=rows, scope='Existing explicit flow endpoints only; no generation or operand inferred',
                original_unchanged=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--flow', type=Path, required=True)
    p.add_argument('--trace', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists():
        raise ValueError('new derived output required')
    result = analyze(a.flow, a.trace)
    a.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
