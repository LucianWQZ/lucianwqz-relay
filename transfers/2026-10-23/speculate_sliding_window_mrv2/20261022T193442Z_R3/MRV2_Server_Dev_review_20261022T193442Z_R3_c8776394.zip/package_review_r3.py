"""Build one bounded review delivery; original server evidence remains unchanged."""
from pathlib import Path
import csv
import datetime as dt
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import zipfile

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID = '20261022T193442Z_R3'
O = R / 'reports' / SID
RUN = R / 'runs' / SID
RAW = RUN / 'raw'
D = R / 'return' / SID
SHA = 'c877639472386aedeb7df11f15b6bf75c078261c'
TREE = '729a2d3bc76ac814d1555cb4a457b513bb0b413f'
DEV = R / 'work/vllm-ascend'
COORD = R.parent / 'resource_coordination/node-39-101'
mapping = []
omitted = []


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def pairs(items):
    d = {}
    for k, v in items:
        if k in d:
            raise ValueError('Duplicate JSON key: ' + str(k))
        d[k] = v
    return d


def load(p):
    return json.loads(p.read_text(), object_pairs_hook=pairs)


def save(p, data):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def cp(src, rel):
    if not src.is_file() or src.is_symlink():
        raise ValueError('Missing or symlink source: ' + str(src))
    dst = D / rel
    if dst.exists():
        assert digest(dst) == digest(src), str(dst)
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    mapping.append(dict(server_path=str(src), review_path=rel,
                        bytes=src.stat().st_size, sha256=digest(src)))


def main():
    # Refuse to overwrite a prior delivery or a failed packaging attempt.
    D.mkdir(exist_ok=False)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=DEV, text=True).strip() == SHA
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=DEV, text=True).strip() == TREE
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=DEV, text=True)
    subprocess.run(['git', 'diff', '--check', 'da5b0f054c4b94362ff3539de911b26b4074052a', SHA], cwd=DEV, check=True)

    # All final reports plus small original failures, predeclarations and parsers.
    exclude = {'MRV2_Profiling_Summary_首次采集前.json', 'ROUND_COUNTS.json'}
    for p in sorted(O.iterdir()):
        if p.is_file() and p.suffix in ('.md', '.json', '.csv', '.log', '.diff', '.py') and p.name not in exclude:
            if p.name.startswith(('build_checkpoint', 'finalize_reports')):
                continue
            cp(p, p.name)
    for folder in ('source', 'review_numeric_fragments', 'platform_sources'):
        for p in sorted((O / folder).rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                cp(p, str(p.relative_to(O)))
    old_platform = R / 'reports/20261022T132626Z_R2/platform_sources'
    for p in sorted(old_platform.rglob('*')):
        if p.is_file() and '.git' not in p.parts:
            cp(p, 'evidence/R2_platform_sources/' + str(p.relative_to(old_platform)))

    # Exact final source files are independent of editable installs / overlays.
    changed = subprocess.check_output(['git', 'diff', '--name-only', 'da5b0f054c4b94362ff3539de911b26b4074052a', SHA], cwd=DEV, text=True).splitlines()
    source_proof = []
    for name in changed:
        p = DEV / name
        if p.is_file():
            blob = subprocess.check_output(['git', 'show', SHA + ':' + name], cwd=DEV)
            assert hashlib.sha256(blob).hexdigest() == digest(p)
            cp(p, 'source/final_files/' + name)
            source_proof.append(dict(path=name, bytes=len(blob), sha256=digest(p), source_sha=SHA))
    cp(DEV / 'LICENSE', 'source/LICENSE')
    save(D / 'source/final_files_identity.json', source_proof)

    # Include complete small case metadata and all read-only verdicts, no tensors.
    prep = RAW / 'C28_prepare_01'
    for p in prep.iterdir():
        if p.is_file() and p.suffix in ('.json', '.md', '.txt'):
            cp(p, 'evidence/raw/' + str(p.relative_to(RAW)))
        elif p.is_dir() and p.name != 'launchers':
            for f in p.iterdir():
                if f.is_file() and f.suffix in ('.json', '.jsonl', '.log'):
                    if f.name.startswith('controlled-target-sample-') and not (
                            f.name == 'controlled-target-sample-000.json' and
                            p.name in ('NUMERIC_TARGET4', 'TARGET4_OFF')):
                        omitted.append(dict(path=str(f), bytes=f.stat().st_size,
                                            reason='Large per-layer write-set metadata retained server-side; 12-pair joint and per-sample summaries included'))
                        continue
                    assert f.stat().st_size < 8 * 1024 * 1024, str(f)
                    cp(f, 'evidence/raw/' + str(f.relative_to(RAW)))
    patterns = [
        'C28_prepare_01/launchers/*/launcher.json',
        'C28_prepare_01/launchers/*/stdout.log',
        'C28_prepare_01/launchers/*/stderr.log',
        'C28_campaign_01/*/runner-result.json',
        'admission_C28_attempt*/*/attempt01/*.json',
        'C28_segment_*/*.json', 'probe_phy0_C28_*/*.json',
        'target_join_C28_01/*.json', 'target_join_C28_01/*.log',
        'profile_analysis_C28_01/*scope-fragments.json',
        'profile_analysis_C28_01/summary.json',
        'profile_analysis_C28_01/parser-integrity.json',
    ]
    for pattern in patterns:
        for p in sorted(RAW.glob(pattern)):
            cp(p, 'evidence/raw/' + str(p.relative_to(RAW)))
    for p in RAW.glob('*.json'):
        cp(p, 'evidence/raw/' + p.name)
    for p in (RUN / 'environment').iterdir():
        if p.is_file() and p.suffix in ('.json', '.jsonl', '.txt'):
            cp(p, 'evidence/environment/' + p.name)
    for p in (RUN / 'orchestration').glob('*c28*.py'):
        cp(p, 'evidence/orchestration/' + p.name)
    for name in ('R3_C28_HOST_EVIDENCE.json', 'R3_C28_RUNTIME_OVERLAY.json', 'STORAGE_BINDING.json', 'PATH_BINDING.json'):
        p = R / 'state' / name
        if p.exists():
            cp(p, 'evidence/state/' + name)
    inp = R / 'inputs' / SID
    for p in inp.rglob('*.json'):
        cp(p, 'inputs/' + str(p.relative_to(inp)))

    cp(COORD / 'PROTOCOL_PR_PROPOSED.md', 'evidence/coordination/PROTOCOL_PR_PROPOSED.md')
    for p in COORD.rglob('*.json'):
        if SID in p.name or p.name == 'pr_20261022T1938Z.json':
            cp(p, 'evidence/coordination/' + str(p.relative_to(COORD)))

    # Copy only this session's progress lines, not earlier journals / experiments.
    lines = (R / 'journal/progress.log').read_text().splitlines()
    keep = [line for line in lines if line[:19] >= '2026-10-22T19:34:42']
    (D / 'progress_R3.log').write_text('\n'.join(keep) + '\n')

    # Server-only raw index: stat inventory, known captured trace hashes reused.
    traces = {x['trace']: x for x in load(RAW / 'profile_analysis_C28_01/summary.json')['rows']}
    index_count = total_bytes = 0
    with (D / 'RAW_FILE_INDEX.jsonl').open('w') as f:
        for p in sorted(RAW.rglob('*')):
            if not p.is_file() or p.is_symlink():
                continue
            st = p.stat(); row = dict(path=str(p), relative_path=str(p.relative_to(RAW)), bytes=st.st_size, mtime_ns=st.st_mtime_ns, retention='SERVER_ONLY_UNLESS_REVIEW_MAP_LISTS_COPY')
            if str(p) in traces:
                row.update(sha256=traces[str(p)]['trace_sha256'], hash_basis='REUSED_COMPLETED_TRACE_PARSER_INPUT_HASH')
            elif re.fullmatch('[0-9a-f]{64}', p.stem):
                row.update(content_address=p.stem, hash_basis='FILENAME_ONLY_NOT_FRESH_REHASH; original storage/joint validation retained')
            f.write(json.dumps(row, ensure_ascii=False) + '\n')
            index_count += 1; total_bytes += st.st_size
    save(D / 'RAW_INDEX_SUMMARY.json', dict(files=index_count, bytes=total_bytes, raw_root=str(RAW), index='RAW_FILE_INDEX.jsonl', full_tensor_rehash_performed=False, selected_metadata_omissions=omitted, reason='Preserve prior producer/storage/joint hashes; do not reread large tensors solely for packaging'))

    (D / '审查包阅读说明.md').write_text('''# R3审查入口

先读：MRV2_持续开发阶段总结.md、MRV2_正常Graph合同审查.md、MRV2_Profiling分析.md。

最终C28、固定vLLM pin、支持边界与失败均保留。evidence/raw与environment为真实小型原件，不覆盖其内部服务器绝对路径；REFERENCE_MAP.json把随包原件映射到包内。RAW_FILE_INDEX.jsonl为服务器保留索引，大tensor/trace不在本包；其stat不冒充新hash验证。外部路径被明确保留，离线片段不声称完整joint可在客户端重算。

review_numeric_fragments/verify_fragment.py只需Python标准库：核验本包输出/小输入的hash、dtype、字节、严格数值及A/B/A′，不能证明完整KV/层/参考执行独立性或Graph Gate。完整producer/artifact/plan/launcher/joint记录在evidence/raw。原始joint授权字段不被改写，设备准入另见inspect/probe/check/bind和device-provenance。

source内bundle以前置Repair7为基线，已经实际从只含该前置的新仓恢复C28；不是包含模型、native安装或vLLM仓的完整环境。还原参照Git_bundle恢复说明.md。所有本轮提交只在本地，未push，Gate冻结。

REVIEW_CONTENTS.json逐项hash不包含自身；外部DOWNLOAD_MANIFEST.json给出最终ZIP与bundle字节及SHA256，以避免自引用。ZIP自检为服务器验证，用户接收校验尚未执行。
''')
    save(D / 'REFERENCE_MAP.json', dict(schema='mrv2-server-review-path-map-v1', files=mapping, external_raw_index='RAW_FILE_INDEX.jsonl', original_references_preserved=True, local_candidate_source='source/final_files', historical_platform_source_remap={'../20261022T132626Z_R2/platform_sources/':'evidence/R2_platform_sources/'}))

    # Strict JSON parse before ZIP; corrupted/duplicate members are never masked.
    json_count = 0
    for p in D.rglob('*.json'):
        load(p); json_count += 1
    for p in D.rglob('*.jsonl'):
        for line in p.read_text().splitlines():
            if line.strip():
                json.loads(line, object_pairs_hook=pairs)
    for x in mapping:
        assert digest(D / x['review_path']) == x['sha256']
    # Explicitly check every copied manifest's local tensor reference.
    frag = load(D / 'review_numeric_fragments/fragment.json')
    for row in frag['rows']:
        assert (D / 'review_numeric_fragments' / row['original_manifest_copy']).is_file()
        for ref in row['refs'].values():
            assert (D / 'review_numeric_fragments/data' / ref['path']).is_file()
    reference_check = dict(status='PASS_COPIED_EVIDENCE_AND_REQUIRED_REFERENCES', mapped_files=len(mapping), strict_json_files=json_count, original_server_references='EXTERNAL_WHEN_NOT_IN_REFERENCE_MAP; raw index retains absolute paths', numeric_fragment_refs='ALL_LOCAL_PRESENT', scope='Not a claim that all large tensor/KV references are portable')
    save(D / 'REFERENCE_SELF_CHECK.json', reference_check)
    files = sorted(p for p in D.rglob('*') if p.is_file())
    save(D / 'REVIEW_CONTENTS.json', dict(schema='mrv2-review-contents-v1', source_sha=SHA, source_tree=TREE, files=[dict(path=str(p.relative_to(D)), bytes=p.stat().st_size, sha256=digest(p)) for p in files], exclusions=['REVIEW_CONTENTS.json itself', 'ZIP / external DOWNLOAD_MANIFEST / post-ZIP selfcheck']))
    files = sorted(p for p in D.rglob('*') if p.is_file())
    zpath = D / ('MRV2_Server_Dev_review_' + SID + '_c8776394.zip')
    with zipfile.ZipFile(zpath, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in files:
            z.write(p, str(p.relative_to(D)))
    assert zpath.stat().st_size < 20 * 1024 * 1024
    with zipfile.ZipFile(zpath) as z:
        names = z.namelist()
        assert len(names) == len(set(names))
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        assert z.testzip() is None
        content = json.loads(z.read('REVIEW_CONTENTS.json'), object_pairs_hook=pairs)
        for row in content['files']:
            data = z.read(row['path'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        with tempfile.TemporaryDirectory(prefix='mrv2-r3-review-', dir='/tmp') as tmp:
            for n in names:
                if n.startswith('review_numeric_fragments/'):
                    z.extract(n, tmp)
            result = subprocess.run(['/usr/local/python3.11.10/bin/python', str(Path(tmp) / 'review_numeric_fragments/verify_fragment.py')], text=True, capture_output=True, timeout=30)
            assert result.returncode == 0, result.stderr
            recalced = json.loads(result.stdout, object_pairs_hook=pairs)
            assert recalced['status'] == 'PASS_OUTPUT_FRAGMENT_RECALC_ONLY'
    save(D / 'ZIP_SERVER_SELF_CHECK.json', dict(at=dt.datetime.now(dt.timezone.utc).isoformat(), status='PASS', zip_crc='PASS', payload_hashes='PASS', member_count=len(names), strict_json_parse='PASS_NO_DUPLICATE_KEYS', portable_fragment_recalc=recalced, bundle_restore_evidence='source/bundle_restore_verification.json', user_receipt_verified=False, zip_path=str(zpath), zip_bytes=zpath.stat().st_size, zip_sha256=digest(zpath)))
    save(O / 'PACKAGING_RESULT.json', dict(directory=str(D), review_zip=str(zpath), zip_bytes=zpath.stat().st_size, zip_sha256=digest(zpath), members=len(names), raw_index_files=index_count, raw_index_bytes=total_bytes, next_action='Generate external download manifest and final stable pointers after inspecting this PASS'))
    print(json.dumps(load(O / 'PACKAGING_RESULT.json'), ensure_ascii=False))


if __name__ == '__main__':
    main()
