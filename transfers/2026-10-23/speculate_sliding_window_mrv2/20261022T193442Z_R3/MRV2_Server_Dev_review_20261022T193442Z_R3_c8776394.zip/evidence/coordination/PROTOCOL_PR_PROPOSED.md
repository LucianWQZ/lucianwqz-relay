# Proposed shared physical-chip coordination

Not a scheduler or hardware isolation. Graph has not acknowledged this protocol. An idle snapshot is not long-term allocation. Each task changes only its registrations. No expired directory may be stolen; exit/context proof is required before release.

Lease storage leases/phy-NN uses atomic mkdir in increasing physical-ID order. A multi-chip failure rolls back only directories created by that acquisition. owner.json records task/run, unique token, host/container/PID/start ticks/PID namespace, deadline/status/heartbeat. Heartbeat at most 60 seconds apart; lease covers loading through worker/context exit. Releases are retained in releases/. PR helper is ../pr/ops/chip_lease.py; valid fresh hardware/mapping/schedule admission is a separate prerequisite.

This shared NFS mount's atomic-mkdir behavior must be verified before the first acquisition. No card has been acquired. Repeated empty NPU-SMI, AICore=0 or HBM below a threshold cannot grant a lease. TP16 requires all 16 units coordinated and no heavy shared-resource contention.
