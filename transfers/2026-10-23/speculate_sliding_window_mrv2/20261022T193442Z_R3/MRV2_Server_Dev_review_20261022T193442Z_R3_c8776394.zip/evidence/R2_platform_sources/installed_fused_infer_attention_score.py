#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.
"""

import re
import os, sys
import ctypes
import json
import shutil


from asc_op_compile_base.common.platform import get_soc_spec
from asc_op_compile_base.common.utils import para_check
from asc_op_compile_base.asc_op_compiler import compile_op, replay_op, check_op_cap, generalize_op_params, get_code_channel, OpInfo
from asc_op_compile_base.asc_op_compiler.compile_op import CommonUtility, AscendCLogLevel
from asc_op_compile_base.common.buildcfg import get_default_build_config
from asc_op_compile_base.common.buildcfg import get_current_build_config
from asc_op_compile_base.common import register as tbe_register
__version__ = '2.0.0'


PYF_PATH = os.path.dirname(os.path.realpath(__file__))

DTYPE_MAP = {"float32": ["DT_FLOAT", "float"],
    "float16": ["DT_FLOAT16", "half"],
    "int8": ["DT_INT8", "int8_t"],
    "int16": ["DT_INT16", "int16_t"],
    "int32": ["DT_INT32", "int32_t"],
    "int64": ["DT_INT64", "int64_t"],
    "uint1": ["DT_UINT1", "uint1b_t"],
    "uint8": ["DT_UINT8", "uint8_t"],
    "uint16": ["DT_UINT16", "uint16_t"],
    "uint32": ["DT_UINT32", "uint32_t"],
    "uint64": ["DT_UINT64", "uint64_t"],
    "bool": ["DT_BOOL", "bool"],
    "double": ["DT_DOUBLE", "double"],
    "dual": ["DT_DUAL", "unknown"],
    "dual_sub_int8": ["DT_DUAL_SUB_INT8", "unknown"],
    "dual_sub_uint8": ["DT_DUAL_SUB_UINT8", "unknown"],
    "string": ["DT_STRING", "unknown"],
    "complex32": ["DT_COMPLEX32", "complex32"],
    "complex64": ["DT_COMPLEX64", "complex64"],
    "complex128": ["DT_COMPLEX128", "unknown"],
    "qint8": ["DT_QINT8", "unknown"],
    "qint16": ["DT_QINT16", "unknown"],
    "qint32": ["DT_QINT32", "unknown"],
    "quint8": ["DT_QUINT8", "unknown"],
    "quint16": ["DT_QUINT16", "unknown"],
    "resource": ["DT_RESOURCE", "unknown"],
    "string_ref": ["DT_STRING_REF", "unknown"],
    "int4": ["DT_INT4", "int4b_t"],
    "bfloat16": ["DT_BF16", "bfloat16_t"],
    "float8_e5m2": ["DT_FLOAT8_E5M2", "fp8_e5m2_t"],
    "float8_e4m3fn": ["DT_FLOAT8_E4M3FN", "fp8_e4m3fn_t"],
    "hifloat8":["DT_HIFLOAT8", "hifloat8_t"],
    "float8_e8m0":["DT_FLOAT8_E8M0", "fp8_e8m0_t"],
    "float4_e2m1":["DT_FLOAT4_E2M1", "fp4x2_e2m1_t"],
    "float4_e1m2":["DT_FLOAT4_E1M2", "fp4x2_e1m2_t"],
    "int2": ["DT_INT2", "int2b_t"]}

def add_dtype_fmt_option_single(x, x_n, is_ref: bool = False):
    options = []
    x_fmt = x.get("format")
    x_dtype = x.get("dtype")
    x_n_in_kernel = x_n + '_REF' if is_ref else x_n
    options.append("-DDTYPE_{n}={t}".format(n=x_n_in_kernel, t=DTYPE_MAP.get(x_dtype)[1]))
    options.append("-DORIG_DTYPE_{n}={ot}".format(n=x_n_in_kernel, ot=DTYPE_MAP.get(x_dtype)[0]))
    options.append("-DFORMAT_{n}=FORMAT_{f}".format(n=x_n_in_kernel, f=x_fmt))
    return options

def get_dtype_fmt_options(__inputs__, __outputs__):
    options = []
    input_names = ['query', 'key', 'value', 'pse_shift', 'atten_mask', 'actual_seq_lengths', 'actual_seq_lengths_kv', 'dequant_scale1', 'quant_scale1', 'dequant_scale2', 'quant_scale2', 'quant_offset2', 'antiquant_scale', 'antiquant_offset', 'block_table', 'query_padding_size', 'kv_padding_size', 'key_antiquant_scale', 'key_antiquant_offset', 'value_antiquant_scale', 'value_antiquant_offset', 'key_shared_prefix', 'value_shared_prefix', 'actual_shared_prefix_len', 'query_rope', 'key_rope', 'key_rope_antiquant_scale', 'dequant_scale_query', 'learnable_sink', 'q_start_idx', 'kv_start_idx']
    output_names = ['attention_out', 'softmax_lse']
    unique_param_name_set = set()
    for idx, x in enumerate(__inputs__):
        if x is None:
            continue
        x_n = input_names[idx].upper()
        unique_param_name_set.add(x_n)
        options += add_dtype_fmt_option_single(x, x_n)

    for idx, x in enumerate(__outputs__):
        if x is None:
            continue
        x_n = output_names[idx].upper()
        if x_n in unique_param_name_set:
            options += add_dtype_fmt_option_single(x, x_n, True)
        else:
            options += add_dtype_fmt_option_single(x, x_n)
    return options

def load_dso(so_path):
    try:
        ctypes.CDLL(so_path)
    except OSError as error :
        CommonUtility.print_compile_log("", error, AscendCLogLevel.LOG_ERROR)
        raise RuntimeError("cannot open %s" %(so_path))
    else:
        msg = "load so succ " + so_path
        CommonUtility.print_compile_log("", msg, AscendCLogLevel.LOG_INFO)

def get_shortsoc_compile_option(compile_option_list: list, shortsoc:str):
    compile_options = []
    if shortsoc in compile_option_list:
        compile_options.extend(compile_option_list[shortsoc])
    if '__ALLSOC__' in compile_option_list:
        compile_options.extend(compile_option_list['__ALLSOC__'])
    return compile_options

def get_kernel_source(src_file, dir_snake, dir_ex):
    src = os.path.join(PYF_PATH, "op_kernel", src_file)
    if os.path.exists(src):
        return src
    src = os.path.join(PYF_PATH, "..", "ascendc", dir_snake, "op_kernel", src_file)
    if os.path.exists(src):
        return src
    src_ex = os.path.join(PYF_PATH, "..", "ascendc", dir_ex, "op_kernel", src_file)
    if os.path.exists(src_ex):
        return src_ex
    src_ex = os.path.join(PYF_PATH, "..", "ascendc", dir_ex, src_file)
    if os.path.exists(src_ex):
        return src_ex
    src = os.environ.get('BUILD_KERNEL_SRC')
    if src and os.path.exists(src):
        return src
    src = os.path.join(PYF_PATH, "..", "ascendc", dir_snake, src_file)
    if os.path.exists(src):
        return src
    src = os.path.join(PYF_PATH, src_file)
    if os.path.exists(src):
        return src
    src = os.path.join(PYF_PATH, "..", "ascendc", dir_snake, dir_snake + ".cpp")
    if os.path.exists(src):
        return src
    src = os.path.join(PYF_PATH, "..", "ascendc", dir_ex, dir_ex + ".cpp")
    if os.path.exists(src):
        return src
    src = os.path.join(PYF_PATH, "..", "ascendc", os.path.splitext(src_file)[0], src_file)
    if os.path.exists(src):
        return src
    return src_ex

def _build_args(query_in__, key_in__, value_in__, pse_shift_in__, atten_mask_in__, actual_seq_lengths_in__, actual_seq_lengths_kv_in__, dequant_scale1_in__, quant_scale1_in__, dequant_scale2_in__, quant_scale2_in__, quant_offset2_in__, antiquant_scale_in__, antiquant_offset_in__, block_table_in__, query_padding_size_in__, kv_padding_size_in__, key_antiquant_scale_in__, key_antiquant_offset_in__, value_antiquant_scale_in__, value_antiquant_offset_in__, key_shared_prefix_in__, value_shared_prefix_in__, actual_shared_prefix_len_in__, query_rope_in__, key_rope_in__, key_rope_antiquant_scale_in__, dequant_scale_query_in__, learnable_sink_in__, q_start_idx_in__, kv_start_idx_in__, attention_out_out_, softmax_lse_out_, num_heads, scale, pre_tokens, next_tokens, input_layout, num_key_value_heads, sparse_mode, inner_precise, block_size, antiquant_mode, softmax_lse_flag, key_antiquant_mode, value_antiquant_mode, query_quant_mode, pse_type, out_dtype):
    __inputs__ = []
    for arg in [query_in__, key_in__, value_in__, pse_shift_in__, atten_mask_in__, actual_seq_lengths_in__, actual_seq_lengths_kv_in__, dequant_scale1_in__, quant_scale1_in__, dequant_scale2_in__, quant_scale2_in__, quant_offset2_in__, antiquant_scale_in__, antiquant_offset_in__, block_table_in__, query_padding_size_in__, kv_padding_size_in__, key_antiquant_scale_in__, key_antiquant_offset_in__, value_antiquant_scale_in__, value_antiquant_offset_in__, key_shared_prefix_in__, value_shared_prefix_in__, actual_shared_prefix_len_in__, query_rope_in__, key_rope_in__, key_rope_antiquant_scale_in__, dequant_scale_query_in__, learnable_sink_in__, q_start_idx_in__, kv_start_idx_in__]:
        if arg is not None:
            if isinstance(arg, (list, tuple)):
                if len(arg) == 0:
                    continue
                __inputs__.append(arg[0])
            else:
                __inputs__.append(arg)
        else:
            __inputs__.append(arg)
    __outputs__ = []
    for arg in [attention_out_out_, softmax_lse_out_]:
        if arg is not None:
            if isinstance(arg, (list, tuple)):
                if len(arg) == 0:
                    continue
                __outputs__.append(arg[0])
            else:
                __outputs__.append(arg)
        else:
            __outputs__.append(arg)
    __attrs__ = []
    if num_heads is not None:
        attr = {}
        attr["name"] = "num_heads"
        attr["dtype"] = "int"
        attr["value"] = num_heads
        __attrs__.append(attr)
    if scale is not None:
        attr = {}
        attr["name"] = "scale"
        attr["dtype"] = "float"
        attr["value"] = scale
        __attrs__.append(attr)
    if pre_tokens is not None:
        attr = {}
        attr["name"] = "pre_tokens"
        attr["dtype"] = "int"
        attr["value"] = pre_tokens
        __attrs__.append(attr)
    if next_tokens is not None:
        attr = {}
        attr["name"] = "next_tokens"
        attr["dtype"] = "int"
        attr["value"] = next_tokens
        __attrs__.append(attr)
    if input_layout is not None:
        attr = {}
        attr["name"] = "input_layout"
        attr["dtype"] = "str"
        attr["value"] = input_layout
        __attrs__.append(attr)
    if num_key_value_heads is not None:
        attr = {}
        attr["name"] = "num_key_value_heads"
        attr["dtype"] = "int"
        attr["value"] = num_key_value_heads
        __attrs__.append(attr)
    if sparse_mode is not None:
        attr = {}
        attr["name"] = "sparse_mode"
        attr["dtype"] = "int"
        attr["value"] = sparse_mode
        __attrs__.append(attr)
    if inner_precise is not None:
        attr = {}
        attr["name"] = "inner_precise"
        attr["dtype"] = "int"
        attr["value"] = inner_precise
        __attrs__.append(attr)
    if block_size is not None:
        attr = {}
        attr["name"] = "block_size"
        attr["dtype"] = "int"
        attr["value"] = block_size
        __attrs__.append(attr)
    if antiquant_mode is not None:
        attr = {}
        attr["name"] = "antiquant_mode"
        attr["dtype"] = "int"
        attr["value"] = antiquant_mode
        __attrs__.append(attr)
    if softmax_lse_flag is not None:
        attr = {}
        attr["name"] = "softmax_lse_flag"
        attr["dtype"] = "bool"
        attr["value"] = softmax_lse_flag
        __attrs__.append(attr)
    if key_antiquant_mode is not None:
        attr = {}
        attr["name"] = "key_antiquant_mode"
        attr["dtype"] = "int"
        attr["value"] = key_antiquant_mode
        __attrs__.append(attr)
    if value_antiquant_mode is not None:
        attr = {}
        attr["name"] = "value_antiquant_mode"
        attr["dtype"] = "int"
        attr["value"] = value_antiquant_mode
        __attrs__.append(attr)
    if query_quant_mode is not None:
        attr = {}
        attr["name"] = "query_quant_mode"
        attr["dtype"] = "int"
        attr["value"] = query_quant_mode
        __attrs__.append(attr)
    if pse_type is not None:
        attr = {}
        attr["name"] = "pse_type"
        attr["dtype"] = "int"
        attr["value"] = pse_type
        __attrs__.append(attr)
    if out_dtype is not None:
        attr = {}
        attr["name"] = "out_dtype"
        attr["dtype"] = "int"
        attr["value"] = out_dtype
        __attrs__.append(attr)
    return __inputs__, __outputs__, __attrs__

@tbe_register.register_operator("FusedInferAttentionScore", trans_bool_to_s8=False)
@para_check.check_op_params(para_check.REQUIRED_INPUT, para_check.DYNAMIC_INPUT, para_check.DYNAMIC_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.OPTION_INPUT, para_check.REQUIRED_OUTPUT, para_check.REQUIRED_OUTPUT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_FLOAT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_STR, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_BOOL, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_INT, para_check.OPTION_ATTR_INT, para_check.KERNEL_NAME)
def fused_infer_attention_score(query_in__, key_in__, value_in__, pse_shift_in__=None, atten_mask_in__=None, actual_seq_lengths_in__=None, actual_seq_lengths_kv_in__=None, dequant_scale1_in__=None, quant_scale1_in__=None, dequant_scale2_in__=None, quant_scale2_in__=None, quant_offset2_in__=None, antiquant_scale_in__=None, antiquant_offset_in__=None, block_table_in__=None, query_padding_size_in__=None, kv_padding_size_in__=None, key_antiquant_scale_in__=None, key_antiquant_offset_in__=None, value_antiquant_scale_in__=None, value_antiquant_offset_in__=None, key_shared_prefix_in__=None, value_shared_prefix_in__=None, actual_shared_prefix_len_in__=None, query_rope_in__=None, key_rope_in__=None, key_rope_antiquant_scale_in__=None, dequant_scale_query_in__=None, learnable_sink_in__=None, q_start_idx_in__=None, kv_start_idx_in__=None, attention_out_out_=None, softmax_lse_out_=None, num_heads=0, scale=1, pre_tokens=2147483647, next_tokens=2147483647, input_layout="BSH", num_key_value_heads=0, sparse_mode=0, inner_precise=1, block_size=0, antiquant_mode=0, softmax_lse_flag=False, key_antiquant_mode=0, value_antiquant_mode=0, query_quant_mode=0, pse_type=0, out_dtype=0, kernel_name="fused_infer_attention_score", impl_mode = ""):
    # do ascendc build step
    if get_current_build_config("enable_op_prebuild"):
        return
    __inputs__, __outputs__, __attrs__ = _build_args(query_in__, key_in__, value_in__, pse_shift_in__, atten_mask_in__, actual_seq_lengths_in__, actual_seq_lengths_kv_in__, dequant_scale1_in__, quant_scale1_in__, dequant_scale2_in__, quant_scale2_in__, quant_offset2_in__, antiquant_scale_in__, antiquant_offset_in__, block_table_in__, query_padding_size_in__, kv_padding_size_in__, key_antiquant_scale_in__, key_antiquant_offset_in__, value_antiquant_scale_in__, value_antiquant_offset_in__, key_shared_prefix_in__, value_shared_prefix_in__, actual_shared_prefix_len_in__, query_rope_in__, key_rope_in__, key_rope_antiquant_scale_in__, dequant_scale_query_in__, learnable_sink_in__, q_start_idx_in__, kv_start_idx_in__, attention_out_out_, softmax_lse_out_, num_heads, scale, pre_tokens, next_tokens, input_layout, num_key_value_heads, sparse_mode, inner_precise, block_size, antiquant_mode, softmax_lse_flag, key_antiquant_mode, value_antiquant_mode, query_quant_mode, pse_type, out_dtype)
    options = get_dtype_fmt_options(__inputs__, __outputs__)
    options += ["-x", "cce"]
    bisheng = os.environ.get('BISHENG_REAL_PATH')
    if bisheng is None:
        bisheng = shutil.which("bisheng")
    if bisheng is not None:
        bisheng_path = os.path.dirname(bisheng)
        tikcpp_path = os.path.realpath(os.path.join(bisheng_path, "..", "..", "tikcpp"))
    else:
        tikcpp_path = os.path.realpath("/usr/local/Ascend/latest/compiler/tikcpp")
    options.append("-I" + tikcpp_path)
    options.append("-I" + os.path.join(tikcpp_path, "..", "..", "include"))
    options.append("-I" + os.path.join(tikcpp_path, "tikcfw"))
    options.append("-I" + os.path.join(tikcpp_path, "tikcfw", "impl"))
    options.append("-I" + os.path.join(tikcpp_path, "tikcfw", "interface"))
    options.append("-I" + os.path.join(tikcpp_path, "..", "ascendc", "act"))
    options.append("-I" + os.path.join(PYF_PATH, "..", "ascendc", "common"))
    toolkit_path = os.environ.get('ASCEND_HOME_PATH')
    if toolkit_path is None:
        toolkit_path = os.path.realpath("/usr/local/Ascend/latest/")
    options.append("-I" + toolkit_path + os.path.join("/", os.uname().machine +"-linux", "asc", "atcos"))
    op_common_path = os.path.realpath(toolkit_path + "/include/op_common/")
    options.append("-I" + op_common_path)
    op_common_path = os.path.realpath(toolkit_path + "/pkg_inc/op_common/")
    options.append("-I" + op_common_path)
    if "impl_mode" in locals():
        if impl_mode == "high_performance":
            options.append("-DHIGH_PERFORMANCE=1")
        elif impl_mode == "high_precision":
            options.append("-DHIGH_PRECISION=1")
        elif "high_precision" in impl_mode and "high_performance" in impl_mode:
            options.append("-DHIGH_PRECISION=1 -DHIGH_PERFORMANCE=1")
    if get_current_build_config("enable_deterministic_mode") == 1:
        options.append("-DDETERMINISTIC_MODE=1")
    else:
        options.append("-DDETERMINISTIC_MODE=0")
    ascendc_api_version_header_path = os.path.join(tikcpp_path, "tikcfw/lib/ascendc_api_version.h")
    if os.path.exists(ascendc_api_version_header_path):
        with open(ascendc_api_version_header_path, "r") as ascendc_api_version_file:
            ascendc_api_version = re.findall(r"#define ASCENDC_API_VERSION (\d+)", ascendc_api_version_file.read())
            if ascendc_api_version:
                options.append(f"-DASCENDC_API_VERSION={ascendc_api_version[0]}")
    custom_compile_options = {'__ALLSOC__': ['--cce-auto-sync=off', '-Wno-deprecated-declarations', '-mllvm', '-cce-vf-remove-membar=false', '-mllvm', '-cce-aicore-hoist-movemask=false']},
    custom_all_compile_options = {'__ALLSOC__': ['-DNOT_DYNAMIC_COMPILE']},
    soc_version = get_soc_spec("SOC_VERSION")
    soc_short = get_soc_spec("SHORT_SOC_VERSION").lower()
    custom_compile_options_soc = get_shortsoc_compile_option(custom_compile_options[0], soc_short)
    custom_all_compile_options_soc = get_shortsoc_compile_option(custom_all_compile_options[0], soc_short)
    options += custom_all_compile_options_soc
    options += custom_compile_options_soc

    origin_func_name = "fused_infer_attention_score"
    ascendc_src_dir_ex = "fused_infer_attention_score"
    ascendc_src_dir = "fused_infer_attention_score"
    ascendc_src_file = "fused_infer_attention_score.cpp"
    src = get_kernel_source(ascendc_src_file, ascendc_src_dir, ascendc_src_dir_ex)

    msg = "start compile Ascend C Operator FusedInferAttentionScore, kernel name is " + kernel_name
    CommonUtility.print_compile_log("", msg, AscendCLogLevel.LOG_INFO)
    op_type = "FusedInferAttentionScore"
    code_channel = get_code_channel(src, kernel_name, op_type, options)
    op_info = OpInfo(kernel_name = kernel_name, op_type = op_type, inputs = __inputs__, outputs = __outputs__,\
        attrs = __attrs__ , impl_mode = impl_mode, origin_inputs=[query_in__, key_in__, value_in__, pse_shift_in__, atten_mask_in__, actual_seq_lengths_in__, actual_seq_lengths_kv_in__, dequant_scale1_in__, quant_scale1_in__, dequant_scale2_in__, quant_scale2_in__, quant_offset2_in__, antiquant_scale_in__, antiquant_offset_in__, block_table_in__, query_padding_size_in__, kv_padding_size_in__, key_antiquant_scale_in__, key_antiquant_offset_in__, value_antiquant_scale_in__, value_antiquant_offset_in__, key_shared_prefix_in__, value_shared_prefix_in__, actual_shared_prefix_len_in__, query_rope_in__, key_rope_in__, key_rope_antiquant_scale_in__, dequant_scale_query_in__, learnable_sink_in__, q_start_idx_in__, kv_start_idx_in__], origin_outputs = [attention_out_out_, softmax_lse_out_],\
                param_type_dynamic = True, mc2_ctx = [], param_type_list = ['required', 'dynamic', 'dynamic', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'optional', 'required', 'required'], init_value_list = [None, None],\
                output_shape_depend_on_compute = [])
    compile_op(src, origin_func_name, op_info, options, code_channel, '{}', {'valueDepend': {5: 'optional', 6: 'optional', 23: 'optional', 29: 'optional', 30: 'optional'}})

def op_select_format(query_in__, key_in__, value_in__, pse_shift_in__=None, atten_mask_in__=None, actual_seq_lengths_in__=None, actual_seq_lengths_kv_in__=None, dequant_scale1_in__=None, quant_scale1_in__=None, dequant_scale2_in__=None, quant_scale2_in__=None, quant_offset2_in__=None, antiquant_scale_in__=None, antiquant_offset_in__=None, block_table_in__=None, query_padding_size_in__=None, kv_padding_size_in__=None, key_antiquant_scale_in__=None, key_antiquant_offset_in__=None, value_antiquant_scale_in__=None, value_antiquant_offset_in__=None, key_shared_prefix_in__=None, value_shared_prefix_in__=None, actual_shared_prefix_len_in__=None, query_rope_in__=None, key_rope_in__=None, key_rope_antiquant_scale_in__=None, dequant_scale_query_in__=None, learnable_sink_in__=None, q_start_idx_in__=None, kv_start_idx_in__=None, attention_out_out_=None, softmax_lse_out_=None, num_heads=0, scale=1, pre_tokens=2147483647, next_tokens=2147483647, input_layout="BSH", num_key_value_heads=0, sparse_mode=0, inner_precise=1, block_size=0, antiquant_mode=0, softmax_lse_flag=False, key_antiquant_mode=0, value_antiquant_mode=0, query_quant_mode=0, pse_type=0, out_dtype=0, impl_mode = ""):
    __inputs__, __outputs__, __attrs__ = _build_args(query_in__, key_in__, value_in__, pse_shift_in__, atten_mask_in__, actual_seq_lengths_in__, actual_seq_lengths_kv_in__, dequant_scale1_in__, quant_scale1_in__, dequant_scale2_in__, quant_scale2_in__, quant_offset2_in__, antiquant_scale_in__, antiquant_offset_in__, block_table_in__, query_padding_size_in__, kv_padding_size_in__, key_antiquant_scale_in__, key_antiquant_offset_in__, value_antiquant_scale_in__, value_antiquant_offset_in__, key_shared_prefix_in__, value_shared_prefix_in__, actual_shared_prefix_len_in__, query_rope_in__, key_rope_in__, key_rope_antiquant_scale_in__, dequant_scale_query_in__, learnable_sink_in__, q_start_idx_in__, kv_start_idx_in__, attention_out_out_, softmax_lse_out_, num_heads, scale, pre_tokens, next_tokens, input_layout, num_key_value_heads, sparse_mode, inner_precise, block_size, antiquant_mode, softmax_lse_flag, key_antiquant_mode, value_antiquant_mode, query_quant_mode, pse_type, out_dtype)
    result = check_op_cap("op_select_format", "FusedInferAttentionScore", __inputs__, __outputs__, __attrs__)
    return result.decode("utf-8")

def get_op_specific_info(query_in__, key_in__, value_in__, pse_shift_in__=None, atten_mask_in__=None, actual_seq_lengths_in__=None, actual_seq_lengths_kv_in__=None, dequant_scale1_in__=None, quant_scale1_in__=None, dequant_scale2_in__=None, quant_scale2_in__=None, quant_offset2_in__=None, antiquant_scale_in__=None, antiquant_offset_in__=None, block_table_in__=None, query_padding_size_in__=None, kv_padding_size_in__=None, key_antiquant_scale_in__=None, key_antiquant_offset_in__=None, value_antiquant_scale_in__=None, value_antiquant_offset_in__=None, key_shared_prefix_in__=None, value_shared_prefix_in__=None, actual_shared_prefix_len_in__=None, query_rope_in__=None, key_rope_in__=None, key_rope_antiquant_scale_in__=None, dequant_scale_query_in__=None, learnable_sink_in__=None, q_start_idx_in__=None, kv_start_idx_in__=None, attention_out_out_=None, softmax_lse_out_=None, num_heads=0, scale=1, pre_tokens=2147483647, next_tokens=2147483647, input_layout="BSH", num_key_value_heads=0, sparse_mode=0, inner_precise=1, block_size=0, antiquant_mode=0, softmax_lse_flag=False, key_antiquant_mode=0, value_antiquant_mode=0, query_quant_mode=0, pse_type=0, out_dtype=0, impl_mode = ""):
    __inputs__, __outputs__, __attrs__ = _build_args(query_in__, key_in__, value_in__, pse_shift_in__, atten_mask_in__, actual_seq_lengths_in__, actual_seq_lengths_kv_in__, dequant_scale1_in__, quant_scale1_in__, dequant_scale2_in__, quant_scale2_in__, quant_offset2_in__, antiquant_scale_in__, antiquant_offset_in__, block_table_in__, query_padding_size_in__, kv_padding_size_in__, key_antiquant_scale_in__, key_antiquant_offset_in__, value_antiquant_scale_in__, value_antiquant_offset_in__, key_shared_prefix_in__, value_shared_prefix_in__, actual_shared_prefix_len_in__, query_rope_in__, key_rope_in__, key_rope_antiquant_scale_in__, dequant_scale_query_in__, learnable_sink_in__, q_start_idx_in__, kv_start_idx_in__, attention_out_out_, softmax_lse_out_, num_heads, scale, pre_tokens, next_tokens, input_layout, num_key_value_heads, sparse_mode, inner_precise, block_size, antiquant_mode, softmax_lse_flag, key_antiquant_mode, value_antiquant_mode, query_quant_mode, pse_type, out_dtype)
    result = check_op_cap("get_op_specific_info", "FusedInferAttentionScore", __inputs__, __outputs__, __attrs__)
    return result.decode("utf-8")
