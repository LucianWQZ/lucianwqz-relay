#include "torch_npu/csrc/core/npu/NPUGraph.h"
#include "torch_npu/csrc/core/npu/NPUCachingAllocator.h"
#include "torch_npu/csrc/core/npu/NPUFunctions.h"
#include "torch_npu/csrc/core/npu/NPUStreamUtils.h"
#include "torch_npu/csrc/aten/NPUGeneratorImpl.h"
#include "torch_npu/csrc/core/npu/register/OptionRegister.h"
#include "torch_npu/csrc/core/npu/GetCANNInfo.h"
#include "third_party/acl/inc/acl/error_codes/rt_error_codes.h"
#include "torch_npu/csrc/core/npu/sys_ctrl/npu_sys_ctrl.h"

#include <cstddef>
#include <cstdint>
#include <vector>

#include <ATen/Functions.h>

namespace c10_npu {

static bool _npu_graphs_debug = false;

namespace {
void apply_cache_op_info(aclrtStream stream, bool enabled)
{
    if (!IsGteCANNVersion("8.5.0", "CANN")) {
		return;
	}
    aclrtStreamAttrValue val;
    val.cacheOpInfoSwitch = static_cast<uint32_t>(enabled ? 1u : 0u);
    int32_t ret = c10_npu::acl::AclrtSetStreamAttribute(stream, aclrtStreamAttr::ACL_STREAM_ATTR_CACHE_OP_INFO,
        &val);
    if (ret == ACL_ERROR_RT_PARAM_INVALID) {
        ASCEND_LOGW("Report shape function is disabled due to incompatible CANN version.");
    } else {
        TORCH_CHECK(ret == ACL_RT_SUCCESS, "AclrtSetStreamAttribute failed with error code: ", ret);
    }
}
}

MempoolId_t graph_pool_handle()
{
    // Sets just the second value, to distinguish it from MempoolId_ts created from
    // aclmdlRICaptureGetInfo id_s in capture_begin.
    auto new_pool = c10_npu::MemPool();
    return new_pool.id();
}

void graph_task_group_begin(c10_npu::NPUStream stream)
{
    c10_npu::detail::checkNotExternalStream(stream, "graph_task_group_begin");
    NPU_CHECK_ERROR(c10_npu::acl::AclmdlRICaptureTaskGrpBegin(stream));
}

NPUTaskGroupHandle graph_task_group_end(c10_npu::NPUStream stream)
{
    c10_npu::detail::checkNotExternalStream(stream, "graph_task_group_end");
    aclrtTaskGrp group;
    NPU_CHECK_ERROR(c10_npu::acl::AclmdlRICaptureTaskGrpEnd(stream, &group));
    NPUTaskGroupHandle handle;
    handle.task_group = group;
    return handle;
}

void graph_task_update_begin(c10_npu::NPUStream stream, NPUTaskGroupHandle handle)
{
    c10_npu::detail::checkNotExternalStream(stream, "graph_task_update_begin");
    NPU_CHECK_ERROR(c10_npu::acl::AclmdlRICaptureTaskUpdateBegin(stream, handle.task_group));
}

void graph_task_update_end(c10_npu::NPUStream stream)
{
    c10_npu::detail::checkNotExternalStream(stream, "graph_task_update_end");
    NPU_CHECK_ERROR(c10_npu::acl::AclmdlRICaptureTaskUpdateEnd(stream));
}

void super_kernel_scope_begin(const char* scope_name)
{
    auto stream = c10_npu::getCurrentNPUStream();
    c10_npu::detail::checkNotExternalStream(stream, "super_kernel_scope_begin");
    NPU_CHECK_ERROR(c10_npu::skapi::AclskScopeBegin(scope_name, stream));
}

void super_kernel_scope_end(const char* scope_name)
{
    auto stream = c10_npu::getCurrentNPUStream();
    c10_npu::detail::checkNotExternalStream(stream, "super_kernel_scope_end");
    NPU_CHECK_ERROR(c10_npu::skapi::AclskScopeEnd(scope_name, stream));
}

void launch_callback(c10_npu::NPUStream stream, NPUCallbackFunc func, void *fnData)
{
    c10_npu::detail::checkNotExternalStream(stream, "launch_callback");
    aclrtCallbackBlockType type = aclrtCallbackBlockType::ACL_CALLBACK_BLOCK;
    NPU_CHECK_ERROR(c10_npu::acl::AclrtLaunchCallback(func, fnData, type, stream));
}

void launch_host_func(c10_npu::NPUStream stream, NPUCallbackFunc func, void *fnData)
{
    NPU_CHECK_ERROR(c10_npu::acl::AclrtLaunchHostFunc(stream, func, fnData));
}

void subscribe_report(uint64_t threadId, c10_npu::NPUStream stream)
{
    c10_npu::detail::checkNotExternalStream(stream, "subscribe_report");
    NPU_CHECK_ERROR(c10_npu::acl::AclrtSubscribeReport(threadId, stream));
}

void unsubscribe_report(uint64_t threadId, c10_npu::NPUStream stream)
{
    c10_npu::detail::checkNotExternalStream(stream, "unsubscribe_report");
    NPU_CHECK_ERROR(c10_npu::acl::AclrtUnSubscribeReport(threadId, stream));
}

/**
 * Note [CUDA Graph Wrapper Class]
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Q: Why do we need graph capture and launch bindings in Pytorch?
 *    Why can't they live in a user extension, for example?
 *
 * A1: Convenience.
 * A2: To ensure valid numerics on replay, some native CUDA ops (like RNG ops with
 *     CPU statefulness) need cooperation from the capture and replay bindings
 *     (see Note [CUDA Graph-safe RNG states] in CUDAGeneratorImpl.h).
 *
 *     We can't expect users to know about this cooperation.  If users write capture
 *     bindings naively in an extension, they likely won't interact with the native
 *     ops properly.  Their graphs would yield invalid numerics on replay.
 */

/**
 * Note [Interaction with CUDA graph capture] in CUDACachingAllocator.cpp
 * describes memory management for captures.
 */

NPUGraph::NPUGraph()
    // NPUStreams may not be default-constructed.
    : capture_stream_(c10_npu::getCurrentNPUStream()) {
}

void NPUGraph::register_generator_state(c10::intrusive_ptr<at_npu::NPUGeneratorState> state)
{
    captured_generator_states_[std::move(state)] = 0;
}

void NPUGraph::register_generator_state(const at::Generator& generator)
{
    c10::intrusive_ptr<at_npu::NPUGeneratorImpl> npu_gen =
        c10::dynamic_intrusive_pointer_cast<at_npu::NPUGeneratorImpl>(generator.getIntrusivePtr());
    npu_gen->register_graph(this);
}

void NPUGraph::capture_begin(MempoolId_t pool, aclmdlRICaptureMode capture_mode, bool report_shape)
{
    NPUGRAPH_LOGD("NPUGRAPH Capture begin");
    static const auto _task_queue_enable = c10_npu::option::OptionsManager::GetTaskQueueEnable();
    TORCH_CHECK(_task_queue_enable != 2,
        "Do not support TASK_QUEUE_ENABLE = 2 during NPU graph capture, please "
        "export TASK_QUEUE_ENABLE=1/0.",
        PTA_ERROR(ErrCode::NOT_SUPPORT));

    TORCH_CHECK(!has_graph_exec_,
                "This NPUGraph instance already owns a captured graph. "
                "To capture a new graph, create a new instance.");

    auto stream = c10_npu::getCurrentNPUStream();
    c10_npu::detail::checkNotExternalStream(stream, "NPUGraph::capture_begin");

    TORCH_CHECK(stream != c10_npu::getDefaultNPUStream(),
                "NPU graphs must be captured on a non-default stream. "
                "(However, after capture, it's ok to replay them on the "
                "default stream.)");

    apply_cache_op_info(stream, report_shape);

    // default generator is always registered
    auto* gen = at::get_generator_or_default<at_npu::NPUGeneratorImpl>(c10::nullopt, at_npu::detail::getDefaultNPUGenerator());
    gen->register_graph(this);
    gen->set_secondary_stream_capture_state(false);

    for (auto& [generator_state, wholegraph_increments] : captured_generator_states_) {
        generator_state->capture_prologue();
    }

    capture_stream_ = stream;
    capture_dev_ = c10_npu::current_device();

    if (pool.first != 0 || pool.second != 0) {
        // Either value being nonzero means the user supplied a pool to share.
        // But only one should be nonzero.
        // If pool was created by another graph's capture_begin, first should be nonzero.
        // If pool was created by graph_pool_handle, second should be nonzero.
        TORCH_INTERNAL_ASSERT(!(pool.first && pool.second));
        mempool_id_ = pool;
    } else {
        // User did not ask us to share a mempool. Create graph pool handle using is_user_created=false.
        // Sets just the first value, to distinguish it from MempoolId_ts created by graph_pool_handle().
        auto mempool = c10_npu::MemPool({}, false);
        mempool_id_ = mempool.id();
        TORCH_INTERNAL_ASSERT(mempool_id_.first > 0);
    }

    NPUGRAPH_LOGD("NPUGRAPH Capture beginAllocateToPool: mempool_id=(%lu,%lu)", mempool_id_.first, mempool_id_.second);
    // Addendum: beginAllocateStreamToPool is now called before cudaStreamBeginCapture to prevent an
    // autograd thread's free() call triggering an invalid cudaEventRecord in the caching allocator
    // due to the capture status being updated _after_ a capture had already started.
    c10_npu::NPUCachingAllocator::beginAllocateToPool(capture_dev_, mempool_id_, [this](aclrtStream stream) {
        aclmdlRICaptureStatus status;
        aclmdlRI model_ri;
        NPU_CHECK_ERROR(c10_npu::acl::AclmdlRICaptureGetInfo(stream, &status, &model_ri));
        return status == aclmdlRICaptureStatus::ACL_MODEL_RI_CAPTURE_STATUS_ACTIVE && model_ri == model_ri_;
    });

    // cudaStreamCaptureModeGlobal is the most conservative option to
    // prevent potentially unsafe CUDA API calls during capture.
    NPU_CHECK_ERROR(c10_npu::acl::AclmdlRICaptureBegin(capture_stream_, capture_mode));

    aclmdlRICaptureStatus status;
    NPU_CHECK_ERROR(c10_npu::acl::AclmdlRICaptureGetInfo(stream, &status, &model_ri_));
    TORCH_INTERNAL_ASSERT(status == aclmdlRICaptureStatus::ACL_MODEL_RI_CAPTURE_STATUS_ACTIVE);

    NPUGRAPH_LOGD("NPUGRAPH Capture begin done: model_ri=%p, capture_dev=%d, "
                  "mempool_id=(%lu,%lu), stream=%p, capture_mode=%d",
                  static_cast<void*>(model_ri_), capture_dev_,
                  mempool_id_.first, mempool_id_.second,
                  static_cast<void*>(capture_stream_.stream(false)), static_cast<int>(capture_mode));
}

void NPUGraph::capture_end()
{
    NPUGRAPH_LOGD("NPUGRAPH Capture end");
    auto stream = c10_npu::getCurrentNPUStream();

    c10_npu::detail::checkNotExternalStream(stream, "NPUGraph::capture_end");

    TORCH_CHECK(stream == capture_stream_,
                "Capture must end on the same stream it began on.");

    apply_cache_op_info(stream, false);

    aclmdlRI model_ri;
    NPU_CHECK_ERROR(c10_npu::acl::AclmdlRICaptureEnd(capture_stream_, &model_ri));

    c10_npu::NPUCachingAllocator::endAllocateToPool(capture_dev_, mempool_id_);

    TORCH_CHECK(model_ri == model_ri_, "Invalid end capture model id: ", model_ri);

    // In typical graph usage some tensors (e.g. the tensors used for graph IO) are not freed
    // between replays.
    // If Pytorch compiles and runs with a CUDA 11.4+ toolkit, there's a chance the allocator backend
    // is cudaMallocAsync.
    // cudaMallocAsync is generally graph-safe, but if some tensors are not freed between replays,
    // the graph's internal bookkeeping requires that we instantiate with
    // cudaGraphInstantiateFlagAutoFreeOnLaunch. See
    // cudaGraphLaunch
    // cudaGraphInstantiateWithFlags
    has_graph_exec_ = true;

    for (auto& [generator_state, wholegraph_increments] : captured_generator_states_) {
        wholegraph_increments = generator_state->capture_epilogue();
    }

    uint32_t num_graph_nodes = 0;

    NPUGRAPH_LOGD("NPUGRAPH Capture end done: model_ri=%p, has_graph_exec=%d",
                  static_cast<void*>(model_ri_), static_cast<int>(has_graph_exec_));
}

void NPUGraph::replay()
{
    NPUGRAPH_LOGD("NPUGRAPH Replay model_ri=%p, device=%d", static_cast<void*>(model_ri_), capture_dev_);
    TORCH_CHECK(has_graph_exec_,
                "Called NPUGraph::replay without a preceding successful capture.");

    c10::OptionalDeviceGuard device_guard{capture_stream_.device()};

    for (auto& [generator_state, wholegraph_increments] : captured_generator_states_) {
        generator_state->replay_prologue(wholegraph_increments);
    }

    // model_ri_ may be replayed in any stream.
    auto stream = c10_npu::getCurrentNPUStream();
    NPU_CHECK_ERROR(c10_npu::acl::AclmdlRIExecuteAsync(model_ri_, stream));
    if (c10_npu::option::OptionsManager::CheckBlockingEnable() &&
        !c10_npu::detail::isExternalStream(stream)) {
        NPU_CHECK_ERROR(c10_npu::acl::AclrtSynchronizeStreamWithTimeout(stream));
    }
}

void NPUGraph::enable_debug_mode()
{
    _npu_graphs_debug = true;
}

void NPUGraph::debug_dump(const std::string& debug_path)
{
    NPUGRAPH_LOGD("NPUGRAPH Debug dump to %s", debug_path.c_str());
    if (has_graph_exec_) {
        TORCH_WARN("calling NPUGraph::debug_dump() for model id ", model_ri_);
        NPU_CHECK_ERROR(c10_npu::acl::AclmdlRIDebugJsonPrint(model_ri_, debug_path.c_str(), 1));
    } else {
        TORCH_WARN("Called NPUGraph::debug_dump without a preceding successful capture.");
    }
}

void NPUGraph::super_kernel_optimize(const aclskOptions *options)
{
    TORCH_CHECK(has_graph_exec_,
                "Called NPUGraph::super_kernel_optimize without a preceding successful capture.");
    NPU_CHECK_ERROR(c10_npu::skapi::AclskOptimize(model_ri_, options));
}

void NPUGraph::reset()
{
    // I'd prefer these checks throw exceptions, not print warnings,
    // but the destructor calls reset(), and at least one CI build
    // refuses to compile with a throwing destructor.
    //
    // Instead of calling reset() in the destructor to clean up, I could
    // call reset() in the __del__ method of a thin Python wrapper,
    // in which case reset would be allowed to throw exceptions.
    // But Stackoverflow does not like user-defined __del__.
    // __del__ prevents Graph instances from EVER being garbage collected
    // if they participate in a reference cycle.
    // And exceptions thrown in __del__ only print a warning anyway.
    //
    // Calling reset() in the C++ destructor, with warnings instead of exceptions
    // if calls fail, is the compromise we chose.
    //
    // If capture_begin, the capture, or capture_end failed at some point, this NPUGraph, the generator,
    // and the allocator could end up in all kinds of weird states depending where failure occurred.
    // If the user catches the failure exception in a script, or is running in REPL or (god forbid)
    // a Jupyter notebook, I don't see an easy way for reset() to gracefully fix all such possible error states.
    if (has_graph_exec_) {
        NPUGRAPH_LOGD("NPUGRAPH Reset releasing graph: model_ri=%p, capture_dev=%d, "
                      "mempool_id=(%lu,%lu)",
                      static_cast<void*>(model_ri_), capture_dev_,
                      mempool_id_.first, mempool_id_.second);
        // notifyCaptureDestroy may throw. How should we handle this?
        c10_npu::NPUCachingAllocator::releasePool(capture_dev_, mempool_id_);
        if (c10_npu::NpuSysCtrl::GetInstance().GetInitFlag()) {
            NPU_CHECK_WARN(c10_npu::acl::AclmdlRIDestroy(model_ri_));
        }
        has_graph_exec_ = false;
    }
}

// Returns an id another graph's capture_begin can use to share the same memory pool as this graph.
MempoolId_t NPUGraph::pool()
{
    TORCH_CHECK(has_graph_exec_,
                "Called NPUGraph::pool() without a preceding successful capture.");
    return mempool_id_;
}

NPUGraph::~NPUGraph()
{
    for (auto& [generator_state, wholegraph_increments] : captured_generator_states_) {
        generator_state->unregister_graph(this);
    }
    reset();
}

} // namespace c10_npu
