"""Explicit continuation of unrun C28 correctness cases on a fresh Phy0 lease.

No automatic invocation: the main agent reviews the first segment first. Same
fixed source/plan may reuse its accepted dependencies, never another SHA/run.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import uuid

from common_c28 import R, SID, RUN, PLAN, AUTH

C = R.parent / 'resource_coordination/node-39-101'
O = R / 'runs' / SID / 'orchestration'
SEGMENT = RUN / 'C28_segment_02'
LEASE = C / 'leases/phy-00'
END = dt.datetime.fromisoformat('2026-10-23T01:30:00+00:00').timestamp()
TOKEN = uuid.uuid4().hex


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write(path, value):
    temp = path.with_name(path.name + '.' + TOKEN + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)


def log(text):
    with (R / 'journal/progress.log').open('a') as f:
        f.write(now() + '：C28_CORRECTNESS_02，' + text + '\n')


def smi(name):
    p = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, timeout=15)
    path = SEGMENT / (name + '-npu-smi.txt')
    path.write_text(p.stdout + '\nSTDERR\n' + p.stderr)
    if p.returncode:
        raise RuntimeError('bounded management query failed')
    return p.stdout, path


def heartbeat(owner):
    current = json.loads((LEASE / 'owner.json').read_text())
    if current['token'] != TOKEN or current['task'] != 'graph':
        raise RuntimeError('C28 own lease changed')
    status = json.loads((R / 'journal/current_status.json').read_text())
    owner.update(heartbeat_at=now(), case=status.get('current_case'),
                 runner_pid=status.get('runner_pid'), worker_pids=status.get('model_worker_pids', []))
    write(LEASE / 'owner.json', owner)
    with (SEGMENT / 'heartbeats.jsonl').open('a') as f:
        f.write(json.dumps(dict(at=now(), case=owner['case'], loadavg=Path('/proc/loadavg').read_text().strip(),
             pr_active_runs=json.loads((R.parent / 'pr/state/ACTIVE_RUNS.json').read_text()))) + '\n')


def acquire():
    prior = json.loads((RUN / 'lease-release-after-pr.json').read_text())
    plan = json.loads(PLAN.read_text())
    if prior.get('status') != 'RELEASED' or prior['candidate_sha'] != plan['commit']:
        raise RuntimeError('prior C28 segment not safely released')
    for case in ('CONFIG', 'B0', 'C2', 'LIFE', 'UNWIND_materialize_after_copy'):
        row = json.loads((RUN / 'C28_campaign_01' / case / 'runner-result.json').read_text())
        if not row.get('dependency_satisfied') or row['source_identity'] != [plan['run_id'], plan['commit'], plan['tree']]:
            raise RuntimeError('required same-source correctness anchor missing: ' + case)
    protocol = hashlib.sha256((C / 'PROTOCOL_PR_PROPOSED.md').read_bytes()).hexdigest()
    graph = json.loads((C / 'acknowledgements' / ('graph_' + SID + '.json')).read_text())
    pr = json.loads((C / 'acknowledgements/pr_20261022T1938Z.json').read_text())
    if not protocol == graph['protocol_sha256'] == pr['protocol_sha256'] or not pr['coordination_established']:
        raise RuntimeError('joint protocol no longer matches')
    ack_path = C / 'acknowledgements' / ('pr_graph_c26_after_c21_' + SID + '.json')
    ack = json.loads(ack_path.read_text())
    if (ack.get('task') != 'pr' or ack.get('graph_session_id') != SID
            or ack.get('status') not in ('CARD_WINDOW_ACKNOWLEDGED_NO_ADDITIONAL_QUIET_COMMITMENT', 'AGREED')
            or ack.get('physical_chips') != [0] or ack['end_at'] != '2026-10-23T01:30:00+00:00'):
        raise RuntimeError('C28 continuation card window not acknowledged')
    earliest = dt.datetime.fromisoformat('2026-10-22T23:35:00+00:00').timestamp()
    if not earliest <= time.time() < END - 600 or time.time() >= json.loads(AUTH.read_text())['deadline_epoch_seconds']:
        raise RuntimeError('outside resource or task window')
    if time.time() < dt.datetime.fromisoformat(ack['start_at']).timestamp():
        first = json.loads((C / 'acknowledgements' / ('pr_graph_perf_after_pr_' + SID + '.json')).read_text())
        if first.get('status') != 'AGREED' or first['end_at'] != ack['start_at']:
            raise RuntimeError('adjacent acknowledged intervals do not cover this earlier start')
    active = json.loads((R.parent / 'pr/state/ACTIVE_RUNS.json').read_text())
    if any(0 in row.get('physical_chips', []) for row in active):
        raise RuntimeError('PR still declares active Phy0 use')
    text, path = smi('before-acquire')
    if 'No running processes found in NPU 0' not in text or '0000:9D:00.0' not in text:
        raise RuntimeError('fresh Phy0 mapping/occupancy not admitted')
    LEASE.mkdir()  # Atomic NFS protocol, never steal another task's lease.
    owner = dict(protocol_version=graph['protocol_version'], protocol_sha256=protocol, task='graph',
                 holder='graph', session=SID, run=plan['run_id'], token=TOKEN, physical_chips=[0],
                 physical_chip=0, pci='0000:9D:00.0', logical_device=0, rank=0,
                 host=socket.gethostname(), container_cgroup=Path('/proc/self/cgroup').read_text(),
                 pid=os.getpid(), process_start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                 pid_namespace=os.readlink('/proc/self/ns/pid'), mount_namespace=os.readlink('/proc/self/ns/mnt'),
                 boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                 acquired_at=now(), heartbeat_at=now(), status='HELD', case=None,
                 expires_at='2026-10-23T01:30:00+00:00', lease_deadline='2026-10-23T01:30:00+00:00',
                 resource_deadline='2026-10-23T05:34:42+00:00', candidate='C28',
                 candidate_sha=plan['commit'], candidate_tree=plan['tree'], card_ack=str(ack_path),
                 experiment_mode='CORRECTNESS_ONLY_NO_QUIET_PERFORMANCE_CLAIM', admission=str(path),
                 supervisor_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    write(LEASE / 'owner.json', owner)
    write(SEGMENT / 'segment.json', owner)
    log('原子取得新的Phy0租约，至01:30UTC；仅正确性，不借后段卡窗口声称正式性能。')
    return owner


def release(owner):
    leftovers = []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name) in (os.getpid(), os.getppid()):
            continue
        try:
            a = [v.decode(errors='replace') for v in (p / 'cmdline').read_bytes().split(b'\0') if v]
            text = ' '.join(a)
            if a and (Path(a[0]).name.startswith('python') or Path(a[0]).name in ('msprof', 'torchrun')):
                if '/candidates/C28_graph_failure/' in text or '/runs/' + SID + '/' in text:
                    leftovers.append(dict(pid=int(p.name), argv=a))
        except (OSError, ProcessLookupError):
            pass
    text, path = smi('release')
    if leftovers or 'No running processes found in NPU 0' not in text:
        write(SEGMENT / 'release-blocked.json', dict(processes=leftovers, evidence=str(path)))
        raise RuntimeError('own worker/context exit not yet established; keep own lease for audit')
    current = json.loads((LEASE / 'owner.json').read_text())
    if current['token'] != TOKEN or current['task'] != 'graph':
        raise RuntimeError('refuse foreign lease release')
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != owner['supervisor_source_sha256']:
        raise RuntimeError('running supervisor source changed')
    owner.update(status='RELEASED', released_at=now(), release_evidence=str(path),
                 task_processes_exited=True, device_contexts_released=True, completion_proof='NOT_INFERRED')
    write(SEGMENT / 'lease-release.json', owner)
    write(C / 'releases' / (TOKEN + '-phy-00.json'), owner)
    shutil.rmtree(LEASE)  # Only this validated token's directory.
    log('全部本任务worker/profiler退出，管理查询确认释放资源，已归还自己的Phy0租约；不推导设备完成验收。')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cases', nargs='+', required=True)
    args = parser.parse_args()
    SEGMENT.mkdir(exist_ok=False)
    owner = acquire()
    rows = []
    try:
        steps = [('probe', [sys.executable, str(O / 'probe_c28_02.py')])]
        steps += [(case, [sys.executable, str(O / 'admit_case_c28_02.py'), '--case', case]) for case in args.cases]
        for name, argv in steps:
            minimum = 1560 if name in ('NUMERIC_TARGET4', 'TARGET4_OFF') else 540 if name == 'NUMERIC_SENTINEL' else 210
            if END - time.time() < minimum:
                rows.append(dict(case=name, status='NOT_STARTED_INSUFFICIENT_WINDOW', remaining_seconds=END-time.time()))
                write(SEGMENT / 'case-results.json', rows)
                continue
            heartbeat(owner)
            owner['case'] = name
            write(LEASE / 'owner.json', owner)
            log('开始' + name + '；新鲜committed准入/独立attempt，以case实际checker与runner裁决为准。')
            with (SEGMENT / (name + '.log')).open('xb') as f:
                p = subprocess.Popen(argv, cwd=O, stdout=f, stderr=subprocess.STDOUT)
                while p.poll() is None:
                    try:
                        p.wait(timeout=30)
                    except subprocess.TimeoutExpired:
                        heartbeat(owner)
            rows.append(dict(case=name, argv=argv, pid=p.pid, returncode=p.returncode, ended_at=now()))
            write(SEGMENT / 'case-results.json', rows)
            if p.returncode:
                break  # Main agent preserves first cause and assesses safe independent continuation.
    finally:
        release(owner)
    return 0 if all(row.get('returncode') == 0 for row in rows) else 2


if __name__ == '__main__':
    raise SystemExit(main())
