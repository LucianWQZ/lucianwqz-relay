"""Prepare the exact C28 checkout/runtime without loading a model or NPU.

Run only in a confirmed preparation gap, with an absolute stop time. The
model-file hashing is intentional and must finish before a performance window.
"""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

from common_c28 import R, SID, SOURCE, PLAN, VLLM, PYTHON, environment

SHA = 'c877639472386aedeb7df11f15b6bf75c078261c'
TREE = '729a2d3bc76ac814d1555cb4a457b513bb0b413f'
REPORT = R / 'reports' / SID


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 << 20), b''):
            h.update(b)
    return h.hexdigest()


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def log(text):
    with (R / 'journal/progress.log').open('a') as f:
        f.write(now() + '：C28_HOST_PREPARE，' + text + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stop-at', required=True, help='absolute timezone-aware preparation cutoff')
    args = parser.parse_args()
    cutoff = dt.datetime.fromisoformat(args.stop_at).timestamp()
    if cutoff - time.time() < 30:
        raise RuntimeError('preparation gap insufficient; no work started')
    result = dict(started_at=now(), source_sha=SHA, source_tree=TREE, stop_at=args.stop_at,
                  model_loaded=False, device_probe=False, status='STARTED')
    path = REPORT / 'C28_runtime_prepare_execution.json'

    def command(argv, *, cwd=None, stdout=None):
        remaining = cutoff - time.time() - 3
        if remaining < 1:
            raise TimeoutError('preparation cutoff; preserve partial outputs and use new attempt')
        completed = subprocess.run(argv, cwd=cwd, env=environment(), stdout=stdout,
                                   stderr=subprocess.STDOUT if stdout else None, timeout=remaining)
        if completed.returncode:
            raise RuntimeError('preparation command failed: ' + repr(argv))

    try:
        log('开始固定源码/runtime准备；当前未使用NPU；准备截止' + args.stop_at)
        if SOURCE.exists() or PLAN.parent.exists():
            raise RuntimeError('candidate/plan already exists; inspect it rather than overwrite')
        SOURCE.parent.mkdir(parents=True, exist_ok=True)
        command(['git', 'worktree', 'add', '--detach', str(SOURCE), SHA], cwd=R / 'work/vllm-ascend')
        actual = subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD^{tree}'], text=True).strip()
        if actual != TREE:
            raise RuntimeError('fixed checkout tree differs')
        donor = R / 'candidates/C21_warmup/vllm-ascend'
        manifest_path = R / 'state/R3_C21_RUNTIME_OVERLAY.json'
        if digest(manifest_path) != '2127a41b885c8f120131742b4696dad58744c06b87892e7ea91c80efa424d37e':
            raise RuntimeError('approved donor runtime manifest changed')
        manifest = json.loads(manifest_path.read_text())
        rows = []
        for row in manifest['overlay']:
            if time.time() > cutoff - 3:
                raise TimeoutError('overlay cutoff')
            rel = row['relative_path']
            if rel.endswith('.py') and rel != 'vllm_ascend/_build_info.py' or rel.endswith('.pyc'):
                raise RuntimeError('business Python/pyc must not come from a donor')
            source, target = donor / rel, SOURCE / rel
            if digest(source) != row['sha256']:
                raise RuntimeError('donor artifact changed: ' + rel)
            if target.exists():
                raise RuntimeError('overlay would overwrite checkout file: ' + rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            if target.stat().st_size != row['bytes'] or digest(target) != row['sha256']:
                raise RuntimeError('runtime artifact copy mismatch: ' + rel)
            rows.append(dict(relative_path=rel, bytes=row['bytes'], sha256=row['sha256'], donor=str(source)))
        overlay = dict(source_sha=SHA, source_tree=TREE, overlay=rows,
                       donor_manifest_sha256=digest(manifest_path),
                       scope='verified ignored native artifacts and generated A3 build metadata only; no business Python')
        (R / 'state/R3_C28_RUNTIME_OVERLAY.json').write_text(json.dumps(overlay, indent=2) + '\n')
        argv = [PYTHON, '-m', 'tools.p7x_graph_local_candidate', 'prepare', '--repo', str(SOURCE),
                '--vllm', str(VLLM), '--inputs', str(R / 'inputs' / SID), '--output', str(PLAN.parent),
                '--host-evidence', str(R / 'state/R3_C28_HOST_EVIDENCE.json'), '--run-id', 'r3-c28-phy0-' + SID]
        result['prepare_argv'] = argv
        with (REPORT / 'C28_prepare.log').open('xb') as output:
            command(argv, cwd=SOURCE, stdout=output)
        plan = json.loads(PLAN.read_text())
        result.update(status='FIXED_RUNTIME_AND_LOCAL_PLAN_PREPARED_NOT_DEVICE_PASS', plan=str(PLAN),
                      plan_sha256=digest(PLAN), overlay_file_count=len(rows),
                      counter_cases=[name for name in plan['cases'] if 'COUNTER_' in name],
                      fault_case=plan['cases']['UNWIND_materialize_after_copy']['argv'])
        log('固定源码/runtime及计划完成；尚无C28设备结果；不等同模型启动通过')
    except BaseException as error:
        result.update(status='PREPARATION_FAILED', error=repr(error))
        log('准备失败，保留全部部分产物：' + repr(error))
        raise
    finally:
        result['ended_at'] = now()
        path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')


if __name__ == '__main__':
    main()
