"""Graph-only adapter to the jointly acknowledged atomic mkdir protocol.

External supervision only. No hot-path device observations or synchronization.
All implementations and the admission subprocess are frozen before dispatch.
"""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import uuid

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID = '20261022T193442Z_R3'
O = R / 'runs' / SID / 'orchestration'
COORD = R.parent / 'resource_coordination/node-39-101'
RAW = R / 'runs' / SID / 'raw'
END = dt.datetime.fromisoformat('2026-10-23T00:30:00+00:00').timestamp()
START = dt.datetime.fromisoformat('2026-10-22T23:35:00+00:00').timestamp()
TOKEN = uuid.uuid4().hex
LEASE = COORD / 'leases/phy-00'


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write(path, value):
    temp = path.with_name(path.name + '.graph-' + TOKEN + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)


def log(message):
    with (R / 'journal/progress.log').open('a') as f:
        f.write(now() + '：' + message + '\n')


def smi(name):
    q = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, timeout=15)
    p = RAW / ('lease-' + TOKEN + '-' + name + '.txt')
    p.write_text(q.stdout + '\nSTDERR\n' + q.stderr)
    if q.returncode:
        raise RuntimeError('bounded npu-smi failed: ' + str(p))
    return q.stdout, p


def acquire():
    h = hashlib.sha256((COORD / 'PROTOCOL_PR_PROPOSED.md').read_bytes()).hexdigest()
    g = json.loads((COORD / 'acknowledgements' / ('graph_' + SID + '.json')).read_text())
    p = json.loads((COORD / 'acknowledgements/pr_20261022T1938Z.json').read_text())
    if h != g['protocol_sha256'] or h != p['protocol_sha256'] or not p['coordination_established']:
        raise RuntimeError('same protocol no longer jointly acknowledged')
    # Require PR's own explicit quiet-window acknowledgement, not Graph's request.
    acks = []
    for path in (COORD / 'acknowledgements').glob('pr*perf*.json'):
        row = json.loads(path.read_text())
        if row.get('task') == 'pr' and row.get('graph_session_id') == SID and row.get('status') == 'AGREED':
            if row.get('start_at') == '2026-10-22T23:35:00+00:00' and row.get('end_at') == '2026-10-23T00:30:00+00:00':
                acks.append(str(path))
    # Shared leases are acknowledged. Missing quiet approval limits interpretation, not authorization.
    mode = 'FORMAL_QUIET_COMPARISON' if acks else 'NORMAL_PATH_SHARED_LOAD_DIAGNOSTIC'
    requested = json.loads((COORD / 'requests/pr_tp16.json').read_text())
    if requested.get('status') in ('AGREED', 'ACQUIRED') and time.time() < dt.datetime.fromisoformat(requested['proposed_end_at']).timestamp():
        raise RuntimeError('PR extended active window; no NPU initialized')
    if not START <= time.time() < END - 600:
        raise RuntimeError('outside bounded admitted performance dispatch window')
    text, evidence = smi('before')
    if 'No running processes found in NPU 0' not in text or '0000:9D:00.0' not in text:
        raise RuntimeError('fresh mapped Phy0/board0 occupancy not admitted')
    pr_active = json.loads((R.parent / 'pr/state/ACTIVE_RUNS.json').read_text())
    other_npu_load = any('No running processes found in NPU ' + str(i) not in text for i in range(8))
    if pr_active or other_npu_load:
        mode = 'NORMAL_PATH_SHARED_LOAD_DIAGNOSTIC'
    LEASE.parent.mkdir(exist_ok=True)
    LEASE.mkdir()  # NFS verified atomic mkdir; never steal or edit PR leases.
    owner = dict(protocol_version=g['protocol_version'], protocol_sha256=h, task='graph',
                 holder='graph', session=SID, run=SID, token=TOKEN, physical_chip=0,
                 physical_chips=[0], pci='0000:9D:00.0', rank=0, logical_device=0,
                 host=socket.gethostname(), container_cgroup=Path('/proc/self/cgroup').read_text(),
                 pid=os.getpid(), process_start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                 pid_namespace=os.readlink('/proc/self/ns/pid'), mount_namespace=os.readlink('/proc/self/ns/mnt'),
                 boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                 acquired_at=now(), created_at=now(), heartbeat_at=now(), status='HELD',
                 expires_at='2026-10-23T00:30:00+00:00', lease_deadline='2026-10-23T00:30:00+00:00',
                 resource_deadline='2026-10-23T05:34:42+00:00', case=None,
                 candidate='C28', candidate_sha='c877639472386aedeb7df11f15b6bf75c078261c',
                 candidate_tree='729a2d3bc76ac814d1555cb4a457b513bb0b413f', experiment_mode=mode,
                 admission=str(evidence), quiet_window_ack=acks,
                 supervisor_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    write(LEASE / 'owner.json', owner)
    segment = RAW / 'C28_segment_01'
    segment.mkdir(exist_ok=False)
    write(segment / 'segment.json', owner)
    write(RAW / 'lease-acquisition-after-pr.json', owner)
    write(RAW / 'segment_scope_after_pr.json', dict(mode=mode, quiet_window_confirmed=bool(acks),
         producer_sha=owner['candidate_sha'], lease_token=TOKEN, device_physical=[0],
         control_repetitions_per_arm=3 if mode == 'FORMAL_QUIET_COMPARISON' else 1,
         formal_speedup_claim_allowed=bool(acks) and not pr_active and not other_npu_load,
         initial_pr_active_runs=pr_active, initial_other_npu_load=other_npu_load,
         diagnostic_limit='Shared-load attribution only when quiet is unconfirmed; no formal speedup claim',
         source_wrapper_sha256=owner['supervisor_source_sha256']))
    log('已原子取得Graph Phy0租约；范围23:35–00:30UTC，是否有安静确认见segment_scope_after_pr.json；probe后执行C28锚点与有限性能。')
    return owner


def heartbeat(owner):
    actual = json.loads((LEASE / 'owner.json').read_text())
    if actual['token'] != TOKEN or actual['task'] != 'graph':
        raise RuntimeError('own lease identity changed')
    status = json.loads((R / 'journal/current_status.json').read_text())
    owner.update(heartbeat_at=now(), case=status.get('current_case'), runner_pid=status.get('runner_pid'),
                 worker_pids=status.get('model_worker_pids', []), candidate=status.get('running_candidate') or 'C28')
    identities = []
    for pid in [status.get('runner_pid'), *status.get('model_worker_pids', [])]:
        if pid is None:
            continue
        try:
            identities.append(dict(pid=pid, start_ticks=Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[19]))
        except OSError:
            pass
    owner['pid_identities'] = identities
    write(LEASE / 'owner.json', owner)
    with (RAW / 'C28_segment_01/resource-heartbeats.jsonl').open('a') as f:
        f.write(json.dumps(dict(at=now(), case=owner.get('case'), loadavg=Path('/proc/loadavg').read_text().strip(), pr_active_runs=json.loads((R.parent / 'pr/state/ACTIVE_RUNS.json').read_text()))) + '\n')


def run(owner, argv, name):
    if time.time() > END - 210:
        return dict(step=name, status='NOT_STARTED_INSUFFICIENT_WINDOW')
    heartbeat(owner)  # Revalidate the actual shared owner token before EACH dispatch.
    owner.update(case=name, heartbeat_at=now())
    write(LEASE / 'owner.json', owner)
    with (RAW / 'per-case-lease-checks.jsonl').open('a') as checked:
        checked.write(json.dumps(dict(case=name, checked_at=now(), token=TOKEN,
             holder_pid=os.getpid(), physical_chip=0, candidate_sha=owner['candidate_sha'],
             lease_deadline=owner['lease_deadline'])) + '\n')
    path = RAW / ('chain-' + name + '.log')
    with path.open('xb') as f:
        p = subprocess.Popen(argv, cwd=O, stdout=f, stderr=subprocess.STDOUT)
        log(f'外部编排开始 {name}，PID={p.pid}；预计75–180秒（模型锚点历史），额外全组预热耗时未知；监督硬限420秒且00:30前退出。')
        while p.poll() is None:
            try:
                p.wait(timeout=30)
            except subprocess.TimeoutExpired:
                heartbeat(owner)
    return dict(step=name, argv=argv, pid=p.pid, returncode=p.returncode, log=str(path), ended_at=now())


def release(owner):
    # Do not infer device completion from process exit. This is resource release only.
    leftovers = []
    for q in Path('/proc').iterdir():
        if not q.name.isdigit() or int(q.name) in (os.getpid(), os.getppid()):
            continue
        try:
            parts = [x.decode(errors='replace') for x in (q / 'cmdline').read_bytes().split(b'\0') if x]
            a = ' '.join(parts)
            related = '/candidates/C28_graph_failure/' in a or '/runs/' + SID + '/' in a
            executable = Path(parts[0]).name if parts else ''
            worker_role = executable.startswith('python') or executable in ('msprof', 'torchrun', 'bisheng', 'ccec')
            if related and worker_role:
                leftovers.append(dict(pid=int(q.name), argv=a[:1500]))
        except (OSError, ProcessLookupError):
            pass
    text, evidence = smi('release')
    if leftovers or 'No running processes found in NPU 0' not in text:
        write(RAW / 'lease-release-blocked.json', dict(own_processes=leftovers, evidence=str(evidence)))
        raise RuntimeError('release cannot yet establish own worker/context exit; lease retained for audit')
    actual = json.loads((LEASE / 'owner.json').read_text())
    if actual['token'] != TOKEN or actual['task'] != 'graph':
        raise RuntimeError('refuse to release foreign lease')
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != owner['supervisor_source_sha256']:
        raise RuntimeError('supervisor file changed while executing; preserve lease/evidence for audit')
    owner.update(status='RELEASED', released_at=now(), release_evidence=str(evidence), task_processes_exited=True,
                 device_contexts_released=True, completion_proof='NOT_INFERRED')
    (COORD / 'releases').mkdir(exist_ok=True)
    write(COORD / 'releases' / (TOKEN + '-phy-00.json'), owner)
    write(RAW / 'lease-release-after-pr.json', owner)
    shutil.rmtree(LEASE)  # Only this validated token's own directory.
    write(COORD / 'acknowledgements' / ('graph_released_' + SID + '.json'),
          dict(task='graph', session_id=SID, state='RELEASED', released_at=now(), active_leases=[],
               no_graph_device_start_until='2026-10-22T23:30:00+00:00', release_evidence=str(evidence)))
    log('Graph已核验worker退出及NPU0无进程，释放自己的Phy0租约；本性能segment结束。资源释放不作为设备完成验收。')


def main():
    owner = acquire()
    results = []
    try:
        steps = [('probe', [sys.executable, str(O / 'probe_c28_01.py')])]
        steps += [(case, [sys.executable, str(O / 'admit_case_c28_01.py'), '--case', case]) for case in
                  (['P0', 'CONFIG', 'A0', 'A1', 'B0', 'UNWIND_materialize_after_copy', 'C2', 'LIFE'] +
                   (['PERF_WARM_OFF_long_01', 'PERF_WARM_ON_long_01', 'PERF_WARM_ON_long_02',
                     'PERF_WARM_OFF_long_02', 'PERF_WARM_OFF_long_03', 'PERF_WARM_ON_long_03']
                    if owner['experiment_mode'] == 'FORMAL_QUIET_COMPARISON' else
                    ['PERF_WARM_OFF_long_01', 'PERF_WARM_ON_long_01']) +
                   ['PROFILE_WARM_OFF_long_normal', 'PROFILE_WARM_ON_long_normal', 'COUNTER_LENGTH_VERIFY'] +
                   (['PERF_COUNTER_LEGACY_ON_long_01', 'PERF_COUNTER_REUSE_ON_long_01',
                     'PERF_COUNTER_REUSE_ON_long_02', 'PERF_COUNTER_LEGACY_ON_long_02',
                     'PERF_COUNTER_LEGACY_ON_long_03', 'PERF_COUNTER_REUSE_ON_long_03']
                    if owner['experiment_mode'] == 'FORMAL_QUIET_COMPARISON' else
                    ['PERF_COUNTER_LEGACY_ON_long_01', 'PERF_COUNTER_REUSE_ON_long_01']) +
                   ['PROFILE_COUNTER_LEGACY_ON_long_normal', 'PROFILE_COUNTER_REUSE_ON_long_normal'])]
        for name, argv in steps:
            row = run(owner, argv, name)
            results.append(row)
            write(RAW / 'chain-results-after-pr.json', results)
            if row.get('returncode') != 0:
                # This bounded branch has a shared correctness/quiet-window dependency.
                break
    finally:
        release(owner)
    return 0 if all(r.get('returncode') == 0 for r in results) else 2


if __name__ == '__main__':
    raise SystemExit(main())
