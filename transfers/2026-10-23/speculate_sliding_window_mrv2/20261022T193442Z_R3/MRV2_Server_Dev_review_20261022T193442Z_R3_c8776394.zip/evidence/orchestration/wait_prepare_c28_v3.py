"""Bounded C28 queue: Host preparation gap, then one jointly coordinated segment.

No NPU import or initialization in this waiting process. The fixed child
dispatch retains the committed inspect/probe/check/bind/runner admission.
"""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID = '20261022T193442Z_R3'
O = R / 'runs' / SID / 'orchestration'
C = R.parent / 'resource_coordination/node-39-101'
PREPARE_AT = dt.datetime.fromisoformat('2026-10-22T23:30:00+00:00').timestamp()
START = dt.datetime.fromisoformat('2026-10-22T23:35:00+00:00').timestamp()
LAST_START = dt.datetime.fromisoformat('2026-10-22T23:45:00+00:00').timestamp()
SELF_SHA = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def log(message):
    with (R / 'journal/progress.log').open('a') as f:
        f.write(now() + '：' + message + '\n')


def wait_until(epoch, text):
    while time.time() < epoch:
        log(text)
        time.sleep(min(30, epoch - time.time()))


def main():
    wait_until(PREPARE_AT, 'WAIT_PR_WINDOW，C28 Host修复已提交，当前未使用NPU、未持租约；23:30准备固定runtime，23:35按共同窗口及fresh准入派发。监控心跳不代表新模型进展。')
    # This gap is after the old PR window and before Graph measurements.
    # Do not hash model weights during an explicitly extended PR perf window.
    pr = json.loads((C / 'requests/pr_tp16.json').read_text())
    if pr.get('status') in ('AGREED', 'ACQUIRED'):
        end = dt.datetime.fromisoformat(pr['proposed_end_at']).timestamp()
        if end > time.time():
            log('WAIT_RESOURCE，PR延长的有效性能窗口尚未结束；不做重I/O或NPU派发，本次队列退出并保留恢复点。')
            return 3
    log('C28_HOST_PREPARE，PR原窗口已结束；开始有界runtime/模型文件哈希准备，硬截止23:34:45UTC，不加载模型。')
    argv = [sys.executable, str(O / 'prepare_c28_bounded.py'), '--stop-at', '2026-10-22T23:34:45+00:00']
    with (R / 'reports' / SID / 'C28_prepare_supervisor.log').open('xb') as f:
        p = subprocess.Popen(argv, cwd=O, stdout=f, stderr=subprocess.STDOUT)
        while p.poll() is None:
            try:
                p.wait(timeout=30)
            except subprocess.TimeoutExpired:
                log('C28_HOST_PREPARE，准备子进程PID=' + str(p.pid) + '仍运行；没有模型/NPU实验，等待固定计划结果。')
    result = dict(argv=argv, pid=p.pid, returncode=p.returncode, ended_at=now(),
                  scope='Host preparation, not probe or model startup')
    (R / 'runs' / SID / 'environment/C28_prepare_queue_outcome.json').write_text(json.dumps(result, indent=2) + '\n')
    if p.returncode:
        log('C28_HOST_PREPARE失败，保留原始异常；尚未启动设备，交主执行者定位，禁止把缺失计划当模型失败。')
        return 2
    wait_until(START, 'WAIT_PR_WINDOW，C28固定runtime/计划已准备；等23:35UTC设备窗口，尚未启动probe或模型。')
    while time.time() <= LAST_START:
        active = json.loads((R.parent / 'pr/state/ACTIVE_RUNS.json').read_text())
        using_zero = any(0 in row.get('physical_chips', []) for row in active)
        if not using_zero and not (C / 'leases/phy-00').exists():
            if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != SELF_SHA:
                raise RuntimeError('running waiter source changed; refuse dispatch')
            log('C28排队进入实际租约/设备准入；接下来先probe、CONFIG与B0，再新异常边界、LIFE和有限性能。')
            os.execv(sys.executable, [sys.executable, str(O / 'lease_window_chain_c28_01.py')])
        log('WAIT_RESOURCE，PR仍登记Phy0或共同租约被占；不初始化设备，最迟23:45UTC结束本次派发等待。')
        time.sleep(30)
    log('WAIT_RESOURCE截止，本次队列未获得Phy0且未启动NPU；保留恢复点，独立Host工作可继续。')
    return 3


if __name__ == '__main__':
    raise SystemExit(main())
