"""Saved reproduction of the inline C15 scope reduction; no new NPU evidence."""
import argparse
from collections import defaultdict
from decimal import Decimal as D
import json
from pathlib import Path
import statistics

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
OLD = R / 'runs/20261022T132626Z_R2/raw/C15_prepare_01'


def analyze():
    out = {}
    for name in ('PROFILE_ON_long_materialize', 'PROFILE_OFF_long_normal'):
        path = next((OLD / name / 'trace').rglob('trace_view.json'))
        doc = json.loads(path.read_text())
        events = doc['traceEvents'] if isinstance(doc, dict) else doc
        label = ('repair5/Draft_materialize_exact_length_snapshot' if '_ON_' in name else
                 'repair5/Draft_propose')
        ranges = [(e.get('pid'), e.get('tid'), D(str(e['ts'])), D(str(e['ts'])) + D(str(e.get('dur', 0))))
                  for e in events if e.get('ph') == 'X' and e.get('name') == label]
        totals = defaultdict(list)
        for event in events:
            if event.get('ph') != 'X' or not any(
                    x in event.get('name', '').lower() for x in ('synchronize', 'memcpy', 'tolist', 'copy_')):
                continue
            lo = D(str(event['ts']))
            hi = lo + D(str(event.get('dur', 0)))
            if any((event.get('pid'), event.get('tid')) == (pid, tid) and a <= lo and hi <= b
                   for pid, tid, a, b in ranges):
                totals[event['name']].append(float(event.get('dur', 0)))
        out[name] = dict(producer_sha='1e88c8208670518f63043552b530b1ed3e2f2677', source_trace=str(path),
                         result_scope='old C15 read-only reanalysis, no new NPU', ranges=len(ranges),
                         same_thread_contained_ops={k: dict(n=len(v), sum_us=sum(v), median_us=statistics.median(v),
                                                           max_us=max(v)) for k, v in totals.items()},
                         association='range containment only, not generation/task execution flow; '
                                     'Decimal trace microseconds, no Host-clock subtraction')
    return out


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists():
        raise ValueError('new output required')
    a.output.write_text(json.dumps(analyze(), ensure_ascii=False, indent=2) + '\n')
