"""Copy only small actual output/input fragments; never claim a complete joint."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');SID='20261022T193442Z_R3';RAW=R/'runs'/SID/'raw/C28_prepare_01/NUMERIC_SENTINEL';OUT=R/'reports'/SID/'review_numeric_fragments'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pairs(rows):
 d={}
 for k,v in rows:
  if k in d:raise ValueError('duplicate key '+str(k))
  d[k]=v
 return d

def load(p):return json.loads(p.read_text(),object_pairs_hook=pairs)
def decode(d):
 if not isinstance(d,dict):return d
 if 'tensor_ref' in d:return d
 if 'mapping' in d:return pairs([(decode(k),decode(v)) for k,v in d['mapping']])
 if 'list' in d:return [decode(v) for v in d['list']]
 if 'tuple' in d:return [decode(v) for v in d['tuple']]
 return {k:decode(v) for k,v in d.items()}

def main():
 OUT.mkdir(exist_ok=False);(OUT/'data').mkdir();(OUT/'original-manifests').mkdir()
 collection=load(RAW/'numeric-reference.json');joint=load(RAW/'numeric-joint.json');assert joint['status']=='PASS_NUMERIC_SENTINEL_ONLY';rows=[]
 for entry in collection['samples']:
  p=RAW/entry['path'];assert p.stat().st_size==entry['bytes'] and sha(p)==entry['sha256'];d=decode(load(p));assert d['identity']['source_sha']=='c877639472386aedeb7df11f15b6bf75c078261c'
  refs={key:d[key]['tensor_ref'] for key in ('graph','reference')};refs.update({key:d['inputs'][key]['tensor_ref'] for key in ('input_ids','positions','slot_mapping')})
  for ref in refs.values():
   assert ref['bytes']<=1<<20 and Path(ref['path']).name==ref['path'];source=RAW/collection['tensor_root']/ref['path'];assert sha(source)==ref['sha256'] and source.stat().st_size==ref['bytes']
   target=OUT/'data'/ref['path']
   if not target.exists():shutil.copy2(source,target)
  shutil.copy2(p,OUT/'original-manifests'/p.name)
  rows.append(dict(identity=d['identity'],scenario=d['case_identity']['scenario'],generation=d['generation'],epoch=d['epoch'],refs=refs,source_sample=dict(server_path=str(p),bytes=p.stat().st_size,sha256=sha(p)),original_manifest_copy='original-manifests/'+p.name))
 result=dict(schema='mrv2-review-numeric-fragment-v1',byte_order=sys.byteorder,rows=rows,
  source_collection=dict(server_path=str(RAW/'numeric-reference.json'),sha256=sha(RAW/'numeric-reference.json')),source_joint=dict(server_path=str(RAW/'numeric-joint.json'),sha256=sha(RAW/'numeric-joint.json'),status=joint['status']),
  atol=0.0,rtol=0.0,full_joint_recomputable_from_this_fragment=False,scope='OUTPUT_AND_SMALL_INPUT_RECALC_ONLY; full layers/KV/independent reference execution require indexed server artifacts')
 (OUT/'fragment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 (OUT/'说明.md').write_text('''# 真实C28数值前哨的小型复算片段\n\n包含A/B/A′实际graph/reference输出及input_ids/positions/slot_mapping小tensor，来自固定C28、Phy0。用Python标准库运行`python verify_fragment.py`，复算bytes/hash/dtype/shape、finite、严格输出差异与ABA输出区分/恢复。它不会运行模型或初始化NPU。\n\n这是局部数值片段，不是完整sample或Graph验收包。original-manifests保留原始manifest与哈希，里面的大KV引用仅在服务器原目录存在；不要把缺少KV的片段交给完整joint后宣称PASS。fragment.json明确full_joint_recomputable_from_this_fragment=false，服务器完整joint保留独立reference调用、完整层集合、输入/KV前态和代际验收。内容哈希去重会让相同值的graph/reference/A′指向同一bin文件；相同哈希自身不证明oracle独立性。\n\n完整数据根：'''+str(RAW)+'\n')
 print('fragment bytes',sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file()),'selected files',len(list((OUT/'data').iterdir())))

if __name__=='__main__':main()
