# 候选与证据对应（R3最终）

|候选|SHA|变化|设备范围|
|---|---|---|---|
|C19|da5b0f054c4b94362ff3539de911b26b4074052a|已验证基线|R2同SHA20case限定结果，原始身份保留|
|C20|eec9a0632f5bf21bfa6df4d3d0426ed2506f258b|全请求组预热/独立长请求/公共Host范围|本轮未执行NPU|
|C21|da542fc60ceab9c0b7dac79d90e55720c99a2cb8|修ON-long真实裁剪准入命名|runtime/plan已准备但从未派发；被C28替代|
|C22|df92c3a145fcb1ecc354f37118794399eb29e873|flow分类|旧trace首次直接CLI失败保留，非NPU|
|C23|8efe4d03a27ba586b867dc1b81408f81d9e89d20|直接trace CLI遮蔽修复|只读重算C17旧trace，不是新NPU|
|C24|8e5203d4480f12165f0ce11a6770ab238528814d|默认关闭CPU计数verify/reuse实验、严格外部证书|28项受影响Host，未NPU|
|C25|d4d9c0c5fb7dc6c9187d980e9604b1cd33f7d22c|Graph早期materialize/发布失败保留与重入拒绝|99项定向Host；扩展155通过1既有AST失败，未NPU|
|C26|26a33274d664a45fc87c7bc2c90c4ab9335d6bd0|按批准pin原件校准唯一精确AST指纹，反例保留|158项受影响Host通过，未NPU|
|C27|86a29c1d344f5fc30cdbb741e4178fa88131f15b|实验profiling明确长度来源与同步边界|28项Host通过；静态检查说明更正另存，未NPU|
|C28|c877639472386aedeb7df11f15b6bf75c078261c|收尾静态问题|162项受影响Host、11重叠flow/warmup通过；17变更文件ruff通过。已准备runtime；真实B0/C2/LIFE21代、早期异常、3样本前哨、完整12数值/ABA与4份profile已接受；Target4双臂12对与原4UNWIND均已完成并接受|

C19→C24 production tree=714c66dac1a25188feff466dea652277b21747c8；C25→C28=b568bdc5b88bc5b87ff2938d1961b97107d8952b。后者改异常路径，正常成功copy/stream/replay/UPDATE、Window数学、Target/full写入未变。故允许按影响引用C19正常数值/Target历史，但不能宣称C28同SHA全套已跑。新早期异常、多代与相关数值结果必须以新设备证据另列。

vLLM pin仍84030bbe3d74d99bad477a3d2e37a973ccd8865c/tree f3e320f8ae2e9a30e57a3c8dccfac94fcae93bee。原AST守卫FAIL在clean C19/clean pin重现；C26校正依据是该批准commit的确切Git blob及完整AST，不增备选哈希、不改数值标准，替换任一方法仍拒绝。

全部本轮本地提交REMOTE_PUBLICATION=NOT_PERFORMED。最终计数来自固定launcher/runner与独立源码关联复查：30个模型进程、1个fixture、2个probe、4个profiler采集（包含于模型计数）；33个case按各自checker接受。逐项分类见R3_CASE_SOURCE_AND_STATUS_AUDIT.json。C19原生15个post-drain参数绑定和4ABORT为历史身份；C28完整Target双臂12对见target_join_C28_01/target-join.json。public Graph Gate冻结。

## 最终覆盖

C28同SHA新执行30模型/1fixture/2probe/4profile，Target4 12数值/ABA及12对Target、LIFE21和5Python隔离；旧C19的native15与4ABORT仅历史引用。源码/报告/分析器/overlay变化分别记录，不拼成跨SHA全PASS。
