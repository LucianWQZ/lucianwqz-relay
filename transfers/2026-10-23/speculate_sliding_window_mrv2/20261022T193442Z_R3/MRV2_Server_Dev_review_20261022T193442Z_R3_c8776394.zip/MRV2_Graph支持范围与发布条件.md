# Graph支持范围建议与发布条件（待审）

本轮不打开public Graph Gate，不宣称全面支持。拟送审配置是**MRV2 DSpark TP1 Target4**；公开支持的批准由验收owner决定。

|配置|capture列表|实际Target库存（C19）|已有证据|本轮建议|
|---|---|---|---|---|
|Base|[7,14,28]|(1,8)/(2,16)，无(4,32)|Draft(1,7)/(2,14)/(4,28)锚点、请求、串行诊断；不等于完整Target4|保留实验范围；不把active4 Full Target写成支持|
|Target4独立扩展|[7,14,28,32]|另有(4,32)|12数值/ABA、Target双臂12对；active/padded1/1、2/2、3/4、4/4|作为完整已测活动数范围的拟支持配置送审；不是Base结果升级|

配置共同约束：Qwen3-8B + dspark_qwen3_8b_block7，K7/sample_from_anchor=true，Draft query7、Target query8，W1024/block128，TP/DP/PP/PCP/DCP均1，async/prefix/SP/DSA-CP/FlashComm保持冻结fixture关闭。InputIds=int32，positions=int64，DSpark noncausal；active3/padded4输入offset[0,7,14,21,21]，FIA padded q[7,14,21,28]，不cast、不放宽容差。

C19的Target比较范围是CONTROLLED_DECODE_SYNTHETIC_PRE_KV；ON臂带串行连续参考。数值/Target之外，LIFE21代、15个post-drain参数绑定、四ABORT/四真实Python展开分别保留诊断/隔离边界。没有扩展为所有自然请求、Eagle3、DFlash、TP8/TP16、Prefix/Async等组合通过。其他历史能力由各自正式证据决定，非Graph PR未被本任务接管。

## 缺桶处理与配置准入

- 内部Target4 producer已核对真实inventory包含(1,8)/(2,16)/(4,32)；缺桶需明确拒绝该Full Graph验收，不造bucket，不eager回退凑PASS。
- 公开Graph Gate目前仍默认拒绝。正式配置若批准，应统一在启动准入核对Target与Draft库存及最大active/padded范围；现有内部工具的拒绝不冒充已实现公开产品入口。
- Base可以提出另行限定active<=2的支持方案，但必须有明确产品约束/拒绝路径和对应请求矩阵；本轮不擅自宣布该支持范围已成立，也不把Base4缺桶反复当成新bug。

## 资源与性能

Target4相对Base增加一个Target capture bucket；额外HBM峰值/独立capture时间增量=NOT_AVAILABLE。原受控Target tensor存储大小不能作为Graph bucket显存代价。未测差值不填0。

旧正常性能约2K（最大2049）没有显示ON加速：R2 OFF三控制中位1648.35ms、ON1767.75ms，工作量/噪声/预热限制见Profiling报告。新3072工作负载单独hash，不能与旧2K总耗时直接算加速率。本轮已新采四份profile及12控制；该工作负载无Window加速，counter小差异未建立稳定收益。

## 发布前必须由审查明确的条件

1. 对正常A/B源码合同认可适用前提与例外：附加capture流尾notify合流、RI endGraphNotify/current FIFO、单update流与ExternalEvent协议、复制的Host vector。无需无信息增量重复dump，详见正常合同审查。
2. 对既定task-internal与physical-read要求给出裁决/可行证据方案。原生POST_DRAIN参数块不是执行occurrence，也不是实际KV读取地址集合。工程源码推导与物理观测分别审查。
3. 明确Target4产品配置、Base边界和缺桶拒绝策略；复核异常后的quarantine/进程隔离，未知native部分提交不设备恢复。
4. 实际production/runtime或capture策略改变时，按影响重验数值/ABA/Target与必要生命周期；C19→C24正常production不变；C25起有Graph异常保护修改。C28已取得新B0/LIFE/早期异常/完整12数值与ABA，C28 Target4 OFF与显式双臂12对join已完成。历史native15及4ABORT不改为C28新执行。

当前结论：代码与限定证据可提交正式审查；正式发布就绪程度仍受以上阻塞项约束，public Graph Gate=FROZEN。

## 2026-10-23T01:05:02.176277+00:00 已有启动资源记录

六个已完成的Base/Target4 LEGACY控制，实际LLM kwargs仅capture列表不同。总Graph memory都报告0.45GiB（两位小数），总KV约31.04GiB、warmup后reserved约49GiB；精确新增桶显存仍NOT_AVAILABLE，不填0。整数capture秒与顺序/cache未配平，不能据此说Target4比Base捕获更快。详见C28_Base与Target4_capture资源日志.json逐条日志路径/行号；新增桶实际inventory包含(4,32)。当前0.45GiB为启动整体Graph分配观察，不能当全部峰值HBM或该单桶独立成本。

## 最终C28限定结果

Target4完整12数值/ABA、双臂12对同SHA通过；ON仍带串行参考，Target为受控合成KV。LIFE21及5Python隔离同SHA，4ABORT和15参数快照为C19历史。拟支持配置是冻结DSpark TP1/Target4及已验证query7/8、active/padded1/1、2/2、3/4、4/4；公开产品任意请求形状/缺桶拒绝入口仍须审查，不用Base或profile请求成功自动升级。没有新的性能门槛被本Agent发明，测得回退/小差异原样交owner决定。
