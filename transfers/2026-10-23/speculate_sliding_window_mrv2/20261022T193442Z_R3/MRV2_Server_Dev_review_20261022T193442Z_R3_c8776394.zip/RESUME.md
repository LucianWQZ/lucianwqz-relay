# R3最小恢复说明

最后完成：C28三样本/完整12数值与ABA、Target4 ON/OFF12对联合复算、LIFE21、早期及4个Python展开；两段Phy0租约已释放，所有监督/worker/profiler/监控已退出，审计2026-10-23T01:08:33.113187+00:00。当前进入交付阶段，无需重新启动模型。

- SESSION_ID=20261022T193442Z_R3，起点2026-10-22T19:34:42+00:00，绝对deadline=2026-10-23T05:34:42+00:00；不自动续期。如果恢复时已过期，先取得新授权，不初始化设备。
- DEV=/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/work/vllm-ascend，HEAD=c877639472386aedeb7df11f15b6bf75c078261c，tree=729a2d3bc76ac814d1555cb4a457b513bb0b413f，tracked clean；未提交代码文件：无。
- fixed=/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/candidates/C28_graph_failure/vllm-ascend，runtime/plan均已准备，actual worker与10类二进制来源在environment记录，不从旧editable导入。
- raw=/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261022T193442Z_R3/raw。case-plan=C28_prepare_01/case-plan.json；实际case结果C28_campaign_01；准入admission_C28_attempt01/02；最终Target join=target_join_C28_01/target-join.json。
- 旧supervisors508120/676716，monitors426725/543101都已退出；不能凭旧PID存在与否越过starttime/boot核验，更不能重跑同一输出目录。恢复先查FINAL_process_and_lease_audit与实时租约。
- 下一条最小动作：审阅正常A/B合同和平台问题单，决定physical-read要求与Target4范围；无新平台能力时不重复native末值dump。需要集成PR时使用双方固定commit的新candidate，不改PR工作树。
- public Graph Gate=FROZEN，REMOTE_PUBLICATION=NOT_PERFORMED。不reset、不恢复未知native部分提交；只Host导出/隔离。
- 当前最后设备候选/数值候选/Target候选都C28；native15与4ABORT仍C19历史，源码影响引用清楚列出。
