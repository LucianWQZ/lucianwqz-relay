# Host验证范围

C57 rank-aware身份/漂移反例107项CPU通过；C58/C59 capture-source/owned Full query及相关方法定向76项通过。完整命令、stdout和失败红例在evidence中。早期失败和后续绿例都保留。
没有把定向CPU测试写成全仓CI通过；ruff/black/isort在现有环境不可用，未安装/升级共享工具。必要格式修正采用局部YAPF(120列)并记录AST等价，不宣称工具不可用即通过。
本包CPU输出/K片段重算仅验证实际持久化字节、finite及差分，不重新运行独立模型或整个KV验收。
