# Eagle3 真实写operand取证修正（待设备确认）

C48 的新数值诊断真实启动，在首个消费者比较 Full 绝对 slot 时拒绝，0份完整数值样本。原始结果保留，不重判为通过。

## 已确认的源码事实

Pinned AttentionBackend.forward_includes_kv_cache_update 默认为 True；AscendAttentionBackend 未覆盖该值。vLLM Attention.forward 仅在该值为 False 时单独调用 unified_kv_cache_update 读取 ForwardContext.slot_mapping。AscendAttentionBackendImpl.forward 在 key/value存在时调用 reshape_and_cache，该函数实际使用 attn_metadata.slot_mapping。

旧诊断 before_model 保存的是传入 _run_model 的 ForwardContext slots，却将其命名为 actual_slots。该字段对当前 backend 不是实际 KV 写operand。源码依据和完整文件hash见 Eagle3_write_operand_source/INDEX.json 及编号原文摘录。实际worker/backend identity仍须在新采集中核验。

## 本次修复与不变判据

schema升级v2：保存实际 metadata.slot_mapping 和未使用 ForwardContext slot 两份，记录并严格检查 backend职责、真实global group、字段及dtype。Full绝对slot仍由canonical Full table和实际positions独立推导；实际metadata slot不等、错误dtype、错误backend或group均须拒绝。参考前态/输出/KV后态仍保持原精确数值要求，不放宽容差。

若真实metadata slot仍不满足Full不变式，只导出在检查前已经复制到Host的最小值，停止该分支并隔离；不在错误后追加D2H、清零、恢复或复用旧backing。

旧C48仅能确认取证字段用错，尚不能由此断言生产写入正确；新C50固定候选真实结果决定是否还有production问题。v1失败原件不转为v2 PASS。额外capture拷贝/逐步drain仍属串行诊断，不证明正常异步复用或physical-read。
