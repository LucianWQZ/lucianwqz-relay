# C59 Eagle3 K后态反例与最小补证计划

已核验：第5样本long-three AR step1、generation367/epoch122；active3/padded4。两份active输出BF16精确一致，KV pre/reference_pre均精确一致；V post精确一致，K post物理块1/2差262139元素，Graph值大部分为0。当前Full slots[2050,770,386,-1]属于物理块16、6、3，不包括1/2。原完整9样本FAIL、exit74、隔离保留。

这不是输入dtype或数值容差问题。也不能由相同输出宣布KV正确。未证明究竟是实际生产K额外改写、capture快照输出/indices/流依赖问题，还是诊断restore的布局问题。

## 三个待区分假设

1. actual K cache在正常AR写入时改动了当前slot之外的块；需定位真实kernel写入与cache format/stride。
2. actual cache正确，但captured index_select快照的源/目的所有权、indices或task依赖不完整；只快照异常，不能先改生产数学。
3. 串行诊断的index_copy restore与cache实际storage格式交互改变了状态；参考前态内容相同不能单独排除后续布局/alias问题。

## 下一条最小有信息量实验

新固定默认关闭诊断producer，在任何数值判据触发之前，将两个AR consumer的已完成before/after快照、merged当前实际KV后态、indices、缓存format/shape/stride/storage身份一次性持久化。它们已在成功显式drain后完成，后续判失败只读Host证据，不能为取证在未知部分提交后继续设备操作。
比较AR1 post与AR2 pre应一致的未写区域，以及AR2 post与merged实际后态；对restore做新进程的无模型roundtrip小反例（只在已知完成的独占测试数据上）。可进一步区分真实写入与取证问题。

不只重新跑同一份9样本；不排除块1/2、不缩小KV检查集合、不放宽dtype/容差。新增同步会保持诊断性质，仍不是正常无附加同步证明。
