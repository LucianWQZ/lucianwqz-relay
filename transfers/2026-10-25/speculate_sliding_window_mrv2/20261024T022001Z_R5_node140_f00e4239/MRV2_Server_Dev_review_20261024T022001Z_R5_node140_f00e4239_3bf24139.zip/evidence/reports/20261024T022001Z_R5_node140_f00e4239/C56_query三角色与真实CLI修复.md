# C56：三种query字段的精确合同与checker真实启动修复

候选fc3e7a6c3769cb93895f4f7175c5ed75db7a79c9，tree b5da2247a16e09926cd06b5fd1a9f1756efe7481。当前仅Host55项通过，尚未设备验证。

## 原始失败

C54真实Eagle3数字诊断完成short-one的first/AR1/AR2三样本，Graph/reference的BF16输出和声明KV前后态一致；在下一个long-mixed first-pass遇到actual captured full query layout changed。整个9样本collection仍为INVALID_EVIDENCE，不能拼出完整通过。原件C54_prepare_01/EAGLE3_NUMERIC和reanalysis/C54_Eagle3_prefix_reanalysis.stdout.json保留。

## 三种字段的不同用途

- 捕获时辅助GPU query_start_loc：capture active=padded4，Q4时[0,4,8,12,16]。当前FIA UPDATE真正使用的是Host actual_seq_lengths_q，不应把这个旧辅助grid误当本代active输入offset。
- 当前输入及carrier.metadata.query_start_loc：active3/padded4时[0,4,8,12,12]，严格保留真实active边界和padding。
- FIA本代Host query长度：[4,8,12,16]，按padded固定query宽度传给真实FIA更新调用。

C56把三者分别存储、分别严格检查，未删除dtype/geometry检查，也未把输入cast成期望值。新schema v4；完整真实CPU小快照在已明确Graph完成的诊断点保存，包含input IDs/positions、Target Full positions、accepted prefix索引、slots、表、三个query角色及runtime/capture identity。若再失败可用同一次原件定位，而不靠字段猜测重复加载模型。

参考仍由独立canonical Full前态构造Window读视图，调用真实eager模型；与Graph共享权重和底层FIA，存在共同失效风险。诊断路径加入D2D、drain/D2H和reference/restoration，只支持串行诊断，不证明正常重叠时序。

## checker实际CLI问题

C55 before_first_replay真实Python异常触发quarantine和下一scope拒绝；原runner因专用checker直接脚本启动时tools/bisect遮蔽stdlib bisect而失败。同C55源码以模块入口只读复核原件得到PASS_SCOPED_EAGLE3_PYTHON_UNWIND，原失败不覆盖。C56与其他工具一致在导入torch前修正script sys.path，并增加真正subprocess --help反例；这不是更改异常验收条件。

## 定向检查与下一步

C56_query_and_real_checker_cli_host_final.log：55 passed，包含active3/padded4三query角色和损坏字段拒绝、真实checker CLI。C56尚待固定checkout/runtime和实际完整9样本；之后scheduler和剩余故障点。当前C52性能控制独立运行，避免本任务重I/O干扰。
