# Eagle3 first-pass 的有效前缀与 Full 写入（C52失败后修正）

更新2026-10-24T16:24:35.575945+08:00；C52 d92903e2e4546c5b4c3987e718eaaedb49b61ec1 原件不改。

## 实际反例

`raw/C52_prepare_01/EAGLE3_NUMERIC/eagle-numeric-contract-failure.json`：short-one/first-pass，L0=E=261；positions=[257,1,2,3]；metadata实际slots与未用ForwardContext slots均为[2945,2946,2947,2948]；旧诊断从Draft尾位置算出[2945,3457,3458,3459]。0个完整样本。不能据此写数值PASS。

## 精确来源

pinned `prepare_prefill_inputs` 对query_len减num_rejected，positions只复制接受前缀，last_token_indices标记其末尾；query_start_loc仍为完整Target query布局。FULL first-pass沿原完整Target写slot网格。`_prefill`仅选last_token_indices输出，随后AR更新有效位置。出处和原件hash见 `Eagle3_rejected_tail_source/INDEX.json`。

## 修复

C53 fe708f2ccff5c4d3b2311c5ac8d5c10327ec892a；C54 774eb1e3aec1535eb8a74a9ac069c214246560a6 仅恢复120列格式，AST不变。
默认关闭诊断新增Target positions及last_token_indices独立captured D2D快照；生产输入、slot写入、Window数学、流顺序、容差不改。
first-pass验证Target完整绝对网格+Draft有效前缀；rejected尾字节完整保留并作为独立eager输入，全部active query输出与KV后态仍精确比较。AR继续按实际Draft绝对positions核验。真实InputBatch/Target静态positions指针必须一致，避免新快照取错所有者。
另纠正checker把实际runtime_identity.method误写为normalized_method的夹具偏差，仍严格要求eagle3。

37项定向Host检查通过，包括C52 literal、合法未刷新尾、损坏有效前缀、错误Target网格、last index越界、缺字段、dtype、坏写slot、数值失败和未完成集合。C54格式AST等价；待新固定候选重新设备采样。

## 对此前根因判断的追加纠正

C50确认实际Ascend KV消费者是metadata.slot_mapping，而非通用ForwardContext字段，这是精确合同修正。但C48没有导出值，不能认定该字段选择是其唯一首因；C52在两字段相同情况下仍失败，已新增定位到rejected-tail假设错误。旧失败和旧判断保留，本文作为更具体的新证据。

## 隔离范围

原进程262198退出；显式POSTGRAPH drain和最终poststate snapshot已在失败前完成，随后仅Host检查，没有reference restore/H2D/forward。分类见C52_numeric_slot_failure_classification.json。原pending/隔离结果不改成PASS；新独立进程须新鲜准入，不恢复原失败backing。
