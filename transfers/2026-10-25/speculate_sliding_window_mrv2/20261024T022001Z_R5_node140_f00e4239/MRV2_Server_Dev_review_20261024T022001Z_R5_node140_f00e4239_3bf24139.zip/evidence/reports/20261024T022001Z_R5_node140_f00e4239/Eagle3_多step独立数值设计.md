# Eagle3 每消费者独立数值验证（待设备检验）

本轮假设：实际 Graph first-pass、AR1、AR2 均使用冻结 proposal horizon 的本代 Window，完整输入与该消费者 KV 前态相同时，独立 eager 前向的两份 hidden 输出和所选 Draft KV 后态应一致。

## 边界

- 冻结 Eagle3/Qwen3 单 Draft 层、K=3；三请求组 active=1/3/4，分别覆盖 padded=1/4/4；每组一代 proposal 的三个消费者，共9个样本。
- 不声称 ABA、全部边界矩阵、完整 Target 双臂、全部 KV allocation 写集合、正常重叠、原生 execution operand 或 physical-read。
- capture 内仅添加 D2D clone/index_select；预分配的物理 block 索引由进程外诊断在 replay 前已 drain 后设置。UPDATE 后显式 drain，再读取样本。新增拷贝会改变诊断 Graph 时序。
- 初始化只允许空闲、未 quarantine 的独立 fixture：证明 Draft/Target 地址区间不相交后，设备 drain、仅清零 Draft KV；不修改 Target。此初始化与串行参考均不能混入正常性能数据。

## 独立参考

从原 canonical Full table、原 L0、当前消费者实际 E 独立计算 S=floor(max(L0+K-W,0)/block)*block、读表和有效长度；绝对 positions 与 Full slot 从实际输入重新推导。参考重新持有输入和 metadata，恢复该消费者实际 KV 前态，直接调用 pinned AutoRegressiveSpeculator._run_model(mode=NONE) 的真实模型；不把 Graph 输出作为 oracle。

参考仍共享权重、底层 eager FIA 及非 read metadata，存在共同失效风险。内容相等允许 storage 去重；独立计算调用、输入指针和 KV 前态须分别留证。

## 失败与恢复

只有已明确完成的诊断 Graph/参考允许恢复已完成的 Draft 后态。任何设备提交阶段异常保持 pending，Host 导出后进程隔离；没有 finally 中无条件恢复、清零或同步取证。数值不一致先保存真实样本，禁止后续依赖提交。

## 判据

input_ids=int32、positions=int64；完整层及两份 K/V；本代 generation/epoch、三个不同消费者 bank；完整样本集合、finite、精确相等（不放宽容差）；Graph/参考输入和 KV 前态一致，输出及所选后态一致。只读 checker 另外重算 canonical Window；单份合法样本、损坏 dtype/epoch/slot/因果语义/别名/缺样本不得通过。外部 plan/launcher/campaign 关联仍由 R13 联合检查负责。
