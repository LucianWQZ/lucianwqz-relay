# PR最新固定pair与Graph集成准备（只读）

核验时点2026-10-24约09:43 UTC，原件PR_C23_fixed_pair_identity.json、PR_readonly_refresh_20261024T0944Z.json。

## 身份与执行顺序

PR开发/固定C23 Ascend 723a2cf1af91e335a1f19e920ec42fe920f28457，tree a7dbab4674aca4e83d48f685283ffbe45688fc65；pin a98247ab4db686ee03c66d5feb3c761e52a2f8ab，tree7f2a24a827bbbb2f211e02031f9d4d0d556d536c，两仓固定树干净。PR最新已验证主候选仍C21 ce721710a9bdab0aedf121dd1ad2e55c19345866；C23当前prompt exact新增功能的设备验证待完成，不是获批最终合入基线。其状态还列真实backend/架构/组合缺口。Graph保持84030bbe pin及Python3.11环境，PR使用不同pin/环境，不互相覆盖。

用户已明确先继续独立Graph，最终集成要求保留，未批准更换pin或具体pair。本轮未修改PR工作树/状态/租约，未创建假集成PASS。

## 接口对照

|合同|Graph独立路线|PR C23|预计适配与风险|
|---|---|---|---|
|精确长度/读视图|P3 DraftMetadataInputs，generation/epoch/lease及cpu/device exact，P6持久bank|DraftWindowLengthBounds区分exact/upper；DraftReadView持有read-only字段，exact_cpu_for按对象所有权认证|只从当前准备阶段的owned exact创建Graph输入；不能把任意CPU tensor或上代镜像认证为精确|
|Window数学|按方法冻结S，E随consumer推进，Full slot/绝对positions独立|DraftWindowPlan/full_exact_end/full_horizon_end/window_start，at_exact_end保留冻结S，DirectPrefixSource规范canonical source|按method/query/phase逐项对照；C23 continuing/no-placeholder exact修复不能用旧Graph测试掩盖|
|metadata|P6构建独立Draft metadata；Target隔离；持久capture地址|新对象DraftReadView.apply仅替换read字段；dense/DSA/MLA/SFA分适配器|不能直接复用旧selector/字段名；Graph UPDATE需要逐backend真实operand接线|
|生命周期|P3租约/epoch + 每consumer P6 capture bank，依赖正常Graph RI/update/event合同|DraftWindowOwnerPool按proposal强持有所有AR步骤，completion需覆盖所有reader/通信流|PR强引用不防别处覆盖，Graph持久地址不能按eager对象更换；须单独建立最后consumer及下一次写依赖|
|异常|quarantine_generation，未知提交后Host导出与进程隔离，下一scope拒绝|PREPARING/ACTIVE/SUBMITTED/QUARANTINED/RELEASED及pool.poisoned，begin_native在可能异步拷贝前|需要映射部分提交、早期metadata和AR异常；不能在未知native后尝试恢复|
|Graph/config|实验Gate默认关闭，公共Gate冻结；dense TP1实际FULL_DECODE_ONLY|非Graph独立产品policy/新backend与native gather，Graph相关baseline仍有限域|保留OFF/forced-OFF/unsupported语义；未实现不能直接改成永久不支持|

精确源码片段与hash见PR_C23_interface_excerpts/INDEX.json。

## 集成后的必需回归

1. 新pin下CLI→EngineArgs/platform/factory→模型的默认OFF、真实诊断配置、错误提示与Gate拒绝；worker Python/native provenance全部重核。
2. 各方法的query/offset/causal、int32 ids/int64 positions、active/padded及Full写slot，完整Draft层、连续数值/ABA及Target隔离按受影响路径重采。
3. first-pass/AR consumer bank、request/generation/epoch/lease、早期/metadata/UPDATE未知状态异常、下一scope拒绝；正常contract安装适用性仍单列。
4. continuing/terminal prefill、真实mixed/decode、请求替换与flag复位；PR新增prompt exact、融合reader和Graph metadata adapter必须联合验证。
5. 正式必需backend/TP16全rank及相关特性组合，不能用dense TP1或独立非Graph PASS拼接。
6. 相同机器/同候选/同工作量的G_OFF/G_ON/E_ON性能接受率；新pin/native gather可能改变等待与工作量，旧耗时只能作历史背景。

可引用：冻结数学、旧失败反例、测试设计、平台公开合同及历史证据身份。不可直接升级：旧pin的NPU数值/Target/调度/异常/性能结果。最终批准pair明确后再在独立集成候选执行，不等于当前已集成。
