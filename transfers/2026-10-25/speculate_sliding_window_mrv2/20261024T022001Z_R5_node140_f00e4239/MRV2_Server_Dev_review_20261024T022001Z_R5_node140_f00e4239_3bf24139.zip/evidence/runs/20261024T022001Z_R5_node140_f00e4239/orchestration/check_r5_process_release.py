from pathlib import Path
import json,datetime,subprocess,re,socket
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');S='20261024T022001Z_R5_node140_f00e4239';RAW=R/'runs'/S/'raw';O=R/'reports'/S;RET=R/'return'/S
owned={}
def add(pid,ticks):
 if pid and ticks is not None:owned[int(pid)]=str(ticks)
for line in (R/'journal'/S/'events.jsonl').read_text().splitlines():
 e=json.loads(line)
 for row in e.get('worker_processes',[]):add(row.get('pid'),row.get('start_ticks'))
 add(e.get('launcher_pid'),e.get('launcher_start_ticks'))
 if e.get('event')=='MODEL_PRODUCER_STARTED':
  m=re.search(r'start_ticks=(\d+)',e.get('message',''));add(e.get('model_producer_pid'),m.group(1) if m else None)
for p in [*RAW.glob('*segment*/supervisor_identity.json'),*RAW.glob('*resource_wait*/identity.json')]:
 j=json.loads(p.read_text());add(j.get('pid'),j.get('start_ticks'))
live=[];reused=[]
for pid,tick in owned.items():
 p=Path('/proc')/str(pid)
 try:
  fields=(p/'stat').read_text().rsplit(')',1)[1].split();actual=fields[19]
  if actual!=tick:reused.append(pid);continue
  argv=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');live.append(dict(pid=pid,start_ticks=tick,process_state=fields[0],argv=argv[:1200]))
 except FileNotFoundError:pass
coord=R.parent/'resource_coordination/node-25-140';leases=[]
for p in (coord/'leases').glob('*/owner.json'):
 j=json.loads(p.read_text())
 if S in json.dumps(j):leases.append(dict(path=str(p),owner=j))
try:
 q=subprocess.run(['npu-smi','info'],capture_output=True,text=True,timeout=12);rc=q.returncode;txt=q.stdout+'\nSTDERR\n'+q.stderr
except subprocess.TimeoutExpired:rc='TIMEOUT_12S';txt='UNKNOWN: bounded management query timed out'
(O/'FINAL_NPU_SMI.txt').write_text(txt)
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),hostname=socket.gethostname(),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),known_pid_starttime_pairs=len(owned),matching_live_processes=live,pid_reuse_ignored=reused,own_leases_remaining=leases,npu_smi_rc=rc,npu_smi_evidence=str(O/'FINAL_NPU_SMI.txt'),scope='ONLY_THIS_SESSION_PID_AND_STARTTIME_IDENTITIES; no signals sent, no reset, no other task leases modified',released=not live and not leases,device_completion_claim='NOT_INFERRED_FROM_PROCESS_EXIT')
for p in [O/'FINAL_PROCESS_AND_LEASE_CHECK.json',RET/'FINAL_PROCESS_AND_LEASE_CHECK.json']:p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
