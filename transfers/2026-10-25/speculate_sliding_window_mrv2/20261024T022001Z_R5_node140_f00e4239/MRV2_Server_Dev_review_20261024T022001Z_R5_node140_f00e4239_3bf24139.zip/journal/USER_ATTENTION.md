# 当前人工关注事项

更新2026-10-24T11:44:10.708008+00:00；node-25-140；SESSION=20261024T022001Z_R5_node140_f00e4239；deadline2026-10-24T12:20:01Z不变。

## 无需重复授权

用户已允许空闲16单元按需使用，本任务只领Phy14跑TP1。其他任务进入不主动退出；如被外部终止不自动重启争抢。当前同SHA有限性能链进行中，准确PID/设备观察见current_status.json。不需要用户再次批准普通修复或这些实验。

## 需要独立技术评审与后续决定

1. 正常UPDATE/backing：已有源码支持合同；请独立评审其A/B推导及安装适用前提。平台维护者/验收负责人待确认。实际execution operand与physical read无直接证据，替代方案未获批准。
2. 产品具体Graph组合：完整范围未缩减；FULL vs FULL_DECODE_ONLY、PIECEWISE、async/prefix/SP/FlashComm/DSA-CP具体必须组合需要沿原合同裁决，不能将未实现改成永久unsupported。
3. 性能阈值：16K特定负载已有测量，短/8K历史回退保留，暂无正式阈值。建议分别规定关键业务长度非劣化预算和预期长上下文收益，先看本轮逐次数据再确认；本Agent不自行宣布达标。
4. PR集成：最新只读固定C23/pin a982并非已批准最终pair；Graph继续独立pin84030。用户明确批准最终固定pair后才建立独立集成候选。

## 本轮新技术风险（不是要求用户本地修复）

C59 Eagle完整9数值第5样本：active输出精确、KV前态一致但K后态blocks1/2不一致。原FAIL保留，需区分真实额外写入与捕获快照取证问题。原进程已隔离，不能通过放宽checker或重试相同trace关闭。
最小下一实验应一次性保存两个AR consumer已完成快照及merged实际KV后态、实际cache格式/stride与storage身份，核对差分是否出现在实际KV，而非只快照；诊断结果不升级正常无同步证明。

所有原问题/回答/建议/实施/验收区别记录：/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/manual_review/adapt_人工后续核查.md。
