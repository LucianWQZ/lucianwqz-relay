# R5 Profiling分析

本轮新采集5次，producer均C52：8K G_ON baseline/single-metadata各1次；16K G_OFF/G_ON/E_ON各1次。原始trace/CSV/DB留raw，包内v2解析器、完整摘要、最小trace片段与hash索引。
初始化/capture不在采集窗口；ALL_DECLARED_GROUPS预热。重型observer、完整Target dump、连续reference、LIFE逐代同步、native verbose关闭；provider开启不等于重型observer安装。

8K各37次materialize：exact snapshot均值baseline8.2757ms、single8.1485ms；materialize9.5989/9.7017ms，未缩短。outer metadata扣除同线程嵌套materialize后0.823665→0.11346ms；两个continuing-prefill build另列，不能混入decode均值。
snapshot的CPU copy包含前序工作等待，不能把它全归小payload拷贝带宽。优化只减少未使用metadata重复构建，未去掉exact同步依赖。~26ms累计Host减少与~29.7ms端到端变化一致，仍不能单凭子范围宣称全部因果。

16K MODEL_EXECUTE硬件计数OFF211、ON171、Draft-eager ON85，分别与Host Draft/Target汇总108+103、86+85、0+85相符。它支持实际Graph dispatch计数一致性，不能据汇总把某task硬配generation/operand。
v2关联使用(cat,name,id)及实际endpoint；裸connectionId跨命名空间碰撞反例保留。direct model execution endpoint为0，generation-bound执行关联NOT_AVAILABLE；旧event/queue direct_matched不能简称执行关联通过。

16K ON有8095个MEMCPY_ASYNC硬件任务，但CSV/DB没有方向/字节字段；ENUM表存在不等于有实际MEMCPY_INFO。H2D/D2H/D2D数量与字节NOT_AVAILABLE。HostToDevice flow类别不是H2D memcpy数量。
并行stream duration不相加当elapsed；同设备时域union可算忙碌区间，未校准Host/Device时钟不相减。所有主要结论对应包内v2 summary字段、per-case摘要及excerpt，不能由相邻行/同shape推断代际。
