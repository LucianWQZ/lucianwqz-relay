# Git bundle恢复

前置基线：C35 f00e423936c23b0710fc2b5cd367d34ec7736d26；本包增量终点C59。
不能单独clone此增量包后假称拥有全部历史。先从已交付C35仓库取得基线，执行git bundle verify，再fetch本包HEAD到独立分支。
bundle_verification/COMMANDS.json与RESTORE_VERIFICATION.json记录了真实临时bare仓恢复、完整SHA与tree一致性。
vLLM pin、native overlay、CANN、Python和模型不在bundle内，需分别按runtime manifest恢复。
