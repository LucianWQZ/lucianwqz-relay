# Graph最终交付范围与验收矩阵

类别1=必须且有对应限定证据；2=必须但仍有实现/验证缺口；3=原定forced-OFF/unsupported；4=具体产品组合合同待确认。未实现不改成unsupported。

|范围|类别|当前真实状态|下一步|
|---|---|---|---|
|DSpark static K7, sample_from_anchor=true, dense GQA/FIA TP1, FULL_DECODE_ONLY Target4|2|140 C33完整12数值/ABA、Target4双臂12对、LIFE21串行诊断；C34 metadata异常两点；C35真实CONFIG/B0及18组30请求稳定性；正常三臂性能及自然请求已测但Window回退。各producer身份保留，产品接入/平台/整体组合尚未齐。|复用原件与源码影响分析；C33完整join已补核，不重跑旧队列；按新增production影响重验。|
|DFlash static K+1 dense FIA Graph|2|C45同SHA已完整14数值/ABA、Target OFF14及显式Target14对联合通过、LIFE160串行诊断、四ABORT及四真实Python展开通过；C38/C39保留历史身份。|证据可供方法阶段审查；C46默认关闭metadata优化单独受影响范围验证，最终产品/拓扑/正常合同不由DFlash阶段PASS代替。|
|eligible DSpark sample_from_anchor=false / query K+1|2|C49独立sample_from_anchor=false K7/Q8/T8配置已完成真实P0/CONFIG、三样本及14数值/ABA、Target OFF14与显式14对联合通过。原Q7合同独立保留。|后续Q8 LIFE/异常/自然请求与正式产品入口按范围完成；旧数据不归给最终SHA。|
|static Eagle3 autoregressive Graph|2|C59三臂真实请求和chunked256的continuing/terminal/decode/mixed调度检查通过，四个真实Python异常点通过。完整9数值失败：4样本精确PASS，第5long-three AR1输出精确但K后态物理块1/2差异；根因生产/捕获快照待区分，不能将部分5样本算完整PASS。|只读分析落盘KV差异后，设计能区分快照取证与实际额外KV写的最小前哨；完整Target/ABA/多代与正式接入仍需推进。|
|TP16 replicated / GLM必要backend路径|2|C57实现replicated TP2/4/16 world/rank/read-semantics的Host生产身份与P2/P6绑定 guard，107检查通过；实际产品startup仍TP1，全rank backend/committed runner尚未完成。|完善真正多rank准入和GLM typed方法/backend入口后再申请完整16片设备窗口；不能把Host基础或非Graph PR结果写成GraphTP16通过。|
|FULL Graph模式 vs FULL_DECODE_ONLY|4|实验base代码允许FULL/FULL_DECODE_ONLY，但真实验证集中后者；公共Gate均冻结|需owner确认最终两种模式是否均为发布必需，保持两者既有拒绝直到审查|
|PIECEWISE Graph|4|当前实验base拒绝PIECEWISE；历史仅明确冻结，未证明最终产品永久不支持|需owner明确模式范围；不自行改成永久unsupported|
|async × Graph (DFlash/DSpark；Eagle3/DSA差异)|4|非Graph明确必需；Graph另有lane/event/completion设计，当前base准入拒绝async；缺实现不称产品不支持|列出Graph lane bank与最后consumer合同差异，请owner确认必需组合；继续独立sync主线|
|prefix × Graph|4|非Graph明确必需；Graph resident epoch/evict hold设计待接入；base拒绝prefix|需确认Graph prefix交付组合；不能复用eager前态当Graph PASS|
|chunked pure prefill→decode / mixed prefill-decode / general multi-request|2|C59三臂实际scheduler记录命中mixed、prefill_continuing、prefill_terminal、pure_decode、pure_prefill_continuing、pure_prefill_terminal。该检查为CPU proposal/manager关联，不证明device completion、Target KV或正常无附加观测复用。|复用实际阶段记录，继续异常flag复位、有限稳定性及最终产品入口合成覆盖；不把长短请求自行等同所有调度支持。|
|SP/FlashComm × Graph|4|原有非Graph拓扑应保留；Graph fingerprint有字段但base明确拒绝，需具体组合边界|核对MRV1/PR真实支持与owner确定Graph需验证组合，不扩成全Cartesian|
|DSA / DSA-CP / required GLM backend Graph|4|非Graph uncompressed DSA-CP必需；Graph derived bank/CP carrier未就绪，不能由dense FIA替代|明确实际模型/backend组后完成derived-state adapter；Graph组合范围请owner确认|
|compressed DSA/QLI, SFA/indexer, MLA, heterogeneous multi-group|4|历史为runtime-dependent/source-blocked，有Graph专属设计；不是已支持或永久不支持|先从真实必须模型/backend库存确定必要子集，不能仅凭模型名推断|
|MTP / DeepSeek-V4 co-trained DSpark Window ON|3|warning-once FORCED_OFF，数字校验/Window分配之前生效；OFF不回退|按变更影响保留forced-OFF合同，不人为启用Graph Window|
|plain Eagle / dynamic-K Eagle3与DFlash2明确区分|4|Frozen X02与R07明确DFlash2 Graph当前unsupported，保留NotImplemented；plain Eagle ON与dynamic-K Eagle3为Owner Decision Required，不能由现有DSpark/Eagle3 static证据扩展。|DFlash2 Graph保留既有拒绝与eager/OFF回归；另两项具体范围等负责人确认，不混为已支持。|
|DSpark TP1 Window OFF限定锚点|1|140 C29/C30/C32/C33 A0实际通过；C32修复为Window ON continuing-prefill专用，默认OFF保留|仅引用对应模型/TP/profile范围，不升级为非Graph全矩阵|
|非Graph既有范围及最终PR组合兼容|2|最新只读PR固定C21 ce721710a9bdab0aedf121dd1ad2e55c19345866，pin a98247ab4db686ee03c66d5feb3c761e52a2f8ab；其交接仍有待完成正确性，最终集成pair未批准。Graph独立pin不变。|等明确最终源码对后独立集成，按方法/拓扑/特性影响重验；两边PASS不拼成整体PASS|
