# R5 待裁决事项

更新2026-10-24T11:44:10.708008+00:00；SESSION=20261024T022001Z_R5_node140_f00e4239；原R4/R3记录留在各自return，人工原始回答追加保存在manual_review/adapt_人工后续核查.md。

|谁决定|具体问题/证据|建议|阻塞|仍可继续|
|---|---|---|---|---|
|平台维护者，负责人待确认|capture notify→RI/current FIFO、单update流/Event协议在实际910B/CANN9.1/runtime_v100安装上的适用前提；R3源码合同与实际worker库hash已附|审查现有A/B推导，逐条确认或给反例；不无限反编译每个二进制分支|正常合同正式验收|独立数值、异常、性能、方法实现|
|验收/产品负责人待确认|执行occurrence operand与physical read原要求来源/证明方式；当前只有post-drain参数、数值语义和task/event统计|网页GPT先独立技术审查，给可替代取证方案；用户未批准豁免|直接设备取证条目/发布判定|保持NOT_PROVEN并继续其他验证|
|产品负责人/用户|FULL/PIECEWISE、async/prefix/SP/FlashComm/DSA-CP具体Graph必需组合；scope矩阵引用Frozen/blueprint|沿原合同确定必要子集，不扩全笛卡尔积、不缩最终目标|对应组合产品范围|已明确的DSpark/DFlash/Eagle/TP16基础|
|用户确认最终PR pair|只读C23Ascend723a2cf1af91e335a1f19e920ec42fe920f28457/pina982；C23新prompt-exact设备未齐，不是最终批准|等对方明确待合入固定版本后一次确认独立集成|整体集成/非Graph回归|Graph独立候选、接口冲突准备|
|业务/性能owner待确认|短/8K历史ON回退；16K本轮获测量，single-metadata小收益默认关闭|按代表负载设非劣化与收益阈值，区分接受率变化及kernel收益|性能达标结论|保留逐次数据、优化与有限复测|

C59 K后态差异是当前工程定位项，由本任务继续，不转嫁为用户修小bug；尚无足够证据决定production修复，不以改预期获得PASS。
public Graph Gate冻结，未自动push/merge。
