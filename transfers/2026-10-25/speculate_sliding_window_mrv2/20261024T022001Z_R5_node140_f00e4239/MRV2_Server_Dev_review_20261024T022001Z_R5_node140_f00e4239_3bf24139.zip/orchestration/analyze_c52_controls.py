import csv,datetime,hashlib,json,statistics
from pathlib import Path
R=Path("/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt")
SID="20261024T022001Z_R5_node140_f00e4239"
BASE=R/"runs"/SID/"raw/C52_prepare_01"
O=R/"reports"/SID
rows=[];artifacts=[]
for p in sorted(BASE.glob("PERF*/performance-joint.json")):
 d=json.loads(p.read_text());case=p.parent.name
 if not (case.startswith("PERF10_G_ON_") or case.startswith("PERF14_SINGLE_") or case.startswith("PERF18_")):continue
 artifacts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),status=d.get("status")))
 if d.get("status")!="PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE":continue
 campaign=json.loads((p.parent/"campaign.json").read_text())
 for c in d["cells"]:
  accepted=sum(x["accepted_draft_tokens"] for x in c["acceptance"]);proposed=sum(x["proposed_draft_tokens"] for x in c["acceptance"])
  rows.append(dict(case=case,variant="single_metadata" if case.startswith("PERF14") else "baseline",arm=d["arm"],workload=c["label"],rep=int(case.rsplit("_",1)[1]),source_sha=campaign["identity"]["source_sha"],requests=c["requests"],input_tokens=c["input_tokens"],output_tokens=c["output_tokens"],elapsed_seconds=c["elapsed_seconds"],output_tokens_per_second=c["output_tokens_per_second"],accepted_draft_tokens=accepted,proposed_draft_tokens=proposed,acceptance_rate=accepted/proposed if proposed else None,draft_replays=d["draft_replays"],target_replays=d["target_replays"],actual_graph_window_crop=d.get("actual_graph_window_crop"),actual_eager_window_crop=d.get("actual_eager_window_crop"),TTFT="NOT_AVAILABLE",TPOT="NOT_AVAILABLE",ITL="NOT_AVAILABLE",evidence=str(p)))
with (O/"C52_performance_cells.csv").open("w") as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ["case"]);w.writeheader();w.writerows(rows)
groups={}
for x in rows:groups.setdefault((x["workload"],x["variant"],x["arm"]),[]).append(x)
summary=[]
for (workload,variant,arm),v in sorted(groups.items()):
 summary.append(dict(workload=workload,variant=variant,arm=arm,n=len(v),repetitions=[x["rep"] for x in v],elapsed_ms=[1000*x["elapsed_seconds"] for x in v],median_ms=statistics.median(x["elapsed_seconds"]*1000 for x in v),min_ms=min(x["elapsed_seconds"]*1000 for x in v),max_ms=max(x["elapsed_seconds"]*1000 for x in v),accepted=[x["accepted_draft_tokens"] for x in v],proposed=[x["proposed_draft_tokens"] for x in v],requests=[x["requests"] for x in v],output_tokens=[x["output_tokens"] for x in v]))
comparisons=[]
for workload in sorted({x["workload"] for x in summary}):
 g={(x["variant"],x["arm"]):x for x in summary if x["workload"]==workload}
 for a,b,label in [(('baseline','G_ON'),('single_metadata','G_ON'),'single_metadata_vs_baseline_ON'),(('baseline','G_OFF'),('baseline','G_ON'),'Window_ON_vs_OFF'),(('baseline','E_ON'),('baseline','G_ON'),'Graph_vs_Draft_eager_same_Window')]:
  if a in g and b in g:comparisons.append(dict(workload=workload,comparison=label,base_n=g[a]["n"],test_n=g[b]["n"],base_ms=g[a]["median_ms"],test_ms=g[b]["median_ms"],elapsed_change_percent=100*(g[b]["median_ms"]/g[a]["median_ms"]-1),complete_three_reps=g[a]["n"]==g[b]["n"]==3))
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status="MEASURED_PARTIAL_OR_COMPLETE_SEE_SAMPLE_COUNTS",cells=rows,group_summary=summary,comparisons=comparisons,artifacts=artifacts,limits=["Three finite repeats are diagnostic evidence, not broad model or length generalization","No formal performance threshold or exclusive whole-host guarantee","Draft/Target replay counts are per case (all active groups), not repeated per request","TTFT/TPOT/ITL not inferable from whole-request elapsed","Initialization/capture and full-group warmup excluded from active request elapsed","Profiler runs excluded from unprofiled controls"] )
(O/"C52_performance_summary.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(dict(cells=len(rows),comparisons=comparisons),ensure_ascii=False))
