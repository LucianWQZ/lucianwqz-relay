import collections,csv,datetime,hashlib,json,statistics
from pathlib import Path
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID='20261024T022001Z_R5_node140_f00e4239'
BASE=R/'runs'/SID/'raw/C52_prepare_01'
O=R/'reports'/SID/'profiling_analysis';O.mkdir(exist_ok=True)
CASES=['PROFILE10_G_ON_long','PROFILE14_SINGLE_long','PROFILE18_G_OFF_long16','PROFILE18_G_ON_long16','PROFILE18_E_ON_long16']
def union(v):
 total=0.;end=None
 for a,b in sorted(v):
  if b<a:raise ValueError('negative interval')
  if end is None or a>end:total+=b-a;end=b
  elif b>end:total+=b-end;end=b
 return total

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
summary=[]
for case in CASES:
 root=BASE/case;profile=json.loads((root/'profile.json').read_text());campaign=json.loads((root/'campaign.json').read_text());joint=json.loads((root/'performance-joint.json').read_text())
 assert joint['status']=='PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE'
 trace=root/next(p for p in profile['raw_exports'] if p.endswith('trace_view.json'))
 data=json.loads(trace.read_bytes());events=data if isinstance(data,list) else data['traceEvents']
 hw={x['pid'] for x in events if x.get('ph')=='M' and x.get('name')=='process_name' and x.get('args',{}).get('name')=='Ascend Hardware'}
 hardware=[x for x in events if x.get('ph')=='X' and x.get('pid') in hw]
 hwstart=collections.defaultdict(list)
 for x in hardware:hwstart[(x.get('pid'),x.get('tid'),str(x.get('ts')))].append(x)
 models=[x for x in hardware if x.get('name')=='MODEL_EXECUTE']
 starts=collections.defaultdict(list);ends=collections.defaultdict(list)
 for x in events:
  if x.get('ph') not in ['s','f']:continue
  key=(x.get('cat'),x.get('name'),str(x.get('id')))
  (starts if x['ph']=='s' else ends)[key].append(x)
 matched=0;host_queue=0;device_pairs=0;model_pairs=0;examples=[]
 for key,sv in starts.items():
  ev=ends.get(key,[])
  if len(sv)!=1 or not ev:continue
  matched+=1
  if key[0]=='async_task_queue':host_queue+=1
  endpoint_tasks=[]
  for endpoint in ev:endpoint_tasks.extend(hwstart.get((endpoint.get('pid'),endpoint.get('tid'),str(endpoint.get('ts'))),[]))
  if endpoint_tasks:device_pairs+=1
  if any(x.get('name')=='MODEL_EXECUTE' for x in endpoint_tasks):model_pairs+=1
  if endpoint_tasks and len(examples)<3:examples.append(dict(flow_namespace=list(key),start=sv[0],finishes=ev,device_tasks=endpoint_tasks))
 taskfile=root/next(p for p in profile['raw_exports'] if p.endswith('task_time.csv'))
 with taskfile.open() as f:tasks=list(csv.DictReader(f))
 streams=collections.defaultdict(list);types=collections.Counter();kinds=collections.Counter();names=collections.Counter();copies=collections.Counter();waits=collections.Counter();intervals=[]
 for x in tasks:
  a=float(x['task_start(us)']);b=float(x['task_stop(us)']);intervals.append((a,b));streams[x['stream_id']].append((a,b));types[x['kernel_type']]+=1;names[x['kernel_name']]+=1
 for x in hardware:
  tasktype=x.get('args',{}).get('Task Type','NOT_AVAILABLE');kinds[tasktype]+=1
  n=x.get('name','');upper=n.upper()
  if 'MEMCPY' in upper:
   direction=next((t for t in ['H2D','D2H','D2D','HTOD','DTOH','DTOD'] if t in upper),'UNKNOWN_DIRECTION');copies[direction]+=1
  if any(t in upper for t in ['WAIT','SYNCHRON']):waits[n]+=1
 stream_summary={k:dict(tasks=len(v),active_union_us=union(v),envelope_us=max(b for a,b in v)-min(a for a,b in v)) for k,v in streams.items()}
 envelope=max(b for a,b in intervals)-min(a for a,b in intervals) if intervals else None
 active=union(intervals)
 calls=[x for x in profile['calls'] if x.get('active')];label_counts=collections.Counter(x['label'] for x in calls)
 range_summary={}
 for label in ['Draft_materialize','Draft_materialize_exact_length_snapshot','Draft_build_attn_metadata','Draft_metadata_bind','Draft_UPDATE_CALL','Draft_retire_host']:
  rows=[x for x in calls if x['label']==label and 'start_ns' in x and 'end_ns' in x]
  if rows:
   durations=[(x['end_ns']-x['start_ns'])/1e6 for x in rows];range_summary[label]=dict(n=len(rows),mean_ms=statistics.mean(durations),median_ms=statistics.median(durations),union_ms=union([(x['start_ns']/1e6,x['end_ns']/1e6) for x in rows]))
  else:range_summary[label]='NOT_AVAILABLE_OR_NOT_EXECUTED_SEE_ARM'
 selected_files=[trace,taskfile,root/'profile.json',root/'performance-joint.json']
 index=[dict(path=str(p),relative_to_case=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=digest(p)) for p in selected_files]
 # Save a concrete counterexample against joining numeric IDs across namespaces.
 collision=None
 for m in models:
  conn=m.get('args',{}).get('connection_id')
  wrong=[v for key,values in starts.items() if key[0]=='async_task_queue' and key[2]==str(conn) for v in values]
  if wrong:collision=dict(model_execute=m,unrelated_queue_flow_with_same_numeric_id=wrong[0],warning='connection_id and async_task_queue flow id have different namespaces; numeric equality is not association');break
 sample=dict(schema='EXCERPT_NOT_COMPLETE_TRACE_DO_NOT_FEED_AS_FULL_ARTIFACT',source_trace=str(trace),source_sha256=index[0]['sha256'],hardware_metadata=[x for x in events if x.get('ph')=='M' and x.get('pid') in hw][:12],model_execute_examples=models[:4],explicit_device_flow_examples=examples,numeric_id_collision_counterexample=collision)
 (O/(case+'_trace_excerpt.json')).write_text(json.dumps(sample,ensure_ascii=False,indent=2)+'\n')
 result=dict(case=case,producer_sha=campaign['identity']['source_sha'],checker_sha='d92903e2e4546c5b4c3987e718eaaedb49b61ec1',device_ids=sorted({x['Device_id'] for x in tasks}),profile=profile['profile_configuration'],initialization_capture=profile['initialization_capture'],warmup=profile['warmup'],observer_installation=campaign['observer_installation'],request_cells=joint['cells'],host_draft_replays=joint['draft_replays'],host_target_replays=joint['target_replays'],hardware_model_execute_tasks=len(models),hardware_tasks=len(hardware),task_csv_rows=len(tasks),hardware_types=dict(kinds),task_types=dict(types),top_task_names=names.most_common(20),flow=dict(any_complete_namespaced_flow=matched,host_queue_flow=host_queue,explicit_device_endpoint_flow=device_pairs,explicit_model_execute_endpoint_flow=model_pairs,generation_bound_model_execution_flow='NOT_AVAILABLE',occurrence_operand='NOT_AVAILABLE',physical_read='NOT_PROVEN'),copies=dict(copies),copy_bytes='NOT_AVAILABLE',device_wait_events=dict(waits),device_task_activity=dict(envelope_us=envelope,all_stream_union_us=active,idle_within_task_envelope_us=envelope-active if envelope is not None else None,summed_task_activity_us_not_elapsed=sum(b-a for a,b in intervals),overlap_union_across_streams_us=sum(x['active_union_us'] for x in stream_summary.values())-active,streams=stream_summary),host_ranges=range_summary,files=index,scope=['Namespaced exact flow endpoints only; no cross-namespace numeric ID joins','Host marker counts distinguish Draft/Target; hardware tasks without explicit role/generation stay unassigned','Task timestamps only compared within exported device domain; never subtract raw Host monotonic ns','Duration sum is activity, not elapsed; device activity envelope is not request elapsed','Profiler overhead and extra Host markers included; no numeric reference/LIFE per-generation drain/native verbose'],boundaries=dict(normal_update_generation='SOURCE_CONTRACT_REVIEW_SEPARATE',normal_backing_reuse='SOURCE_CONTRACT_REVIEW_SEPARATE',task_internal_operand='NOT_PROVEN',physical_read_set='NOT_PROVEN'))
 (O/(case+'_summary.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');summary.append(result)
 print(json.dumps(dict(case=case,tasks=len(tasks),models=len(models),flow=result['flow']),ensure_ascii=False),flush=True)
 del data,events,hardware,tasks
(O/'MRV2_Profiling_Summary.json').write_text(json.dumps(dict(updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),session=SID,new_collections=len(summary),profiles=summary,not_release_approval=True),ensure_ascii=False,indent=2)+'\n')
