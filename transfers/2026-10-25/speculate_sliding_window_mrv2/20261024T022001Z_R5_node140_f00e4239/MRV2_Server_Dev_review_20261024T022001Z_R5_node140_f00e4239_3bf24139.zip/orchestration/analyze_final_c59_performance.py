from pathlib import Path
import json,csv,statistics,datetime,hashlib
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');S='20261024T022001Z_R5_node140_f00e4239';O=R/'reports'/S;B=R/'runs'/S/'raw/C59_prepare_01';rows=[];artifacts=[]
for p in sorted(B.glob('PERF18_*/performance-joint.json')):
 j=json.loads(p.read_text());artifacts.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,status=j.get('status')))
 if j.get('status')!='PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE':continue
 c=json.loads((p.parent/'campaign.json').read_text())
 for x in j['cells']:
  accepted=sum(z['accepted_draft_tokens'] for z in x['acceptance']);proposed=sum(z['proposed_draft_tokens'] for z in x['acceptance']);steps=sum(z['verification_request_steps'] for z in x['acceptance'])
  rows.append(dict(case=p.parent.name,arm=j['arm'],rep=int(p.parent.name.rsplit('_',1)[1]),source_sha=c['identity']['source_sha'],workload=x['label'],requests=x['requests'],input_tokens=x['input_tokens'],output_tokens=x['output_tokens'],elapsed_seconds=x['elapsed_seconds'],output_tokens_per_second=x['output_tokens_per_second'],accepted_draft_tokens=accepted,proposed_draft_tokens=proposed,verification_request_steps=steps,acceptance_rate=accepted/proposed if proposed else None,mean_accept_length_including_bonus=1+accepted/steps if steps else None,draft_replays=j['draft_replays'],target_replays=j['target_replays'],actual_graph_window_crop=j.get('actual_graph_window_crop'),actual_eager_window_crop=j.get('actual_eager_window_crop'),TTFT='NOT_AVAILABLE',TPOT='NOT_AVAILABLE',ITL='NOT_AVAILABLE',evidence=str(p),acceptance_per_request=x['acceptance']))
groups=[]
for arm in ['G_OFF','G_ON','E_ON']:
 cells=[x for x in rows if x['arm']==arm]
 if cells:groups.append(dict(arm=arm,n=len(cells),elapsed_ms=[1000*x['elapsed_seconds'] for x in cells],median_ms=statistics.median(1000*x['elapsed_seconds'] for x in cells),min_ms=min(1000*x['elapsed_seconds'] for x in cells),max_ms=max(1000*x['elapsed_seconds'] for x in cells),workload_counts=[dict(accepted=x['accepted_draft_tokens'],proposed=x['proposed_draft_tokens'],verification=x['verification_request_steps'],output_tokens=x['output_tokens']) for x in cells]))
comparisons=[];by={x['arm']:x for x in groups}
for a,b,label in [('G_OFF','G_ON','Window_ON_vs_OFF'),('E_ON','G_ON','Graph_vs_Draft_eager_same_Window')]:
 if a in by and b in by:comparisons.append(dict(comparison=label,base_n=by[a]['n'],test_n=by[b]['n'],base_ms=by[a]['median_ms'],test_ms=by[b]['median_ms'],elapsed_change_percent=100*(by[b]['median_ms']/by[a]['median_ms']-1),complete_three_repetitions=by[a]['n']==by[b]['n']==3))
summary=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),producer_sha='3bf24139a506dc4fb8417a5a26c15ca33ac0aa9c',cells=rows,groups=groups,comparisons=comparisons,artifacts=artifacts,scope='SAME_MACHINE_C59_NATIVE_16K_512TOKENS_NONEXCLUSIVE_BACKGROUND_RECORDED',limits=['Target remains Graph in all arms; E_ON makes Draft eager only','Counts exclude proposal padding and bonus from accepted draft; accepted plus verification may exceed emitted tokens after final clipping','No formal performance threshold approved','No whole-host exclusivity guarantee','Three finite repeats, not broad lengths/models','No per-cell CPU/RAM/HBM peak monitor; management samples in admission and heartbeat retained','Profiler not enabled in these controls'])
(O/'C59_performance_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
if rows:
 with (O/'C59_performance_cells.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=[k for k in rows[0] if k!='acceptance_per_request']);w.writeheader();w.writerows({k:v for k,v in x.items() if k!='acceptance_per_request'} for x in rows)
print(json.dumps(dict(cells=len(rows),groups=groups,comparisons=comparisons),ensure_ascii=False))
