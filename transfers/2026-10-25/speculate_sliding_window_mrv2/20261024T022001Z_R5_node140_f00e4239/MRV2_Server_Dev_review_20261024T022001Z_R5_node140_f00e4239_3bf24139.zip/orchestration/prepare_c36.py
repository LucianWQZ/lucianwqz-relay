import json,subprocess,datetime as dt,sys,hashlib
from common_c36 import *
o=R/'reports'/SID
a=[PYTHON,'-m','tools.p7x_graph_local_candidate','prepare','--repo',str(SOURCE),'--vllm',str(VLLM),'--inputs',str(R/'inputs'/SID),'--output',str(PLAN.parent),'--host-evidence',str(R/'state/R5_C36_HOST_EVIDENCE.json'),'--run-id','r5-c36-node140-phy8-'+SID,'--reuse-fixture-plan',str(R/'runs'/'20261023T121157Z_R4_node140_c8776394'/'raw/C35_prepare_01/case-plan.json'),'--authorized-host-phy-ids',*[str(x) for x in range(8,16)]]
x={'start':dt.datetime.now(dt.timezone.utc).isoformat(),'argv':a,'source_sha':SHA,'source_tree':TREE,'device_initialization':False}
with (o/'C36_prepare.stdout.log').open('x') as out,(o/'C36_prepare.stderr.log').open('x') as err:q=subprocess.run(a,cwd=SOURCE,env=environment(),stdout=out,stderr=err,timeout=240)
x.update(end=dt.datetime.now(dt.timezone.utc).isoformat(),rc=q.returncode,plan=str(PLAN));(o/'C36_prepare_execution.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps(x,ensure_ascii=False));raise SystemExit(q.returncode)
