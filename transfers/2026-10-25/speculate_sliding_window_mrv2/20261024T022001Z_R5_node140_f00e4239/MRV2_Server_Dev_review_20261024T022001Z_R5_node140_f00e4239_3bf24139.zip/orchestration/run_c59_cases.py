"""Bounded external R5 supervision; committed producer/checkers remain authoritative."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import uuid
from common_c59 import *

START_HASH=digest(Path(__file__))
COORD=R.parent/'resource_coordination'/socket.gethostname()
CASE_ROOT=RUN/'C59_campaign_01'
ENV=environment()
CURRENT_CASE=None
TOKEN=uuid.uuid4().hex
SEGMENT=RUN/('C59_segment_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
OWNER=None
LEASE=None
OWNED={}
LAST_DEVICE=None
PROVENANCE_DONE=False


def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def write(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.partial-r4');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');os.replace(tmp,p)
def ticks(pid):
 try:return Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()[19]
 except (OSError,ValueError):return None

def event(kind,message,**extra):
 at=dt.datetime.now(dt.timezone.utc);state=json.loads((R/'state/R5_SESSION_STATE.json').read_text())
 update=dict(fixed_candidate=str(SOURCE),runtime_manifest=str(R/'runtime/node140/C59_3bf24139/runtime_manifest.json'),status=extra.get('stage','DEVICE_RUNNING'),phase=kind,current_action=message,current_case=CURRENT_CASE,running_candidate=SHA,active_pids=[os.getpid()],npu_currently_used=None,last_monitor_check=at.isoformat(),last_device_observation=LAST_DEVICE)
 update.update({k:v for k,v in extra.items() if k!='stage'})
 if kind in ('SEGMENT_START','CASE_START'):
  update.update(worker_processes=[],npu_observed_own_pids=[],model_producer_pid=None,last_model_progress=None,last_model_log_mtime=None)
 if kind=='SEGMENT_START':
  update.update(historical_failure_first_cause=state.get('failure_first_cause'),failure_first_cause=None)
 update['active_leases']=[str(LEASE)] if OWNER and OWNER.get('status')=='HELD' else []
 if kind in ('SEGMENT_START','PROBE_END','SEGMENT_END'):update['npu_currently_used']=False
 if kind=='PROBE_END':update['npu_probes']=state.get('npu_probes',0)+1
 if kind=='MODEL_PRODUCER_STARTED':update['formal_model_starts']=state.get('formal_model_starts',0)+1
 live_path=R/'state/R5_DEVELOPMENT_LIVE.json'
 if live_path.exists():
  live=json.loads(live_path.read_text());update.update({k:live[k] for k in ('development_head','development_tree','development_dirty') if k in live});update['last_agent_update']=live.get('at',state.get('last_agent_update'));update['development_live_status']=str(live_path);update['agent_action']=live.get('agent_action','未提供新的Host动作')
 state.update(update)
 for p in [R/'state/R5_SESSION_STATE.json',R/'state/SESSION_STATE.json',R/'journal/current_status.json']:write(p,state)
 if kind=='HEARTBEAT':message += '；Agent当前工作='+state.get('agent_action','UNKNOWN')
 row=dict(utc=at.isoformat(),beijing=at.astimezone(dt.timezone(dt.timedelta(hours=8))).isoformat(),node=socket.gethostname(),session=SID,event=kind,case=CURRENT_CASE,candidate=SHA,message=message,**extra)
 with (R/'journal/progress.log').open('a') as f:f.write(f"{row['beijing']} node={row['node']} SESSION={SID} stage={state['status']}：{kind} {message}\n");f.flush()
 with (R/'journal'/SID/'events.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')


def query(path):
 global LAST_DEVICE
 try:
  q=subprocess.run(['npu-smi','info'],capture_output=True,text=True,timeout=12);text=q.stdout+'\nSTDERR\n'+q.stderr;rc=q.returncode
 except subprocess.TimeoutExpired:rc='TIMEOUT_12S';text='bounded management query timeout'
 Path(path).write_text(text);LAST_DEVICE={'at':now(),'rc':rc,'path':str(path)};return rc,text


def owned_processes(root):
 rows={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   s=(p/'stat').read_text().rsplit(')',1)[1].split();rows[int(p.name)]=(int(s[1]),s[19])
  except (OSError,ValueError):pass
 found={root};changed=True
 while changed:
  old=len(found);found.update(pid for pid,(ppid,_) in rows.items() if ppid in found);changed=len(found)>old
 out=[]
 for pid in found:
  if pid not in rows:continue
  try:
   argv=[z.decode(errors='replace') for z in Path('/proc',str(pid),'cmdline').read_bytes().split(b'\0') if z];args=' '.join(argv)
   OWNED[pid]=rows[pid][1];out.append({'pid':pid,'start_ticks':rows[pid][1],'argv':args[:1200],'argv_list':argv})
  except OSError:pass
 return out


def sample_worker(procs,out):
 global PROVENANCE_DONE
 if PROVENANCE_DONE:return
 for row in procs:
  p=Path('/proc',str(row['pid']))
  try:
   maps=(p/'maps').read_text();paths=sorted(set(z.split()[-1] for z in maps.splitlines() if '/' in z))
   if not any(str(SOURCE) in z and z.endswith('.so') for z in paths):continue
   keep=[z for z in paths if any(k in z for k in ['vllm_ascend_C','libvllm_ascend','libtorch_npu','libruntime_v100','libacl_rt','libascendcl'])]
   env=[v.decode(errors='replace') for v in (p/'environ').read_bytes().split(b'\0') if v.startswith((b'PYTHONPATH=',b'ASCEND_RT_VISIBLE_DEVICES=',b'VLLM_VERSION=',b'VLLM_ENABLE_V1_MULTIPROCESSING='))]
   write(out,dict(at=now(),pid=row['pid'],start_ticks=row['start_ticks'],argv=row['argv'],exe=os.readlink(p/'exe'),cwd=os.readlink(p/'cwd'),namespace=os.readlink(p/'ns/mnt'),environment=env,loaded_libraries=[dict(path=z,bytes=Path(z).stat().st_size,sha256=digest(z)) for z in keep],scope='Actual NPU worker process mapping/env/native sources; campaign imports and observed PID correlated separately'))
   PROVENANCE_DONE=True;return
  except OSError:pass


def stop_owned(reason):
 snapshot=[{'pid':pid,'start_ticks':t} for pid,t in OWNED.items() if ticks(pid)==t and pid!=os.getpid()];write(SEGMENT/('owned_stop_'+str(time.time_ns())+'.json'),dict(reason=reason,processes=snapshot))
 for sig in [signal.SIGTERM,signal.SIGKILL]:
  for row in reversed(snapshot):
   if ticks(row['pid'])==row['start_ticks']:
    try:os.kill(row['pid'],sig)
    except ProcessLookupError:pass
  if sig==signal.SIGTERM:time.sleep(2)


def bounded(argv,out,timeout,*,monitor=False):
 out=Path(out);out.parent.mkdir(parents=True,exist_ok=True);begin=time.time();last=time.time();timed=False;producer_seen=False;producer_pid=None;log_signature=None;model_progress_observed=None
 with out.with_suffix('.stdout.log').open('x') as stdout,out.with_suffix('.stderr.log').open('x') as stderr:
  p=subprocess.Popen(argv,env=ENV,cwd=SOURCE,stdout=stdout,stderr=stderr,start_new_session=True);OWNED[p.pid]=ticks(p.pid)
  event('PROCESS_STARTED',f'case={CURRENT_CASE} launcher/runner PID={p.pid} start_ticks={OWNED[p.pid]}；尚不据此判定设备执行',launcher_pid=p.pid,launcher_start_ticks=OWNED[p.pid],case_argv=argv,stage='HOST_TEST' if CURRENT_CASE=='P0' or str(CURRENT_CASE).startswith('CONFIG') else 'MODEL_STARTING' if monitor else 'ENV_CHECK',worker_processes=owned_processes(p.pid),npu_observed_own_pids=[])
  while p.poll() is None:
   procs=owned_processes(p.pid)
   if monitor and CURRENT_CASE != 'P0' and not CURRENT_CASE.startswith('CONFIG'):sample_worker(procs,out.parent/'worker-provenance.json')
   if monitor and not producer_seen:
    for row in procs:
     argv_list=row['argv_list'];indices=[i for i,v in enumerate(argv_list) if Path(v).name in ('p7x_graph_repair2.py','p7x_graph_repair11_method_anchor.py','p7x_graph_repair13_eagle.py')]
     if indices and indices[0]+1<len(argv_list) and argv_list[indices[0]+1]=='run':
      producer_seen=True;producer_pid=row['pid'];event('MODEL_PRODUCER_STARTED',f'正式模型producer PID={row["pid"]} start_ticks={row["start_ticks"]}已创建；NPU执行仍以实际管理采样/业务产物分开记录',model_producer_pid=row['pid'],stage='MODEL_STARTING');break
   if monitor and time.time()-last>=40:
    last=time.time();rc,txt=query(out.parent/f'npu_smi_{int(last)}.txt');seen=[]
    for line in txt.splitlines():
     fields=[x.strip() for x in line.strip().strip('|').split('|')]
     if len(fields)>=5 and fields[0].split()==[str(PHY//2),str(PHY%2)]:seen.append({'host_pid':fields[1],'container_pid':fields[4]})
    ownseen=[v for v in seen if v['container_pid'].isdigit() and int(v['container_pid']) in {z['pid'] for z in procs}]
    model_logs=list((RUN/'C59_prepare_01'/'launchers'/str(CURRENT_CASE)).glob('*.log'));latest=max((v.stat().st_mtime for v in model_logs),default=None);signature=tuple((str(v),v.stat().st_size,v.stat().st_mtime_ns) for v in model_logs)
    if signature != log_signature and signature:model_progress_observed=now();log_signature=signature
    event('HEARTBEAT',f'case={CURRENT_CASE} 已运行{int(time.time()-begin)}秒；监督器存活，runner存活，子进程{len(procs)}，本卡观测到本任务PID={ownseen if rc==0 else "UNKNOWN"}；最近模型日志mtime={latest}，剩余时间未知',worker_processes=procs,npu_observed_own_pids=ownseen,last_model_log_mtime=latest,last_model_progress=model_progress_observed,model_progress_basis='First supervisor observation of log stat change; filesystem mtime stored separately, not assumed same clock',elapsed_seconds=time.time()-begin,npu_currently_used=bool(ownseen) if rc==0 else None,stage='ENV_CHECK' if CURRENT_CASE=='P0' or CURRENT_CASE.startswith('CONFIG') else 'DEVICE_RUNNING' if ownseen else 'ANALYZING' if producer_seen and not any(z['pid']==producer_pid for z in procs) else 'MODEL_STARTING')
    if OWNER:OWNER['heartbeat_at']=now();write(LEASE/'owner.json',OWNER)
   if time.time()-begin>timeout or time.time()>DEADLINE-25 or OWNER and time.time()>dt.datetime.fromisoformat(OWNER['lease_deadline']).timestamp()-25:
    timed=True;owned_processes(p.pid);stop_owned('bounded case timeout/deadline');break
   time.sleep(2)
  try:rc=p.wait(timeout=15)
  except subprocess.TimeoutExpired:stop_owned('runner did not exit');rc=p.wait(timeout=10)
 return dict(argv=argv,pid=p.pid,start_ticks=OWNED.get(p.pid),returncode=rc,signal=-rc if rc<0 else None,timeout=timed,start_epoch=begin,end_epoch=time.time(),elapsed_seconds=time.time()-begin,stdout=str(out.with_suffix('.stdout.log')),stderr=str(out.with_suffix('.stderr.log')))


def acquire():
 global LEASE,OWNER
 COORD.mkdir(parents=True,exist_ok=True);(COORD/'leases').mkdir(exist_ok=True);(COORD/'releases').mkdir(exist_ok=True)
 proto=COORD/'PROTOCOL_GRAPH_R4.md'
 if not proto.exists():
  with proto.open('x') as f:f.write('# node-25-140 atomic-mkdir-v1\nUse leases/phy-NN atomic mkdir, complete-set acquisition or rollback of own dirs only. Owner token/session/PID/start/boot/namespace/deadline and <=60s heartbeat required. No stale lease theft. Fresh actual mapping/resource admission remains separate. Release only own token after worker exit audit. This is Graph adoption, not other-task acknowledgment or administrator authorization.\n')
 # Verify shared-mount mkdir exclusion without touching any device lease.
 probe=COORD/('atomic_probe_'+TOKEN);results=[]
 for _ in range(2):
  try:probe.mkdir();results.append('CREATED')
  except FileExistsError:results.append('EXISTS')
 probe.rmdir();assert results==['CREATED','EXISTS'];write(SEGMENT/'atomic_mkdir_test.json',dict(results=results,scope='same-mount create exclusion; no device lease yet'))
 rc,txt=query(SEGMENT/'resources_before_acquire.txt');assert rc==0 and f'No running processes found in NPU {PHY//2}' in txt,'selected management NPU busy; no acquisition'
 LEASE=COORD/'leases'/f'phy-{PHY:02d}';LEASE.mkdir()
 OWNER=dict(protocol_version='atomic-mkdir-v1',holder='graph',session=SID,run='r5-c59-node140-phy14-'+SID,candidate=SHA,case=None,host=socket.gethostname(),phy_ids=[PHY],pci=[PCI],pid=os.getpid(),process_start_ticks=ticks(os.getpid()),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),namespace=os.readlink('/proc/self/ns/pid'),token=TOKEN,acquired_at=now(),heartbeat_at=now(),lease_deadline=dt.datetime.fromtimestamp(min(time.time()+7200,DEADLINE),dt.timezone.utc).isoformat(),resource_deadline=dt.datetime.fromtimestamp(DEADLINE,dt.timezone.utc).isoformat(),status='HELD')
 write(LEASE/'owner.json',OWNER);write(SEGMENT/'lease_acquired.json',OWNER)


def probe_device():
 global CURRENT_CASE
 CURRENT_CASE='PROBE';p=SEGMENT/'probe';p.mkdir();inventory=p/'inspect.json';dev=SOURCE/'tools/p7x_graph_repair7_device.py'
 q=subprocess.run([PYTHON,str(dev),'inspect','--output',str(inventory)],env=ENV,capture_output=True,text=True,timeout=30);assert q.returncode==0,q.stderr;inv=json.loads(inventory.read_text());rc,txt=query(p/'resources.txt');assert rc==0
 at=time.time();rec=dict(schema='repair7-user-authorized-device-v1',run_id=PLAN_DATA['run_id'],source_sha=SHA,source_tree=TREE,case_id='PREPROBE',user_authorization=dict(path=str(AUTH),sha256=digest(AUTH)),issued_at=at,expires_at=min(at+1800,DEADLINE),host_phy_id=PHY,tp=1,allocated_nodes={f'/dev/davinci{PHY}':inv['nodes'][f'/dev/davinci{PHY}']},namespace=inv['namespace'],boot_id=inv['boot_id'],visibility=inv['visibility'],mapping_evidence=[dict(path=str(inventory),sha256=digest(inventory))],resource_evidence=[dict(path=str(p/'resources.txt'),sha256=digest(p/'resources.txt'))],resource_observed_at=at);write(p/'receipt.json',rec)
 argv=[str(dev),'probe','--run-id',PLAN_DATA['run_id'],'--receipt',str(p/'receipt.json'),'--output',str(p/'committed-probe.json')]
 body='import runpy,sys,time,json;sys.argv='+repr(argv)+';runpy.run_path(sys.argv[0],run_name="__main__");import torch;d=json.load(open('+repr(str(p/'committed-probe.json'))+'));print(json.dumps(dict(value=d["value"],logical_device=torch.npu.current_device())),flush=True);time.sleep(10)'
 start=time.time_ns();out=(p/'stdout.log').open('x');err=(p/'stderr.log').open('x');child=subprocess.Popen([PYTHON,'-c',body],env=ENV,stdout=out,stderr=err);OWNED[child.pid]=ticks(child.pid);obs=[];first=None
 event('PROBE_START',f'Phy{PHY}/PCI{PCI} probe PID={child.pid}；预计15–35秒，硬超时90秒',probe_pid=child.pid,phy_id=PHY,pci=PCI)
 time.sleep(4)  # Let committed inspect/admission finish before management sampling.
 while child.poll() is None:
  rc,txt=query(p/f'npu_smi_{len(obs):02d}.txt');matches=[]
  for line in txt.splitlines():
   f=[v.strip() for v in line.strip().strip('|').split('|')]
   if len(f)>=5 and f[0].split()==[str(PHY//2),str(PHY%2)] and f[4]==str(child.pid):matches.append(f)
  obs.append(dict(at=now(),path=LAST_DEVICE['path'],smi_mentions_pid=bool(matches),rows=matches,returncode=rc))
  if matches and first is None:first=(matches[0],Path(LAST_DEVICE['path']))
  if time.time_ns()-start>90*10**9:stop_owned('probe timeout');break
  time.sleep(2)
 child.wait(timeout=10);out.close();err.close();result=dict(pid=child.pid,start_ticks=OWNED[child.pid],argv=[PYTHON,'-c',body],start_ns=start,end_ns=time.time_ns(),rc=child.returncode,visibility=str(PHY),stdout=(p/'stdout.log').read_text(),stderr=(p/'stderr.log').read_text(),observations=obs);write(p/'probe_result.json',result);assert child.returncode==0 and first is not None,result
 fields,observed=first;rec['probe']=dict(host_pid=int(fields[1]),container_pid=child.pid,command=result['argv'],start_ns=start,end_ns=result['end_ns'],host_phy_id=PHY,status='EXITED',returncode=0,host_process_evidence=dict(path=str(observed),sha256=digest(observed)),pid_namespace_evidence=dict(path=str(p/'probe_result.json'),sha256=digest(p/'probe_result.json')))
 event('PROBE_END',f'probe value1024、逻辑npu:0与Phy{PHY}实际PID映射通过；进程已退出，此结果不等于模型通过',probe_result=str(p/'probe_result.json'))
 return rec


def run_case(case,probe):
 global CURRENT_CASE, PROVENANCE_DONE
 PROVENANCE_DONE=False
 CURRENT_CASE=case;d=RUN/'admission_C59_01'/case/'attempt01';d.mkdir(parents=True,exist_ok=False);cp=PLAN_DATA['cases'][case];hard=cp['timeout_seconds']+180
 if time.time()+hard+30>min(DEADLINE,dt.datetime.fromisoformat(OWNER['lease_deadline']).timestamp()):write(d/'not_started.json',dict(reason='Insufficient remaining authorized timeout/cleanup budget'));return False
 invpath=d/'inspect.json';dev=SOURCE/'tools/p7x_graph_repair7_device.py';q=subprocess.run([PYTHON,str(dev),'inspect','--output',str(invpath)],env=ENV,capture_output=True,text=True,timeout=30);assert q.returncode==0,q.stderr;inv=json.loads(invpath.read_text());rc,txt=query(d/'resources.txt');assert rc==0 and f'No running processes found in NPU {PHY//2}' in txt
 rec=dict(probe);at=time.time();rec.update(case_id=case,issued_at=at,expires_at=min(at+1800,DEADLINE),namespace=inv['namespace'],boot_id=inv['boot_id'],visibility=inv['visibility'],resource_observed_at=at,mapping_evidence=[dict(path=str(invpath),sha256=digest(invpath))],resource_evidence=[dict(path=str(d/'resources.txt'),sha256=digest(d/'resources.txt'))]);write(d/'receipt.json',rec)
 checks=[]
 for name,argv in [('check',[PYTHON,str(dev),'check','--receipt',str(d/'receipt.json'),'--run-id',PLAN_DATA['run_id'],'--output',str(d/'check.json')]),('bind',[PYTHON,str(SOURCE/'tools/p7x_graph_local_candidate.py'),'bind','--plan',str(PLAN),'--receipt',str(d/'receipt.json'),'--output',str(d/'admitted-plan.json'),'--case-id',case])]:
  checks.append(bounded(argv,d/name,90));assert checks[-1]['returncode']==0,checks[-1]
 OWNER.update(case=case,heartbeat_at=now());write(LEASE/'owner.json',OWNER)
 argv=[PYTHON,str(SOURCE/'tools/p7x_graph_repair6_runner.py'),'--plan',str(d/'admitted-plan.json'),'--case-id',case,'--output',str(CASE_ROOT)]
 eta='ETA_UNKNOWN：新增诊断/性能路径尚无同类耗时；普通锚点历史约1–3分钟，硬超时另行记录'
 event('CASE_START',f'case={case}/attempt01 candidate={SHA} host={socket.gethostname()} Phy{PHY}/PCI{PCI}/logical0待实际观测；TP1；预计{eta}，硬超时{hard}秒；日志{d}',case_argv=argv,timeout_seconds=hard,phy_id=PHY,pci=PCI,stage='HOST_TEST' if case=='P0' or case.startswith('CONFIG') else 'MODEL_STARTING')
 runner=bounded(argv,d/'runner',hard,monitor=True);respath=CASE_ROOT/case/'runner-result.json';res=json.loads(respath.read_text()) if respath.exists() else {};campaign=RUN/'C59_prepare_01'/case/'campaign.json';c=json.loads(campaign.read_text()) if campaign.exists() else {};ok=runner['returncode']==0 and res.get('dependency_satisfied') is True
 earliest_error = c.get('exception_message')
 if earliest_error is None and runner['returncode'] != 0:
  candidates = [Path(runner['stderr'])] + sorted((CASE_ROOT/case).glob('command-*/stderr.log'))
  failures = [(str(p),p.read_text()[-4000:]) for p in candidates if p.exists() and p.stat().st_size]
  earliest_error = dict(layer='producer_or_tool_stderr' if res else 'runner_prelaunch',evidence=failures,primary_failure=res.get('primary_failure'))
 execution=dict(case=case,source_sha=SHA,source_tree=TREE,runner=runner,checks=checks,runner_status=res.get('status'),dependency_satisfied=res.get('dependency_satisfied'),producer_status=c.get('status'),earliest_producer_error=c.get('exception_message'),earliest_failure=earliest_error,artifact_statuses={p.name:json.loads(p.read_text()).get('status') for p in (RUN/'C59_prepare_01'/case).glob('*joint*.json')},case_decision_rc=0 if ok else runner['returncode'] or 2,supervisor_sha256_at_start=START_HASH,supervisor_sha256_at_exit=digest(Path(__file__)))
 write(d/'execution.json',execution)
 with (R/'state/EXPERIMENTS.jsonl').open('a') as f:f.write(json.dumps(execution,ensure_ascii=False)+'\n')
 event('CASE_END',f'case={case} runner_rc={runner["returncode"]} runner={res.get("status")} dependency={res.get("dependency_satisfied")} producer={c.get("status")}；真实首因={earliest_error}；耗时{runner["elapsed_seconds"]:.1f}秒；证据{d}',stage='ANALYZING',last_completed_case=case)
 known_python_unwind = case in ('UNWIND_metadata_before_publish','UNWIND_metadata_store_publish') and ok and c.get('exception_type')=='InjectedMetadataPublishUnwindError' and c.get('exception_message') in ('REPAIR10_METADATA_UNWIND:before_publish','REPAIR10_METADATA_UNWIND:store_publish')
 known_eagle_unwind = case.startswith('UNWIND_EAGLE3_') and ok and c.get('exception_type')=='InjectedEagle3UnwindError' and c.get('exception_message')=='REPAIR19_EAGLE_UNWIND:'+case.removeprefix('UNWIND_EAGLE3_')
 if (c.get('graph_submission_uncertain') or c.get('method_isolation_required')) and not (known_python_unwind or known_eagle_unwind):
  write(SEGMENT/'native_uncertainty.json',execution)
  event('ISOLATION_REQUIRED','生产提交状态不明，停止本设备后续派发，仅Host证据与进程隔离',stage='ANALYZING',native_uncertainty_unresolved=True)
  raise RuntimeError('Graph submission uncertain; no further device reuse')
 return ok


def main():
 global PLAN_DATA,DEADLINE
 parser=argparse.ArgumentParser();parser.add_argument('--cases',nargs='+',required=True);args=parser.parse_args();PLAN_DATA=json.loads(PLAN.read_text());DEADLINE=dt.datetime.fromisoformat(json.loads(AUTH.read_text())['deadline_utc']).timestamp();assert socket.gethostname()=='node-25-140';assert PLAN_DATA['commit']==SHA and PLAN_DATA['tree']==TREE;assert PLAN_DATA['authorized_host_phy_ids']==list(range(8,16));assert time.time()<DEADLINE
 assert not json.loads((R/'state/R5_SESSION_STATE.json').read_text()).get('native_uncertainty_unresolved',False)
 accepted=set()
 for prior in CASE_ROOT.glob('*/runner-result.json'):
  if json.loads(prior.read_text()).get('dependency_satisfied') is True:accepted.add(prior.parent.name)
 for case in args.cases:
  assert case in PLAN_DATA['cases']
  missing=set(PLAN_DATA['cases'][case]['dependencies'])-accepted
  if missing:raise ValueError('Pre-admission dependency closure missing for '+case+': '+repr(sorted(missing)))
  accepted.add(case)
 SEGMENT.mkdir(parents=True,exist_ok=False);write(SEGMENT/'supervisor_identity.json',dict(pid=os.getpid(),start_ticks=ticks(os.getpid()),sha256=START_HASH,source_sha=SHA,cases=args.cases,deadline=DEADLINE));event('SEGMENT_START','C56保持C54生产，区分捕获辅助query/当前query/FIA Host更新query，并修复专用checker直接CLI；先验证完整9样本和真实scheduler，再四个Eagle3专属Python故障点；仅严格专用checker接受后允许下一独立进程，未知native仍隔离停止；实际Phy14/PCI81；旧C48失败不改判。先真实数值/调度，再独立无本任务重负载性能与profiling，Gate冻结。',stage='ENV_CHECK')
 outcomes=[]
 try:
  acquire();probe=probe_device()
  for case in args.cases:outcomes.append(dict(case=case,scoped_accepted=run_case(case,probe)))
 finally:
  live=[pid for pid,t in OWNED.items() if ticks(pid)==t]
  if live:stop_owned('segment cleanup after runner exit/failure')
  if OWNER and LEASE and (LEASE/'owner.json').exists():
   current=json.loads((LEASE/'owner.json').read_text());assert current['token']==TOKEN
   OWNER.update(status='RELEASED',released_at=now(),remaining_owned_pids=[pid for pid,t in OWNED.items() if ticks(pid)==t]);write(SEGMENT/'lease_release.json',OWNER);write(COORD/'releases'/('graph_'+TOKEN+'.json'),OWNER)
   if not OWNER['remaining_owned_pids']:(LEASE/'owner.json').unlink();LEASE.rmdir()
  aggregate=dict(cases=outcomes,all_selected_attempted=len(outcomes)==len(args.cases),all_scoped_accepted=len(outcomes)==len(args.cases) and all(x['scoped_accepted'] for x in outcomes),unhandled_exception=repr(sys.exc_info()[1]) if sys.exc_info()[1] else None,scope='Case/runner acceptance only, not formal Graph gate; supervisor rc2 for any failed/blocked/not-started case')
  write(SEGMENT/'segment_result.json',aggregate)
  event('SEGMENT_END','本段退出并核对本任务进程/租约；设备完成与资源释放分别裁决',stage='ANALYZING',running_candidate=None,active_pids=[],current_case=None)
 return 0 if aggregate['all_scoped_accepted'] else 2

if __name__=='__main__':raise SystemExit(main())
