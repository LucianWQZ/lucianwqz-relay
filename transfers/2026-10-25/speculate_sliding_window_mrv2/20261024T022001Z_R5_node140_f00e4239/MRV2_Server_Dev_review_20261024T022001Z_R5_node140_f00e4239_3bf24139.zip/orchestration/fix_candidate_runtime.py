"""Finite Host-only creation of a fixed checkout and exact native/generated overlay."""
import argparse,subprocess,json,hashlib,shutil,datetime
from pathlib import Path
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID='20261024T022001Z_R5_node140_f00e4239'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--sha',required=True);p.add_argument('--donor',type=Path,required=True);a=p.parse_args()
dev=R/'work/node140/vllm-ascend';tree=subprocess.check_output(['git','rev-parse',a.sha+'^{tree}'],cwd=dev,text=True).strip();prod=subprocess.check_output(['git','rev-parse',a.sha+':vllm_ascend'],cwd=dev,text=True).strip();dest=R/'candidates/node140'/a.name/'vllm-ascend';dest.parent.mkdir(exist_ok=False)
subprocess.run(['git','worktree','add','--detach',str(dest),a.sha],cwd=dev,capture_output=True,check=True)
m=json.loads(a.donor.read_text());tracked=set(subprocess.check_output(['git','ls-files'],cwd=dest,text=True).splitlines());files=[]
for row in m['overlay']:
 rel=row['relative_path'];source=Path(row['target']);assert digest(source)==row['sha256'];target=dest/rel
 if rel in tracked:assert target.exists() and digest(target)==row['sha256'],rel
 else:
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);assert digest(target)==row['sha256']
 files.append(dict(relative_path=rel,bytes=row['bytes'],sha256=row['sha256'],source=str(source),target=str(target)))
runtime=R/'runtime/node140'/a.name;runtime.mkdir();record=dict(source_sha=a.sha,source_tree=tree,production_tree=prod,overlay=files,donor=str(a.donor),donor_manifest_sha256=digest(a.donor),scope='Same verified node140 ABI/build lineage; exact manifest native/generated files only; no old production Python copied; device validation separate')
(runtime/'runtime_manifest.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));assert not subprocess.check_output(['git','status','--porcelain'],cwd=dest,text=True)
print(json.dumps(dict(fixed_candidate=str(dest),runtime=str(runtime),source_sha=a.sha,tree=tree,files=len(files),bytes=sum(x['bytes'] for x in files)),ensure_ascii=False))
