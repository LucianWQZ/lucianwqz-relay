import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
OPS=Path(__file__).parent
PY="/usr/local/python3.11.10/bin/python"
PHASES=[('C52_perf03', 'run_c52_perf03_cases.py', ['PROFILE18_G_OFF_long16', 'PROFILE18_E_ON_long16']), ('C56_Eagle', 'run_c56_cases.py', ['P0', 'CONFIG_EAGLE3', 'EAGLE3_G_ON', 'EAGLE3_NUMERIC', 'EAGLE3_E_ON', 'EAGLE3_SCHED_G_OFF', 'EAGLE3_SCHED_G_ON', 'EAGLE3_SCHED_E_ON', 'UNWIND_EAGLE3_before_first_replay', 'UNWIND_EAGLE3_after_first_update', 'UNWIND_EAGLE3_after_ar_update', 'UNWIND_EAGLE3_after_diagnostic_completion'])]
record=dict(start=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),phases=[])
p=OPS/"pipeline_c52perf03_c56_01.execution.json"
def save():p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
save()
for phase,script,cases in PHASES:
 row=dict(phase=phase,argv=[PY,str(OPS/script),"--cases",*cases],start=datetime.datetime.now(datetime.timezone.utc).isoformat());record["phases"].append(row);save()
 q=subprocess.run(row["argv"],cwd=OPS)
 row.update(end=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=q.returncode);save()
 if q.returncode:record["stopped_reason"]="Phase failed/blocked; no automatic retry or next device dispatch";save();raise SystemExit(q.returncode)
record["end"]=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
