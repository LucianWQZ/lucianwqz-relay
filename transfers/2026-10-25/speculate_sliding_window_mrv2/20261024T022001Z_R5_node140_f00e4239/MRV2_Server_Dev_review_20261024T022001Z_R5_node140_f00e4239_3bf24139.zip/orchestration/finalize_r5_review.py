"""Final offline assembly and self-check; invoke only after model chain cleanup."""
import collections
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import shutil
import struct
import subprocess
import zipfile

import build_r5_review as b

R, O, RET, RAW, SID, SHA, TREE = b.R, b.O, b.RET, b.RAW, b.SID, b.SHA, b.TREE


def portable():
    d = RAW / 'C59_prepare_01/EAGLE3_NUMERIC'
    manifest = b.read(d / 'eagle-numeric.json')
    root = d / manifest['tensor_root']
    out = RET / 'portable_numeric_excerpt'
    out.mkdir(exist_ok=True)
    refs = {}

    def visit(x):
        if isinstance(x, dict):
            if 'tensor_ref' in x:
                refs[x['tensor_ref']['path']] = x['tensor_ref']
            else:
                for v in x.values(): visit(v)
        elif isinstance(x, list):
            for v in x: visit(v)

    excerpts = []
    for i in (0, 1, 2, 4):
        original = d / f'eagle-numeric-sample-{i:03}.json'
        payload = b.read(original)
        selected = {k: v for k, v in payload['mapping'] if k in {
            'identity', 'group', 'descriptor', 'active', 'first_pass', 'inputs', 'reference_inputs',
            'canonical_table', 'l0', 'ends', 'valid', 'oracle', 'actual_reads', 'reference_metadata',
            'actual_slots', 'captured_full_input_queries', 'runtime_queries', 'graph', 'reference',
            'reference_call', 'metrics', 'status'}}
        visit(selected)
        name = f'sample-{i:03}-EXCERPT.json'
        b.write(out / name, dict(scope='EXCERPT_NOT_COMPLETE_ARTIFACT_NO_FULL_KV_RECOMPUTATION',
                                original_sample=str(original), original_sha256=b.hashlib.sha256(original.read_bytes()).hexdigest(),
                                tensor_root='tensors', fields=selected))
        excerpts.append(name)
    (out / 'tensors').mkdir(exist_ok=True)
    for name, ref in refs.items():
        source = root / name
        assert source.stat().st_size == ref['bytes']
        assert hashlib.sha256(source.read_bytes()).hexdigest() == ref['sha256']
        shutil.copyfile(source, out / 'tensors' / name)
    b.write(out / 'INDEX.json', dict(excerpts=excerpts, tensors=list(refs.values()),
        scope='ACTUAL_C59_OUTPUT_AND_INPUT_EXCERPTS; original complete sample fails KV at sample004; output equality alone is insufficient'))
    code = '''from pathlib import Path
import hashlib,json,math,struct
root=Path(__file__).parent
idx=json.loads((root/'INDEX.json').read_text());result=[]
for name in idx['excerpts']:
 d=json.loads((root/name).read_text());f=d['fields'];a=f['graph']['tuple'];b=f['reference']['tuple'];pairs=[]
 for x,y in zip(a,b):
  rx,ry=x['tensor_ref'],y['tensor_ref'];payload=[]
  for ref in (rx,ry):
   data=(root/'tensors'/ref['path']).read_bytes();assert len(data)==ref['bytes'];assert hashlib.sha256(data).hexdigest()==ref['sha256'];assert ref['dtype']=='torch.bfloat16';assert math.prod(ref['shape'])*2==len(data);payload.append(data)
  active=f['active']*(4 if f['first_pass'] else 1);prefix=active*math.prod(rx['shape'][1:])*2
  finite=all((v[0]&0x7f80)!=0x7f80 for data in payload for v in struct.iter_unpack('<H',data[:prefix]));pairs.append(dict(active_byte_equal=payload[0][:prefix]==payload[1][:prefix],full_padded_byte_equal_observation=payload[0]==payload[1],finite_active=finite,active_rows=active,shape=rx['shape']))
 result.append(dict(sample=name,pairs=pairs,scope='OUTPUT_EXCERPT_ONLY_NOT_COMPLETE_KV_OR_FORWARD_REFERENCE'))
print(json.dumps(result,indent=2))
'''
    (out / 'recompute_outputs.py').write_text(code)
    q = subprocess.run(['/usr/local/python3.11.10/bin/python', str(out / 'recompute_outputs.py')],
                       capture_output=True, text=True, timeout=30)
    assert q.returncode == 0, q.stderr
    (out / 'SERVER_OUTPUT_RECOMPUTATION.json').write_text(q.stdout)
    subprocess.run(['/usr/local/python3.11.10/bin/python', str(b.OPS / 'extract_C59_failed_K_blocks.py')], check=True)


def main():
    state = b.read(R / 'journal/current_status.json')
    assert not state.get('active_pids') and not state.get('active_leases'), 'Model/lease must be cleaned before offline assembly'
    subprocess.run(['/usr/local/python3.11.10/bin/python', str(b.OPS / 'analyze_final_c59_performance.py')], check=True)
    b.main()
    perf = b.read(O / 'C59_performance_summary.json')
    b.cp(O / 'C59_performance_summary.json', 'MRV2_性能与接受率_Summary.json')
    b.cp(O / 'C59_performance_cells.csv', 'MRV2_性能与接受率_逐cell.csv')
    for name in ('C59_numeric_KV_failure_analysis.json', 'C59_numeric_failure_classification.json',
                 'Eagle3_K后态反例与最小补证计划.md'):
        b.cp(O / name)
    b.cp(R / 'state/PATH_BINDING.json', 'PATH_BINDING.json')
    b.cp(R / 'state/STORAGE_BINDING.json', 'STORAGE_BINDING.json')
    b.cp(R / 'reports/DECISION_QUEUE.md', 'DECISION_QUEUE.md')
    b.cp(R / 'reports/RESUME.md', 'RESUME.md')
    scope = b.read(O / 'Graph最终交付范围与验收矩阵.json')
    b.cp(O / 'Graph最终交付范围与验收矩阵.json', 'Graph最终交付范围与验收矩阵.json')
    b.doc('Graph最终交付范围与验收矩阵.md', '\n'.join([
        '# Graph最终交付范围与验收矩阵', '',
        '类别1=必须且有对应限定证据；2=必须但仍有实现/验证缺口；3=原定forced-OFF/unsupported；4=具体产品组合合同待确认。未实现不改成unsupported。', '',
        '|范围|类别|当前真实状态|下一步|', '|---|---|---|---|',
        *[f"|{x['feature']}|{x['category']}|{x['current_status']}|{x['next_action']}|" for x in scope['items']]]))
    for item in scope['source_documents']:
        p = Path(item['path'])
        assert hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256']
        b.cp(p, 'requirements/' + p.name)
    r4 = R / 'return/20261023T121157Z_R4_node140_c8776394'
    for p in r4.glob('MRV2_Graph_*'):
        if p.suffix == '.md' and any(x in p.name for x in ('验收', '独立技术')):
            b.cp(p, 'requirements/R4_' + p.name)
    portable()
    events = [json.loads(x) for x in (R / 'journal' / SID / 'events.jsonl').read_text().splitlines() if x.strip()]
    starts = [x for x in events if x.get('event') == 'MODEL_PRODUCER_STARTED']
    model_ids = {(x.get('candidate'), x.get('case'), x.get('model_producer_pid')) for x in starts}
    cases = b.read(RET / 'EXPERIMENT_LEDGER.json')
    accepted = [x for x in cases if x['runner_status'] == 'SCOPED_COMMANDS_ACCEPTED']
    observed_model_cases = []
    for case in cases:
        if not isinstance(case.get('start_epoch'), (int, float)) or not isinstance(case.get('end_epoch'), (int, float)):
            continue
        if any(x.get('candidate') == case['producer_sha'] and x.get('case') == case['case']
               and case['start_epoch'] <= dt.datetime.fromisoformat(x['utc']).timestamp() <= case['end_epoch']
               for x in starts):
            observed_model_cases.append(case)
    normal = [x for x in observed_model_cases if x['case'] != 'A1'
              and not x['case'].startswith(('ABORT', 'UNWIND', 'CONFIG')) and x['case'] not in ('P0', 'C2')]
    counts = dict(model_producer_starts_observed=len(model_ids),
                  model_cases_with_correlated_producer_start=len(observed_model_cases),
                  accepted_normal_model_cases_with_observed_start=sum(x['runner_status'] == 'SCOPED_COMMANDS_ACCEPTED' for x in normal),
                  failed_normal_model_cases_with_observed_start=sum(x['runner_status'] != 'SCOPED_COMMANDS_ACCEPTED' for x in normal),
                  successful_scoped_cases=len(accepted), case_execution_records=len(cases),
                  expected_gate_rejection_cases=sum(x['case'] == 'A1' for x in accepted),
                  accepted_abort_cases=sum(x['case'].startswith('ABORT') for x in accepted),
                  accepted_python_unwind_cases=sum(x['case'].startswith('UNWIND') for x in accepted),
                  accepted_fixture_cases=sum(x['case'] == 'C2' for x in accepted),
                  probe_starts=sum(x.get('event') == 'PROBE_START' for x in events),
                  probe_completed_events=sum(x.get('event') == 'PROBE_END' for x in events),
                  new_profiler_collections=5,
                  offline_reanalysis='SEE_REANALYSIS_INDEX_NOT_COUNTED_AS_MODEL_RUN',
                  counts_limit='Observed model-producer starts include expected A1 and intentional faults, not all represent loaded model or successful inference; scoped case counts also include Host CONFIG/P0, never a completion percentage')
    b.write(RET / 'EXECUTION_COUNTS.json', counts)
    now = dt.datetime.now(dt.timezone.utc)
    elapsed = (now - dt.datetime.fromisoformat('2026-10-24T02:20:01+00:00')).total_seconds()
    b.write(RET / 'WINDOW_AND_WAIT.json', dict(start='2026-10-24T02:20:01+00:00',
        deadline='2026-10-24T12:20:01+00:00', snapshot_at=now.isoformat(), elapsed_seconds=elapsed,
        pr_performance_window_wait='NO_NEW_R5_PR_WINDOW_REQUESTED', resource_wait_seconds='NOT_AVAILABLE_AS_SINGLE_AUDITED_TOTAL',
        resource_wait_evidence=str(RAW / 'C54_resource_wait_01'),
        explanation='Resource conflicts and user replies are timestamped, but continuous accumulated waiting duration was not recorded; do not invent zero or infer all non-NPU time was waiting'))
    b.doc('MRV2_执行状态合同核对.md', '''# 分层退出状态合同

实验矩阵分别保留runner进程rc/signal/timeout、producer状态、artifact/checker专用状态、case_decision_rc和最早失败。orchestrator_decision_rc是外部case决策，不冒充顶层shell进程rc。
当前监督器对任一失败/未派发返回2；scoped_accepted只有实际committed runner接受才成立。C56缺EAGLE3_G_OFF依赖的第一次计划在模型启动前被真实runner拒绝（0模型），保留原attempt；后续独立plan/attempt按依赖闭包预检，不删来源或准入检查。
C55真实故障命中但direct CLI被tools/bisect影射stdlib而失败，模块调用只读复核单独记录；C56修真实CLI后C59四故障经原入口通过。原runner失败不被擦除。
exit0不自动等于数值/Graph通过；预期GRAPH_FROZEN、故障隔离、正常业务完成分别统计。C59数值producer74与完整joint FAIL是失败，不能因输出局部一致改写。
''')
    lines = ['# 性能与接受率（R5）', '', '## 同SHA C59最终16K控制', '',
             '16385输入、512输出，TP1，三臂各预声明3次，平衡交错顺序，所有组预热；Target策略均Graph，E_ON仅Draft eager。全部原始cell及失败保留。', '',
             '|arm|有效重复|elapsed中位ms|范围ms|', '|---|---:|---:|---|']
    for x in perf['groups']:
        lines.append(f"|{x['arm']}|{x['n']}|{x['median_ms']:.5f}|{x['min_ms']:.3f}–{x['max_ms']:.3f}|")
    for x in perf['comparisons']:
        lines += ['', f"{x['comparison']}：elapsed变化{x['elapsed_change_percent']:.4f}%；完整3重复={x['complete_three_repetitions']}。"]
    lines += ['', '接受率定义来自pinned scheduler/stats原文：proposed为实际调度proposal，不含padding；accepted不含bonus。平均接受长度含bonus=1+accepted/verification_request_steps。调度统计发生在最终stop/max_tokens截断之前，所以不能要求accepted+steps等于最终输出token数。', '',
              '逐cell实际proposed、accepted、verification、Draft/Target replay、裁剪状态见Summary和CSV；分位置计数在完整JSON acceptance_per_request内。TTFT/TPOT/ITL均NOT_AVAILABLE；未用总elapsed倒算。原框架CPU统计未新增D2H/sync采样。CPU/RAM逐cell峰值NOT_AVAILABLE，准入与外部SMI背景保留。', '',
              '## C52同轮历史控制与优化定位', '',
              'C52原生16K：G_OFF/G_ON/E_ON中位4147.1237/3894.07557/4294.29099ms；ON比OFF elapsed低6.10177%，同Window Graph比Draft eager低9.31971%。OFF accepted/proposed=414/721(57.42025%)、验证103；ON与E_ON=426/595(71.59664%)、验证85。输出512token IDs相同；Window收益包含验证轮数减少，不能全归FIA kernel加速。', '',
              'single-metadata默认关闭原型：3重复，8K elapsed约−1.8334%、short1−2.1825%、short3−3.4127%。省去未用metadata构建，exact snapshot仍约8ms等待；未获得全矩阵资格，保持默认关闭。', '',
              'R4短/8K ON回退16.19%/11.85%/5.58%保留，不与140 R5新文本/长度混作同负载代码收益。不同SHA分表，不合并中位数。', '',
              '## 解释与边界', '',
              '有限重复、同机非独占背景；本任务控制期间无自身并行重负载，不能保证其他用户完全无干扰。长16K是真实中文技术文本，模型配置maxpos40960、runtime max_model_len24576，未擅改RoPE；不外推32K/128K或其他模型/拓扑。性能阈值未正式批准，测量完成不等于业务达标。完整数值/生命周期结论与性能分开。']
    b.doc('MRV2_性能与接受率报告.md', '\n'.join(lines))
    b.doc('MRV2_持续开发阶段总结.md', f'''# MRV2 R5持续开发阶段总结

SESSION：{SID}；节点node-25-140；开始2026-10-24 02:20:01 UTC，原截止12:20:01 UTC。本报告快照{now.isoformat()}，已用{elapsed/3600:.3f}小时，未重置窗口。

## 本轮真正推进

1. DFlash从C35请求锚点补齐独立K15/Q16方法合同、完整真实producer→分块storage→checker→runner。C45同SHA14连续数值/ABA、Target14对、LIFE160串行诊断、四ABORT和四Python异常展开通过，完整joint及执行关联随包。
2. DSpark no-anchor独立K7/Q8/T8：C49完整14数值/ABA和Target14对通过，没有把Q7全局替换为Q8。
3. Eagle建立first-pass/两AR consumer独立捕获与eager参考；定位Full slot、accepted-prefix positions、captured Tensor寿命和Full query拥有者合同。C59三臂自然请求、真实chunked scheduler continuing/terminal/decode/mixed、四Python异常隔离，以及DSpark/DFlash/Q8前哨通过。
4. **Eagle完整9数值仍失败**：4样本精确通过，第5long-three AR1输出精确、前态一致，但K后态物理块1/2不同。旧失败及最小补证计划完整保留，未改容差/排除块凑PASS。
5. TP16增加replicated world/rank/read语义Host生产身份及P2/P6漂移拒绝，107项检查；实际TP16产品startup和全rank设备仍未完成。
6. 默认关闭single-metadata原型小幅收益，未降低exact合同。C52完成12对照、16K三臂9控制及5正常profiler；最终C59新三臂控制结果见性能报告，不能由总耗时推断physical read。

## 当前候选及未完成目标

C59 {SHA}，tree {TREE}；独立固定candidate/runtime，开发树状态见SOURCE_IDENTITY.json，本地提交未push。
DSpark/DFlash限定方法阶段更接近审查；原定整体Graph目标未完成。Eagle完整Target/ABA/正常多代、Q8生命周期、TP16/backend、产品Graph入口/必要组合、最终非Graph集成仍缺。
正常UPDATE/backing为SOURCE_SUPPORTED_CONTRACT，安装适用性待维护者确认；execution operand和physical read直接证据仍缺，未获替代验收批准。public Gate冻结，不具备原定完整产品正式发布条件。

## 下一轮最小工作

先用新默认关闭诊断一次性保存AR1/AR2完整已完成快照和merged真实K后态，区分真实额外写与取证问题；不要原样再跑相同9样本。证据指出production错误时再修，提交固定候选后补对应数值/Target/生命周期。
继续完成TP16真实rank-aware runner/backend及observer-off产品接入；具体组合及最终PR pair按待裁决项推进，不能两边各PASS拼整体PASS。
下一轮仍需至少1片TP1；TP16只有实现和完整准入就绪才申请16片整体窗口。当前授权到期不自动续期。

## 计数、资源与交付

观察到正式producer启动{counts['model_producer_starts_observed']}次；成功限定case {len(accepted)}次包含Host前置，不能作完成率。预期Gate拒绝{counts['expected_gate_rejection_cases']}、专用ABORT {counts['accepted_abort_cases']}、Python展开{counts['accepted_python_unwind_cases']}；fixture {counts['accepted_fixture_cases']}；probe启动/完成事件{counts['probe_starts']}/{counts['probe_completed_events']}；新profiling5次。细分及限制见EXECUTION_COUNTS.json。
资源等待有原始时戳记录，但没有统一累计秒数，报告NOT_AVAILABLE而非虚填0。没有新R5 PR性能窗口等待。最终进程/设备/租约释放须看FINAL_PROCESS_AND_LEASE_CHECK.json，不从旧PID猜测。
用户先看本总结、性能与接受率报告、Graph支持范围与发布条件。服务器自检不等于用户接收验证或发布批准。
''')
    b.doc('MRV2_资源协调与交接记录.md', '''# R5资源协调

沿用node-25-140共同原子mkdir租约，node+Phy/PCI标识，不继承101租约。后八单元原授权；用户补充所有空闲单元按需可用。TP1只领实际一片，先后segment见实际准入receipt，计划名字中phy12不代表后续实际映射。
用户最新决定：其他任务进入不主动退出；若本任务被外部终止，不自动重启争抢并通知。正常case结束/故障隔离/硬timeout仍按既定合同收尾，不能为占卡无目的运行。
本轮性能与自身其他模型重负载分时，外部同机背景记录但不能保证独占。未执行TP16，不占半套资源等待。共同目录与所有本任务lease生命周期在原segment/owner记录；最终释放实查见FINAL_PROCESS_AND_LEASE_CHECK.json。
没有修改PR工作树、PR租约或其他用户进程，没有reset设备。
''')
    b.doc('MRV2_140环境与运行身份.md', '''# R5环境身份

这是140既有成功环境续跑，不是重新迁移。实际node-25-140，boot ID c07febaa-9b23-48a8-bf2b-579efaa26657；Python/usr/local/python3.11.10/bin/python，torch2.10.0/torch_npu2.10.0.post4/CANN9.1。
原生overlay按C8/C11构建lineage复用，C59 runtime_manifest与worker-provenance实际库路径/hash随包；不能将donor旧candidate误认为Python production来源。Python源码固定C59，vLLM固定84030；未升级共享栈。
TMPDIR与编译缓存沿用本机/tmp及已绑定cache，避免NFS TemporaryDirectory清理问题。PATH_BINDING/STORAGE_BINDING包含共享盘事实；盘、RAM、shm、HBM分开记录，不恢复无依据500GiB门槛。
各case启动前inspect/probe/check/bind来自committed工具；用户授权事实与机器映射分开，不伪造管理员receipt。
''')
    # Preserve all raw path/size entries; large data are not duplicated or rehashed here.
    raw_index = []
    for path in RAW.rglob('*'):
        if path.is_file():
            st = path.stat()
            row = dict(path=str(path), bytes=st.st_size)
            stem = path.stem
            if path.suffix == '.bin' and len(stem) == 64 and all(c in '0123456789abcdef' for c in stem):
                row.update(producer_content_address=stem, rehashed_during_delivery=False)
            raw_index.append(row)
    b.write(RET / 'RAW_SERVER_INDEX.json', dict(root=str(RAW), files=raw_index,
        scope='SERVER_PATH_SIZE_INDEX; tensor content-address and profiler parser hashes are separate original evidence; no blanket rehash claim'))
    b.write(RET / 'evidence/COPIED_EVIDENCE_INDEX.json', b.copied)
    print(json.dumps(dict(status='ASSEMBLED_NOT_YET_PACKAGED_OR_RECEIVER_VERIFIED', root=str(RET), counts=counts,
                          raw_files=len(raw_index)), ensure_ascii=False))


if __name__ == '__main__':
    main()
