"""R5 bounded report assembly. Never changes raw evidence or global progress inode."""
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID = '20261024T022001Z_R5_node140_f00e4239'
RUN = R / 'runs' / SID
RAW = RUN / 'raw'
OPS = RUN / 'orchestration'
O = R / 'reports' / SID
RET = R / 'return' / SID
DEV = R / 'work/node140/vllm-ascend'
SHA = '3bf24139a506dc4fb8417a5a26c15ca33ac0aa9c'
TREE = 'b85f1a87cc0d337a5bd8db1bf5c61e7fe8b3ba5b'
MANUAL = R.parent / 'manual_review/adapt_人工后续核查.md'
NOW = dt.datetime.now(dt.timezone.utc).isoformat()
copied = []


def read(p):
    return json.loads(Path(p).read_text())


def write(p, value):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def doc(name, text):
    (RET / name).write_text(text.strip() + '\n')


def cp(p, target=None):
    p = Path(p)
    if not p.is_file():
        return
    dest = RET / (target if target else 'evidence/' + str(p.relative_to(R)))
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(p, dest)
    copied.append(dict(source=str(p), member=str(dest.relative_to(RET)), bytes=p.stat().st_size,
                       sha256=hashlib.sha256(p.read_bytes()).hexdigest(), scope='ORIGINAL_FILE_COPY'))


def main():
    RET.mkdir(parents=True, exist_ok=True)
    # The matrix preserves each layer and each attempt, including prelaunch failures.
    rows = []
    for p in sorted(RAW.glob('admission*/*/attempt*/execution.json')):
        j = read(p)
        runner = j.get('runner', {})
        case = j.get('case', p.parent.parent.name)
        receipts = list(p.parent.glob('receipt.json'))
        receipt = read(receipts[0]) if receipts else {}
        admitted = p.parent / 'admitted-plan.json'
        plan = read(admitted).get('cases', {}).get(case, {}) if admitted.exists() else {}
        output = Path(plan['outputs']) if plan.get('outputs') else None
        campaign = read(output / 'campaign.json') if output and (output / 'campaign.json').exists() else {}
        rows.append(dict(case=case, attempt=p.parent.name, segment=p.parents[2].name,
                         producer_sha=j.get('source_sha'), source_tree=j.get('source_tree'),
                         runner_rc=runner.get('returncode'), runner_signal=runner.get('signal'),
                         timeout=runner.get('timeout'), runner_status=j.get('runner_status'),
                         producer_status=j.get('producer_status'),
                         artifact_statuses=json.dumps(j.get('artifact_statuses', {}), ensure_ascii=False),
                         checker_status='SEE_ARTIFACT_STATUSES_AND_ORIGINAL_RUNNER_RECORD',
                         orchestrator_decision_rc=j.get('case_decision_rc'),
                         start_epoch=runner.get('start_epoch'), end_epoch=runner.get('end_epoch'),
                         elapsed_seconds=runner.get('elapsed_seconds'), pid=runner.get('pid'),
                         start_ticks=runner.get('start_ticks'), argv=json.dumps(runner.get('argv'), ensure_ascii=False),
                         producer_argv=json.dumps(plan.get('argv'), ensure_ascii=False),
                         run_id=plan.get('run_id'), requests_sha256=plan.get('requests_sha256'),
                         fixture_sha256=plan.get('fixture_sha256'),
                         configuration_identity=json.dumps({k: v for k, v in campaign.items()
                             if ('sha256' in k or k in ('profile', 'config_identity'))}, ensure_ascii=False),
                         host_phy_id=receipt.get('host_phy_id'), logical_device=0 if receipt else None,
                         tp=receipt.get('tp'), boot_id=receipt.get('boot_id'), namespace=receipt.get('namespace'),
                         earliest_failure=j.get('earliest_failure'),
                         device_receipt=str(receipts[0]) if receipts else 'NOT_AVAILABLE',
                         evidence=str(p)))
        cp(p)
        for f in ('receipt.json', 'check.json', 'worker-provenance.json'):
            cp(p.parent / f)
        # Actual mapping/occupancy evidence is small, unlike tensor payloads.
        for f in ('inspect.json', 'resources.txt'):
            cp(p.parent / f)
    if rows:
        with (RET / 'MRV2_实验矩阵与结论.csv').open('w') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    write(RET / 'EXPERIMENT_LEDGER.json', rows)
    # Copy decisive complete small artifacts, not excerpts disguised as complete inputs.
    roots = ['C45_eagle_prepare_01', 'C49_prepare_01', 'C59_prepare_01']
    for name in roots:
        base = RAW / name
        if not base.exists():
            continue
        cp(base / 'case-plan.json')
        for directory in sorted(base.iterdir()):
            if not directory.is_dir() or directory.name == 'launchers':
                continue
            for p in directory.glob('*.json'):
                if (p.name.endswith('-joint.json') or p.name in ('numeric-reference.json', 'campaign.json',
                        'lifecycle-check.json', 'abort-check.json', 'unwind-check.json', 'profile.json',
                        'eagle-numeric.json', 'eagle-numeric-summary.json', 'eagle-numeric-failure.json')
                        or p.name.startswith(('eagle-contract-', 'eagle-numeric-sample-'))):
                    if p.stat().st_size <= 3 * 1024 * 1024:
                        cp(p)
        for p in base.glob('launchers/*/launcher.json'):
            cp(p)
    # All target joins, commands, pairing decisions and device associations must be included.
    for p in (O / 'R4_Target4_join_originals').glob('*'):
        cp(p)
    for pattern in ('*Target*join*.json', '*Target*index*.json', '*Target*execution*.json'):
        for p in (O / 'reanalysis').glob(pattern):
            cp(p)
    for p in O.glob('C*_verified.json'):
        cp(p)
    for p in O.glob('C*_classification.json'):
        cp(p)
    for p in O.glob('C*_failure*.json'):
        cp(p)
    for pattern in ('C5*host*.log', 'C5*red.log', 'C5*AST*.json', 'C5*identity.json',
                    'C5*execution.json', 'C5*performance*.json', 'C5*performance*.csv',
                    'C52_profile_metadata_exclusive.json', 'C52_new_profiles_host_summary.json',
                    'C52_long16_output_and_workload_identity.json', 'TP16_GLM_backend依赖核对.json'):
        for p in O.glob(pattern):
            if p.stat().st_size <= 2 * 1024 * 1024:
                cp(p)
    for folder in ('profiling_analysis_v2', 'acceptance_definition_sources', 'normal_contract_R5_sources',
                   'PR_C23_interface_excerpts', 'reanalysis/C52_actual_performance_counterexamples'):
        for p in (O / folder).rglob('*'):
            if p.is_file() and p.stat().st_size <= 2 * 1024 * 1024:
                cp(p)
    for f in ('正常合同_R5方法差异审查.md', 'MRV2_PR最新固定pair接口与集成准备.md',
              'PR_C23_fixed_pair_identity.json', 'Eagle3_多step独立数值设计.md',
              'Eagle3_Full_slot_operand合同修正.md', 'Eagle3_rejected_tail合同修正.md',
              'C56_query三角色与真实CLI修复.md', 'Graph最终交付范围与验收矩阵.json'):
        cp(O / f)
    # Relevant prior platform contract sources: exact applicable files, no historical raw archive.
    cp(R / 'return/20261022T193442Z_R3/MRV2_正常Graph合同审查.md', 'platform/R3_正常Graph合同审查.md')
    for directory in [R / 'reports/20261022T132626Z_R2/platform_sources',
                      R / 'return/20261022T193442Z_R3/platform_sources']:
        if directory.exists():
            for p in directory.rglob('*'):
                if p.is_file() and p.stat().st_size < 300000:
                    cp(p, 'platform/' + directory.parent.name + '/' + str(p.relative_to(directory)))
    # Actual environment and fixed scripts/configs. No auth/config secrets or model files.
    for p in OPS.glob('*.py'):
        cp(p, 'orchestration/' + p.name)
    for p in (R / 'inputs' / SID).glob('*.json'):
        if p.stat().st_size < 1000000:
            cp(p)
    for p in (R / 'inputs' / SID / 'requests').glob('*.json'):
        if p.stat().st_size < 1000000:
            cp(p)
    for f in ('runtime_manifest.json',):
        cp(R / 'runtime/node140/C59_3bf24139' / f, 'runtime/C59_' + f)
    for p in (R / 'state').glob('*R5*BINDING*.json'):
        cp(p)
    cp(R / 'state/R5_USER_AUTHORIZATION_RECORD.json')
    cp(R / 'journal' / SID / 'events.jsonl', 'journal/events.jsonl')
    cp(MANUAL, 'adapt_人工后续核查.md')
    cp(R / 'journal/USER_ATTENTION.md', 'journal/USER_ATTENTION.md')
    # Only this session's global log lines; original global file remains append-only and intact.
    with (R / 'journal/progress.log').open() as f:
        selected = [line for line in f if SID in line]
    (RET / 'journal/progress_R5_excerpt.log').write_text(''.join(selected))
    git = lambda *a: subprocess.check_output(['git', '-C', str(DEV), *a], text=True)
    (RET / 'COMMITS.txt').write_text(git('log', '--reverse', '--format=%H %T %s',
        'f00e423936c23b0710fc2b5cd367d34ec7736d26..' + SHA))
    (RET / 'C35_to_C59.diff').write_text(git('diff', 'f00e423936c23b0710fc2b5cd367d34ec7736d26', SHA, '--'))
    for name in git('diff', '--name-only', 'f00e423936c23b0710fc2b5cd367d34ec7736d26', SHA).splitlines():
        p = DEV / name
        if p.is_file():
            cp(p, 'source/' + name)
    bundle = O / 'bundle_verification_C59_02/MRV2_R5_C35_to_C59.bundle'
    cp(bundle, bundle.name)
    for f in ('COMMANDS.json', 'RESTORE_VERIFICATION.json'):
        cp(bundle.parent / f, 'bundle_verification/' + f)
    doc('Git_bundle恢复说明.md', '''# Git bundle恢复

前置基线：C35 f00e423936c23b0710fc2b5cd367d34ec7736d26；本包增量终点C59。
不能单独clone此增量包后假称拥有全部历史。先从已交付C35仓库取得基线，执行git bundle verify，再fetch本包HEAD到独立分支。
bundle_verification/COMMANDS.json与RESTORE_VERIFICATION.json记录了真实临时bare仓恢复、完整SHA与tree一致性。
vLLM pin、native overlay、CANN、Python和模型不在bundle内，需分别按runtime manifest恢复。
''')
    # Result fields are read from full artifacts rather than inferred from exit status.
    final_cases = [x for x in rows if x['producer_sha'] == SHA]
    numeric = RAW / 'C59_prepare_01/EAGLE3_NUMERIC/eagle3-joint.json'
    numeric_result = read(numeric) if numeric.exists() else {'status': 'PENDING_OR_NOT_RUN'}
    write(RET / 'C59_FINAL_CASES.json', final_cases)
    write(RET / 'C59_EAGLE_NUMERIC_STATUS.json', numeric_result)
    write(RET / 'SOURCE_IDENTITY.json', dict(session=SID, sha=SHA, tree=TREE,
        git_status=git('status', '--porcelain'), branch=git('branch', '--show-current').strip(),
        development_path=str(DEV), candidate=str(R / 'candidates/node140/C59_3bf24139/vllm-ascend'),
        vllm_pin='84030bbe3d74d99bad477a3d2e37a973ccd8865c',
        vllm_tree='f3e320f8ae2e9a30e57a3c8dccfac94fcae93bee',
        remote_publication='NOT_PERFORMED', public_graph_gate='FROZEN'))
    profile = O / 'profiling_analysis_v2/MRV2_Profiling_Summary.json'
    if profile.exists():
        cp(profile, 'MRV2_Profiling_Summary.json')
    doc('MRV2_候选与证据对应表.md', f'''# 候选与证据对应表

更新{NOW}。每个原始文件自身的producer/checker/run身份优先；复核不是新NPU执行。

|候选|实际范围|限制|
|---|---|---|
|C33（R4）1d246b8f154e2dc5327d1924b7d7c078ca81d09b|12数值/ABA、Target4双臂12对、LIFE21；补齐Target join原件和执行关联|历史R4，非C59新设备结果|
|C38/C39|DFlash早期14数值/Target，C39只读复核LIFE|保留旧producer与checker不同身份|
|C45 76a7e60d2a5c58991103da41d94c754b302f5a6f|DFlash14数值/ABA、Target14对、LIFE160、四ABORT及四Python展开；Eagle三臂自然请求|LIFE含同步，非正常重叠安全证明；Eagle锚点非完整数值|
|C49 d7a7e66b64ead4805a434caec26f20f5080e7eb3|DSpark sample_from_anchor=false K7/Q8/T8三样本与14数值/ABA、Target14对|Q8 LIFE/异常/产品集成未齐|
|C52 d92903e2e4546c5b4c3987e718eaaedb49b61ec1|优化前后12控制、16K三臂9控制、5次正常profiling、single-metadata三样本前哨|默认关闭优化；无全部矩阵覆盖、无普遍性能达标结论|
|C54/C56/C58|保留失败、部分完成样本与最早异常|不可将部分3/4样本改成9样本PASS|
|C57 28c710082ccb5cc7f44915aceb4e0f18366375b4|TP2/4/16 replicated rank身份/绑定Host基础107检查|产品startup仍TP1，未实施TP16全rank设备runner|
|C59 {SHA}|见C59_FINAL_CASES.json和完整joint；四Python异常、三臂实际scheduler与相关方法前哨|最终数值状态：{numeric_result.get('status')}；不复用C45/C49标签伪装同SHA全矩阵|

C58只增加默认关闭诊断的D2D源Tensor拥有者；C59改变Eagle capture的Full query绑定，必须取得新Eagle设备证据。
C57引入共享Host身份检查，最终性能需区分C52与C59。原生15层参数快照仅C19历史POST_DRAIN导出，不属于本轮新执行实例证据。
''')
    doc('MRV2_正常Graph合同审查.md', '''# 正常Graph合同审查（R5）

## 必须保证什么

本代FIA必须使用本代UPDATE参数；下一代写同址backing之前，上一代最后相关消费者必须完成。
Host return、UPDATE return、retire、进程退出均不是完成证明。

## A：最后consumer到下一次写

已有匹配版本源码表明capture附加流尾notify合流，RI/Stars endGraphNotify将capture相关工作汇回current FIFO；下一代materialize/backing写在该current流排队。
因此在所有相关消费者均属于被合流capture且没有脱离其依赖的工作这一前提下，下一次写排在旧consumer之后。
适用证据见platform/R3_正常Graph合同审查.md、evidence下normal_contract_R5_sources/INDEX.json及实际worker-provenance中的libruntime_v100路径/hash。
不能由仅版本号相同推导所有安装补丁分支；具体安装/硬件适用性仍需平台维护者确认，负责人待确认。

## B：UPDATE版本与放行

每consumer replay前update_stream.wait_stream(current)，replay的ExternalEvent wait/reset与单update_stream的UPDATE/record FIFO配合；FIA专用宏对Host长度vector拥有拷贝。
在上述API合同成立时，当前被放行的任务获取本代更新，下一代update/record不能越过上一代current完成前缀。
Eagle first/AR管理器使用同一speculator.update_stream，各consumer独立bank。必须保持wait-current在replay之前；为取证挪到之后可能形成环依赖。
完整五步论证及源码出处复用R3，R5方法差异见随包原件；结论SOURCE_SUPPORTED_CONTRACT，非正式发布裁决。

## 本轮发现与修复

C58：captured D2D/index_select节点只保存地址不会自动拥有源Tensor；诊断快照必须显式持有源对象，弱引用反例及真实first-pass改善支持修复。
C59：Eagle捕获GPU query与runtime必须绑定同一owned Full input buffer；FIA Host padded query另立合同。严禁通过cast、全局dtype替换、放宽容差取得通过。
上述不是将LIFE drain搬入正常production；C59未新增正常同步或D2H。

## 仍未证明什么

原生参数导出仅POST_DRAIN_EXPORTED_PARAMETERS_ONLY；合成ts/dur不可用于真实先后。
本轮trace有真实MODEL_EXECUTE计数和event/queue关联，但没有generation绑定的执行实例operand，也没有硬件physical read-set。
数值无窗外影响不等于硬件没读取窗外地址。维护者/验收负责人应分别审查语义正确性、API适用性与特定取证方式，不能把网页GPT意见写成批准。
''')
    doc('MRV2_Profiling分析.md', '''# R5 Profiling分析

本轮新采集5次，producer均C52：8K G_ON baseline/single-metadata各1次；16K G_OFF/G_ON/E_ON各1次。原始trace/CSV/DB留raw，包内v2解析器、完整摘要、最小trace片段与hash索引。
初始化/capture不在采集窗口；ALL_DECLARED_GROUPS预热。重型observer、完整Target dump、连续reference、LIFE逐代同步、native verbose关闭；provider开启不等于重型observer安装。

8K各37次materialize：exact snapshot均值baseline8.2757ms、single8.1485ms；materialize9.5989/9.7017ms，未缩短。outer metadata扣除同线程嵌套materialize后0.823665→0.11346ms；两个continuing-prefill build另列，不能混入decode均值。
snapshot的CPU copy包含前序工作等待，不能把它全归小payload拷贝带宽。优化只减少未使用metadata重复构建，未去掉exact同步依赖。~26ms累计Host减少与~29.7ms端到端变化一致，仍不能单凭子范围宣称全部因果。

16K MODEL_EXECUTE硬件计数OFF211、ON171、Draft-eager ON85，分别与Host Draft/Target汇总108+103、86+85、0+85相符。它支持实际Graph dispatch计数一致性，不能据汇总把某task硬配generation/operand。
v2关联使用(cat,name,id)及实际endpoint；裸connectionId跨命名空间碰撞反例保留。direct model execution endpoint为0，generation-bound执行关联NOT_AVAILABLE；旧event/queue direct_matched不能简称执行关联通过。

16K ON有8095个MEMCPY_ASYNC硬件任务，但CSV/DB没有方向/字节字段；ENUM表存在不等于有实际MEMCPY_INFO。H2D/D2H/D2D数量与字节NOT_AVAILABLE。HostToDevice flow类别不是H2D memcpy数量。
并行stream duration不相加当elapsed；同设备时域union可算忙碌区间，未校准Host/Device时钟不相减。所有主要结论对应包内v2 summary字段、per-case摘要及excerpt，不能由相邻行/同shape推断代际。
''')
    doc('MRV2_Graph支持范围与发布条件.md', '''# Graph支持范围与发布条件

最终产品目标未缩减。Graph最终交付范围与验收矩阵.json区分必须项、明确forced-OFF、合同待确认；未实现不能改成unsupported。

阶段候选：DSpark Qwen3-8B K7 sample_from_anchor=true，TP1/W1024/block128，Target4 [7,14,28,32]；Base [7,14,28]缺Target(4,32)是已知范围，应明确拒绝，不eager回退。DFlash K15/Q16/capture[16,32,64]、DSpark no-anchor K7/Q8/[8,16,32]均独立合同。Eagle K3 firstQ4/ARQ1，两类consumer分别验证。
真实模式为FULL_DECODE_ONLY；decode descriptor称FULL不代表FULL整个模式或PIECEWISE已验。

尚缺：Eagle完整Target隔离/ABA/正常多代及有限稳定性；Q8 LIFE/异常与自然请求；TP16真实全rank/backend准入与执行；Graph async/prefix/SP/FlashComm/DSA-CP具体必需组合接入；观察关闭时真实产品入口全链；与最终非Graph固定pair集成。
MTP/DeepSeek-V4 co-trained DSpark保持既有warning-once forced-OFF；DFlash2 Graph现有NotImplemented不被改成通过。其他组合按原合同确定，不扩成任意笛卡尔积。

正常合同适用性、execution operand、physical-read和性能阈值尚待具体维护者/验收负责人决定。负责人不明确时写待确认，没有批准即不视为豁免。
可提交限定方法/范围的工程技术审查；不满足原定整体Graph适配和正式发布审查完整条件。public Gate继续冻结，不自动push/merge。

PR：当前只读固定C23 723a2cf1af91e335a1f19e920ec42fe920f28457，tree a7dbab4674aca4e83d48f685283ffbe45688fc65，vLLM a98247ab4db686ee03c66d5feb3c761e52a2f8ab；尚非用户批准最终pair，C23 prompt-exact新增设备验证未完成。Graph仍独立pin84030。两份PASS不能拼成集成PASS，接口冲突及回归计划随包，未修改PR工作树。
''')
    doc('MRV2_Graph_验收方案_中文说明.md', '''# 给用户的验收方案说明

## 现在担心哪些具体错误

1. 更新错代：本次Draft读到上次长度/地址，可能产生错误token或越界。已有单update流/Event源码合同和多代数值；缺实际执行实例的直接operand关联。
2. 过早覆盖backing：旧任务仍在读时下一代改写，可能偶发错值/崩溃。已有capture notify合流/current FIFO推导及隔离反例，诊断同步成功不单独排除正常重叠风险。
3. Target被污染：Window错误作用于Target或Full写slot/positions，可能长请求后持续输出错误。DFlash/Q8完整双臂逐对联合核验降低风险；不能把旧SHA证据升级为最终SHA全通过。
4. 精确长度/辅助字段混淆：本轮确实发现Eagle captured源对象寿命与query归属问题；C58/C59有红绿Host反例和新设备重验。不能用放宽dtype/容差掩盖。
5. 物理访问与语义不同：数值正确不能证明硬件没有读取窗外地址，缓存预取也可能访问。现有profiler无地址read-set；若合同要求精确物理读范围，需要平台能力或明确替代验收裁决。

## 建议如何审

保持正确性不变式，分别审查API适用合同、独立参考/前态、故障隔离、正常工作量、直接取证能力。先把源码支持的工程论证交独立技术评审，列出无法直接观测的具体风险；需要验收负责人明确是否接受某证明方式。负责人待确认时不虚构审批制度。
调整证明方式即使获同意，也只能承诺约定模型/方法/拓扑/配置和API前提下的语义与生命周期合同，不能承诺未测方法、任意拓扑或硬件精确read-set。
本包只是供网页GPT独立技术审查，用户没有批准替代证据、发布或Gate解冻。网页意见不改设备结果。
''')
    doc('MRV2_Graph_验收主张与证据对应表.md', '''# 验收主张与证据对应表

|主张/要求来源|依据与适用前提|反例/检查|尚存风险与建议|
|---|---|---|---|
|Window只改Draft读取、Full/Target不变：原始设计正确性不变式|scope矩阵引用Frozen Design，原件节选及方法合同；DFlash/Q8完整numeric与Target joins|逐层输出、输入/必要KV前态/后态/写集合与独立参考，保留失败|不能外推所有方法/最终SHA；补受影响范围|
|UPDATE本代生效：平台API必要条件和设计推导|单update流、wait-current前缀、ExternalEvent、Host vector owning copy；匹配API/安装前提|多代诊断和异常展开，原始joint，不只producer自报|平台维护者确认安装适用性；execution occurrence没有直接operand关联|
|旧consumer完成后才覆盖：正确性不变式|capture附加流notify合流、RI/endGraphNotify/current FIFO；无脱离capture工作|LIFE诊断、bank身份、多consumer guard、异常quarantine|不能用逐代drain证明原正常重叠；审阅完整源码顺序|
|执行实例operand：历史诊断/取证方案，是否硬发布门槛来源需确认|C19参数仅post-drain快照；本轮真实task汇总与queue/eventflow|跨命名空间ID碰撞反例，v2拒绝硬配|要求来源分开查；负责人待确认，不能说已满足|
|physical read-set：原验收方式来源需核查|数值非干扰不等于精确物理地址未读；profiler缺地址字段|保持NOT_PROVEN，不重复相同dump|平台接口或明确替代方案供审，未获批准不关闭|
|性能达标：业务阈值尚未正式确认|三臂同机控制、有效工作量/接受率原始计数|保留全部重复、慢值、旧回退|可证明某负载测量结果，不宣布全部性能达标|

团队/维护者明确原文、设计原文、平台必要条件、调查用取证方案、历史Agent自提要求须逐项区分。现有可附原件见evidence与platform；没有团队签字原文的门槛不得编造为不可更改团队制度。
''')
    doc('MRV2_Graph_独立技术评审请求.md', f'''# 网页GPT独立技术评审请求

目标是MRV2投机Draft Sliding Window Graph完整适配。当前C59 {SHA}，tree {TREE}，node-25-140，Python3.11.10/torch2.10/torch_npu2.10.0.post4/CANN9.1，vLLM84030固定。public Gate冻结。本包不是发布请求批准，更不是缺失直接证据已补齐。

请先读验收方案中文说明、候选与证据表、正常合同、完整numeric/Target/故障joint及源码diff。逐项审查：

1. UPDATE生效代际和backing完成顺序是否有逻辑跳跃或循环论证？API安装适用前提是否准确？
2. 独立eager参考是否真的独立？canonical full前态来源、Graph快照与参考调用是否区分？共享底层算子有哪些共同失效风险？相同blob hash不单独证明或否定独立性。
3. 诊断drain/D2H/restore是否改变被证明的正常时序？哪些结论只能限于串行诊断？
4. 是否有把C33/C45/C49/C52旧候选证据错误归给C59的情况？最终同SHA覆盖够不够？
5. C58捕获源Tensor寿命、C59 owned query绑定修复是否必要充分？严格v5是否仍拒绝错误dtype、字节/metadata矛盾、过期generation和FIA Host长度错误？
6. 替代证据是否覆盖原要求防范的错误？execution occurrence operand和physical read-set是否被语义/性能混淆？
7. 哪些缺口可由更小代码/实验继续解决，哪些确需平台维护者？有无比重复native末值dump更直接的补证方法？
8. 最终产品范围、observer-off入口、TP16、其他组合与PR集成还缺什么？

包内evidence/COPIED_EVIDENCE_INDEX.json标完整原件；trace excerpt明确只为片段不可送入完整checker。完整tensor/trace服务器索引可追溯，但网页端不能独立复算所有KV；少量BF16样本仅支持局部复查。服务器自检、网页技术意见、正式发布审批三者分开。
''')
    write(RET / 'evidence/COPIED_EVIDENCE_INDEX.json', copied)
    print(json.dumps(dict(return_root=str(RET), experiments=len(rows), copied_files=len(copied),
                          eagle_numeric=numeric_result.get('status')), ensure_ascii=False))


if __name__ == '__main__':
    main()
