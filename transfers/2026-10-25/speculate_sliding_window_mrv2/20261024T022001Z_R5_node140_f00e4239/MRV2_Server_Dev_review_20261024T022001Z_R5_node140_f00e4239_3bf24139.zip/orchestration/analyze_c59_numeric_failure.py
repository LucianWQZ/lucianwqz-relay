from pathlib import Path
import sys,json,datetime
import torch
R=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt');SID='20261024T022001Z_R5_node140_f00e4239';D=R/'runs'/SID/'raw/C59_prepare_01/EAGLE3_NUMERIC';O=R/'reports'/SID
sys.path.insert(0,str(R/'candidates/node140/C59_3bf24139/vllm-ascend'))
from tools.p7x_graph_repair6_storage import CollectionReader
reader=CollectionReader(D/'eagle-numeric.json');record=reader.record(4)
rows=[]
for key in record['pre_kv']:
 a,b=record['graph_post_kv'][key],record['reference_post_kv'][key];pre,refpre=record['pre_kv'][key],record['reference_pre_kv'][key]
 nz=(a!=b).nonzero();head=nz[:16]
 rows.append(dict(key=key,shape=list(a.shape),post_equal=torch.equal(a,b),pre_equal=torch.equal(pre,refpre),mismatched_elements=nz.shape[0],indices=head.tolist(),graph_values=[float(a[tuple(x)]) for x in head],reference_values=[float(b[tuple(x)]) for x in head],selected_physical_blocks=[record['selected_blocks'][i] for i in sorted(set(nz[:,0].tolist()))] if len(nz) else [],graph_changed_blocks=[record['selected_blocks'][i] for i in (a!=pre).reshape(a.shape[0],-1).any(1).nonzero().flatten().tolist()],reference_changed_blocks=[record['selected_blocks'][i] for i in (b!=refpre).reshape(b.shape[0],-1).any(1).nonzero().flatten().tolist()]))
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),producer_sha=record['identity']['source_sha'],sample=4,identity=record['identity'],metrics=record['metrics'],outputs_equal=[torch.equal(a,b) for a,b in zip(record['graph'],record['reference'])],kv=rows,actual_slots={k:v.tolist() for k,v in record['actual_slots'].items()},inputs={k:v.tolist() for k,v in record['inputs'].items() if k not in ['hidden_states']},scope='READ_ONLY_REAL_DURABLE_FAILED_SAMPLE; NO_NPU_REEXECUTION; ORIGINAL_FAIL_RETAINED')
(O/'C59_numeric_KV_failure_analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False)[:7000])
