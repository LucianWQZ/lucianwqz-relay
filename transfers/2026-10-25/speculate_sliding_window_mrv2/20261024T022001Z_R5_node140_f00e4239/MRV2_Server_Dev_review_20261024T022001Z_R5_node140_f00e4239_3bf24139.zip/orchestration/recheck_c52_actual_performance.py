import copy,datetime,hashlib,json,sys
from pathlib import Path
R=Path("/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt")
SID="20261024T022001Z_R5_node140_f00e4239"
SOURCE=R/"candidates/node140/C52_d92903e2/vllm-ascend"
sys.path[:0]=[str(SOURCE),str(R/"candidates/C2_303ef7fe/vllm")]
from tools.p7x_graph_repair10_performance import check
root=R/"runs"/SID/"raw/C52_prepare_01";case="PERF10_G_ON_short_01"
original=json.loads((root/case/"campaign.json").read_text());profile=json.loads((root/case/"profile.json").read_text());launcher=json.loads((root/"launchers"/case/"launcher.json").read_text());expected=json.loads((root/"case-plan.json").read_text())["cases"][case];artifact=root/case/"profile.json"
out=R/"reports"/SID/"reanalysis/C52_actual_performance_counterexamples";out.mkdir(exist_ok=False)
results=[]
for name in ["valid_actual","wrong_actual_prompt_ids","wrong_config_rehashed_by_producer"]:
 c=copy.deepcopy(original)
 if name=="wrong_actual_prompt_ids":c["outputs"][0]["prompt_token_ids"][0][0]+=1
 if name=="wrong_config_rehashed_by_producer":
  c["llm_kwargs"]["seed"]+=1
  c["config_sha256"]=hashlib.sha256(json.dumps(c["llm_kwargs"],sort_keys=True).encode()).hexdigest()
 result=check(c,launcher,profile,expected,artifact)
 (out/(name+".campaign.json")).write_text(json.dumps(c,ensure_ascii=False,indent=2)+"\n")
 (out/(name+".result.json")).write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
 assert (result["status"]=="PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE") == (name=="valid_actual"),result
 results.append(dict(case=name,result=result["status"],error=result.get("error")))
summary=dict(producer_commit=original["identity"]["source_sha"],checker_commit="d92903e2e4546c5b4c3987e718eaaedb49b61ec1",source_run=str(root/case),result_scope="READ_ONLY_REAL_ARTIFACT_AND_DELIBERATELY_CORRUPTED_MEMORY_COPIES_NO_NPU",at=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_campaign_sha256=hashlib.sha256((root/case/"campaign.json").read_bytes()).hexdigest(),artifact_sha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),results=results)
(out/"SUMMARY.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n");print(json.dumps(summary,ensure_ascii=False))
