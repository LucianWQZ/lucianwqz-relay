"""Read-only CPU excerpt of the actual failed K blocks, never a full artifact."""
from pathlib import Path
import hashlib
import json
import sys

import torch

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID = '20261024T022001Z_R5_node140_f00e4239'
sys.path.insert(0, str(R / 'candidates/node140/C59_3bf24139/vllm-ascend'))
from tools.p7x_graph_repair6_storage import CollectionReader

source = R / 'runs' / SID / 'raw/C59_prepare_01/EAGLE3_NUMERIC/eagle-numeric.json'
record = CollectionReader(source).record(4)
key = 'model.layers.36.self_attn.attn/0'
blocks = [1, 2]
indices = [record['selected_blocks'].index(x) for x in blocks]
out = R / 'return' / SID / 'portable_numeric_excerpt/failed_K_blocks'
out.mkdir(parents=True, exist_ok=True)
files = {}
for field in ('pre_kv', 'graph_post_kv', 'reference_pre_kv', 'reference_post_kv'):
    tensor = record[field][key][indices].contiguous()
    assert tensor.dtype == torch.bfloat16
    data = tensor.view(torch.uint8).numpy().tobytes()
    sha = hashlib.sha256(data).hexdigest()
    name = sha + '.bin'
    (out / name).write_bytes(data)
    files[field] = dict(path=name, bytes=len(data), sha256=sha, shape=list(tensor.shape), dtype=str(tensor.dtype))
index = dict(scope='EXCERPT_TWO_PHYSICAL_K_BLOCKS_NOT_FULL_KV_CHECK', source_collection=str(source),
             identity=record['identity'], physical_blocks=blocks, layer_key=key,
             actual_current_slots={k: v.tolist() for k, v in record['actual_slots'].items()}, files=files,
             actual_original_status=record['status'])
(out / 'INDEX.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
code = '''from pathlib import Path
import json,hashlib,struct
p=Path(__file__).parent;j=json.loads((p/'INDEX.json').read_text());data={}
for field,ref in j['files'].items():
 b=(p/ref['path']).read_bytes();assert len(b)==ref['bytes'] and hashlib.sha256(b).hexdigest()==ref['sha256'];data[field]=b
a,b=data['graph_post_kv'],data['reference_post_kv'];mismatches=sum(x!=y for x,y in zip(struct.iter_unpack('<H',a),struct.iter_unpack('<H',b)))
print(json.dumps(dict(scope=j['scope'],physical_blocks=j['physical_blocks'],post_mismatched_bfloat16_elements=mismatches,pre_equal=data['pre_kv']==data['reference_pre_kv'],reference_post_equals_pre=data['reference_post_kv']==data['pre_kv'],original_status=j['actual_original_status']),indent=2))
'''
(out / 'recompute_K_difference.py').write_text(code)
print('Actual failed K blocks excerpt retained; not a full numeric artifact')
