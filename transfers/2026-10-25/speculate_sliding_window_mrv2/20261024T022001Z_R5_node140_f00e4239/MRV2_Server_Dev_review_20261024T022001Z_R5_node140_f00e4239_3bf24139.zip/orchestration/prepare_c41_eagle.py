import subprocess,json,datetime as dt
from common_c41 import *
o=R/'reports'/SID
a=[PYTHON,'-m','tools.p7x_graph_local_candidate','prepare','--repo',str(SOURCE),'--vllm',str(VLLM),'--inputs',str(R/'inputs'/SID),'--output',str(PLAN.parent),'--host-evidence',str(R/'state/R5_C41_HOST_EVIDENCE.json'),'--run-id','r5-c41-node140-phy12-'+SID,'--reuse-fixture-plan',str(R/'runs'/SID/'raw/C38_prepare_01/case-plan.json'),'--authorized-host-phy-ids',*[str(x) for x in range(8,16)]]
x=dict(start=dt.datetime.now(dt.timezone.utc).isoformat(),argv=a,source_sha=SHA,source_tree=TREE,device_initialization=False)
with (o/'C41_prepare.stdout.log').open('x') as out,(o/'C41_prepare.stderr.log').open('x') as err:q=subprocess.run(a,cwd=SOURCE,env=environment(),stdout=out,stderr=err,timeout=240)
x.update(end=dt.datetime.now(dt.timezone.utc).isoformat(),rc=q.returncode,plan=str(PLAN));(o/'C41_prepare_execution.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps(x,ensure_ascii=False));raise SystemExit(q.returncode)
