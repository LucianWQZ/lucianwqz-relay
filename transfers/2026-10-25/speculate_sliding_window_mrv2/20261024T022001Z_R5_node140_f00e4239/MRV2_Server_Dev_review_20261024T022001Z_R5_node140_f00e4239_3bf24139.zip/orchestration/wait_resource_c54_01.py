"""One bounded, read-only wait, then exec the frozen C54 case supervisor.

No lease is held while waiting. The next supervisor still performs its own
fresh acquire/inspect/probe/check/bind. No active or stale lease is removed.
"""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import time

R = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt')
SID = '20261024T022001Z_R5_node140_f00e4239'
OPS = R / 'runs' / SID / 'orchestration'
OUT = R / 'runs' / SID / 'raw' / 'C54_resource_wait_01'
COORD = R.parent / 'resource_coordination' / 'node-25-140'
DEADLINE = dt.datetime.fromisoformat('2026-10-24T12:20:01+00:00').timestamp()
MAPPING = {14: '0000:81:00.0', 12: '0000:85:00.0', 10: '0000:89:00.0', 8: '0000:8D:00.0'}
CASES = ['EAGLE3_G_ON', 'EAGLE3_NUMERIC', 'EAGLE3_E_ON', 'EAGLE3_SCHED_G_OFF',
         'EAGLE3_SCHED_G_ON', 'EAGLE3_SCHED_E_ON']


def save(path, document):
    temporary = path.with_name(path.name + '.resource-wait-tmp')
    temporary.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')
    os.replace(temporary, path)


def event(message):
    at = dt.datetime.now(dt.timezone.utc)
    with (R / 'journal/progress.log').open('a') as stream:
        stream.write(f'{at.astimezone(dt.timezone(dt.timedelta(hours=8))).isoformat()} '
                     f'node={socket.gethostname()} SESSION={SID} stage=WAIT_RESOURCE：{message}\n')
    for path in [R / 'state/R5_SESSION_STATE.json', R / 'state/SESSION_STATE.json', R / 'journal/current_status.json']:
        document = json.loads(path.read_text())
        document.update(status='WAIT_RESOURCE', active_pids=[os.getpid()], active_leases=[], current_case=None,
                        npu_currently_used=False, current_action=message, last_monitor_check=at.isoformat(),
                        resource_wait_supervisor_pid=os.getpid())
        save(path, document)


def main():
    assert socket.gethostname() == 'node-25-140'
    OUT.mkdir(exist_ok=False)
    begin = time.time()
    save(OUT / 'identity.json', dict(pid=os.getpid(), start_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                                    boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                                    start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                                    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                                    wait_limit_seconds=900, poll_interval_seconds=60, device_initialization=False))
    index = 0
    while time.time() < min(begin + 900, DEADLINE - 1500):
        try:
            query = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, timeout=12)
            text, rc = query.stdout + '\nSTDERR\n' + query.stderr, query.returncode
        except subprocess.TimeoutExpired:
            text, rc = 'TIMEOUT_12_SECONDS', 'TIMEOUT'
        path = OUT / f'smi_{index:03}.txt'
        path.write_text(text)
        index += 1
        for phy, pci in MAPPING.items():
            if (rc != 0 or f'No running processes found in NPU {phy // 2}' not in text or pci not in text
                    or (COORD / 'leases' / f'phy-{phy:02}').exists()):
                continue
            common = (OPS / 'common_c54.py').read_text().replace('PHY=12', f'PHY={phy}')
            common = common.replace("PCI='0000:85:00.0'", f"PCI='{pci}'")
            common_path = OPS / 'common_c54_resume01.py'
            common_path.write_text(common)
            supervisor = (OPS / 'run_c54_cases.py').read_text()
            supervisor = supervisor.replace('from common_c54 import', 'from common_c54_resume01 import')
            supervisor = supervisor.replace("'C54_segment_'", "'C54_resume01_segment_'")
            supervisor = supervisor.replace("'admission_C54_01'", "'admission_C54_resume01'")
            supervisor = supervisor.replace('C54精确区分Eagle3接受前缀/Target Full写网格与实际method字段，v3独立数值诊断；加强性能配置与输入核验',
                f'C54资源恢复：本段实际Phy{phy}/PCI{pci}；原冻结run_id phy12字样仅为名称，不作映射；G_OFF来源Phy12原段，后续case独立记录；v3数值/调度链')
            supervisor_path = OPS / 'run_c54_resume01_cases.py'
            supervisor_path.write_text(supervisor)
            compile(common, str(common_path), 'exec')
            compile(supervisor, str(supervisor_path), 'exec')
            save(OUT / 'dispatch.json', dict(phy=phy, pci=pci, fresh_smi=str(path), cases=CASES,
                                             common_sha256=hashlib.sha256(common_path.read_bytes()).hexdigest(),
                                             supervisor_sha256=hashlib.sha256(supervisor_path.read_bytes()).hexdigest(),
                                             original_frozen_plan_run_name='r5-c54-node140-phy12-' + SID,
                                             scope='Fresh independent device segment; original plan name is not physical mapping'))
            event(f'资源只读观察发现Phy{phy}/PCI{pci}候选空闲，无租约；结束等待并exec既有C54监督器重新准入，尚不表示NPU模型启动。')
            os.execv('/usr/local/python3.11.10/bin/python', ['/usr/local/python3.11.10/bin/python',
                      str(supervisor_path), '--cases', *CASES])
        event(f'当前NPU未使用；监督器有界等待1片TP1，已等待{int(time.time()-begin)}秒，最近设备查询rc={rc}；原始证据{path}，继续Host工作。')
        time.sleep(min(60, max(0, begin + 900 - time.time())))
    event('本次15分钟有界资源观察结束，未派发模型、未持有租约；继续Host并等待资源协调，截止不变。')
    for path in [R / 'state/R5_SESSION_STATE.json', R / 'state/SESSION_STATE.json', R / 'journal/current_status.json']:
        document = json.loads(path.read_text())
        document.update(active_pids=[], resource_wait_supervisor_pid=None)
        save(path, document)


if __name__ == '__main__':
    main()
