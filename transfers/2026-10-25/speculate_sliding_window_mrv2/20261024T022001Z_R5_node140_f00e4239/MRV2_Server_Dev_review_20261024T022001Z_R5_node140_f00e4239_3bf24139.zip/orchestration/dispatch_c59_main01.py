import subprocess
from pathlib import Path
OPS=Path(__file__).parent
order=['P0', 'CONFIG_EAGLE3', 'EAGLE3_G_OFF', 'EAGLE3_G_ON', 'UNWIND_EAGLE3_before_first_replay', 'UNWIND_EAGLE3_after_first_update', 'UNWIND_EAGLE3_after_ar_update', 'UNWIND_EAGLE3_after_diagnostic_completion', 'EAGLE3_SCHED_G_OFF', 'EAGLE3_SCHED_G_ON', 'EAGLE3_E_ON', 'EAGLE3_SCHED_E_ON', 'CONFIG', 'A0', 'A1', 'B0', 'NUMERIC_SENTINEL', 'CONFIG_DFLASH', 'DFLASH_NUMERIC_SENTINEL', 'CONFIG_DSPARK_Q8', 'DSPARK_Q8_SENTINEL', 'EAGLE3_NUMERIC']
raise SystemExit(subprocess.call(["/usr/local/python3.11.10/bin/python",str(OPS/"run_c59_cases.py"),"--cases",*order],cwd=OPS))
