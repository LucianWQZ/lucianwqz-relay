# 验收主张与证据对应表

|主张/要求来源|依据与适用前提|反例/检查|尚存风险与建议|
|---|---|---|---|
|Window只改Draft读取、Full/Target不变：原始设计正确性不变式|scope矩阵引用Frozen Design，原件节选及方法合同；DFlash/Q8完整numeric与Target joins|逐层输出、输入/必要KV前态/后态/写集合与独立参考，保留失败|不能外推所有方法/最终SHA；补受影响范围|
|UPDATE本代生效：平台API必要条件和设计推导|单update流、wait-current前缀、ExternalEvent、Host vector owning copy；匹配API/安装前提|多代诊断和异常展开，原始joint，不只producer自报|平台维护者确认安装适用性；execution occurrence没有直接operand关联|
|旧consumer完成后才覆盖：正确性不变式|capture附加流notify合流、RI/endGraphNotify/current FIFO；无脱离capture工作|LIFE诊断、bank身份、多consumer guard、异常quarantine|不能用逐代drain证明原正常重叠；审阅完整源码顺序|
|执行实例operand：历史诊断/取证方案，是否硬发布门槛来源需确认|C19参数仅post-drain快照；本轮真实task汇总与queue/eventflow|跨命名空间ID碰撞反例，v2拒绝硬配|要求来源分开查；负责人待确认，不能说已满足|
|physical read-set：原验收方式来源需核查|数值非干扰不等于精确物理地址未读；profiler缺地址字段|保持NOT_PROVEN，不重复相同dump|平台接口或明确替代方案供审，未获批准不关闭|
|性能达标：业务阈值尚未正式确认|三臂同机控制、有效工作量/接受率原始计数|保留全部重复、慢值、旧回退|可证明某负载测量结果，不宣布全部性能达标|

团队/维护者明确原文、设计原文、平台必要条件、调查用取证方案、历史Agent自提要求须逐项区分。现有可附原件见evidence与platform；没有团队签字原文的门槛不得编造为不可更改团队制度。
