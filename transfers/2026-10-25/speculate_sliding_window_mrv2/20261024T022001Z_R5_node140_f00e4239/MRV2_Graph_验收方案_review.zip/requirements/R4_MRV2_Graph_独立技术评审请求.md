# MRV2 Graph 独立技术评审请求（给网页 GPT）

请独立审查本ZIP，而不是只复述执行Agent结论。生成时间2026-10-23T18:59:55.479402+00:00。项目目标是完成原定MRV2投机Draft Sliding Window Graph适配；DSpark TP1 Target4仅第一阶段。当前C32 `45cd0e0296cd0ff64f30cc75d3e8a37805b8a71c` / tree `fc4d682b4aad954c9aee7b2d0755636801537ec6`，vLLM pin84030bbe3d74d99bad477a3d2e37a973ccd8865c；环境与当前设备验证阶段见SNAPSHOT_IDENTITY.json。

用户只授权生成评审材料，未批准替代验收、发布、合并或Gate开放。你的意见只能记为独立技术审查意见，不得把缺失设备证据写成已补齐。

## 请回答

1. A/B正常UPDATE与backing推导是否有循环论证或未证明的边？请指出具体源码函数、流/事件前提和可能反例。
2. Runtime源码与140安装/实际加载路径适用性证据是否充分？哪些地方确实需要平台维护者确认，具体应问什么？负责人未知则不要编名字。
3. numeric reference是否是独立调用，是否真的恢复了必要KV前态、输入/层集合/代际？它与Graph共享哪些实现，哪些共同错误不能排除？请区分计算独立与算法独立。
4. LIFE/continuous numeric/normal profiling分别加入什么观测、D2H或同步？是否错误用串行诊断证明正常重叠？
5. 是否有把C19/C28/C29证据错归新SHA/140的地方？当前C32生产phase修复需要哪些最小设备回归？
6. 末值native dump能支持什么，不能支持什么？是否存在更小、更直接且安全的执行occurrence/operand版本验证？
7. physical read-set的要求在材料中来自谁、属于正确性还是某种取证方式？若需要确切硬件读地址，当前替代证据有哪些漏项？请不要自行降低正确性或宣称获批。
8. 请审查continuing-prefill production修复：它是否严格实现原定phase baseline，而非缺桶eager回退？是否影响Target/full write、decode Graph、dummy/profile或异常保护？
9. 哪些缺口可以继续用代码/有判别力实验关闭？哪些确实属于平台可观测性限制？是否存在比当前方案更小、更直接的补证方法？
10. 在明确配置/证据范围下，哪些主张可认可为工程合同，哪些只能OPEN？请给“有条件认可/不认可/需更多证据”，附依据和最小下一步。不得把技术意见自动升格为正式发布批准。

## 建议阅读顺序

先读中文说明 → 主张证据表 → SOURCE_INDEX/SNAPSHOT → 原始平台源码与生产run_fullgraph/lease → numeric producer/checker和小样本 → 原始失败及Host反例 → 整体范围矩阵。

可离线运行C29_sentinel/recompute_outputs.py，验证真实输出finite、Graph/reference精确相等、A/B区分和A′恢复。完整模型/KV-forward必须在服务器复算，包内明确保留其manifest/chunk索引，不伪称小样本足以独立重跑全部模型。

请将结论写成：主张、是否成立、证据、隐含前提、反例、剩余风险、建议动作。不要只给“总体合理”或“仍需owner裁决”。
