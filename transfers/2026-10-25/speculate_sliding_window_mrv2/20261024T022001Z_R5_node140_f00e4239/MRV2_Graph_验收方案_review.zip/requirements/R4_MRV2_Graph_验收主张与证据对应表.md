# MRV2 Graph 验收主张与证据对应表

**裁决：待独立技术评审；没有替代方案批准，没有Gate解冻。** 精确候选/环境快照见 evidence/SNAPSHOT_IDENTITY.json。下述路径均指ZIP内 `acceptance_review/evidence/`，完整原路径与hash见SOURCE_INDEX.json。

## 要求来源核对

|来源类别|实际材料/相关原文|可以确认的权限/含义|不能推导|
|---|---|---|---|
|当前用户明确要求|本轮对话：Window只改Draft读取；不污染Target；不覆盖在读backing；不得降低原证据要求或自行解冻Gate；最新答复仅授权准备网页GPT评审材料|本任务执行边界与正确性要求|用户已批准某套底层替代验收，或具名维护者已确认API|
|团队/维护者明确要求|包内没有找到可验证的具名团队/维护者验收批准文件|负责人/正式要求来源待确认；不能虚构制度或签名|把历史Agent报告自动等同团队不可变发布政策|
|原始设计不变式|requirement_sources/Final_Design，Target/full/write、V_final集合交、generation/lease等；原文行号见REQUIREMENT_EXCERPTS|要保证的数学与隔离语义|只有一种固定工具/trace才可证明|
|平台API使用条件|CANN91_TaskUpdate_en.txt：“A task group is similar to a critical resource and does not support concurrent update of multiple threads and streams.”；ExternalEvent update/wait/reset/record章节|调用方必须满足线程/流、任务捕获与事件复用条件；原文/版本可复查|本安装所有分支天然满足，或任意最终dump可关联执行代际|
|诊断/取证方法|Graph master G1–G5表；LIFE event/drain、native post-drain dump、连续numeric reference|这些方法用于补特定证据；同步成本和证明边界必须披露|诊断路径即正常重叠路径；方法成功即所有正确性成立|
|历史Agent提出、未查到正式确认的证据门槛|Graph master G3 physical-read oracle / G5 timeline；Frozen表中的physical-slot-set oracle|保留原件与当前用户未豁免事实，提交独立评审核查充分性|伪称已获维护者批准，或执行Agent直接删除门槛|

## 五项核心主张

|主张|依据/原件|适用前提|反例/测试|未排除风险|建议裁决|
|---|---|---|---|---|---|
|UPDATE N放行的FIA使用N参数|source_C32/.../dflash/aclgraph.py；Runtime capture_model/model；CANN TaskUpdate；op-plugin update_op_api_common.h|合法capture，单update stream，wait-current前缀位于本代replay前，事件wait/reset/record协议成立|C29三代A/B/A′可区分、同Window独立eager参考；C30长请求失败保留|没有真实occurrence到参数版本的直接映射；相同kernel共享缺陷可能同时影响参考|SOURCE_SUPPORTED_CONTRACT，可审查推导；平台安装适用性待确认，不能命名为直接执行实测|
|旧consumer完成前下一代不覆盖backing|Runtime context_aclgraph.cc附加流尾notify合流；model.cc endGraphNotify；current FIFO；proposal lease/quarantine|所有相关consumer属于被捕获Graph/已合流附加流；无脱离capture的未知异步读者|实际Host反例、C28历史LIFE/异常；C32新的metadata fault工具在包内但设备验收以快照为准|LIFE加入drain不代表正常路径；未知native部分提交没有全组rollback保证|保持正常依赖推导与异常隔离，负责人确认最后consumer及安装例外|
|原生参数对应实际执行实例|历史C19 15参数块绑定范围；本包源码/报告说明post-drain限制|只可把最终参数看成导出快照|当前没有可安全获得的新API，故不重复同dump|实际某次执行地址/参数版本未直接绑定generation；合成ts/dur无真实时间意义|OPEN，OBSERVABILITY_LIMIT；请求更直接平台能力或正式评审替代方式，不改写证据等级|
|Draft Window连续数值正确|C29_sentinel真实graph/reference张量、完整sample JSON、launcher/joint；numeric.py独立_run_model(...NONE)|同Window、完整输入和KV前态、层集合/epoch/active/padded匹配；这是串行诊断|六份原始输出可复算 exact_equal；B可区分，A′恢复；旧dtype/metadata/padding反例保留在历史索引|共享模型/底层FIA并非完全独立算法oracle；完整前态复算需服务器；C32改变phase必须新测|只接受其producer SHA和诊断范围；不以hash相同或greedy token代替完整检查|
|硬件不读窗口外KV地址|原设计G3与physical-slot要求；effective length/参数/输出只能是部分依据|需要明确“实际读取”含cache/向量加载/内部prefetch等的定义与平台观测能力|窗内/窗外反事实可支持语义；目前无完整物理read-set采集|输出无变化不能证明没有读取；参数快照不能证明真实地址访问|OPEN；负责人待确认，需平台能力或明确认可另一证明范围，不能Agent自免|

## 必须避免的混用

- C29/140前哨不是C32执行结果；C28/101完整12对和LIFE不是140新实测。
- 正常成功源码合同与诊断完成证据分别判断；Host return/retire/进程退出不是完成证明。
- 参数绑定、执行实例、物理地址读取、数值语义、性能收益分别裁决。
- 来源完整性/服务器ZIP自检不是用户接收校验，也不是模型验收。
