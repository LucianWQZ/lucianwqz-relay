# Graph支持范围与发布条件

最终产品目标未缩减。Graph最终交付范围与验收矩阵.json区分必须项、明确forced-OFF、合同待确认；未实现不能改成unsupported。

阶段候选：DSpark Qwen3-8B K7 sample_from_anchor=true，TP1/W1024/block128，Target4 [7,14,28,32]；Base [7,14,28]缺Target(4,32)是已知范围，应明确拒绝，不eager回退。DFlash K15/Q16/capture[16,32,64]、DSpark no-anchor K7/Q8/[8,16,32]均独立合同。Eagle K3 firstQ4/ARQ1，两类consumer分别验证。
真实模式为FULL_DECODE_ONLY；decode descriptor称FULL不代表FULL整个模式或PIECEWISE已验。

尚缺：Eagle完整Target隔离/ABA/正常多代及有限稳定性；Q8 LIFE/异常与自然请求；TP16真实全rank/backend准入与执行；Graph async/prefix/SP/FlashComm/DSA-CP具体必需组合接入；观察关闭时真实产品入口全链；与最终非Graph固定pair集成。
MTP/DeepSeek-V4 co-trained DSpark保持既有warning-once forced-OFF；DFlash2 Graph现有NotImplemented不被改成通过。其他组合按原合同确定，不扩成任意笛卡尔积。

正常合同适用性、execution operand、physical-read和性能阈值尚待具体维护者/验收负责人决定。负责人不明确时写待确认，没有批准即不视为豁免。
可提交限定方法/范围的工程技术审查；不满足原定整体Graph适配和正式发布审查完整条件。public Gate继续冻结，不自动push/merge。

PR：当前只读固定C23 723a2cf1af91e335a1f19e920ec42fe920f28457，tree a7dbab4674aca4e83d48f685283ffbe45688fc65，vLLM a98247ab4db686ee03c66d5feb3c761e52a2f8ab；尚非用户批准最终pair，C23 prompt-exact新增设备验证未完成。Graph仍独立pin84030。两份PASS不能拼成集成PASS，接口冲突及回归计划随包，未修改PR工作树。
