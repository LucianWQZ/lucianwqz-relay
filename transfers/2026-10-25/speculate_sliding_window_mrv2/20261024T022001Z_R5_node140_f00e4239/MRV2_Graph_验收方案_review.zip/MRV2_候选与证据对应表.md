# 候选与证据对应表

更新2026-10-24T11:55:01.556436+00:00。每个原始文件自身的producer/checker/run身份优先；复核不是新NPU执行。

|候选|实际范围|限制|
|---|---|---|
|C33（R4）1d246b8f154e2dc5327d1924b7d7c078ca81d09b|12数值/ABA、Target4双臂12对、LIFE21；补齐Target join原件和执行关联|历史R4，非C59新设备结果|
|C38/C39|DFlash早期14数值/Target，C39只读复核LIFE|保留旧producer与checker不同身份|
|C45 76a7e60d2a5c58991103da41d94c754b302f5a6f|DFlash14数值/ABA、Target14对、LIFE160、四ABORT及四Python展开；Eagle三臂自然请求|LIFE含同步，非正常重叠安全证明；Eagle锚点非完整数值|
|C49 d7a7e66b64ead4805a434caec26f20f5080e7eb3|DSpark sample_from_anchor=false K7/Q8/T8三样本与14数值/ABA、Target14对|Q8 LIFE/异常/产品集成未齐|
|C52 d92903e2e4546c5b4c3987e718eaaedb49b61ec1|优化前后12控制、16K三臂9控制、5次正常profiling、single-metadata三样本前哨|默认关闭优化；无全部矩阵覆盖、无普遍性能达标结论|
|C54/C56/C58|保留失败、部分完成样本与最早异常|不可将部分3/4样本改成9样本PASS|
|C57 28c710082ccb5cc7f44915aceb4e0f18366375b4|TP2/4/16 replicated rank身份/绑定Host基础107检查|产品startup仍TP1，未实施TP16全rank设备runner|
|C59 3bf24139a506dc4fb8417a5a26c15ca33ac0aa9c|见C59_FINAL_CASES.json和完整joint；四Python异常、三臂实际scheduler与相关方法前哨|最终数值状态：FAIL；不复用C45/C49标签伪装同SHA全矩阵|

C58只增加默认关闭诊断的D2D源Tensor拥有者；C59改变Eagle capture的Full query绑定，必须取得新Eagle设备证据。
C57引入共享Host身份检查，最终性能需区分C52与C59。原生15层参数快照仅C19历史POST_DRAIN导出，不属于本轮新执行实例证据。
