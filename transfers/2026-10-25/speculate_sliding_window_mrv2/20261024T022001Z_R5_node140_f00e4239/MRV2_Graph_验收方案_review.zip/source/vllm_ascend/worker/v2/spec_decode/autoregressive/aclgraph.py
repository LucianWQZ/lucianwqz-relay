# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Ascend project
from collections.abc import Callable
from typing import Any

import torch
from vllm.config import VllmConfig, set_current_vllm_config
from vllm.config.compilation import CUDAGraphMode
from vllm.forward_context import get_forward_context, set_forward_context
from vllm.logger import logger
from vllm.v1.kv_cache_interface import KVCacheConfig
from vllm.v1.worker.gpu.block_table import BlockTables
from vllm.v1.worker.gpu.cudagraph_utils import (
    BatchExecutionDescriptor,
    CudaGraphManager,
    prepare_inputs_to_capture,
)
from vllm.v1.worker.gpu.input_batch import InputBuffers
from vllm.v1.worker.gpu.model_states.interface import ModelState
from vllm.v1.worker.gpu.spec_decode.autoregressive.cudagraph_utils import SpeculatorCudaGraphManager
from vllm.v1.worker.utils import AttentionGroup

from vllm_ascend.ascend_forward_context import _EXTRA_CTX
from vllm_ascend.compilation.acl_graph import (
    set_draft_graph_params,
    set_draft_graph_prefill_params,
    update_full_graph_params,
)
from vllm_ascend.worker.v2.aclgraph_utils import (
    collect_sorted_captured_token_sizes,
    model_capture_wrapper,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_graph import (
    DraftWindowGraphRoute,
    DraftWindowGraphStage,
    assert_draft_window_graph_metadata_batch,
    build_draft_window_graph_update_binding,
    observe_draft_window_graph_capture,
    observe_draft_window_graph_source,
)
from vllm_ascend.worker.v2.utils import communicator_switch


class AutoRegressiveAclGraphManager(SpeculatorCudaGraphManager):
    """ACL graph manager for autoregressive speculative decoding."""

    def __init__(
        self,
        vllm_config: VllmConfig,
        device: torch.device,
        cudagraph_mode: CUDAGraphMode,
        decode_query_len: int,
        lora_capture_cases: list[int] | None = None,
    ):
        super().__init__(
            vllm_config,
            device,
            cudagraph_mode,
            decode_query_len,
            lora_capture_cases=lora_capture_cases,
        )

        # Upstream constructs graph managers without a speculator reference.
        # AscendAutoRegressiveSpeculator attaches it after construction so replay
        # can rebuild draft metadata and update graph parameters.
        self.speculator: Any = None
        # The attention backend keys its per-size graph params by the actual
        # captured token counts (rounded up to decode_query_len when using
        # speculative decoding), so derive them from the capture descriptors
        # instead of the raw config sizes.
        self.capture_sizes = collect_sorted_captured_token_sizes(self._capture_descs)
        # Upstream uses num_speculative_steps + 1 as the draft-prefill query
        # length and 1 for draft decode.
        self.is_draft_model_prefill = decode_query_len > 1
        if super().needs_capture():
            if self.is_draft_model_prefill:
                set_draft_graph_prefill_params(self.capture_sizes)
            else:
                set_draft_graph_params(self.capture_sizes)

    def capture(
        self,
        forward_fn: Callable,
        model_state: ModelState,
        input_buffers: InputBuffers,
        block_tables: BlockTables,
        attn_groups: list[list[AttentionGroup]],
        kv_cache_config: KVCacheConfig,
        progress_bar_desc: str = "Capturing CUDA graphs",
    ) -> None:
        """Capture ACL graphs for autoregressive speculative decoding."""

        session = getattr(self.speculator, "_eagle3_graph_session", None)
        observe_draft_window_graph_capture(self.speculator, capture_context=session)
        if session is not None:
            actual_forward = forward_fn

            def forward_fn(*args, **kwargs):
                if self.is_draft_model_prefill:
                    n, tokens = args[0], args[1]
                else:
                    desc = args[2]
                    n = desc.num_reqs or min(desc.num_tokens, self.max_num_reqs)
                    tokens = desc.num_tokens
                with session.capture_call(first=self.is_draft_model_prefill, n=n, tokens=tokens):
                    return actual_forward(*args, **kwargs)

        with communicator_switch(), model_capture_wrapper(self.speculator, self.is_draft_model_prefill):
            if self.is_draft_model_prefill:
                super().capture(
                    forward_fn,
                    model_state,
                    input_buffers,
                    block_tables,
                    attn_groups,
                    kv_cache_config,
                    progress_bar_desc=progress_bar_desc,
                )
                if session is None:
                    observe_draft_window_graph_source(self.speculator, DraftWindowGraphStage.CONSUMER)
                return

            def create_forward_fn(desc: BatchExecutionDescriptor, warmup: bool):
                num_tokens = desc.num_tokens
                num_reqs = desc.num_reqs or min(num_tokens, self.max_num_reqs)
                num_tokens_across_dp = (
                    torch.full((self.dp_size,), num_tokens, dtype=torch.int32, device="cpu")
                    if self.dp_size > 1
                    else None
                )
                prepare_inputs_to_capture(
                    num_reqs,
                    num_tokens,
                    model_state,
                    input_buffers,
                    block_tables,
                    attn_groups,
                    kv_cache_config,
                    full_cudagraph=(desc.cg_mode == CUDAGraphMode.FULL),
                )
                seq_lens_cpu_upper_bound = input_buffers.seq_lens_cpu[:num_reqs]
                return lambda cg_mode: forward_fn(
                    num_reqs,
                    cg_mode == CUDAGraphMode.PIECEWISE,
                    BatchExecutionDescriptor(cg_mode=cg_mode, num_tokens=num_tokens, num_reqs=num_reqs),
                    num_tokens_across_dp,
                    seq_lens_cpu_upper_bound,
                )

            CudaGraphManager.capture(self, create_forward_fn, progress_bar_desc=progress_bar_desc)
        if session is None:
            observe_draft_window_graph_source(self.speculator, DraftWindowGraphStage.CONSUMER)

    def dispatch(
        self, num_reqs: int, num_tokens: int, uniform_token_count: int | None,
        num_active_loras: int, max_query_len: int | None = None, num_ubatches: int = 1,
    ) -> BatchExecutionDescriptor:
        owner = self.speculator
        if (getattr(owner, "_eagle3_window_continuing_prefill", False)
                or getattr(owner, "_eagle3_graph_eager_proposal", False)):
            # A declared scheduler phase uses the existing eager route. This
            # branch never catches a missing bucket or an UPDATE exception.
            return BatchExecutionDescriptor(
                cg_mode=CUDAGraphMode.NONE, num_tokens=num_tokens, num_reqs=num_reqs,
                num_active_loras=self._resolve_effective_loras(num_active_loras), num_ubatches=num_ubatches,
            )
        return super().dispatch(
            num_reqs, num_tokens, uniform_token_count, num_active_loras, max_query_len, num_ubatches
        )

    def run_fullgraph(self, desc: BatchExecutionDescriptor) -> torch.Tensor | tuple[torch.Tensor, list[torch.Tensor]]:
        """Replay the draft ACL graph and update its attention parameters."""
        num_tokens = desc.num_tokens
        if self.is_draft_model_prefill:
            logger.info_once(
                "AutoRegressiveAclGraphManager: draft prefill run_fullgraph with num_tokens=%s", num_tokens
            )
        else:
            logger.info_once("AutoRegressiveAclGraphManager: draft run_fullgraph with num_tokens=%s", num_tokens)

        session = getattr(self.speculator, "_eagle3_graph_session", None)
        if session is not None:
            session.controller.require_reusable()
            stream = int(self.update_stream.npu_stream)
            if not hasattr(session, "_update_stream_identity"):
                session._update_stream_identity = stream
            if stream != session._update_stream_identity:
                session.controller.quarantine("Eagle3 UPDATE stream changed")
                raise RuntimeError("Eagle3 UPDATE stream changed across proposals")
            if self.is_draft_model_prefill:
                owner = self.speculator
                try:
                    context = owner._require_eagle3_window_context()
                    session.controller.begin(context.mapping_epoch, context.ordered_request_ids)
                    inputs = owner._materialize_eagle3_first_pass(
                        num_reqs=owner.input_batch.num_reqs, num_reqs_padded=desc.num_reqs,
                    )
                    session.stage(inputs, first=True, n=desc.num_reqs, tokens=desc.num_tokens, ordinal=0)
                except BaseException as error:
                    session.controller.quarantine(type(error).__name__ + ": " + str(error))
                    owner._draft_window_graph_submission_uncertain = True
                    raise
        draft_attn_metadatas = self.speculator.build_draft_attn_metadatas(
            desc.num_reqs,
            desc.num_tokens,
            self.is_draft_model_prefill,
        )
        graph_route = (
            DraftWindowGraphRoute.EAGLE3_FIRST_PASS
            if self.is_draft_model_prefill
            else DraftWindowGraphRoute.EAGLE3_AR_STEP
        )
        graph_provider_present = hasattr(
            self.speculator,
            "_draft_window_graph_binding_provider",
        )
        graph_mode_name = getattr(desc.cg_mode, "name", None)
        if graph_provider_present and not isinstance(graph_mode_name, str):
            raise RuntimeError("Draft Window graph carrier requires an explicit graph mode")
        assert_draft_window_graph_metadata_batch(
            self.speculator,
            route=graph_route,
            draft_attn_metadatas=draft_attn_metadatas,
            num_reqs=desc.num_reqs,
            num_tokens=desc.num_tokens,
            graph_mode=graph_mode_name,
        )
        self.update_stream.wait_stream(torch.npu.current_stream())
        observe_draft_window_graph_source(
            self.speculator,
            DraftWindowGraphStage.REPLAY,
        )
        ret = super().run_fullgraph(desc)
        observe_draft_window_graph_source(
            self.speculator,
            DraftWindowGraphStage.CONSUMER,
        )

        # Mirror vLLM's DP graph-replay token-count metadata.
        num_tokens_across_dp = torch.full([self.speculator.dp_size], num_tokens)
        # sfa_v1.py:AscendSFABackend.get_impl_cls reaches
        # sfa_cp.py:resolve_sfa_impl, whose SFA CP selector reads the current
        # ModelConfig. Publish the draft config because set_forward_context()
        # does not update it.
        # TODO: Remove this explicit current-config scope once ACL graph replay
        # passes VllmConfig directly through the graph-update interfaces.
        draft_vllm_config = self.speculator.draft_vllm_config
        with (
            set_current_vllm_config(draft_vllm_config),
            set_forward_context(
                self.speculator.model_state.attn_metadata,
                draft_vllm_config,
                num_tokens=num_tokens,
                cudagraph_runtime_mode=desc.cg_mode,
                num_tokens_across_dp=num_tokens_across_dp,
                batch_descriptor=None,  # Full graph model don't need batch_descriptor
                slot_mapping=None,
            ),
        ):
            # Select the draft prefill/decode graph-parameter pool.
            _EXTRA_CTX.is_draft_model = True
            _EXTRA_CTX.is_draft_model_prefill = self.is_draft_model_prefill

            forward_context = get_forward_context()
            attn_backend = self.speculator.attn_backend
            assert attn_backend is not None, "Speculator attention backend is not initialized"
            graph_update_binding = build_draft_window_graph_update_binding(
                self.speculator,
                route=graph_route,
                draft_attn_metadatas=draft_attn_metadatas,
            )
            update_full_graph_params(
                # FIXME(Ronald1995): support hybrid attn backend
                attn_backend,
                self.update_stream,
                forward_context,
                num_tokens,
                draft_vllm_config,
                self.speculator.speculative_config,
                draft_attn_metadatas=draft_attn_metadatas,
                draft_window_graph_update_binding=graph_update_binding,
            )
        return ret
