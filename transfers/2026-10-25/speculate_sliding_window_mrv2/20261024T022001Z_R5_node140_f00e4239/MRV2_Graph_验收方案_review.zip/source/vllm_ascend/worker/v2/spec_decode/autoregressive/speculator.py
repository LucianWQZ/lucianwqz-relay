# Adapt from https://github.com/vllm-project/vllm/blob/main/vllm/v1/worker/gpu/sample/spec_decode/autoregressive/speculator.py
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#
import logging
from collections.abc import Mapping
from contextlib import contextmanager
from copy import copy
from typing import TYPE_CHECKING, Any

import numpy as np
import torch
import vllm.v1.worker.gpu.spec_decode.speculator as upstream_speculator_module
from vllm.config import VllmConfig, replace, set_current_vllm_config
from vllm.config.compilation import CUDAGraphMode
from vllm.v1.attention.backend import AttentionBackend
from vllm.v1.kv_cache_interface import KVCacheConfig
from vllm.v1.worker.gpu.attn_utils import build_slot_mappings_by_layer
from vllm.v1.worker.gpu.block_table import BlockTables
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor
from vllm.v1.worker.gpu.input_batch import InputBatch, InputBuffers
from vllm.v1.worker.gpu.model_states.interface import ModelState
from vllm.v1.worker.gpu.spec_decode.autoregressive.speculator import AutoRegressiveSpeculator
from vllm.v1.worker.utils import AttentionGroup

from vllm_ascend.attention.attention_v1 import AscendAttentionBackend, AscendAttentionState
from vllm_ascend.attention.dsa_v1 import AscendDSABackend
from vllm_ascend.attention.indexer import AscendSFAIndexerBackend
from vllm_ascend.attention.mla_v1 import AscendMLABackend
from vllm_ascend.attention.sfa_v1 import AscendSFABackend
from vllm_ascend.utils import vllm_version_is
from vllm_ascend.worker.v2.aclgraph_utils import _get_graph_update_backend
from vllm_ascend.worker.v2.attn_utils import (
    build_attn_metadata_wrapper,
    build_draft_attn_metadata_factory,
)
from vllm_ascend.worker.v2.input_batch import AscendInputBatch, AscendInputBuffers
from vllm_ascend.worker.v2.pcp_manager import AscendPCPManager
from vllm_ascend.worker.v2.spec_decode.draft_window import (
    DraftMetadataInputs,
    DraftWindowPolicyDecision,
    DraftWindowPolicyState,
    build_draft_window_runtime_state,
    build_draft_window_source_capability,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_eager import (
    AscendDraftAttentionReadInputs,
    _isolate_draft_metadata_from_target,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3 import (
    Eagle3DraftWindowMixin,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_graph import (
    DraftWindowGraphRoute,
    consume_draft_window_graph_metadata,
)
from vllm_ascend.worker.v2.spec_decode.pcp_utils import (
    disable_target_pcp_for_replicated_draft,
    prepare_replicated_pcp_config,
)

if TYPE_CHECKING:
    from vllm_ascend.worker.v2.model_states.default import AscendModelState

logger = logging.getLogger(__name__)


class AscendAutoRegressiveSpeculator(Eagle3DraftWindowMixin, AutoRegressiveSpeculator):
    """Shared Ascend spec-decode loop for AscendEagle/AscendMTPSpeculator.

    GQA, MLA, DSA, and SFA draft decode state share one path. The current MTP path
    uses the draft attention backend recorded by ``set_attn``.

    MLA's per-step state lives in ``.decode`` (cloned per step, written via an
    alias), GQA's is top-level. Both rebuild the base metadata for the padded
    draft batch. MLA also forwards rotary ``positions`` into
    build_attn_metadata. DSA and SFA manage their draft state in their metadata
    builders and skip the generic MLA/GQA init and update logic.
    """

    model_state: "AscendModelState"

    def _configure_draft_window(self, decision: DraftWindowPolicyDecision) -> None:
        """Attach the eligible P1 policy contract without enabling a window."""
        if decision.state is not DraftWindowPolicyState.ELIGIBLE_ON:
            raise ValueError("draft-window owner requires an ELIGIBLE_ON policy decision")
        if hasattr(self, "_draft_window_policy"):
            raise RuntimeError("draft-window policy is already configured")
        self._draft_window_policy = decision

    def _initialize_draft_window_source_capability(self) -> None:
        """Atomically bind eligible P2 source and P3 ownership state."""
        policy = getattr(self, "_draft_window_policy", None)
        if policy is None:
            return
        if hasattr(self, "_draft_window_source_capability") or hasattr(
            self,
            "_draft_window_runtime_state",
        ):
            raise RuntimeError("draft-window runtime ownership is already initialized")
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import (
            experimental_draft_window_graph_characterization_enabled,
        )
        from vllm_ascend.worker.v2.spec_decode.draft_window import build_draft_window_runtime_context

        graph_context = None
        if (experimental_draft_window_graph_characterization_enabled()
                and build_draft_window_runtime_context(self.vllm_config, self.block_tables).graph_mode != "NONE"):
            from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_capture import build_eagle3_graph_source
            capability, graph_context = build_eagle3_graph_source(self)
        else:
            capability = build_draft_window_source_capability(
                policy=policy,
                runtime_route=policy.normalized_method,
                attn_groups=self.attn_groups,
                block_tables=self.block_tables,
                causal=True,
                vllm_config=self.vllm_config,
            )
        runtime_state = build_draft_window_runtime_state(capability)
        self._draft_window_source_capability = capability
        self._draft_window_runtime_state = runtime_state
        try:
            self._initialize_eagle3_draft_window_state()
            if graph_context is not None:
                self._eagle3_graph_runtime_context = graph_context
        except BaseException:
            del self._draft_window_source_capability
            del self._draft_window_runtime_state
            raise

    def __init__(self, vllm_config: VllmConfig, device: torch.device):
        """Override the upstream __init__ for Ascend NPUs.

        Ascend attention-metadata building needs more information (e.g.
        seq_lens_cpu from input_batch), so we replace input_buffers with
        AscendInputBuffers after super().__init__.
        """
        vllm_config, self.replicated_pcp = prepare_replicated_pcp_config(vllm_config)
        super().__init__(vllm_config, device)

        self.attn_architecture: str | None = None
        self.attn_backend: type[AttentionBackend] | None = None
        self.draft_vllm_config = self._create_draft_vllm_config()

        del self.input_buffers
        # AscendInputBuffers has extra `seq_lens_cpu` attribute.
        # so reinitialize input_buffers here.
        self.input_buffers: AscendInputBuffers = AscendInputBuffers(
            max_num_reqs=self.max_num_reqs,
            max_num_tokens=self.max_num_tokens,
            device=device,
        )

        # add more attributes for `input_buffers` in graph mode
        cudagraph_mode = self.vllm_config.compilation_config.cudagraph_mode
        if cudagraph_mode.decode_mode() == CUDAGraphMode.FULL:
            self.input_buffers.draft_seq_lens_cpus = [
                torch.zeros(self.max_num_reqs, dtype=torch.int32, device="cpu")
                for _ in range(self.num_speculative_steps - 1)
            ]

        # when in decode phase of eagle speculator, we need some value in
        # draft model's input_batch. so we keep a reference here.
        self.input_batch: InputBatch | None = None
        self.pcp_manager: AscendPCPManager | None = None

    def _create_draft_vllm_config(self) -> VllmConfig:
        """Build the runtime config used while executing the draft model."""
        source_parallel_config = self.vllm_config.parallel_config
        dcp_size = source_parallel_config.decode_context_parallel_size
        parallel_config = replace(
            source_parallel_config,
            pipeline_parallel_size=1,
            decode_context_parallel_size=1 if self.replicated_pcp else dcp_size,
        )
        draft_config = replace(
            self.vllm_config,
            model_config=self.draft_model_config,
            parallel_config=parallel_config,
            cache_config=replace(self.vllm_config.cache_config),
        )
        if self.replicated_pcp:
            # TODO: Separate draft execution settings from worker topology.
            # Restore DCP only after the complete draft config reconstruction;
            # this does not rerun validation or recompute DCP-dependent settings.
            draft_config.parallel_config.decode_context_parallel_size = dcp_size
        return draft_config

    # TODO: Remove this method once vllm-project/vllm#53458 or an
    # equivalent upstream fix is merged.
    def _maybe_remove_d2t(self, draft_model: torch.nn.Module) -> None:
        """Drop the identity d2t mapping of a full-vocab EAGLE3 draft."""
        if self.method != "eagle3":
            return
        target_vocab_size = self.draft_model_config.get_vocab_size()
        draft_vocab_size = draft_model.config.draft_vocab_size
        if draft_vocab_size == target_vocab_size:
            draft_model.draft_id_to_target_id = None

    def load_draft_model(
        self,
        target_model: torch.nn.Module,
        target_attn_layer_names: set[str],
    ) -> torch.nn.Module:
        draft_model = super().load_draft_model(
            target_model,
            target_attn_layer_names,
        )
        self._maybe_remove_d2t(draft_model)
        return draft_model

    @property
    def draft_prefill_attn_groups(self) -> list[list[AttentionGroup]]:
        if self.replicated_pcp:
            return self.attn_groups
        return self.target_attn_groups

    def _prepare_replicated_prefill_attn(
        self,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_reqs_padded: int,
        num_tokens_padded: int,
        cudagraph_runtime_mode: CUDAGraphMode,
    ) -> tuple[
        dict[str, Any] | None,
        dict[str, torch.Tensor] | None,
    ]:
        """Refresh global draft mappings and prepare attention for replicated PCP."""
        input_batch = self.input_batch
        if attn_metadata is None or not self.replicated_pcp or input_batch is None:
            return attn_metadata, slot_mappings

        assert isinstance(input_batch, AscendInputBatch)
        if input_batch.is_dummy:
            return attn_metadata, slot_mappings

        # Omitting out updates the default buffers bound by draft graph capture.
        self.block_tables.gather_block_tables(
            input_batch.idx_mapping,
            num_reqs_padded=num_reqs_padded,
        )
        slot_mappings_tensor = self.block_tables.compute_slot_mappings(
            input_batch.idx_mapping,
            input_batch.query_start_loc,
            input_batch.positions,
            num_tokens_padded=num_tokens_padded,
        )
        # TODO: Remove this early return once FIA supports padded Query tensors
        # whose token count exceeds the cumulative query length. Keep the
        # mapping refresh above when unifying metadata construction.
        if cudagraph_runtime_mode == CUDAGraphMode.FULL and self.attn_architecture in ("MLA", "GQA"):
            return attn_metadata, slot_mappings

        slot_mappings = build_slot_mappings_by_layer(
            slot_mappings_tensor,
            self.kv_cache_config,
        )
        attn_metadata = self._build_draft_attn_metadata(
            num_reqs=input_batch.num_reqs,
            num_reqs_padded=num_reqs_padded,
            num_tokens_padded=num_tokens_padded,
            seq_lens_cpu_upper_bound=input_batch.seq_lens_cpu_upper_bound,
            step=0,
            query_start_loc_np=input_batch.query_start_loc_np,
        )
        return attn_metadata, slot_mappings

    def init_cudagraph_manager(self, cudagraph_mode: CUDAGraphMode) -> None:
        if self.speculative_config.enforce_eager:
            cudagraph_mode = CUDAGraphMode.NONE
        super().init_cudagraph_manager(cudagraph_mode)
        # The Ascend graph managers are patched onto the upstream module and
        # created by super().init_cudagraph_manager without a speculator ref.
        # They need this speculator to update full-graph params, so set it here.
        self.prefill_cudagraph_manager.speculator = self
        self.decode_cudagraph_manager.speculator = self
        self.prefill_cudagraph_manager.update_stream = self.update_stream
        self.decode_cudagraph_manager.update_stream = self.update_stream
        context = getattr(self, "_eagle3_graph_runtime_context", None)
        if context is not None:
            from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_capture import Eagle3GraphSession
            self._eagle3_graph_session = Eagle3GraphSession(self, context)

    def propose(
        self,
        input_batch: InputBatch,
        attn_metadata: dict[str, Any],
        slot_mappings: dict[str, torch.Tensor],
        # [num_tokens, hidden_size]
        last_hidden_states: torch.Tensor,
        # num_layers x [num_tokens, hidden_size]
        aux_hidden_states: list[torch.Tensor] | None,
        # [num_reqs]
        num_sampled: torch.Tensor,
        # [num_reqs]
        num_rejected: torch.Tensor,
        # [max_num_reqs]
        last_sampled: torch.Tensor,
        # [max_num_reqs]
        next_prefill_tokens: torch.Tensor,
        # [max_num_reqs]
        temperature: torch.Tensor,
        # [max_num_reqs]
        seeds: torch.Tensor,
        num_tokens_across_dp: torch.Tensor | None = None,
        dummy_run: bool = False,
        skip_attn_for_dummy_run: bool = False,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
        is_profile: Any = None,
        # vLLM #53694 replaced num_tokens_across_dp with the DP sync state.
        dp_sync: Any = None,
    ):
        """Override GPU EagleSpeculator.propose for Ascend NPUs,
        because npu attention metadata needs more information,
        we need to cache input_batch, so we can use it later in
        generate_draft.
        """
        self.input_batch = input_batch
        if vllm_version_is("0.28.0"):
            sync_state = num_tokens_across_dp
        else:
            # Replicated drafts use global tokens, unlike the PCP-local target.
            # Every DP rank must take the draft sync, including decode and idle ranks.
            sync_state = None if self.replicated_pcp else dp_sync
        # wrap build_attn_metadata to use Ascend attention metadata building.
        # so we can call super().propose() directly.
        with (
            disable_target_pcp_for_replicated_draft(self),
            build_attn_metadata_wrapper(),
            torch_gather_wrapper(),
            self._eagle3_draft_window_proposal_scope(
                input_batch,
                dummy_run=dummy_run,
                is_profile=bool(is_profile),
            ),
        ):
            return super().propose(
                input_batch,
                attn_metadata,
                slot_mappings,
                last_hidden_states,
                aux_hidden_states,
                num_sampled,
                num_rejected,
                last_sampled,
                next_prefill_tokens,
                temperature,
                seeds,
                sync_state,
                dummy_run,
                skip_attn_for_dummy_run,
                mm_inputs,
                is_profile=is_profile,
            )

    def set_attn(
        self,
        model_state: ModelState,
        kv_cache_config: KVCacheConfig,
        block_tables: BlockTables,
        target_input_buffers: InputBuffers,
        target_attn_groups: list[list[AttentionGroup]],
    ) -> None:
        # Initialize the draft attention backend with its PCP=1 config.
        with set_current_vllm_config(self.attn_vllm_config):
            super().set_attn(
                model_state,
                kv_cache_config,
                block_tables,
                target_input_buffers,
                target_attn_groups,
            )

            # Use the first executable draft attention layer as the architecture
            # discriminator and cache it for ACL graph parameter updates.
            self.attn_backend = _get_graph_update_backend(self.attn_groups)
        self._initialize_draft_window_source_capability()
        if issubclass(self.attn_backend, AscendDSABackend):
            self.attn_architecture = "DSA"
        elif issubclass(self.attn_backend, AscendMLABackend):
            self.attn_architecture = "MLA"
        elif issubclass(self.attn_backend, (AscendSFABackend, AscendSFAIndexerBackend)):
            self.attn_architecture = "SFA"
        elif issubclass(self.attn_backend, AscendAttentionBackend):
            self.attn_architecture = "GQA"
        else:
            raise ValueError(f"Unsupported attention backend: {self.attn_backend}")

    def capture(self) -> None:
        logger.info("Capturing model for speculator...")
        # Reset indices to zeros to prevent stale values from prior
        # dummy runs to cause out-of-bounds indexing during capture.
        self.last_token_indices.zero_()
        session = getattr(self, "_eagle3_graph_session", None)
        if session is not None:
            session.initialize_numeric_capture()

        # Capture the prefill routine (model forward + compute_logits +
        # sample).
        # For FULL graphs, the entire routine is recorded as one graph.
        # For PIECEWISE, only the model's compiled regions are captured
        # and the rest (compute_logits, gumbel_sample) runs eagerly.
        assert self.prefill_cudagraph_manager is not None
        if self.prefill_cudagraph_manager.use_breakable_cg:
            self.prefill_cudagraph_manager.init_breakable_cg_runner(self.model)
        with disable_target_pcp_for_replicated_draft(self):
            self.prefill_cudagraph_manager.capture(
                self._prefill,
                self.model_state,
                self.target_input_buffers,
                self.block_tables,
                self.draft_prefill_attn_groups,
                self.kv_cache_config,
                progress_bar_desc="Capturing prefill CUDA graphs",
            )

        if self.num_speculative_steps == 1:
            return

        # Capture all decode draft generation steps as a single graph.
        assert self.decode_cudagraph_manager is not None
        with (
            disable_target_pcp_for_replicated_draft(self),
            build_attn_metadata_wrapper(),
        ):
            self.decode_cudagraph_manager.capture(
                self._multi_step_decode,
                self.model_state,
                self.input_buffers,
                self.block_tables,
                self.attn_groups,
                self.kv_cache_config,
                progress_bar_desc="Capturing decode CUDA graphs",
            )

    @torch.inference_mode()
    def _run_model(
        self,
        num_tokens: int,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_tokens_across_dp: torch.Tensor | None,
        cudagraph_runtime_mode: CUDAGraphMode = CUDAGraphMode.NONE,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Override AutoRegressiveSpeculator._run_model for Ascend NPUs."""
        session = getattr(self, "_eagle3_graph_session", None)
        capture_identity = None
        if session is not None and session._capture_call is not None:
            attn_metadata, capture_identity = session.capture_metadata(attn_metadata)
        if session is not None and session.numeric_snapshots is not None:
            session.numeric_snapshots.before_model(capture_identity, attn_metadata, slot_mappings)
        last_hidden_states, hidden_states = super()._run_model(
            num_tokens,
            attn_metadata,
            slot_mappings,
            num_tokens_across_dp,
            cudagraph_runtime_mode,
            mm_inputs,
        )
        if session is not None:
            if session.numeric_snapshots is not None:
                session.numeric_snapshots.after_model(capture_identity)
            session.retain_capture_output(capture_identity, (last_hidden_states, hidden_states))
        return AscendPCPManager.broadcast_replicated_hidden_states(
            last_hidden_states, hidden_states, num_tokens, replicated_pcp=self.replicated_pcp
        )

    def _generate_draft(
        self,
        num_reqs: int,
        num_tokens_padded: int,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_tokens_across_dp: torch.Tensor | None,
        cudagraph_runtime_mode: CUDAGraphMode = CUDAGraphMode.NONE,
    ) -> None:
        """Thin override: delegate to upstream single-step ``_generate_draft``,
        then apply Ascend-specific attention-metadata updates required by the
        FIA operator."""
        if self._eagle3_window_is_active():
            if cudagraph_runtime_mode != CUDAGraphMode.NONE:
                raise NotImplementedError("MRV2 Eagle3 Draft Window supports serialized eager execution only")
            inputs = self._eagle3_window_live_inputs
            if inputs is None:
                raise RuntimeError("Eagle3 Draft forward has no active Window generation")
            stored_metadata = self._draft_window_runtime_state.read_metadata(inputs.identity)
            if attn_metadata is not stored_metadata:
                raise RuntimeError("Eagle3 Draft forward did not receive metadata from the Draft-only store")
            try:
                super()._generate_draft(
                    num_reqs,
                    num_tokens_padded,
                    attn_metadata,
                    slot_mappings,
                    num_tokens_across_dp,
                    cudagraph_runtime_mode,
                )
            except BaseException:
                self._finish_eagle3_window_step(inputs, succeeded=False)
                raise
            self._finish_eagle3_window_step(inputs, succeeded=True)
            return

        super()._generate_draft(
            num_reqs,
            num_tokens_padded,
            attn_metadata,
            slot_mappings,
            num_tokens_across_dp,
            cudagraph_runtime_mode,
        )
        if attn_metadata is not None:
            self._update_decode_attn_metadata(attn_metadata, 1, num_reqs)

    def _multi_step_decode(  # type: ignore[misc]
        self,
        num_reqs: int,
        skip_attn: bool,
        batch_desc: BatchExecutionDescriptor,
        num_tokens_across_dp: torch.Tensor | None,
        seq_lens_cpu_upper_bound: torch.Tensor | None = None,
    ) -> None:
        """Minimal override to handle the merged multi-step graph in FULL mode.

        In FULL mode the captured graph already contains all speculative
        steps, so ``run_fullgraph`` is called once instead of once per
        step.  For PIECEWISE / NONE modes we delegate to the upstream
        ``_multi_step_decode`` which iterates over steps and calls
        ``_generate_draft`` per step.
        """
        session = getattr(self, "_eagle3_graph_session", None)
        if session is not None and self._eagle3_window_is_active() and batch_desc.cg_mode == CUDAGraphMode.FULL:
            if skip_attn or seq_lens_cpu_upper_bound is None:
                raise RuntimeError("real Eagle3 Graph Window requires attention and current CPU upper lengths")
            try:
                padded = batch_desc.num_reqs or num_reqs
                self._snapshot_eagle3_decode_step_one(num_reqs=num_reqs, num_reqs_padded=padded)
                for step in range(1, self.num_speculative_steps):
                    inputs = self._materialize_eagle3_decode_step(
                        step=step, num_reqs=num_reqs, num_reqs_padded=padded,
                        seq_lens_cpu_upper_bound=seq_lens_cpu_upper_bound,
                    )
                    session.stage(inputs, first=False, n=padded, tokens=batch_desc.num_tokens, ordinal=step - 1)
                self.decode_cudagraph_manager.run_fullgraph(batch_desc)
                return
            except BaseException as error:
                session.controller.quarantine(type(error).__name__ + ": " + str(error))
                self._draft_window_graph_submission_uncertain = True
                raise
        if self._eagle3_window_is_active():
            if batch_desc.cg_mode != CUDAGraphMode.NONE:
                raise NotImplementedError("MRV2 Eagle3 Draft Window does not support graph decode")
            if skip_attn:
                raise RuntimeError("a real Eagle3 Window proposal cannot skip Draft attention")
            if seq_lens_cpu_upper_bound is None:
                raise ValueError("Eagle3 Window decode requires Target CPU upper lengths")
            self._snapshot_eagle3_decode_step_one(
                num_reqs=num_reqs,
                num_reqs_padded=batch_desc.num_reqs or num_reqs,
            )
        if batch_desc.cg_mode == CUDAGraphMode.FULL:
            assert self.decode_cudagraph_manager is not None
            self.decode_cudagraph_manager.run_fullgraph(batch_desc)
            return
        super()._multi_step_decode(num_reqs, skip_attn, batch_desc, num_tokens_across_dp, seq_lens_cpu_upper_bound)

    def _prefill(
        self,
        num_reqs: int,
        num_tokens: int,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_tokens_across_dp: torch.Tensor | None,
        cudagraph_runtime_mode: CUDAGraphMode = CUDAGraphMode.NONE,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
    ) -> None:
        attn_metadata, slot_mappings = self._prepare_replicated_prefill_attn(
            attn_metadata,
            slot_mappings,
            num_reqs,
            num_tokens,
            cudagraph_runtime_mode=cudagraph_runtime_mode,
        )
        if self._eagle3_window_is_active():
            if (
                getattr(self, "_eagle3_graph_session", None) is not None
                and cudagraph_runtime_mode == CUDAGraphMode.NONE
            ):
                # Explicit nonuniform-prefill phase rule: all AR consumers of
                # this proposal keep the existing full eager Window path.
                # Never use this rule to recover from a missing Graph bucket.
                self._eagle3_graph_eager_proposal = True
            input_batch = self.input_batch
            assert input_batch is not None
            if cudagraph_runtime_mode != CUDAGraphMode.NONE:
                raise NotImplementedError("MRV2 Eagle3 first-pass Window supports eager execution only")
            if self.replicated_pcp:
                raise NotImplementedError("MRV2 Eagle3 Draft Window does not support replicated PCP")
            if slot_mappings is None:
                raise ValueError("Eagle3 Window first pass requires full physical slot mappings")
            target_metadata = self._require_eagle3_target_metadata(attn_metadata)
            inputs = self._materialize_eagle3_first_pass(
                num_reqs=num_reqs,
                num_reqs_padded=num_reqs,
            )
            try:
                draft_metadata = self._build_eagle3_private_attn_metadata(
                    inputs=inputs,
                    num_reqs=num_reqs,
                    num_reqs_padded=num_reqs,
                    num_tokens_padded=num_tokens,
                    query_start_loc_np=input_batch.query_start_loc_np,
                    target_metadata=target_metadata,
                    first_pass=True,
                )
                super()._prefill(
                    num_reqs,
                    num_tokens,
                    draft_metadata,
                    slot_mappings,
                    num_tokens_across_dp,
                    cudagraph_runtime_mode,
                    mm_inputs,
                )
            except BaseException:
                self._finish_eagle3_window_step(inputs, succeeded=False)
                raise
            self._finish_eagle3_window_step(inputs, succeeded=True)
            return

        # Draft prefill reuses target metadata, but the target metadata may
        # also contain target-only attention layers (e.g. GDN layers).
        if attn_metadata is not None and self.draft_attn_layer_names is not None:
            attn_metadata = {
                name: metadata for name, metadata in attn_metadata.items() if name in self.draft_attn_layer_names
            }

        super()._prefill(
            num_reqs,
            num_tokens,
            attn_metadata,
            slot_mappings,
            num_tokens_across_dp,
            cudagraph_runtime_mode,
            mm_inputs,
        )

    def _build_draft_attn_metadata(  # type: ignore[misc]
        self,
        num_reqs: int,
        num_reqs_padded: int,
        num_tokens_padded: int,
        seq_lens_cpu_upper_bound: torch.Tensor,
        step: int,
        num_query_per_req: int = 1,
        causal: bool = True,
        query_start_loc_np: np.ndarray | None = None,
    ) -> dict[str, Any] | None:
        assert self.input_batch is not None
        if self._eagle3_window_is_active():
            if num_query_per_req != 1:
                raise ValueError("Eagle3 autoregressive Window steps require one query per request")
            if query_start_loc_np is not None:
                raise ValueError("Eagle3 autoregressive decode requires the uniform one-query layout")
            if causal is not True:
                raise ValueError("Eagle3 Draft Window requires causal Draft attention")
            target_metadata = self._require_eagle3_target_metadata()
            inputs = self._materialize_eagle3_decode_step(
                step=step,
                num_reqs=num_reqs,
                num_reqs_padded=num_reqs_padded,
                seq_lens_cpu_upper_bound=seq_lens_cpu_upper_bound,
            )
            try:
                return self._build_eagle3_private_attn_metadata(
                    inputs=inputs,
                    num_reqs=num_reqs,
                    num_reqs_padded=num_reqs_padded,
                    num_tokens_padded=num_tokens_padded,
                    query_start_loc_np=None,
                    target_metadata=target_metadata,
                    first_pass=False,
                )
            except BaseException:
                if self._eagle3_window_live_inputs is inputs:
                    self._finish_eagle3_window_step(inputs, succeeded=False)
                raise
        with build_draft_attn_metadata_factory(
            self.input_buffers.positions,
            num_tokens_padded,
            torch.from_numpy(self.input_batch.is_prefilling_np),
        ):
            attn_metadata = super()._build_draft_attn_metadata(
                num_reqs,
                num_reqs_padded,
                num_tokens_padded,
                seq_lens_cpu_upper_bound,
                step,
                num_query_per_req,
                causal,
                query_start_loc_np=query_start_loc_np,
            )
        if attn_metadata is not None:
            # Ascend-specific: force DecodeOnly attention state for the draft model.
            for metadata in attn_metadata.values():
                if metadata is None:
                    continue
                metadata.attn_state = AscendAttentionState.DecodeOnly
        return attn_metadata

    def _build_eagle3_private_attn_metadata(
        self,
        *,
        inputs: DraftMetadataInputs,
        num_reqs: int,
        num_reqs_padded: int,
        num_tokens_padded: int,
        query_start_loc_np: np.ndarray | None,
        target_metadata: Mapping[Any, Any],
        first_pass: bool,
        read_inputs_override: AscendDraftAttentionReadInputs | None = None,
        publish: bool = True,
    ) -> dict[str, Any]:
        """Build one Draft-only metadata object from validated read inputs.

        This is the narrow Ascend-owned assembly seam required by R-REPO-01.
        It duplicates only upstream query-layout/builder kwargs; proposal,
        positions, slot calculation, forward, and sampling stay upstream.
        """
        if read_inputs_override is None:
            read_inputs = self._validated_eagle3_read_inputs(inputs, inputs.identity)
        else:
            inputs.validate_for(inputs.identity)
            read_inputs = read_inputs_override
        if query_start_loc_np is not None:
            query_start_loc_cpu = torch.empty(num_reqs_padded + 1, dtype=torch.int32)
            query_start_loc_cpu[: num_reqs + 1] = torch.from_numpy(query_start_loc_np[: num_reqs + 1])
            query_start_loc_cpu[num_reqs:] = query_start_loc_cpu[num_reqs]
            query_lengths = query_start_loc_cpu[1:] - query_start_loc_cpu[:-1]
            max_query_len = int(query_lengths.max().item()) if query_lengths.numel() else 0
        else:
            query_start_loc_cpu = torch.clamp(self.arange[: num_reqs_padded + 1], max=num_reqs)
            max_query_len = 1

        if len(read_inputs.block_tables) != len(self.block_tables.input_block_tables):
            raise ValueError("Eagle3 Window read tables do not match configured cache groups")
        if read_inputs.seq_lens.shape[0] != num_reqs_padded:
            raise ValueError("Eagle3 Window read lengths do not match padded requests")
        if self.block_tables.cp_size != 1:
            raise NotImplementedError("MRV2 Eagle3 Draft Window does not support DCP")
        if self.model_state.attn_metadata is not target_metadata:
            raise RuntimeError("Target metadata owner changed before Eagle3 Draft metadata build")

        builder_kwargs = dict(
            attn_groups=self.attn_groups,
            num_reqs=num_reqs_padded,
            num_tokens=num_tokens_padded,
            query_start_loc_gpu=self.input_buffers.query_start_loc[: num_reqs_padded + 1],
            query_start_loc_cpu=query_start_loc_cpu,
            max_query_len=max_query_len,
            seq_lens=read_inputs.seq_lens,
            seq_lens_cpu=read_inputs.seq_lens_cpu_exact,
            dcp_local_seq_lens=None,
            max_seq_len=read_inputs.max_seq_len,
            block_tables=list(read_inputs.block_tables),
            # The write carrier is always the canonical full slot owner.
            slot_mappings=self.block_tables.slot_mappings[:, :num_tokens_padded],
            kv_cache_config=self.kv_cache_config,
            causal=True,
            seq_lens_cpu_upper_bound=read_inputs.seq_lens_cpu_upper_bound,
        )
        input_batch = self.input_batch
        assert input_batch is not None
        is_prefilling = torch.from_numpy(input_batch.is_prefilling_np)
        with build_draft_attn_metadata_factory(
            self.input_buffers.positions,
            num_tokens_padded,
            is_prefilling,
        ):
            metadata = self._call_eagle3_draft_attn_metadata_builder(**builder_kwargs)
        if not isinstance(metadata, dict) or not metadata:
            raise RuntimeError("eligible Eagle3 Window route produced no Draft metadata")
        if self.model_state.attn_metadata is not target_metadata:
            raise RuntimeError("Target metadata owner changed during Eagle3 Draft metadata build")

        # Isolate before assigning per-layer state: a buggy/reusing builder
        # must not let the state write below mutate a Target-owned object.
        metadata = _isolate_draft_metadata_from_target(metadata, target_metadata)
        for layer_name, layer_metadata in metadata.items():
            if layer_metadata is None:
                continue
            if first_pass:
                target_layer_metadata = target_metadata.get(layer_name)
                if target_layer_metadata is None or not hasattr(target_layer_metadata, "attn_state"):
                    raise RuntimeError(f"Target metadata has no first-pass state for Draft layer {layer_name!r}")
                layer_metadata.attn_state = target_layer_metadata.attn_state
            else:
                layer_metadata.attn_state = AscendAttentionState.DecodeOnly

        if not publish:
            return metadata
        self._draft_window_runtime_state.publish_metadata(
            inputs,
            metadata,
            target_metadata=target_metadata,
        )
        return self._draft_window_runtime_state.read_metadata(inputs.identity)

    def _build_eagle3_graph_metadata(self, *, read: Any, **kwargs: Any) -> dict[str, Any]:
        gid = kwargs["inputs"].identity.global_group_id
        upper = read.cpu_window_upper[:read.actual_request_count]
        view = AscendDraftAttentionReadInputs(
            block_tables=tuple(
                read.window_block_table if i == gid else table[:read.padded_request_count]
                for i, table in enumerate(self.block_tables.input_block_tables)
            ),
            seq_lens=read.device_window_exact,
            seq_lens_cpu_exact=read.cpu_window_exact,
            seq_lens_cpu_upper_bound=read.cpu_window_upper,
            max_seq_len=int(upper.max().item()) if upper.numel() else 0,
        )
        metadata = self._build_eagle3_private_attn_metadata(**kwargs, read_inputs_override=view, publish=False)
        # The normal nonparallel FIA builder deliberately prefers its CPU
        # seq_lens. FULL Graph capture owns a separate device operand. Bind
        # both exact owners explicitly here, leaving eager assembly unchanged.
        for layer in metadata.values():
            if layer is not None:
                layer.seq_lens = read.device_window_exact
                layer.seq_lens_cpu = read.cpu_window_exact
                layer.seq_lens_list = read.cpu_window_exact.tolist()
        return metadata

    def _call_eagle3_draft_attn_metadata_builder(self, **builder_kwargs: Any) -> dict[str, Any]:
        """Call the existing Ascend-patched builder with explicit read state."""
        return upstream_speculator_module.build_attn_metadata(**builder_kwargs)

    def _require_eagle3_target_metadata(
        self,
        passed_metadata: dict[str, Any] | None = None,
    ) -> Mapping[Any, Any]:
        target_metadata = self.model_state.attn_metadata
        if not isinstance(target_metadata, Mapping) or not target_metadata:
            raise ValueError("Window ON requires non-empty Target metadata from model_state.attn_metadata")
        if passed_metadata is not None and passed_metadata is not target_metadata:
            raise RuntimeError("Eagle3 first pass did not receive the real Target metadata owner")
        return target_metadata

    def build_draft_attn_metadatas(
        self,
        num_reqs_padded: int,
        num_tokens_padded: int,
        is_draft_model_prefill: bool,
    ):
        """Build draft_attn_metadatas for partial-merged draft graph."""
        route = (
            DraftWindowGraphRoute.EAGLE3_FIRST_PASS if is_draft_model_prefill else DraftWindowGraphRoute.EAGLE3_AR_STEP
        )
        expected_consumer_count = 1 if is_draft_model_prefill else len(self.input_buffers.draft_seq_lens_cpus)
        graph_metadata = consume_draft_window_graph_metadata(
            self,
            route=route,
            expected_consumer_count=expected_consumer_count,
        )
        if graph_metadata is not None:
            return list(graph_metadata)
        attn_metadata = self.model_state.attn_metadata
        attn_metadata = {
            name: metadata for name, metadata in attn_metadata.items() if name in self.draft_attn_layer_names
        }

        if is_draft_model_prefill:
            prepared_attn_metadata, _ = self._prepare_replicated_prefill_attn(
                attn_metadata,
                None,
                num_reqs_padded,
                num_tokens_padded,
                cudagraph_runtime_mode=CUDAGraphMode.FULL,
            )
            assert prepared_attn_metadata is not None
            return [prepared_attn_metadata]

        draft_attn_metadatas = self._init_decode_draft_attn_metadatas(attn_metadata, num_reqs_padded)

        for i, per_step_attn_metadata in enumerate(draft_attn_metadatas):
            step = i + 1
            assert self.input_batch is not None
            self._update_decode_attn_metadata(per_step_attn_metadata, step, self.input_batch.num_reqs)

        return draft_attn_metadatas

    def _init_decode_draft_attn_metadatas(self, attn_metadata: dict[str, Any] | None, num_reqs_padded: int):
        """Initialize per-step decode attention metadata for graph mode."""
        if attn_metadata is None:
            return

        # DSA and SFA own their per-step sparse-attention state in their
        # metadata builders and do not use draft graph metadata updates.
        if self.attn_architecture in ("DSA", "SFA"):
            return []

        # TODO: _build_draft_attn_metadata pulls data (seq_lens, block_table,
        # ...) from input_buffers internally; future may pass these as CPU
        # params directly to build_attn_metadata, decoupling from input_buffers.
        # Target metadata can contain fewer block-table rows than the draft
        # decode graph requires. Rebuild GQA metadata too, so its block tables
        # and query layout describe the same padded batch as the sequence lengths.
        if self.attn_architecture in ("GQA", "MLA"):
            assert self.input_batch is not None
            attn_metadata = self._build_draft_attn_metadata(  # type: ignore[call-arg]
                num_reqs=self.input_batch.num_reqs,
                num_reqs_padded=num_reqs_padded,
                num_tokens_padded=num_reqs_padded,  # decode: 1 token/req
                seq_lens_cpu_upper_bound=self.input_batch.seq_lens_cpu_upper_bound,
                step=1,
            )
            if attn_metadata is None:
                return

        attn_state = AscendAttentionState.DecodeOnly

        draft_attn_metadatas = []
        # attn_metadata is build in vllm's super class.
        # We need to update attn_state for each layer's metadata.
        for seq_lens_cpu in self.input_buffers.draft_seq_lens_cpus:
            per_step_attn_metadata = {k: copy(v) for k, v in attn_metadata.items()}

            seq_lens_cpu = seq_lens_cpu[:num_reqs_padded]
            for metadata in per_step_attn_metadata.values():
                metadata.attn_state = attn_state
                metadata.seq_lens_cpu = seq_lens_cpu
                if self.attn_architecture == "MLA":
                    # clone .decode so per-step seq_lens_list writes don't alias.
                    metadata.decode = copy(metadata.decode)
            draft_attn_metadatas.append(per_step_attn_metadata)

        return draft_attn_metadatas

    def _update_decode_attn_metadata(
        self, attn_metadata: dict[str, Any] | None, step: int, num_reqs: int | None = None
    ):
        """Update per-step decode attention metadata on Ascend."""
        if attn_metadata is None:
            return

        if self.attn_architecture in ("DSA", "SFA"):
            return

        attn_meta = next(iter(attn_metadata.values()))
        num_reqs_padded = attn_meta.seq_lens_cpu.shape[0]
        seq_lens_cpu = self._get_seq_lens_cpu(num_reqs_padded)
        if num_reqs is None:
            num_reqs = num_reqs_padded
        next_seq_lens_cpu = self._calc_next_seq_lens_cpu(seq_lens_cpu, num_reqs, num_reqs_padded, step)

        query_lens_list = [i for i in range(1, num_reqs_padded + 1)]
        seq_lens_list = next_seq_lens_cpu.tolist()
        for metadata in attn_metadata.values():
            if self.attn_architecture == "MLA":
                decode_metadata = metadata.decode
            else:
                decode_metadata = metadata
            decode_metadata.seq_lens_list = seq_lens_list
            decode_metadata.actual_seq_lengths_q = query_lens_list
            metadata.seq_lens_cpu.copy_(next_seq_lens_cpu)

    def _calc_next_seq_lens_cpu(self, seq_lens_cpu, num_reqs, num_reqs_padded, step):
        # NOTE(drslark) to achieve fully alignment with vllm, `num_rejected` should be subtracted from `seq_lens`
        # to avoid extra sync overhead, `v2` is currently aligned with NPU `v1` only

        # follows the logic in `prepare_eagle_decode` and `update_eagle_inputs`
        next_seqs_cpu = torch.clamp(seq_lens_cpu[:num_reqs_padded] + step, max=self.max_model_len)
        next_seqs_cpu[num_reqs:].fill_(0)
        return next_seqs_cpu

    def _get_seq_lens_cpu(self, num_reqs_padded: int) -> torch.Tensor:
        """Return the target sequence lengths for the padded graph batch.

        ``input_batch.seq_lens_np`` can contain only the active requests.
        During full-graph capture the draft batch can be padded to a larger
        graph batch, so using that compact view produces a tensor that is too
        short for ``num_reqs_padded``. The target input buffer owns the same
        sequence lengths and retains the storage required by the padded graph
        batch.
        """
        assert isinstance(self.target_input_buffers, AscendInputBuffers)
        return self.target_input_buffers.seq_lens_cpu[:num_reqs_padded]


# TODO Remove this patch when cann fix the gather bug.
# NOTE(Ronald1995): torch.gather will pollute the cache such as self.input_buffers.positions
# the bug is reported to huawei CANN team, but not fixed yet.
# NOTE(drslark): make a temporary patch only for `torch.gather`
_original_gather = torch.gather


def gather(input, dim, index, *, sparse_grad=False, out=None):
    if out is None:
        return _original_gather(input, dim, index, sparse_grad=sparse_grad)
    out[:] = _original_gather(input, dim, index, sparse_grad=sparse_grad)
    return out


@contextmanager
def torch_gather_wrapper():
    """Context manager to override torch.gather for Ascend NPUs."""
    original_gather = torch.gather
    try:
        torch.gather = gather
        yield
    finally:
        torch.gather = original_gather
