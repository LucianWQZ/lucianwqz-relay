# SPDX-License-Identifier: Apache-2.0
"""Default-off Eagle3 captured device copies for independent numerical replay.

These extra D2D/index-select operators change the captured diagnostic program.
They are not a normal-overlap, native operand or physical-read observation.
No Host/device copy, synchronization, event query or I/O occurs in callbacks.
The external disposable producer updates indices before replay, drains after
UPDATE, and runs the independent eager reference. Normal Graph has no copies.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import torch


@dataclass(slots=True)
class Eagle3CapturedState:
    indices: torch.Tensor
    before: dict[str, Any] | None = None
    after: dict[str, torch.Tensor] | None = None
    # Captured clone/index_select nodes retain raw source addresses, not Python
    # ownership. Keep exact sources alive for this captured program's lifetime.
    capture_sources: tuple[torch.Tensor, ...] = ()


class Eagle3CaptureSnapshots:

    def __init__(self, owner: Any, captures: Mapping, *, max_device_bytes: int = 2 << 30) -> None:
        self.owner = owner
        if getattr(owner.attn_backend, "forward_includes_kv_cache_update", None) is not True:
            raise RuntimeError("Eagle3 numeric requires metadata-owned Ascend KV writes")
        context = owner.draft_vllm_config.compilation_config.static_forward_context
        layers = sorted(owner.draft_attn_layer_names)
        if not layers or any(name not in context for name in layers):
            raise RuntimeError("Eagle3 numeric capture has no complete Draft layer inventory")
        self.caches = {f"{name}/{i}": tensor for name in layers for i, tensor in enumerate(context[name].kv_cache)}
        if not self.caches or any(not isinstance(t, torch.Tensor) or t.ndim < 2 for t in self.caches.values()):
            raise RuntimeError("Eagle3 numeric capture requires initialized real Draft KV tensors")
        self.layers = tuple(layers)
        self.states = {}
        groups = {identity.fingerprint.global_group_id for identity in captures.values()}
        if len(groups) != 1:
            raise RuntimeError("Eagle3 numeric profile requires one actual global cache group")
        self.global_group_id = next(iter(groups))
        width = owner.block_tables.input_block_tables[self.global_group_id].shape[1]
        per_block = sum(t[0].numel() * t.element_size() for t in self.caches.values())
        needed = sum(
            (identity.fingerprint.padded_request_count * width + 1) * per_block * 2 for identity in captures.values())
        if needed > max_device_bytes:
            raise ValueError("BLOCKED_RESOURCE: Eagle3 capture copies exceed declared 2 GiB device budget")
        self.hbm_free_before_capture = None
        if owner.device.type in ("npu", "privateuseone"):
            self.hbm_free_before_capture = torch.npu.mem_get_info(owner.device)[0]
            if self.hbm_free_before_capture < needed + (2 << 30):
                raise ValueError("BLOCKED_RESOURCE: insufficient HBM for diagnostic copies and 2 GiB margin")
        self.device_bytes_bound = needed
        for identity in captures.values():
            n = identity.fingerprint.padded_request_count
            self.states[identity] = Eagle3CapturedState(
                indices=torch.zeros(n * width + 1, dtype=torch.int64, device=owner.device))

    def before_model(self, identity: Any, metadata: Mapping, slots: Mapping) -> None:
        if identity is None:
            return
        owner, state = self.owner, self.states[identity]
        fp = identity.fingerprint
        n, tokens = fp.padded_request_count, fp.padded_token_count
        if not isinstance(slots, Mapping) or not set(self.layers) <= set(slots):
            raise RuntimeError("Eagle3 captured numeric input is missing actual full slot operands")
        if not set(self.layers) <= set(metadata):
            raise RuntimeError("Eagle3 captured numeric input is missing actual layer metadata")
        # In particular builder.query_start_loc may be an otherwise unused,
        # freshly allocated GPU auxiliary tensor. Keeping only clone outputs
        # lets its allocation be reused before the diagnostic Graph replays.
        # These are references only: no new copy/sync/query and no normal-path
        # installation. Owners are bounded by the frozen capture inventory.
        sources = [
            owner.input_buffers.input_ids, owner.input_buffers.positions,
            owner.hidden_states, owner.input_buffers.seq_lens,
            owner.input_buffers.query_start_loc, owner.target_input_buffers.positions,
            owner.last_token_indices, owner.block_tables.input_block_tables[fp.global_group_id],
            state.indices, *self.caches.values(),
        ]
        for name in self.layers:
            layer = metadata[name]
            sources.extend((layer.slot_mapping, layer.block_tables, layer.seq_lens,
                            layer.query_start_loc, slots[name]))
        if any(not isinstance(tensor, torch.Tensor) for tensor in sources):
            raise RuntimeError("captured numeric copy source must be an owned tensor")
        state.capture_sources = tuple(sources)
        state.before = dict(
            inputs={
                "input_ids": owner.input_buffers.input_ids[:tokens].clone(),
                "positions": owner.input_buffers.positions[:tokens].clone(),
                "hidden_states": owner.hidden_states[:tokens].clone(),
                "full_exact": owner.input_buffers.seq_lens[:n].clone(),
                "query_start_loc": owner.input_buffers.query_start_loc[:n + 1].clone(),
                # First-pass keeps the Target Full write grid, while upstream
                # only refreshes the accepted Draft input prefix. Rejected
                # tail positions may retain old values and are not a new
                # source for recomputing the Full write slots.
                "target_positions": owner.target_input_buffers.positions[:tokens].clone(),
                "last_token_indices": owner.last_token_indices[:n].clone(),
            },
            canonical_table=owner.block_tables.input_block_tables[fp.global_group_id][:n].clone(),
            # This backend writes KV through metadata.slot_mapping. The
            # ForwardContext argument is retained separately, not mislabeled.
            actual_slots={name: metadata[name].slot_mapping[:tokens].clone()
                          for name in self.layers},
            forward_context_slots={name: slots[name][:tokens].clone()
                                   for name in self.layers},
            bank_tables={name: metadata[name].block_tables.clone()
                         for name in self.layers},
            bank_device_exact={name: metadata[name].seq_lens.clone()
                               for name in self.layers},
            metadata_query={name: metadata[name].query_start_loc.clone()
                            for name in self.layers},
            kv={
                key: tensor.index_select(0, state.indices)
                for key, tensor in self.caches.items()
            },
        )

    def after_model(self, identity: Any) -> None:
        if identity is not None:
            state = self.states[identity]
            state.after = {key: tensor.index_select(0, state.indices) for key, tensor in self.caches.items()}

    def set_indices_before_replay(self, identities: tuple, selected: list[int]) -> None:
        """External diagnostic only, never invoked from a capture callback."""
        if not selected or selected != sorted(set(selected)) or selected[0] < 0:
            raise ValueError("Eagle3 numeric selection must be a sorted unique physical block set")
        if any(selected[-1] >= tensor.shape[0] for tensor in self.caches.values()):
            raise ValueError("Eagle3 numeric selection exceeds actual Draft KV capacity")
        for identity in identities:
            indices = self.states[identity].indices
            if len(selected) > indices.numel():
                raise ValueError("Eagle3 numeric selection exceeds declared capture capacity")
            values = torch.zeros(indices.numel(), dtype=torch.int64)
            values[:len(selected)] = torch.tensor(selected, dtype=torch.int64)
            indices.copy_(values)
