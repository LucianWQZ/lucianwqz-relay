#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Explicit single-build variant; existing normal and numeric cases stay intact."""
import copy
import hashlib
import json


def add_cases(cases, inputs):
    path = inputs / "single-metadata-experiment.json"
    if not path.exists():
        return []
    document = json.loads(path.read_text())
    if (document != dict(schema="r5-single-metadata-v1", enabled=True, workloads=["short", "long"], repetitions=3)
            or document.get("enabled") is not True or type(document.get("repetitions")) is not int):
        raise ValueError("single-metadata experiment requires its exact declared finite profile")
    checksum = hashlib.sha256(path.read_bytes()).hexdigest()
    variants = []
    sentinel = "NUMERIC_SINGLE_META_SENTINEL"

    def clone(source, name):
        if source not in cases or name in cases:
            raise ValueError("single-metadata source missing or output case already exists: " + source)

        def rewrite(value):
            if isinstance(value, str):
                return value.replace(source, name)
            if isinstance(value, list):
                return [rewrite(v) for v in value]
            if isinstance(value, dict):
                return {k: rewrite(v) for k, v in value.items()}
            return value

        case = rewrite(copy.deepcopy(cases[source]))
        case["argv"].append("--repair14-single-metadata")
        case["launch_argv"].append("--repair14-single-metadata")
        case.update(single_metadata_experiment=True,
                    single_metadata_profile_sha256=checksum,
                    single_metadata_profile_path=str(path))
        cases[name] = case
        variants.append(name)
        return case

    clone("NUMERIC_SENTINEL", sentinel)
    for workload in document["workloads"]:
        for repeat in range(1, 4):
            case = clone(f"PERF10_G_ON_{workload}_{repeat:02}", f"PERF14_SINGLE_{workload}_{repeat:02}")
            case["dependencies"] = list(dict.fromkeys([*case["dependencies"], sentinel]))
        case = clone(f"PROFILE10_G_ON_{workload}", f"PROFILE14_SINGLE_{workload}")
        case["dependencies"] = list(dict.fromkeys([*case["dependencies"], sentinel]))
    return variants
