# SPDX-License-Identifier: Apache-2.0
"""Explicit finite 16K performance extension; old workload contracts unchanged."""
import copy
import hashlib
import json
from pathlib import Path

from tools.p7x_graph_repair6_storage import require

MAX_MODEL_LEN = 24576
PROMPT_TOKENS = 16385
OUTPUT_TOKENS = 512


def validate_model_capacity(args):
    require(args.repair10_max_model_len == MAX_MODEL_LEN, "exact long-context max-model-len profile")
    for model in (args.target_model, args.draft_model):
        config = json.loads((Path(model) / "config.json").read_text())
        require(
            type(config.get("max_position_embeddings")) is int and config["max_position_embeddings"] >= MAX_MODEL_LEN
            and config.get("rope_scaling") is None,
            "long context requires native model position capacity, without RoPE changes")


def add_cases(cases, inputs):
    marker = inputs / "long-context-experiment.json"
    if not marker.exists():
        return []
    declaration = json.loads(marker.read_text())
    require(
        declaration == dict(schema="r5-long16-v1",
                            max_model_len=MAX_MODEL_LEN,
                            prompt_tokens=PROMPT_TOKENS,
                            output_tokens=OUTPUT_TOKENS,
                            repetitions=3), "exact finite long-context declaration")
    require(
        all(type(declaration[k]) is int for k in ("max_model_len", "prompt_tokens", "output_tokens", "repetitions")),
        "typed long profile")
    request = inputs / "requests/performance18-long16.json"
    entries = json.loads(request.read_text())
    require(
        len(entries) == 1 and entries[0]["max_tokens"] == OUTPUT_TOKENS and len(entries[0]["prompts"]) == 1,
        "one declared long-context request group")
    tokens = entries[0]["prompts"][0]["prompt_token_ids"]
    require(
        len(tokens) == PROMPT_TOKENS and all(type(t) is int and t >= 0 for t in tokens), "exact long input token ids")
    checksum = hashlib.sha256(request.read_bytes()).hexdigest()
    names = []
    for arm in ("G_OFF", "G_ON", "E_ON"):
        for repeat in range(1, 5):
            source = f"PERF10_{arm}_long_{repeat:02}" if repeat < 4 else f"PROFILE10_{arm}_long"
            name = f"PERF18_{arm}_long16_{repeat:02}" if repeat < 4 else f"PROFILE18_{arm}_long16"
            original = cases[source]

            def rewrite(value):
                if isinstance(value, str):
                    return value.replace(source, name).replace(original["request_path"], str(request))
                if isinstance(value, list): return [rewrite(x) for x in value]
                if isinstance(value, dict): return {k: rewrite(v) for k, v in value.items()}
                return value

            case = rewrite(copy.deepcopy(original))
            for field in ("argv", "launch_argv"):
                argv = case[field]
                argv[argv.index("--repair10-max-model-len") + 1] = str(MAX_MODEL_LEN)
                argv.append("--repair18-long-context")
            case.update(request_path=str(request),
                        requests_sha256=checksum,
                        long_context_profile=declaration,
                        selection="OPT_IN_FINITE_NATIVE_POSITION_LONG16_PROFILE")
            cases[name] = case
            names.append(name)
    return names
