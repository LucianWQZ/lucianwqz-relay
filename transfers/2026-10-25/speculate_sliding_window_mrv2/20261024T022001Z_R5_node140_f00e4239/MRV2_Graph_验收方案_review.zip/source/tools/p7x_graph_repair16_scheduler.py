# SPDX-License-Identifier: Apache-2.0
"""CPU-only observations of actual scheduler rows, never synthetic phases.

This separate bounded request arm uses chunked prefill. It observes existing
proposal calls and Graph manager submissions without a device copy or drain.
It does not measure normal performance or certify Target KV / physical reads.
"""
from __future__ import annotations

import copy
import time
from types import MethodType

from tools.p7x_graph_repair6_storage import require


def configure(config):
    result = copy.deepcopy(config)
    result.update(enable_chunked_prefill=True, max_num_batched_tokens=256)
    require(result["max_num_seqs"] == 4 and result["max_model_len"] == 8192, "declared bounded scheduler profile")
    return result


def phase_from_rows(row):
    """Independent verifier: derive phases from retained CPU counters."""
    n = len(row["request_ids"])
    require(n > 0 and len(set(row["request_ids"])) == n, "unique nonempty active request set")
    require(all(len(row[k]) == n for k in ("computed", "scheduled", "prefill", "is_prefilling")),
            "complete CPU row arrays")
    phases = []
    for c, s, p, prefill in zip(row["computed"], row["scheduled"], row["prefill"], row["is_prefilling"]):
        require(all(type(x) is int and x >= 0 for x in (c, s, p)), "typed CPU scheduler counters")
        require(type(prefill) is bool and prefill == (c < p), "prefill state mismatch")
        phases.append("pure_decode" if c >= p else "prefill_continuing" if c + s < p else "prefill_terminal")
    unique = set(phases)
    batch = ("pure_decode" if unique == {"pure_decode"} else "pure_prefill_continuing" if unique
             == {"prefill_continuing"} else "pure_prefill_terminal" if unique == {"prefill_terminal"} else "mixed")
    return phases, batch


class SchedulerRows:

    def __init__(self, owner):
        self.owner, self.saved, self.rows = owner, [], []
        self.current = None
        self.group = None

    def wrap(self, owner, name, function):
        original = getattr(owner, name)
        self.saved.append((owner, name, name in vars(owner), vars(owner).get(name)))
        setattr(owner, name, MethodType(function(original), owner))

    def __enter__(self):
        observer = self

        def proposal(original):

            def call(_self, input_batch, *args, **kwargs):
                require(observer.current is None, "nested scheduler proposal")
                n = int(input_batch.num_reqs)
                # These are pinned InputBatch CPU numpy arrays, never tensors.
                row = dict(group=observer.group,
                           start_ns=time.monotonic_ns(),
                           request_ids=list(input_batch.req_ids[:n]),
                           computed=input_batch.num_computed_prefill_tokens_np[:n].tolist(),
                           scheduled=input_batch.num_scheduled_tokens[:n].tolist(),
                           prefill=input_batch.prefill_len_np[:n].tolist(),
                           is_prefilling=input_batch.is_prefilling_np[:n].tolist(),
                           graphs=[])
                row["row_phases"], row["batch_phase"] = phase_from_rows(row)
                observer.current = row
                try:
                    return original(input_batch, *args, **kwargs)
                except BaseException as error:
                    row["exception"] = dict(type=type(error).__name__, message=str(error))
                    raise
                finally:
                    row["end_ns"] = time.monotonic_ns()
                    row["flags_after"] = {
                        k: bool(getattr(observer.owner, k, False))
                        for k in ("_draft_window_bypass_active", "_draft_window_prefill_bypass_active",
                                  "_eagle3_window_bypass_active", "_eagle3_window_continuing_prefill")
                    }
                    observer.rows.append(row)
                    observer.current = None

            return call

        self.wrap(self.owner, "propose", proposal)
        for route, manager in (("first_pass", self.owner.prefill_cudagraph_manager),
                               ("AR", self.owner.decode_cudagraph_manager)):

            def graph(original, route=route):

                def call(_self, desc):
                    if observer.current is not None:
                        observer.current["graphs"].append(
                            dict(route=route, descriptor=[desc.num_reqs, desc.num_tokens],
                                 start_ns=time.monotonic_ns()))
                    return original(desc)

                return call

            self.wrap(manager, "run_fullgraph", graph)
        return self

    def __exit__(self, *_):
        for owner, name, existed, value in reversed(self.saved):
            if existed:
                setattr(owner, name, value)
            else:
                delattr(owner, name)
        self.saved.clear()


def check_rows(rows, arm, launcher):
    require(rows, "no actual scheduler proposal observations")
    phases, groups = set(), set()
    for row in rows:
        actual_rows, actual_batch = phase_from_rows(row)
        require(row["row_phases"] == actual_rows and row["batch_phase"] == actual_batch, "phase relabeling")
        require(launcher["host_start_ns"] <= row["start_ns"] < row["end_ns"] <= launcher["host_end_ns"],
                "proposal outside actual process interval")
        require(not row.get("exception") and not any(row["flags_after"].values()), "exception or leaked bypass flags")
        if arm == "E_ON":
            require(not row["graphs"], "Draft eager arm unexpectedly submitted Graph")
        if arm == "G_ON" and actual_batch == "pure_prefill_continuing":
            require(not row["graphs"], "continuing prefill did not keep full-read eager baseline")
        for graph in row["graphs"]:
            require(row["start_ns"] <= graph["start_ns"] < row["end_ns"], "Graph manager call outside proposal")
        phases.update(actual_rows)
        phases.add(actual_batch)
        groups.add(row["group"])
    require({"pure_decode", "prefill_continuing", "prefill_terminal", "mixed"} <= phases,
            "actual scheduler did not cover all declared phases")
    require(len(groups) == 3 and None not in groups, "all bounded request groups")
    if arm != "E_ON":
        require(any(r["graphs"] and r["batch_phase"] == "pure_decode" for r in rows),
                "no actual decode Graph manager submissions after prefill")
    return dict(status="PASS_SCOPED_ACTUAL_SCHEDULER_PHASES",
                phases=sorted(phases),
                proposals=len(rows),
                groups=sorted(groups),
                boundary="CPU_PROPOSAL_AND_MANAGER_CALLS_NOT_DEVICE_COMPLETION",
                target_kv="NOT_ASSESSED",
                normal_overlap="UNPROVEN",
                performance="NOT_A_PERFORMANCE_ARM")
