# SPDX-License-Identifier: Apache-2.0
"""Disposable Eagle3 per-consumer reference; captured D2D + serial diagnostics.

The reference starts from each actual captured input/KV pre-state and independently
projects canonical Full rows using frozen L0+K. It calls pinned _run_model with
NONE, never a Graph output as an oracle, and restores only completed Draft state.
Target metadata/KV and the production speculator/input owners are never swapped.
This scope does not prove normal overlap, ABA, full Target or physical read-set.
"""
from __future__ import annotations

import copy
import time
from types import MethodType, SimpleNamespace

import torch

from tools.p7x_graph_repair6_storage import CollectionWriter, atomic_json, require, require_space
from tools.p7x_graph_repair6_submission import NumericMismatch, SubmissionState


def canonical_window(full, l0, ends, valid, active, padded, width, *, k=3, window=1024, block=128):
    require(full.dtype == torch.int32 and full.ndim == 2 and full.shape[0] == padded, "canonical Full geometry/dtype")
    require(len(l0) == len(ends) == len(valid) == active <= padded, "Eagle3 exact/active geometry")
    table = torch.zeros((padded, width), dtype=torch.int32)
    lengths, rows = [], []
    for r, (anchor, end, count) in enumerate(zip(l0, ends, valid)):
        require(all(type(v) is int for v in (anchor, end, count)), "typed canonical lengths/counts")
        start = max(anchor + k - window, 0) // block * block
        stop = (end + block - 1) // block
        first = start // block
        require(0 <= start <= end and 0 <= first < stop <= count <= full.shape[1], "Eagle3 canonical source shortage")
        require(stop - first <= width and len(set(full[r, :count].tolist())) == count, "canonical block geometry")
        table[r, :stop - first] = full[r, first:stop]
        lengths.append(end - start)
        rows.append(dict(L0=anchor, H=anchor + k, S=start, E=end, V=end - start, columns=[first, stop]))
    return table, lengths + [0] * (padded - active), rows


def canonical_slots(full, positions, query, active, tokens, *, block=128, dtype=torch.int64):
    require(positions.dtype == torch.int64 and query.dtype == torch.int32, "absolute positions/query dtype")
    require(query.ndim == 1 and int(query[0]) == 0 and len(query) >= active + 1, "canonical query layout")
    result = torch.full((tokens, ), -1, dtype=dtype)
    for r in range(active):
        begin, end = int(query[r]), int(query[r + 1])
        require(0 <= begin <= end <= tokens, "full query interval")
        for i in range(begin, end):
            pos = int(positions[i])
            require(0 <= pos // block < full.shape[1], "absolute write outside Full table")
            result[i] = int(full[r, pos // block]) * block + pos % block
    return result


class EagleContinuousReference:

    def __init__(self, runner, scheduler, output, identity, entries):
        require(not scheduler.requests and not scheduler.running and not scheduler.waiting, "exclusive idle engine")
        self.runner, self.owner = runner, runner.speculator
        from vllm_ascend.attention.attention_v1 import AscendAttentionBackend
        require(self.owner.attn_backend is AscendAttentionBackend,
                "this independent numeric profile requires the exact installed dense Ascend backend")
        self.session = self.owner._eagle3_graph_session
        self.snapshots = self.session.numeric_snapshots
        require(self.snapshots is not None and self.owner.num_speculative_steps == 3, "actual K3 numeric capture")
        require(len(self.snapshots.layers) == 1, "this numeric profile is the frozen single-layer Eagle3 fixture")
        self.identity, self.output = dict(identity), output
        self.groups = {e["label"]: len(e["prompts"]) for e in entries}
        require(len(self.groups) == 3 and sorted(self.groups.values()) == [1, 3, 4], "declared 1/3/4 request groups")
        self.group = None
        self.completed = set()
        self.pending_epoch = None
        self.failed = self.poisoned = False
        self.submission = SubmissionState()
        self.records, self.saved = [], []

    def __enter__(self):
        require_space(self.output.parent, 4 << 30)
        require(
            not self.session.controller.quarantined
            and self.owner._draft_window_runtime_state.quarantined_identity is None,
            "numeric fixture cannot initialize quarantined state")

        # A fresh, idle disposable fixture owns no logical request. Initialize
        # ONLY Draft cache bytes, making unused tail bytes deterministic/finite.
        # Require disjoint actual address intervals from every Target cache.
        def interval(t):
            require(all(s >= 0 for s in t.stride()), "unsupported negative KV stride")
            return (t.data_ptr(), t.data_ptr() + (1 + sum(
                (n - 1) * v for n, v in zip(t.shape, t.stride()))) * t.element_size())

        draft_ranges = [interval(t) for t in self.snapshots.caches.values()]
        target_ranges = []
        for name, layer in self.runner.compilation_config.static_forward_context.items():
            if name in self.snapshots.layers:
                continue
            for t in getattr(layer, "kv_cache", ()):
                if isinstance(t, torch.Tensor) and t.numel():
                    target_ranges.append(interval(t))
        require(target_ranges and all(not (a < d and c < b) for a, b in draft_ranges for c, d in target_ranges),
                "Draft-only initialization aliases Target KV storage")
        self.submission.submit("IDLE_FIXTURE_DEVICE_DRAIN_AND_DRAFT_ONLY_INIT_PENDING")
        torch.npu.synchronize(self.owner.device)
        for t in self.snapshots.caches.values():
            t.zero_()
        torch.npu.current_stream().synchronize()
        self.submission.complete("IDLE_FIXTURE_DEVICE_DRAIN_AND_DRAFT_ONLY_INIT_COMPLETE")
        self.writer = CollectionWriter(
            self.output,
            dict(
                identity=self.identity,
                numeric_schema="r5-eagle3-continuous-v5",
                groups=self.groups,
                expected_samples=9,
                tolerance=dict(atol=0.0, rtol=0.0),
                layers=list(self.snapshots.layers),
                global_group_id=self.snapshots.global_group_id,
                kv_inventory={
                    k: dict(shape=list(v.shape), dtype=str(v.dtype))
                    for k, v in self.snapshots.caches.items()
                },
                capture_device_kv_bound_bytes=self.snapshots.device_bytes_bound,
                hidden_contract=dict(width=self.owner.hidden_size, dtype=str(self.owner.dtype)),
                max_model_len=self.owner.max_model_len,
                slot_dtype=str(self.owner.block_tables.slot_mappings.dtype),
                kv_write_contract=dict(
                    backend=self.owner.attn_backend.__module__ + "." + self.owner.attn_backend.__qualname__,
                    forward_includes_kv_cache_update=self.owner.attn_backend.forward_includes_kv_cache_update,
                    consumed_field="AscendMetadata.slot_mapping",
                    forward_context_slot_mapping="RETAINED_BUT_UNUSED_BY_THIS_BACKEND"),
                first_pass_input_contract="PINNED_ACCEPTED_PREFIX_WITH_TARGET_FULL_WRITE_GRID",
                gpu_query_contract="CAPTURE_AND_RUNTIME_OWNED_FULL_INPUT_QUERY_FIA_HOST_PADDED_SEPARATE",
                initialization="EXCLUSIVE_IDLE_DRAFT_ONLY_ZERO_AFTER_DEVICE_DRAIN; TARGET_INTERVALS_DISJOINT",
                scope="CAPTURED_D2D_SNAPSHOTS_AND_SERIAL_EAGER_REFERENCE",
                normal_overlap="UNPROVEN",
                ABA="NOT_ASSESSED",
                full_target="NOT_ASSESSED",
                physical_read="NOT_PROVEN",
                shared_failure_risk=
                "Same weights, eager FIA and common metadata non-read fields; canonical projection and forward call independent.",
            ),
            max_bytes=4 << 30)
        probe = self
        for first, manager in ((True, self.owner.prefill_cudagraph_manager), (False,
                                                                              self.owner.decode_cudagraph_manager)):
            original = manager.run_fullgraph
            self.saved.append((manager, "run_fullgraph" in vars(manager), vars(manager).get("run_fullgraph")))

            def run(_manager, desc, *, first=first, original=original):
                if probe.group is None or probe.group in probe.completed:
                    return original(desc)
                require(not probe.failed, "failed numeric branch cannot submit another generation")
                owner = probe.owner
                epoch = owner._require_eagle3_window_context().mapping_epoch
                if owner.input_batch.num_reqs != probe.groups[probe.group]:
                    return original(desc)
                if not first and probe.pending_epoch != epoch:
                    return original(desc)
                try:
                    value = probe._run_phase(desc, first=first, original=original)
                    if first:
                        probe.pending_epoch = epoch
                    else:
                        probe.completed.add(probe.group)
                        probe.pending_epoch = None
                    return value
                except BaseException as error:
                    probe.failed = True
                    probe.submission.failed(error)
                    probe.poisoned = probe.submission.pending
                    if probe.poisoned:
                        probe.owner._draft_window_graph_submission_uncertain = True
                        probe.session.controller.quarantine("numeric diagnostic submission uncertain")
                    atomic_json(
                        probe.output.with_name("eagle-numeric-failure.json"),
                        dict(identity=probe.identity, submission=probe.submission.snapshot(), group=probe.group))
                    raise

            manager.run_fullgraph = MethodType(run, manager)
        return self

    def set_group(self, label):
        require(label in self.groups and self.pending_epoch is None, "unknown or unfinished Eagle3 numeric group")
        self.group = label

    def _drain(self, manager, phase):
        self.submission.submit(phase + "_PENDING")
        manager.update_stream.synchronize()
        torch.npu.current_stream().synchronize()
        self.submission.complete(phase + "_COMPLETE")

    def _run_phase(self, desc, *, first, original):
        from vllm.config.compilation import CUDAGraphMode
        from vllm.v1.worker.gpu.spec_decode.autoregressive.speculator import AutoRegressiveSpeculator
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe
        from tools.p7x_graph_repair6 import metrics

        owner, snapshots = self.owner, self.snapshots
        require(owner.input_batch.positions.data_ptr() == owner.target_input_buffers.positions.data_ptr(),
                "actual Target positions do not use the captured stable input buffer")
        manager = owner.prefill_cudagraph_manager if first else owner.decode_cudagraph_manager
        require(desc.cg_mode is CUDAGraphMode.FULL, "actual FULL Graph phase required")
        nr, padded, tokens = owner.input_batch.num_reqs, desc.num_reqs, desc.num_tokens
        self._drain(manager, "PRESTATE_DIAGNOSTIC_DRAIN")
        self.submission.submit("RAW_CANONICAL_INSPECTION_PENDING")
        l0 = owner.input_batch.seq_lens_np[:nr].tolist()
        mapping = owner.input_batch.idx_mapping_np[:nr].tolist()
        group_id = snapshots.global_group_id
        valid = owner.block_tables.num_blocks.cpu[group_id, mapping].tolist()
        full = owner.block_tables.input_block_tables[group_id][:padded].detach().cpu().clone()
        selected = sorted({0} | {int(b) for r in range(nr) for b in full[r, :valid[r]].tolist()})
        ids = tuple(
            self.session.resolve(first=first, n=padded, tokens=tokens, ordinal=i) for i in range(1 if first else 2))
        snapshots.set_indices_before_replay(ids, selected)
        torch.npu.current_stream().synchronize()
        self.submission.complete("RAW_CANONICAL_INSPECTION_COMPLETE")
        self.submission.submit("GRAPH_REPLAY_UPDATE_PENDING")
        returned = original(desc)
        require(returned is None, "legal Graph manager None return changed")
        self._drain(manager, "POSTGRAPH_DIAGNOSTIC_DRAIN")
        caches = snapshots.caches
        indices = torch.tensor(selected, dtype=torch.int64, device=owner.device)
        self.submission.submit("COMPLETED_GRAPH_POSTSTATE_SNAPSHOT_PENDING")
        final = {key: t.index_select(0, indices) for key, t in caches.items()}
        torch.npu.current_stream().synchronize()
        self.submission.complete("COMPLETED_GRAPH_POSTSTATE_SNAPSHOT_COMPLETE")
        carriers = self.session.provider.submitted_carriers
        require(len(carriers) == len(ids), "actual submitted consumer cardinality")
        mismatch = False
        for identity, carrier in zip(ids, carriers):
            require(carrier.capture_identity == identity and carrier.state.name == "UPDATED",
                    "actual UPDATE attribution")
            state = snapshots.states[identity]
            require(state.before is not None and state.after is not None, "missing actual captured input/KV copies")
            source = state.before
            self.submission.submit("CAPTURED_INPUT_INSPECTION_PENDING")
            inputs = {k: t.detach().cpu().clone() for k, t in source["inputs"].items()}
            observed_full = source["canonical_table"].detach().cpu().clone()
            require(torch.equal(observed_full, full), "canonical Full table changed between preparation and consumer")
            ends = inputs["full_exact"][:nr].tolist()
            width = source["bank_tables"][snapshots.layers[0]].shape[1]
            ref_table, lengths, rows = canonical_window(full, l0, ends, valid, nr, padded, width)
            slots = canonical_slots(full,
                                    inputs["target_positions"] if first else inputs["positions"],
                                    inputs["query_start_loc"],
                                    nr,
                                    tokens,
                                    dtype=owner.block_tables.slot_mappings.dtype)
            actual = carrier.metadata
            actual_reads, actual_slots, actual_queries, runtime_queries = {}, {}, {}, {}
            unused_context_slots = {}
            metadata = {}
            for name in snapshots.layers:
                actual_reads[name] = dict(table=source["bank_tables"][name].detach().cpu().clone(),
                                          exact=source["bank_device_exact"][name].detach().cpu().clone())
                actual_slots[name] = source["actual_slots"][name].detach().cpu().clone()
                actual_queries[name] = source["metadata_query"][name].detach().cpu().clone()
                runtime_queries[name] = actual[name].query_start_loc.detach().cpu().clone()
                unused_context_slots[name] = source["forward_context_slots"][name].detach().cpu().clone()
                # All values below have already been copied from a completed
                # diagnostic Graph. Export the whole relevant contract before
                # testing it, so another failure does not require a field-by-
                # field recapture. No post-failure device inspection follows.
                atomic_json(
                    self.output.with_name(f"eagle-contract-{self.group}-step{carrier.runtime_identity.step}.json"),
                    dict(identity=self.identity,
                         runtime_identity=_json_safe(carrier.runtime_identity),
                         capture_identity=_json_safe(identity),
                         layer=name,
                         active=nr,
                         padded=padded,
                         first_pass=first,
                         l0=l0,
                         ends=ends,
                         valid=valid,
                         canonical_full_table=full.tolist(),
                         inputs={
                             k: dict(values=v.tolist(), dtype=str(v.dtype))
                             for k, v in inputs.items() if k != "hidden_states"
                         },
                         actual_reads={
                             k: dict(table=v["table"].tolist(), exact=v["exact"].tolist())
                             for k, v in actual_reads.items()
                         },
                         actual_slots=actual_slots[name].tolist(),
                         expected_slots=slots.tolist(),
                         captured_full_input_query=actual_queries[name].tolist(),
                         runtime_query=runtime_queries[name].tolist(),
                         actual_fia_query=list(actual[name].actual_seq_lengths_q),
                         actual_causal=actual[name].causal,
                         expected_read_table=ref_table.tolist(),
                         expected_exact=lengths,
                         scope="ALREADY_COPIED_CPU_CONTRACT_AFTER_DIAGNOSTIC_DRAIN_NOT_COMPLETE_NUMERIC_SAMPLE"))
                if not torch.equal(actual_slots[name], slots):
                    # Only already-copied Host values. No new device operation
                    # follows a failed contract to obtain additional evidence.
                    atomic_json(
                        self.output.with_name("eagle-numeric-contract-failure.json"),
                        dict(identity=self.identity,
                             group=self.group,
                             layer=name,
                             first_pass=first,
                             capture_identity=_json_safe(identity),
                             runtime_identity=_json_safe(carrier.runtime_identity),
                             descriptor=[padded, tokens],
                             active=nr,
                             l0=l0,
                             ends=ends,
                             valid=valid,
                             canonical_full_table=full.tolist(),
                             positions=inputs["positions"].tolist(),
                             target_positions=inputs["target_positions"].tolist(),
                             last_token_indices=inputs["last_token_indices"].tolist(),
                             query_start_loc=inputs["query_start_loc"].tolist(),
                             actual_slot_dtype=str(actual_slots[name].dtype),
                             actual_slots=actual_slots[name].tolist(),
                             unused_forward_context_slots=unused_context_slots[name].tolist(),
                             expected_slot_dtype=str(slots.dtype),
                             expected_slots=slots.tolist(),
                             graph_completion_scope="EXPLICIT_POSTGRAPH_DIAGNOSTIC_DRAIN_ALREADY_COMPLETE",
                             export_scope="ALREADY_COPIED_CPU_VALUES_ONLY; NOT_A_COMPLETE_NUMERIC_SAMPLE"))
                require(
                    torch.equal(actual_reads[name]["table"], ref_table)
                    and actual_reads[name]["exact"].tolist() == lengths,
                    "production read differs from canonical oracle")
                require(torch.equal(actual_slots[name], slots),
                        "actual captured writes differ from absolute Full slot semantics")
                require(torch.equal(actual_queries[name], inputs["query_start_loc"]),
                        "captured Full query differs from its owned current input layout")
                require(torch.equal(runtime_queries[name], inputs["query_start_loc"]),
                        "runtime metadata changed the current full input query layout")
                ref = copy.copy(actual[name])
                ref.block_tables = ref_table.to(owner.device)
                ref.seq_lens = torch.tensor(lengths, dtype=torch.int32, device=owner.device)
                ref.seq_lens_cpu = torch.tensor(lengths, dtype=torch.int32)
                ref.seq_lens_list = list(lengths)
                ref.slot_mapping = slots.to(owner.device)
                ref.query_start_loc = source["inputs"]["query_start_loc"].clone()
                ref.actual_seq_lengths_q = [(i + 1) * (4 if first else 1) for i in range(padded)]
                ref.causal, ref.num_actual_tokens = True, tokens
                ref.max_seq_len = max(lengths)
                if hasattr(ref, "positions"):
                    ref.positions = source["inputs"]["positions"].clone()
                metadata[name] = ref
            graph = tuple(t.detach().cpu().clone() for t in self.session.captured_outputs[identity])
            torch.npu.current_stream().synchronize()
            self.submission.complete("CAPTURED_INPUT_INSPECTION_COMPLETE")
            before = {key: t[:len(selected)] for key, t in source["kv"].items()}
            graph_after = {key: t[:len(selected)] for key, t in state.after.items()}
            self.submission.submit("REFERENCE_RESTORE_AND_EAGER_FORWARD_PENDING")
            for key, t in caches.items():
                t.index_copy_(0, indices, before[key])
            reference_before = {key: t.index_select(0, indices) for key, t in caches.items()}
            ref_inputs = {k: t.clone() for k, t in source["inputs"].items()}
            ref_input_snapshot = {k: t.detach().cpu().clone() for k, t in ref_inputs.items()}
            ref_metadata_snapshot = {
                name:
                dict(table=m.block_tables.detach().cpu().clone(),
                     exact=m.seq_lens.detach().cpu().clone(),
                     slot=m.slot_mapping.detach().cpu().clone(),
                     query=m.query_start_loc.detach().cpu().clone(),
                     fia_query=list(m.actual_seq_lengths_q),
                     causal=m.causal,
                     table_address=m.block_tables.data_ptr())
                for name, m in metadata.items()
            }
            proxy = SimpleNamespace(
                supports_mm_inputs=False,
                vllm_config=owner.vllm_config,
                model=owner.model,
                input_buffers=SimpleNamespace(input_ids=ref_inputs["input_ids"], positions=ref_inputs["positions"]),
                hidden_states=ref_inputs["hidden_states"],
            )
            call_start = time.monotonic_ns()
            reference = AutoRegressiveSpeculator._run_model(
                proxy,
                tokens,
                metadata,
                {name: slots.to(owner.device)
                 for name in snapshots.layers},
                None,
                CUDAGraphMode.NONE,
            )
            torch.npu.current_stream().synchronize()
            call_end = time.monotonic_ns()
            self.submission.complete("REFERENCE_EAGER_FORWARD_COMPLETE")
            self.submission.submit("REFERENCE_POSTSTATE_INSPECTION_PENDING")
            reference = tuple(t.detach().cpu().clone() for t in reference)
            reference_after = {key: t.index_select(0, indices) for key, t in caches.items()}
            measured = [
                metrics(a[:nr * (4 if first else 1)], b[:nr * (4 if first else 1)]) for a, b in zip(graph, reference)
            ]
            finite = all(bool(torch.isfinite(t).all()) for t in (*graph, *reference))
            valid_numeric = finite and all(m["max_abs"] == 0.0 and m["finite"] for m in measured)
            valid_kv = all(
                torch.equal(graph_after[k], reference_after[k]) and torch.equal(before[k], reference_before[k])
                for k in caches)
            torch.npu.current_stream().synchronize()
            self.submission.complete("REFERENCE_POSTSTATE_INSPECTION_COMPLETE")
            status = "PASS_SCOPED_EAGLE3_CONTINUOUS" if valid_numeric and valid_kv else "NUMERIC_MISMATCH"
            self.submission.submit("COMPLETED_GRAPH_POSTSTATE_RESTORE_PENDING")
            for key, t in caches.items():
                t.index_copy_(0, indices, final[key])
            torch.npu.current_stream().synchronize()
            self.submission.complete("COMPLETED_GRAPH_POSTSTATE_RESTORE_COMPLETE")
            runtime_identity = carrier.runtime_identity
            record = dict(
                identity=dict(self.identity,
                              generation=runtime_identity.generation_id,
                              epoch=runtime_identity.mapping_epoch,
                              step=runtime_identity.step),
                group=self.group,
                descriptor=[padded, tokens],
                active=nr,
                first_pass=first,
                capture_identity=_json_safe(identity),
                runtime_identity=_json_safe(runtime_identity),
                canonical_table=full,
                l0=l0,
                ends=ends,
                valid=valid,
                mapping=mapping,
                oracle=rows,
                selected_blocks=selected,
                inputs=inputs,
                reference_inputs=ref_input_snapshot,
                actual_reads=actual_reads,
                reference_metadata=ref_metadata_snapshot,
                actual_fia_query={name: list(actual[name].actual_seq_lengths_q)
                                  for name in snapshots.layers},
                actual_causal={name: actual[name].causal
                               for name in snapshots.layers},
                actual_slots=actual_slots,
                forward_context_slots=unused_context_slots,
                captured_full_input_queries=actual_queries,
                runtime_queries=runtime_queries,
                pre_kv=before,
                graph_post_kv=graph_after,
                reference_pre_kv=reference_before,
                reference_post_kv=reference_after,
                graph=graph,
                reference=reference,
                reference_call=dict(mode="NONE",
                                    function="pinned AutoRegressiveSpeculator._run_model",
                                    start_ns=call_start,
                                    end_ns=call_end,
                                    input_pointers={
                                        k: int(t.data_ptr())
                                        for k, t in ref_inputs.items()
                                    },
                                    captured_input_pointers={
                                        k: int(t.data_ptr())
                                        for k, t in source["inputs"].items()
                                    }),
                metrics=measured,
                status=status,
                write_scope="ALL_VALID_FULL_ROWS_OF_ACTIVE_REQUESTS_PLUS_BLOCK0_NOT_ENTIRE_KV_ALLOCATION",
            )
            self.submission.submit("EVIDENCE_EXPORT_PENDING")
            self.writer.start(record["identity"])
            self.writer.finish(record)
            torch.npu.current_stream().synchronize()
            self.submission.complete("EVIDENCE_EXPORT_COMPLETE")
            self.records.append(dict(identity=record["identity"], group=self.group, status=status, metrics=measured))
            if status == "NUMERIC_MISMATCH":
                mismatch = True
                break
        if mismatch:
            raise NumericMismatch("EAGLE3_NUMERIC_MISMATCH: completed durable sample; dependent branch stopped")
        return returned

    def __exit__(self, kind, *_):
        for manager, existed, value in self.saved:
            if existed:
                manager.run_fullgraph = value
            else:
                delattr(manager, "run_fullgraph")
        complete = not kind and not self.failed and len(self.records) == 9 and self.completed == set(self.groups)
        self.writer.close(
            "COMPLETE" if complete else "EXECUTION_FAILED" if kind or self.failed else "INCOMPLETE_COVERAGE")
        atomic_json(
            self.output.with_name("eagle-numeric-summary.json"),
            dict(
                identity=self.identity,
                samples=self.records,
                completed_groups=sorted(self.completed),
                submission=self.submission.snapshot(),
                complete=complete,
                normal_overlap="UNPROVEN",
                ABA="NOT_ASSESSED",
            ))
