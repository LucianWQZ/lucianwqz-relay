# SPDX-License-Identifier: Apache-2.0
"""Independent DSpark K7 / non-anchor Q8 profile, never a Q7 reinterpretation."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

from tools.p7x_graph_repair12_contract import method_for_profile, validate_method_document
from tools.p7x_graph_repair5_evidence import file_sha
from tools.p7x_graph_repair6_storage import require

PROFILE = "dspark_k7_noanchor_q8"


def validate_model_view(document):
    require(document["schema"] == "r5-dspark-noanchor-q8-fixture-v1", "distinct Q8 fixture schema")
    validate_method_document(PROFILE, document["method_contract"])
    directory = Path(document["draft_model"])
    require(not directory.is_symlink() and directory.is_dir(), "owned model configuration directory")
    require({p.name for p in directory.iterdir()} == {"config.json", "model.safetensors"}, "exact model view inventory")
    config = directory / "config.json"
    weight = directory / "model.safetensors"
    require(not config.is_symlink() and weight.is_symlink(), "only owned config and immutable weight symlink")
    require(str(weight.resolve(strict=True)) == document["weight_source"], "model weight symlink retargeted")
    current = json.loads(config.read_text())
    source_config = Path(document["source_config"])
    original_bytes = source_config.read_bytes()
    require(
        hashlib.sha256(original_bytes).hexdigest() == document["source_config_sha256"], "original model config changed")
    expected = json.loads(original_bytes)
    expected["sample_from_anchor"] = False
    require(current == expected and current["sample_from_anchor"] is False,
            "only explicit sampling config change allowed")
    require(
        any(x["path"] == str(config) and x["sha256"] == hashlib.sha256(config.read_bytes()).hexdigest()
            for x in document["files"]), "owned configuration absent from fixture files")
    require(any(x["path"] == document["weight_source"] for x in document["files"]), "weight source absent from fixture")


def prepare_cases(cases, inputs, output, repo, python, sha, tree, verified_files):
    path = inputs / "dspark-k7-noanchor-q8-fixture.json"
    if not path.exists():
        return None
    fixture = json.loads(path.read_text())
    validate_model_view(fixture)
    known = {x["path"]: x for x in verified_files}
    files = []
    for item in fixture["files"]:
        file = Path(item["path"])
        stat = file.stat()
        prior = known.get(str(file))
        unchanged = prior is not None and (prior["sha256"], prior["size"],
                                           prior["mtime_ns"]) == (item["sha256"], stat.st_size, stat.st_mtime_ns)
        require(unchanged or file_sha(file) == item["sha256"], "Q8 fixture file changed")
        files.append(dict(path=str(file), sha256=item["sha256"], size=stat.st_size, mtime_ns=stat.st_mtime_ns))
    proof = output / "dspark-q8-fixture-verification.json"
    fixture_sha = hashlib.sha256(path.read_bytes()).hexdigest()
    content = (json.dumps(dict(source_sha=sha, source_tree=tree, fixture_sha256=fixture_sha, files=files), indent=2) +
               "\n").encode()
    checksum = hashlib.sha256(content).hexdigest()
    selections = [("NUMERIC_SENTINEL", "DSPARK_Q8_SENTINEL", ["CONFIG_DSPARK_Q8"]),
                  ("NUMERIC_TARGET4", "NUMERIC_DSPARK_Q8", ["DSPARK_Q8_SENTINEL"]),
                  ("TARGET4_OFF", "DSPARK_Q8_OFF", ["DSPARK_Q8_SENTINEL"])]
    for source, name, dependencies in selections:
        case = copy.deepcopy(cases[source])
        for field in ("argv", "launch_argv"):
            argv = [v.replace(source, name) for v in case[field]]
            for flag, value in (("--draft-model", fixture["draft_model"]), ("--fixture-manifest", str(path)),
                                ("--repair5-capture-profile", PROFILE)):
                if flag in argv:
                    argv[argv.index(flag) + 1] = value
                else:
                    argv += [flag, value]
            argv += ["--repair12-fixture-verification", str(proof), "--repair12-fixture-verification-sha256", checksum]
            case[field] = argv
        for command in case["validation_commands"]:
            command["argv"] = [v.replace(source, name) for v in command["argv"]]
        case.pop("check_argv", None)
        case.pop("additional_checks", None)
        case["acceptance_identity"]["case_id"] = name
        case.update(case_id=name,
                    outputs=str(output / name),
                    dependencies=dependencies,
                    capture_profile=PROFILE,
                    fixture_sha256=fixture_sha,
                    method_contract=method_for_profile(PROFILE).document(),
                    selection="OPT_IN_INDEPENDENT_DSPARK_K7_NOANCHOR_Q8")
        cases[name] = case
    case = copy.deepcopy(cases["CONFIG"])
    name = "CONFIG_DSPARK_Q8"
    case.update(case_id=name,
                outputs=str(output / name),
                dependencies=["P0"],
                validation_commands=[],
                selection="READ_ONLY_ACTUAL_DSPARK_Q8_FRAMEWORK_CONFIG")
    case["argv"] = [
        python,
        str(repo / "tools/p7x_graph_repair7.py"), "config-check", "--framework", "--plan",
        str(output / "case-plan.json"), "--output",
        str(output / name / "config.json")
    ]
    case.pop("launch_argv", None)
    cases[name] = case
    return dict(path=str(proof), sha256=checksum, content=content)
