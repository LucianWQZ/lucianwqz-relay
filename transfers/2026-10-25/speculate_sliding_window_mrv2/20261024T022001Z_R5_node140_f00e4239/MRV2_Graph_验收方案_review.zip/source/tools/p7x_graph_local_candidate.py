#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Audited local-commit plan and per-case device binding for Repair7 descendants.

This path never represents a local commit as a verified remote publication.
Preparation is Host only. Binding still requires the committed device receipt
validator and a fresh receipt for the selected case.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

BASE_SHA = "7a9f4aae1ebe5c5f3d4876ec9b49926949dfae14"
VLLM_SHA = "84030bbe3d74d99bad477a3d2e37a973ccd8865c"
VLLM_TREE = "f3e320f8ae2e9a30e57a3c8dccfac94fcae93bee"
FIXTURE_SHA = "1c485bc43a6e8f6d0d83c1dc6ebfd0fb9bb1f31a8ad9e498ef1d3e9d562e7cd4"
STATUS = "LOCAL_COMMITTED_CANDIDATE"


def digest(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 << 20), b""):
            sha.update(block)
    return sha.hexdigest()


def _git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def _identity(repo: Path, sha: str, tree: str, *, ancestor: str | None = None) -> None:
    if _git(repo, "rev-parse", "HEAD") != sha or _git(repo, "rev-parse", "HEAD^{tree}") != tree:
        raise ValueError("local candidate commit/tree mismatch")
    if _git(repo, "status", "--porcelain", "--untracked-files=all"):
        raise ValueError("local candidate checkout is dirty")
    if ancestor is not None:
        subprocess.run(["git", "-C", str(repo), "merge-base", "--is-ancestor", ancestor, sha], check=True)


def _cases_sha(plan: dict) -> str:
    return hashlib.sha256(json.dumps(plan["cases"], sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _planned_device_scope(value: list[int]) -> list[int]:
    if (
        not isinstance(value, list)
        or any(type(physical) is not int for physical in value)
        or value not in (list(range(8)), list(range(8, 16)))
    ):
        raise ValueError("planned physical scope must be one explicit group of eight")
    return list(value)


def _validate_scope_binding(plan: dict, manifest: dict) -> None:
    scope = _planned_device_scope(plan.get("authorized_host_phy_ids", list(range(8))))
    if scope != _planned_device_scope(manifest.get("authorized_host_phy_ids", list(range(8)))):
        raise ValueError("local planned physical scope changed")


def _validate_host_evidence(evidence: list[dict]) -> None:
    if not evidence or any(
        row.get("status") != "PASS" or digest(Path(row["path"])) != row["sha256"] for row in evidence
    ):
        raise ValueError("Host evidence missing or changed")
    required = {"graph_quarantine", "local_admission"}
    if not required.issubset({row.get("label") for row in evidence}):
        raise ValueError("Host evidence coverage missing")


def validate_local_plan(plan: dict) -> dict:
    if plan.get("publication_status") != STATUS or plan.get("remote_publication") != "NOT_PERFORMED":
        raise ValueError("not a local committed candidate plan")
    if plan.get("schema") != "repair7-case-plan-v1":
        raise ValueError("local candidate requires Repair7 case schema")
    if not plan.get("local_candidate_manifest") or not plan.get("local_candidate_manifest_sha256"):
        raise ValueError("local candidate manifest missing")
    path = Path(plan["local_candidate_manifest"])
    if digest(path) != plan["local_candidate_manifest_sha256"]:
        raise ValueError("local candidate manifest changed")
    manifest = json.loads(path.read_text())
    if manifest.get("schema") != "repair7-local-candidate-v1":
        raise ValueError("unknown local candidate manifest")
    if (manifest.get("source_sha"), manifest.get("source_tree"), manifest.get("run_id")) != (
        plan["commit"],
        plan["tree"],
        plan["run_id"],
    ):
        raise ValueError("local manifest/source/run mismatch")
    if manifest.get("baseline_sha") != BASE_SHA or manifest.get("cases_sha256") != _cases_sha(plan):
        raise ValueError("local baseline or cases changed")
    _validate_scope_binding(plan, manifest)
    repo = Path(manifest["source_checkout"])
    vllm = Path(manifest["vllm_checkout"])
    _identity(repo, plan["commit"], plan["tree"], ancestor=BASE_SHA)
    _identity(vllm, VLLM_SHA, VLLM_TREE)
    if manifest.get("vllm_sha") != VLLM_SHA or manifest.get("vllm_tree") != VLLM_TREE:
        raise ValueError("vLLM pin changed")
    for rel, expected in manifest["source_files_sha256"].items():
        if digest(repo / rel) != expected:
            raise ValueError("local source file changed: " + rel)
    fixture = Path(manifest["fixture_manifest"])
    if digest(fixture) != FIXTURE_SHA:
        raise ValueError("fixture manifest changed")
    method_proof = manifest.get("method_fixture_verification")
    if method_proof is not None:
        proof_path = Path(method_proof["path"])
        if digest(proof_path) != method_proof["sha256"]:
            raise ValueError("method fixture verification changed")
    for proof in manifest.get("additional_method_fixture_verifications", []):
        if digest(Path(proof["path"])) != proof["sha256"]:
            raise ValueError("additional method fixture verification changed")
    expected_files = json.loads(fixture.read_text())["files"]
    verified_files = manifest.get("fixture_files", [])
    if len(expected_files) != len(verified_files):
        raise ValueError("fixture verification count changed")
    for expected, verified in zip(expected_files, verified_files):
        path = Path(expected["path"])
        stat = path.stat()
        if (verified.get("path"), verified.get("sha256"), verified.get("size"), verified.get("mtime_ns")) != (
            str(path),
            expected["sha256"],
            stat.st_size,
            stat.st_mtime_ns,
        ):
            raise ValueError("fixture changed since prepare: " + str(path))
    config_path = Path(manifest["config_report"])
    if digest(config_path) != manifest["config_report_sha256"]:
        raise ValueError("local config report changed")
    config = json.loads(config_path.read_text())
    if (
        config.get("status") != "CONFIGS_VALID"
        or not config.get("rows")
        or any(row.get("status") != "SCHEMA_VALID_NOT_FRAMEWORK_PASS" for row in config["rows"])
    ):
        raise ValueError("local schema check did not pass")
    if {row.get("numeric_enabled") for row in config["rows"]} != {False, True}:
        raise ValueError("local schema check lacks enabled and disabled diagnostic cases")
    evidence = manifest.get("host_evidence", [])
    _validate_host_evidence(evidence)
    return {
        "status": STATUS,
        "source_sha": plan["commit"],
        "source_tree": plan["tree"],
        "device_validation": "NOT_INFERRED",
    }


def prepare(args: argparse.Namespace) -> None:
    from tools.p7x_graph_repair7 import config_matrix
    from tools.p7x_graph_repair7_campaign import build_plan

    planned_scope = _planned_device_scope(getattr(args, "authorized_host_phy_ids", list(range(8))))

    if args.output.exists():
        raise ValueError("new local candidate output directory required")
    sha, tree = _git(args.repo, "rev-parse", "HEAD"), _git(args.repo, "rev-parse", "HEAD^{tree}")
    _identity(args.repo, sha, tree, ancestor=BASE_SHA)
    _identity(args.vllm, VLLM_SHA, VLLM_TREE)
    fixture = args.inputs / "fixture_manifest.json"
    if digest(fixture) != FIXTURE_SHA:
        raise ValueError("fixture manifest mismatch")
    verified_files = []
    reusable = {}
    reused_plan = getattr(args, "reuse_fixture_plan", None)
    if reused_plan is not None:
        prior_plan = json.loads(reused_plan.read_text())
        validate_local_plan(prior_plan)
        prior_manifest = json.loads(Path(prior_plan["local_candidate_manifest"]).read_text())
        reusable = {row["path"]: row for row in prior_manifest["fixture_files"]}
    for row in json.loads(fixture.read_text())["files"]:
        path = Path(row["path"])
        stat = path.stat()
        prior = reusable.get(str(path))
        unchanged = (
            prior is not None
            and prior["sha256"] == row["sha256"]
            and prior["size"] == stat.st_size
            and prior["mtime_ns"] == stat.st_mtime_ns
        )
        if not unchanged and digest(path) != row["sha256"]:
            raise ValueError("fixture file changed: " + str(path))
        verified_files.append(
            {"path": str(path), "sha256": row["sha256"], "size": stat.st_size, "mtime_ns": stat.st_mtime_ns}
        )
    host_evidence = json.loads(args.host_evidence.read_text())
    _validate_host_evidence(host_evidence)
    plan = build_plan(args.repo, args.inputs, args.output, args.vllm, sys.executable, sha, tree, args.run_id)
    plan["authorized_host_phy_ids"] = planned_scope
    method_fixture = args.inputs / "dflash-k15-q16-fixture.json"
    method_verification = None
    if method_fixture.exists():
        records = []
        known = {row["path"]: row for row in verified_files}
        for item in json.loads(method_fixture.read_text())["files"]:
            path = Path(item["path"])
            stat = path.stat()
            previous = known.get(str(path))
            unchanged = previous is not None and (
                previous["sha256"], previous["size"], previous["mtime_ns"]
            ) == (item["sha256"], stat.st_size, stat.st_mtime_ns)
            if not unchanged:
                if digest(path) != item["sha256"]:
                    raise ValueError("DFlash fixture changed: " + str(path))
            records.append(
                dict(
                    path=str(path),
                    size=stat.st_size,
                    mtime_ns=stat.st_mtime_ns,
                    sha256=item["sha256"],
                    verification="CURRENT_PREPARE_OR_VALIDATED_UNCHANGED_PRIOR",
                )
            )
        method_verification = dict(
            source_sha=sha, source_tree=tree, fixture_sha256=digest(method_fixture), files=records
        )
        receipt_path = args.output / "method-fixture-verification.json"
        receipt_bytes = (json.dumps(method_verification, indent=2) + "\n").encode()
        receipt_sha = hashlib.sha256(receipt_bytes).hexdigest()
        from tools.p7x_graph_repair12_contract import attach_fixture_verification

        attach_fixture_verification(plan["cases"], receipt_path, receipt_sha)
    additional_proofs = []
    eagle_fixture = args.inputs / "eagle3-k3-fixture.json"
    if eagle_fixture.exists():
        from tools.p7x_graph_repair13_eagle import add_cases, validate_contract

        eagle = json.loads(eagle_fixture.read_text())
        if eagle.get("schema") != "r5-eagle3-k3-fixture-v1":
            raise ValueError("unexpected Eagle3 fixture contract")
        validate_contract(eagle["method_contract"])
        known = {row["path"]: row for row in verified_files}
        records = []
        for item in eagle["files"]:
            path = Path(item["path"])
            st = path.stat()
            previous = known.get(str(path))
            unchanged = previous is not None and (
                previous["sha256"], previous["size"], previous["mtime_ns"]
            ) == (item["sha256"], st.st_size, st.st_mtime_ns)
            if st.st_size != item["bytes"] or not unchanged and digest(path) != item["sha256"]:
                raise ValueError("Eagle3 fixture changed: " + str(path))
            records.append(dict(path=str(path), size=st.st_size, mtime_ns=st.st_mtime_ns, sha256=item["sha256"]))
        proof_path = args.output / "eagle3-fixture-verification.json"
        proof_bytes = (json.dumps(dict(source_sha=sha, source_tree=tree, fixture_sha256=digest(eagle_fixture),
                                       files=records), indent=2) + "\n").encode()
        proof_sha = hashlib.sha256(proof_bytes).hexdigest()
        additional_proofs.append(dict(path=str(proof_path), sha256=proof_sha, content=proof_bytes))
        add_cases(plan["cases"], args.inputs, args.output, args.repo, sys.executable, sha, proof_path, proof_sha)
    from tools.p7x_graph_repair17_dspark_q8 import prepare_cases as prepare_q8_cases
    q8_proof = prepare_q8_cases(plan["cases"], args.inputs, args.output, args.repo, sys.executable, sha, tree, verified_files)
    if q8_proof is not None:
        additional_proofs.append(q8_proof)
    config = config_matrix(plan, framework=False)
    if config.get("status") != "CONFIGS_VALID":
        raise ValueError("local schema configuration failed: " + config.get("status", "UNKNOWN"))
    configurations = {row["case_id"]: row["config_sha256"] for row in config["rows"]}
    for name, case in plan["cases"].items():
        if case.get("performance_arm") is not None:
            if name not in configurations:
                raise ValueError("performance case has no independently prepared configuration: " + name)
            case["expected_llm_kwargs_sha256"] = configurations[name]
    args.output.mkdir(parents=True)
    if method_verification is not None:
        receipt_path.write_bytes(receipt_bytes)
    for proof in additional_proofs:
        Path(proof["path"]).write_bytes(proof["content"])
    config_path = args.output / "config-schema.json"
    config_path.write_text(json.dumps(config, indent=2) + "\n")
    source_files = [
        "tools/p7x_graph_local_candidate.py",
        "tools/p7x_graph_repair6_runner.py",
        "tools/p7x_graph_repair7_device.py",
        "tools/p7x_graph_repair7_campaign.py",
        "tools/p7x_graph_repair8_unwind.py",
        "tools/p7x_graph_repair8_task_dump.py",
        "tools/p7x_graph_repair9_host_lengths.py",
        "tools/p7x_graph_repair9_materialize_fault.py",
        "tools/p7x_graph_repair5_profile.py",
        "tools/p7x_graph_repair10_performance.py",
        "tools/p7x_graph_repair10_metadata_fault.py",
        "tools/p7x_graph_repair11_method_anchor.py",
        "tools/p7x_graph_repair12_contract.py",
        "tools/p7x_graph_repair13_eagle.py",
        "tools/p7x_graph_repair14_single_metadata.py",
        "tools/p7x_graph_repair15_eagle_numeric.py",
        "tools/p7x_graph_repair15_eagle_numeric_check.py",
        "tools/p7x_graph_repair16_scheduler.py",
        "tools/p7x_graph_repair17_dspark_q8.py",
        "tools/p7x_graph_repair18_long_context.py",
        "vllm_ascend/worker/v2/spec_decode/draft_window_eagle3_diagnostics.py",
        "vllm_ascend/worker/v2/spec_decode/draft_window_graph_metadata.py",
        "vllm_ascend/ascend_config.py",
        "tools/p7x_graph_repair6_numeric.py",
        "tools/p7x_graph_repair6_numeric_check.py",
        "tools/p7x_graph_repair5_target.py",
        "vllm_ascend/worker/v2/spec_decode/dflash/speculator.py",
        "tools/p7x_graph_repair5_evidence.py",
        "tools/p7x_graph_repair7.py",
        "tools/p7x_graph_repair2.py",
        "vllm_ascend/worker/v2/spec_decode/draft_window.py",
        "vllm_ascend/worker/v2/spec_decode/draft_window_eager.py",
        "vllm_ascend/worker/v2/spec_decode/dflash/aclgraph.py",
    ]
    manifest = {
        "schema": "repair7-local-candidate-v1",
        "source_checkout": str(args.repo.resolve()),
        "source_sha": sha,
        "source_tree": tree,
        "baseline_sha": BASE_SHA,
        "vllm_checkout": str(args.vllm.resolve()),
        "vllm_sha": VLLM_SHA,
        "vllm_tree": VLLM_TREE,
        "run_id": args.run_id,
        "authorized_host_phy_ids": planned_scope,
        "cases_sha256": _cases_sha(plan),
        "source_files_sha256": {rel: digest(args.repo / rel) for rel in source_files},
        "fixture_manifest": str(fixture.resolve()),
        "fixture_files": verified_files,
        "fixture_reuse_from": None
        if reused_plan is None
        else dict(path=str(reused_plan), sha256=digest(reused_plan), source_sha=prior_plan["commit"]),
        "method_fixture_verification": None
        if method_verification is None
        else dict(path=str(receipt_path), sha256=receipt_sha),
        "additional_method_fixture_verifications": [
            {key: proof[key] for key in ("path", "sha256")} for proof in additional_proofs
        ],
        "config_report": str(config_path.resolve()),
        "config_report_sha256": digest(config_path),
        "host_evidence": host_evidence,
        "remote_publication": "NOT_PERFORMED",
        "device_validation": "NOT_RUN",
    }
    manifest_path = args.output / "local-candidate-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    plan.update(
        publication_status=STATUS,
        remote_publication="NOT_PERFORMED",
        local_candidate_manifest=str(manifest_path.resolve()),
        local_candidate_manifest_sha256=digest(manifest_path),
        readiness="HOST_PREPARED; fresh per-case device receipt still required",
    )
    plan_path = args.output / "case-plan.json"
    plan_path.write_text(json.dumps(plan, indent=2) + "\n")
    validate_local_plan(plan)


def bind(args: argparse.Namespace) -> None:
    from tools.p7x_graph_repair7_device import validate_admission

    if args.output.exists():
        raise ValueError("new admitted plan output required")
    plan = json.loads(args.plan.read_text())
    validate_local_plan(plan)
    if args.case_id not in plan["cases"] or not plan["cases"][args.case_id].get("requires_device_admission"):
        raise ValueError("case does not require device binding")
    plan.update(device_admission_receipt=str(args.receipt.resolve()), device_admission_sha256=digest(args.receipt))
    validate_admission(plan, args.case_id)
    args.output.write_text(json.dumps(plan, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    for name in ("repo", "vllm", "inputs", "output", "host-evidence"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--run-id", required=True)
    p.add_argument(
        "--reuse-fixture-plan", type=Path, help="Validate prior fixed plan and reuse only unchanged exact file versions"
    )
    p.add_argument(
        "--authorized-host-phy-ids",
        type=int,
        nargs="+",
        default=list(range(8)),
        help="Planned front/rear eight only; fresh user/machine admission still required",
    )
    b = sub.add_parser("bind")
    for name in ("plan", "receipt", "output"):
        b.add_argument("--" + name, type=Path, required=True)
    b.add_argument("--case-id", required=True)
    args = parser.parse_args()
    (prepare if args.command == "prepare" else bind)(args)


if __name__ == "__main__":
    main()
