# SPDX-License-Identifier: Apache-2.0
"""Disposable Eagle3 Python unwind probe; never simulate native corruption.

Only the named completion diagnostic drains before raising. Once the fault is
raised this probe uses Host identities/guards only and the producer exits 74.
It does not restore, clear, synchronize or reuse the failed process's banks.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from types import MethodType

if __name__ == "__main__":
    # Direct-file launch must not let tools/bisect shadow stdlib bisect.
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair5_evidence import audit_execution, require
from tools.p7x_graph_repair6_storage import atomic_json

POINTS = ("before_first_replay", "after_first_update", "after_ar_update", "after_diagnostic_completion")


class InjectedEagle3UnwindError(RuntimeError):
    pass


class EagleUnwind:

    def __init__(self, owner, output, identity, point):
        require(point in POINTS, "unknown Eagle3 unwind point")
        self.owner, self.output, self.identity, self.point = owner, output, dict(identity), point
        self.session = owner._eagle3_graph_session
        self.saved, self.record = [], None
        self.post_fault_manager_calls = 0

    def __enter__(self):
        probe = self
        for first, manager in ((True, self.owner.prefill_cudagraph_manager), (False,
                                                                              self.owner.decode_cudagraph_manager)):
            original = manager.run_fullgraph
            self.saved.append((manager, "run_fullgraph" in vars(manager), vars(manager).get("run_fullgraph")))

            def call(_manager, desc, *, first=first, manager=manager, original=original):
                if probe.record is not None:
                    probe.post_fault_manager_calls += 1
                    raise RuntimeError("faulted Eagle3 process must not submit another Graph")
                context = probe.owner._eagle3_window_proposal_context
                eligible = (context is not None and desc.cg_mode.name == "FULL"
                            and not probe.owner._eagle3_window_bypass_active)
                if eligible and not first:
                    # The initial nonuniform prefill may have an eager first
                    # pass plus an AR Graph. This experiment specifically
                    # requires one proposal containing all three Graph banks.
                    eligible = (probe.session.controller._first_pass_is_graph
                                and any(t.step == 0 and t.mapping_epoch == context.mapping_epoch
                                        for t in probe.session.controller.transfers))
                if not eligible:
                    return original(desc)
                if first and probe.point == "before_first_replay":
                    probe.inject(desc, context, completed=False)
                result = original(desc)
                require(result is None, "legal Eagle3 manager None return")
                if first and probe.point == "after_first_update":
                    probe.inject(desc, context, completed=False)
                if not first and probe.point in ("after_ar_update", "after_diagnostic_completion"):
                    completed = probe.point == "after_diagnostic_completion"
                    if completed:
                        # Explicit diagnostic before the fault, never a claim
                        # about normal overlap or a post-fault recovery.
                        import torch
                        probe.owner.prefill_cudagraph_manager.update_stream.synchronize()
                        manager.update_stream.synchronize()
                        torch.npu.current_stream().synchronize()
                    probe.inject(desc, context, completed=completed)
                return result

            manager.run_fullgraph = MethodType(call, manager)
        return self

    def inject(self, desc, context, *, completed):
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe
        transfers = [t for t in self.session.controller.transfers if t.mapping_epoch == context.mapping_epoch]
        first = self.point in ("before_first_replay", "after_first_update")
        capture = self.session.resolve(first=first, n=desc.num_reqs, tokens=desc.num_tokens, ordinal=0)
        self.record = dict(
            point=self.point,
            ns=time.monotonic_ns(),
            epoch=context.mapping_epoch,
            request_ids=list(context.ordered_request_ids),
            descriptor=[desc.num_reqs, desc.num_tokens],
            capture_identity=_json_safe(capture),
            transfers=_json_safe(transfers),
            carrier_states=[
                self.session.provider._require_registered_capture(t.capture_identity).state.name for t in transfers
            ],
            backing_address=capture.backing_identity.window_block_table.data_ptr,
            explicit_diagnostic_drain_complete=completed,
            submission_scope=("NO_FIRST_GRAPH_REPLAY; PRIOR_INPUT_PREPARATION_MAY_BE_ENQUEUED"
                              if self.point == "before_first_replay" else "EXPLICIT_DIAGNOSTIC_DRAIN_COMPLETED"
                              if completed else "REPLAY_AND_UPDATE_RETURNED_COMPLETION_UNKNOWN"))
        raise InjectedEagle3UnwindError("REPAIR19_EAGLE_UNWIND:" + self.point)

    def __exit__(self, kind, error, traceback):
        for manager, existed, value in reversed(self.saved):
            if existed:
                manager.run_fullgraph = value
            else:
                delattr(manager, "run_fullgraph")
        guard = dict(ns=time.monotonic_ns(), body_entered=False, rejected=False, error=None)
        state = dict(quarantined=self.session.controller.quarantined,
                     proposal_context_absent=self.owner._eagle3_window_proposal_context is None,
                     live_inputs_absent=self.owner._eagle3_window_live_inputs is None,
                     graph_submission_uncertain=bool(
                         getattr(self.owner, "_draft_window_graph_submission_uncertain", False)))
        if self.record is not None and state["quarantined"]:
            try:
                with self.owner._eagle3_draft_window_proposal_scope(self.owner.input_batch,
                                                                    dummy_run=False,
                                                                    is_profile=False):
                    guard["body_entered"] = True  # Host-only empty body.
            except RuntimeError as failure:
                guard.update(rejected=not guard["body_entered"], error=str(failure))
        atomic_json(
            self.output,
            dict(schema="r5-eagle-unwind-v1",
                 identity=self.identity,
                 record=self.record,
                 state=state,
                 next_scope_guard=guard,
                 exception_type=type(error).__name__ if error is not None else None,
                 exception_message=str(error) if error is not None else None,
                 post_fault_manager_calls=self.post_fault_manager_calls,
                 post_fault_device_operations="NONE_BY_PROBE",
                 native_partial_submission="NOT_SIMULATED",
                 scope="REAL_EAGLE3_PROPOSAL_PYTHON_UNWIND_AND_HOST_GUARD_ONLY"))


def check(document, campaign, launcher, expected, artifact):
    result = audit_execution(document, campaign, launcher, expected, artifact, unwind=True)
    if result["status"] != "EXECUTION_ASSOCIATED":
        return result
    try:
        point = expected["eagle3_unwind_point"]
        require(point in POINTS and document["schema"] == "r5-eagle-unwind-v1", "exact Eagle3 fault contract")
        require(
            campaign["exception_type"] == document["exception_type"] == "InjectedEagle3UnwindError"
            and campaign["exception_message"] == document["exception_message"] == "REPAIR19_EAGLE_UNWIND:" + point,
            "exact injected error, not arbitrary exit 74")
        row, state, guard = document["record"], document["state"], document["next_scope_guard"]
        require(
            row["point"] == point and launcher["host_start_ns"] <= row["ns"] <= guard["ns"] <= launcher["host_end_ns"],
            "actual point/process interval")
        require(
            type(row["epoch"]) is int and row["epoch"] >= 0 and row["request_ids"]
            and len(set(row["request_ids"])) == len(row["request_ids"]), "actual proposal identity")
        expected_steps = [] if point == "before_first_replay" else [0] if point == "after_first_update" else [0, 1, 2]
        require([t["step"] for t in row["transfers"]] == expected_steps
                and all(t["mapping_epoch"] == row["epoch"] for t in row["transfers"]), "actual consumer generations")
        require(row["carrier_states"] == ["UPDATED"] * len(expected_steps), "actual backend UPDATE attribution")
        if expected_steps:
            generations = [t["generation"] for t in row["transfers"]]
            require(
                all(type(g) is int and g >= 0 for g in generations)
                and generations == list(range(generations[0], generations[0] + len(generations))),
                "actual consecutive consumer generations")
        require(type(row["backing_address"]) is int and row["backing_address"] > 0, "actual bank identity")
        capture = row["capture_identity"]
        require(
            capture["fingerprint"]["method"] == "eagle3"
            and capture["fingerprint"]["capture_bucket"] == row["descriptor"]
            and capture["fingerprint"]["query_width"] == (4 if point in POINTS[:2] else 1)
            and capture["fingerprint"]["route"] == ("eagle3_first_pass" if point in POINTS[:2] else "eagle3_ar_step")
            and capture["consumer_ordinal"] == 0
            and capture["backing_identity"]["window_block_table"]["data_ptr"] == row["backing_address"],
            "fault belongs to the actual captured bank")
        require(row["explicit_diagnostic_drain_complete"] is (point == "after_diagnostic_completion"),
                "completion scope mismatch")
        require(
            all(state[k] is True for k in ("quarantined", "proposal_context_absent", "live_inputs_absent",
                                           "graph_submission_uncertain")), "real scope quarantine/cleanup")
        require(guard["rejected"] is True and guard["body_entered"] is False and "quarantined" in guard["error"],
                "next real Host scope must refuse before body")
        require(
            document["post_fault_manager_calls"] == 0 and document["post_fault_device_operations"] == "NONE_BY_PROBE"
            and document["native_partial_submission"] == "NOT_SIMULATED", "post-fault device action")
        result.update(status="PASS_SCOPED_EAGLE3_PYTHON_UNWIND",
                      point=point,
                      epoch=row["epoch"],
                      submission_scope=row["submission_scope"],
                      normal_overlap="NOT_PROVEN",
                      native_partial_submission="NOT_SIMULATED")
    except (ValueError, KeyError, TypeError, IndexError) as error:
        result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("artifact", "campaign", "launcher", "plan", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    result = check(json.loads(args.artifact.read_text()), json.loads(args.campaign.read_text()),
                   json.loads(args.launcher.read_text()),
                   json.loads(args.plan.read_text())["cases"][args.case_id], args.artifact)
    atomic_json(args.output, result)
    return 0 if result["status"] == "PASS_SCOPED_EAGLE3_PYTHON_UNWIND" else 4


if __name__ == "__main__":
    raise SystemExit(main())
