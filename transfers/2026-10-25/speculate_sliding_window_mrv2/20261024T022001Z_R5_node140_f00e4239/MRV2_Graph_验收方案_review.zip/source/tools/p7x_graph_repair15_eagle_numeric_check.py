# SPDX-License-Identifier: Apache-2.0
"""Read-only recomputation of Eagle3 per-step canonical Window and tensors."""
from __future__ import annotations

import torch

from tools.p7x_graph_repair6_storage import CollectionReader, require


def _tensor(value, shape, dtype, *, finite=True):
    require(
        isinstance(value, torch.Tensor) and list(value.shape) == list(shape) and str(value.dtype) == dtype,
        "exact tensor shape/dtype mismatch")
    if finite:
        require(bool(torch.isfinite(value).all()), "nonfinite required tensor")
    return value


def validate_sample(record, header):
    r, h = record, header
    require(h["numeric_schema"] == "r5-eagle3-continuous-v5", "exact numeric binding schema")
    require(h["gpu_query_contract"] == "CAPTURE_AND_RUNTIME_OWNED_FULL_INPUT_QUERY_FIA_HOST_PADDED_SEPARATE",
            "exact owned Full query binding contract")
    require(
        h["kv_write_contract"] == dict(backend="vllm_ascend.attention.attention_v1.AscendAttentionBackend",
                                       forward_includes_kv_cache_update=True,
                                       consumed_field="AscendMetadata.slot_mapping",
                                       forward_context_slot_mapping="RETAINED_BUT_UNUSED_BY_THIS_BACKEND"),
        "exact backend write-operand contract")
    require(h["kv_write_contract"]["forward_includes_kv_cache_update"] is True, "typed write-path contract")
    require(
        type(h["global_group_id"]) is int and h["global_group_id"] >= 0
        and r["capture_identity"]["fingerprint"]["global_group_id"] == h["global_group_id"],
        "actual global cache group identity")
    require(r["status"] in ("PASS_SCOPED_EAGLE3_CONTINUOUS", "NUMERIC_MISMATCH"), "unknown sample status")
    runtime = r["runtime_identity"]
    step = runtime["step"]
    require(type(step) is int and step in (0, 1, 2) and r["first_pass"] is (step == 0), "actual consumer ordinal")
    active = h["groups"][r["group"]]
    padded = 1 if active == 1 else 4
    query, tokens = (4 if step == 0 else 1), padded * (4 if step == 0 else 1)
    require(r["active"] == active and r["descriptor"] == [padded, tokens], "method/active/padded descriptor")
    require(
        runtime["method"] == "eagle3" and runtime["actual_request_count"] == active
        and runtime["padded_request_count"] == padded, "runtime method/geometry")
    requests = runtime["ordered_request_fingerprint"]
    require(len(requests) == len(set(requests)) == active, "logical request ownership")
    require(
        r["identity"] == dict(h["identity"],
                              generation=runtime["generation_id"],
                              epoch=runtime["mapping_epoch"],
                              step=step), "producer/generation/epoch identity")
    require(len(r["l0"]) == len(r["ends"]) == len(r["valid"]) == active, "canonical exact geometry")
    layers = h["layers"]
    require(len(layers) == len(set(layers)) == 1, "complete frozen single-layer Eagle3 inventory")
    require(
        set(h["kv_inventory"]) == {f"{name}/{i}"
                                   for name in layers
                                   for i in (0, 1)}, "both actual K/V buffers of every Draft layer")
    for field in ("actual_reads", "reference_metadata", "actual_slots", "captured_full_input_queries", "runtime_queries",
                  "actual_fia_query", "actual_causal", "forward_context_slots"):
        require(set(r[field]) == set(layers), "complete layer coverage: " + field)
    full = r["canonical_table"]
    require(
        isinstance(full, torch.Tensor) and full.dtype is torch.int32 and full.ndim == 2 and full.shape[0] == padded
        and bool((full >= 0).all()), "canonical Full table")
    width = r["actual_reads"][layers[0]]["table"].shape[1]
    expected_table = torch.zeros((padded, width), dtype=torch.int32)
    expected_exact, oracle, selected = [], [], {0}
    for row in range(active):
        anchor, end, count = r["l0"][row], r["ends"][row], r["valid"][row]
        require(all(type(v) is int for v in (anchor, end, count)), "typed exact canonical counters")
        start_column = max((anchor + 3 - 1024) // 128, 0)
        final_column = (end + 127) // 128
        require(0 <= start_column < final_column <= count <= full.shape[1], "canonical source coverage")
        require(final_column - start_column <= width and len(set(full[row, :count].tolist())) == count,
                "canonical Full uniqueness/capacity")
        for col in range(final_column - start_column):
            expected_table[row, col] = full[row, col + start_column]
        length = end - start_column * 128
        require(length >= query and end <= h["max_model_len"], "current exact range")
        expected_exact.append(length)
        oracle.append(
            dict(L0=anchor, H=anchor + 3, S=start_column * 128, E=end, V=length, columns=[start_column, final_column]))
        selected.update(full[row, :count].tolist())
    expected_exact += [0] * (padded - active)
    require(r["oracle"] == oracle and r["selected_blocks"] == sorted(selected), "independent canonical projection/set")
    if step == 0:
        require(r["ends"] == r["l0"], "first-pass current full exact must be raw L0")
    inputs, ref_inputs = r["inputs"], r["reference_inputs"]
    require(
        set(inputs) == set(ref_inputs) == {
            "input_ids", "positions", "hidden_states", "full_exact", "query_start_loc", "target_positions",
            "last_token_indices"
        }, "complete input/prestate payload")
    expected_inputs = dict(input_ids=([tokens], "torch.int32"),
                           positions=([tokens], "torch.int64"),
                           hidden_states=([tokens, h["hidden_contract"]["width"]], h["hidden_contract"]["dtype"]),
                           full_exact=([padded], "torch.int32"),
                           query_start_loc=([padded + 1], "torch.int32"),
                           target_positions=([tokens], "torch.int64"),
                           last_token_indices=([padded], "torch.int64"))
    for key, (shape, dtype) in expected_inputs.items():
        _tensor(inputs[key], shape, dtype)
        _tensor(ref_inputs[key], shape, dtype)
        require(torch.equal(inputs[key], ref_inputs[key]), "eager reference input differs from actual captured input")
    require(inputs["full_exact"][:active].tolist() == r["ends"], "raw actual device full exact")
    require(inputs["query_start_loc"].tolist() == [min(i, active) * query for i in range(padded + 1)],
            "full query offsets")
    slots = torch.full((tokens, ), -1, dtype=getattr(torch, h["slot_dtype"].removeprefix("torch.")))
    for row in range(active):
        if step == 0:
            last = int(inputs["last_token_indices"][row])
            require(row * query <= last < (row + 1) * query, "accepted prefix last-token index")
        for offset in range(query):
            index = row * query + offset
            pos = r["ends"][row] - query + offset
            if step == 0:
                require(int(inputs["target_positions"][index]) == pos, "Target Full absolute position changed")
                if index <= last:
                    require(int(inputs["positions"][index]) == pos, "accepted Draft prefix position changed")
                # The pinned prepare kernel does not refresh positions after
                # last_token_indices. Keep, compare and reference these bytes;
                # never use them to redefine the unchanged Full write grid.
            else:
                require(int(inputs["positions"][index]) == pos, "absolute position changed")
            slots[index] = int(full[row, pos // 128]) * 128 + pos % 128
    for name in layers:
        _tensor(r["actual_slots"][name], [tokens], h["slot_dtype"])
        require(
            r["forward_context_slots"][name].dtype in (torch.int32, torch.int64)
            and list(r["forward_context_slots"][name].shape) == [tokens], "retained unused context slot ABI")
        read, ref = r["actual_reads"][name], r["reference_metadata"][name]
        _tensor(read["table"], [padded, width], "torch.int32")
        _tensor(read["exact"], [padded], "torch.int32")
        require(
            torch.equal(read["table"], expected_table) and read["exact"].tolist() == expected_exact,
            "actual Window read")
        require(
            torch.equal(ref["table"], expected_table) and ref["exact"].tolist() == expected_exact,
            "independent reference read")
        require(
            torch.equal(r["actual_slots"][name], slots) and torch.equal(ref["slot"], slots),
            "Full absolute write slots")
        require(
            torch.equal(r["runtime_queries"][name], inputs["query_start_loc"])
            and torch.equal(ref["query"], inputs["query_start_loc"]), "actual/reference full query owner")
        _tensor(r["captured_full_input_queries"][name], [padded + 1], "torch.int32")
        _tensor(r["runtime_queries"][name], [padded + 1], "torch.int32")
        require(torch.equal(r["captured_full_input_queries"][name], inputs["query_start_loc"]),
                "captured owned Full input query")
        require(r["actual_fia_query"][name] == ref["fia_query"] == [(i + 1) * query for i in range(padded)],
                "padded FIA cumulative queries")
        require(r["actual_causal"][name] is True and ref["causal"] is True and ref["table_address"] > 0,
                "actual and reference causal method contract")
        require(ref["table_address"] != r["capture_identity"]["backing_identity"]["window_block_table"]["data_ptr"],
                "reference cannot use the captured bank as its independent view")
    call = r["reference_call"]
    require(
        call["mode"] == "NONE" and call["function"] == "pinned AutoRegressiveSpeculator._run_model"
        and call["start_ns"] < call["end_ns"], "independent real eager call")
    require(
        set(call["input_pointers"]) == set(call["captured_input_pointers"]) == set(inputs),
        "reference input provenance")
    require(
        all(
            type(v) is int and v > 0 and v != call["captured_input_pointers"][k]
            for k, v in call["input_pointers"].items()), "reference input owners alias captured state")
    require(len(r["graph"]) == len(r["reference"]) == 2, "last-hidden/feedback output contract")
    numeric_ok = True
    for actual, reference in zip(r["graph"], r["reference"]):
        _tensor(actual, [tokens, h["hidden_contract"]["width"]], h["hidden_contract"]["dtype"])
        _tensor(reference, [tokens, h["hidden_contract"]["width"]], h["hidden_contract"]["dtype"])
        numeric_ok &= torch.equal(actual[:active * query], reference[:active * query])
    for field in ("pre_kv", "graph_post_kv", "reference_pre_kv", "reference_post_kv"):
        require(set(r[field]) == set(h["kv_inventory"]), "complete actual KV layer/buffer set")
        for key, inventory in h["kv_inventory"].items():
            _tensor(r[field][key], [len(selected), *inventory["shape"][1:]], inventory["dtype"])
    require(all(torch.equal(r["pre_kv"][k], r["reference_pre_kv"][k]) for k in h["kv_inventory"]),
            "reference KV prestate")
    numeric_ok &= all(torch.equal(r["graph_post_kv"][k], r["reference_post_kv"][k]) for k in h["kv_inventory"])
    require((r["status"] == "PASS_SCOPED_EAGLE3_CONTINUOUS") == bool(numeric_ok),
            "producer status/tensor contradiction")
    return dict(group=r["group"],
                generation=runtime["generation_id"],
                epoch=runtime["mapping_epoch"],
                step=step,
                active=active,
                padded=padded,
                cropped=any(x["S"] > 0 for x in oracle),
                l0=r["l0"],
                ends=r["ends"],
                requests=requests,
                numeric_match=bool(numeric_ok),
                status=r["status"])


def check_collection(path, expected_identity):
    result = dict(status="INVALID_EVIDENCE",
                  samples=[],
                  normal_overlap="UNPROVEN",
                  ABA="NOT_ASSESSED",
                  full_target="NOT_ASSESSED",
                  physical_read="NOT_PROVEN",
                  external_execution_association="MUST_JOIN_PLAN_LAUNCHER_CAMPAIGN")
    try:
        reader = CollectionReader(path)
        h = reader.header
        require(h["identity"] == expected_identity and h["numeric_schema"] == "r5-eagle3-continuous-v5",
                "source/collection identity")
        require(h["first_pass_input_contract"] == "PINNED_ACCEPTED_PREFIX_WITH_TARGET_FULL_WRITE_GRID",
                "exact first-pass accepted-prefix/Full-write contract")
        require(h["tolerance"] == dict(atol=0.0, rtol=0.0) and h["expected_samples"] == 9, "frozen tolerance/coverage")
        require(h["scope"] == "CAPTURED_D2D_SNAPSHOTS_AND_SERIAL_EAGER_REFERENCE", "diagnostic scope")
        for index in range(len(reader.samples)):
            require(not reader.incomplete(index), "incomplete sample manifest")
            result["samples"].append(validate_sample(reader.record(index), h))
        if any(not r["numeric_match"] for r in result["samples"]):
            result.update(status="NUMERIC_MISMATCH", execution=reader.execution)
            return result
        require(reader.execution == "COMPLETE" and len(reader.samples) == 9, "complete nine-consumer coverage")
        require(set(h["groups"].values()) == {1, 3, 4} and len(h["groups"]) == 3, "declared method coverage")
        for group in h["groups"]:
            rows = [s for s in result["samples"] if s["group"] == group]
            require([s["step"] for s in rows] == [0, 1, 2] and len({s["epoch"]
                                                                    for s in rows}) == 1,
                    "one complete proposal with distinct AR consumers")
            require([s["generation"] for s in rows] == list(range(rows[0]["generation"], rows[0]["generation"] + 3)),
                    "generation order")
            require(all(s["l0"] == rows[0]["l0"] and s["requests"] == rows[0]["requests"] for s in rows),
                    "frozen proposal anchor/request set across AR steps")
            require(rows[2]["ends"] == [min(e + 1, h["max_model_len"]) for e in rows[1]["ends"]],
                    "actual AR exact progression")
        require(any(s["cropped"] and s["active"] == 3 and s["padded"] == 4 for s in result["samples"]),
                "real clipped mixed/padded case")
        result.update(status="PASS_SCOPED_EAGLE3_SERIAL_CONTINUOUS", execution=reader.execution)
    except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
        result["error"] = str(error)
    return result
