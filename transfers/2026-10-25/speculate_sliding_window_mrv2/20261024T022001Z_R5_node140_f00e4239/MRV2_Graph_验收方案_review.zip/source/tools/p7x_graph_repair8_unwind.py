# SPDX-License-Identifier: Apache-2.0
"""Opt-in Python exception injection through the real C1 proposal finally.

Unknown submission branches perform Host inspection only. The completed branch
explicitly drains ordinary events BEFORE raising and is diagnostic only. No
ExternalEvent query, capture callback I/O, or post-fault device operation.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path
from types import MethodType

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair6_storage import atomic_json, require

POINTS = ("before_replay", "after_replay", "after_update", "after_completion")


class InjectedGraphUnwindError(RuntimeError):
    """Deliberate Python exception, never an assertion of native failure."""


class ProposalUnwindProbe:
    def __init__(self, spec, output, identity, point):
        require(point in POINTS, "unknown Python unwind point")
        self.spec, self.manager = spec, spec.query_cudagraph_manager
        self.output, self.identity, self.point = output, identity, point
        self.saved, self.record = [], None
        self.quarantine_calls = []
        self.poisoned = False

    def _wrap(self, owner, name, function):
        self.saved.append((owner, name, name in vars(owner), vars(owner).get(name)))
        setattr(owner, name, MethodType(function, owner))

    def _raise(self):
        self.record["injected_ns"] = time.monotonic_ns()
        self.record["injected_point"] = self.point
        self.poisoned = True
        raise InjectedGraphUnwindError("REPAIR8_PYTHON_UNWIND:" + self.point)

    def __enter__(self):
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe

        session = self.spec._draft_window_graph_characterization
        require(not session.recorder.enabled, "Python unwind requires observer-OFF")
        probe = self
        try:
            for desc, graph in self.manager.graphs.items():
                original = graph.replay

                def replay(_graph, original=original, desc=desc):
                    require(probe.record is None, "unwind must inject on the first real replay")
                    live = probe.spec._draft_window_live_inputs
                    carriers = session.provider.submitted_carriers
                    require(live is not None and len(carriers) == 1, "missing real generation/carrier")
                    binding = carriers[0].runtime_identity
                    require(
                        binding is not None and binding.generation_id == live.identity.generation_id
                        and binding.mapping_epoch == live.identity.mapping_epoch,
                        "live/carrier generation mismatch",
                    )
                    probe.record = dict(
                        generation=live.identity.generation_id,
                        epoch=live.identity.mapping_epoch,
                        generation_identity=_json_safe(live.identity),
                        carrier_binding=_json_safe(binding),
                        descriptor=[desc.num_reqs, desc.num_tokens],
                        backing=asdict(carriers[0].capture_identity.backing_identity),
                        replay_called=False,
                        replay_returned=False,
                        update_returned=False,
                        completion="UNPROVEN",
                        quarantine_calls=probe.quarantine_calls,
                        before_replay_ns=time.monotonic_ns(),
                    )
                    if probe.point == "before_replay":
                        probe._raise()
                    probe.record["replay_called"] = True
                    original()
                    probe.record.update(replay_returned=True, replay_return_ns=time.monotonic_ns())
                    if probe.point == "after_replay":
                        probe._raise()

                self._wrap(graph, "replay", replay)
            original_run = self.manager.run_fullgraph

            def run(_manager, desc):
                result = original_run(desc)
                require(probe.record is not None, "no real Graph replay")
                probe.record.update(update_returned=True, update_return_ns=time.monotonic_ns())
                if probe.point == "after_update":
                    probe._raise()
                if probe.point == "after_completion":
                    import torch

                    update, consumer = torch.npu.Event(), torch.npu.Event()
                    update.record(probe.manager.update_stream)
                    consumer.record(torch.npu.current_stream())
                    update.synchronize()
                    consumer.synchronize()
                    probe.record.update(
                        completion="DIAGNOSTIC_STREAM_DRAIN_BEFORE_EXCEPTION",
                        complete_ns=time.monotonic_ns(),
                        completion_events=[id(update), id(consumer)],
                        completion_impact="two ordinary events and explicit stream drains BEFORE injected error",
                    )
                    probe._raise()
                return result

            self._wrap(self.manager, "run_fullgraph", run)
            runtime = self.spec._draft_window_runtime_state
            quarantine = runtime.quarantine_generation

            def quarantine_generation(_runtime, identity):
                probe.quarantine_calls.append(dict(identity=_json_safe(identity), ns=time.monotonic_ns()))
                return quarantine(identity)  # Actual production C1 code retains the backing.

            self._wrap(runtime, "quarantine_generation", quarantine_generation)
            return self
        except BaseException:
            self._restore()
            raise

    def _restore(self):
        for owner, name, existed, old in reversed(self.saved):
            if existed:
                setattr(owner, name, old)
            else:
                delattr(owner, name)
        self.saved.clear()

    def __exit__(self, kind, *_):
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe

        # Called after the real proposal scope has already unwound. Host only.
        self.poisoned = self.poisoned or kind is not None
        try:
            runtime = self.spec._draft_window_runtime_state
            state = dict(
                quarantined_identity=_json_safe(runtime.quarantined_identity)
                if runtime.quarantined_identity is not None else None,
                active_backing_retained=runtime._active_inputs is not None,
                live_inputs_cleared=self.spec._draft_window_live_inputs is None,
                proposal_context_cleared=self.spec._draft_window_proposal_context is None,
                graph_submission_uncertain=bool(getattr(self.spec, "_draft_window_graph_submission_uncertain", False)),
            )
            # The actual production scope checks quarantine BEFORE epoch.begin,
            # any materialize or device work. Never submit a second use.
            guard = dict(rejected=False, body_entered=False)
            if runtime.quarantined_identity is not None:
                try:
                    with self.spec._draft_window_proposal_scope(
                        self.spec.input_batch, dummy_run=False, is_profile=False
                    ):
                        guard["body_entered"] = True
                except RuntimeError as error:
                    guard.update(rejected=True, exception=str(error), ns=time.monotonic_ns())
            atomic_json(self.output, dict(
                schema="repair8-python-unwind-v1", identity=self.identity, point=self.point,
                record=self.record, state=state, next_scope_guard=guard,
                status="HOST_EXPORTED_ISOLATION_REQUIRED", isolated_exit_required=74,
                scope="real C1 exception unwinding; no native partial-submit claim or recovery",
                post_fault_device_operations="NONE_BY_THIS_PROBE",
            ))
        finally:
            self._restore()


def check(document, campaign, launcher, expected, artifact):
    from tools.p7x_graph_repair5_evidence import audit_execution

    result = dict(status="INVALID_EVIDENCE", normal_reuse="UNPROVEN", native_partial_submission="NOT_SIMULATED")
    try:
        result["execution"] = audit_execution(document, campaign, launcher, expected, artifact, unwind=True)
        require(result["execution"]["status"] == "EXECUTION_ASSOCIATED", "unwind execution not associated")
        point = expected["unwind_point"]
        from tools.p7x_graph_repair5_evidence import method_from_expected

        method = method_from_expected(expected)
        require(document["schema"] == "repair8-python-unwind-v1" and document["point"] == point, "point/schema")
        record, state, guard = document["record"], document["state"], document["next_scope_guard"]
        require(record["injected_point"] == point, "injection point missing")
        require(campaign["exception_type"] == "InjectedGraphUnwindError", "unexpected original exception")
        require(campaign["exception_message"] == "REPAIR8_PYTHON_UNWIND:" + point, "exception mismatch")
        require(launcher["host_start_ns"] <= record["before_replay_ns"] <= record["injected_ns"]
                < guard["ns"] <= launcher["host_end_ns"], "unwind clock/launcher interval")
        require(
            record["descriptor"] in [[n, n * method.draft_query] for n in (1, 2, 4)],
            "not frozen real Draft descriptor",
        )
        if method.method == "dflash":
            require(record["generation_identity"]["normalized_method"] == "dflash", "unwind method mismatch")
        require(record["generation_identity"]["generation_id"] == record["generation"]
                and record["generation_identity"]["mapping_epoch"] == record["epoch"], "generation/epoch")
        require(state["quarantined_identity"] == record["generation_identity"], "quarantine identity")
        require(
            len(record["quarantine_calls"]) == 1
            and record["quarantine_calls"][0]["identity"] == record["generation_identity"],
            "actual C1 quarantine call",
        )
        require(state["active_backing_retained"] and state["live_inputs_cleared"]
                and state["proposal_context_cleared"] and state["graph_submission_uncertain"], "C1 state")
        require(guard["rejected"] and not guard["body_entered"]
                and "backing is quarantined" in guard["exception"], "next use not rejected at Host guard")
        require(document["post_fault_device_operations"] == "NONE_BY_THIS_PROBE", "post-fault device operations")
        require(record["replay_called"] is (point != "before_replay")
                and record["replay_returned"] is (point != "before_replay")
                and record["update_returned"] is (point in ["after_update", "after_completion"]), "submit branch")
        if point == "after_completion":
            require(record["completion"] == "DIAGNOSTIC_STREAM_DRAIN_BEFORE_EXCEPTION"
                    and record["update_return_ns"] <= record["complete_ns"] < record["injected_ns"], "diagnostic drain")
        else:
            require(record["completion"] == "UNPROVEN" and "complete_ns" not in record, "unexpected completion claim")
        result.update(status="PASS_SCOPED_PYTHON_UNWIND_ISOLATION", point=point, generation=record["generation"])
    except (ValueError, KeyError, TypeError, OSError) as error:
        result["error"] = str(error)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("artifact", "campaign", "launcher", "plan", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    result = check(json.loads(args.artifact.read_text()), json.loads(args.campaign.read_text()),
                   json.loads(args.launcher.read_text()), json.loads(args.plan.read_text())["cases"][args.case_id],
                   args.artifact)
    atomic_json(args.output, result)
    return 0 if result["status"] == "PASS_SCOPED_PYTHON_UNWIND_ISOLATION" else 4


if __name__ == "__main__":
    raise SystemExit(main())
