# SPDX-License-Identifier: Apache-2.0
"""Single-build experiment still owns exact current state and one real P6 publish."""
from dataclasses import replace
from types import SimpleNamespace

import pytest
from vllm.config.compilation import CUDAGraphMode
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor

from tests.ut.spec_decode.test_draft_window_graph_carrier import _materialize
from tests.ut.spec_decode.test_draft_window_graph_characterization import (
    _characterization_owner,
    _install_metadata_builder,
    _runtime_context,
)
from tests.ut.spec_decode.test_draft_window_eager import _harness
from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import (
    install_parallel_draft_window_graph_characterization,
    prepare_parallel_draft_window_graph_characterization,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_graph_metadata import (
    select_parallel_graph_metadata,
    defer_parallel_graph_metadata,
    validate_deferred_parallel_graph_metadata,
)


def prepared(monkeypatch):
    monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE", "0")
    owner, desc = _characterization_owner()
    session = install_parallel_draft_window_graph_characterization(owner, runtime_context=_runtime_context())
    inputs = _materialize(owner._draft_window_runtime_state, mapping_epoch=3)
    owner._draft_window_live_inputs = inputs
    owner._draft_window_proposal_context = SimpleNamespace(
        mapping_epoch=3,
        ordered_request_ids=inputs.identity.ordered_request_fingerprint,
    )
    owner._draft_window_single_metadata_enabled = True
    owner._draft_window_deferred_metadata = None
    select_parallel_graph_metadata(owner, desc)
    _install_metadata_builder(owner)
    return owner, desc, inputs, session


def test_real_p6_still_builds_and_publishes_one_metadata_before_replay(monkeypatch):
    owner, desc, inputs, session = prepared(monkeypatch)
    target = owner.model_state.attn_metadata
    calls = []
    original = owner._build_ascend_draft_attn_metadata

    def build(**kwargs):
        calls.append(kwargs["read_inputs"])
        return original(**kwargs)

    owner._build_ascend_draft_attn_metadata = build
    assert defer_parallel_graph_metadata(owner, inputs, padded_requests=4, padded_tokens=8)
    assert owner._draft_window_runtime_state.metadata_store._entry is None
    carrier = prepare_parallel_draft_window_graph_characterization(owner, desc)
    assert len(calls) == 1 and carrier.state.name == "BOUND"
    assert owner._draft_window_runtime_state.read_metadata(inputs.identity) is carrier.metadata
    assert owner.model_state.attn_metadata is target
    assert carrier.read_inputs.cpu_window_exact.tolist() == inputs.cpu_window_exact.tolist()
    assert carrier.read_inputs.cpu_window_exact.data_ptr() != inputs.cpu_window_exact.data_ptr()
    assert carrier.runtime_identity.generation_id == inputs.identity.generation_id


@pytest.mark.parametrize("damage", ["epoch", "requests", "bucket", "published", "live"])
def test_wrong_or_reused_selection_is_rejected(monkeypatch, damage):
    owner, desc, inputs, _ = prepared(monkeypatch)
    selection = owner._draft_window_selected_metadata
    if damage == "epoch": owner._draft_window_selected_metadata = replace(selection, mapping_epoch=99)
    if damage == "requests": owner._draft_window_selected_metadata = replace(selection, request_ids=("B", "A"))
    if damage == "bucket": owner._draft_window_selected_metadata = replace(selection, padded_tokens=16)
    if damage == "published": owner._draft_window_runtime_state.metadata_store._entry = object()
    if damage == "live": owner._draft_window_live_inputs = None
    with pytest.raises(RuntimeError):
        defer_parallel_graph_metadata(owner, inputs, padded_requests=4, padded_tokens=8)


def test_eager_and_default_off_do_not_defer_or_create_graph_ownership(monkeypatch):
    owner, desc, inputs, _ = prepared(monkeypatch)
    owner._draft_window_single_metadata_enabled = False
    assert not defer_parallel_graph_metadata(owner, inputs, padded_requests=4, padded_tokens=8)
    owner._draft_window_single_metadata_enabled = True
    select_parallel_graph_metadata(owner, BatchExecutionDescriptor(cg_mode=CUDAGraphMode.NONE, num_reqs=4,
                                                                   num_tokens=8))
    assert not defer_parallel_graph_metadata(owner, inputs, padded_requests=4, padded_tokens=8)
    with pytest.raises(RuntimeError, match="no actual dispatch"):
        validate_deferred_parallel_graph_metadata(owner, inputs, desc)


def test_real_eager_mixin_skips_only_unused_full_temporary_metadata(monkeypatch):
    owner, batch = _harness(query_width=2)
    # Apply-time upper includes query width 2: 191+2 covers actual exact 193.
    batch.seq_lens_cpu_upper_bound[0] = 191
    context = owner._draft_window_epoch_source.begin(batch)
    owner._draft_window_proposal_context = context
    owner._draft_window_single_metadata_enabled = True
    # The real source narrowing still validates/records current materialization;
    # this observer has no device reads and is not a fabricated Graph completion.
    owner._draft_window_graph_characterization = SimpleNamespace(observe_materialized=lambda inputs: None)
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph import install_draft_window_graph_binding_provider
    install_draft_window_graph_binding_provider(owner)
    desc = BatchExecutionDescriptor(cg_mode=CUDAGraphMode.FULL, num_reqs=4, num_tokens=8)
    select_parallel_graph_metadata(owner, desc)
    before = owner.input_buffers.seq_lens.clone()
    result = owner._build_draft_attn_metadata(
        num_reqs=2,
        num_reqs_padded=4,
        num_tokens_padded=8,
        seq_lens_cpu_upper_bound=batch.seq_lens_cpu_upper_bound,
        step=2,
    )
    assert result is None and owner.builder_events == []
    inputs = owner._draft_window_live_inputs
    assert inputs is owner._draft_window_runtime_state._active_inputs
    assert owner._draft_window_runtime_state.metadata_store._entry is None
    assert owner._draft_window_deferred_metadata == inputs.identity
    assert owner.input_buffers.seq_lens.equal(before)


@pytest.mark.parametrize("false_value", [False, "false", "0"])
def test_false_schema_value_never_enables_single_build(false_value):
    from vllm_ascend.ascend_config import AscendConfig
    assert AscendConfig(sparse_kv_offload_config=SimpleNamespace(enabled=False),
                        draft_window_graph_single_metadata=false_value).draft_window_graph_single_metadata is False


def test_performance_checker_does_not_mix_single_build_with_original_configuration(tmp_path):
    from tests.ut.spec_decode.test_graph_repair10_performance import specimen
    from tools.p7x_graph_repair10_performance import check
    campaign, launcher, profile, expected, artifact = specimen(tmp_path)
    campaign["llm_kwargs"]["additional_config"]["draft_window_graph_single_metadata"] = True
    result = check(campaign, launcher, profile, expected, artifact)
    assert result["status"] == "INVALID_EVIDENCE" and "own declared configuration" in result["error"]
    expected["single_metadata_experiment"] = True
    result = check(campaign, launcher, profile, expected, artifact)
    assert result["status"] == "PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE"
    campaign["llm_kwargs"]["additional_config"]["draft_window_graph_single_metadata"] = False
    assert check(campaign, launcher, profile, expected, artifact)["status"] == "INVALID_EVIDENCE"


def test_single_build_cli_is_explicit_and_wrong_arm_is_rejected(tmp_path):
    from tools.p7x_graph_repair2 import parse_args, build_llm_kwargs
    argv = [
        "run", "--case", "B-observer-off", "--case-id", "single-meta-host", "--run-id", "host-r", "--attempt", "1",
        "--expected-sha", "a" * 40, "--target-model", "target", "--draft-model", "draft", "--vllm-repo",
        str(tmp_path), "--fixture-manifest",
        str(tmp_path / "fixture.json"), "--output",
        str(tmp_path / "out"), "--repair14-single-metadata"
    ]
    args = parse_args(argv)
    assert build_llm_kwargs(args)["additional_config"]["draft_window_graph_single_metadata"] is True
    argv[argv.index("B-observer-off")] = "A0"
    with pytest.raises(SystemExit):
        parse_args(argv)


def test_variant_plan_preserves_original_cases_and_exact_launch_identity(tmp_path):
    import copy, json
    from tools.p7x_graph_repair14_single_metadata import add_cases
    cases = {}
    sources = ["NUMERIC_SENTINEL"]
    for workload in ("short", "long"):
        sources += [f"PERF10_G_ON_{workload}_{i:02}" for i in range(1, 4)] + [f"PROFILE10_G_ON_{workload}"]
    for name in sources:
        argv = ["python", "driver.py", "run", "--case-id", name]
        cases[name] = dict(case_id=name,
                           argv=argv,
                           launch_argv=["launcher", "--", *argv],
                           dependencies=["CONFIG", "B0"],
                           acceptance_identity=dict(case_id=name))
    original = copy.deepcopy(cases)
    assert add_cases(cases, tmp_path) == [] and cases == original
    profile = dict(schema="r5-single-metadata-v1", enabled=True, workloads=["short", "long"], repetitions=3)
    (tmp_path / "single-metadata-experiment.json").write_text(json.dumps(profile))
    variants = add_cases(cases, tmp_path)
    assert len(variants) == 9 and all(cases[k] == v for k, v in original.items())
    for name in variants:
        c = cases[name]
        assert c["argv"] == c["launch_argv"][c["launch_argv"].index("--") + 1:]
        assert c["case_id"] == c["acceptance_identity"]["case_id"] == name
        assert c["single_metadata_experiment"] is True
        if not name.startswith("NUMERIC"):
            assert c["dependencies"] == ["CONFIG", "B0", "NUMERIC_SINGLE_META_SENTINEL"]
    profile["repetitions"] = 999
    (tmp_path / "single-metadata-experiment.json").write_text(json.dumps(profile))
    with pytest.raises(ValueError, match="finite profile"):
        add_cases({}, tmp_path)
