# SPDX-License-Identifier: Apache-2.0
"""Explicit finite long profile; neither model RoPE nor original requests change."""
import copy
import json
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair18_long_context import add_cases, validate_model_capacity


def profile(tmp_path):
    marker = dict(schema="r5-long16-v1", max_model_len=24576, prompt_tokens=16385, output_tokens=512, repetitions=3)
    (tmp_path / "long-context-experiment.json").write_text(json.dumps(marker))
    (tmp_path / "requests").mkdir()
    (tmp_path / "requests/performance18-long16.json").write_text(
        json.dumps([dict(label="long16", max_tokens=512, prompts=[dict(prompt_token_ids=[17] * 16385)])]))
    cases = {}
    for arm in ("G_OFF", "G_ON", "E_ON"):
        for repeat in range(1, 5):
            name = f"PERF10_{arm}_long_{repeat:02}" if repeat < 4 else f"PROFILE10_{arm}_long"
            argv = [
                "python", "driver", "run", "--case-id", name, "--requests", "old-request", "--repair10-max-model-len",
                "12288"
            ]
            cases[name] = dict(argv=argv,
                               launch_argv=["python", "launch", "--", *argv],
                               request_path="old-request",
                               validation_commands=[dict(argv=["checker", name])],
                               performance_workload="long")
    return marker, cases


def test_finite_plan_preserves_old_cells_and_explicit_child_identity(tmp_path):
    _, cases = profile(tmp_path)
    old = copy.deepcopy(cases)
    names = add_cases(cases, tmp_path)
    assert len(names) == 12 and all(cases[k] == v for k, v in old.items())
    for name in names:
        c = cases[name]
        assert c["launch_argv"][c["launch_argv"].index("--") + 1:] == c["argv"]
        assert c["argv"][c["argv"].index("--repair10-max-model-len") + 1] == "24576"
        assert c["requests_sha256"] and "--repair18-long-context" in c["argv"]


@pytest.mark.parametrize("damage", ["bound", "rope", "position"])
def test_model_native_capacity_not_upper_bound_or_rope_override(tmp_path, damage):
    model = tmp_path / 'model'
    model.mkdir()
    config = dict(max_position_embeddings=40960, rope_scaling=None)
    args = SimpleNamespace(target_model=str(model), draft_model=str(model), repair10_max_model_len=24576)
    if damage == 'bound': args.repair10_max_model_len = 32768
    if damage == 'rope': config['rope_scaling'] = dict(factor=2.0)
    if damage == 'position': config['max_position_embeddings'] = 16384
    (model / 'config.json').write_text(json.dumps(config))
    with pytest.raises(ValueError):
        validate_model_capacity(args)
    config = dict(max_position_embeddings=40960, rope_scaling=None)
    (model / 'config.json').write_text(json.dumps(config))
    args.repair10_max_model_len = 24576
    validate_model_capacity(args)
