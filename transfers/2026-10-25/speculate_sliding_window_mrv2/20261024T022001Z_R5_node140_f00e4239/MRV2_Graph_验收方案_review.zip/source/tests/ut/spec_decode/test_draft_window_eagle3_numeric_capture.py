# SPDX-License-Identifier: Apache-2.0
"""Diagnostic copies are separately owned and absent from normal capture."""
from types import SimpleNamespace

import pytest
import torch

from tests.ut.spec_decode.test_draft_window_eagle3_capture import session_fixture
from tests.ut.spec_decode.test_draft_window_graph_carrier import _target_metadata
from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_diagnostics import Eagle3CaptureSnapshots


def snapshot_fixture():
    session, owner = session_fixture()
    owner.device = torch.device("cpu")
    owner.attn_backend = SimpleNamespace(forward_includes_kv_cache_update=True)
    owner.draft_attn_layer_names = {"draft.layers.0.self_attn"}
    owner.input_buffers = SimpleNamespace(
        input_ids=torch.arange(16, dtype=torch.int32),
        positions=torch.arange(16, dtype=torch.int64),
        seq_lens=torch.tensor([32, 32, 32, 0], dtype=torch.int32),
        query_start_loc=torch.tensor([0, 4, 8, 12, 12], dtype=torch.int32),
    )
    owner.hidden_states = torch.ones((16, 8), dtype=torch.bfloat16)
    owner.target_input_buffers = SimpleNamespace(positions=torch.arange(16, dtype=torch.int64) + 100)
    owner.last_token_indices = torch.tensor([0, 4, 8, 0], dtype=torch.int64)
    caches = [torch.arange(32 * 64 * 2 * 4, dtype=torch.float32).reshape(32, 64, 2, 4)]
    owner.draft_vllm_config = SimpleNamespace(compilation_config=SimpleNamespace(
        static_forward_context={"draft.layers.0.self_attn": SimpleNamespace(kv_cache=caches)}))
    return session, owner, caches


@pytest.mark.parametrize("value", [False, "false"])
def test_default_and_string_false_install_no_device_copy_program(monkeypatch, value):
    session, owner = session_fixture()
    owner.vllm_config = SimpleNamespace(additional_config=dict(draft_window_graph_numeric_diagnostic=value))
    import vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_diagnostics as module

    def forbidden(*args, **kwargs):
        raise AssertionError("normal Graph must not install numeric copies")

    monkeypatch.setattr(module, "Eagle3CaptureSnapshots", forbidden)
    session.initialize_numeric_capture()
    assert session.numeric_snapshots is None


def test_per_consumer_indices_and_copies_do_not_alias_model_inputs_or_kv(monkeypatch):
    session, owner, caches = snapshot_fixture()
    snapshots = Eagle3CaptureSnapshots(owner, session._captures)
    identity = session.resolve(first=True, n=4, tokens=16, ordinal=0)
    snapshots.set_indices_before_replay((identity, ), [0, 1, 8])

    def forbidden(*args, **kwargs):
        raise AssertionError("no dummy H2D/initialization in capture callback")

    with monkeypatch.context() as patch:
        patch.setattr(torch.Tensor, "copy_", forbidden)
        patch.setattr(torch.Tensor, "fill_", forbidden)
        patch.setattr(torch.Tensor, "zero_", forbidden)
        snapshots.before_model(identity, _target_metadata(), {"draft.layers.0.self_attn": torch.arange(16) + 999})
    state = snapshots.states[identity]
    assert state.before["actual_slots"]["draft.layers.0.self_attn"].equal(
        _target_metadata()["draft.layers.0.self_attn"].slot_mapping[:16])
    assert state.before["forward_context_slots"]["draft.layers.0.self_attn"].equal(torch.arange(16) + 999)
    original_inputs = owner.input_buffers.input_ids.clone()
    assert state.before["inputs"]["target_positions"].equal(owner.target_input_buffers.positions)
    assert state.before["inputs"]["last_token_indices"].equal(owner.last_token_indices)
    assert state.before["inputs"]["target_positions"].data_ptr() != owner.target_input_buffers.positions.data_ptr()
    assert state.before["inputs"]["last_token_indices"].data_ptr() != owner.last_token_indices.data_ptr()
    owner.input_buffers.input_ids.add_(100)
    assert state.before["inputs"]["input_ids"].equal(original_inputs)
    assert state.before["inputs"]["input_ids"].data_ptr() != owner.input_buffers.input_ids.data_ptr()
    assert state.before["kv"]["draft.layers.0.self_attn/0"][1].equal(caches[0][1])
    caches[0][1].add_(1)
    snapshots.after_model(identity)
    assert not state.after["draft.layers.0.self_attn/0"][1].equal(state.before["kv"]["draft.layers.0.self_attn/0"][1])
    assert len({state.indices.data_ptr() for state in snapshots.states.values()}) == 3


def test_device_copy_budget_missing_layers_and_wrong_physical_indices_reject():
    session, owner, _ = snapshot_fixture()
    with pytest.raises(ValueError, match="device budget"):
        Eagle3CaptureSnapshots(owner, session._captures, max_device_bytes=1)
    snapshots = Eagle3CaptureSnapshots(owner, session._captures)
    identity = session.resolve(first=True, n=4, tokens=16, ordinal=0)
    for indices in ([1, 1], [1, 0], [-1], [32]):
        with pytest.raises(ValueError):
            snapshots.set_indices_before_replay((identity, ), indices)
    with pytest.raises(RuntimeError, match="full slot"):
        snapshots.before_model(identity, _target_metadata(), {})


def test_nonzero_global_group_uses_its_actual_full_table():
    from dataclasses import replace
    session, owner, _ = snapshot_fixture()
    old = owner.block_tables.input_block_tables[0]
    owner.block_tables.input_block_tables = [old, old + 7]
    captures = {
        key: replace(identity, fingerprint=replace(identity.fingerprint, global_group_id=1))
        for key, identity in session._captures.items()
    }
    snapshots = Eagle3CaptureSnapshots(owner, captures)
    identity = next(iter(captures.values()))
    n, tokens = identity.fingerprint.padded_request_count, identity.fingerprint.padded_token_count
    snapshots.before_model(identity, _target_metadata(), {"draft.layers.0.self_attn": torch.arange(tokens)})
    assert snapshots.global_group_id == 1
    assert snapshots.states[identity].before["canonical_table"].equal(owner.block_tables.input_block_tables[1][:n])


def test_captured_d2d_keeps_exact_source_tensor_alive_after_metadata_scope_ends():
    import gc
    import weakref
    session, owner, _ = snapshot_fixture()
    snapshots = Eagle3CaptureSnapshots(owner, session._captures)
    identity = session.resolve(first=True, n=4, tokens=16, ordinal=0)
    metadata = _target_metadata()
    layer = metadata["draft.layers.0.self_attn"]
    source = layer.query_start_loc
    weak = weakref.ref(source)
    snapshots.before_model(identity, metadata, {"draft.layers.0.self_attn": torch.arange(16)})
    # A captured clone is a replay-time read from the original address. The
    # clone output alone is not ownership of that source allocation.
    layer.query_start_loc = torch.full_like(source, 999)
    del source, layer, metadata
    gc.collect()
    assert weak() is not None, "captured diagnostic D2D source lost its Python/storage owner"
    assert any(t is weak() for t in snapshots.states[identity].capture_sources)
