# SPDX-License-Identifier: Apache-2.0
"""Rank-local P6 contracts; these CPU tests do not enable a TP16 product route."""
from dataclasses import replace
from types import SimpleNamespace

import pytest
import torch

from tests.ut.spec_decode.test_draft_window_graph_carrier import (
    _bind_read_carrier,
    _fingerprint,
    _materialize,
    _register,
    _runtime_fixture,
    _target_metadata,
)
from vllm_ascend.device.hardware_profile import AttentionBackendFamily
from vllm_ascend.worker.v2.spec_decode.draft_window import build_draft_window_runtime_state
from vllm_ascend.worker.v2.spec_decode.draft_window_eager_capability import P7EagerTopologyFingerprint
from vllm_ascend.worker.v2.spec_decode.draft_window_graph import install_draft_window_graph_binding_provider
from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import validate_base_graph_characterization_context


def rank_runtime(world, rank, physical_offset=0):
    _, capability, tables = _runtime_fixture()
    tables.input_block_tables[0].add_(physical_offset)
    fp = replace(_fingerprint(), tensor_parallel_size=world, tensor_parallel_rank=rank)
    topology = P7EagerTopologyFingerprint(
        normalized_method=fp.method,
        runtime_route=fp.method,
        attention_backend_family=AttentionBackendFamily.STANDARD,
        backend_impls=(fp.backend_impl, ),
        builder_impls=(fp.builder_impl, ),
        global_group_ids=(fp.global_group_id, ),
        layouts=(fp.layout, ),
        block_geometry=((fp.logical_block_size, fp.kernel_block_size, fp.block_span_tokens), ),
        tensor_parallel_size=world,
        tensor_parallel_rank=rank,
        parallel_read_semantics="replicated",
        data_parallel_size=1,
        pipeline_parallel_size=1,
        prefill_context_parallel_size=1,
        decode_context_parallel_size=1,
        sequence_parallel=False,
        dsa_context_parallel=False,
        flashcomm=False,
        graph_mode="FULL",
        async_scheduling=False,
        prefix_caching=False,
        provider_version=1,
        execution_lane=0,
    )
    capability = replace(capability, eager_topology_fingerprint=topology)
    runtime = build_draft_window_runtime_state(capability)
    provider = install_draft_window_graph_binding_provider(SimpleNamespace(_draft_window_runtime_state=runtime))
    return runtime, provider, fp


@pytest.mark.parametrize("world", [2, 4, 16])
def test_replicated_rank_local_carriers_keep_full_logical_lengths(world):
    copies = []
    for rank in [0, world - 1]:
        runtime, provider, fingerprint = rank_runtime(world, rank, rank * 1000)
        capture = _register(provider, fingerprint=fingerprint)
        inputs = _materialize(runtime, mapping_epoch=10)
        bound = _bind_read_carrier(provider, runtime, capture, inputs, _target_metadata())
        assert capture.provider_schema_version == 3
        identity = bound.runtime_identity
        assert (identity.tensor_parallel_size, identity.tensor_parallel_rank,
                identity.parallel_read_semantics) == (world, rank, "replicated")
        # Logical lengths are replicated, never divided by TP. Physical tables
        # and ownership remain local; no tensor or address is shared by ranks.
        assert bound.read_inputs.cpu_window_exact.tolist() == [96, 64, 0, 0]
        copies.append(bound.read_inputs.window_block_table.clone())
    assert not torch.equal(copies[0], copies[1])


def test_missing_p2_identity_never_infers_tp16():
    runtime, _, _ = _runtime_fixture()
    provider = install_draft_window_graph_binding_provider(SimpleNamespace(_draft_window_runtime_state=runtime))
    with pytest.raises(RuntimeError, match="capture/P2 TP"):
        _register(provider, fingerprint=replace(_fingerprint(), tensor_parallel_size=16))


def test_rank_zero_capture_cannot_bind_as_rank_one():
    runtime, provider, fp = rank_runtime(16, 0)
    capture = _register(provider, fingerprint=fp)
    forged = replace(capture, fingerprint=replace(fp, tensor_parallel_rank=1))
    with pytest.raises(RuntimeError, match="TP rank"):
        _bind_read_carrier(provider, runtime, forged, _materialize(runtime, mapping_epoch=10), _target_metadata())


def test_world_drift_is_rejected_before_bank_copy():
    runtime, provider, fp = rank_runtime(16, 0)
    capture = _register(provider, fingerprint=fp)
    inputs = _materialize(runtime, mapping_epoch=10)
    before = provider.startup_capture_read_inputs(capture).window_block_table.clone()
    runtime.capability = replace(runtime.capability,
                                 eager_topology_fingerprint=replace(runtime.capability.eager_topology_fingerprint,
                                                                    tensor_parallel_size=8))
    with pytest.raises(RuntimeError, match="P2/runtime TP identity drift"):
        _bind_read_carrier(provider, runtime, capture, inputs, _target_metadata())
    assert torch.equal(before, provider.startup_capture_read_inputs(capture).window_block_table)


@pytest.mark.parametrize("rank", [-1, 16, True])
def test_invalid_rank_is_not_a_valid_capture(rank):
    with pytest.raises(ValueError, match="TP rank"):
        replace(_fingerprint(), tensor_parallel_size=16, tensor_parallel_rank=rank)


def test_replicated_contract_rejects_partitioned_read_semantics():
    with pytest.raises(ValueError, match="replicated"):
        replace(_fingerprint(), parallel_read_semantics="dcp_interleaved")


def test_runtime_product_tp16_gate_is_still_closed():
    context = SimpleNamespace(attention_backend_family=AttentionBackendFamily.STANDARD,
                              graph_mode="FULL_DECODE_ONLY",
                              async_scheduling=False,
                              tensor_parallel_size=16,
                              data_parallel_size=1,
                              pipeline_parallel_size=1,
                              prefill_context_parallel_size=1,
                              decode_context_parallel_size=1)
    with pytest.raises(NotImplementedError, match="requires TP=1"):
        validate_base_graph_characterization_context(context)


@pytest.mark.parametrize("rank", [False, 0.0])
def test_malformed_p2_rank_is_rejected_before_allocation(rank):
    runtime, provider, fingerprint = rank_runtime(16, 0)
    runtime.capability = replace(runtime.capability,
                                 eager_topology_fingerprint=replace(runtime.capability.eager_topology_fingerprint,
                                                                    tensor_parallel_rank=rank))
    with pytest.raises(RuntimeError, match="explicit integers"):
        _register(provider, fingerprint=fingerprint)


def test_binding_identity_cannot_hide_a_boolean_rank():
    runtime, provider, fingerprint = rank_runtime(16, 0)
    capture = _register(provider, fingerprint=fingerprint)
    bound = _bind_read_carrier(provider, runtime, capture, _materialize(runtime, mapping_epoch=10), _target_metadata())
    with pytest.raises(ValueError, match="explicit integers"):
        replace(bound.runtime_identity, tensor_parallel_rank=False)


@pytest.mark.parametrize("rank", [False, 0.0])
def test_runtime_rank_type_drift_is_not_hidden_by_python_equality(rank):
    runtime, provider, fingerprint = rank_runtime(16, 0)
    runtime.topology_fingerprint = replace(runtime.topology_fingerprint, tensor_parallel_rank=rank)
    with pytest.raises(RuntimeError, match="P2/runtime TP identity drift"):
        _register(provider, fingerprint=fingerprint)
