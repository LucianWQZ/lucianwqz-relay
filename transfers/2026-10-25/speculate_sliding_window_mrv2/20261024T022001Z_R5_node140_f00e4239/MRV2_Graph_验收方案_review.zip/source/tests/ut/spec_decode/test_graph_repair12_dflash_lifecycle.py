# SPDX-License-Identifier: Apache-2.0
"""Exact Q16/K15 diagnostic contracts; no weakening of DSpark or completion."""

import copy
import hashlib
import json
from pathlib import Path

import pytest

from tests.ut.spec_decode.test_graph_repair5_contracts import token_joint
from tools.p7x_graph_repair4_acceptance import audit_joint
from tools.p7x_graph_repair5_evidence import method_from_expected
from tools.p7x_graph_repair5_lifecycle import check_lifecycle
from tools.p7x_graph_repair12_contract import method_for_profile


def actual_structure():
    return json.loads((Path(__file__).parent / "data/repair12_dflash_lifecycle_excerpt.json").read_text())


def test_actual_c38_lifecycle_is_k15_with_q16_and_rejects_wrong_contract():
    document = actual_structure()
    assert check_lifecycle(document)["status"] == "INVALID_EVIDENCE"
    result = check_lifecycle(document, profile="dflash_k15_q16")
    assert result["status"] == "STRUCTURE_VALID_NOT_EXECUTION_ACCEPTED", result
    assert result["generations"] == 3
    assert result["normal_overlap"] == "UNPROVEN"


@pytest.mark.parametrize("damage", ["descriptor", "k", "order", "epoch", "completion", "backing", "event"])
def test_actual_c38_structure_rejects_corruption(damage):
    document = actual_structure()
    record = document["records"][0]
    if damage == "descriptor":
        record["descriptor"] = [1, 7]
    elif damage == "k":
        record["token_shape"] = [1, 7]
        record["draft_tokens"][0] = record["draft_tokens"][0][:7]
    elif damage == "order":
        record["complete_ns"] = record["before_replay_ns"] - 1
    elif damage == "epoch":
        document["records"][1]["epoch"] = 0
    elif damage == "completion":
        record["completion"] = "HOST_RETURN"
    elif damage == "backing":
        document["records"][1]["backing"]["device_window_exact"]["data_ptr"] += 128
    else:
        record["consumer_event_kind"] = "torch.npu.ExternalEvent"
    assert check_lifecycle(document, profile="dflash_k15_q16")["status"] == "INVALID_EVIDENCE"


def test_named_64_token_request_contract_does_not_change_frozen_16():
    campaign, launcher, raw, expected = token_joint()
    requests = json.loads(raw)
    for request, output in zip(requests, campaign["outputs"]):
        request["max_tokens"] = 64
        output["token_ids"] = [[7] * 64 for _ in request["prompts"]]
    raw = json.dumps(requests).encode()
    checksum = hashlib.sha256(raw).hexdigest()
    campaign["request_manifest"] = dict(entries=requests, sha256=checksum)
    launcher["requests_sha256"] = expected["requests_sha256"] = checksum
    assert audit_joint(campaign, launcher, raw, expected)["status"] == "INVALID_EVIDENCE"
    expected["normal_request_contract"] = "dflash_k15_q16_lifecycle_64"
    assert audit_joint(campaign, launcher, raw, expected)["status"] == "PASS"
    campaign["outputs"][0]["token_ids"][0].pop()
    assert audit_joint(campaign, launcher, raw, expected)["status"] == "FAIL"


def test_method_cannot_be_inferred_from_the_observed_descriptor():
    expected = dict(capture_profile="dflash_k15_q16", method_contract=method_for_profile("dflash_k15_q16").document())
    assert method_from_expected(expected).draft_query == 16
    broken = copy.deepcopy(expected)
    broken["method_contract"]["k"] = 7
    with pytest.raises(ValueError):
        method_from_expected(broken)
    with pytest.raises(KeyError):
        method_from_expected(dict(capture_profile="dflash_k15_q16"))


def test_method_fault_cases_preserve_exact_points_and_dedicated_checks(tmp_path):
    from tools.p7x_graph_repair12_contract import add_cases

    (tmp_path / "requests").mkdir()
    for name in ("dflash-controlled", "dflash-lifecycle"):
        (tmp_path / "requests" / f"{name}.json").write_text("[]")
    (tmp_path / "dflash-k15-q16-fixture.json").write_text(json.dumps(dict(draft_model="declared-dflash")))
    cases = {}
    points = ("before_replay", "after_replay", "after_update", "after_completion")
    names = ["NUMERIC_SENTINEL", "NUMERIC_TARGET4", "TARGET4_OFF", "LIFE"]
    names += [f"{kind}_{point}" for kind in ("ABORT", "UNWIND") for point in points]
    for name in names:
        argv = [
            "python", "p7x_graph_repair2.py", "run",
            "--requests", str(tmp_path / name), "--output", str(tmp_path / name),
        ]
        if name.startswith(("ABORT_", "UNWIND_")):
            kind, point = name.split("_", 1)
            argv += ["--repair5-abort-at" if kind == "ABORT" else "--repair8-unwind-at", point]
        cases[name] = dict(argv=argv, launch_argv=["launcher", "--", *argv],
                           acceptance_identity=dict(case_id=name),
                           lifecycle_coverage=dict(descriptors=[]),
                           validation_commands=[dict(argv=["dedicated-checker", name, str(tmp_path / name)])])
    add_cases(cases, tmp_path, tmp_path, tmp_path, "python")
    for kind in ("ABORT", "UNWIND"):
        for point in points:
            name = f"{kind}_DFLASH_{point}"
            case = cases[name]
            assert case["dependencies"] == ["DFLASH_LIFE"]
            assert case["launch_argv"][2:] == case["argv"]
            assert case["argv"][case["argv"].index("--repair5-capture-profile") + 1] == "dflash_k15_q16"
            option = "--repair5-abort-at" if kind == "ABORT" else "--repair8-unwind-at"
            assert case["argv"][case["argv"].index(option) + 1] == point
            assert case["validation_commands"][0]["argv"][1] == name
            assert case["method_contract"]["k"] == 15
