# SPDX-License-Identifier: Apache-2.0
"""Q16 real Python capture/producer/storage/checker CPU contract; native services mocked."""

import copy

import pytest
import torch

from tests.ut.spec_decode.test_graph_repair6_numeric_pipeline import joined, produce
from tools.p7x_graph_repair5_target import case_plan
from tools.p7x_graph_repair6 import joint
from tools.p7x_graph_repair6_numeric_check import validate_sample
from tools.p7x_graph_repair6_storage import CollectionReader
from tools.p7x_graph_repair12_contract import method_for_profile, validate_method_document


@pytest.mark.parametrize("limit", [None, 3])
def test_dflash_actual_q16_capture_reference_storage_joint(monkeypatch, tmp_path, limit):
    path, contract, snapshot = produce(monkeypatch, tmp_path, sample_limit=limit, profile="dflash_k15_q16")
    campaign, launcher, plan = joined(path, contract, snapshot)
    if limit:
        plan["numeric_samples"] = 3
        plan["argv"] += ["--repair6-target-prefix", "3"]
        plan["launch_argv"] += ["--repair6-target-prefix", "3"]
        launcher["argv"] = plan["argv"]
    result = joint(path, campaign, launcher, plan, "numeric")
    assert result["status"] == ("PASS_NUMERIC_SENTINEL_ONLY" if limit else "PASS_DIAGNOSTIC_CONTINUOUS_REFERENCE"), (
        result
    )
    assert result["aba"] == "PASS_SCOPED"
    reader = CollectionReader(path)
    assert len(reader.samples) == (3 if limit else 14)
    if not limit:
        r = reader.record(10)
        assert r["descriptor"] == [4, 64] and r["target_descriptor"] == [4, 64]
        assert r["inputs"]["query_start_loc"].tolist() == [0, 16, 32, 48, 48]
        assert r["actual_metadata"][contract["draft_layers"][0]]["query"] == [16, 32, 48, 64]
    # Valid current-generation bytes pass, precise damaged contracts do not.
    r = reader.record(0)
    case = case_plan("dflash_k15_q16")[0]
    assert r["sampling_state"]["sample_idx_mapping"].dtype == torch.int32
    assert validate_sample(r, reader.header, case)["status"] == "PASS"
    for field in ("ids_dtype", "positions_dtype", "offset", "mapping_dtype", "exact", "metadata", "contract"):
        bad, header = copy.deepcopy(r), copy.deepcopy(reader.header)
        if field == "ids_dtype":
            bad["inputs"]["input_ids"] = bad["inputs"]["input_ids"].long()
        elif field == "positions_dtype":
            bad["inputs"]["positions"] = bad["inputs"]["positions"].int()
        elif field == "offset":
            bad["sampling_state"]["sample_indices"][0] = 0
        elif field == "mapping_dtype":
            bad["sampling_state"]["sample_idx_mapping"] = bad["sampling_state"]["sample_idx_mapping"].long()
        elif field == "exact":
            bad["exact"][0] -= 1
        elif field == "metadata":
            bad["actual_metadata"][contract["draft_layers"][0]]["causal"] = True
        else:
            header["provenance"]["method_contract"]["k"] = 7
        with pytest.raises(ValueError):
            validate_sample(bad, header, case)


def test_method_contract_strict_and_scenario_boundaries():
    m = method_for_profile("dflash_k15_q16")
    assert (m.k, m.draft_query, m.target_query, m.sample_offset) == (15, 16, 16, 1)
    assert method_for_profile("target4").draft_query == 7
    d = m.document()
    d["sample_from_anchor"] = 0
    with pytest.raises(ValueError):
        validate_method_document("dflash_k15_q16", d)
    cases = case_plan("dflash_k15_q16")
    assert len(cases) == 14 and cases[-2]["ends"][0] + 16 == 1024 and cases[-1]["ends"][0] + 16 == 1152


def test_fixed_fixture_receipt_rejects_changed_source_hash_or_file_version(tmp_path):
    import hashlib
    import json
    from types import SimpleNamespace

    from tools.p7x_graph_repair12_contract import verify_fixture_receipt

    data = tmp_path / "weights.bin"
    data.write_bytes(b"declared synthetic test payload")
    fixture = {"files": [{"path": str(data), "sha256": hashlib.sha256(data.read_bytes()).hexdigest()}]}
    manifest = tmp_path / "fixture.json"
    manifest.write_text(json.dumps(fixture))
    st = data.stat()
    receipt = dict(
        source_sha="a" * 40,
        fixture_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
        files=[dict(path=str(data), sha256=fixture["files"][0]["sha256"], size=st.st_size, mtime_ns=st.st_mtime_ns)],
    )
    proof = tmp_path / "proof.json"
    proof.write_text(json.dumps(receipt))
    args = SimpleNamespace(
        repair12_fixture_verification=proof,
        repair12_fixture_verification_sha256=hashlib.sha256(proof.read_bytes()).hexdigest(),
        expected_sha="a" * 40,
        fixture_manifest=manifest,
    )
    assert verify_fixture_receipt(args, fixture)["source_sha"] == args.expected_sha
    args.expected_sha = "b" * 40
    with pytest.raises(ValueError, match="source/manifest"):
        verify_fixture_receipt(args, fixture)
    args.expected_sha = "a" * 40
    data.write_bytes(b"changed")
    with pytest.raises(ValueError, match="changed since"):
        verify_fixture_receipt(args, fixture)
    proof.write_text("{}")
    with pytest.raises(ValueError, match="receipt hash"):
        verify_fixture_receipt(args, fixture)


def test_explicit_dflash_plan_preserves_launcher_and_method_identity(tmp_path):
    import json

    from tools.p7x_graph_repair12_contract import add_cases

    (tmp_path / "requests").mkdir()
    for name in ("dflash-controlled", "dflash-lifecycle"):
        (tmp_path / "requests" / (name + ".json")).write_text("[]")
    (tmp_path / "dflash-k15-q16-fixture.json").write_text(json.dumps(dict(draft_model="independent-dflash")))
    cases = {}
    for name in ("NUMERIC_SENTINEL", "NUMERIC_TARGET4", "TARGET4_OFF", "LIFE"):
        argv = [
            "python",
            "driver",
            "run",
            "--draft-model",
            "dspark",
            "--fixture-manifest",
            "old",
            "--repair5-capture-profile",
            "target4",
            "--requests",
            "old",
            "--output",
            str(tmp_path / name),
        ]
        cases[name] = dict(
            argv=argv,
            launch_argv=[
                "python",
                "launcher",
                "--output",
                str(tmp_path / "launchers" / name),
                "--case-id",
                name,
                "--",
                *argv,
            ],
            validation_commands=[dict(argv=["checker", str(tmp_path / name)])],
            acceptance_identity=dict(case_id=name),
            lifecycle_coverage=dict(descriptors=[]),
        )
    add_cases(cases, tmp_path, tmp_path, tmp_path, "python")
    for name in ("DFLASH_NUMERIC_SENTINEL", "NUMERIC_DFLASH", "DFLASH_OFF", "DFLASH_LIFE"):
        c = cases[name]
        assert c["launch_argv"][c["launch_argv"].index("--") + 1 :] == c["argv"]
        assert c["capture_profile"] == "dflash_k15_q16"
        assert c["method_contract"]["draft_query"] == c["method_contract"]["target_query"] == 16
        assert c["fixture_sha256"] and c["requests_sha256"]
    assert cases["DFLASH_LIFE"]["lifecycle_coverage"]["descriptors"] == [[1, 16], [2, 32], [4, 64]]


def test_fixture_receipt_flags_only_reach_the_actual_controlled_driver(tmp_path):
    from tools.p7x_graph_repair12_contract import attach_fixture_verification

    cases = {}
    for name, program, command in (
        ("numeric", "p7x_graph_repair2.py", "run"),
        ("anchor", "p7x_graph_repair11_method_anchor.py", "run"),
        ("config", "p7x_graph_repair11_method_anchor.py", "config"),
    ):
        argv = ["python", program, command]
        cases[name] = dict(capture_profile="dflash_k15_q16", argv=argv, launch_argv=["python", "launcher", "--", *argv])
    attach_fixture_verification(cases, tmp_path / "proof.json", "a" * 64)
    assert "--repair12-fixture-verification" in cases["numeric"]["argv"]
    assert cases["numeric"]["launch_argv"][3:] == cases["numeric"]["argv"]
    assert cases["anchor"]["argv"] == ["python", "p7x_graph_repair11_method_anchor.py", "run"]
    assert cases["config"]["argv"] == ["python", "p7x_graph_repair11_method_anchor.py", "config"]


def test_pinned_dflash_constructor_allocates_exact_sampling_dtypes(monkeypatch):
    from types import SimpleNamespace

    import vllm.model_executor.models.qwen3_dflash as model
    import vllm.v1.worker.gpu.spec_decode.dflash.speculator as upstream

    def base_init(owner, *_):
        owner.max_num_tokens, owner.hidden_size = 64, 2
        owner.max_num_reqs, owner.num_speculative_steps = 4, 15
        owner.dtype = torch.bfloat16
        owner.draft_model_config = SimpleNamespace(hf_config=SimpleNamespace(dflash_config={}))

    monkeypatch.setattr(upstream.DraftModelSpeculator, "__init__", base_init)
    monkeypatch.setattr(upstream, "get_parallel_drafting_token_id", lambda _: 17)
    monkeypatch.setattr(model, "dflash_has_any_non_causal", lambda _: True)
    owner = upstream.DFlashSpeculator(SimpleNamespace(), torch.device("cpu"))
    assert owner.sample_idx_mapping.dtype == torch.int32
    assert owner.sample_col.dtype == torch.int32
    assert owner.sample_indices.dtype == owner.sample_pos.dtype == torch.int64
    assert owner.num_query_per_req == 16 and owner.sample_from_anchor is False
