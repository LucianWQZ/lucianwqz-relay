# SPDX-License-Identifier: Apache-2.0
"""Host evidence fixtures, not real model or native fault evidence."""
import copy
import json
import subprocess
import sys
from pathlib import Path

import pytest

from tools.p7x_graph_repair19_eagle_unwind import POINTS, check
from tools.p7x_graph_repair5_evidence import file_sha
from tools.p7x_graph_repair6_runner import adjudicate_records


def test_direct_checker_cli_avoids_real_stdlib_bisect_shadow(tmp_path):
    script = Path(__file__).resolve().parents[3] / "tools/p7x_graph_repair19_eagle_unwind.py"
    result = subprocess.run([sys.executable, str(script), "--help"],
                            cwd=tmp_path,
                            capture_output=True,
                            text=True,
                            timeout=60)
    assert result.returncode == 0, result.stderr
    assert "--artifact" in result.stdout and "--plan" in result.stdout


def fixture(tmp_path, point):
    identity = dict(run_id="host-only",
                    case_id="UNWIND_EAGLE3_" + point,
                    attempt_id="1",
                    source_sha="a" * 40,
                    source_tree="b" * 40,
                    driver_mode="B-observer-off",
                    process_id=42,
                    engine_id=43)
    steps = [] if point == "before_first_replay" else [0] if point == "after_first_update" else [0, 1, 2]
    query = 4 if point in POINTS[:2] else 1
    document = dict(schema="r5-eagle-unwind-v1",
                    identity=identity,
                    exception_type="InjectedEagle3UnwindError",
                    exception_message="REPAIR19_EAGLE_UNWIND:" + point,
                    record=dict(point=point,
                                ns=20,
                                epoch=11,
                                request_ids=["r"],
                                descriptor=[1, query],
                                transfers=[dict(step=s, mapping_epoch=11, generation=30 + s) for s in steps],
                                backing_address=1000,
                                carrier_states=["UPDATED"] * len(steps),
                                capture_identity=dict(fingerprint=dict(
                                    method="eagle3",
                                    capture_bucket=[1, query],
                                    query_width=query,
                                    route="eagle3_first_pass" if query == 4 else "eagle3_ar_step"),
                                                      consumer_ordinal=0,
                                                      backing_identity=dict(window_block_table=dict(data_ptr=1000))),
                                explicit_diagnostic_drain_complete=point == "after_diagnostic_completion",
                                submission_scope="HOST_TEST_NOT_DEVICE"),
                    state=dict(quarantined=True,
                               proposal_context_absent=True,
                               live_inputs_absent=True,
                               graph_submission_uncertain=True),
                    next_scope_guard=dict(ns=30, rejected=True, body_entered=False, error="backing quarantined"),
                    post_fault_manager_calls=0,
                    post_fault_device_operations="NONE_BY_PROBE",
                    native_partial_submission="NOT_SIMULATED")
    path = tmp_path / "eagle-unwind.json"
    path.write_text(json.dumps(document))
    campaign = dict(identity=identity,
                    status="EXCEPTION",
                    startup_complete=True,
                    exception_type=document["exception_type"],
                    exception_message=document["exception_message"],
                    diagnostic_quarantine="PROCESS_EXIT_74_NO_REUSE",
                    request_manifest=dict(sha256="c" * 64),
                    diagnostic_artifacts={path.name: dict(bytes=path.stat().st_size, sha256=file_sha(path))})
    launcher = dict(identity,
                    argv=["python", "producer"],
                    pid=42,
                    requests_sha256="c" * 64,
                    host_start_ns=10,
                    host_end_ns=40,
                    status="EXITED",
                    signal=None,
                    timeout=False,
                    returncode=74)
    expected = dict(acceptance_identity=identity,
                    argv=launcher["argv"],
                    launch_argv=["launch", "--", *launcher["argv"]],
                    outputs=str(tmp_path),
                    requests_sha256="c" * 64,
                    eagle3_unwind_point=point)
    return document, campaign, launcher, expected, path


@pytest.mark.parametrize("point", POINTS)
def test_external_process_and_point_specific_quarantine_contract(tmp_path, point):
    args = fixture(tmp_path, point)
    assert check(*args)["status"] == "PASS_SCOPED_EAGLE3_PYTHON_UNWIND"


@pytest.mark.parametrize(
    "damage",
    ["exit", "signal", "timeout", "pid", "point", "epoch", "bank", "guard", "sync", "error", "update", "route"])
def test_exit_74_and_self_report_are_not_enough(tmp_path, damage):
    d, c, l, e, p = fixture(tmp_path, "after_ar_update")
    if damage == "exit": l["returncode"] = 0
    if damage == "signal": l["signal"] = 11
    if damage == "timeout": l["timeout"] = True
    if damage == "pid": l["pid"] = 99
    if damage == "point": d["record"]["point"] = "after_first_update"
    if damage == "epoch": d["record"]["transfers"][1]["mapping_epoch"] = 10
    if damage == "bank": d["record"]["backing_address"] = 2000
    if damage == "guard": d["next_scope_guard"]["body_entered"] = True
    if damage == "sync": d["post_fault_device_operations"] = "RECOVERED_WITH_SYNC"
    if damage == "error": c["exception_type"] = "UnknownNativeError"
    if damage == "update": d["record"]["carrier_states"][1] = "SUBMITTED"
    if damage == "route": d["record"]["capture_identity"]["fingerprint"]["route"] = "eagle3_first_pass"
    assert check(d, c, l, e, p)["status"] != "PASS_SCOPED_EAGLE3_PYTHON_UNWIND"


def test_runner_requires_matching_named_case_and_dedicated_checker():
    point = "after_ar_update"
    name = "UNWIND_EAGLE3_" + point
    plan = dict(cases={name: dict(eagle3_unwind_point=point)})
    records = [
        dict(returncode=74, timeout=False, kind="launch", status="EXITED", argv=["producer"]),
        dict(returncode=0,
             timeout=False,
             kind="read_only_acceptance",
             status="EXITED",
             argv=["python", "p7x_graph_repair19_eagle_unwind.py"])
    ]
    assert adjudicate_records(plan, name, records)["dependency_satisfied"]
    assert not adjudicate_records(plan, name, records[:1])["dependency_satisfied"]
    wrong = copy.deepcopy(records)
    wrong[1]["argv"] = ["python", "generic_checker.py"]
    assert not adjudicate_records(plan, name, wrong)["dependency_satisfied"]
    plan["cases"][name]["eagle3_unwind_point"] = "after_first_update"
    assert not adjudicate_records(plan, name, records)["dependency_satisfied"]


def test_probe_crosses_real_eagle_scope_and_next_scope_host_guard(tmp_path):
    from dataclasses import replace
    from types import SimpleNamespace
    from tests.ut.spec_decode.test_draft_window_eagle3 import _integration_speculator
    from tests.ut.spec_decode.test_draft_window_graph_carrier import _fingerprint
    from tools.p7x_graph_repair19_eagle_unwind import EagleUnwind, InjectedEagle3UnwindError
    from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_graph import Eagle3GraphStagingOwner
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph import (DraftWindowGraphRoute,
                                                                      install_draft_window_graph_binding_provider)

    owner, batch = _integration_speculator()
    provider = install_draft_window_graph_binding_provider(owner)
    controller = Eagle3GraphStagingOwner(owner._draft_window_runtime_state,
                                         provider,
                                         static_k=3,
                                         current_stream_identity=lambda: 101)
    inventory = owner._draft_window_runtime_state.capability.inventory
    group = inventory.require_single_group_direct_prefix()
    fingerprint = replace(_fingerprint(method="eagle3", route=DraftWindowGraphRoute.EAGLE3_FIRST_PASS, query_width=4),
                          window_size=inventory.window_size,
                          logical_block_size=group.logical_block_size,
                          kernel_block_size=group.kernel_block_size,
                          block_span_tokens=group.block_span_tokens)
    capture = provider.register_capture_identity(fingerprint=fingerprint, execution_lane=0, consumer_ordinal=0)
    owner._eagle3_graph_session = SimpleNamespace(controller=controller, provider=provider, resolve=lambda **_: capture)
    calls = []
    first = lambda desc: calls.append(desc)
    owner.prefill_cudagraph_manager = SimpleNamespace(run_fullgraph=first)
    owner.decode_cudagraph_manager = SimpleNamespace(run_fullgraph=lambda desc: None)
    owner.input_batch = batch
    path = tmp_path / "real-scope-host.json"
    with pytest.raises(InjectedEagle3UnwindError):
        with EagleUnwind(owner, path, dict(host_test_only=True), "before_first_replay"):
            with owner._eagle3_draft_window_proposal_scope(batch, dummy_run=False, is_profile=False):
                owner.prefill_cudagraph_manager.run_fullgraph(
                    SimpleNamespace(cg_mode=SimpleNamespace(name="FULL"), num_reqs=4, num_tokens=16))
    document = json.loads(path.read_text())
    assert not calls and owner.prefill_cudagraph_manager.run_fullgraph is first
    assert all(document["state"].values())
    assert document["next_scope_guard"]["rejected"] and not document["next_scope_guard"]["body_entered"]
    assert document["post_fault_manager_calls"] == 0
