# SPDX-License-Identifier: Apache-2.0
"""Actual P3/P6 bank separation and source seams, no fabricated NPU completion."""
from types import SimpleNamespace

import pytest
import torch
from vllm.config.compilation import CUDAGraphMode
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor

from tests.ut.spec_decode.test_draft_window_graph_carrier import _runtime_fixture, _target_metadata
from tests.ut.spec_decode.test_draft_window_graph_characterization import _runtime_context
from tests.ut.spec_decode.test_draft_window_eagle3 import _integration_speculator
from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_capture import Eagle3GraphSession


def session_fixture():
    runtime, _, tables = _runtime_fixture(method="eagle3", max_num_reqs=4)
    owner = SimpleNamespace(
        _draft_window_runtime_state=runtime,
        num_speculative_steps=3,
        max_model_len=1024,
        block_tables=tables,
    )
    owner.prefill_cudagraph_manager = SimpleNamespace(
        max_num_reqs=4,
        _capture_descs={
            CUDAGraphMode.FULL:
            [BatchExecutionDescriptor(cg_mode=CUDAGraphMode.FULL, num_reqs=4, num_tokens=16, uniform_token_count=4)]
        },
    )
    owner.decode_cudagraph_manager = SimpleNamespace(
        max_num_reqs=4,
        _capture_descs={
            CUDAGraphMode.FULL:
            [BatchExecutionDescriptor(cg_mode=CUDAGraphMode.FULL, num_reqs=4, num_tokens=4, uniform_token_count=1)]
        },
    )
    session = Eagle3GraphSession(owner, _runtime_context(graph_mode="FULL_DECODE_ONLY"))
    session.controller._stream_identity = lambda: 101
    owner.input_buffers = SimpleNamespace(query_start_loc=torch.arange(5, dtype=torch.int32) * 4)
    return session, owner


def test_actual_capture_consumers_have_disjoint_banks_and_preserve_full_query_writes():
    session, owner = session_fixture()
    target = _target_metadata()
    original = target[next(iter(target))]
    old_table, old_lengths = original.block_tables.clone(), original.seq_lens.clone()
    captures, outputs = [], []
    # Actual AR preparation owns Q=1 query offsets. The builder may return a
    # value-equivalent temporary copy, which is not the stable Full owner.
    owner.input_buffers.query_start_loc = torch.arange(5, dtype=torch.int32)
    with session.capture_call(first=False, n=4, tokens=4):
        for _ in range(2):
            metadata, identity = session.capture_metadata(target)
            layer = metadata[next(iter(metadata))]
            assert layer.slot_mapping is original.slot_mapping
            assert torch.equal(layer.query_start_loc, original.query_start_loc)
            assert layer.query_start_loc.data_ptr() == owner.input_buffers.query_start_loc.data_ptr()
            assert layer.positions is original.positions
            assert layer.block_tables is not original.block_tables
            assert layer.seq_lens_list == [191] * 4  # W128 + block64 - 1, dummy capacity only.
            out = (torch.tensor([1.0]), torch.tensor([2.0]))
            session.retain_capture_output(identity, out)
            captures.append(identity)
            outputs.append(out)
    addresses = [c.backing_identity.window_block_table.data_ptr for c in captures]
    assert len(set(addresses)) == 2
    assert torch.equal(original.block_tables, old_table)
    assert torch.equal(original.seq_lens, old_lengths)
    assert all(session.captured_outputs[c] is o for c, o in zip(captures, outputs))
    assert owner._draft_window_runtime_state._active_inputs is None
    assert all(session.provider.startup_capture_read_inputs(c).actual_request_count == 4 for c in captures)


def test_capture_rejects_missing_extra_nested_and_wrong_bucket_consumers():
    session, _ = session_fixture()
    target = _target_metadata()
    with pytest.raises(RuntimeError, match="every actual"):
        with session.capture_call(first=False, n=4, tokens=4):
            session.capture_metadata(target)
    with pytest.raises(RuntimeError, match="no exact capture bank"):
        session.resolve(first=True, n=3, tokens=12, ordinal=0)
    with pytest.raises(RuntimeError, match="nested"):
        with session.capture_call(first=True, n=4, tokens=16):
            with session.capture_call(first=True, n=4, tokens=16):
                pass
    with pytest.raises(RuntimeError, match="no exact capture bank"):
        with session.capture_call(first=False, n=4, tokens=4):
            for _ in range(3):
                session.capture_metadata(target)


def test_real_proposal_unwind_quarantines_staging_and_next_scope_is_host_rejected():
    speculator, batch = _integration_speculator()
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph import install_draft_window_graph_binding_provider
    from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_graph import Eagle3GraphStagingOwner
    provider = install_draft_window_graph_binding_provider(speculator)
    controller = Eagle3GraphStagingOwner(
        speculator._draft_window_runtime_state,
        provider,
        static_k=3,
        current_stream_identity=lambda: 101,
    )
    speculator._eagle3_graph_session = SimpleNamespace(controller=controller)
    with pytest.raises(ValueError, match="injected after materialize"):
        with speculator._eagle3_draft_window_proposal_scope(batch, dummy_run=False, is_profile=False):
            inputs = speculator._materialize_eagle3_first_pass(num_reqs=1, num_reqs_padded=1)
            retained = inputs.window_block_table.clone()
            raise ValueError("injected after materialize")
    runtime = speculator._draft_window_runtime_state
    assert runtime.quarantined_identity == inputs.identity
    assert runtime._active_inputs is inputs
    assert torch.equal(inputs.window_block_table, retained)
    with pytest.raises(RuntimeError, match="quarantined"):
        with speculator._eagle3_draft_window_proposal_scope(batch, dummy_run=False, is_profile=False):
            pytest.fail("must reject before another device submission")


def test_dispatch_phase_rule_does_not_catch_missing_graph_buckets(monkeypatch):
    from vllm_ascend.worker.v2.spec_decode.autoregressive.aclgraph import AutoRegressiveAclGraphManager
    from vllm.v1.worker.gpu.spec_decode.autoregressive.cudagraph_utils import SpeculatorCudaGraphManager
    manager = object.__new__(AutoRegressiveAclGraphManager)
    manager.speculator = SimpleNamespace(_eagle3_window_continuing_prefill=True)
    manager._resolve_effective_loras = lambda n: n
    called = []

    def baseline(*args):
        called.append(True)
        raise RuntimeError("missing real Graph bucket")

    monkeypatch.setattr(SpeculatorCudaGraphManager, "dispatch", baseline)
    assert manager.dispatch(3, 12, 4, 0).cg_mode is CUDAGraphMode.NONE
    assert not called
    manager.speculator._eagle3_window_continuing_prefill = False
    with pytest.raises(RuntimeError, match="missing real Graph bucket"):
        manager.dispatch(3, 12, 4, 0)
    assert called == [True]


def test_capture_callback_has_no_host_to_device_copy_or_dummy_initialization(monkeypatch):
    session, _ = session_fixture()  # Initialize real P3/P6 before capture.
    target = _target_metadata()

    def forbidden(*args, **kwargs):
        raise AssertionError("GLOBAL capture must not initialize/copy the dummy bank")

    monkeypatch.setattr(torch.Tensor, "copy_", forbidden)
    monkeypatch.setattr(torch.Tensor, "fill_", forbidden)
    monkeypatch.setattr(torch.Tensor, "zero_", forbidden)
    with session.capture_call(first=False, n=4, tokens=4):
        for _ in range(2):
            metadata, identity = session.capture_metadata(target)
            assert identity is not None and metadata is not target


def test_graph_metadata_binds_device_exact_when_eagle_builder_prefers_cpu():
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph import DraftWindowGraphReadInputs
    spec, batch = _integration_speculator()
    context = spec._eagle3_window_epoch_source.begin(batch)
    spec._eagle3_window_proposal_context = context
    inputs = spec._materialize_eagle3_first_pass(num_reqs=1, num_reqs_padded=1)
    read = DraftWindowGraphReadInputs(
        window_block_table=inputs.window_block_table.clone(), valid_num_blocks=inputs.valid_num_blocks.clone(),
        device_window_exact=inputs.device_window_exact.clone(), cpu_window_exact=inputs.cpu_window_exact.clone(),
        cpu_window_upper=inputs.cpu_window_upper.clone(), actual_request_count=1, padded_request_count=1,
    )
    assert read.device_window_exact.data_ptr() != read.cpu_window_exact.data_ptr()
    target = spec.model_state.attn_metadata
    old = target["draft.layer"].seq_lens.clone() if hasattr(target["draft.layer"], "seq_lens") else None
    def actual_nonparallel_builder_choice(**kwargs):
        return {"draft.layer": SimpleNamespace(
            block_tables=kwargs["block_tables"][0], seq_lens=kwargs["seq_lens_cpu"],
            seq_lens_cpu=kwargs["seq_lens_cpu"], seq_lens_list=kwargs["seq_lens_cpu"].tolist(),
            attn_state="builder", slot_mapping=kwargs["slot_mappings"],
        )}
    spec._call_eagle3_draft_attn_metadata_builder = actual_nonparallel_builder_choice
    metadata = spec._build_eagle3_graph_metadata(
        inputs=inputs, read=read, num_reqs=1, num_reqs_padded=1, num_tokens_padded=4,
        query_start_loc_np=batch.query_start_loc_np, target_metadata=target, first_pass=True,
    )
    assert metadata["draft.layer"].seq_lens is read.device_window_exact
    assert metadata["draft.layer"].seq_lens_cpu is read.cpu_window_exact
    assert metadata["draft.layer"].seq_lens_list == read.cpu_window_exact.tolist()
    assert spec.model_state.attn_metadata is target
    if old is not None:assert target["draft.layer"].seq_lens.equal(old)


def test_capture_query_binds_same_owned_full_input_buffer_as_runtime():
    import torch
    from types import SimpleNamespace
    session, owner = session_fixture()
    query = torch.tensor([0, 4, 8, 12, 16], dtype=torch.int32)
    owner.input_buffers = SimpleNamespace(query_start_loc=query)
    target = _target_metadata()
    original = target["draft.layers.0.self_attn"].query_start_loc.clone()
    with session.capture_call(first=True, n=4, tokens=16):
        metadata, identity = session.capture_metadata(target)
    actual = metadata["draft.layers.0.self_attn"].query_start_loc
    assert actual.data_ptr() == query.data_ptr(), "capture and runtime must bind the same owned Full query source"
    query[-1] = 12
    assert actual.tolist() == [0, 4, 8, 12, 12]
    assert target["draft.layers.0.self_attn"].query_start_loc.equal(original)
