# SPDX-License-Identifier: Apache-2.0
"""Host fixtures only; these rows are not scheduler device evidence."""
import copy
from types import SimpleNamespace

import numpy as np
import pytest

from tools.p7x_graph_repair16_scheduler import SchedulerRows, check_rows, configure, phase_from_rows


def row(group, computed, scheduled, prefill, graphs=()):
    value = dict(group=group,
                 request_ids=[f"{group}-{i}" for i in range(len(computed))],
                 computed=computed,
                 scheduled=scheduled,
                 prefill=prefill,
                 is_prefilling=[c < p for c, p in zip(computed, prefill)],
                 start_ns=100,
                 end_ns=200,
                 graphs=list(graphs),
                 flags_after={})
    value["row_phases"], value["batch_phase"] = phase_from_rows(value)
    return value


def fixtures():
    return [
        row("one", [0], [256], [513]),
        row("one", [512], [1], [513]),
        row("mixed", [513, 0], [4, 128], [513, 257]),
        row("return", [513], [4], [513], [dict(route="AR", start_ns=150, descriptor=[1, 1])])
    ]


def test_actual_row_counters_and_distinct_scheduler_profile():
    original = dict(max_model_len=8192, max_num_seqs=4, max_num_batched_tokens=8192)
    assert configure(original)["max_num_batched_tokens"] == 256
    assert original["max_num_batched_tokens"] == 8192
    result = check_rows(fixtures(), "G_ON", dict(host_start_ns=1, host_end_ns=1000))
    assert result["status"] == "PASS_SCOPED_ACTUAL_SCHEDULER_PHASES"


@pytest.mark.parametrize("damage", ["phase", "prefill", "flag", "continuing_graph", "interval", "coverage"])
def test_damaged_or_missing_scheduler_phase_is_not_accepted(damage):
    rows = fixtures()
    if damage == "phase": rows[0]["batch_phase"] = "pure_decode"
    if damage == "prefill": rows[0]["is_prefilling"] = [False]
    if damage == "flag": rows[-1]["flags_after"] = {"_eagle3_window_continuing_prefill": True}
    if damage == "continuing_graph": rows[0]["graphs"] = [dict(start_ns=150)]
    if damage == "interval": rows[-1]["end_ns"] = 1001
    if damage == "coverage": rows.pop(2)
    with pytest.raises(ValueError):
        check_rows(rows, "G_ON", dict(host_start_ns=1, host_end_ns=1000))
    with pytest.raises(ValueError):
        check_rows(fixtures(), "E_ON", dict(host_start_ns=1, host_end_ns=1000))


def test_wrapped_proposal_restores_methods_and_preserves_exception_without_device_work():
    desc = SimpleNamespace(num_reqs=1, num_tokens=1)
    manager = SimpleNamespace(run_fullgraph=lambda d: None)
    owner = SimpleNamespace(prefill_cudagraph_manager=manager,
                            decode_cudagraph_manager=SimpleNamespace(run_fullgraph=lambda d: None))
    original_graph = manager.run_fullgraph

    def propose(batch):
        manager.run_fullgraph(desc)
        raise RuntimeError("original-python-error")

    owner.propose = propose
    batch = SimpleNamespace(num_reqs=1,
                            req_ids=["r"],
                            num_computed_prefill_tokens_np=np.array([513], dtype=np.int32),
                            num_scheduled_tokens=np.array([4], dtype=np.int32),
                            prefill_len_np=np.array([513], dtype=np.int32),
                            is_prefilling_np=np.array([False]))
    with SchedulerRows(owner) as recorder:
        recorder.group = "actual-host-test"
        with pytest.raises(RuntimeError, match="original-python-error"):
            owner.propose(batch)
    assert owner.propose is propose and manager.run_fullgraph is original_graph
    assert recorder.current is None and recorder.rows[0]["graphs"][0]["route"] == "first_pass"
    assert recorder.rows[0]["exception"]["message"] == "original-python-error"
