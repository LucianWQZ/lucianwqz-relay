# SPDX-License-Identifier: Apache-2.0
"""Independent padded-grid fixtures; Host-only, not a device result."""
import copy

import pytest
import torch

from tests.ut.spec_decode.test_graph_repair15_eagle_numeric import specimen
from tools.p7x_graph_repair15_eagle_numeric_check import validate_sample


def padded_specimen():
    r, h = specimen()
    h["groups"]["short"] = 3
    h["kv_inventory"] = {key: dict(shape=[300, 128, 1, 1], dtype="torch.bfloat16") for key in h["kv_inventory"]}
    r.update(active=3, descriptor=[4, 16], l0=[64] * 3, ends=[64] * 3, valid=[2] * 3)
    r["runtime_identity"].update(actual_request_count=3,
                                 padded_request_count=4,
                                 ordered_request_fingerprint=["a", "b", "c"])
    full = torch.arange(1, 257, dtype=torch.int32).reshape(4, 64)
    r["canonical_table"] = full
    selected = [0, 1, 2, 65, 66, 129, 130]
    r["selected_blocks"] = selected
    r["oracle"] *= 3
    inputs = dict(input_ids=torch.arange(16, dtype=torch.int32),
                  positions=torch.tensor([60, 61, 62, 63] * 3 + [0, 0, 0, 0], dtype=torch.int64),
                  hidden_states=torch.ones((16, 8), dtype=torch.bfloat16),
                  full_exact=torch.tensor([64, 64, 64, 0], dtype=torch.int32),
                  query_start_loc=torch.tensor([0, 4, 8, 12, 12], dtype=torch.int32),
                  target_positions=torch.tensor([60, 61, 62, 63] * 3 + [0, 0, 0, 0], dtype=torch.int64),
                  last_token_indices=torch.tensor([3, 7, 11, 0], dtype=torch.int64))
    r["inputs"], r["reference_inputs"] = inputs, copy.deepcopy(inputs)
    table = torch.zeros((4, 9), dtype=torch.int32)
    table[:3, 0] = full[:3, 0]
    exact = torch.tensor([64, 64, 64, 0], dtype=torch.int32)
    slots = torch.tensor([int(full[row, 0]) * 128 + pos for row in range(3) for pos in range(60, 64)] + [-1] * 4,
                         dtype=torch.int64)
    name = "draft.layer"
    r["actual_reads"] = {name: dict(table=table, exact=exact)}
    r["reference_metadata"] = {
        name:
        dict(table=table.clone(),
             exact=exact.clone(),
             slot=slots.clone(),
             query=inputs["query_start_loc"].clone(),
             fia_query=[4, 8, 12, 16],
             causal=True,
             table_address=300)
    }
    r["actual_slots"] = {name: slots}
    r["forward_context_slots"] = {name: slots.clone()}
    r["captured_full_input_queries"] = {name: torch.tensor([0, 4, 8, 12, 12], dtype=torch.int32)}
    r["runtime_queries"] = {name: inputs["query_start_loc"].clone()}
    r["actual_fia_query"] = {name: [4, 8, 12, 16]}
    output = torch.ones((16, 8), dtype=torch.bfloat16)
    r["graph"] = (output, output.clone())
    r["reference"] = (output.clone(), output.clone())
    kv = {key: torch.zeros((7, 128, 1, 1), dtype=torch.bfloat16) for key in h["kv_inventory"]}
    for field in ("pre_kv", "reference_pre_kv", "graph_post_kv", "reference_post_kv"):
        r[field] = copy.deepcopy(kv)
    return r, h


def test_active3_padded4_owned_gpu_input_query_differs_from_fia_host_padding():
    r, h = padded_specimen()
    assert validate_sample(r, h)["numeric_match"] is True
    assert r["inputs"]["query_start_loc"].tolist() == [0, 4, 8, 12, 12]
    assert r["captured_full_input_queries"]["draft.layer"].tolist() == [0, 4, 8, 12, 12]


@pytest.mark.parametrize("field,value", [("runtime_queries", 16), ("captured_full_input_queries", 16),
                                         ("actual_fia_query", 12)])
def test_damaged_query_roles_are_rejected_even_with_matching_outputs(field, value):
    r, h = padded_specimen()
    r[field]["draft.layer"][-1] = value
    with pytest.raises(ValueError):
        validate_sample(r, h)


def test_old_auxiliary_schema_cannot_be_relabelled_as_owned_input_evidence():
    r, h = padded_specimen()
    h["numeric_schema"] = "r5-eagle3-continuous-v4"
    with pytest.raises(ValueError, match="exact numeric binding schema"):
        validate_sample(r, h)
