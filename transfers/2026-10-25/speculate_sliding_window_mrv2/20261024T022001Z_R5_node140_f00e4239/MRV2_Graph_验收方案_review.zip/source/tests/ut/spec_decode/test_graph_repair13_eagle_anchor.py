# SPDX-License-Identifier: Apache-2.0
"""Eagle3 has a causal first pass and ordered Q1 AR consumers, not Q16."""

import copy
import json

import pytest

from tools.p7x_graph_repair13_eagle import CONTRACT, add_cases, configure, counts, parse_args, validate_contract


def base_config():
    return dict(
        model="target",
        speculative_config=dict(model="independent-eagle"),
        compilation_config=dict(cudagraph_mode="FULL_DECODE_ONLY", cudagraph_capture_sizes=[7, 14, 28]),
        enforce_eager=False,
        async_scheduling=False,
        enable_prefix_caching=False,
        additional_config=dict(draft_window_size=1024),
        disable_log_stats=True,
    )


@pytest.mark.parametrize("arm", ["G_OFF", "E_ON", "G_ON"])
def test_eagle3_independent_k3_ar_contract_and_unchanged_target(arm):
    original = base_config()
    result = configure(original, arm)
    assert original == base_config()
    assert result["enforce_eager"] is False
    assert result["speculative_config"] == dict(
        model="independent-eagle", method="eagle3", num_speculative_tokens=3, enforce_eager=arm == "E_ON"
    )
    assert result["compilation_config"]["cudagraph_capture_sizes"] == [1, 2, 4, 8, 16]
    assert result["additional_config"] == ({} if arm == "G_OFF" else dict(draft_window_size=1024))
    assert result["disable_log_stats"] is False  # Separate timestamp/statistics arm.
    with pytest.raises(ValueError, match="unknown Eagle3 arm"):
        configure(original, "UNDECLARED")


@pytest.mark.parametrize(
    "key,value", [("causal", 1), ("k", 15), ("ar_query", 16), ("capture_sizes", [True, 2, 4, 8, 16])]
)
def test_wrong_or_untyped_eagle_contract_is_rejected(key, value):
    document = copy.deepcopy(CONTRACT)
    validate_contract(document)
    document[key] = value
    with pytest.raises(ValueError):
        validate_contract(document)


def test_acceptance_excludes_bonus_and_uses_actual_shortened_proposals():
    metric = dict(
        num_spec_tokens=3,
        per_step_drafted=[3, 1],
        per_step_accepted=[2, 0],
        acceptance_histogram=[1, 0, 1, 0],
        num_draft_tokens=4,
        num_accepted_draft_tokens=2,
        num_spec_steps=2,
        draft_acceptance_rate=0.5,
        mean_acceptance_length=2.0,
    )
    assert counts(metric) == dict(proposed=4, accepted=2, verification_request_steps=2)
    metric["mean_acceptance_length"] = 1.0
    with pytest.raises(ValueError):
        counts(metric)


def test_eagle_cases_parse_as_their_actual_entrypoints_without_dflash_flags(tmp_path):
    fixture = tmp_path / "eagle3-k3-fixture.json"
    fixture.write_text(json.dumps(dict(schema="r5-eagle3-k3-fixture-v1", method_contract=CONTRACT)))
    (tmp_path / "requests").mkdir()
    (tmp_path / "requests/eagle3-k3-anchor.json").write_text("[]")
    common = dict(
        acceptance_identity=dict(run_id="eagle-host-r", driver_mode="A0", case_id="A0"),
        argv=["python", "driver", "run", "--vllm-repo", "/fixed-vllm"],
        dependencies=[],
        requires_device_admission=True,
    )
    cases = dict(A0=copy.deepcopy(common), CONFIG=copy.deepcopy(common))
    # The real committed CONFIG is a Host command, not a model launch; it
    # deliberately has no child acceptance identity or external launcher.
    cases["CONFIG"].pop("acceptance_identity")
    add_cases(cases, tmp_path, tmp_path, tmp_path, "python", "a" * 40, tmp_path / "proof.json", "b" * 64)
    for arm in ("G_OFF", "E_ON", "G_ON"):
        name = "EAGLE3_" + arm
        case = cases[name]
        argv = case["argv"]
        parsed = parse_args(argv[argv.index("run") :])
        assert parsed.arm == arm and parsed.case_id == name
        assert case["launch_argv"][case["launch_argv"].index("--") + 1 :] == argv
        assert case["eagle3_contract"] == CONTRACT
        assert "--repair12-fixture-verification" not in argv
        assert "--repair5-capture-profile" not in argv
    for arm in ("G_OFF", "G_ON", "E_ON"):
        name = "EAGLE3_SCHED_" + arm
        case = cases[name]
        argv = case["argv"]
        parsed = parse_args(argv[argv.index("run") :])
        assert parsed.scheduler_phases and not parsed.eagle3_numeric
        assert parsed.case_id == name and parsed.arm == arm
        assert case["launch_argv"][case["launch_argv"].index("--") + 1:] == argv
        assert case["dependencies"] == ["CONFIG_EAGLE3", "EAGLE3_" + arm]
    assert cases["EAGLE3_G_OFF"]["dependencies"] == ["CONFIG_EAGLE3"]
    assert cases["EAGLE3_E_ON"]["dependencies"] == ["CONFIG_EAGLE3", "EAGLE3_G_OFF"]
    from tools.p7x_graph_repair19_eagle_unwind import POINTS
    for point in POINTS:
        name = "UNWIND_EAGLE3_" + point
        case = cases[name]
        args = parse_args(case["argv"][case["argv"].index("run"):])
        assert args.eagle3_unwind == point and args.arm == "G_ON"
        assert not args.eagle3_numeric and not args.scheduler_phases
        assert case["launch_argv"][case["launch_argv"].index("--") + 1:] == case["argv"]
        assert case["dependencies"] == ["CONFIG_EAGLE3", "EAGLE3_G_ON"]
        assert any("p7x_graph_repair19_eagle_unwind.py" in value
                   for value in case["validation_commands"][0]["argv"])
