# 网页GPT独立技术评审请求

目标是MRV2投机Draft Sliding Window Graph完整适配。当前C59 3bf24139a506dc4fb8417a5a26c15ca33ac0aa9c，tree b85f1a87cc0d337a5bd8db1bf5c61e7fe8b3ba5b，node-25-140，Python3.11.10/torch2.10/torch_npu2.10.0.post4/CANN9.1，vLLM84030固定。public Gate冻结。本包不是发布请求批准，更不是缺失直接证据已补齐。

请先读验收方案中文说明、候选与证据表、正常合同、完整numeric/Target/故障joint及源码diff。逐项审查：

1. UPDATE生效代际和backing完成顺序是否有逻辑跳跃或循环论证？API安装适用前提是否准确？
2. 独立eager参考是否真的独立？canonical full前态来源、Graph快照与参考调用是否区分？共享底层算子有哪些共同失效风险？相同blob hash不单独证明或否定独立性。
3. 诊断drain/D2H/restore是否改变被证明的正常时序？哪些结论只能限于串行诊断？
4. 是否有把C33/C45/C49/C52旧候选证据错误归给C59的情况？最终同SHA覆盖够不够？
5. C58捕获源Tensor寿命、C59 owned query绑定修复是否必要充分？严格v5是否仍拒绝错误dtype、字节/metadata矛盾、过期generation和FIA Host长度错误？
6. 替代证据是否覆盖原要求防范的错误？execution occurrence operand和physical read-set是否被语义/性能混淆？
7. 哪些缺口可由更小代码/实验继续解决，哪些确需平台维护者？有无比重复native末值dump更直接的补证方法？
8. 最终产品范围、observer-off入口、TP16、其他组合与PR集成还缺什么？

包内evidence/COPIED_EVIDENCE_INDEX.json标完整原件；trace excerpt明确只为片段不可送入完整checker。完整tensor/trace服务器索引可追溯，但网页端不能独立复算所有KV；少量BF16样本仅支持局部复查。服务器自检、网页技术意见、正式发布审批三者分开。
