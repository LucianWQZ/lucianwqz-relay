from pathlib import Path
import hashlib,json,math,struct
root=Path(__file__).parent
idx=json.loads((root/'INDEX.json').read_text());result=[]
for name in idx['excerpts']:
 d=json.loads((root/name).read_text());f=d['fields'];a=f['graph']['tuple'];b=f['reference']['tuple'];pairs=[]
 for x,y in zip(a,b):
  rx,ry=x['tensor_ref'],y['tensor_ref'];payload=[]
  for ref in (rx,ry):
   data=(root/'tensors'/ref['path']).read_bytes();assert len(data)==ref['bytes'];assert hashlib.sha256(data).hexdigest()==ref['sha256'];assert ref['dtype']=='torch.bfloat16';assert math.prod(ref['shape'])*2==len(data);payload.append(data)
  active=f['active']*(4 if f['first_pass'] else 1);prefix=active*math.prod(rx['shape'][1:])*2
  finite=all((v[0]&0x7f80)!=0x7f80 for data in payload for v in struct.iter_unpack('<H',data[:prefix]));pairs.append(dict(active_byte_equal=payload[0][:prefix]==payload[1][:prefix],full_padded_byte_equal_observation=payload[0]==payload[1],finite_active=finite,active_rows=active,shape=rx['shape']))
 result.append(dict(sample=name,pairs=pairs,scope='OUTPUT_EXCERPT_ONLY_NOT_COMPLETE_KV_OR_FORWARD_REFERENCE'))
print(json.dumps(result,indent=2))
