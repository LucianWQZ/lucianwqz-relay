from pathlib import Path
import json,hashlib,struct
p=Path(__file__).parent;j=json.loads((p/'INDEX.json').read_text());data={}
for field,ref in j['files'].items():
 b=(p/ref['path']).read_bytes();assert len(b)==ref['bytes'] and hashlib.sha256(b).hexdigest()==ref['sha256'];data[field]=b
a,b=data['graph_post_kv'],data['reference_post_kv'];mismatches=sum(x!=y for x,y in zip(struct.iter_unpack('<H',a),struct.iter_unpack('<H',b)))
print(json.dumps(dict(scope=j['scope'],physical_blocks=j['physical_blocks'],post_mismatched_bfloat16_elements=mismatches,pre_equal=data['pre_kv']==data['reference_pre_kv'],reference_post_equals_pre=data['reference_post_kv']==data['pre_kv'],original_status=j['actual_original_status']),indent=2))
