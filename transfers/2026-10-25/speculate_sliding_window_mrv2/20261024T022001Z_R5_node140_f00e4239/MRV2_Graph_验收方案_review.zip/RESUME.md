# R5最终恢复入口

SESSION=20261024T022001Z_R5_node140_f00e4239；节点node-25-140；当前本地C59 3bf24139a506dc4fb8417a5a26c15ca33ac0aa9c，tree b85f1a87cc0d337a5bd8db1bf5c61e7fe8b3ba5b，开发树/固定候选干净。
实际起点2026-10-24T02:20:01Z，原截止2026-10-24T12:20:01Z（北京时间20:20:01），恢复不重置、不自动续期。

- 开发树：/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/work/node140/vllm-ascend。
- 固定源码：/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/candidates/node140/C59_3bf24139/vllm-ascend。
- runtime：/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runtime/node140/C59_3bf24139/runtime_manifest.json。
- raw：/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261024T022001Z_R5_node140_f00e4239/raw。
- 唯一交付：/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/return/20261024T022001Z_R5_node140_f00e4239；全局日志：/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/journal/progress.log（只追加，不能换inode）。
- 人工问题/原回答/建议/实施/验收区别：/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/manual_review/adapt_人工后续核查.md。

## 最后实际完成

C59 16K三臂各3控制全部专用checker通过：OFF/ON/E_ON中位4125.6619/3903.79164/4293.73922ms，ON相对OFF降低5.3778%，同Window Graph相对Draft eager降低9.0818%；接受率57.42025%→71.59664%、验证轮103→85，九组实际输入与512输出IDs一致。不能把工作量变化都称kernel加速，未批准普遍性能达标。
C59四Python故障与三臂真实scheduler通过；完整Eagle9数值FAIL（4完成PASS、第5AR1输出精确但K后态blocks1/2差异）。完整原件和独立可复算K片段在交付内，绝不改标PASS。
C45 DFlash完整14/Target14/LIFE160/8故障，C49 Q8完整14/Target14仍绑定各自SHA；不拼最终SHA全通过。
最终实查无本任务worker/supervisor/profiler/租约，详见FINAL_PROCESS_AND_LEASE_CHECK.json；历史PID不可直接发信号。

## 下一条动作

先检查本机、有效授权与已有进程/租约，读取NEXT_SESSION_HANDOFF.json；若仍在原有效窗口也不得重复已结束case。下一窗口明确授权后，围绕K后态最小判别计划补producer一次性导出所有已完成AR快照及merged真实cache/format/storage身份，定向Host→commit→固定候选→1片TP1；不重复相同9样本无信息采集、不放宽比较器。
TP16目前只有rank-aware Host基础，真实backend/all-rank runner未齐；产品入口与其他必须组合、正常合同适用性、execution operand/physical-read与最终PR集成仍需推进。public Gate冻结，整体目标未完成。

## 恢复依赖

Python/usr/local/python3.11.10/bin/python，先source CANN9.1 set_env；torch2.10.0/torch_npu2.10.0.post4；vLLM pin84030；native overlay按runtime manifest lineage/hash复用，不复制旧Python覆盖候选。
TMPDIR /tmp/mrv2_graph_20261024T022001Z_R5_node140_f00e4239/tmp；cache使用已绑定目录，避免NFS TemporaryDirectory错误。
增量bundle需C35 f00e423936c23b0710fc2b5cd367d34ec7736d26前置；已真实bare仓验证恢复C59 SHA/tree，模型、底层栈与overlay不在bundle。
