# 正常Graph合同审查（R5）

## 必须保证什么

本代FIA必须使用本代UPDATE参数；下一代写同址backing之前，上一代最后相关消费者必须完成。
Host return、UPDATE return、retire、进程退出均不是完成证明。

## A：最后consumer到下一次写

已有匹配版本源码表明capture附加流尾notify合流，RI/Stars endGraphNotify将capture相关工作汇回current FIFO；下一代materialize/backing写在该current流排队。
因此在所有相关消费者均属于被合流capture且没有脱离其依赖的工作这一前提下，下一次写排在旧consumer之后。
适用证据见platform/R3_正常Graph合同审查.md、evidence下normal_contract_R5_sources/INDEX.json及实际worker-provenance中的libruntime_v100路径/hash。
不能由仅版本号相同推导所有安装补丁分支；具体安装/硬件适用性仍需平台维护者确认，负责人待确认。

## B：UPDATE版本与放行

每consumer replay前update_stream.wait_stream(current)，replay的ExternalEvent wait/reset与单update_stream的UPDATE/record FIFO配合；FIA专用宏对Host长度vector拥有拷贝。
在上述API合同成立时，当前被放行的任务获取本代更新，下一代update/record不能越过上一代current完成前缀。
Eagle first/AR管理器使用同一speculator.update_stream，各consumer独立bank。必须保持wait-current在replay之前；为取证挪到之后可能形成环依赖。
完整五步论证及源码出处复用R3，R5方法差异见随包原件；结论SOURCE_SUPPORTED_CONTRACT，非正式发布裁决。

## 本轮发现与修复

C58：captured D2D/index_select节点只保存地址不会自动拥有源Tensor；诊断快照必须显式持有源对象，弱引用反例及真实first-pass改善支持修复。
C59：Eagle捕获GPU query与runtime必须绑定同一owned Full input buffer；FIA Host padded query另立合同。严禁通过cast、全局dtype替换、放宽容差取得通过。
上述不是将LIFE drain搬入正常production；C59未新增正常同步或D2H。

## 仍未证明什么

原生参数导出仅POST_DRAIN_EXPORTED_PARAMETERS_ONLY；合成ts/dur不可用于真实先后。
本轮trace有真实MODEL_EXECUTE计数和event/queue关联，但没有generation绑定的执行实例operand，也没有硬件physical read-set。
数值无窗外影响不等于硬件没读取窗外地址。维护者/验收负责人应分别审查语义正确性、API适用性与特定取证方式，不能把网页GPT意见写成批准。
