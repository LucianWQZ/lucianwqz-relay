"""Prepare exact Repair7 source after publication and owner device admission.

No model is loaded, and no experiment is executed by this script.
"""
import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "vllm", "output", "receipt"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--run-id", required=True)
    a = p.parse_args()
    root = Path(__file__).resolve().parent
    h = json.loads((root / "handoff.json").read_text())
    if h["publication_status"] != "VERIFIED":
        raise RuntimeError("PRE_PUBLICATION: reviewed publication + independent network recovery required")
    if a.output.exists():
        raise RuntimeError("new attempt/output directory required; retain all previous attempts")
    for repo, sha, tree in ((a.repo, h["commit"], h["tree"]), (a.vllm, h["vllm"]["commit"], h["vllm"]["tree"])):
        def git(*args):
            return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
        if git("rev-parse", "HEAD") != sha or git("rev-parse", "HEAD^{tree}") != tree or git("status", "--porcelain", "--untracked-files=all"):
            raise RuntimeError("exact clean source mismatch: " + str(repo))
    for path, sha in {**h["tools_sha256"], **h["production_sha256"]}.items():
        if digest(a.repo / path) != sha:
            raise RuntimeError("source hash mismatch: " + path)
    fixture = root / "inputs/fixture_manifest.json"
    if digest(fixture) != h["fixture_manifest_sha256"]:
        raise RuntimeError("original fixture manifest changed")
    sys.path.insert(0, str(a.repo.resolve()))
    from tools.p7x_graph_repair7_device import inspect, validate_receipt
    receipt = json.loads(a.receipt.read_text())
    validate_receipt(receipt, inspect(), a.run_id)
    if (receipt["source_sha"], receipt["source_tree"]) != (h["commit"], h["tree"]):
        raise RuntimeError("device receipt belongs to other source")
    # Mapping/visibility is established before importing framework-dependent plan tools.
    for item in json.loads(fixture.read_text())["files"]:
        if digest(item["path"]) != item["sha256"]:
            raise RuntimeError("model fixture hash mismatch: " + item["path"])
    from tools.p7x_graph_repair7_campaign import build_plan
    plan = build_plan(a.repo, root / "inputs", a.output, a.vllm, sys.executable, h["commit"], h["tree"], a.run_id)
    plan.update(publication_status="VERIFIED", device_admission_receipt=str(a.receipt.resolve()), device_admission_sha256=digest(a.receipt))
    a.output.mkdir(parents=True)
    (a.output / "case-plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    print("Prepared only. Execute one selected case; fresh per-case admission required.")


if __name__ == "__main__":
    main()
