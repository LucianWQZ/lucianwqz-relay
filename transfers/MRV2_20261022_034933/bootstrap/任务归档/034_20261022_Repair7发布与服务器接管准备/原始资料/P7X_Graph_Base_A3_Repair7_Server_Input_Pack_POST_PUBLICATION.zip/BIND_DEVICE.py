"""Bind a fresh owner-attested receipt to one copied case plan, not a device run."""
import argparse
import json
import sys
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "plan", "receipt", "output"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--case-id", required=True)
    a = p.parse_args()
    if a.output.exists():
        raise ValueError("new admitted-plan output required")
    plan = json.loads(a.plan.read_text())
    if plan["publication_status"] != "VERIFIED":
        raise ValueError("PRE_PUBLICATION cannot admit execution")
    sys.path.insert(0, str(a.repo.resolve()))
    from tools.p7x_graph_repair7_device import digest, validate_admission
    plan.update(device_admission_receipt=str(a.receipt.resolve()), device_admission_sha256=digest(a.receipt))
    validate_admission(plan, a.case_id)
    a.output.write_text(json.dumps(plan, indent=2) + "\n")


if __name__ == "__main__":
    main()
