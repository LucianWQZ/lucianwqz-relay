# R6 Graph 当前恢复入口

当前候选C204 `06fafe0da5f690bbd7accb21984063b53fb60031`、tree `95496f41d5d1ef0cdf297ce15b8c5217f3c9e98d`、pin `84030bbe3d74d99bad477a3d2e37a973ccd8865c`。工程NOT_READY、管理58%，Gate冻结。当前没有本任务设备/派发/后台写入者/lease；以final_process_lease_audit.json最后采样为准。原硬截止2026-10-27T19:21:18.369Z，不能从resume重新计时；需要适用的新授权才派发。

第一项是读取evidence/C203_owned_legacy_failure_reanalysis.json及本包Eagle报告，Host准备一次实际attention Q/输出完整采证；不是重跑旧OFF/ON/完整矩阵。完整后续顺序和预算见NEXT_SESSION_HANDOFF.json。保留原失败、0容差和当前candidate；不改PR工作树/基线/底层栈。

五入口仍为dev/all的adapt_progress.log、adapt_live.log、adapt进度.md、adapt_任务总报告.md、adapt_日志入口.json。原journal/progress.log只追加，人工原问答`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/manual_review/adapt_人工后续核查.md`。实验SID非Codex CLI UUID。

服务器bundle恢复和输出摘录复算不等同完整NPU复验或用户下载验证。未批准最终PR固定pair，PR eager可独立先交。


恢复顺序仍为DSpark未闭合同/匹配性能→DFlash Full8 Target/reader及SWA接口→指定Eagle。上游待外部答复只阻塞对应分支。Eagle具名采证是可独立准备的后续项，不以此取消DSpark优先级。新授权前没有设备队列自动恢复。
