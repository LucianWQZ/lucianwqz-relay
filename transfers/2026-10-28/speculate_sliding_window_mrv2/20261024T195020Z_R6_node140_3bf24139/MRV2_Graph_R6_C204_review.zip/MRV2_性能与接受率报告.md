# 性能与接受率：已测事实、回退与边界

## 口径

G_OFF=Draft Graph/Window OFF，G_ON=Draft Graph/W1024，E_ON=同窗口Draft eager；Target保持既定Graph策略。不是整个引擎eager。同Window Graph/eager端到端差包含实际padding/验证工作量，不称纯kernel效率。请求首/末token按同一客户端monotonic时钟；mean TPOT=(末次−首次非空token送达)/(实际输出tokens−1)，不是用整请求E2E反推。SSE可能一次多个token，逐token ITL分位数NOT_AVAILABLE。原始SSE/usage/框架计数有保存；工具为直接官方HTTP/SSE，不冒称AISBench。

accepted/proposed来自真实每请求框架统计：bonus/padding不计accepted/proposed；最后超出停止上限的proposal可能已被统计，不能按输出数倒算。平均接受长度=1+accepted/verification_request_steps，含bonus。TP复制rank计数不重复累加。接受率不是业务质量。

## C185：同机同候选、完整有限平衡组

每臂2独立服务（前/逆序块）×每实例3重复，**6观察而非6启动**；固定请求/采样/maxlen24576/maxseq4，完整预热，缓存引擎ON但idle native reset与固定salt后actual_cached_tokens=0。正式72组/108请求，36预热不计。normal关闭完整Target dump/连续参考/LIFE逐代同步/native verbose/重型observer，保留轻量CPU审计和原生统计；未量化其独立Host成本。无外来device context观察不代表整机独占证明。

|负载|G_OFF/G_ON/E_ON中位秒|Window耗时节省|同Window Graph耗时节省|
|---|---|---:|---:|
|257/256，c1|4.962736 / 4.938499 / 5.416848|+0.49%|+8.83%|
|8193/512，c1|12.283477 / 14.935678 / 16.133031|**−21.59%**|+7.42%|
|realtext16385/512，c1|14.230234 / 11.643295 / 12.511821|+18.18%|+6.94%|
|混合[127,2049,8193]/各256，c3|11.581193 / 12.966991 / 13.466588|**−11.97%**|+3.71%|

8K接受率39.12%→33.48%，验证请求步743→834；16K36.70%→55.11%、782→568；混合34.21%→25.73%、1241→1518。工作量改变解释部分端到端变化，不能把全部归某个kernel。短OFF最慢8.37955秒对应97验证步、其余中位55，原慢例保留。两对proposal/accepted/逐位置计数全同且start=0的短样本，ON仍慢6.78%/5.17%；准备开销未消失。并发c3没有自动消除波动或回退。36对输出OFF/ON 21对相同、ON/EON34对相同，仅自然轨迹观察，不豁免C151。

## C204：新增32K/2000/n4/c1前向pilot

同候选/同140、maxlen36864、TP16/K8/W1024、四条固定circular-shift重复realtext token流，非师傅GSM8K/独立数据集；输入32000、输出2000、4请求串行。C201前工具guard拒绝、C20249152 KV需5.06GiB/仅4.11GiB失败均保留；C204只调整unused容量，未改K/W/采样/util0.6。

|臂|实际正式组|elapsed秒|accepted/proposed；验证请求步|状态|
|---|---:|---|---|---|
|G_OFF|1|474.264420，16.8682输出tok/s|2835/41304=6.8637%；5163；MAL1.5491|原3重复未齐，自身40min timeout；独立完整组SSE/rank/reset已核验|
|G_ON|3|196.958977、196.341399、196.691099；中位196.691099，40.6729tok/s|每组6131/14992=40.8951%；1874；MAL4.2716|producer/checker/all16限定接受，仍仅一启动3同实例重复|
|E_ON|0|NOT_AVAILABLE|NOT_AVAILABLE|剩余窗口不能保留45min收尾，NOT_RUN|

OFF预热548.878秒、ON208.883秒以及初始化/RPC/reset全部排除。ON中位相对单个OFF组描述性少58.53%，但**1 vs3、不平衡、无逆序块**，不作稳定/正式性能验收或代码优化幅度。主要同时发生验证步5163→1874、接受率6.86%→40.90%的工作量变化；不能冒称纯FIA裁窗速度。当前32K Graph/eager收益缺失；C185对应旧负载有匹配对照，但不跨负载/候选拼成32K结果。

## 已采取与未解决

未删除exact等待、未启用旧counter/single-metadata原型、未换CPU上界或底层栈来凑速度。本轮性能代码无新生产优化；补测显示长度/输出/接受率会改变收益。R4短/8K负收益、R5 16K收益和C185负例均保留。用户接受的“>5%回退触发定位、长上下文争取≥5%”只是诊断建议，非正式门槛；正确性/质量与性能分别裁决，当前均不宣称发布性能PASS。

逐次CSV、完整框架计数/逐位置结果、源profile及原始日志索引在evidence。CPU/RAM/HBM真实峰值NOT_AVAILABLE；有管理采样，不能当连续峰值或无干扰保证。

## C204已取得的服务指标（逐请求，不是group elapsed反推）

|臂|可核验正式请求数|E2E中位秒|TTFT中位秒|mean TPOT中位ms|
|---|---:|---:|---:|---:|
|G_OFF|4|117.781503|4.989417|56.424125|
|G_ON|12|49.416450|5.129092|22.152263|

单请求SSE首/末token与usage逐项核对；OFF4、ON12请求来自不同数量同实例重复，不能称独立数据集或平衡置信区间。ITL分位数仍缺失。
