# 候选、producer、checker与证据归属

|候选/角色|真实结果|证据及复用边界|
|---|---|---|
|C138 producer / C140 checker|两臂GLM TP16全特性服务、10对token限定一致|不同于C151较长/混合自然轨迹，不能消除其FAIL|
|C147|CP两臂14样本/all16、Full写/ABA/Target224|evidence/C147_Target224_full_join.json完整逐对，不是仅摘要；串行诊断|
|C151 / C158 / C160|三臂各自服务/阶段通过；token配对及跨M失败；首层Native部分归因|同前态同M比较通过；不同M/自然轨迹需分开裁决|
|C157|eager每rank522代、520回收，两lane各260、末2持有|已有event诊断，不替代正常Graph最后consumer|
|C159 producer/C164 checker|GLM DFlash14数值/ABA/Full写及Target224|evidence/C159_C164_Target224_full_join.json；不证明业务质量或新Q023加载组合|
|C195 `fbf9d89ed47400dbe5099ef246ef96033fd4c079` / C196 `68725a835d1b7295ca809b61082e491ce47de4a8`|Full8实际eager参考、TP4每rank3样本数值接受|C196修exact=Full_end−start关联，只离线；不归最终SHA新NPU|
|C190 / C192|指定Qwen3.6 Eagle TP2 OFF/ON，各5×32token锚点|actual2rank/first+AR Host调用/ON裁窗；接受率响应NA，无完整数值/Target|
|C200 `266494744766fb199017df575c630167b4224cf6`|6consumer/rank通过，7th输出FAIL；preKV所有权反事实成立|默认关闭诊断修复；旧V前态NaN不是新生产写集合结论|
|C203 `ac70fbf6d35c6bda2981f0d38f2e0d199f5b42d1`|42Host/实际TP2；7th仍失败，owned=legacy|取证假设未成立；完整result、执行关联、独立复算和失败张量均附|
|C201/C202|前者旧工具guard在模型前拒绝；后者all16加载后KV容量不足|不算数值失败；C202自身有序SIGTERM记录，非外来终止|
|C204 `06fafe0da5f690bbd7accb21984063b53fb60031`|50Host容量合同；32K G_OFF1完整组/timeout，G_ON3正式组限定接受|GON所有rank和原件校验，EON NOT_RUN；正常GLM生产路径相对C185无新增行为|
|C185 `26fe310d3bcd55e6cdc83a5d72bd24fb26846d50`|完整有限三臂6观察/cell|2独立启动/臂，不是6启动。C185_to_C204_source_impact逐文件说明复用，不移植结果身份|

最后C204只改实验容量profile至36864；其production与C203相同。C185→C204仅5个production文件差异，均在默认关闭数值诊断或其他方法分支；GLM DSpark普通路径未改，但新32K工作量仍单独测量。source目录及完整diff可核查。
