# 正常Graph合同与证据边界

## 要保证什么

Window只改Draft读取table视图与有效长度；canonical Full表、绝对positions、写slots和Target不被污染；本代exact/row/generation对应；仍有reader消费的backing不能复用。Host返回、retire、HTTP完成、日志落盘或进程退出不等于最后设备consumer完成。这些来自用户/Frozen Design正确性要求，不是一个可自动豁免的观测脚本。

## 实际已有平台依据

适用140 A3/910_9382、CANN9.1/runtime_v100、PTA2.10.0.post4/git5dd8ef3f：capture辅助流尾notify合流→RI endGraphNotify与current FIFO；单update流/ExternalEvent协议；每代wait-current前缀；FIA Host长度vector拥有拷贝。实际加载版本/hash及调用链已记录，不能笼统说“没有平台依据”。这些材料支持在列明前提下的语义与复用安全工程推导；没有新具体缺边时，不逐代强制同步、不追每个二进制分支。

## 分别裁决

|主张|依据|边界/剩余|
|---|---|---|
|UPDATE当代绑定/精确长度|固定Source/API、current generation/epoch/row检查、CP连续数值/ABA|实际native执行实例operand尚无直接字段；不能拿最终导出参数或同shape相邻task硬配|
|下一次写入在最后reader之后|stream/ExternalEvent/notify合流协议、正常请求、已有异常隔离|诊断LIFE带额外同步；eager event不是Graph证明；具体适用性及原验收方式待用户/师傅审查|
|窗口数值语义/Full写/Target|独立canonical投影与实际eager、Full KV写集合、双臂Target联合|同底层算子共同失效风险；不覆盖未测模型/自然轨迹|
|physical read-set|当前无可用直接观测字段|NOT_AVAILABLE/UNPROVEN；窗外扰动无数值影响≠硬件地址没读；未批准替代门槛|
|Eagle当前差异|C203实际有效输出失败，KV精确且owned=legacy|这是具体未解失败，不能以平台证据方式调整豁免|

原生参数导出只作POST_DRAIN_EXPORTED_PARAMETERS_ONLY，合成ts/dur非真实执行时间线。现有公开Source/API合同足以支持哪些工程推导可供审查，不能无限要求不可得字段；同时用户已明确未豁免原正确性/证据要求。physical/operand取证方式是否团队硬发布条件，其团队原始出处尚需核对，不能把旧Agent建议冒充团队规则。

## 待裁决的具体事项

1. 用户/师傅确认R6-C151-TOKEN-01：同前态同M同窗口数值、不同padding原生数值、自然最终轨迹三类要求分别是什么；保留C158/C151原FAIL，C160只解释首层组件，不套PR Q017。
2. 对上述固定平台Source/API+独立数值+正常/异常证据，确认能否满足对应正常reader验收，或给出明确缺失保证/平台能力；负责人待确认。提交问题不等于已关闭。
3. C184另需当前A3/CANN9.1 pagedTND/GQA8:2/D128/正长度/mask组合准确API约束；这是特定调用合法性，不笼统问“FIA支持否”，不认定平台缺陷。用户已说无可确认owner/已知限制，本轮不反复追问。

网页GPT意见仅独立技术建议，不变设备结果或发布批准。完整历史审查来源与技术子包/人工台账原答一并追溯，不新增虚构审批制度。


## 包内可独立核查的来源原件

`evidence/normal_contract/C147_normal_Async_source_contract.json`含固定vLLM/Ascend调用链、源hash及逐行片段；`C158_parallel_normal_contract_applicability.json`记录并行路径适用前提。`platform_copy_sources`保留与实际PTA Git版本对应的拷贝/Host allocator源码和出处。`evidence/historical_R4_sources/REQUIREMENT_EXCERPTS.json`及requirement_sources保留原需求/设计/历史Agent要求分层片段；旧R4来源只作原始出处，不把其旧PASS或910_B_93源码分支自动当当前A3完整适用证明。当前安装与worker实际加载身份另见environment_identity及C203/C204 provenance。负责人、验收批准仍未补造。
