# Graph R6 / C204 小型审查交付

**NOT_READY，整体目标尚未完成；public Graph Gate冻结。** 本包保存限定通过、原失败和未完成项，不是发布批准。实际机器node-25-140。原硬截止北京时间2026-10-28 03:21:18.369，已停止新派发并释放自己的设备/后台进程，后续设备工作需新授权。

先读《MRV2_持续开发阶段总结》《正常Graph合同审查》《性能与接受率报告》《Eagle3_K后态首因与修复验证》。C204最终开发/32K producer，C203指定Eagle producer与C204 production子树相同；旧C147/C159/C185等保持原producer身份。管理估算58/100不等于验收通过率。

## 无服务器、无Torch也能复算的部分

解压后执行（Python标准库，不调用NPU）：

```bash
python3 evidence/hidden_outputs_C195_C200/offline_recheck.py
python3 evidence/hidden_outputs_C203/offline_recheck.py
```

第一条应重现Full8的12对有效输出完全一致、C200的24对一致和4对原失败（7009元素、max0.5）。第二条应重现C203的24对一致、4对失败（7296元素、max0.3125），并确认4个失败输出owned与legacy相同。脚本exit0表示**如实重现声明的输出观察，包括失败**，不是将Eagle变成PASS。这些EXCERPT没有完整KV、Target或所有consumer，不可作为完整artifact交给原checker。

完整224对DSpark、224对GLM DFlash Target联合裁决与执行关联在evidence，旧C91和此前漏包的C33完整join也带入；大KV/trace留服务器完整raw索引。C184原生输出/调用参数/API来源在小包，但完整输入49.6MB需按optional_native_repro_input.json另取。API合法性/完整官方模型归属仍缺证据，不能将原生复现认定平台缺陷。

## 源码恢复

Git bundle单独下载，依赖官方Ascend基线52ce43b15172fce79297ae4f20612fec3a476f3f，不包含权重、native环境或配套vLLM对象。bundle_recovery_check.json记录已在无alternates临时仓中取得精确baseline、verify/fetch/checkout C204、tree匹配及fsck通过。当前配套vLLM固定84030bbe，不自动换PR pin。source/与diff供直接审代码。

## 验证边界

PACKAGE_FILES.json列包内文件bytes/SHA256（不自索引）；技术子包有独立子集索引。DOWNLOAD_MANIFEST.json和package_selfcheck.json在下载目录，记录ZIP CRC/全部成员hash、解压后CPU复算与损坏样本拒绝。服务器自检与源码bundle恢复已核验；用户下载接收校验、网页独立评审和完整NPU重跑均没有因打包而新增。没有复制认证、全局配置或会话数据库。历史源码/设计片段明确标历史，未扩大硬件/版本适用性。
