# Profiling：已有依据与未证明项

本续跑未新增大trace。普通GLM生产时序相对C185未变，诊断Eagle额外D2D不用于性能结论；已复用既有前缀解析和工作量对照，不重复采看不到的physical-read字段。

C110旧GLM TP16 G_ON、16385输入/512输出、**async_scheduling=false**的rank0 trace：174次4字节int32 exact snapshot，均值55.380ms，p50 55.217、p95 58.013，范围总9.636s；其中_to_copy9.601s/99.64%。这是Host等待位置，不是可删除的9.6s净开销。C98同负载OFF metadata _to_copy6.353ms/次，ON snapshot6.602ms/次，OFF也承担类似前序等待。

该C110解析只有725494个完整事件对象的前缀，官方导出被中断，无device/generation-bound occurrence/operand/physical-read字段；不可冒充当前C204 Async联合配置时间线。Host各嵌套/跨stream duration不相加成elapsed；Host/device时钟未校准不相减。

source/API材料已确认本代exact来自NPU seq_lens，CPU optimistic upper在Async下不自然等价。未删除必要边、未把等待搬到别处宣称优化。C185/C204的Target验证次数、接受率和padding信息可解释工作量，不能按相邻算子/同shape硬配某generation或把没有方向/bytes的MEMCPY写成带宽。

evidence/historical_C110_exact_wait_origin.md和historical_snapshot_source_argument.md含原始case/trace/解析脚本索引及版本；这些历史“下一步C133”等仅历史，不控制派发。当前profiling剩余只有具名新问题才补一个有限采集；不要全量重解析/重采几十GiB作为所有工作的默认前置。
