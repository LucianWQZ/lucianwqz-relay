# 实际多rank与必需组合

GLM DSpark主配置：K8/Q8、Target Q9、W1024/B128、TP16/DP1/EP；Target SFA/legacy DSA-CP，Draft合法FIA/SP路径。配置capture[16,32,48]，实际库存/descriptor在worker原件，不按该数组猜所有query形状。有效Graph模式FULL_DECODE_ONLY；FULL decode descriptor不代表整个FULL/PIECEWISE已验。

|项目|已实际取得|限制|
|---|---|---|
|16rank/物理映射|C138/C147/C151/C159/C185、当前C204完整16rank及PID/PCI关联|rank0或Host配置不替代all16；每case实际映射原件保留|
|FlashComm/SP|GLM配置资格、真实调用路径与rank记录|不是逐kernel物理occurrence证明；E_ON的Draft是否适用SP按实际query/路径，不强迫与Target一致|
|legacy DSA-CP|明确enable_dsa_cp、对应SFA/Full-write/metadata合同、CP数值14场景|没有用PCP替代；Target SFA不意味着需要另找Draft SFA权重|
|Async|实际三臂服务及eager event回收，已有Python异常隔离|Graph正常最后consumer仅源码/API论证及正常行为，不当串行LIFE完成证明|
|chunked|C138/151真实continuing/terminal，C151 mixed/decode/请求替换|只配置参数不算触发；C185/204性能负载不替代全部scheduler覆盖|
|prefix|C138/151实际hit兼容；性能C185/204引擎ON但真实cached0|命中与无命中用途分开，没有新增全排列矩阵|
|Target/Draft Graph|实际库存、Host replay及worker/device关联、正常服务|不把仅Target开图或probe capture当Draft产品通过|
|Qwen Full8 TP4/DP2|C165 OFF经C167只读ID纠正；C172 ON，各8请求×256，真实8单元|不是GLM TP16或SWA DP2证明|
|Qwen Eagle TP2|C190 OFF/ON自然锚点；C203两rank数值前哨FAIL|没有以TP2替代TP16，没有扩成所有Eagle拓扑|

配置、Host调用、设备context、数值、完成依赖分别裁决。一般参数出现或Host manager次数不等于设备执行次数；数据索引中保留实际argv、卡、PID、原始结果与scoped限制。
