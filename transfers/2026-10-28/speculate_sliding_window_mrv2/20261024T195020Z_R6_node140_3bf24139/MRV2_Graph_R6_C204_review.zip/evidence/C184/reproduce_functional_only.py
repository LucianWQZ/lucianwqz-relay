# SPDX-License-Identifier: Apache-2.0
"""Standalone saved-input FIA discriminator: fresh functional calls only.

Three active requests, compact ND KV, no hand-made out/LSE or Graph call.
This combined diagnostic removes earlier out-call state and unspecified
padding/LSE conventions; it does not identify which variable caused a change.
Requires torch, torch_npu and safetensors, not vLLM or model weights.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

if __name__=='__main__':
    # A direct tools/*.py invocation must not shadow stdlib bisect.
    sys.path[:]=[p for p in sys.path if Path(p or '.').resolve()!=Path(__file__).parent.resolve()]

import torch
from safetensors.torch import load_file, save_file


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def inputs(path, view='current-window'):
    manifest=json.loads(Path(path).read_text())
    data_path=Path(manifest['data']['path'])
    if not data_path.exists():data_path=Path(path).parent/data_path.name
    require(digest(data_path)==manifest['data']['sha256'],'saved operand bytes changed')
    data=load_file(data_path)
    require(view in ('current-window','canonical-off'),'named saved read view required')
    if view=='canonical-off':
        origin=manifest['canonical_off']
        require(origin['table_dtype']=='torch.int32' and origin['full_lengths']==[36889,8201,395,0]
                and origin['attention_call_and_cached_view_equal_to_official_base'] is True,
                'canonical Full metadata or official-call source identity missing')
        data['table']=torch.tensor(origin['table'],dtype=torch.int32)
        manifest=dict(manifest,metadata=dict(manifest['metadata'],kv_lengths=origin['full_lengths']))
    meta=manifest['metadata'];q,k,v,t,s=(data[n] for n in ('query','key','value','table','selected'))
    require(q.dtype==k.dtype==v.dtype==torch.bfloat16 and q.shape==(32,8,128)
            and k.shape==v.shape==(s.numel(),128,2,128) and s.dtype==torch.int64
            and s.tolist()==sorted(set(s.tolist())) and int(s.min())>=0
            and t.dtype==torch.int32 and t.ndim==2 and t.shape[0]==4,
            'saved rank0 BF16/GQA/TND/page contract changed')
    lengths=meta['kv_lengths'][:3];bound=int(s.max())+1
    require(lengths==([36889,8201,395] if view=='canonical-off' else [32793,8201,395])
            and meta['query_lengths']==[8,16,24,32]
            and meta['kv_lengths'][3]==0 and bound*128*256<2**31,
            'this discriminator must retain the named active lengths and bounded ND capacity')
    for row,length in enumerate(lengths):
        used=t[row,:(length+127)//128]
        require(used.numel()==(length+127)//128 and set(used.tolist())<=set(s.tolist()),
                'some actually readable page was not saved')
    require(bool((t[:3]>=0).all() and (t[:3]<bound).all())
            and all(bool(torch.isfinite(x).all()) for x in (q,k,v)),
            'invalid page index or nonfinite saved input')
    return manifest,data,bound


def parameters(manifest):
    return dict(atten_mask=None,input_layout='TND',block_size=128,num_key_value_heads=2,num_heads=8,
                scale=128**-.5,sparse_mode=0,pre_tokens=2147483647,next_tokens=2147483647,
                actual_seq_lengths=[8,16,24],actual_seq_lengths_kv=list(manifest['metadata']['kv_lengths'][:3]),
                inner_precise=0,softmax_lse_flag=False)


def check(path):
    result=json.loads(Path(path).read_text());manifest,data,bound=inputs(result['input'],result.get('view','current-window'))
    require(not result['pending'] and digest(result['raw']['path'])==result['raw']['sha256'],
            'unfinished execution or changed raw outputs')
    require(result['input_manifest_sha256']==digest(result['input'])
            and result['tool_sha256']==digest(__file__) and result['scalar']==parameters(manifest)
            and result['shape']==[bound,128,256] and result['strides']==[32768,256,1] and result['format']==2,
            'saved call scalars/source/ND layout changed')
    raw=load_file(result['raw']['path'])
    for when in ('before','after'):
        for part in ('key','value'):
            require(torch.equal(raw[when+'_'+part],data[part].reshape(-1,128,256)),
                    'upload/mutation invalidates the discriminator')
        require(torch.equal(raw[when+'_query'],data['query'][:24])
                and torch.equal(raw[when+'_table'],data['table'][:3]),'query/table changed')
    reference=raw['output_0'];rows=[]
    require(reference.shape==(24,8,128) and reference.dtype==torch.bfloat16,'effective output geometry changed')
    for i in range(1,5):
        value=raw[f'output_{i}'];delta=(reference.float()-value.float()).abs()
        require(value.shape==reference.shape and value.dtype==reference.dtype,'output ABI changed')
        flat=int(delta.argmax());q,h,d=flat//1024,flat%1024//128,flat%128
        rows.append(dict(repeat=i,finite=bool(torch.isfinite(reference).all() and torch.isfinite(value).all()),
            exact_differences=int((delta!=0).sum()),max_abs=float(delta.max()),
            max_at=dict(query=q,head=h,dimension=d,first=float(reference[q,h,d]),other=float(value[q,h,d]))))
    return dict(status='NATIVE_ACTIVE_FUNCTIONAL_REPEAT_DIFFERENCE' if any(r['exact_differences'] for r in rows)
                else 'NOT_REPRODUCED_FRESH_FUNCTIONAL_ACTIVE3_COMPACT',comparisons=rows,
                input_readbacks_exact=True,valid_rows=[0,24],api_eligibility='REQUIRES_VERSION_SPECIFIC_REVIEW',
                original_model_failure='UNCHANGED_NO_WAIVER',scope='No native determinism or release precision guarantee inferred')


def run(args):
    import torch_npu
    manifest,data,bound=inputs(args.input,args.view)
    require(not args.output.exists(),'new output directory required');args.output.mkdir(parents=True)
    pending=False;raw={}
    try:
        pending=True
        key=torch.zeros(bound*128*256,dtype=torch.bfloat16,device='npu:0').view(bound,128,256)
        value=torch.zeros_like(key);index=data['selected'].to('npu:0')
        for target,part in ((key,'key'),(value,'value')):
            target.index_copy_(0,index,data[part].reshape(-1,128,256).to('npu:0'))
        query=data['query'][:24].to('npu:0');table=data['table'][:3].to('npu:0')
        torch.npu.synchronize();pending=False
        require(torch_npu.get_npu_format(key)==torch_npu.get_npu_format(value)==2,
                'compact cache must retain the saved ND format')
        scalar=parameters(manifest)
        fingerprint=json.dumps(scalar,sort_keys=True)
        for when in ('before','after'):
            pending=True
            raw[when+'_key']=key.index_select(0,index).cpu().clone()
            raw[when+'_value']=value.index_select(0,index).cpu().clone()
            raw[when+'_query']=query.cpu().clone();raw[when+'_table']=table.cpu().clone()
            pending=False
            if when=='before':
                for i in range(5):
                    pending=True
                    output,_lse=torch_npu.npu_fused_infer_attention_score(query,key,value,block_table=table,**scalar)
                    torch.npu.synchronize();raw[f'output_{i}']=output.detach().cpu().clone();pending=False
                    require(json.dumps(scalar,sort_keys=True)==fingerprint,'Host scalar/list arguments mutated')
        file=args.output/'raw.safetensors';save_file(raw,str(file))
        loaded=sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines()
                       if any(name in line for name in ('libtorch_npu','libopapi','libcust_opapi','libruntime_v100','libascendcl'))})
        write(args.output/'result.json',dict(input=str(args.input),input_manifest_sha256=digest(args.input),
            view=args.view,pending=False,scalar=scalar,
            pid=os.getpid(),start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],
            versions=dict(torch=str(torch.__version__),torch_npu=str(torch_npu.__version__)),
            loaded_libraries=[dict(path=p,sha256=digest(p)) for p in loaded],
            operator_paths={name:os.environ.get(name) for name in ('ASCEND_CUSTOM_OPP_PATH','ASCEND_OPP_PATH','LD_LIBRARY_PATH')},
            tool_sha256=digest(__file__),shape=list(key.shape),strides=list(key.stride()),format=int(torch_npu.get_npu_format(key)),
            raw=dict(path=str(file),sha256=digest(file)),lse='Allocated by the functional PTA wrapper, never supplied by this script'))
        time.sleep(10)  # External PID/device association, outside model or performance timing.
    except BaseException:
        write(args.output/'failure.json',dict(pending=pending,traceback=traceback.format_exc(),post_failure_device_operations='NONE'))
        os._exit(74)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('command',choices=('run','check','cpu-check'))
    parser.add_argument('--input',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--view',choices=('current-window','canonical-off'),default='current-window')
    args=parser.parse_args();torch.set_num_threads(2)
    if args.command=='run':run(args)
    elif args.command=='check':write(args.output,check(args.input))
    else:
        manifest,data,bound=inputs(args.input,args.view)
        write(args.output,dict(status='CPU_INPUT_CHECK_ONLY',kv_bound=bound,kv_elements=bound*128*256,
                              active_lengths=manifest['metadata']['kv_lengths'][:3],valid_query_rows=[0,24]))


if __name__=='__main__':main()
