from pathlib import Path
import json,hashlib,datetime
import torch
from safetensors.torch import load_file
torch.set_num_threads(2)
root=Path(__file__).resolve().parent
source=json.loads((root/'probe/result.json').read_text())
file=Path(source['output']['path']);data=load_file(file)
rows=[];maximal=[];maximum=0.0
for case,padded in [('original_padded4',4),('active3_only_diagnostic',3)]:
 for phase in ['functional','out','graph_update']:
  first=data[f'{case}_{phase}_0']
  for i in range(1,5):
   other=data[f'{case}_{phase}_{i}'];delta=(first.float()-other.float()).abs();valid=delta[:24];bad=valid!=0
   value=float(valid.max());flat=int(valid.argmax());q=flat//1024;head=flat%1024//128;dim=flat%128
   row=dict(case=case,phase=phase,reference_repeat=0,compared_repeat=i,valid_query_rows=[0,24],
    exact_difference_count=int(bad.sum()),different_valid_query_rows=torch.nonzero(bad.any(2).any(1)).flatten().tolist(),
    different_valid_heads=torch.nonzero(bad.any(2).any(0)).flatten().tolist(),per_query_count=bad.sum((1,2)).tolist(),
    per_head_count=bad.sum((0,2)).tolist(),max_abs=value,max_at=dict(query=q,request_row=q//8,query_within_request=q%8,head=head,head_dimension=dim,
      first=float(first[q,head,dim]),other=float(other[q,head,dim])),
    finite_valid=bool(torch.isfinite(first[:24]).all() and torch.isfinite(other[:24]).all()),
    observed_valid_abs_output_max=float(torch.maximum(first[:24].float().abs().max(),other[:24].float().abs().max())),
    scale_only_not_acceptance_counts={str(t):int((valid>t).sum())for t in [.01,.1,1.,5.]},
    padding_exact_difference_count=int((delta[24:]!=0).sum()),padding_abs_max=float(delta[24:].max())if padded>3 else None)
   rows.append(row)
   if value>maximum:maximum=value;maximal=[row]
   elif value==maximum:maximal.append(row)
cross=[]
for case in ['original_padded4','active3_only_diagnostic']:
 for phase in ['out','graph_update']:
  x=data[f'{case}_functional_0'][:24];y=data[f'{case}_{phase}_0'][:24];z=(x.float()-y.float()).abs()
  cross.append(dict(case=case,reference='functional_0',compared=phase+'_0',valid_exact_difference_count=int((z!=0).sum()),valid_max_abs=float(z.max())))
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),analysis_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 original_output=dict(path=str(file),sha256=hashlib.sha256(file.read_bytes()).hexdigest()),within_each_phase=rows,cross_phase_first_runs=cross,
 largest_valid_difference=maximum,largest_valid_pairs=maximal,
 comparison_contract='Raw exact-difference counts support the original model zero-difference diagnostic; no per-bit determinism guarantee of the native API inferred. Scale-only counts are descriptive, not a new tolerance.',
 valid_scope='3 active requests x8 TND query rows. Row24..31 of padded4 excluded from valid verdict, retained separately. Active3 case has no fourth request; API eligibility still requires exact version confirmation.',
 full_meaning='The sixth, noncausal Full-attention layer of the SWA6 draft. Its currently selected Full-type cache/read operands are supplied verbatim from C180 Window-ON state; not proof that this is a Window-OFF model run. Native five causal SWA layers are not invoked.')
out=root/'valid_output_analysis.json';assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(largest_valid_difference=maximum,largest_valid_pairs=maximal,within_phase=[dict(case=r['case'],phase=r['phase'],repeat=r['compared_repeat'],n=r['exact_difference_count'],max=r['max_abs'],rows=r['different_valid_query_rows'],heads=r['different_valid_heads'],padding_n=r['padding_exact_difference_count'])for r in rows]),ensure_ascii=False))
