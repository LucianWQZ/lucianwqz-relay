"""Output-only C203 excerpt verification, standard library only; expected FAIL retained."""
from pathlib import Path
import json,hashlib,struct,math
R=Path(__file__).parent;index=json.loads((R/'index.json').read_text());p=R/index['tensor_file']['path'];blob=p.read_bytes();assert hashlib.sha256(blob).hexdigest()==index['tensor_file']['sha256'];n=struct.unpack_from('<Q',blob)[0];h=json.loads(blob[8:8+n]);data=memoryview(blob)[8+n:]
def values(name,count):
 m=h[name];assert m['dtype']=='BF16';start,end=m['data_offsets'];assert 0<=start<end<=len(data)and end-start==math.prod(m['shape'])*2
 return[struct.unpack('<f',struct.pack('<I',x<<16))[0]for x in struct.unpack_from('<'+'H'*count,data,start)]
exact=different=legacy=0
for row in index['rows']:
 count=row['valid_rows']*math.prod(row['shape'][1:]);name=row['prefix'];a=values(name+'.owned',count);b=values(name+'.reference',count);assert all(math.isfinite(x)for x in a+b);diff=sum(x!=y for x,y in zip(a,b));maximum=max(abs(x-y)for x,y in zip(a,b));assert diff==row['different']and maximum==row['max_abs']
 if diff:assert row['index']==6 and diff==7296 and maximum==0.3125;different+=1
 else:exact+=1
 if name+'.legacy'in h:assert values(name+'.legacy',count)==a;legacy+=1
assert(exact,different,legacy)==(24,4,4)
print(json.dumps(dict(status='DECLARED_OUTPUT_OBSERVATIONS_REPRODUCED_INCLUDING_PRESERVED_FAILURE',exact_output_pairs=exact,different_output_pairs=different,owned_legacy_equal_pairs=legacy,scope='EXCERPT_ONLY; no full-model/KV/Target/lifetime/release PASS'),indent=2))
