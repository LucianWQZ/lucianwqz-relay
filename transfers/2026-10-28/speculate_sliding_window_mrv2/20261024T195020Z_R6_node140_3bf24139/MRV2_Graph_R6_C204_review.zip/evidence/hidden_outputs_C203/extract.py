from pathlib import Path
import json,hashlib,torch
from safetensors.torch import save_file
from tools.p7x_graph_repair6_storage import CollectionReader,digest,safe_path

torch.set_num_threads(2)
B=Path(__file__).parents[2];OUT=Path(__file__).parent;case=B/'raw/C203_qwen36_Eagle3_TP2_owned_outputs_numeric_01_node140';arrays={};rows=[]
def node(reader,index):
 e=reader.samples[index];p=safe_path(reader.path.parent,e['path']);assert digest(p)==e['sha256'];return dict(json.loads(p.read_text())['mapping'])
for rank in range(2):
 reader=CollectionReader(case/f'model/numeric/rank-{rank}/eagle-numeric.json')
 for index,entry in enumerate(reader.samples):
  if reader.incomplete(index):continue
  d=node(reader,index);active=reader.store.decode(d['active']);valid=active*(4 if reader.store.decode(d['first_pass'])else 1)
  graph=reader.store.decode(d['graph']);reference=reader.store.decode(d['reference'])
  for number,(g,r)in enumerate(zip(graph,reference)):
   prefix=f'rank{rank}.sample{index}.output{number}';arrays[prefix+'.owned']=g.clone().contiguous();arrays[prefix+'.reference']=r.clone().contiguous();delta=(g[:valid].float()-r[:valid].float()).abs()
   rows.append(dict(prefix=prefix,rank=rank,index=index,identity=entry['identity'],status=entry['status'],shape=list(g.shape),valid_rows=valid,finite=bool(torch.isfinite(g[:valid]).all()and torch.isfinite(r[:valid]).all()),different=int((g[:valid]!=r[:valid]).sum()),max_abs=float(delta.max()),sample_sha256=entry['sha256']))
 phases=CollectionReader(reader.path.with_name('eagle-completed-phases.json'))
 d=node(phases,len(phases.samples)-1);cons=d['consumers']['list'];assert len(cons)==1;last=dict(cons[0]['mapping']);legacy=phases.store.decode(last['legacy_capture_pool_outputs']);owned=phases.store.decode(last['outputs'])
 for number,(old,current)in enumerate(zip(legacy,owned)):
  assert torch.equal(old,current);arrays[f'rank{rank}.sample6.output{number}.legacy']=old.clone().contiguous()
p=OUT/'outputs.bf16.safetensors';save_file(arrays,str(p),metadata=dict(scope='EXCERPT_ONLY_NOT_COMPLETE_ARTIFACT; preserved C203 failure and same-Graph owned=legacy'))
(OUT/'index.json').write_text(json.dumps(dict(status='EXCERPT_ONLY_C203_HIDDEN_AND_LEGACY_COMPARISONS',producer='ac70fbf6d35c6bda2981f0d38f2e0d199f5b42d1',tensor_file=dict(path=p.name,bytes=p.stat().st_size,sha256=digest(p)),rows=rows,scope='No full KV/Target/lifetime/release proof; original failed/IN_PROGRESS remains'),ensure_ascii=False,indent=2,allow_nan=False)+'\n');print(dict(rows=len(rows),bytes=p.stat().st_size,sha256=digest(p)))
