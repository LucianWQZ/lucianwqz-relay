# C133/C110 exact-length 等待归因（既有 trace 离线复核）

时间：2026-10-26T17:41:42.997734+08:00；node-25-140；SESSION `20261024T195020Z_R6_node140_3bf24139`。当前 NPU 未使用，16 卡已按用户要求临时让给同事。本次只读复用旧产物，没有启动模型、采集 profiler 或修改 production。

## 结论

1. C110 的 GLM TP16、DSpark K8、G_ON、输入 16385/输出 512 的 profiling 请求中，rank0 有 174 次 exact-length snapshot。每次只有 1 个 `torch.int32`，即 4 字节；范围均值 55.380ms、p50 55.217ms、p95 58.013ms。
2. snapshot 总计 9.636s，其中其内 `aten::_to_copy` 为 9.601s，占 99.64%。该范围约占 profiled 请求 20.422s 的 47.18%，但这是 Host 阻塞位置，不是已经证明可直接删除的净开销。
3. C98 短请求的同负载对照显示：G_OFF 在 metadata 内的 `_to_copy` 为 209.659ms/33次（6.353ms/次），G_ON snapshot 内为 217.880ms/33次（6.602ms/次），差约3.92%。OFF 也在别处承担相似等待，所以删掉 snapshot 很可能把等待移到下一处读取/绑定，而非取得等额端到端收益。
4. 当前 exact 来源是 NPU `input_buffers.seq_lens`。CPU optimistic length 在异步投机解码下按“上一轮全接受”推算，只有完成专门校正后才可能等价；不能拿 upper bound、上一代缓存或未校正 CPU 值替代本代 exact。
5. 因此本轮没有 production 修改。已有 pinned H2D review 是 CPU→NPU workspace 拷贝所有权实验，方向不同，不能消除这里的 NPU→CPU exact snapshot。

## 证据范围

- C110 producer：`7a98691f9ab5c8f120e46c3d763fabd04092ffa7`；分析源码：`50c00977d6d1e8273280a6d482ce88a9c02f9fa3`。
- 原始 case：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261024T195020Z_R6_node140_3bf24139/raw/C110_glm_real16k_G_ON_profile01`；joint 为 `PASS_SCOPED_GLM_TP16_NORMAL_WORKLOAD_AND_ACCEPTANCE`，profiling arm 不计入正常重复中位数。
- trace 摘要：`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/reports/20261024T195020Z_R6_node140_3bf24139/reanalysis/C110_saved_rank0_trace_02/Summary.json`。官方 export 被中断，只解析 725494 个完整事件对象的前缀；没有 device event、generation-bound occurrence、execution operand 或 physical-read 字段。
- C98/C110 的 `draft_window_eager.py` blob 相同：`778cd0798bec3a449bb6352cca99f33be36da904`。C133 当前 blob 为 `38f18c369596c1137bc2b3e188c200fa97cdf727`，差异只在 Graph 模式不创建 eager async pool；snapshot/materialize 实现未变。
- C110 使用 `async_scheduling=false`。它可定位当前 exact 路径的等待位置，但不能冒充 C133 Async 联合配置的性能结果。

## 分项数字（rank0 Host 范围）

|范围|次数|均值 ms|p50 ms|p95 ms|总计 ms|
|---|---:|---:|---:|---:|---:|
|exact snapshot|174|55.380|55.217|58.013|9636.086|
|runtime materialize|174|0.893|0.881|1.015|155.406|
|metadata bind|174|2.374|2.207|3.254|413.153|
|UPDATE call|174|1.392|1.370|1.586|242.160|
|retire Host|174|0.116|0.108|0.174|20.158|

这些 Host 区间不能相加当设备 elapsed；跨流工作和等待位置未由这个截断 trace 直接证明。

## 最小后续动作

资源归还后先执行已经固定的 C133 两项 TP16 正确性/联合特性 case：Window OFF 的实际 SP/DSA-CP/FlashComm 底座，然后 Window ON + Async + prefix hit + chunked + Target SP/DSA-CP/FlashComm。两项通过后，如性能仍是最高优先级，再对 C133 同请求做一个有界、匹配的 control/profile 对；不能在正确性尚未建立时用 C110 同步配置的等待比例预测 C133 Async 收益。
