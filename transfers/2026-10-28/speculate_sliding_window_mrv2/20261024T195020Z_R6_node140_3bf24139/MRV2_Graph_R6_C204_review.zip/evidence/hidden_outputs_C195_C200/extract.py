from pathlib import Path
import json,hashlib,datetime as dt
import torch
from safetensors.torch import save_file
from tools.p7x_graph_repair6_storage import CollectionReader,digest,safe_path

torch.set_num_threads(2)
B=Path(__file__).parents[2]
OUT=Path(__file__).parent
arrays={};records=[]
for candidate,case,ranks,collection,kind in [
 ('C195','C195_qwen36_Full8_actual_eager_numeric3_01_node140',4,'numeric.json','full8'),
 ('C200','C200_qwen36_Eagle3_TP2_owned_prestate_numeric_01_node140',2,'eagle-numeric.json','eagle')]:
 for rank in range(ranks):
  path=B/'raw'/case/'model/numeric'/f'rank-{rank}'/collection
  reader=CollectionReader(path)
  for index,entry in enumerate(reader.samples):
   if reader.incomplete(index):continue
   p=safe_path(path.parent,entry['path'])
   assert p.stat().st_size==entry['bytes'] and digest(p)==entry['sha256']
   encoded=dict(json.loads(p.read_text())['mapping'])
   identity=reader.store.decode(encoded['identity'])
   assert identity==entry['identity']
   if kind=='full8':
    actual=identity['actual'];valid=actual*8
    graph=(reader.store.decode(encoded['graph_hidden']),)
    reference=(reader.store.decode(encoded['reference_hidden']),)
   else:
    actual=reader.store.decode(encoded['active']);first=reader.store.decode(encoded['first_pass'])
    valid=actual*(4 if first else 1)
    graph=reader.store.decode(encoded['graph']);reference=reader.store.decode(encoded['reference'])
   metrics=[]
   for number,(left,right)in enumerate(zip(graph,reference)):
    assert left.dtype==right.dtype==torch.bfloat16 and left.shape==right.shape
    prefix=f'{candidate}.rank{rank}.sample{index}.output{number}'
    arrays[prefix+'.graph']=left.clone().contiguous()
    arrays[prefix+'.reference']=right.clone().contiguous()
    l=left[:valid];rr=right[:valid];delta=(l.float()-rr.float()).abs();flat=int(delta.reshape(-1).argmax())
    metrics.append(dict(prefix=prefix,shape=list(left.shape),valid_rows=valid,finite=bool(torch.isfinite(l).all() and torch.isfinite(rr).all()),different_elements=int((l!=rr).sum()),max_abs=float(delta.max()),flat_index_in_valid_output=flat,left=float(l.reshape(-1)[flat]),right=float(rr.reshape(-1)[flat])))
   records.append(dict(candidate=candidate,rank=rank,index=index,identity=identity,raw_status=entry['status'],collection=str(path),collection_sha256=digest(path),sample=str(p),sample_sha256=digest(p),raw_execution=reader.execution,metrics=metrics))
p=OUT/'outputs.bf16.safetensors';save_file(arrays,str(p),metadata=dict(scope='EXCERPT_ONLY_NOT_A_FULL_ARTIFACT; full hidden arrays, valid rows match original checker. No KV, Target, lifetime or release verdict.'))
manifest=dict(status='EXCERPT_ONLY_FOR_INDEPENDENT_HIDDEN_OUTPUT_RECALCULATION',created_at=dt.datetime.now(dt.timezone.utc).isoformat(),selection='All completed C195 Full8 samples/all4 ranks and C200 Eagle samples/all2 ranks; hash-verified selective tensor decoding, no KV reread or model execution',validity='Full8 actual*8; Eagle actual*(4 firstpass else1), original zero-tolerance checker rules',tensor_file=dict(path=p.name,bytes=p.stat().st_size,sha256=digest(p)),records=records,limitations=['Not a complete CollectionWriter artifact; must not feed to original checker as full evidence','No full KV/Target/ABA/normal Graph lifetime proof in this excerpt','C200 execution remains IN_PROGRESS/failed, first6 consumer results do not make whole run pass'])
(OUT/'index.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(records=len(records),arrays=len(arrays),tensor_bytes=p.stat().st_size,sha256=digest(p))))
