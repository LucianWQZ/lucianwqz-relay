"""Standard-library-only EXCERPT checker; no NPU, torch, full-KV or model verdict.

Run beside index.json and outputs.bf16.safetensors. Exit0 means the declared
output-only observations, including the preserved Eagle failure, reproduced.
It does not turn a failed model campaign into a pass.
"""
from pathlib import Path
import hashlib,json,math,struct
from functools import reduce
from operator import mul

ROOT=Path(__file__).parent
manifest=json.loads((ROOT/'index.json').read_text())
assert manifest['status']=='EXCERPT_ONLY_FOR_INDEPENDENT_HIDDEN_OUTPUT_RECALCULATION'
p=ROOT/manifest['tensor_file']['path'];raw=p.read_bytes()
assert len(raw)==manifest['tensor_file']['bytes']
assert hashlib.sha256(raw).hexdigest()==manifest['tensor_file']['sha256']
length=struct.unpack_from('<Q',raw)[0];header=json.loads(raw[8:8+length]);data=memoryview(raw)[8+length:]

def values(name,valid_rows):
    entry=header[name];assert entry['dtype']=='BF16'
    first,last=entry['data_offsets'];count=reduce(mul,entry['shape'],1)
    assert 0<=first<last<=len(data) and last-first==count*2
    valid=valid_rows*reduce(mul,entry['shape'][1:],1)
    assert 0<valid<=count
    bits=struct.unpack_from('<'+'H'*valid,data,first)
    return [struct.unpack('<f',struct.pack('<I',value<<16))[0]for value in bits]

summary={'Full8_valid_output_pairs_exact':0,'Eagle_valid_output_pairs_exact':0,
         'Eagle_valid_output_pairs_different':0,'records':len(manifest['records']),
         'scope':'OUTPUT_EXCERPT_ONLY; expected failure preserved; no full-model/KV/Target/lifetime/release verdict'}
for record in manifest['records']:
    for expected in record['metrics']:
        left=values(expected['prefix']+'.graph',expected['valid_rows'])
        right=values(expected['prefix']+'.reference',expected['valid_rows'])
        finite=all(math.isfinite(x)for x in left+right)
        different=sum(a!=b for a,b in zip(left,right))
        maximum=max(abs(a-b)for a,b in zip(left,right))
        assert finite==expected['finite'] and different==expected['different_elements']
        assert maximum==expected['max_abs']
        if record['candidate']=='C195':
            assert different==0;summary['Full8_valid_output_pairs_exact']+=1
        elif different:
            assert record['index']==6 and maximum==0.5 and different==7009
            summary['Eagle_valid_output_pairs_different']+=1
        else:summary['Eagle_valid_output_pairs_exact']+=1
assert summary['records']==26 and summary['Full8_valid_output_pairs_exact']==12
assert summary['Eagle_valid_output_pairs_exact']==24 and summary['Eagle_valid_output_pairs_different']==4
print(json.dumps(summary,ensure_ascii=False,indent=2))
