# exact_length_snapshot 等待归因：R6 源码核查

本轮假设：ON 的 snapshot 等待不是独有的传输成本；OFF 可能在稍后的 metadata 构建承担同类等待。必须用同线程区间并集及端到端三臂负载检验，不能仅缩短一个范围就宣布加速。

## 源码可确认的顺序

1. pinned DFlash `propose` 先调用 `prepare_dflash_inputs`，实际 Triton kernel 用当前 `last_valid_pos`、本方法 Q 和 max_model_len 写 `input_buffers.seq_lens`，padding 写0。
2. 此后调用 `model.precompute_and_store_context_kv`，再选择真实 Graph descriptor，然后构建 metadata。
3. ON 的 `_materialize_draft_window_read_inputs` 从当前设备 seq_lens 执行 `.to(cpu,int32,copy=True)`，CPU长度用于当前 epoch 的 phase/window计划；不能以 CPU upper 或旧镜像替代。
4. OFF baseline 在 Ascend builder 中，parallel_drafting 分支将 `seq_lens` 设回设备tensor；`metadata_seq_lens_cpu` 在没有显式 CPU exact 时仍是该设备值，随后 `.tolist()` 取得列表。因此源码显示 OFF 也有一个取得本代精确长度的等待点，但具体等待覆盖哪些前序kernel不能仅由 Python 源码定量归因。
5. ON builder显式传入CPU exact，parallel_drafting下 `seq_lens_cpu_is_explicit=True` 使用该CPU值，避免这处再次设备tolist。single-metadata默认关闭的旧实验还保留本代精确materialize，只省掉实际FULL临时metadata的一次外围构建，R5约0.7ms外围减少未证明snapshot或端到端稳定改善。

## 仍未证明／下一步

- 不能把ON snapshot约7–10ms全算成小payload传输，也不能声称删除该等待可节省同等端到端时间。
- 尚无可直接复用的本代精确CPU镜像合同；prepare kernel依赖当前拒绝数，scheduler upper不是exact。
- 可能的独立优化实验：在prepare已入队、context precompute之前发起owned pinned CPU快照，使用明确完成边后再读取；这将引入新的所有权/事件及集成接线，尚未实现、更未验证，不是当前正常路径事实。需先评估vendor seam、异常隔离和current/update排序，不能通过测试driver注入即称产品已接入。
- 当前先取得6次平衡正常控制（三臂×257单请求、257三请求、16385单请求），区分接受率/验证轮数、padding和顺序噪声，再决定是否值得实现新的默认关闭快照路线。
- 高并发可摊薄Host准备成本，也改变bucket、padding、HBM工作量和接受率，不保证降低噪声。并发1/3分开统计，不混合结果来掩盖短请求回退。

所有正常性能关闭完整tensor/Target dump、串行reference、逐代LIFE同步及profiler。R6 C76仅工具计划变化，production与C66相同；新6次矩阵尚未执行。
