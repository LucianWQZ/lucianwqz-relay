> 时点说明（追加于2026-10-25T11:40:19.511099+00:00）：下文原C61/C89结论保留作为当时快照；最新设备范围及限制见本文件末尾的“R6后续验证更新”。原失败与判据未删除。

# Eagle3 K后态差异：当前定位与C61验证

## 原问题
C59和C60在long-three、generation367/epoch122、AR1、active3/padded4上输出一致但K块1/2不同，原判据正确拒绝，全部失败原件保留。

## 有区分能力的事实
C60一次导出的同一merged Graph中：AR1后态快照的K块1/2全零；紧接着AR2前态有原值。AR2后态和独立post-Graph实际缓存一致。所有参考前态恢复与最终恢复roundtrip一致。差异出现在模型内captured poststate取证链路，不能由输出一致豁免K检查。

隔离Tensor实验02以Norm scatter、BF16同block几何、两个consumer、动态正逆序及重复padding索引，比较capture内分配输出与外部预分配输出，各3代均符合独立CPU写slot参考。它没有复现完整模型问题，不归为MRV2通过。01因遗漏Norm参数失败，原件保留。

## C61修改与结果
C61 `730a295674e742d28c2479e13755e5a9abeb6226`，tree `8e5cc9cb07c5513325497df07169d93b65b51f13`。
仅默认关闭的Eagle数值诊断，按完整capture inventory在capture前固定分配poststate目的地，以index_select(out=...)写入。不变更正常模型、读Window、Full slots、query、positions、UPDATE顺序、数值容差或检查范围。38项定向Host通过；固定C60源码反例拒绝capture前缺失post owner。

在Phy14/PCI0000:81:00.0上，P0、真实CONFIG、G_OFF、G_ON均由runner接受。原9样本（3组×first/AR1/AR2）严格checker全部通过，包括原失败样本；完整K/V前后态、当前输入/代际、实际slot和独立eager调用接受。额外6个phase、9个restore的36项只读比较无差异。

## 可以与不可以得出的结论
已修复/验证：在该固定候选、模型与串行诊断范围内，poststate目的地外部持有消除了原快照不一致，原9样本可以继续严格核验。原先差异不能再直接当作已证实的正常生产K写入错误。

仍有限制：简化Tensor实验未复现完整模型问题，尚不能宣称已证明某个通用NPU allocator/kernel缺陷。诊断Graph包含额外D2D和显式drain；结果不等于正常无附加同步backing完成证据。原9场景不是严格A/B/A′反事实，ABA仍NOT_ASSESSED；完整Target隔离、Eagle LIFE/ABORT及真实多rank仍按各自分支补齐，Gate冻结。

## 直接证据（相对工作根）
- runs/20261024T195020Z_R6_node140_3bf24139/raw/C60_prepare_02/EAGLE3_NUMERIC/eagle-numeric.json（原FAIL）
- reports/20261024T195020Z_R6_node140_3bf24139/reanalysis/C60_eagle_phases_01.json（21项，2组不一致）
- runs/20261024T195020Z_R6_node140_3bf24139/raw/C61_prepare_01/EAGLE3_NUMERIC/eagle3-joint.json（完整9样本联合裁决）
- runs/20261024T195020Z_R6_node140_3bf24139/raw/C61_campaign_01/EAGLE3_NUMERIC/runner-result.json（runner接受/外部执行关联）
- reports/20261024T195020Z_R6_node140_3bf24139/reanalysis/C61_eagle_phases_01.json（36项，无差异）
- reports/20261024T195020Z_R6_node140_3bf24139/C61_external_post_host.log、C61_external_post_red_fixed_C60_direct.log

所有旧样本保留producer原SHA。新checker未放宽原v5合同；36项离线分析不是新NPU运行。

## R6后续验证更新（2026-10-25T11:40:19.511099+00:00）

原C59 K块差异的定位没有被扩大为通用kernel缺陷：C61诊断目的地预持有修复后，原9consumer严格K/V检查通过；正常路径未因该取证修复增加同步。

随后完整42consumer扩展另发现**合法consumer padding切换被生产路径错误拒绝**（C80 sample9，first-pass padded2→AR padded1），与原K快照异常分开。C89 `f096fec844e6226785bca4de33ac043d62e8773b` 按descriptor/consumer保存padding，保留proposal的请求顺序、L0/H/S、epoch、active reader及独立bank保护；不改Window数学/Full写入/UPDATE顺序，未添加normal同步。

C91 `7d49759f026b3aa02430b430e49c4e0ba54d21c3` 已在140真实完成完整14proposal／42consumer，同Window独立eager连续参考严格通过；first、AR1、AR2各自A/B可区分且A′恢复。原件 `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261024T195020Z_R6_node140_3bf24139/raw/C91_prepare_01/EAGLE3_TARGET_ON/eagle3-joint.json` 的 `numeric.status`、`numeric.ABA.consumers`、`numeric.samples` 可核查。Target同SHA OFF/ON显式14对通过，原件 `/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/reports/20261024T195020Z_R6_node140_3bf24139/reanalysis/C91_Eagle_complete_Target_join_01.json` 的 `status`、`pairs`；并非只附摘要。

C100 `fee0798c2c6addbfa2fc3bcba687fd84f8835d23` 对受影响Eagle路径又实际完成18项：P0/CONFIG、三臂锚点、原9consumer、LIFE、四个os._exit ABORT、四个真实Python异常展开及三臂scheduler。`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/dev/adapt/runs/20261024T195020Z_R6_node140_3bf24139/raw/C100_perf_01_segment_20261025T075501Z/segment_result.json` 的全部 `cases[].scoped_accepted=true`。原9consumer本身ABA仍NOT_ASSESSED；完整ABA引用C91，不倒填为C100设备结果。LIFE为有额外同步的诊断范围，ABORT及Python展开分开。

尚缺：当前候选的完整产品范围、Eagle正常性能/稳定性和最终固定pair集成继续推进；正常UPDATE/backing仅在源码/API前提内论证，执行实例operand、真实occurrence及physical-read仍UNPROVEN。以上不能因输出相同、Host retire或进程退出升级为设备最后consumer完成。public Gate仍FROZEN。
