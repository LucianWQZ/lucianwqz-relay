# SPDX-License-Identifier: Apache-2.0
"""Disposable all-rank GLM E_ON Python faults at real proposal boundaries.

Default unarmed worker extension. Uses the official HTTP service and existing
Host error-export barrier. After the fault: CPU headers, ownership and refusal
only; no tensor read, event query, device RPC, drain or recovery. A completed
forward or materialization Host call is not a completed device operation.
"""
from __future__ import annotations

import sys
from pathlib import Path

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import ast
import json
import os
import time
import uuid
import urllib.request
from types import MethodType

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair32_glm_rank import TARGET
from tools.p7x_graph_repair33_service import request, run_service
from tools.p7x_graph_repair41_rank_unwind import install_execute_error_export, validate_fault_identity
from tools.p7x_graph_repair50_glm_required_baseline import (
    GLMRequiredFeatureWorker, validate_required_features, validate_required_workers,
)
from tools.p7x_graph_repair56_glm_joint_performance import joint_serve_argv
from tools.p7x_graph_local_candidate import _git, _identity

PROFILE = 'GLM_TP16_REQUIRED_EAGER_ASYNC_AFTER_FORWARD_UNWIND_V1'
EXTENSION = 'tools.p7x_graph_repair61_glm_eager_unwind.GLMEagerUnwindWorker'
MESSAGE = 'MRV2_EAGER_AFTER_FORWARD:'


class InjectedEagerAfterForward(RuntimeError):
    pass


class InjectedEagerAfterMaterialization(RuntimeError):
    pass


def fault_contract(point):
    if point == 'after_eager_forward':
        return (PROFILE, MESSAGE, InjectedEagerAfterForward, '_run_model',
                'PASS_SCOPED_ALL16_EAGER_AFTER_FORWARD_ISOLATION')
    if point == 'after_eager_materialization':
        return ('GLM_TP16_REQUIRED_EAGER_ASYNC_AFTER_MATERIALIZATION_UNWIND_V1',
                'MRV2_EAGER_AFTER_MATERIALIZATION:', InjectedEagerAfterMaterialization,
                '_materialize_draft_window_read_inputs',
                'PASS_SCOPED_ALL16_EAGER_AFTER_MATERIALIZATION_ISOLATION')
    raise ValueError('unknown explicit eager fault boundary')


def pointers(inputs):
    # data_ptr/shape are Host storage headers, not a tensor value read.
    return {name: dict(pointer=getattr(inputs, name).data_ptr(),
                       shape=list(getattr(inputs, name).shape), dtype=str(getattr(inputs, name).dtype))
            for name in ('window_block_table', 'device_window_exact', 'cpu_window_exact')}


class EagerAfterForwardProbe:
    def __init__(self, spec, root, identity, source_rows, *, point='after_eager_forward'):
        self.spec, self.root, self.identity = spec, Path(root), identity
        self.source_rows = source_rows
        self.point = point
        _, _, _, self.attribute, _ = fault_contract(point)
        self.original = getattr(spec, self.attribute)
        self.observation = None

    def __enter__(self):
        probe = self

        def forward(_spec, *args, **kwargs):
            output = probe.original(*args, **kwargs)
            handle = getattr(_spec, '_draft_window_async_handle', None)
            if handle is not None and probe.observation is None:
                is_forward = probe.point == 'after_eager_forward'
                require(handle.preparation_started and handle.inputs is not None and output is not None
                        and handle.consumer_started is is_forward
                        and handle.state.value == ('bound' if is_forward else 'materialized')
                        and (is_forward or output is handle.inputs),
                        'real eager proposal boundary/output was not retained')
                probe.native_output = output
                probe.handle, probe.inputs = handle, handle.inputs
                probe.observation = dict(native_host_return_ns=time.monotonic_ns(),
                    point=probe.point, preparation_started=handle.preparation_started,
                    generation=handle.inputs.identity.generation_id, epoch=handle.mapping_epoch,
                    execution_lane=handle.execution_lane, requests=list(handle.ordered_request_fingerprint),
                    tp_rank=handle.inputs.identity.topology_fingerprint.tensor_parallel_rank,
                    tp_size=handle.inputs.identity.topology_fingerprint.tensor_parallel_size,
                    before=pointers(handle.inputs), consumer_started=handle.consumer_started)
                _, message, exception_type, _, _ = fault_contract(probe.point)
                raise exception_type(message + probe.identity['nonce'])
            return output

        setattr(self.spec, self.attribute, MethodType(forward, self.spec))
        return self

    def __exit__(self, kind, error, traceback):
        setattr(self.spec, self.attribute, self.original)
        require(self.observation is not None, 'fault did not reach the declared real eager boundary')
        pool, handle = self.spec._draft_window_async_pool, self.handle
        # Guard the diagnostic re-entry at the CPU epoch boundary. If quarantine
        # is broken this sentinel raises before acquire/materialize or a query.
        epoch = self.spec._draft_window_epoch_source
        original_begin = epoch.begin
        reached_epoch = False

        def refuse_before_any_device_operation(*args, **kwargs):
            nonlocal reached_epoch
            reached_epoch = True
            raise RuntimeError('UNSAFE_NEXT_SCOPE_REACHED_CPU_EPOCH_BOUNDARY')

        epoch.begin = refuse_before_any_device_operation
        try:
            try:
                with self.spec._draft_window_proposal_scope(
                    self.spec.input_batch, dummy_run=False, is_profile=False):
                    raise RuntimeError('UNSAFE_NEXT_SCOPE_ENTERED')
            except RuntimeError as refusal:
                message = str(refusal)
        finally:
            epoch.begin = original_begin
        runtime = pool._runtimes[handle.execution_lane]
        report = dict(identity=self.identity, observation=self.observation,
            exception_type=kind.__name__, exception_message=str(error),
            caught_after_unwind_ns=time.monotonic_ns(),
            pool_quarantined=pool.has_uncertain_submission, handle_state=handle.state.value,
            handle_still_owned=pool._active[handle.execution_lane] is handle,
            inputs_still_owned=handle.inputs is self.inputs,
            metadata_still_owned=handle.bound_metadata is not None,
            runtime_quarantined=runtime.quarantined_identity == self.inputs.identity,
            completion_token_absent=handle.completion_token is None,
            native_output_retained=self.point == 'after_eager_forward' and self.native_output is not None,
            prepared_inputs_retained=self.point == 'after_eager_materialization' and self.native_output is self.inputs,
            after=pointers(self.inputs), next_scope_reached_epoch=reached_epoch,
            next_scope_error=message,
            source_rows=list(self.source_rows),
            post_fault_device_operations='NONE_BY_THIS_PROBE',
            native_completion='UNKNOWN_NOT_QUERIED', native_partial_failure='NOT_INJECTED')
        write(self.root / 'eager-unwind.json', report)
        return False


class GLMEagerUnwindWorker(GLMRequiredFeatureWorker):
    def mrv2_service_worker_identity(self, nonce):
        row = super().mrv2_service_worker_identity(nonce)
        row['eager_fault_extension'] = dict(path=__file__, sha256=digest(__file__))
        self._mrv2_eager_features = row['required_features']
        return row

    def mrv2_arm_eager_unwind(self, payload):
        require(not hasattr(self, '_mrv2_eager_unwind_probe'), 'eager fault already armed')
        profile, _, _, _, _ = fault_contract(payload['point'])
        require(payload['profile'] == profile and payload['tp'] == 16
                and payload['mode'] == 'python_unwind'
                and isinstance(payload['nonce'], str) and len(payload['nonce']) == 32
                and isinstance(payload['source_sha'], str) and len(payload['source_sha']) == 40
                and all(value in '0123456789abcdef' for value in payload['nonce'] + payload['source_sha']),
                'explicit all16 same-point eager fault identity required')
        spec = self.model_runner.speculator
        require(spec.method == 'dspark' and spec.num_speculative_steps == spec.num_query_per_req == 8
                and spec.speculative_config.enforce_eager is True
                and spec._draft_window_async_pool is not None, 'actual E_ON K8 async owner required')
        identity = dict(rank=self.rank, world_size=16, pid=os.getpid(),
            process_start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
            source_sha=payload['source_sha'], nonce=payload['nonce'], mode=payload['mode'], point=payload['point'])
        actual = next(row for row in payload['worker_processes'] if row['rank'] == self.rank)
        validate_fault_identity(identity, actual, payload)
        root = Path(payload['root']) / f'rank-{self.rank}'
        probe = EagerAfterForwardProbe(spec, root, identity, self._mrv2_rank_window_generations,
                                      point=payload['point'])
        probe.required_feature_host_evidence = dict(required_features=self._mrv2_eager_features,
            scope='EXISTING_CPU_HEADERS_AND_BUILDER_RETURNS_NOT_DEVICE_COMPLETION')
        probe.__enter__()
        self._mrv2_eager_unwind_probe = probe
        install_execute_error_export(self.model_runner, probe, root / 'terminal.json', identity, payload)
        write(root / 'armed.json', dict(identity=identity, point=payload['point'], native_corruption=False))
        return identity


def serve_argv(python, port, model, arm, *, worker_provenance=False):
    require(arm == 'E_ON', 'only actual Window eager control is faulted')
    argv = joint_serve_argv(python, port, model, arm, worker_provenance=worker_provenance)
    argv[argv.index('--worker-extension-cls') + 1] = EXTENSION
    return argv


def validate_unwind(report, terminal, worker, payload):
    _, message, exception_type, _, _ = fault_contract(payload['point'])
    is_forward = payload['point'] == 'after_eager_forward'
    identity = report['identity']
    validate_fault_identity(identity, worker, payload)
    validate_fault_identity(terminal['identity'], worker, payload)
    require(report['exception_type'] == terminal['exception_type'] == exception_type.__name__
            and report['exception_message'] == terminal['exception_message'] == message + payload['nonce']
            and 'probe_export_error' not in terminal and 'required_feature_export_error' not in terminal
            and terminal['entrypoint'] in ('execute_model', 'sample_tokens')
            and set(terminal['guarded_entrypoints']) == {'execute_model', 'sample_tokens'},
            'actual intended exception/export chain differs')
    for name in ('pool_quarantined', 'handle_still_owned', 'inputs_still_owned',
                 'runtime_quarantined', 'completion_token_absent'):
        require(report[name] is True, 'uncertain reader owner not retained: ' + name)
    require(report['metadata_still_owned'] is is_forward
            and report['native_output_retained'] is is_forward
            and report['prepared_inputs_retained'] is (not is_forward),
            'forward output or pre-publication preparation ownership contradicts the fault boundary')
    observed = report['observation']
    require(all(type(value) is int and value >= 0 for value in (
                observed['native_host_return_ns'], report['caught_after_unwind_ns'], terminal['caught_ns'],
                observed['generation'], observed['epoch'], observed['execution_lane'])),
            'typed current generation/epoch and Host time required')
    headers = observed['before']
    require(set(headers) == {'window_block_table', 'device_window_exact', 'cpu_window_exact'}
            and all(type(value['pointer']) is int and value['pointer'] > 0
                    and value['dtype'] == 'torch.int32'
                    and len(value['shape']) == (2 if name == 'window_block_table' else 1)
                    and all(type(size) is int and size > 0 for size in value['shape'])
                    for name, value in headers.items()), 'owned storage headers missing or malformed')
    sources = report['source_rows']
    require(sources and sources[-1]['generation'] == observed['generation']
            and sources[-1]['epoch'] == observed['epoch']
            and sources[-1]['execution_lane'] == observed['execution_lane']
            and sources[-1]['tp_rank'] == worker['rank'] and sources[-1]['tp_size'] == 16
            and sources[-1]['requests'] == observed['requests']
            and len(observed['requests']) == 1
            and any(start > 0 for start in sources[-1]['window_starts']),
            'actual rank/current-generation clipped source association missing')
    require(report['handle_state'] == 'quarantined'
            and observed['point'] == payload['point'] and observed['preparation_started'] is True
            and observed['consumer_started'] is is_forward
            and observed['tp_rank'] == worker['rank'] and observed['tp_size'] == 16
            and observed['native_host_return_ns'] < terminal['caught_ns'] <= report['caught_after_unwind_ns']
            and observed['before'] == report['after']
            and report['next_scope_reached_epoch'] is False
            and 'quarantin' in report['next_scope_error']
            and report['post_fault_device_operations'] == 'NONE_BY_THIS_PROBE'
            and report['native_completion'] == 'UNKNOWN_NOT_QUERIED'
            and report['native_partial_failure'] == 'NOT_INJECTED',
            'reader boundary, storage identity, next-scope guard or completion claim differs')
    return dict(rank=worker['rank'], generation=observed['generation'], epoch=observed['epoch'],
                execution_lane=observed['execution_lane'], requests=observed['requests'],
                status=('SCOPED_EAGER_UNCERTAIN_READER_ISOLATION' if is_forward else
                        'SCOPED_EAGER_UNCERTAIN_PREPARATION_ISOLATION'))


def validate_error_exports(root, payload):
    """Require every actual terminal and at least one complete hashed index.

    The first escaping worker error can terminate peers after ALL terminals
    have been indexed but before peers save their duplicate indexes. This is
    the existing Tool41 Host-export contract, never a device completion edge.
    Any index that exists must still be complete and match the original bytes.
    """
    root = Path(root)
    workers = {row['rank']: row for row in payload['worker_processes']}
    require(len(workers) == payload['tp'] and set(workers) == set(range(payload['tp'])),
            'complete pre-fault worker map required')
    indexes = []
    for rank in range(payload['tp']):
        terminal = root / f'rank-{rank}/terminal.json'
        validate_fault_identity(json.loads(terminal.read_text())['identity'], workers[rank], payload)
        path = terminal.with_name('host-error-barrier.json')
        if not path.exists():
            continue
        index = json.loads(path.read_text())
        proofs = index['proofs']
        require(index['status'] == 'ALL_RANK_HOST_ERROR_EXPORTS_PRESENT_NOT_DEVICE_COMPLETION'
                and index['post_fault_device_operations'] == 'NONE'
                and index['native_completion'] == 'NOT_PROVEN'
                and len(proofs) == payload['tp']
                and all(type(proof['rank']) is int for proof in proofs)
                and sorted(proof['rank'] for proof in proofs) == list(range(payload['tp'])),
                'incomplete or contradictory Host export index')
        for proof in proofs:
            require(Path(proof['path']) == root / f"rank-{proof['rank']}/terminal.json"
                    and digest(proof['path']) == proof['sha256'], 'indexed terminal bytes or path changed')
        indexes.append(dict(rank=rank, path=str(path), sha256=digest(path)))
    require(indexes, 'no complete Host export index before process isolation')
    return dict(terminals=payload['tp'], complete_indexes=indexes,
                missing_duplicate_indexes=payload['tp'] - len(indexes), device_completion='NOT_PROVEN')


def validate_checker_source(args, campaign):
    """Explicit immutable producer/checker pair for offline-only tool fixes."""
    checker = Path(__file__).resolve().parents[1]
    source = Path(args.producer_source).resolve() if args.producer_source else checker
    checker_sha = _git(checker, 'rev-parse', 'HEAD')
    checker_tree = _git(checker, 'rev-parse', 'HEAD^{tree}')
    _identity(source, args.expected_sha, campaign['source_tree'])
    _identity(checker, checker_sha, checker_tree, ancestor=args.expected_sha)
    if source != checker:
        require(args.checker_sha == checker_sha, 'explicit fixed checker SHA required for offline reanalysis')
        require(_git(source, 'rev-parse', 'HEAD:vllm_ascend')
                == _git(checker, 'rev-parse', 'HEAD:vllm_ascend'), 'offline tool fix changed production')
        name = 'tools/p7x_graph_repair61_glm_eager_unwind.py'
        required = {'fault_contract', 'EagerAfterForwardProbe', 'GLMEagerUnwindWorker', 'serve_argv'}
        def hooks(path):
            tree = ast.parse(path.read_text())
            return {node.name: ast.dump(node, include_attributes=False)
                    for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))
                    and node.name in required}
        require(hooks(source / name) == hooks(checker / name)
                and set(hooks(source / name)) == required, 'offline reanalysis changed the actual producer hooks')
        for relative in ('tools/p7x_graph_repair41_rank_unwind.py',
                         'tools/p7x_graph_repair50_glm_required_baseline.py',
                         'tools/p7x_graph_repair56_glm_joint_performance.py'):
            require(digest(source / relative) == digest(checker / relative),
                    'offline reanalysis changed an inherited producer/feature/CLI contract')
    else:
        require(args.expected_sha == checker_sha and args.checker_sha in (None, checker_sha),
                'same-source checker identity differs')
    return source, dict(sha=checker_sha, tree=checker_tree, tool_path=__file__, tool_sha256=digest(__file__))


def check_saved(args):
    root = args.case / 'model'
    campaign = json.loads((root / 'campaign.json').read_text())
    payload = json.loads((root / 'fault-payload.json').read_text())
    receipt = json.loads(Path(campaign['admission_path']).read_text())
    source, checker = validate_checker_source(args, campaign)
    producer_tool = source / 'tools/p7x_graph_repair61_glm_eager_unwind.py'
    profile, _, _, _, accepted_status = fault_contract(args.fault_point)
    require(campaign['source_sha'] == payload['source_sha'] == args.expected_sha
            and campaign['fault_profile'] == payload['profile'] == profile
            and campaign['fault_point'] == payload['point'] == args.fault_point
            and campaign['status'] == 'FAILED' and campaign['arm'] == 'E_ON'
            and campaign['server_rc'] is not None and campaign['execution_tp'] == 16
            and campaign['requests_sha256'] == digest(args.requests)
            and campaign['admission_sha256'] == digest(campaign['admission_path'])
            and receipt['source_sha'] == args.expected_sha
            and receipt['source_tree'] == campaign['source_tree'] and receipt['tp'] == 16
            and receipt['issued_at'] <= campaign['started_at'] <= receipt['expires_at']
            and campaign['fault_tool_sha256'] == digest(producer_tool)
            and payload['parent_pid'] == campaign['pid'] and payload['root'] == str(root),
            'actual fault campaign/source/admission differs')
    name = campaign['server_argv'][campaign['server_argv'].index('--served-model-name') + 1]
    require(campaign['server_argv'] == serve_argv(campaign['server_argv'][0], args.port, name,
                                                'E_ON', worker_provenance=True), 'actual E_ON CLI differs')
    states = campaign['worker_provenance']
    require(len(states) == 1 and states[0]['phase'] == 'BEFORE_REQUESTS', 'device/worker RPC after fault')
    rows = states[0]['results']
    validate_required_workers(rows, nonce=states[0]['nonce'], source=source,
                              vllm_source=receipt['vllm_checkout'], arm='E_ON')
    armed = json.loads((root / 'all-rank-armed.json').read_text())
    request_record = json.loads((root / 'fault-client-raw.json').read_text())
    groups = json.loads(args.requests.read_text())
    body = request_record['request']
    require(len(groups) == len(groups[0]['prompts']) == 1
            and len(groups[0]['prompts'][0]['prompt_token_ids']) == 8193
            and groups[0]['max_tokens'] == body['max_tokens'] == body['min_tokens'] == 256
            and body['prompt'] == groups[0]['prompts'][0]['prompt_token_ids'] and body['model'] == name
            and type(body['seed']) is int and body['seed'] == 0
            and type(body['temperature']) in (int, float) and body['temperature'] == 0
            and type(body['max_tokens']) is type(body['min_tokens']) is int
            and body['ignore_eos'] is True
            and body['stream'] is True and body['return_token_ids'] is True
            and request_record['status'] == 'FAILED_PARTIAL_CLIENT_EVENTS'
            and campaign['start_monotonic_ns'] <= states[0]['start_ns'] < states[0]['end_ns']
            <= armed['start_ns'] < armed['end_ns'] <= request_record['start_ns']
            < request_record['end_ns'] <= campaign['end_monotonic_ns']
            and len(armed['results']) == len(payload['worker_processes']) == 16,
            'actual failed request, allrank arm or invocation timing differs')
    ranks, features = [], []
    for row in sorted(rows, key=lambda item: item['rank_snapshot']['rank']):
        worker = row['rank_snapshot']
        rank_root = root / f'rank-{worker["rank"]}'
        ack = [item for item in armed['results'] if item['rank'] == worker['rank']]
        require(len(ack) == 1, 'missing or duplicate armed rank')
        validate_fault_identity(ack[0], worker, payload)
        require(row['eager_fault_extension'] == dict(path=str(producer_tool), sha256=digest(producer_tool)),
                'actual worker extension is not this fixed source')
        report = json.loads((rank_root / 'eager-unwind.json').read_text())
        terminal = json.loads((rank_root / 'terminal.json').read_text())
        ranks.append(validate_unwind(report, terminal, worker, payload))
        feature = terminal['required_feature_host_evidence']
        initial, final = row['required_features'], feature['required_features']
        require(set(initial) == set(final) and all(final[key] == initial[key]
                for key in initial if key != 'actual_metadata_audit'), 'effective fault features changed')
        features.append(feature)
    exports = validate_error_exports(root, payload)
    require(all((row['epoch'], row['requests']) == (ranks[0]['epoch'], ranks[0]['requests']) for row in ranks),
            'allrank fault belongs to different business generations')
    validate_required_features(features, require_execution=True, require_graph_window=False)
    return dict(status=accepted_status, producer_sha=args.expected_sha, producer_source=str(source),
        checker=checker, host_export_indexes=exports, fault_point=args.fault_point,
        ranks=ranks, completion='UNKNOWN_NOT_QUERIED', scope='Actual all16 declared eager boundary, Python error, Host ownership/refusal; external process/device join required; materialization fault does not execute a Draft forward',
        native_partial_submission='NOT_INJECTED', normal_completion='NOT_PROVEN', numerical='NOT_ASSESSED')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('run', 'check'))
    parser.add_argument('--expected-sha', required=True)
    parser.add_argument('--producer-source', type=Path,
                        help='check only: immutable original producer for explicit offline tool reanalysis')
    parser.add_argument('--checker-sha', help='explicit fixed checker SHA when reanalysing another producer')
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--fault-point', choices=('after_eager_forward', 'after_eager_materialization'),
                        default='after_eager_forward')
    for name in ('requests', 'output', 'admission', 'case'):
        parser.add_argument('--' + name, type=Path, required=name in ('requests', 'output'))
    args = parser.parse_args()
    if args.command == 'check':
        try:
            result = check_saved(args)
        except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
            result = dict(status='INVALID_EAGER_FAULT_EVIDENCE', error=f'{type(error).__name__}: {error}')
        write(args.output, result)
        return 0 if result['status'].startswith('PASS_SCOPED_') else 4

    require(args.producer_source is None and args.checker_sha is None,
            'producer/checker override is allowed only for read-only check')

    async def fault_client(base, model, groups, output):
        import aiohttp

        require(len(groups) == len(groups[0]['prompts']) == 1
                and len(groups[0]['prompts'][0]['prompt_token_ids']) == 8193,
                'one bounded nonaligned long request required')
        campaign = json.loads((output / 'campaign.json').read_text())
        workers = [row['rank_snapshot'] for row in campaign['worker_provenance'][0]['results']]
        profile, _, _, _, _ = fault_contract(args.fault_point)
        payload = dict(profile=profile, tp=16, mode='python_unwind', point=args.fault_point,
            nonce=uuid.uuid4().hex, source_sha=args.expected_sha, worker_processes=workers,
            root=str(output), parent_pid=os.getpid())
        write(output / 'fault-payload.json', payload)
        body = json.dumps(dict(method='mrv2_arm_eager_unwind', args=[payload], timeout=60)).encode()
        rpc = urllib.request.Request(base + '/collective_rpc', data=body,
                                     headers={'Content-Type': 'application/json'})
        started = time.monotonic_ns()
        with urllib.request.urlopen(rpc, timeout=70) as response:
            armed = json.load(response)['results']
        require(len(armed) == 16, 'complete allrank fault arm required')
        write(output / 'all-rank-armed.json', dict(start_ns=started,
              end_ns=time.monotonic_ns(), results=armed))
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=240)) as session:
            await request(session, base + '/v1/completions', model=model,
                prompt=groups[0]['prompts'][0]['prompt_token_ids'], output=groups[0]['max_tokens'],
                failure_path=output / 'fault-client-raw.json')
        raise RuntimeError('declared eager fault unexpectedly returned a completed request')

    args.arm, args.worker_provenance = 'E_ON', True
    profile, _, _, _, _ = fault_contract(args.fault_point)
    try:
        return run_service(args, server_argv_builder=serve_argv, target_model=str(TARGET), tp=16,
            ready_timeout_seconds=1800, client_runner=fault_client,
            extra_metadata=dict(fault_profile=profile, fault_point=args.fault_point,
                                fault_tool_sha256=digest(__file__)))
    except BaseException:
        # No new RPC or device action here. An exit code alone never accepts.
        reports = list(args.output.glob('rank-*/eager-unwind.json'))
        return 74 if len(reports) == 16 else 2


if __name__ == '__main__':
    raise SystemExit(main())
