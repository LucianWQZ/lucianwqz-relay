# SPDX-License-Identifier: Apache-2.0
"""Read-only existing Eagle Target evidence with a fixed newer checker.

Original attempts are immutable. A separate dependency receipt can authorize
later cases of the SAME producer/source/run; it never claims a new NPU launch.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair21_rank import digest, require, write

ACCEPTED = ("PASS_SCOPED_EAGLE3_TARGET_PREFIX", "PASS_SCOPED_EAGLE3_TARGET_ARM")


def receipt(plan, case_id, joined, *, checker_identity, original):
    case = plan["cases"][case_id]
    require(case.get("eagle3_target") is True, "explicit Eagle Target case required")
    require(
        case["eagle3_target_prefix"] is None
        or (type(case["eagle3_target_prefix"]) is int and case["eagle3_target_prefix"] == 1),
        "explicit full or single-prefix contract required")
    wanted = ACCEPTED[0] if case["eagle3_target_prefix"] == 1 else ACCEPTED[1]
    require(joined.get("status") == wanted, "complete strict scoped checker did not accept this case")
    require(original["source_identity"] == [plan["run_id"], plan["commit"], plan["tree"]],
            "original runner belongs to another source/run")
    require(len(checker_identity["sha"]) == 40 and len(checker_identity["tree"]) == 40, "fixed checker required")
    return dict(status="SCOPED_READONLY_REANALYSIS_ACCEPTED",
                dependency_satisfied=True,
                source_identity=original["source_identity"],
                case_id=case_id,
                producer_commit=plan["commit"],
                checker_identity=checker_identity,
                original_runner_status=original["status"],
                checker_status=joined["status"],
                result_scope="OLD_DEVICE_ARTIFACT_NEW_CHECKER_NO_NEW_NPU",
                device_validation_of_checker_commit="NOT_PERFORMED",
                public_graph_gate="FROZEN")


def recheck(plan_path, case_id, original_result, output):
    from tools.p7x_graph_local_candidate import BASE_SHA, _git, _identity, validate_local_plan
    from tools.p7x_graph_repair13_eagle import check
    plan = json.loads(Path(plan_path).read_text())
    validate_local_plan(plan)  # Exact original clean commit/tree, pin, files, config and fixture.
    case = plan["cases"][case_id]
    require(case.get("eagle3_target") is True, "only existing strict Eagle Target evidence")
    checker = Path(__file__).resolve().parents[1]
    sha, tree = _git(checker, "rev-parse", "HEAD"), _git(checker, "rev-parse", "HEAD^{tree}")
    _identity(checker, sha, tree, ancestor=BASE_SHA)
    output = Path(output)
    require(not output.exists(), "independent immutable reanalysis output required")
    output.mkdir(parents=True)
    artifact = Path(case["outputs"]) / "profile.json"
    campaign = Path(case["outputs"]) / "campaign.json"
    launch_argv = case["launch_argv"]
    launcher = Path(launch_argv[launch_argv.index("--output") + 1]) / "launcher.json"
    original = json.loads(Path(original_result).read_text())
    # The unchanged independent execution join and complete raw storage readers
    # run again. Original producer self-report/exit0 is never sufficient.
    joined = check(json.loads(artifact.read_text()), json.loads(campaign.read_text()), json.loads(launcher.read_text()),
                   case, artifact)
    write(output / "joint.json", joined)
    identity = dict(sha=sha, tree=tree, source=str(checker), tool_sha256=digest(__file__))
    result = dict(status="REANALYSIS_REJECTED",
                  dependency_satisfied=False,
                  source_identity=[plan["run_id"], plan["commit"], plan["tree"]],
                  producer_commit=plan["commit"],
                  checker_identity=identity,
                  result_scope="OLD_DEVICE_ARTIFACT_NEW_CHECKER_NO_NEW_NPU")
    try:
        result = receipt(plan, case_id, joined, checker_identity=identity, original=original)
    except (ValueError, KeyError, TypeError) as error:
        result["error"] = str(error)
    result.update(original_result=dict(path=str(original_result), sha256=digest(original_result)),
                  plan=dict(path=str(plan_path), sha256=digest(plan_path)),
                  campaign=dict(path=str(campaign), sha256=digest(campaign)),
                  launcher=dict(path=str(launcher), sha256=digest(launcher)),
                  joined=dict(path=str(output / "joint.json"), sha256=digest(output / "joint.json")))
    write(output / "runner-result.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("plan", "original-result", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    import torch
    torch.set_num_threads(2)
    result = recheck(args.plan, args.case_id, args.original_result, args.output)
    return 0 if result["dependency_satisfied"] else 4


if __name__ == "__main__":
    raise SystemExit(main())
