# SPDX-License-Identifier: Apache-2.0
"""Read-only three-arm service token join after actual GLM phase checks.

Rechecks every arm using its fixed producer's checker and revalidates saved
process/device associations. Compares whole requests, not intermediate tensors
from different speculative trajectories. Never launches a model or device probe.
"""
from __future__ import annotations

import sys
from pathlib import Path

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import json
import os
import subprocess

from tools.p7x_graph_local_candidate import _identity
from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair30_device_join import validate_association
from tools.p7x_graph_repair52_glm_feature_pair import raw_rows
from tools.p7x_graph_repair59_glm_service_phases import PROFILE

ARMS = ('G_OFF', 'G_ON', 'E_ON')


def compare_documents(documents):
    require(set(documents) == set(ARMS), 'all three raw service documents required')
    rows = {arm: raw_rows(documents[arm]) for arm in ARMS}
    require(len({len(value) for value in rows.values()}) == 1, 'three-arm request count differs')
    pairs = []
    for ordinal, reference in enumerate(rows['G_ON']):
        for arm in ('G_OFF', 'E_ON'):
            other = rows[arm][ordinal]
            require(reference['key'] == other['key']
                    and reference['request_sha256'] == other['request_sha256'],
                    f'{arm} whole-request business identity differs at {ordinal}')
            require(reference['tokens'] == other['tokens'],
                    f'{arm}/G_ON whole-request tokens differ at {reference["key"]}')
        pairs.append({key: reference[key] for key in (
            'key', 'request_sha256', 'prompt_tokens', 'output_tokens', 'output_sha256')})
    require(bool(pairs), 'at least one complete three-arm request required')
    return pairs


def recheck_case(root, arm, args, check_root):
    campaign = json.loads((root / 'model/campaign.json').read_text())
    result = json.loads((root / 'result.json').read_text())
    require(campaign['source_sha'] == result['source_sha'] == args.producer_sha
            and campaign['source_tree'] == result['source_tree'] == args.producer_tree
            and campaign['arm'] == arm and campaign['phase_profile'] == PROFILE
            and campaign['requests_sha256'] == digest(args.requests)
            and result['scoped_accepted'] is True
            and result['device_ranks_associated'] == 16,
            'declared producer, complete rank set or phase arm differs')
    receipt = json.loads(Path(campaign['admission_path']).read_text())
    port = campaign['server_argv'][campaign['server_argv'].index('--port') + 1]
    output = check_root / f'{arm}.json'
    argv = [sys.executable, str(args.producer_source / 'tools/p7x_graph_repair59_glm_service_phases.py'),
        'check', '--arm', arm, '--expected-sha', args.producer_sha, '--port', port,
        '--requests', str(args.requests), '--campaign', str(root / 'model/campaign.json'),
        '--records', str(root / 'model/requests.json'), '--server-argv', str(root / 'server-argv.json'),
        '--output', str(output)]
    env = os.environ.copy()
    env['PYTHONPATH'] = f'{args.producer_source}:{receipt["vllm_checkout"]}:' + env.get('PYTHONPATH', '')
    with (check_root / f'{arm}.stdout.log').open('x') as stdout, (
        check_root / f'{arm}.stderr.log').open('x') as stderr:
        checked = subprocess.run(argv, cwd=args.producer_source, env=env,
                                 stdout=stdout, stderr=stderr, timeout=180)
    verdict = json.loads(output.read_text())
    require(checked.returncode == 0 and verdict['status'] == 'PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS',
            'independent saved phase/source/feature/request check rejected ' + arm)
    execution = json.loads((root / 'execution.json').read_text())
    associations = json.loads((root / 'all_rank_device_association.json').read_text())
    require(associations['source_sha'] == args.producer_sha
            and associations['source_tree'] == args.producer_tree
            and len(associations['ranks']) == 16, 'original device association set differs')
    mapping = json.loads(Path(receipt['mapping_evidence']['path']).read_text())
    require(digest(receipt['mapping_evidence']['path']) == receipt['mapping_evidence']['sha256'],
            'original physical mapping changed')
    workers = campaign['worker_provenance'][-1]['results']
    require(sorted(row['rank_snapshot']['rank'] for row in workers) == list(range(16)), 'missing actual rank')
    for row in workers:
        worker = row['rank_snapshot']
        rank = worker['rank']
        physical = receipt['phy_ids'][rank]
        matches = [item for item in associations['ranks'] if item['rank'] == rank]
        require(len(matches) == 1 and matches[0]['status'] == 'ASSOCIATED'
                and matches[0]['phy_id'] == physical, 'missing or contradictory rank/physical join')
        chip = next(line.split()[:2] for line in mapping['mapping_command']['stdout'].splitlines()
                    if len(line.split()) >= 5 and line.split()[2:4] == [str(physical), str(physical)])
        validate_association(worker, physical, matches[0]['proof'], chip,
                             source_sha=args.producer_sha, execution=execution)
    return dict(arm=arm, case=str(root), recheck=str(output), recheck_sha256=digest(output),
                requests_sha256=digest(root / 'model/requests.json'),
                runtime_manifest=receipt['runtime_manifest'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--producer-source', type=Path, required=True)
    parser.add_argument('--producer-sha', required=True)
    parser.add_argument('--producer-tree', required=True)
    parser.add_argument('--requests', type=Path, required=True)
    parser.add_argument('--off', type=Path, required=True)
    parser.add_argument('--on', type=Path, required=True)
    parser.add_argument('--eager', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    check_root = args.output.with_suffix('.rechecks')
    require(not args.output.exists() and not check_root.exists(), 'new read-only join attempt required')
    check_root.mkdir(parents=True)
    result = dict(status='INVALID_EVIDENCE_OR_TOKEN_MISMATCH', producer_sha=args.producer_sha,
                  producer_tree=args.producer_tree, checker_tool_sha256=digest(__file__))
    try:
        _identity(args.producer_source, args.producer_sha, args.producer_tree,
                  ancestor=args.producer_sha)
        roots = dict(G_OFF=args.off, G_ON=args.on, E_ON=args.eager)
        checks = [recheck_case(roots[arm], arm, args, check_root) for arm in ARMS]
        require(all(item['runtime_manifest'] == checks[0]['runtime_manifest'] for item in checks),
                'three-arm native/runtime binding differs')
        pairs = compare_documents({arm: json.loads((root / 'model/requests.json').read_text())
                                   for arm, root in roots.items()})
        result.update(status='PASS_SCOPED_THREE_ARM_ACTUAL_PHASE_SERVICE_TOKEN_PAIR',
            checks=checks, pairs=pairs, pair_count=len(pairs),
            scope='Full service requests only; per-arm raw phase/source/manager and external rank/device rechecks',
            tensor_numeric='NOT_INFERRED', normal_completion='NOT_PROVEN',
            execution_operand='NOT_OBSERVED', physical_read='NOT_OBSERVED', performance='NOT_ASSESSED')
    except (ValueError, KeyError, TypeError, IndexError, OSError, StopIteration,
            subprocess.SubprocessError) as error:
        result['error'] = f'{type(error).__name__}: {error}'
    write(args.output, result)
    return 0 if result['status'].startswith('PASS_SCOPED_') else 4


if __name__ == '__main__':
    raise SystemExit(main())
