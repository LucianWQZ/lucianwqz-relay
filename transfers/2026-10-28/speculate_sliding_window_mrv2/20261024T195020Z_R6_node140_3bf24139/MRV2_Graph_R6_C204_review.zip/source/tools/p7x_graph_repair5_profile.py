# SPDX-License-Identifier: Apache-2.0
"""Opt-in request-stage profiler. No is_profile dispatch flag; no device polling.

Host wrappers are opt-in. Eagle detailed ranges also wrap its module-local
UPDATE alias for the bounded request scope, restoring it on exit. The enclosing
manager range is explicitly REPLAY_PLUS_UPDATE; Host bindings are not operands.
No claim of task operands, physical reads, or completion is made.
"""

from __future__ import annotations

import argparse
import csv
import inspect
import json
import os
import sys
import time
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from types import MethodType

if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != root / "tools"]
    sys.path.insert(0, str(root))


def preflight(torch_npu):
    p = getattr(torch_npu, "profiler", None)
    result = {"status": "CAPABILITY_UNVERIFIED", "apis": {}, "version": str(torch_npu.__version__)}
    for name in ("profile", "tensorboard_trace_handler"):
        fn = getattr(p, name, None)
        if not callable(fn):
            result.update(status="BLOCKED", error=f"torch_npu.profiler.{name} missing")
            return result
        try:
            result["apis"][name] = {"signature": str(inspect.signature(fn)), "source": inspect.getsource(fn)}
        except (TypeError, OSError, ValueError):
            result["apis"][name] = {"signature": None, "source": None, "reason": "NATIVE_OR_UNAVAILABLE"}
    activity = getattr(p, "ProfilerActivity", None)
    if not all(hasattr(activity, n) for n in ("CPU", "NPU")):
        result.update(status="BLOCKED", error="CPU/NPU activities missing")
        return result
    result["status"] = "APIS_AVAILABLE_DEVICE_NOT_RUN"
    return result


def warmup_requests(llm, sampling_params, requests, probe, *, all_groups=False):
    """Warm the declared workload without enabling profiling or eager dispatch.

    The legacy default remains the first group with sixteen output tokens.
    All-group mode uses each group's real output limit and preserves order.
    Warmup completion is a serving result, not a new device completion proof.
    """
    probe.warmup_policy = "ALL_DECLARED_GROUPS" if all_groups else "FIRST_GROUP_16_TOKENS"
    records = []
    for request in requests if all_groups else requests[:1]:
        max_tokens = request["max_tokens"] if all_groups else 16
        with probe.group("warmup/" + request["label"]):
            results = llm.generate(
                request["prompts"],
                sampling_params(temperature=0.0, seed=0, ignore_eos=True, max_tokens=max_tokens),
                use_tqdm=False,
            )
        records.append(dict(label=request["label"], max_tokens=max_tokens,
                            token_ids=[r.outputs[0].token_ids for r in results]))
    if not all_groups:
        return {key: records[0][key] for key in ("label", "token_ids")}
    return dict(policy=probe.warmup_policy, groups=records)


def draft_graph_managers(speculator):
    """Keep parallel and autoregressive manager identities distinct."""
    parallel = getattr(speculator, "query_cudagraph_manager", None)
    if parallel is not None:
        return (("Draft", parallel),)
    first = getattr(speculator, "prefill_cudagraph_manager", None)
    ar = getattr(speculator, "decode_cudagraph_manager", None)
    if first is None or ar is None:
        raise ValueError("speculator has no complete declared graph manager route")
    return (("Draft_first_pass", first), ("Draft_AR", ar))


class RequestProfiler:
    def __init__(self, runner, output, identity, *, enabled, diagnostic=False, detailed=False,
                 materialize_ranges=False, counter_length_experiment=False, window_history=False):
        import torch

        self.torch, self.runner, self.output = torch, runner, Path(output)
        self.identity, self.enabled, self.diagnostic = identity, enabled, diagnostic
        if counter_length_experiment and diagnostic:
            raise ValueError("counter length experiment must not be combined with serialized LIFE")
        self.counter_length_experiment = counter_length_experiment
        if detailed and (not enabled or diagnostic):
            raise ValueError("detailed profile requires a separate enabled normal-path experiment")
        self.detailed = detailed
        if materialize_ranges and diagnostic:
            raise ValueError("materialize subranges require a normal-path experiment")
        self.materialize_ranges = materialize_ranges
        if type(window_history) is not bool or window_history and diagnostic:
            raise ValueError("Window history is an explicit Host-only normal request observation")
        self.window_history = window_history
        self.warmup_policy = "CALLER_DEFINED; see inactive groups"
        self.call_stack, self.next_call_id = [], 0
        self.saved, self.calls, self.groups = [], [], []
        self.profiler = None
        self.active = False
        self.current_group = None
        self.installations = {}
        self.deadline = time.monotonic() + 900
        self.device = str(runner.device) if hasattr(runner, "device") else "UNAVAILABLE"

    def _wrap(self, owner, name, label, descriptor=None):
        original = getattr(owner, name)
        self.saved.append((owner, name, name in vars(owner), vars(owner).get(name)))
        probe = self
        installation = dict(installed=True, method=name, owner=type(owner).__name__)
        if label in self.installations and self.installations[label].get("installed"):
            previous = self.installations[label]
            installation["other_methods"] = [{k:v for k,v in previous.items() if k != "other_methods"}, *previous.get("other_methods", [])]
        self.installations[label] = installation

        def wrapped(_self, *args, **kwargs):
            start = time.monotonic_ns()
            live_before = getattr(probe.runner.speculator, "_draft_window_live_inputs", None)
            context = getattr(probe.runner.speculator, "_draft_window_proposal_context", None)
            if live_before is None:
                live_before = getattr(probe.runner.speculator, "_eagle3_window_live_inputs", None)
            if context is None:
                context = getattr(probe.runner.speculator, "_eagle3_window_proposal_context", None)
            call_id = parent_id = None
            if probe.materialize_ranges:
                call_id, parent_id = probe.next_call_id, probe.call_stack[-1] if probe.call_stack else None
                probe.next_call_id += 1
                probe.call_stack.append(call_id)
            try:
                with probe.torch.profiler.record_function("repair5/" + label):
                    result = original(*args, **kwargs)
            finally:
                if probe.materialize_ranges:
                    probe.call_stack.pop()
            # CPU-only record AFTER the wrapped operation. No device tensor read.
            probe.calls.append(
                dict(
                    label=label,
                    start_ns=start,
                    end_ns=time.monotonic_ns(),
                    descriptor=descriptor,
                    active=probe.active,
                    request_group=probe.current_group,
                    clock_domain="HOST_MONOTONIC_NS",
                    boundary="HOST_CALL_NOT_DEVICE_COMPLETION",
                )
            )
            identity = getattr(result, "identity", None) or getattr(live_before, "identity", None)
            if probe.materialize_ranges:
                probe.calls[-1].update(call_id=call_id, parent_call_id=parent_id,
                                       host_method=name, host_owner=type(owner).__name__,
                                       proposal_context_id=id(context) if context is not None else None,
                                       proposal_mapping_epoch=getattr(context, "mapping_epoch", None))
                identity = identity or kwargs.get("identity")
                binding = kwargs.get("draft_window_graph_update_binding")
                if binding is not None:
                    probe.calls[-1]["host_update_route"] = binding.route.name
                    probe.calls[-1]["host_update_bindings"] = [
                        dict(generation=carrier.runtime_identity.generation_id,
                             epoch=carrier.runtime_identity.mapping_epoch,
                             consumer_ordinal=carrier.capture_identity.consumer_ordinal)
                        for carrier in binding.carriers
                    ]
                    probe.calls[-1]["binding_scope"] = "ACTUAL_HOST_UPDATE_ARGUMENT_NOT_DEVICE_OCCURRENCE_OR_OPERAND"
            if label == "Draft_retire_host":
                # The actual retire argument wins over a possibly different
                # first/AR live-input alias. This remains a Host argument, not
                # a certificate that the last device reader has completed.
                identity = args[0] if args else kwargs.get("expected_identity")
            if identity is not None and hasattr(identity, "generation_id"):
                probe.calls[-1].update(generation=identity.generation_id, mapping_epoch=identity.mapping_epoch)
                if probe.window_history and label == "Draft_retire_host":
                    probe.calls[-1].update(
                        window_request_ids=list(identity.ordered_request_fingerprint),
                        window_active=identity.actual_request_count,
                        window_padded=identity.padded_request_count,
                        window_read_descriptors=[asdict(d) for d in identity.read_descriptor_fingerprint],
                        window_scope="ACTUAL_RETIRED_HOST_IDENTITY_NOT_DEVICE_COMPLETION_OR_OPERAND",
                    )
            if args and hasattr(args[0], "num_tokens"):
                probe.calls[-1]["descriptor"] = [args[0].num_reqs, args[0].num_tokens]
            if label == "Draft_REPLAY_PLUS_UPDATE":
                live = getattr(probe.runner.speculator, "_draft_window_live_inputs", None)
                if live is not None:
                    # Immutable host descriptors; no tensor read, device query or
                    # observer enabled. This establishes actual planned S>0.
                    probe.calls[-1]["window_descriptors"] = [
                        asdict(d) for d in live.identity.read_descriptor_fingerprint
                    ]
                    probe.calls[-1]["generation"] = live.identity.generation_id
            return result

        setattr(owner, name, MethodType(wrapped, owner))

    def __enter__(self):
        spec = self.runner.speculator
        if not self.diagnostic and getattr(spec, "_draft_window_graph_characterization", None) is not None:
            if spec._draft_window_graph_characterization.recorder.enabled:
                raise ValueError("normal profiling requires heavy observer OFF")
        try:
            eagle = getattr(spec, "_eagle3_graph_session", None) is not None
            autoregressive = getattr(spec, "prefill_cudagraph_manager", None) is not None
            self.window_active = eagle or getattr(spec, "_draft_window_graph_characterization", None) is not None
            if autoregressive and self.counter_length_experiment:
                raise ValueError("counter length experiment is a separate parallel method contract")
            for label in ("Draft_materialize", "Draft_metadata_bind", "Draft_UPDATE_CALL", "Draft_retire_host"):
                self.installations[label] = dict(installed=False, reason="METHOD_OR_RUNTIME_NOT_PRESENT")
            self._wrap(spec, "propose", "Draft_propose")
            # Common OFF/ON seam: OFF's exact-length .tolist() may wait here,
            # while Window snapshots earlier in materialize. No added copies.
            if hasattr(spec, "_build_draft_attn_metadata"):
                self._wrap(spec, "_build_draft_attn_metadata", "Draft_build_attn_metadata")
            if hasattr(getattr(spec, "model", None), "precompute_and_store_context_kv"):
                self._wrap(spec.model, "precompute_and_store_context_kv", "Draft_context_KV")
            for method, label in (
                ("_materialize_draft_window_read_inputs", "Draft_materialize"),
                ("build_draft_attn_metadatas", "Draft_metadata_bind"),
            ):
                if hasattr(spec, method):
                    self._wrap(spec, method, label)
            if autoregressive and not self.materialize_ranges:
                for label in ("Draft_materialize", "Draft_UPDATE_CALL"):
                    self.installations[label] = dict(installed=False, reason="EAGLE_EXTRA_RANGES_DISABLED_FOR_LIGHT_CONTROL")
            if autoregressive and self.materialize_ranges:
                if eagle:
                    self._wrap(spec, "_materialize_eagle3_first_pass", "Draft_materialize")
                    self._wrap(spec, "_materialize_eagle3_decode_step", "Draft_materialize")
                # The two managers share this actual Python UPDATE alias.
                # Wrap once after capture, and restore before leaving scope.
                manager = spec.prefill_cudagraph_manager
                module = sys.modules[type(manager).__module__]
                self._wrap(module, "update_full_graph_params", "Draft_UPDATE_CALL")
            parallel_manager = getattr(spec, "query_cudagraph_manager", None)
            if parallel_manager is not None and hasattr(parallel_manager, "_update_full_graph_params"):
                self._wrap(parallel_manager, "_update_full_graph_params", "Draft_UPDATE_CALL")
            runtime = getattr(spec, "_draft_window_runtime_state", None)
            if runtime is not None:
                self._wrap(runtime, "retire_generation", "Draft_retire_host")
                if self.materialize_ranges:
                    snapshot = "_snapshot_eagle3_decode_step_one" if eagle else "_snapshot_prepared_draft_seq_lens"
                    epoch_source = spec._eagle3_window_epoch_source if eagle else spec._draft_window_epoch_source
                    for owner, method, label in (
                        (spec, snapshot, "Draft_materialize_exact_length_snapshot"),
                        (epoch_source, "validate", "Draft_materialize_epoch_validate"),
                        (runtime, "materialize", "Draft_materialize_runtime"),
                        (runtime.workspace, "materialize", "Draft_materialize_workspace"),
                        (runtime.workspace, "build_inputs", "Draft_materialize_build_inputs"),
                    ):
                        self._wrap(owner, method, label)
                    if eagle:
                        self._wrap(runtime, "materialize_serialized_step", "Draft_materialize_runtime")
            for name, manager in (("Target", self.runner.cudagraph_manager), *draft_graph_managers(spec)):
                self._wrap(manager, "run_fullgraph", name + "_REPLAY_PLUS_UPDATE")
                for desc, graph in manager.graphs.items():
                    self._wrap(graph, "replay", name + "_REPLAY_SUBMIT", [desc.num_reqs, desc.num_tokens])
            return self
        except BaseException:
            self._restore()
            raise

    def begin_active(self):
        if self.enabled:
            import torch_npu

            self.capability = preflight(torch_npu)
            if self.capability["status"] != "APIS_AVAILABLE_DEVICE_NOT_RUN":
                raise RuntimeError(self.capability)
            if self.detailed:
                parameters = inspect.signature(torch_npu.profiler.profile).parameters
                if not all(k in parameters for k in ("record_shapes", "with_stack")):
                    raise RuntimeError("CAPABILITY_UNVERIFIED: detailed profile keyword signature unavailable")
            self.profiler = torch_npu.profiler.profile(
                activities=[torch_npu.profiler.ProfilerActivity.CPU, torch_npu.profiler.ProfilerActivity.NPU],
                record_shapes=self.detailed,
                profile_memory=False,
                with_stack=self.detailed,
                on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(self.output / "trace")),
            )
            self.profiler.__enter__()
        self.active = True

    @contextmanager
    def group(self, label):
        if time.monotonic() > self.deadline:
            raise TimeoutError("profiling request-stage budget exceeded")
        start = time.monotonic_ns()
        self.current_group = label
        with self.torch.profiler.record_function("repair5/request/" + label):
            yield
        self.groups.append(dict(label=label, active=self.active, start_ns=start, end_ns=time.monotonic_ns()))
        self.current_group = None
        if self.active and self.profiler is not None:
            self.profiler.step()
        if time.monotonic() > self.deadline:
            raise TimeoutError("profiling request-stage budget exceeded")

    def _restore(self):
        for owner, name, existed, value in reversed(self.saved):
            if existed:
                setattr(owner, name, value)
            else:
                delattr(owner, name)
        self.saved.clear()

    def __exit__(self, *exc):
        self._scope_failed = exc[0] is not None
        if self._scope_failed and self.profiler is not None:
            # Unknown failed native submission: retain the collector until the
            # producer isolates this process. Native Stop/destructor may drain
            # the device and is not an allowed error-observation operation.
            self._unclosed_profiler_after_error = self.profiler
            self.profiler = None
            self.native_cleanup_skipped_after_error = True
        try:
            if self.profiler is not None:
                try:
                    self.profiler.__exit__(*exc)
                except BaseException as error:
                    self._scope_failed = True
                    self.native_cleanup_failed = True
                    self.native_cleanup_error = repr(error)
                    self._unclosed_profiler_after_error = self.profiler
                    self.profiler = None
                    raise
        finally:
            if self._scope_failed:
                try:
                    self._export_host_profile()
                except BaseException as error:
                    self.host_export_error = repr(error)
                    # Preserve the original model/update/storage exception.
            else:
                self._export_host_profile()
        return False

    def _export_host_profile(self):
        self._restore()
        active_replays = [
            c for c in self.calls
            if c["active"] and c["label"].startswith("Draft") and c["label"].endswith("_REPLAY_SUBMIT")
        ]
        payload = dict(
            schema="repair5-profile-v1",
            identity=self.identity,
            python_worker_pid=os.getpid(),
            device=self.device,
            wrapper_pid=None,
            profiler_enabled=self.enabled,
            profile_configuration=dict(record_shapes=self.detailed, with_stack=self.detailed, profile_memory=False),
            detailed_diagnostic=self.detailed,
            materialize_subranges=self.materialize_ranges,
            window_history_enabled=self.window_history,
            materialize_timing_contract={
                "method_semantics": (
                    "Eagle first pass uses current CPU InputBatch exact; only AR1 takes its existing device exact snapshot"
                    if getattr(self.runner.speculator, "_eagle3_graph_session", None) is not None
                    else "parallel Draft uses its existing prepared device exact snapshot"
                ),
                "snapshot": (
                    "EXPERIMENTAL: existing Target counter-copy event wait and owned CPU exact lengths; no seq D2H"
                    if self.counter_length_experiment else
                    "existing exact seq_lens.to(cpu, copy=True); includes possible wait and CPU copy"
                ),
                "epoch_validate": "Host epoch validation; calls outside materialize also retained",
                "runtime": "identity/lease/source binding and nested workspace construction",
                "workspace": "existing validation, table preparation/copies and length backing operations",
                "residual": "CPU upper/resident/phase plan and uninstrumented Host work; no single-op attribution",
                "association": (
                    "explicit same-thread call_id/parent_call_id + proposal context/epoch; not device flow"
                ),
                "impact": (
                    "Host ranges add no device operations; counter experiment separately waits existing event"
                    if self.counter_length_experiment else
                    "additional Host record_function ranges and bookkeeping; no new device sync/copy/query"
                ),
            } if self.materialize_ranges else None,
            capability=getattr(self, "capability", None),
            groups=self.groups,
            calls=self.calls,
            host_subrange_coverage=self.subrange_coverage(),
            status="FAILED_HOST_EXPORT_ONLY" if getattr(self, "_scope_failed", False) else "GRAPH_REPLAY_OBSERVED" if active_replays else "OPEN_NO_DRAFT_REPLAY",
            native_cleanup_skipped_after_error=getattr(self, "native_cleanup_skipped_after_error", False),
            native_cleanup_failed=getattr(self, "native_cleanup_failed", False),
            native_cleanup_error=getattr(self, "native_cleanup_error", None),
            scope=("DIAGNOSTIC_SERIALIZED" if self.diagnostic else
                   "EXPERIMENTAL_COUNTER_REUSE_NORMAL_DISPATCH_OBSERVER_OFF" if self.counter_length_experiment else
                   "NORMAL_OBSERVER_OFF"),
            counter_length_experiment=self.counter_length_experiment,
            clock_domain="HOST_MONOTONIC_NS_ONLY",
            initialization_capture="EXCLUDED",
            warmup=self.warmup_policy,
            warmup_groups=[g for g in self.groups if not g["active"]],
            update_host_range="Draft_UPDATE_CALL when instance seam exists; submission not completion",
            physical_read="NOT_PROVEN",
            completion="NOT_PROVEN",
        )
        payload["host_statistics"] = host_statistics(self.calls)
        payload["raw_exports"] = [
            str(p.relative_to(self.output)) for p in sorted((self.output / "trace").rglob("*")) if p.is_file()
        ]
        (self.output / "profile.json").write_text(json.dumps(payload, indent=2) + "\n")

    def subrange_coverage(self):
        replays = [c for c in self.calls if c["active"] and c["label"] in (
            "Draft_REPLAY_PLUS_UPDATE", "Draft_first_pass_REPLAY_PLUS_UPDATE", "Draft_AR_REPLAY_PLUS_UPDATE")]
        result = {}
        for label, installation in self.installations.items():
            if label not in ("Draft_materialize", "Draft_metadata_bind", "Draft_UPDATE_CALL", "Draft_retire_host"):
                continue
            calls = [c for c in self.calls if c["active"] and c["label"] == label]
            expected = (
                len(replays) if self.window_active or label in ("Draft_metadata_bind", "Draft_UPDATE_CALL") else 0
            )
            expected_gens = {c["generation"] for c in replays if "generation" in c}
            actual_gens = {c["generation"] for c in calls if "generation" in c}
            missing = sorted(expected_gens - actual_gens) if self.window_active else []
            result[label] = dict(
                installation,
                expected_minimum=expected,
                actual=len(calls),
                missing_generations=missing,
                status="MISSING"
                if expected and (not installation["installed"] or len(calls) < expected or missing)
                else "OBSERVED"
                if calls
                else "NOT_APPLICABLE_WINDOW_OFF"
                if not self.window_active
                else "NOT_EXECUTED",
                expected_rule="minimum one per observed Draft graph; extra context/prefill calls retained",
                timing_scope="nested host ranges; do not sum as device elapsed",
            )
        return result


def host_statistics(calls):
    groups = defaultdict(list)
    for c in calls:
        if c["active"]:
            groups[c["label"]].append((c["end_ns"] - c["start_ns"]) / 1e6)
    result = {}
    for name, values in groups.items():
        ordered = sorted(values)
        result[name] = dict(
            samples=len(values),
            sum_ms=sum(values),
            mean_ms=sum(values) / len(values),
            p50_ms=ordered[(len(values) - 1) // 2],
            p95_ms=ordered[min(len(values) - 1, int(len(values) * 0.95))],
            scope="HOST_SUBMISSION_NOT_DEVICE_COMPLETION",
        )
    return result


def analyze_csv(paths):
    """Stream CSV metrics, retain field availability; never infer missing flows.

    Duration sums are NOT elapsed or non-overlapped device occupancy.
    """
    files, totals = [], defaultdict(lambda: {"samples": 0, "duration_us_sum": 0.0})
    for root in paths:
        for path in sorted(Path(root).rglob("*.csv")):
            with path.open(newline="", encoding="utf-8-sig") as stream:
                reader = csv.DictReader(stream)
                fields = reader.fieldnames or []
                duration = next((x for x in ("Duration(us)", "Duration (us)", "Duration") if x in fields), None)
                names = next((x for x in ("Name", "Op Name", "OP Type", "Op Type") if x in fields), None)
                rows = 0
                nonempty = dict.fromkeys(fields, 0)
                for row in reader:
                    rows += 1
                    for k in fields:
                        nonempty[k] += bool(row.get(k))
                    name = (row.get(names, "") if names else "").lower()
                    category = (
                        "copy"
                        if any(x in name for x in ("memcpy", "memcopy"))
                        else "wait_sync"
                        if any(x in name for x in ("wait", "synchron"))
                        else "update"
                        if "update" in name
                        else "replay"
                        if "replay" in name
                        else "UNRESOLVED_KERNEL_OR_API"
                    )
                    # An unlabeled Duration column has no established unit.
                    # Inventory it, but never relabel it as microseconds.
                    if duration in ("Duration(us)", "Duration (us)") and row.get(duration):
                        try:
                            value = float(row[duration])
                            if value >= 0 and value != float("inf"):
                                bucket = totals[f"{path}:{category}"]
                                bucket["samples"] += 1
                                bucket["duration_us_sum"] += value
                        except ValueError:
                            pass
                files.append(
                    dict(
                        path=str(path),
                        fields=fields,
                        nonempty=nonempty,
                        rows=rows,
                        duration_units="UNVERIFIED" if duration == "Duration" else "us",
                    )
                )
    return dict(
        status="FIELDS_ANALYZED" if files else "OPEN_NO_CSV",
        files=files,
        totals=dict(totals),
        device_idle="UNRESOLVED_WITHOUT_CALIBRATED_TIMELINE",
        target_draft_kernel_attribution="UNRESOLVED_UNLESS_EXPLICIT_FLOW_ASSOCIATION",
        stream_context_flow="FIELDS_INVENTORIED_NOT_INFERRED",
        stage="request-only profiling; prefill/decode attribution requires actual ranges",
        warning="overlapping duration sums are not end-to-end elapsed; host/device clocks not joined",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("preflight", "analyze"))
    parser.add_argument("--input", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "preflight":
        try:
            import torch_npu

            result = preflight(torch_npu)
        except ImportError as error:
            result = {"status": "BLOCKED", "reason": str(error)}
    else:
        result = analyze_csv(args.input)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    return 2 if result["status"] in ("BLOCKED", "OPEN_NO_CSV") else 0


if __name__ == "__main__":
    raise SystemExit(main())
