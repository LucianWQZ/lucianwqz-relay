# SPDX-License-Identifier: Apache-2.0
"""Controlled Eagle Target/ABA diagnostics; no normal timing or public admission.

Every Target arm owns an empty disposable engine. Complete canonical Target
states are initialized independently; real first/AR proposals then run. Normal
serving histories, device occurrence operands and physical reads are not proven.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import time
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch

from tools.p7x_graph_repair5_target import (
    ControlledTarget,
    _base,
    _tensor_equal,
    outside_digest,
    logical_kv,
    sample_identity,
    validate_controlled_record,
)
from tools.p7x_graph_repair5_evidence import file_sha
from tools.p7x_graph_repair6_storage import CollectionReader, atomic_json, require
from tools.p7x_graph_repair6_submission import SubmissionState

PROFILE = "eagle3_static_k3_controlled"


@dataclass(frozen=True)
class EagleTargetContract:
    method: str = "eagle3"
    k: int = 3
    draft_query: int = 4  # First-pass staging reserve; AR query is separate.
    target_query: int = 4
    ar_query: int = 1
    ar_consumers: int = 2
    causal: bool = True
    window: int = 1024
    block: int = 128

    def document(self):
        return asdict(self)


def case_plan():
    declarations = (
        ("A", [1152], 1, 0),
        ("B", [1280], 1, 0),
        ("A_prime", [1152], 1, 0),
        ("short", [32], 1, 0),
        ("long", [2051], 1, 0),
        ("horizon-window-boundary", [1021], 1, 0),
        ("horizon-block-boundary", [1149], 1, 0),
        ("nonaligned", [1153], 1, 0),
        ("mixed", [32, 1153], 2, 0),
        ("target-padded2-ar-padded1", [32], 2, 0),
        ("return-short", [32], 1, 0),
        ("three-active-four-padded", [32, 1025, 1153], 4, 0),
        ("four-active", [32, 1024, 1152, 1153], 4, 0),
        ("rejected-tail", [1153], 1, 3),
    )
    return [
        dict(scenario=name,
             step=i,
             ends=ends,
             padded=padded,
             query_width=4,
             num_rejected=rejected,
             num_sampled=4 - rejected) for i, (name, ends, padded, rejected) in enumerate(declarations)
    ]


def equal_tree(left, right):
    if isinstance(left, (list, tuple)) or isinstance(right, (list, tuple)):
        return type(left) is type(right) and len(left) == len(right) and all(
            equal_tree(a, b) for a, b in zip(left, right))
    return _tensor_equal(left, right)


def validate_layer_inventory(runner, inventory):
    """Validate loaded, fixture-verified model ownership, never a guessed layer count."""
    count = getattr(runner.model.config, "num_hidden_layers", None)
    target = inventory["target_layers"]
    draft = inventory["draft_layers"]
    require(type(count) is int and count > 0, "loaded Target HF layer count is required")
    require(len(target) == count and len(set(target)) == count,
            "complete Target layer inventory must match loaded verified HF configuration")
    require(len(draft) == 1 and set(draft) == set(runner.speculator.draft_attn_layer_names)
            and not set(draft) & set(target), "complete frozen single-layer Eagle ownership")
    return dict(target=count, draft=1, basis="FIXTURE_VERIFIED_LOADED_MODEL_CONFIG_AND_MODULE_OWNERSHIP")


def selected_reproduction_cases(repro=None):
    cases = case_plan()
    require(repro in (None, "target-padded2-ar-padded1"), "only the declared padding reproduction is allowed")
    return cases if repro is None else [cases[9]]


def original_case_for_generation(cases, generation):
    require(type(generation) is int, "original scenario generation must be an integer")
    matches = [case for case in cases if case["step"] == generation]
    require(len(matches) == 1, "original scenario generation missing or duplicated in selected cases")
    return matches[0]


class EagleControlledTarget(ControlledTarget):

    def __init__(self, runner, *, fixture_id, arm, scheduler, identity, numeric_probe=None, sample_limit=None, repro=None):
        super().__init__(runner,
                         fixture_id=fixture_id,
                         arm=arm,
                         scheduler=scheduler,
                         identity=identity,
                         profile=PROFILE,
                         bounded_store=True,
                         numeric_probe=numeric_probe,
                         sample_limit=sample_limit,
                         method_contract=EagleTargetContract(),
                         declared_cases=selected_reproduction_cases(repro))
        self.submission = SubmissionState()
        self.poisoned = False
        require(runner.speculator.method == "eagle3" and runner.speculator.num_speculative_steps == 3,
                "actual Eagle3 static K3 required")
        self.inventory["declared_layer_counts"] = validate_layer_inventory(runner, self.inventory)

    def _stage(self, case):
        descriptor, batch, owners = super()._stage(case)
        tables = self.runner.block_tables
        contract = EagleTargetContract()
        require(
            tables.block_sizes == tables.kernel_block_sizes == [contract.block] and tables.blocks_per_kv_block == [1],
            "Eagle fixture requires direct kernel-block source units")
        require(batch.num_reqs == len(case["ends"]) and batch.idx_mapping_np.tolist() == list(range(batch.num_reqs)),
                "exclusive fixture request-state rows")
        # Target and parallel Draft consume input_block_tables. Eagle AR calls
        # compute_slot_mappings, whose pointer table refers to block_tables[i].gpu.
        # Initialize that canonical source through the normal staging API too;
        # never change the absolute Full slot oracle to match an empty source.
        raw_rows = []
        for row, end in enumerate(case["ends"]):
            columns = (end + contract.draft_query + contract.block - 1) // contract.block
            mapping = {column: physical for physical, (name, column) in owners.items() if name == f"row-{row}"}
            require(set(mapping) == set(range(columns)), "complete canonical raw source ownership required")
            blocks = [mapping[column] for column in range(columns)]
            require(
                all(type(block) is int and block > 0 for block in blocks) and len(blocks) == len(set(blocks)),
                "invalid raw canonical Full blocks")
            raw_rows.append(blocks)
        for row, blocks in enumerate(raw_rows):
            tables.append_block_ids(row, (blocks, ), overwrite=True)
        tables.apply_staged_writes()
        return descriptor, batch, owners

    def _execute_draft_after_target(self, *, record, batch, hidden, inputs, access, slots, blocks):
        spec = self.runner.speculator
        actual_hidden = hidden[0] if isinstance(hidden, tuple) else hidden
        case = original_case_for_generation(self.cases, record["generation"])
        record["checkpoint"]["case_kind"] = "CONTROLLED_EXCLUSIVE_SYNTHETIC_KV"
        if self.numeric_probe is not None:
            self.numeric_probe.set_group(case["scenario"])
        nr, maximum, device = batch.num_reqs, spec.max_num_reqs, self.runner.device
        target_root = self.runner.model_state.attn_metadata
        start = time.monotonic_ns()
        self.submission.submit("REAL_EAGLE_PROPOSE_AND_UPDATE_PENDING")
        try:
            tokens = spec.propose(batch, target_root,
                                  {name: slots[f"{name}/K"]
                                   for name in self.inventory["target_layers"]}, actual_hidden,
                                  list(hidden[1]) if isinstance(hidden, tuple) else None,
                                  torch.full((nr, ), case["num_sampled"], dtype=torch.int32, device=device),
                                  torch.full((nr, ), case["num_rejected"], dtype=torch.int32, device=device),
                                  torch.full((maximum, ), 17, dtype=torch.int64, device=device),
                                  # Pinned RequestState.next_prefill_tokens is int32;
                                  # last_sampled above and absolute positions stay int64.
                                  torch.full((maximum, ), 17, dtype=torch.int32, device=device),
                                  torch.zeros(maximum, device=device),
                                  torch.zeros(maximum, dtype=torch.int64, device=device))
            # Successful real propose/UPDATE return, then explicit diagnostic drain.
            # No post-fault device action is attempted if propose throws.
            spec.update_stream.synchronize()
            torch.npu.current_stream().synchronize()
            self.submission.complete("REAL_EAGLE_PROPOSE_DIAGNOSTIC_COMPLETE")
        except BaseException as error:
            self.submission.failed(error)
            self.poisoned = self.submission.pending
            if self.poisoned:
                spec._draft_window_graph_submission_uncertain = True
            raise
        require(self.runner.model_state.attn_metadata is target_root, "Draft replaced Target metadata owner")
        record["draft_tokens"] = tokens.detach().cpu().clone()
        record["draft_semantics"] = f"Window {self.arm}; Draft OFF/ON outputs are not paired as equal oracles"
        record["draft_execution"] = dict(start_ns=start,
                                         complete_ns=time.monotonic_ns(),
                                         submission=self.submission.snapshot(),
                                         num_sampled=case["num_sampled"],
                                         num_rejected=case["num_rejected"],
                                         first_query=4,
                                         ar_query=1,
                                         ar_consumers=2)
        record["target_after_draft"] = dict(kv=self.probe.snapshot(access(), [self.probe.max_bytes], blocks),
                                            inputs=self.probe.snapshot(inputs, [self.probe.max_bytes]),
                                            outside=outside_digest(access(), blocks),
                                            root_same=True,
                                            slot_phase="PINNED_EAGLE_FINAL_AR_FULL_SLOT_PREFIX_AND_REMAINDER_MINUS_ONE")


def run_controlled(runner, scheduler, output, identity, arm, fixture_sha, profiler, *, prefix=None, repro=None):
    from contextlib import ExitStack
    from tools.p7x_graph_repair15_eagle_numeric import EagleContinuousReference
    cases = case_plan()
    selected = selected_reproduction_cases(repro)
    require(repro is None or arm == "G_ON" and prefix is None, "padding reproduction is a distinct ON single-case scope")
    entries = [dict(label=c["scenario"], prompts=[{} for _ in c["ends"]]) for c in cases]
    require(prefix in (None, 1), "only the declared single-sample resource prefix is allowed")
    start = time.monotonic_ns()
    with ExitStack() as stack:
        numeric = None
        if arm == "G_ON":
            numeric = stack.enter_context(
                EagleContinuousReference(runner,
                                         scheduler,
                                         output / "eagle-numeric.json",
                                         identity,
                                         entries,
                                         controlled_cases=cases))
        controlled = EagleControlledTarget(runner,
                                           fixture_id="eagle3-fixture:" + fixture_sha,
                                           arm="ON" if arm == "G_ON" else "OFF",
                                           scheduler=scheduler,
                                           identity=identity,
                                           numeric_probe=numeric,
                                           sample_limit=prefix,
                                           repro=repro)
        profiler.begin_active()
        try:
            document = controlled.execute(output / "eagle-target.json", include_draft=True)
        except BaseException:
            if controlled.poisoned or numeric is not None and numeric.poisoned:
                runner.speculator._draft_window_graph_submission_uncertain = True
            raise
    summary = dict(identity=identity,
                   profile=PROFILE,
                   expected_cases=selected,
                   samples=len(document["records"]),
                   sample_limit=prefix,
                   host_start_ns=start,
                   host_end_ns=time.monotonic_ns(),
                   extra_sync=True,
                   numerical_reference=arm == "G_ON",
                   status="COMPLETE_DECLARED_REPRODUCTION" if repro else "COMPLETE_DECLARED_PREFIX" if prefix else "COMPLETE_DECLARED_TARGET_ARM",
                   reproduction=repro,
                   normal_overlap="NOT_PROVEN",
                   physical_read="NOT_PROVEN")
    atomic_json(output / "eagle-target-run.json", summary)
    return summary


def validate_target_sample(record):
    require(record["status"] == "CAPTURED_COMPLETE", "Target producer incomplete/blocked")
    require(record["checkpoint"]["case_kind"] == "CONTROLLED_EXCLUSIVE_SYNTHETIC_KV",
            "controlled synthetic state must not claim a natural request history")
    semantics = validate_controlled_record(record, expected_target_query=4)
    base = _base()
    before = base._snapshot_value(record["checkpoint"]["inputs"])
    require(
        before["input_ids"].dtype == torch.int32 and before["positions"].dtype == torch.int64
        and before["query_start_loc"].dtype == torch.int32, "exact Target input dtypes")
    base._validate_read_coverage(record["checkpoint"])
    coverage = base._write_coverage(record["checkpoint"]["kv_before"], record["checkpoint"]["kv_after"],
                                    record["checkpoint"]["write_slots"])
    require(not any(row["changed_outside_write_slots"] for row in coverage.values()),
            "Target wrote outside complete declared Full slots")
    require(record["outside_before"] == record["outside_after"], "Target wrote outside selected blocks")
    for field, source in (("logical_pre_kv", "kv_before"), ("logical_post_kv", "kv_after")):
        require(equal_tree(logical_kv(record["checkpoint"][source], record["block_owners"]), record[field]),
                "logical normalization does not match complete raw KV")
    after = record["target_after_draft"]
    require(
        after["root_same"] and after["outside"] == record["outside_after"]
        and not base._differences(record["checkpoint"]["kv_after"], after["kv"]), "Draft polluted Target KV/owner")
    current = base._snapshot_value(after["inputs"])
    for field in ("input_ids", "positions", "query_start_loc", "seq_lens", "is_padding"):
        require(equal_tree(before[field], current[field]), "Draft changed Target input " + field)
    require(before["layers"].keys() == current["layers"].keys(), "Target layer set changed")
    case = case_plan()[record["generation"]]
    for name, metadata in before["layers"].items():
        now = current["layers"][name]
        require(metadata.keys() == now.keys(), "Target metadata field inventory changed")
        for key, value in metadata.items():
            if key != "slot_mapping":
                require(equal_tree(value, now[key]), "Draft changed Target metadata " + name + "/" + key)
        # Ascend's pinned slot kernel writes all unused tail entries to -1.
        # Eagle's final AR2 consumes one Full absolute write position per row.
        expected = torch.full_like(now["slot_mapping"], -1)
        for row, end in enumerate(case["ends"]):
            pos = end - case["num_rejected"] + 1
            expected[row] = int(metadata["block_tables"][row, pos // 128]) * 128 + pos % 128
        require(torch.equal(now["slot_mapping"], expected), "final AR canonical Full slot prefix/tail contract")
    execution = record["draft_execution"]
    require(
        execution["submission"]["pending"] is False
        and execution["submission"]["phase"] == "REAL_EAGLE_PROPOSE_DIAGNOSTIC_COMPLETE"
        and execution["start_ns"] < execution["complete_ns"], "Draft lacks explicit completed diagnostic scope")
    require(record["draft_tokens"].shape == (record["identity"]["active"], 3), "actual K3 proposal output")
    return semantics


def check_numeric_aba(reader):
    groups = {name: [] for name in ("A", "B", "A_prime")}
    for index in range(len(reader.samples)):
        record = reader.record(index)
        if record["group"] in groups:
            groups[record["group"]].append(record)
        if all(len(rows) == 3 for rows in groups.values()):
            break
    require(
        all(len(rows) == 3 and [r["runtime_identity"]["step"] for r in rows] == [0, 1, 2] for rows in groups.values()),
        "ABA needs all three real consumers in all three proposals")
    checks = []
    for step, (a, b, again) in enumerate(zip(groups["A"], groups["B"], groups["A_prime"])):
        require(a["identity"]["epoch"] < b["identity"]["epoch"] < again["identity"]["epoch"], "ABA epoch order")
        for field in ("inputs", "pre_kv", "canonical_table", "actual_slots", "graph", "reference", "graph_post_kv",
                      "reference_post_kv"):
            require(equal_tree(a[field], again[field]), "A-prime did not restore exact " + field)
        distinct = not equal_tree(a["graph"], b["graph"]) and not equal_tree(a["reference"], b["reference"])
        checks.append(
            dict(step=step,
                 A_B_distinct=distinct,
                 A_prime_restored=True,
                 generations=[r["identity"]["generation"] for r in (a, b, again)]))
    return dict(status="PASS_SCOPED_CONTINUOUS_ABA" if all(c["A_B_distinct"]
                                                           for c in checks) else "OPEN_NONDISCRIMINATING",
                consumers=checks,
                scope="Declared states; no physical-read proof")


def base_target_keys(record):
    return set(record["checkpoint"]["kv_keys"])


def expected_layer_counts(expected):
    """Read independently hashed fixture configs, not producer-reported counts."""
    argv = expected["argv"]
    fixture_path = Path(argv[argv.index("--fixture") + 1])
    require(file_sha(fixture_path) == expected["method_fixture_sha256"], "layer fixture identity changed")
    fixture = json.loads(fixture_path.read_text())
    counts = {}
    for role in ("target", "draft"):
        path = Path(fixture[role + "_model"]) / "config.json"
        entries = [row for row in fixture["files"] if Path(row["path"]) == path]
        require(
            len(entries) == 1 and file_sha(path) == entries[0]["sha256"],
            "independent layer config hash mismatch: " + role)
        config = json.loads(path.read_text())
        if role == "draft" and ("transformer_layer_config" in config or "speculators_model_type" in config
                                or config.get("architectures") == ["Eagle3Speculator"]):
            require(
                config.get("speculators_model_type") == "eagle3"
                and config.get("architectures") == ["Eagle3Speculator"], "explicit Eagle3 speculators format required")
            layer_config = config.get("transformer_layer_config")
            require(isinstance(layer_config, dict), "Eagle transformer_layer_config must be an object")
            count = layer_config.get("num_hidden_layers")
            require(
                "num_hidden_layers" not in config
                or (type(config["num_hidden_layers"]) is int and config["num_hidden_layers"] == count),
                "conflicting outer/nested Eagle layer counts")
        else:
            count = config.get("num_hidden_layers")
        require(type(count) is int and count > 0, "explicit configured layer count required")
        counts[role] = count
    require(counts["draft"] == 1, "frozen single-layer Eagle configuration required")
    return counts


def check_arm(output, campaign, launcher, expected):
    result = dict(status="INVALID_EVIDENCE", full_target="NOT_ASSESSED", normal_overlap="NOT_PROVEN")
    try:
        require(campaign["timing_scope"] == "CONTROLLED_EAGLE_TARGET_AND_SERIAL_REFERENCE_NOT_PERFORMANCE",
                "controlled arm mislabeled as normal performance")
        require(campaign["request_manifest"]["entries"] == case_plan(), "frozen controlled scenario file")
        summary = json.loads((output / "eagle-target-run.json").read_text())
        require(summary["identity"] == campaign["identity"] and summary["expected_cases"] == case_plan(),
                "controlled source/run identity")
        require(
            launcher["host_start_ns"] <= summary["host_start_ns"] < summary["host_end_ns"] <= launcher["host_end_ns"],
            "controlled execution outside actual child")
        prefix = expected.get("eagle3_target_prefix")
        require(summary["sample_limit"] == prefix and prefix in (None, 1), "prefix contract")
        reader = CollectionReader(output / "eagle-target.json")
        h = reader.header
        require(
            h["identity"] == campaign["identity"] and h["capture_profile"] == PROFILE and h["cases"] == case_plan()
            and h["method_contract"] == EagleTargetContract().document(), "Target collection/contract identity")
        require(h["arm"] == ("ON" if campaign["arm"] == "G_ON" else "OFF"), "Target arm mismatch")
        require(h["tolerance"]["atol"] == h["tolerance"]["rtol"] == 0.0, "Target tolerance changed")
        inventory = h["inventory"]
        counts = expected_layer_counts(expected)
        require(
            all(len(inventory[role + "_layers"]) == len(set(inventory[role + "_layers"])) == counts[role]
                for role in ("target", "draft")), "complete actual layer inventory differs from hashed model config")
        require(set(inventory["configured_layers"]) == set(inventory["target_layers"]) | set(inventory["draft_layers"])
                and not set(inventory["target_layers"]) & set(inventory["draft_layers"]),
                "missing or conflicting complete model ownership")
        require(inventory["declared_layer_counts"] == dict(
            **counts, basis="FIXTURE_VERIFIED_LOADED_MODEL_CONFIG_AND_MODULE_OWNERSHIP"),
                "loaded layer counts differ from independently hashed fixture configs")
        count = prefix or len(case_plan())
        require(len(reader.samples) == summary["samples"] == count, "incomplete/extra Target samples")
        for index in range(count):
            require(not reader.incomplete(index), "uncommitted Target sample")
            record = reader.record(index)
            require(record["identity"] == sample_identity(case_plan()[index], h["fixture_id"]), "Target case order")
            require(
                base_target_keys(record) == {
                    name + "/" + kind
                    for name in inventory["target_layers"]
                    for kind in ("K", "V")
                }, "sample lacks full header Target KV inventory")
            validate_target_sample(record)
        numeric = "NOT_INSTALLED_OFF_ARM"
        if campaign["arm"] == "G_ON":
            from tools.p7x_graph_repair15_eagle_numeric_check import check_collection, validate_sample
            path = output / "eagle-numeric.json"
            if prefix:
                n = CollectionReader(path)
                require(
                    n.header["identity"] == campaign["identity"] and n.header["controlled_cases"] == case_plan()
                    and n.header["numeric_schema"] == "r6-eagle3-controlled-continuous-v6"
                    and n.header["expected_samples"] == 3 * len(case_plan())
                    and n.header["tolerance"] == dict(atol=0.0, rtol=0.0)
                    and n.header["groups"] == {case["scenario"]: len(case["ends"])
                                               for case in case_plan()} and len(n.samples) == 3
                    and all(not n.incomplete(i) for i in range(3)), "prefix exact header/consumer coverage")
                numeric = [validate_sample(n.record(i), n.header) for i in range(3)]
                require(
                    all(row["numeric_match"] and row["write_scope_match"] and row["group"] == "A" for row in numeric)
                    and [row["step"] for row in numeric] == [0, 1, 2] and len({row["epoch"]
                                                                               for row in numeric}) == 1,
                    "prefix numerical consumer mismatch")
            else:
                numeric = check_collection(path, campaign["identity"])
                require(numeric["status"] == "PASS_SCOPED_EAGLE3_SERIAL_CONTINUOUS", str(numeric))
        result.update(status="PASS_SCOPED_EAGLE3_TARGET_PREFIX" if prefix else "PASS_SCOPED_EAGLE3_TARGET_ARM",
                      samples=count,
                      numeric=numeric,
                      full_target="SINGLE_ARM_NOT_OFF_ON_JOINED")
    except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
        result["error"] = str(error)
    return result


def joined_compare(plan, off_case, on_case):
    """One complete pair at a time, after both strict real arm execution joins."""
    from tools.p7x_graph_repair13_eagle import check as check_execution
    result = dict(status="INVALID_EVIDENCE", pairs=[], physical_read="NOT_PROVEN", normal_overlap="NOT_PROVEN")
    try:
        cases = [plan["cases"][key] for key in (off_case, on_case)]
        readers = []
        for expected, arm in zip(cases, ("G_OFF", "G_ON")):
            require(
                expected["eagle3_target"] and expected["eagle3_target_prefix"] is None
                and expected["eagle3_arm"] == arm, "full explicit OFF/ON arm required")
            output = Path(expected["outputs"])
            artifact = output / "profile.json"
            campaign = json.loads((output / "campaign.json").read_text())
            launcher_root = Path(expected["launch_argv"][expected["launch_argv"].index("--output") + 1])
            launcher = json.loads((launcher_root / "launcher.json").read_text())
            joined = check_execution(json.loads(artifact.read_text()), campaign, launcher, expected, artifact)
            require(joined["status"] == "PASS_SCOPED_EAGLE3_TARGET_ARM", str(joined))
            readers.append(CollectionReader(output / "eagle-target.json"))
        a, b = readers
        require(a.header["fixture_id"] == b.header["fixture_id"] and a.header["inventory"] == b.header["inventory"],
                "different actual model/fixture inventory")
        require(
            all(a.header["identity"][key] == b.header["identity"][key]
                for key in ("run_id", "source_sha", "source_tree", "vllm_sha")), "cross-source/run arm mixture")
        for index, case in enumerate(case_plan()):
            x, y = a.record(index), b.record(index)
            require(x["identity"] == y["identity"] == sample_identity(case, a.header["fixture_id"]), "pair identity")
            same = validate_target_sample(x) == validate_target_sample(y)
            require(same and equal_tree(x["logical_pre_kv"], y["logical_pre_kv"]), "unaligned complete logical pre-KV")
            errors = [field for field in ("hidden", "logits", "logical_post_kv") if not equal_tree(x[field], y[field])]
            result["pairs"].append(dict(identity=x["identity"], status="FAIL" if errors else "PASS", errors=errors))
        result.update(status="FAIL" if any(pair["errors"]
                                           for pair in result["pairs"]) else "PASS_SCOPED_EAGLE3_TARGET_DOUBLE_ARM",
                      complete_pairs=len(result["pairs"]),
                      source_sha=a.header["identity"]["source_sha"],
                      source_tree=a.header["identity"]["source_tree"],
                      scope="Complete declared controlled Target state; serial diagnostics, not normal overlap")
    except (ValueError, KeyError, TypeError, IndexError, OSError, RuntimeError) as error:
        result["error"] = str(error)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--off-case", required=True)
    parser.add_argument("--on-case", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(2)
    result = joined_compare(json.loads(args.plan.read_text()), args.off_case, args.on_case)
    atomic_json(args.output, result)
    return 0 if result["status"] == "PASS_SCOPED_EAGLE3_TARGET_DOUBLE_ARM" else 2


if __name__ == "__main__":
    raise SystemExit(main())
