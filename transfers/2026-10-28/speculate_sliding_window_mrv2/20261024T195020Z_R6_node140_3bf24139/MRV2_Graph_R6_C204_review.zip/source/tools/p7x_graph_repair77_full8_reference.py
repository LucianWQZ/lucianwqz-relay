# SPDX-License-Identifier: Apache-2.0
"""Named Qwen3.6 Full8 TP4 same-prestate Graph/eager diagnostic.

Reuse the completed-call snapshots, independent canonical read projection,
actual eager forward, restore isolation and raw checker of Tool74. Full8 has
eight noncausal readers, one actual group, one local KV head and W1024; it
does not pretend to have the SWA6 native-reader plan. Three real replays per
rank are a sentinel, not complete ABA, Target isolation or normal lifetime.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
from collections.abc import Mapping
import json
import os
from types import SimpleNamespace
import uuid

from tools.p7x_graph_repair21_rank import digest, require, run_anchor, write
from tools.p7x_graph_repair25_rank_numeric import RankContract, validate_runtime_overlay
from tools.p7x_graph_repair28_rank_anchor_check import check as check_anchor
from tools.p7x_graph_repair6_storage import CollectionReader
from tools.p7x_graph_repair68_qwen36_dflash_anchor import (
    Qwen36DFlashWorker, build_kwargs as anchor_kwargs,
    profile_identity as anchor_identity, validate_worker,
)
from tools import p7x_graph_repair74_swa_reference as shared

PROFILE = shared.FULL8_PROFILE
REQUESTS = (('long-one', (1537,)), ('long-three', (1537, 1153, 387)))
OUTPUT_TOKENS = 64


def identity(owned_failure_probe=False):
    return dict(profile=shared.FULL8_FAILURE_PROFILE if owned_failure_probe else PROFILE, anchor=anchor_identity(),
                reference_metadata_source='ACTUAL_DRAFT_EAGER_BUILDER_WITH_CANONICAL_READS',
                requests=[[label, list(lengths)] for label, lengths in REQUESTS],
                output_tokens=OUTPUT_TOKENS, quota={'1': 1} if owned_failure_probe else {'1': 2, '3': 1},
                output_contract='All active query rows n*8 at zero tolerance; padded hidden saved/descriptive, all Full KV writes still checked',
                scope=('One first-layer query/output, owned/raw hidden, exact-restore second eager and two functional calls; not acceptance'
                       if owned_failure_probe else 'Same shape, actual eager from canonical full prestate; serialized diagnostic only'))


def build_kwargs(tp, *, window_on_review=False, owned_failure_probe=False):
    require(window_on_review is True, 'explicit W1024 numerical ON only')
    kw = anchor_kwargs(tp, window_on_review=True)
    kw['additional_config']['draft_window_graph_numeric_diagnostic'] = True
    if owned_failure_probe:
        kw['additional_config']['draft_window_graph_numeric_owned_output'] = True
    kw['worker_extension_cls'] = 'tools.p7x_graph_repair77_full8_reference.Full8ReferenceWorker'
    return kw


class Full8ReplayReference(shared.SWAReplayReference):
    profile_name = PROFILE
    window = 1024
    kv_heads = 1
    owned_profile_name = shared.FULL8_FAILURE_PROFILE
    owned_quota_entries = ((1, 1),)

    def build_eager_reference_metadata(self, desc, tables, window_table, window_lengths):
        """Use the actual Draft eager builder, with independent read operands.

        A Graph UPDATE carrier also holds a Target-derived stage enum. That
        enum is not an eager Draft dispatch contract: PrefillNoCache selects
        current-query K/V in _get_fia_params. Never copy that carrier enum into
        an independent cached Draft reference.
        """
        import torch
        from vllm_ascend.worker.v2.attn_utils import build_attn_metadata_wrapper
        from vllm_ascend.worker.v2.spec_decode.draft_window_eager import AscendDraftAttentionReadInputs

        s = self.owner
        n, p = s.input_batch.num_reqs, desc.num_reqs
        live = s._draft_window_live_inputs
        live.validate_for(live.identity)
        exact = torch.tensor(window_lengths, dtype=torch.int32)
        upper = live.cpu_window_upper[:p].clone()
        require(upper.device.type == 'cpu' and upper.shape == exact.shape
                and bool(torch.all(upper[:n] >= exact[:n])),
                'current CPU upper is a max bound only, not the exact reference oracle')
        full_gid = self.reader_plan().full_gid
        read = AscendDraftAttentionReadInputs(
            block_tables=tuple(window_table.to(s.device) if gid == full_gid else full[:p]
                              for gid,full in enumerate(s.block_tables.input_block_tables)),
            seq_lens=exact.to(s.device), seq_lens_cpu_exact=exact,
            seq_lens_cpu_upper_bound=upper, max_seq_len=int(upper[:n].max()))
        with build_attn_metadata_wrapper():
            metadata = s._build_ascend_draft_attn_metadata(
                num_reqs=n, num_reqs_padded=p, num_tokens_padded=desc.num_tokens,
                read_inputs=read, causal=s._group_causal,
                query_start_loc_np=None, dcp_local_seq_lens=None)
        s._update_draft_attn_metadata(metadata, p)
        return metadata

    def reader_plan(self):
        spec = self.owner
        require(spec._draft_window_graph_binding_provider.native_swa_graph_plan is None,
                'Full8 cannot borrow a native SWA source plan')
        names = set(spec.draft_attn_layer_names)
        groups = []
        for members in self.runner.attn_groups:
            for group in members:
                own = names.intersection(group.layer_names)
                if own:
                    groups.append((group.kv_cache_group_id, tuple(sorted(own))))
        require(len(groups) == 1 and len(names) == 8 and set(groups[0][1]) == names,
                'actual Full8 noncausal single-group reader inventory differs')
        causal = spec._group_causal
        require((causal.get(groups[0][0]) if isinstance(causal, Mapping) else causal) is False,
                'actual Full8 reader is not noncausal')
        # This is only a diagnostic inventory of actual framework groups.
        # No production provider, group, metadata or native plan is changed.
        return SimpleNamespace(full_gid=groups[0][0], full_layers=groups[0][1], native_groups=())


class Full8ReferenceWorker(Qwen36DFlashWorker):
    def mrv2_full8_reference_install(self, output, nonce, parent_pid, source_sha):
        require(not hasattr(self, '_full8_reference'), 'duplicate Full8 reference install')
        probe = Full8ReplayReference(self, output, RankContract(4, self.rank, nonce, parent_pid, source_sha))
        require(not probe.owned or probe.profile == shared.FULL8_FAILURE_PROFILE,
                'owned Full8 cannot borrow the SWA discriminator contract')
        probe.reader_plan()
        self._full8_reference = probe
        return dict(rank=self.rank, output=str(probe.output), profile=probe.profile)

    def mrv2_rank_snapshot(self):
        row = super().mrv2_rank_snapshot()
        probe = getattr(self, '_full8_reference', None)
        row['full8_reference'] = None if probe is None else probe.snapshot()
        return row


def preflight(llm, record, output):
    rows = llm.collective_rpc('mrv2_rank_snapshot', timeout=90)
    record['full8_post_capture_preflight'] = rows
    write(Path(output)/'campaign.json', record)
    require(len(rows) == 4 and {r['rank'] for r in rows} == set(range(4)), 'all4 post-capture workers required')
    for row in rows:
        validate_worker(row, 4)
        require(row['window_size'] == 1024 and row['window_provider_installed'] is True
                and row['heavy_observer_enabled'] is False and row['submission_uncertain'] is False,
                'actual controlled W1024 Graph required without heavy observer')
    nonce = uuid.uuid4().hex
    record['full8_reference_contract'] = dict(nonce=nonce, parent_pid=os.getpid(), source_sha=record['source_sha'])
    record['full8_reference_install'] = llm.collective_rpc('mrv2_full8_reference_install',
        args=(str(Path(output)/'numeric'), nonce, os.getpid(), record['source_sha']), timeout=90)
    write(Path(output)/'campaign.json', record)


def collect_full8_failure_repeat(probe, desc, metadata, caches, before, cpu):
    """Bounded repeated eager and functional calls, preserving completed stages.

    All extra operations are diagnostic. The normal eager builder supplies the
    reference state; the prior metadata-copy path is an explicit counterfactual,
    never an oracle. Unknown submission still uses Host-only quarantine/export.
    """
    import torch
    import torch_npu
    from vllm.config.compilation import CUDAGraphMode
    from vllm.v1.worker.gpu.attn_utils import build_slot_mappings_by_layer
    from vllm_ascend.attention.attention_v1 import AscendAttentionState, SWA_INT_MAX
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph_diagnostics import _metadata_header

    s = probe.owner
    require(probe.profile == shared.FULL8_FAILURE_PROFILE and probe.owned
            and s.input_batch.num_reqs == desc.num_reqs == 1,
            'bounded first active1/padded1 Full8 diagnostic required')

    def completed_reference(meta, label):
        probe.submission.submit(label+'_RESTORE_FORWARD_PENDING')
        for key, cache in caches.items():
            cache['tensor'].index_copy_(0, cache['indices'], before[key])
        restored = {key: cache['tensor'].index_select(0, cache['indices']) for key, cache in caches.items()}
        probe.sink.reference_active = True
        try:
            hidden = s._run_model(desc.num_tokens, meta,
                build_slot_mappings_by_layer(s.block_tables.slot_mappings[:, :desc.num_tokens], s.kv_cache_config),
                None, CUDAGraphMode.NONE)
        finally:
            probe.sink.reference_active = False
        torch.npu.current_stream().synchronize()
        probe.submission.complete(label+'_COMPLETE')
        probe.submission.submit(label+'_EXPORT_PENDING')
        result = dict(scope=label, hidden=cpu(hidden), attention=cpu(probe.sink.reference_attention),
                      restored=cpu(restored), metadata={k:_metadata_header(v) for k,v in meta.items()},
                      post={key: cpu(cache['tensor'].index_select(0,cache['indices'])) for key,cache in caches.items()})
        # Save now. A later optional call must not erase a completed comparison.
        write(probe.output/(label.lower()+'.json'), probe.writer.store.encode(dict(
            schema='COMPLETED_STAGE_EXCERPT_NOT_MAIN_NUMERIC_ARTIFACT', **result)))
        probe.submission.complete(label+'_EXPORT_COMPLETE')
        return result

    result = completed_reference(metadata, 'FULL8_SECOND_ACTUAL_EAGER_FROM_SAME_PRESTATE')
    name = probe.sink.attention_layer_name
    impl, meta = probe.sink._attention_impl, metadata[name]
    eligible = (meta.causal is False and impl.sinks is None and impl.sliding_window is None
                and meta.attn_state != AscendAttentionState.PrefillNoCache)
    guard = dict(layer=name, causal=meta.causal, sinks_is_none=impl.sinks is None,
                 sliding_window=impl.sliding_window,
                 attn_state=getattr(meta.attn_state,'name',None if meta.attn_state is None else str(meta.attn_state)),
                 eligible=eligible)
    write(probe.output/'functional-eligibility.json', guard)
    native = dict(status='SKIPPED_INTERFACE_BRANCH', guard=guard,
                  reason='No semantics changed to manufacture a cached noncausal functional call')
    if eligible:
        probe.submission.submit('FULL8_READONLY_FUNCTIONAL_INPUT_SNAPSHOT_PENDING')
        query = probe.sink.reference_attention['query']
        key, value, block, table, lengths = impl._get_fia_params(None, None, meta)
        kwargs = dict(input_layout='TND', num_heads=impl.num_heads, num_key_value_heads=impl.num_kv_heads,
                      block_size=block, actual_seq_lengths=list(meta.actual_seq_lengths_q),
                      actual_seq_lengths_kv=list(lengths), atten_mask=meta.attn_mask, sparse_mode=0,
                      scale=impl.scale, pre_tokens=SWA_INT_MAX, next_tokens=SWA_INT_MAX)
        first_caches = {k:c for k,c in caches.items() if any(x.rsplit('/',1)[0] == name for x in c['layers'])}
        native = dict(status='EXECUTED_TWO_READONLY_CALLS', guard=guard, layer=name,
                      parameters={k:v for k,v in kwargs.items() if k != 'atten_mask'},
                      mask=cpu(meta.attn_mask), query=cpu(query), table=cpu(table),
                      cache_headers=dict(key_shape=list(key.shape),value_shape=list(value.shape),
                                         key_stride=list(key.stride()),value_stride=list(value.stride()),
                                         key_dtype=str(key.dtype),value_dtype=str(value.dtype)),
                      before={k:cpu(c['tensor'].index_select(0,c['indices'])) for k,c in first_caches.items()}, outputs=[])
        probe.submission.complete('FULL8_READONLY_FUNCTIONAL_INPUT_SNAPSHOT_COMPLETE')
        for attempt in range(2):
            probe.submission.submit('FULL8_READONLY_FUNCTIONAL_CALL_PENDING')
            output, _ = torch_npu.npu_fused_infer_attention_score(query=query,key=key,value=value,block_table=table,**kwargs)
            torch.npu.current_stream().synchronize()
            probe.submission.complete('FULL8_READONLY_FUNCTIONAL_CALL_COMPLETE')
            probe.submission.submit('FULL8_READONLY_FUNCTIONAL_EXPORT_PENDING')
            native['outputs'].append(cpu(output))
            write(probe.output/f'functional-completed-{attempt}.json',probe.writer.store.encode(dict(
                schema='COMPLETED_STAGE_EXCERPT_NOT_MAIN_NUMERIC_ARTIFACT',**native)))
            probe.submission.complete('FULL8_READONLY_FUNCTIONAL_EXPORT_COMPLETE')
        probe.submission.submit('FULL8_READONLY_FUNCTIONAL_INPUT_READBACK_PENDING')
        native['after_query'], native['after_table'] = cpu(query), cpu(table)
        native['after'] = {k:cpu(c['tensor'].index_select(0,c['indices'])) for k,c in first_caches.items()}
        probe.submission.complete('FULL8_READONLY_FUNCTIONAL_INPUT_READBACK_COMPLETE')
    result['functional'] = native
    legacy = probe.legacy_reference_meta
    changed = {k for k in metadata if metadata[k].attn_state != legacy[k].attn_state}
    result['legacy_metadata_counterfactual'] = None
    if changed:
        old = completed_reference(legacy, 'LEGACY_C191_GRAPH_METADATA_COPY_NOT_ORACLE')
        old['changed_states'] = sorted(changed)
        result['legacy_metadata_counterfactual'] = old
    return result


def validate_generation_binding(record, worker):
    """Join like-for-like lengths: the Host generation exports Window exact.

    The raw canonical end is absolute. Derive the Window length independently
    from that end and the recorded block-aligned start; neither may stand in
    for the other. Padding remains zero and every actual reader must agree.
    """
    ident = record['identity']
    active, padded = ident['actual'], ident['padded']
    ends, starts = record['full_exact'], record['window_starts']
    require(type(active) is int and type(padded) is int and 0 < active <= padded
            and len(ends) == padded and len(starts) == active
            and all(type(v) is int for v in ends + starts)
            and all(0 <= start < end and start % 128 == 0
                    for end, start in zip(ends[:active], starts))
            and ends[active:] == [0] * (padded-active),
            'invalid canonical end, Window start or padding geometry')
    expected = [end-start for end, start in zip(ends[:active], starts)] + [0]*(padded-active)
    generations = [g for g in worker['window_generations']
                   if g['generation'] == ident['generation'] and g['epoch'] == ident['epoch']]
    bindings = [g for g in worker['window_graph_bindings']
                if g['generation'] == ident['generation'] and g['epoch'] == ident['epoch']]
    require(len(generations) == len(bindings) == 1, 'missing or ambiguous actual generation binding')
    g, binding = generations[0], bindings[0]
    require(g['actual'] == active and g['padded'] == padded
            and g['requests'] == record['requests'] and g['row_phases'] == record['row_phases']
            and g['window_starts'] == starts
            and g['global_group_id'] == binding['global_group_id'] == record['full_gid']
            and binding['capture_bucket'] == [padded, padded*8]
            and any(starts), 'raw sample differs from actual clipped Graph binding')
    require(g['exact'] == expected and record['actual_metadata']
            and all(meta['exact'] == expected for meta in record['actual_metadata'].values()),
            'Window exact differs from canonical Full end minus start')


def check(planned, execution):
    require('--owned-failure-probe' not in json.loads(Path(planned).read_text())['argv'],
            'owned failure discriminator requires raw analysis, not three-sample acceptance')
    result = check_anchor(planned, execution, kwargs_factory=build_kwargs, worker_validator=validate_worker,
                          entrypoint_name=Path(__file__).name, request_plan=REQUESTS, output_tokens=OUTPUT_TOKENS)
    if not result['status'].startswith('PASS_SCOPED_'):
        return result
    plan = json.loads(Path(planned).read_text())
    argv = plan['argv']
    output = Path(argv[argv.index('--output')+1])
    campaign = json.loads((output/'campaign.json').read_text())
    require(plan['profile_identity'] == campaign['profile_identity'] == identity(), 'fixed Full8 numerical scope differs')
    checked = []
    for worker in campaign['ranks']:
        summary = worker['full8_reference']
        path = Path(summary['collection'])
        require(path == output/'numeric'/f"rank-{worker['rank']}"/'numeric.json'
                and digest(path) == summary['manifest_sha256'] and summary['failed'] is False
                and summary['profile'] == PROFILE and summary['submission']['pending'] is False
                and {int(k): v for k,v in summary['counts'].items()} == shared.QUOTA,
                'missing numerical completion, source or quota')
        reader = CollectionReader(path)
        require(reader.execution == 'COMPLETE' and len(reader.samples) == 3
                and reader.header['profile'] == PROFILE and reader.header['rank'] == worker['rank']
                and reader.header['source'] == str(Path(argv[1]).resolve().parents[1])
                and reader.header['tool_sha256'] == digest(argv[1])
                and reader.header['reference_helper_sha256'] == digest(Path(argv[1]).with_name(Path(shared.__file__).name)),
                'partial or foreign numerical collection')
        records = [reader.record(i) for i in range(3)]
        require({n: sum(r['identity']['actual'] == n for r in records) for n in shared.QUOTA} == shared.QUOTA,
                'raw active-row coverage differs')
        previous = (-1, -1)
        for record in records:
            ident = record['identity']
            require(record.get('reference_metadata_source') == 'ACTUAL_DRAFT_EAGER_BUILDER_WITH_CANONICAL_READS',
                    'Graph carrier metadata is not the independent Draft eager builder')
            require(set(record['reference_backend_states']) == set(record['actual_metadata'])
                    and all(value is None for value in record['reference_backend_states'].values()),
                    'fixed dense Draft builder state differs; do not inherit Target PrefillNoCache')
            require(record['profile'] == PROFILE and ident['rank'] == worker['rank']
                    and ident['generation'] > previous[0] and ident['epoch'] > previous[1],
                    'cross-rank, foreign or stale raw sample')
            previous = (ident['generation'], ident['epoch'])
            validate_generation_binding(record, worker)
            require(not shared.validate_sample(record)['errors'], 'raw numerical or Full write mismatch')
            for cache in record['caches'].values():
                for layer_part in cache['layers']:
                    geometry = worker['draft_kv_geometry'][layer_part]
                    require(all(cache['allocation'][key] == geometry[key] for key in ('shape','stride','data_ptr','dtype')),
                            'snapshot allocation differs from actual worker geometry')
        checked.append(dict(rank=worker['rank'], samples=3, collection=str(path), sha256=digest(path)))
    result.update(status='PASS_SCOPED_FULL8_SAME_PRESTATE_NUMERIC_3_PER_RANK_TP4', numeric=checked,
                  scope='All4 ranks, three same-prestate actual eager comparisons per rank, all8 readers/16 KV parts; '
                        'retained Full blocks and current generation joins; serialized diagnostic, not complete '
                        'Target join, ABA, normal overlap or performance',
                  target_kv='NOT_JOINED', normal_overlap='UNPROVEN_SERIAL_DIAGNOSTIC', physical_read='NOT_OBSERVED')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('run','check'))
    parser.add_argument('--expected-sha')
    parser.add_argument('--tp', type=int, choices=(4,), default=4)
    parser.add_argument('--window-on-review', action='store_true')
    parser.add_argument('--owned-failure-probe', action='store_true')
    for name in ('admission','output','planned','execution'):
        parser.add_argument('--'+name, type=Path, required=name=='output')
    args = parser.parse_args()
    if args.command == 'run':
        require(args.window_on_review is True, 'explicit numerical ON only')
        receipt = json.loads(args.admission.read_text())
        validate_runtime_overlay(receipt['runtime_manifest']['path'], Path(__file__).resolve().parents[1],
                                 args.expected_sha, receipt['source_tree'])
        return run_anchor(args, profile_kwargs=build_kwargs(args.tp, window_on_review=True,
                                                          owned_failure_probe=args.owned_failure_probe),
                          profile_identity=identity(args.owned_failure_probe), producer_path=__file__, before_requests=preflight,
                          request_plan=REQUESTS, output_tokens=OUTPUT_TOKENS)
    try:
        result = check(args.planned, args.execution)
    except (ValueError, KeyError, TypeError, OSError, RuntimeError, IndexError) as error:
        result = dict(status='INVALID_EVIDENCE', error=str(error))
    write(args.output, result)
    return 0 if result['status'].startswith('PASS_SCOPED_') else 4


if __name__ == '__main__':
    raise SystemExit(main())
