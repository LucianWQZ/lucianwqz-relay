# SPDX-License-Identifier: Apache-2.0
"""SWA6 extra-Window32768 long Graph anchor with native operand Host headers.

This is the same finite TP4/DP1 request set as the original long control.
CPU-only records bind every observed native/Full metadata row to the actual
generation and canonical owners. They do not attest device completion,
execution operands, physical reads, independent numerical or performance.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
from functools import wraps
import json
from types import MethodType

from tools.p7x_graph_repair21_rank import digest, require, run_anchor, write
from tools.p7x_graph_repair28_rank_anchor_check import check as check_anchor
from tools.p7x_graph_repair70_qwen36_swa_anchor import Qwen36SWAWorker, validate_geometry
from tools.p7x_graph_repair72_qwen36_swa_long_anchor import (
    OUTPUT_TOKENS, REQUESTS, build_kwargs as original_kwargs, profile_identity as original_identity,
)

PROFILE = 'QWEN36_SWA6_WINDOW32768_GRAPH_TP4_DP1_LONG36865_V1'
MAX_RECORDS = 8192
# Frozen JSON vocabulary of the pinned row-phase contract. Offline validation
# must not import worker/native modules merely to inspect these strings.
ROW_PHASES = frozenset(('pure_decode', 'prefill_continuing', 'prefill_terminal'))


def profile_identity():
    return dict(profile=PROFILE,original_control=original_identity(),window_size=32768,
                scope='Same fixed model/requests; native causal4096 unchanged, Full extraWindow32768')


def build_kwargs(tp, *, window_on_review=False):
    require(window_on_review is True,'explicit SWA extra Window ON only; original control is separate')
    kw = original_kwargs(tp)
    kw['additional_config'] = dict(draft_window_size=32768,draft_window_graph_replicated_tp_review=True)
    kw['worker_extension_cls'] = 'tools.p7x_graph_repair73_qwen36_swa_window_anchor.SWAWindowWorker'
    return kw


def bound_record(spec,descriptor,*,allow_dp_dummy=False):
    if getattr(spec,'_draft_window_bypass_active',False):
        if getattr(spec,'_draft_window_dp_dummy_active',False):
            from vllm_ascend.worker.v2.spec_decode.draft_window_graph_metadata import is_parallel_graph_dp_dummy
            require(allow_dp_dummy is True and is_parallel_graph_dp_dummy(spec),
                    'DP dummy must be separately admitted, not a continuing prefill request')
            return dict(kind='BASELINE_DP_DUMMY',dp_size=spec.dp_size,scope_marker=True,
                no_live_generation=True,prefill_bypass=False,
                descriptor=dict(mode=descriptor.cg_mode.name,requests=descriptor.num_reqs,tokens=descriptor.num_tokens),
                scope='IDLE_REPLICA_BASELINE_GRAPH_NOT_A_BUSINESS_WINDOW_GENERATION')
        from vllm_ascend.worker.v2.spec_decode.draft_window_nongraph import classify_draft_window_batch_phase
        phase=classify_draft_window_batch_phase(spec.input_batch)
        require(getattr(spec,'_draft_window_prefill_bypass_active',False) is True
                and not getattr(spec,'_draft_window_dp_dummy_active',False) and phase.bypass_entire_batch,
                'unexpected dummy/profile bypass in real TP4/DP1 request replay')
        return dict(kind='BASELINE_CONTINUING_PREFILL',requests=list(phase.ordered_request_fingerprint),
            row_phases=list(phase.row_phase_fingerprint),actual=spec.input_batch.num_reqs,
            descriptor=dict(mode=descriptor.cg_mode.name,requests=descriptor.num_reqs,tokens=descriptor.num_tokens),
            scope='EXISTING_BASELINE_BYPASS_NOT_A_NEW_WINDOW_GENERATION')
    provider = spec._draft_window_graph_binding_provider
    plan = provider.native_swa_graph_plan
    require(plan is not None and len(provider.submitted_carriers)==1,'native/Full submitted reader contract missing')
    carrier = provider.submitted_carriers[0]
    full = carrier.native_full_snapshot
    require(full is not None,'current native full exact snapshot missing')
    identity = full.identity
    metadata = carrier.metadata
    selected = metadata[plan.full_layers[0]]
    layers=[]
    for group in plan.native_groups:
        for name in group.layers:
            value=metadata[name]
            layers.append(dict(layer=name,gid=group.gid,native_window=group.native_window,causal=value.causal,
                table_ptr=value.block_tables.data_ptr(),canonical_table_ptr=spec.block_tables.input_block_tables[group.gid].data_ptr(),
                seq_lens=list(value.seq_lens_list),slot_ptr=value.slot_mapping.data_ptr(),
                canonical_slot_ptr=spec.block_tables.slot_mappings[group.gid].data_ptr(),
                positions_ptr=value.positions.data_ptr(),query_ptr=value.query_start_loc.data_ptr()))
    return dict(kind='WINDOW_CURRENT',generation=identity.generation_id,epoch=identity.mapping_epoch,
        carrier_generation=carrier.runtime_identity.generation_id,carrier_epoch=carrier.runtime_identity.mapping_epoch,
        requests=list(identity.ordered_request_fingerprint),row_phases=list(identity.row_phase_fingerprint),
        actual=identity.actual_request_count,padded=identity.padded_request_count,
        descriptor=dict(mode=descriptor.cg_mode.name,requests=descriptor.num_reqs,tokens=descriptor.num_tokens),
        full_exact=full.cpu_exact.tolist(),window_exact=carrier.read_inputs.cpu_window_exact.tolist(),
        window_starts=[v.source_start_column*carrier.capture_identity.fingerprint.block_span_tokens+v.first_token_offset
                       for v in identity.read_descriptor_fingerprint],
        block_span=carrier.capture_identity.fingerprint.block_span_tokens,
        full_read=dict(layer=plan.full_layers[0],table_ptr=selected.block_tables.data_ptr(),
            bank_table_ptr=carrier.read_inputs.window_block_table.data_ptr(),seq_lens=list(selected.seq_lens_list),
            causal=selected.causal,slot_ptr=selected.slot_mapping.data_ptr(),
            canonical_slot_ptr=spec.block_tables.slot_mappings[plan.full_gid].data_ptr(),
            positions_ptr=selected.positions.data_ptr(),query_ptr=selected.query_start_loc.data_ptr()),
        full_gid=plan.full_gid,native_layers=layers,positions_ptr=spec.input_buffers.positions.data_ptr(),
        query_ptr=spec.input_buffers.query_start_loc.data_ptr(),
        scope='HOST_BOUND_METADATA_AFTER_MANAGER_RETURN_NOT_DEVICE_EXECUTION_OR_COMPLETION')


class SWAWindowWorker(Qwen36SWAWorker):
    def mrv2_rank_install_dispatch_observer(self):
        result=super().mrv2_rank_install_dispatch_observer()
        self._swa_window_records=[];self._swa_window_records_truncated=False
        manager=self.model_runner.speculator.query_cudagraph_manager
        original=manager.run_fullgraph
        @wraps(original)
        def replay(_manager,descriptor):
            value=original(descriptor)
            if len(self._swa_window_records)<MAX_RECORDS:
                self._swa_window_records.append(bound_record(self.model_runner.speculator,descriptor,
                    allow_dp_dummy=getattr(self,'swa_allow_dp_dummy',False)))
            else:self._swa_window_records_truncated=True
            return value
        manager.run_fullgraph=MethodType(replay,manager)
        return result

    def mrv2_rank_snapshot(self):
        row=super().mrv2_rank_snapshot()
        spec=self.model_runner.speculator
        plan=spec._draft_window_graph_binding_provider.native_swa_graph_plan
        module=Path(sys.modules[type(plan).__module__].__file__)
        row['swa_extra_window']=dict(window=plan.window_size,query_width=plan.query_width,full_gid=plan.full_gid,
            full_layers=list(plan.full_layers),native_groups=[dict(gid=g.gid,layers=list(g.layers),
                window=g.native_window,table_ptr=g.table_ptr) for g in plan.native_groups],
            module=dict(path=str(module),sha256=digest(module)),
            records=list(self._swa_window_records),truncated=self._swa_window_records_truncated,
            scope='ACTUAL_SOURCE_PROGRAM_AND_CPU_BOUND_METADATA_NOT_EXECUTION_OPERANDS')
        return row


def validate_bound(record,plan):
    n,p = record['actual'],record['padded']
    require(record['generation']==record['carrier_generation'] and record['epoch']==record['carrier_epoch']
            and record['full_gid']==plan['full_gid'] and record['block_span']==128
            and type(n) is type(p) is int and 0<n<=p and p in (1,2,4)
            and len(record['requests'])==n and len(set(record['requests']))==n
            and len(record['full_exact'])==len(record['window_exact'])==p and len(record['window_starts'])==n
            and record['descriptor']==dict(mode='FULL',requests=p,tokens=p*8),
            'native/Full current row/capture bucket differs')
    e,v,s=record['full_exact'],record['window_exact'],record['window_starts']
    phases=record['row_phases']
    require(len(phases)==n and all(p in ROW_PHASES for p in phases)
            and any(p!='prefill_continuing' for p in phases),
            'native Window Graph row phase or all-continuing baseline bypass differs')
    require(all(type(x) is int and x>=0 for x in e+v) and all(x>0 for x in e[:n])
            and all(type(x) is int and x>=0 and x%128==0 for x in s)
            and all(type(v[i]) is int and v[i]+s[i]==e[i] for i in range(n))
            and all(s[i]==(0 if phases[i]=='prefill_continuing'
                           else max(e[i]-32768,0)//128*128) for i in range(n))
            and all(e[i]==v[i]==0 for i in range(n,p)), 'native full E and extra Window V/S are inconsistent')
    selected=record['full_read']
    require(all(type(selected[k]) is int and selected[k]>0
                for k in ('table_ptr','bank_table_ptr','slot_ptr','canonical_slot_ptr','positions_ptr','query_ptr'))
            and selected['layer']==plan['full_layers'][0] and selected['table_ptr']==selected['bank_table_ptr']
            and selected['seq_lens']==v and selected['causal'] is False
            and selected['slot_ptr']==selected['canonical_slot_ptr']
            and selected['positions_ptr']==record['positions_ptr'] and selected['query_ptr']==record['query_ptr'],
            'Full layer lost Window read bank/exact or canonical write/query owners')
    expected={(name,g['gid']):g for g in plan['native_groups'] for name in g['layers']}
    rows=record['native_layers']
    require(len(rows)==len(expected) and {(r['layer'],r['gid']) for r in rows}==set(expected),
            'native reader missing/duplicated or assigned another group')
    for row in rows:
        group=expected[(row['layer'],row['gid'])]
        require(all(type(row[k]) is int and row[k]>0 for k in
                    ('table_ptr','canonical_table_ptr','slot_ptr','canonical_slot_ptr','positions_ptr','query_ptr'))
                and row['native_window']==group['window']==4096 and row['causal'] is True
                and row['table_ptr']==row['canonical_table_ptr']==group['table_ptr']
                and row['seq_lens']==e and row['slot_ptr']==row['canonical_slot_ptr']
                and row['positions_ptr']==record['positions_ptr'] and row['query_ptr']==record['query_ptr'],
                'native SWA lost original absolute read/write operands or causality')


def validate_worker(worker,tp,*,allow_dp_dummy=False):
    require(tp==4 and worker['window_size']==32768 and worker['window_provider_installed'] is True
            and worker['heavy_observer_enabled'] is False and worker['submission_uncertain'] is False,
            'actual observer-off TP4 extra Window32768 Graph required')
    validate_geometry(worker,tp)
    plan=worker['swa_extra_window'];p=worker['qwen36_profile']
    require(plan['window']==32768 and plan['query_width']==8 and plan['truncated'] is False
            and len(plan['full_layers'])==1 and len(plan['native_groups'])>=1,
            'actual native/Full source program differs')
    groups={g['global_group_id']:g['layers'] for g in p['draft_groups']}
    causal={g['global_group_id']:g['causal'] for g in p['group_causal']}
    native_names=[n for g in plan['native_groups'] for n in g['layers']]
    require(len(native_names)==len(set(native_names))==5 and not set(native_names)&set(plan['full_layers'])
            and len({g['gid'] for g in plan['native_groups']})==len(plan['native_groups'])
            and groups.get(plan['full_gid'])==plan['full_layers'] and causal[plan['full_gid']] is False
            and all(groups.get(g['gid'])==g['layers'] and causal[g['gid']] is True for g in plan['native_groups'])
            and set(plan['full_layers'])|{n for g in plan['native_groups'] for n in g['layers']}==set(worker['draft_layers']),
            'native/full source selection does not match actual model/cache inventory')
    previous=(-1,-1)
    for record in plan['records']:
        if record['kind']=='BASELINE_DP_DUMMY':
            p=record['descriptor']['requests']
            require(allow_dp_dummy is True and type(record['dp_size']) is int and record['dp_size']==2
                    and record['scope_marker'] is record['no_live_generation'] is True
                    and record['prefill_bypass'] is False and type(p) is int and p in (1,2,4)
                    and record['descriptor']==dict(mode='FULL',requests=p,tokens=p*8)
                    and not {'generation','epoch','requests','row_phases','full_exact'}&set(record),
                    'DP dummy lacks its no-generation baseline scope or is relabelled business state')
            continue
        if record['kind']=='BASELINE_CONTINUING_PREFILL':
            n=record['actual'];p=record['descriptor']['requests']
            require(type(n) is type(p) is int and 0<n<=p and p in (1,2,4)
                    and len(record['requests'])==len(set(record['requests']))==len(record['row_phases'])==n
                    and record['row_phases']==['prefill_continuing']*n
                    and record['descriptor']==dict(mode='FULL',requests=p,tokens=p*8)
                    and 'generation' not in record and 'epoch' not in record,
                    'baseline prefill was relabelled as a Window generation')
            continue
        require(record['kind']=='WINDOW_CURRENT','unknown native/Window replay kind')
        require(type(record['generation']) is type(record['epoch']) is int
                and record['generation']>previous[0] and record['epoch']>previous[1],
                'native snapshot is stale or belongs to a repeated generation')
        validate_bound(record,plan);previous=(record['generation'],record['epoch'])


def preflight(llm,record,output):
    rows=llm.collective_rpc('mrv2_rank_snapshot',timeout=90)
    record['swa_window_post_capture_preflight']=rows;write(Path(output)/'campaign.json',record)
    require(len(rows)==4 and {r['rank'] for r in rows}==set(range(4)),'all actual post-capture workers required')
    for row in rows:validate_worker(row,4)


def check(planned,execution):
    result=check_anchor(planned,execution,kwargs_factory=build_kwargs,worker_validator=validate_worker,
        entrypoint_name=Path(__file__).name,request_plan=REQUESTS,output_tokens=OUTPUT_TOKENS)
    if result['status'].startswith('PASS_SCOPED_'):
        plan=json.loads(Path(planned).read_text());argv=plan['argv']
        campaign=json.loads((Path(argv[argv.index('--output')+1])/'campaign.json').read_text())
        require(plan['profile_identity']==campaign['profile_identity']==profile_identity(),'fixed model/long-request identity changed')
        before=campaign['swa_window_post_capture_preflight'];after=campaign['ranks']
        require(len(before)==4 and {(r['rank'],r['pid'],r['process_start_ticks']) for r in before}
                =={(r['rank'],r['pid'],r['process_start_ticks']) for r in after},'worker changed after capture')
        for row in before:validate_worker(row,4)
        source=Path(argv[1]).resolve().parents[1]
        module=source/'vllm_ascend/worker/v2/spec_decode/draft_window_swa_graph.py'
        for row in after:
            require(row['swa_extra_window']['module']==dict(path=str(module),sha256=digest(module)),
                    'actual native SWA helper imported another source')
            records=row['swa_extra_window']['records']
            require(len(records)==row['draft_replays'] and records
                    and any(any(s>0 for s in r['window_starts']) for r in records if r['kind']=='WINDOW_CURRENT'),
                    'actual current native/Window binding absent from some Graph replay')
        result.update(status='PASS_SCOPED_SWA_WINDOW32768_GRAPH_LONG_REQUESTS_TP4_DP1',profile=PROFILE,
            scope='All4 current native/full Host bindings and real Graph dispatch/device joins; '
                  'not independent numerical, last-reader completion, DP2, physical-read or performance acceptance')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=('run','check'));parser.add_argument('--expected-sha')
    parser.add_argument('--tp',type=int,choices=(4,),default=4);parser.add_argument('--window-on-review',action='store_true')
    for name in ('admission','output','planned','execution'):
        parser.add_argument('--'+name,type=Path,required=name=='output')
    args=parser.parse_args()
    if args.command=='run':
        require(args.window_on_review is True,'explicit ON arm required')
        from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay
        require(args.admission is not None and args.expected_sha is not None,'fresh complete source/admission required')
        receipt=json.loads(args.admission.read_text())
        validate_runtime_overlay(receipt['runtime_manifest']['path'],Path(__file__).resolve().parents[1],
                                 args.expected_sha,receipt['source_tree'])
        return run_anchor(args,profile_kwargs=build_kwargs(args.tp,window_on_review=True),profile_identity=profile_identity(),
                          producer_path=__file__,before_requests=preflight,request_plan=REQUESTS,output_tokens=OUTPUT_TOKENS)
    require(args.planned is not None and args.execution is not None,'saved planned/execution evidence required')
    try:result=check(args.planned,args.execution)
    except (ValueError,KeyError,TypeError,OSError,IndexError,AttributeError) as error:
        result=dict(status='INVALID_EVIDENCE',error=str(error))
    write(args.output,result)
    return 0 if result['status'].startswith('PASS_SCOPED_') else 4


if __name__=='__main__':
    raise SystemExit(main())
