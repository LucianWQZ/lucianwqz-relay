# SPDX-License-Identifier: Apache-2.0
"""Designated Full8 DFlash original/Window Graph HTTP, TP4 per DP replica.

The pinned DP client broadcasts a collective RPC but returns only its first
replica's result. Each real worker therefore writes its own nonce-bound Host
record. Window ON uses the explicit private review. The named structural-SWA
option retains its own model, native layer geometry and Window32768 contract.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import asyncio
from functools import partial, wraps
import json
import re
import time
import urllib.request
from types import SimpleNamespace
from types import MethodType
import inspect

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair33_service import request, run_service, serve_argv, validate_requests
from tools.p7x_graph_repair39_service_identity import host_worker_identity, validate_worker_identity
from tools.p7x_graph_repair47_glm_service import install_phase_audit
from tools.p7x_graph_repair68_qwen36_dflash_anchor import (
    Qwen36DFlashWorker, TARGET, build_kwargs, profile_identity as full_model_identity, validate_worker,
)
from tools.p7x_graph_repair70_qwen36_swa_anchor import Qwen36SWAWorker
from tools.p7x_graph_repair73_qwen36_swa_window_anchor import SWAWindowWorker

PROFILE = 'QWEN36_FULL8_DFLASH_K7_Q8_TP4_DP2_GRAPH_HTTP_V3'
EXTENSION = 'tools.p7x_graph_repair69_qwen36_dp_service.Qwen36DPServiceWorker'
SWA_PROFILE = 'QWEN36_SWA6_DFLASH_K7_Q8_TP4_DP2_GRAPH_LONG_HTTP_V1'
SWA_EXTENSION = 'tools.p7x_graph_repair69_qwen36_dp_service.Qwen36SWADPServiceWorker'
SWA_WINDOW_EXTENSION = 'tools.p7x_graph_repair69_qwen36_dp_service.SWAWindowDPServiceWorker'


def profile_identity(*, structural_swa=False):
    require(type(structural_swa) is bool,'explicit named model selection required')
    if structural_swa:
        from tools.p7x_graph_repair70_qwen36_swa_anchor import profile_identity as swa_identity
        identity=swa_identity()
    else:identity=full_model_identity()
    return dict(identity,profile=SWA_PROFILE if structural_swa else PROFILE,source_model_identity_profile=identity['profile'],
                scope='Same fixed models/method; actual DP/TP/EP requires worker/group/device evidence')


def moe_shard_headers(model):
    from vllm.model_executor.layers.fused_moe.layer import MoERunner

    rows=[]
    for name,module in model.named_modules():
        if not isinstance(module,MoERunner):continue
        config=module.moe_config
        weights={key:dict(shape=list(value.shape),dtype=str(value.dtype),device=str(value.device))
                 for key,value in module.routed_experts.named_parameters(recurse=False)
                 if key in ('w13_weight','w2_weight')}
        rows.append(dict(name=name,module=type(module).__module__+'.'+type(module).__qualname__,
                         global_experts=config.num_experts,local_experts=config.num_local_experts,
                         ep_size=config.ep_size,ep_rank=config.ep_rank,weights=weights))
    return rows


def export_identity(row, destination, nonce):
    destination = Path(destination)
    require(isinstance(nonce,str) and len(nonce) == 32 and all(c in '0123456789abcdef' for c in nonce)
            and destination.is_absolute() and destination.name == nonce
            and (destination/'attempt-nonce').read_text() == nonce
            and row['nonce'] == nonce, 'fresh controller-created nonce directory required')
    dp, tp = row['dp_rank'], row['tp_rank']
    require(type(dp) is type(tp) is int and dp in range(2) and tp in range(4),
            'actual DP2/TP4 coordinate required')
    path = destination/f'dp-{dp}-tp-{tp}.json'
    # The controller waits for RPC completion before reading. Exclusive files
    # reject duplicate workers/coordinates; nothing can overwrite old evidence.
    with path.open('x') as stream:
        stream.write(json.dumps(row, indent=2, allow_nan=False)+'\n')
    return dict(dp_rank=dp, tp_rank=tp, pid=row['pid'], path=str(path), sha256=digest(path))


class Qwen36DPServiceWorker(Qwen36DFlashWorker):
    def mrv2_qwen_dp_identity(self, nonce, destination):
        from vllm.distributed.parallel_state import get_tp_group,get_dp_group,get_ep_group,get_world_group

        if not hasattr(self, '_mrv2_rank_replay_records'):
            self.mrv2_rank_install_dispatch_observer()
            install_dp_dummy_audit(self)
            install_phase_audit(self, detailed=True)
        parallel = self.vllm_config.parallel_config
        tp,dp,ep,world=get_tp_group(),get_dp_group(),get_ep_group(),get_world_group()
        row = host_worker_identity(self, nonce)
        row.update(dp_rank=parallel.data_parallel_rank, dp_size=parallel.data_parallel_size,
                   tp_rank=tp.rank_in_group,tp_size=tp.world_size,tp_ranks=list(tp.ranks),
                   global_rank=world.rank,global_world=world.world_size,world_ranks=list(world.ranks),
                   dp_group_rank=dp.rank_in_group,dp_ranks=list(dp.ranks),
                   ep_rank=ep.rank_in_group,ep_world=ep.world_size,ep_ranks=list(ep.ranks),
                   ep_enabled=parallel.enable_expert_parallel,target_moe_shards=moe_shard_headers(self.model_runner.model),
                   engine_rank=self.rank, rank_snapshot=self.mrv2_rank_snapshot(),
                   audit_tool=dict(path=__file__,sha256=digest(__file__)),
                   proposal_phases=list(self._mrv2_service_phases),
                   proposal_phases_truncated=self._mrv2_service_phases_truncated,
                   dp_dummy_records=list(self._mrv2_dp_dummy_records),
                   dp_dummy_records_truncated=self._mrv2_dp_dummy_records_truncated)
        return export_identity(row, destination, nonce)


class Qwen36SWADPServiceWorker(Qwen36SWAWorker, Qwen36DPServiceWorker):
    """Original native SWA geometry with the existing all-replica audit."""


class SWAWindowDPServiceWorker(SWAWindowWorker, Qwen36DPServiceWorker):
    """Keep real Window rows and explicitly scoped idle-replica calls separate."""
    swa_allow_dp_dummy = True


def install_dp_dummy_audit(worker):
    """CPU call records around existing dummy Graph/UPDATE, no device query."""
    spec=worker.model_runner.speculator;manager=spec.query_cudagraph_manager
    original=spec.propose;signature=inspect.signature(original)
    original_graph=manager.run_fullgraph;original_update=manager._update_full_graph_params
    worker._mrv2_dp_dummy_records=[];worker._mrv2_dp_dummy_records_truncated=False
    active=None
    def graph(_manager,desc):
        if active is None:return original_graph(desc)
        row=dict(mode=desc.cg_mode.name,tokens=desc.num_tokens,requests=desc.num_reqs,
                 scope_marker=getattr(spec,'_draft_window_dp_dummy_active',False),
                 no_live_generation=getattr(spec,'_draft_window_live_inputs',None) is None
                    and getattr(spec,'_draft_window_proposal_context',None) is None,
                 generations_before=len(worker._mrv2_rank_window_generations),updates=[],returned=False)
        active['graphs'].append(row);active['current_graph']=row
        try:
            value=original_graph(desc);row['returned']=True;return value
        finally:
            row['generations_after']=len(worker._mrv2_rank_window_generations)
            active.pop('current_graph',None)
    def update(_manager,*args,**kwargs):
        row=active.get('current_graph') if active is not None else None
        if row is not None:row['updates'].append(dict(window_binding=kwargs.get('draft_window_graph_update_binding') is not None))
        return original_update(*args,**kwargs)
    @wraps(original.__func__)
    def propose(_spec,*args,**kwargs):
        nonlocal active
        bound=signature.bind(*args,**kwargs)
        if not bound.arguments.get('dummy_run',False) or bound.arguments.get('is_profile',False):
            return original(*args,**kwargs)
        row=dict(graphs=[],returned=False,start_ns=time.monotonic_ns())
        if len(worker._mrv2_dp_dummy_records)<4096:worker._mrv2_dp_dummy_records.append(row)
        else:worker._mrv2_dp_dummy_records_truncated=True
        require(active is None,'nested DP dummy audit')
        active=row
        try:
            value=original(*args,**kwargs);row['returned']=True;return value
        finally:
            row.update(end_ns=time.monotonic_ns(),flags_after={name:bool(getattr(spec,name,False)) for name in
                ('_draft_window_dp_dummy_active','_draft_window_bypass_active','_draft_window_prefill_bypass_active')},
                submission_uncertain=bool(getattr(spec,'_draft_window_graph_submission_uncertain',False)))
            active=None
    manager.run_fullgraph=MethodType(graph,manager);manager._update_full_graph_params=MethodType(update,manager)
    spec.propose=MethodType(propose,spec)


def read_all_exports(destination, nonce):
    destination = Path(destination)
    paths = [destination/f'dp-{dp}-tp-{tp}.json' for dp in range(2) for tp in range(4)]
    require(set(destination.glob('dp-*-tp-*.json')) == set(paths),
            'missing or extra DP/TP worker export; one returned replica is insufficient')
    rows = []
    for path in paths:
        row = json.loads(path.read_text())
        require(path.name == f"dp-{row['dp_rank']}-tp-{row['tp_rank']}.json" and row['nonce'] == nonce,
                'export path/coordinate/nonce contradiction')
        row['durable_export'] = dict(path=str(path), sha256=digest(path))
        rows.append(row)
    return rows


def identity_collector(root, base, nonce):
    destination = Path(root)/nonce
    destination.mkdir(parents=True, exist_ok=False)
    (destination/'attempt-nonce').write_text(nonce)
    body = json.dumps(dict(method='mrv2_qwen_dp_identity', args=[nonce, str(destination)], timeout=90)).encode()
    req = urllib.request.Request(base+'/collective_rpc', data=body, headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=100) as response:
        require(response.status == 200, 'actual broadcast worker RPC failed')
        returned = json.load(response)['results']
    write(destination/'returned-first-replica.json', returned)
    rows = read_all_exports(destination, nonce)
    require(isinstance(returned, list) and len(returned) == 4, 'pinned first-replica RPC contract differs')
    for ack in returned:
        matches = [r for r in rows if (r['dp_rank'], r['tp_rank']) == (ack['dp_rank'], ack['tp_rank'])]
        require(len(matches) == 1 and matches[0]['pid'] == ack['pid']
                and matches[0]['durable_export'] == {k:ack[k] for k in ('path','sha256')},
                'returned replica acknowledgement does not match durable worker bytes')
    require(len({ack['dp_rank'] for ack in returned}) == 1
            and {ack['tp_rank'] for ack in returned} == set(range(4)), 'partial returned TP replica')
    return rows


def validate_workers(rows, *, nonce, source, vllm_source, arm, worker_validator=None, window_size=1024):
    require(arm in ('G_OFF','G_ON') and isinstance(rows, list) and len(rows) == 8,
            'explicit complete TP4/DP2 Graph baseline/review only')
    require({(r['dp_rank'],r['tp_rank']) for r in rows} == {(d,t) for d in range(2) for t in range(4)}
            and len({r['pid'] for r in rows}) == 8
            and {r['global_rank'] for r in rows} == set(range(8))
            and {r['ep_rank'] for r in rows} == set(range(8)), 'missing/duplicate DP/global/EP coordinate or worker PID')
    identities = []
    for row in rows:
        require(type(row['dp_rank']) is type(row['tp_rank']) is int
                and row['dp_size'] == 2 and row['tp_size'] == 4, 'actual model topology differs')
        require(type(row['global_rank']) is type(row['ep_rank']) is int
                and row['global_rank'] == row['dp_rank']*4+row['tp_rank']
                and row['global_world'] == row['ep_world'] == 8 and row['ep_enabled'] is True
                and set(row['world_ranks']) == set(row['ep_ranks']) == set(range(8))
                and row['ep_ranks'][row['ep_rank']] == row['global_rank']
                and row['tp_ranks'] == list(range(row['dp_rank']*4,row['dp_rank']*4+4))
                and row['dp_group_rank'] == row['dp_rank'] and row['dp_ranks'] == [row['tp_rank'],row['tp_rank']+4],
                'actual distributed TP/DP/EP groups differ from pinned non-elastic mp topology')
        shards=row['target_moe_shards']
        require(len(shards) == len({s['name'] for s in shards}) == 40
                and all(s['global_experts']==256 and s['local_experts']==32 and s['ep_size']==8
                        and s['ep_rank']==row['ep_rank'] and set(s['weights'])=={'w13_weight','w2_weight'}
                        and all(len(w['shape'])>=3 and w['shape'][0]==32 for w in s['weights'].values())
                        for s in shards), 'actual 40-layer Target MoE expert shards not established')
        producer_tool=Path(source)/'tools'/Path(__file__).name
        require(row['audit_tool'] == dict(path=str(producer_tool),sha256=digest(producer_tool)),
                'worker imported another DP audit tool')
        path = Path(row['durable_export']['path'])
        require(path.parent.name == nonce and digest(path) == row['durable_export']['sha256'],
                'durable export missing or changed')
        saved = json.loads(path.read_text())
        require(saved == {k:v for k,v in row.items() if k != 'durable_export'},
                'campaign replaces the actual worker export')
        identity = validate_worker_identity([row], nonce=nonce, source=source, vllm_source=vllm_source, arm=arm)
        snapshot = row['rank_snapshot']
        require(snapshot['pid'] == row['pid'] and snapshot['process_start_ticks'] == row['process_start_ticks']
                and type(row['engine_rank']) is int and row['engine_rank'] == snapshot['rank']
                and snapshot['world_size'] == snapshot['tp_size'] == 4
                and snapshot['window_size'] == (window_size if arm=='G_ON' else None)
                and snapshot['window_provider_installed'] is (arm=='G_ON')
                and snapshot['heavy_observer_enabled'] is False
                and not snapshot['submission_uncertain'], 'worker snapshot/DP replica association differs')
        (worker_validator or validate_worker)(snapshot, 4)
        identities.append(dict(dp_rank=row['dp_rank'],tp_rank=row['tp_rank'],**identity))
    return dict(status='ALL_8_DP_REPLICA_HOST_IDENTITIES',
                workers=sorted(identities,key=lambda r:(r['dp_rank'],r['tp_rank'])))


def server_argv(python, port, name, arm, *, worker_provenance=False, structural_swa=False):
    require(arm in ('G_OFF','G_ON') and worker_provenance is True,
            'explicit Graph OFF baseline/ON review with separate Host audit required')
    require(type(structural_swa) is bool,'explicit named model selection required')
    if structural_swa:
        from tools.p7x_graph_repair72_qwen36_swa_long_anchor import build_kwargs as swa_off
        from tools.p7x_graph_repair73_qwen36_swa_window_anchor import build_kwargs as swa_on
        kwargs = (swa_on if arm=='G_ON' else swa_off)(4,window_on_review=arm=='G_ON')
        extension=SWA_WINDOW_EXTENSION if arm=='G_ON' else SWA_EXTENSION
    else:
        kwargs = build_kwargs(4,window_on_review=arm=='G_ON');extension=EXTENSION
    argv = serve_argv(python,port,name,arm,worker_provenance=True)
    argv[argv.index('serve')+1] = str(TARGET)
    for flag,value in [('--tensor-parallel-size','4'),('--max-model-len','40960' if structural_swa else '4096'),
                       ('--speculative-config',json.dumps(kwargs['speculative_config'],sort_keys=True)),
                       ('--compilation-config',json.dumps(kwargs['compilation_config'],sort_keys=True)),
                       ('--additional-config',json.dumps(kwargs['additional_config'],sort_keys=True)),
                       ('--worker-extension-cls',extension)]:
        argv[argv.index(flag)+1] = value
    return argv+['--data-parallel-size','2','--data-parallel-size-local','2',
                 '--enable-expert-parallel','--trust-remote-code','--quantization','ascend',
                 '--distributed-executor-backend','mp']


def validate_groups(groups,*,max_model_len=4096):
    require(type(max_model_len) is int and 0<max_model_len<=40960,'explicit bounded model context required')
    require(isinstance(groups,list) and 1 <= len(groups) <= 4
            and len({g['label'] for g in groups}) == len(groups), 'bounded distinct request groups required')
    for group in groups:
        require(len(group['prompts']) == 2 and type(group['max_tokens']) is int
                and group['max_tokens'] in (256,512), 'both replicas and fixed output budget required')
        require(all(0 < len(p['prompt_token_ids']) and len(p['prompt_token_ids'])+group['max_tokens'] <= max_model_len
                    and all(type(v) is int and 0 <= v < 248320 for v in p['prompt_token_ids'])
                    for p in group['prompts']), 'request exceeds actual named model/profile')


def validate_dispatch(rows, records, *, window_on_review=False, allow_continuing_prefill=False):
    from tools.p7x_graph_repair16_scheduler import phase_from_rows

    require(type(allow_continuing_prefill) is bool,'explicit continuing-prefill review flag required')
    expected = {dp:{g['results'][dp]['summary']['response_id']+'-0' for g in records['groups']}
                for dp in range(2)}
    require(all(len(expected[dp])==len(records['groups']) for dp in range(2)),
            'duplicate external HTTP request identity')
    normalized, summaries = {}, []
    for worker in rows:
        dp,tp = worker['dp_rank'],worker['tp_rank']
        phases = worker['proposal_phases']
        require(phases and worker['proposal_phases_truncated'] is False,
                'actual non-dummy proposals missing from a replica')
        requests_seen, graph_requests, sequence = set(),set(),[]
        previous_generation=previous_epoch=-1;clipped=False
        for phase in phases:
            raw = phase['raw_cpu_rows']
            row_phases,batch_phase = phase_from_rows(raw)
            require(phase['returned'] is True and 'classification_error' not in phase
                    and phase['requests'] == raw['request_ids'] and phase['row_phases'] == row_phases
                    and phase['batch_phase'] == batch_phase,
                    'non-dummy request/CPU phase/Window OFF state differs')
            require(type(phase['start_ns']) is type(phase['end_ns']) is int
                    and phase['start_ns'] < phase['end_ns'], 'proposal Host clock range missing')
            require(set(phase['flags_after']) == {'_draft_window_bypass_active','_draft_window_prefill_bypass_active'}
                    and all(value is False for value in phase['flags_after'].values()), 'bypass flag not reset')
            graphs=[v for v in phase['manager_calls'] if v['role'].startswith('draft:')]
            require(all(v['returned'] is True and v['mode'] == 'FULL'
                        and v['num_tokens'] in (8,16,32)
                        and phase['start_ns'] <= v['host_start_ns'] < v['host_return_ns'] <= phase['end_ns']
                        for v in graphs), 'actual Draft Graph dispatch differs')
            if not window_on_review:
                require(not phase['window_materializations'],'Window OFF unexpectedly materialized a generation')
            else:
                materialized=phase['window_materializations']
                baseline=allow_continuing_prefill and row_phases==['prefill_continuing']*len(row_phases)
                if baseline:
                    require(not materialized,'continuing prefill baseline created a Window generation')
                else:
                    require((batch_phase in ('pure_prefill_terminal','pure_decode') or allow_continuing_prefill)
                            and len(materialized)==1 and graphs,
                        'named Window service requires one real generation per terminal/decode Graph proposal')
                    value=materialized[0]
                    n=len(phase['requests'])
                    require(value['requests']==phase['requests'] and value['row_phases']==row_phases
                            and type(value['actual']) is type(value['padded']) is int
                            and value['actual']==n and value['padded'] in (1,2,4) and n<=value['padded']
                            and value['tp_size']==4 and value['tp_rank']==tp
                            and type(value['generation']) is type(value['epoch']) is int
                            and value['generation']>previous_generation and value['epoch']>previous_epoch
                            and len(value['exact'])==value['padded'] and len(value['window_starts'])==n
                            and all(type(v) is int and v>0 for v in value['exact'][:n])
                            and all(type(v) is int and v==0 for v in value['exact'][n:])
                            and all(type(v) is int and v>=0 and v%128==0 for v in value['window_starts']),
                            'stale, unowned or wrong-row Window generation')
                    matches=[v for v in worker['rank_snapshot']['window_graph_bindings']
                             if v['generation']==value['generation'] and v['epoch']==value['epoch']]
                    require(len(matches)==1 and matches[0]['tp_rank']==tp and matches[0]['tp_size']==4
                            and matches[0]['global_group_id']==value['global_group_id']
                            and matches[0]['capture_bucket']==[value['padded'],value['padded']*8]
                            and all(v['num_reqs']==value['padded'] and v['num_tokens']==value['padded']*8 for v in graphs),
                            'actual Window generation is not bound to its Graph bucket')
                    previous_generation,previous_epoch=value['generation'],value['epoch']
                    clipped|=any(v>0 for v in value['window_starts'])
            requests_seen.update(phase['requests'])
            if graphs: graph_requests.update(phase['requests'])
            sequence.append(dict(raw=raw,graphs=[{k:v[k] for k in ('role','mode','num_tokens','num_reqs')}
                                                for v in graphs],
                window=[{k:v[k] for k in ('generation','epoch','global_group_id','actual','padded','requests',
                                          'row_phases','exact','window_starts')} for v in phase['window_materializations']]))
        # Pinned vLLM 84030bbe: completion/serving.py first appends the
        # prompt index; InputProcessor.assign_request_id then appends exactly
        # eight random_uuid hex characters. Never strip an arbitrary suffix
        # or match only a shared prefix. Each HTTP identity must resolve one
        # complete internal ID, on this replica and every TP peer.
        bindings={external:sorted(request for request in requests_seen
                                 if re.fullmatch(re.escape(external)+r'-[0-9a-f]{8}',request))
                  for external in expected[dp]}
        require(all(len(matches)==1 for matches in bindings.values())
                and requests_seen == graph_requests == {matches[0] for matches in bindings.values()},
                'replica did not dispatch real Draft Graphs for its actual routed HTTP requests')
        if dp in normalized: require(sequence == normalized[dp], 'TP peers disagree within a DP replica')
        if window_on_review:require(clipped,'this replica never actually clipped a Window')
        normalized[dp]=sequence
        summaries.append(dict(dp_rank=dp,tp_rank=tp,proposals=len(phases),requests=len(requests_seen),
                              external_to_internal={key:values[0] for key,values in sorted(bindings.items())},
                              window_clipped=clipped if window_on_review else None))
    require({(r['dp_rank'],r['tp_rank']) for r in summaries} == {(d,t) for d in range(2) for t in range(4)},
            'incomplete dispatch replica/TP set')
    return dict(scope='ACTUAL_NON_DUMMY_HTTP_REQUEST_AND_HOST_GRAPH_DISPATCH_NOT_DEVICE_OPERANDS',workers=summaries)


async def clients(base, name, groups, output):
    import aiohttp
    rows = []
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=600)) as session:
        for phase in ('warmup','measured'):
            for group in groups:
                require(len(group['prompts']) == 2, 'each group must explicitly exercise both DP replicas')
                start = time.monotonic_ns()
                results = await asyncio.gather(*[
                    request(session,base+'/v1/completions',model=name,prompt=p['prompt_token_ids'],
                            output=group['max_tokens'],data_parallel_rank=dp,
                            failure_path=output/f'failed-{phase}-{group["label"]}-dp{dp}.json')
                    for dp,p in enumerate(group['prompts'])])
                rows.append(dict(phase=phase,label=group['label'],group_start_ns=start,
                                 group_end_ns=time.monotonic_ns(),results=results))
                write(output/'requests.json',dict(status='IN_PROGRESS',groups=rows))
    return rows


def check_saved(args, *, producer_source=None, declared_server_argv=None):
    require(args.campaign is not None and args.records is not None and args.requests is not None,
            'saved campaign, client records and frozen requests required')
    require(declared_server_argv is not None or args.server_argv is not None,
            'declared official server invocation required')
    structural_swa=getattr(args,'structural_swa',False)
    campaign = json.loads(args.campaign.read_text())
    receipt_path = Path(campaign['admission_path'])
    require(digest(receipt_path) == campaign['admission_sha256'], 'original admission changed')
    receipt = json.loads(receipt_path.read_text())
    source = Path(__file__).resolve().parents[1] if producer_source is None else Path(producer_source)
    from tools.p7x_graph_local_candidate import BASE_SHA,VLLM_SHA,VLLM_TREE,_identity
    _identity(source,args.expected_sha,receipt['source_tree'],ancestor=BASE_SHA)
    _identity(Path(receipt['vllm_checkout']),VLLM_SHA,VLLM_TREE)
    from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay
    runtime = validate_runtime_overlay(receipt['runtime_manifest']['path'],source,args.expected_sha,receipt['source_tree'])
    require(runtime == campaign['runtime_manifest'] == receipt['runtime_manifest'], 'native/runtime binding changed')
    require(receipt['source_sha'] == campaign['source_sha'] == args.expected_sha
            and receipt['tp'] == 8 and len(receipt['phy_ids']) == len(set(receipt['phy_ids'])) == 8
            and campaign['named_profile'] == (SWA_PROFILE if structural_swa else PROFILE) and campaign['execution_tp'] == 4
            and campaign['execution_dp'] == 2 and campaign['physical_device_count'] == 8,
            'source/complete devices/actual TP4 per DP2 topology differs')
    require(campaign['profile_identity'] == profile_identity(structural_swa=structural_swa), 'fixed model identity changed')
    declared = json.loads(args.server_argv.read_text()) if declared_server_argv is None else declared_server_argv
    expected = server_argv(declared[0],args.port,declared[declared.index('--served-model-name')+1],args.arm,
                           worker_provenance=True,structural_swa=structural_swa)
    require(expected == declared, 'declared official CLI differs from named model/config')
    records = json.loads(args.records.read_text())
    validate_groups(json.loads(args.requests.read_text()),max_model_len=40960 if structural_swa else 4096)
    require(digest(args.requests) == campaign['requests_sha256'], 'frozen requests changed')
    worker_identity_validator=validate_workers
    extension=EXTENSION
    if structural_swa:
        from tools.p7x_graph_repair70_qwen36_swa_anchor import validate_worker as swa_off
        from tools.p7x_graph_repair73_qwen36_swa_window_anchor import validate_worker as swa_on
        validator=partial(swa_on,allow_dp_dummy=True) if args.arm=='G_ON' else swa_off
        worker_identity_validator=partial(validate_workers,worker_validator=validator,window_size=32768)
        extension=SWA_WINDOW_EXTENSION if args.arm=='G_ON' else SWA_EXTENSION
    result = validate_requests(campaign,records,json.loads(args.requests.read_text()),
        expected_server_argv=expected,expected_source=source,expected_vllm_source=receipt['vllm_checkout'],
        worker_identity_validator=worker_identity_validator,worker_extension_cls=extension)
    for group in records['groups']:
        require([r.get('routing_headers') for r in group['results']] ==
                [{'X-data-parallel-rank':str(dp)} for dp in range(2)], 'actual explicit DP request routing absent')
    snapshots = [r['rank_snapshot'] for r in campaign['worker_provenance'][-1]['results']]
    require(all(s['draft_replays'] > 0 and s['target_replays'] > 0 for s in snapshots),
            'some actual DP/TP worker did not dispatch both Graph roles')
    rows=campaign['worker_provenance'][-1]['results']
    result['all_replica_dispatch'] = validate_dispatch(rows,records,window_on_review=args.arm=='G_ON',
                                                     allow_continuing_prefill=structural_swa)
    if structural_swa and args.arm=='G_ON':
        module=source/'vllm_ascend/worker/v2/spec_decode/draft_window_swa_graph.py'
        for snapshot in snapshots:
            plan=snapshot['swa_extra_window']
            require(plan['module']==dict(path=str(module),sha256=digest(module))
                    and len(plan['records'])==snapshot['draft_replays'] and plan['records'],
                    'SWA source program/bound records absent from some actual Graph replay')
    if args.arm=='G_ON':result['dummy_audit']=validate_dummy_records(rows)
    result.update(status='PASS_SCOPED_QWEN36_TP4_DP2_HTTP_HOST_DISPATCH_DEVICE_JOIN_REQUIRED',
                  numeric='NOT_ASSESSED',normal_completion='NOT_PROVEN',window='ON_REVIEW' if args.arm=='G_ON' else 'OFF_ONLY',
                  execution_operand='NOT_OBSERVED',physical_read='NOT_AVAILABLE',
                  profile=SWA_PROFILE if structural_swa else PROFILE)
    return result


def validate_dummy_records(rows):
    """Scope only observed Host dummy calls, retaining an explicit zero case."""
    count=0
    require(all(row['dp_dummy_records_truncated'] is False for row in rows),'DP dummy records truncated')
    for row in rows:
        for dummy in row['dp_dummy_records']:
            require(dummy['returned'] is True and dummy['submission_uncertain'] is False
                    and set(dummy['flags_after'])=={'_draft_window_dp_dummy_active','_draft_window_bypass_active',
                                                   '_draft_window_prefill_bypass_active'}
                    and all(value is False for value in dummy['flags_after'].values()),
                    'DP dummy scope failed or flags not reset')
            for graph in dummy['graphs']:
                require(graph['returned'] is True and graph['mode']=='FULL' and graph['scope_marker'] is True
                        and graph['no_live_generation'] is True
                        and type(graph['generations_before']) is type(graph['generations_after']) is int
                        and graph['generations_before']==graph['generations_after']
                        and graph['updates']==[dict(window_binding=False)],
                        'DP dummy reused a business Window generation or omitted baseline UPDATE')
                count+=1
    return dict(graph_calls=count,status='OBSERVED_HOST_DUMMY_BASELINE_UPDATE' if count else 'NOT_OBSERVED',
                completion='NOT_PROVEN_BY_HOST_RETURN')


def validate_device_join(rows, associations, physicals, receipt, *, source_sha, execution):
    """Join eight global ranks, preserving the separate TP4/DP2 coordinates."""
    from tools.p7x_graph_repair30_device_join import validate_association

    require(len(rows)==8 and all(type(row['global_rank']) is int for row in rows)
            and {row['global_rank'] for row in rows}==set(range(8)),
            'missing/duplicate actual global worker')
    require(len(physicals)==8 and all(type(p) is int and p in range(16) for p in physicals)
            and len(set(physicals))==8 and physicals==receipt['phy_ids'],
            'complete distinct admitted physical devices required')
    mapping=receipt['mapping_evidence']
    require(digest(mapping['path'])==mapping['sha256'],'saved physical map changed')
    raw=json.loads(Path(mapping['path']).read_text())['mapping_command']
    require(raw['rc']==0,'actual physical mapping not available')
    require(len(associations)==8 and all(type(v['rank']) is int for v in associations)
            and {v['rank'] for v in associations}==set(range(8)),
            'missing/duplicate independent global worker/device association')
    for row in rows:
        worker=dict(row['rank_snapshot'],rank=row['global_rank'])
        physical=physicals[row['global_rank']]
        chip=[line.split()[:2] for line in raw['stdout'].splitlines()
              if len(line.split())>=5 and line.split()[2:4]==[str(physical),str(physical)]]
        require(len(chip)==1 and row['hostname']==receipt['host'] and row['boot_id']==receipt['boot_id']
                and row['namespace']==receipt['namespace'], 'worker runtime/physical chip ambiguity')
        association=next(v for v in associations if v['rank']==row['global_rank'])
        validate_association(worker,physical,association,chip[0],source_sha=source_sha,execution=execution)
    return dict(status='ALL_8_GLOBAL_WORKERS_DEVICE_ASSOCIATED',physical_devices=physicals)


def check_external_saved(args):
    from tools.p7x_graph_local_candidate import BASE_SHA,_git,_identity

    require(args.planned is not None and args.execution is not None,
            'original planned invocation and actual execution evidence required')
    plan=json.loads(args.planned.read_text());observed=json.loads(args.execution.read_text())
    argv=plan['argv'];run=build_parser().parse_args(argv[2:]);execution=observed['execution']
    source=Path(argv[1]).resolve().parents[1]
    require(Path(argv[1]) == source/'tools'/Path(__file__).name and run.command=='run'
            and run.expected_sha==plan['source_sha']==args.expected_sha
            and run.arm==args.arm and run.arm in ('G_OFF','G_ON') and run.port==args.port
            and execution['argv']==argv and execution['returncode']==0
            and execution['signal'] is None and execution['timeout'] is False,
            'actual named producer invocation did not complete')
    checker=Path(__file__).resolve().parents[1]
    checker_sha,checker_tree=_git(checker,'rev-parse','HEAD'),_git(checker,'rev-parse','HEAD^{tree}')
    _identity(checker,checker_sha,checker_tree,ancestor=BASE_SHA)
    receipt=json.loads(run.admission.read_text());campaign=json.loads((run.output/'campaign.json').read_text())
    require(digest(run.admission)==plan['admission_sha256']==campaign['admission_sha256']
            and receipt['source_tree']==plan['source_tree']==campaign['source_tree']
            and receipt['phy_ids']==plan['phy_ids'] and len(set(plan['phy_ids']))==8
            and digest(run.requests)==plan['requests_sha256']
            and campaign['pid']==execution['pid']
            and execution['start_epoch']<=campaign['started_at']<campaign['ended_at']<=execution['end_epoch'],
            'producer/campaign/admission/request/process association differs')
    name='graph-r6-'+run.expected_sha[:8]+'-'+run.arm.lower()
    declared=server_argv(argv[0],run.port,name,run.arm,worker_provenance=True,structural_swa=run.structural_swa)
    saved=SimpleNamespace(campaign=run.output/'campaign.json',records=run.output/'requests.json',
                          requests=run.requests,expected_sha=run.expected_sha,port=run.port,arm=run.arm,
                          structural_swa=run.structural_swa)
    result=check_saved(saved,producer_source=source,declared_server_argv=declared)
    result['device_join']=validate_device_join(campaign['worker_provenance'][-1]['results'],
        observed['per_rank_device_association'],plan['phy_ids'],receipt,
        source_sha=run.expected_sha,execution=execution)
    result.update(status='PASS_SCOPED_QWEN36_TP4_DP2_OFFICIAL_HTTP_ALL8_DEVICE_ASSOCIATED'
                         + ('_WINDOW_ON_REVIEW' if run.arm=='G_ON' else ''),
                  producer_commit=run.expected_sha,checker_commit=checker_sha,checker_tree=checker_tree,
                  checker_tool_sha256=digest(__file__),actual_tp=4,actual_dp=2,actual_ep=8,
                  scope='All real worker/group/shard/HTTP/Host Graph dispatch identities joined to device observations; '
                        + ('explicit Window generation/bucket and observed dummy baseline UPDATE reviewed. ' if run.arm=='G_ON' else 'Window OFF. ')
                        + 'Not internal numerical, device completion, execution operand, physical-read or performance acceptance.')
    if run.structural_swa:
        result['status']+='__STRUCTURAL_SWA6_WINDOW32768' if run.arm=='G_ON' else '__STRUCTURAL_SWA6_ORIGINAL_OFF'
    return result


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=('run','check','check-external'))
    parser.add_argument('--expected-sha',required=True)
    parser.add_argument('--arm',choices=('G_OFF','G_ON'),required=True)
    parser.add_argument('--port',type=int,required=True)
    parser.add_argument('--structural-swa',action='store_true',
                        help='Named fixed six-layer SWA model, context40960 and optional extra Window32768')
    for name in ('admission','output','requests','campaign','records','server-argv','planned','execution'):
        parser.add_argument('--'+name,type=Path,required=name=='output')
    return parser


def main():
    args = build_parser().parse_args()
    if args.command in ('check','check-external'):
        result = dict(status='INVALID_EVIDENCE')
        try: result = check_saved(args) if args.command=='check' else check_external_saved(args)
        except (ValueError,KeyError,TypeError,OSError,IndexError) as error: result['error']=f'{type(error).__name__}: {error}'
        write(args.output,result)
        return 0 if result['status'].startswith('PASS_SCOPED_') else 4
    require(args.admission is not None and args.requests is not None,'fresh complete physical admission and frozen requests required')
    validate_groups(json.loads(args.requests.read_text()),max_model_len=40960 if args.structural_swa else 4096)
    from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay
    receipt = json.loads(args.admission.read_text())
    runtime = validate_runtime_overlay(receipt['runtime_manifest']['path'],Path(__file__).resolve().parents[1],
                                       args.expected_sha,receipt['source_tree'])
    args.worker_provenance = True
    return run_service(args,server_argv_builder=partial(server_argv,structural_swa=args.structural_swa),target_model=TARGET,tp=4,dp=2,
        ready_timeout_seconds=1200,client_runner=clients,
        identity_collector=partial(identity_collector,args.output/'worker_identity_exports'),
        extra_metadata=dict(named_profile=SWA_PROFILE if args.structural_swa else PROFILE,
                            profile_identity=profile_identity(structural_swa=args.structural_swa),runtime_manifest=runtime))


if __name__ == '__main__':
    raise SystemExit(main())
