#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Full Chrome trace flow association; no adjacency-based kernel attribution."""

from __future__ import annotations

import sys
from pathlib import Path

# Direct script execution must not resolve tools/bisect as the stdlib module.
if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != root / "tools"]
    sys.path.insert(0, str(root))

import argparse
import bisect
import json
from collections import Counter, defaultdict
from decimal import Decimal


def stamp(e):
    return Decimal(str(e["ts"]))


def flow_key(e):
    # Chrome id2.local is process scoped; global and legacy id join processes.
    ident = e.get("id2", e.get("id"))
    local = isinstance(ident, dict) and "local" in ident
    return (
        e.get("cat"),
        e.get("name") if e.get("name") in ("torch_to_npu", "enqueue_to_dequeue") else None,
        json.dumps(ident, sort_keys=True),
        e.get("pid") if local else None,
        e.get("scope"),
    )


class Intervals:
    def __init__(self, events, predicate):
        self.by_thread = defaultdict(list)
        for i, e in enumerate(events):
            if e.get("ph") == "X" and "ts" in e and predicate(e):
                self.by_thread[(e.get("pid"), e.get("tid"))].append((stamp(e), stamp(e) + Decimal(str(e["dur"])), i))
        self.index = {}
        for key, rows in self.by_thread.items():
            rows.sort()
            # A long request range can cover thousands of disjoint operators.
            # Prefix maxima then force a scan of every earlier operator for
            # every point. A max-end tree prunes expired subtrees while keeping
            # the same inclusive boundaries and innermost-first result order.
            size = 1
            while size < len(rows):
                size *= 2
            ends = [Decimal("-Infinity")] * (2 * size)
            for i, (_, end, _) in enumerate(rows):
                ends[size + i] = end
            for i in range(size - 1, 0, -1):
                ends[i] = max(ends[2 * i], ends[2 * i + 1])
            self.index[key] = ([r[0] for r in rows], rows, size, ends)

    def containing(self, e):
        key = (e.get("pid"), e.get("tid"))
        if key not in self.index:
            return []
        starts, rows, size, ends = self.index[key]
        at = stamp(e)
        last = bisect.bisect_right(starts, at) - 1
        matches = []

        def visit(node, left, right):
            if left > last or ends[node] < at:
                return
            if left == right:
                start, end, i = rows[left]
                if start <= at <= end:
                    matches.append((end - start, i))
                return
            middle = (left + right) // 2
            visit(2 * node, left, middle)
            visit(2 * node + 1, middle + 1, right)

        if last >= 0:
            visit(1, 0, size - 1)
        return [i for _, i in sorted(matches)]


def destination_kind(flow, events):
    """Classify explicit endpoints; outer model ranges do not rename events."""
    if flow["status"] != "MATCHED":
        return "UNRESOLVED"
    destinations = flow.get("destination_intervals", [])
    if not destinations:
        return "UNKNOWN_DESTINATION"
    # Intervals.containing sorts innermost first by duration.
    leaf = events[destinations[0]].get("name")
    if leaf in ("EVENT_RECORD", "EVENT_WAIT", "EVENT_RESET"):
        return "DEVICE_EVENT_FLOW"
    if "enqueue_to_dequeue" in flow["key"]:
        return "HOST_QUEUE_EVENT_FLOW"
    if leaf == "MODEL_EXECUTE":
        return "MODEL_EXECUTION_CONTEXT_FLOW"
    return "OTHER_EXPLICIT_FLOW"


def analyze(events, *, replay_roles=("Draft",)):
    contracts = {
        "Draft": ("repair5/Draft_REPLAY_SUBMIT", "repair5/Draft_REPLAY_PLUS_UPDATE"),
        "Eagle_first": ("repair5/Draft_first_pass_REPLAY_SUBMIT", "repair5/Draft_first_pass_REPLAY_PLUS_UPDATE"),
        "Eagle_AR": ("repair5/Draft_AR_REPLAY_SUBMIT", "repair5/Draft_AR_REPLAY_PLUS_UPDATE"),
        "Target": ("repair5/Target_REPLAY_SUBMIT", "repair5/Target_REPLAY_PLUS_UPDATE"),
    }
    if (not isinstance(replay_roles, (tuple, list)) or not replay_roles
            or any(type(role) is not str or role not in contracts for role in replay_roles)
            or len(set(replay_roles)) != len(replay_roles)):
        raise ValueError("explicit unique supported Host replay roles required")
    selected = {contracts[role][0]: (role, contracts[role][1]) for role in replay_roles}
    flows = defaultdict(list)
    for i, e in enumerate(events):
        if e.get("ph") in ("s", "f", "t"):
            flows[flow_key(e)].append(i)
    intervals = Intervals(events, lambda e: True)
    ranges = Intervals(events, lambda e: e.get("name", "").startswith(("repair5/", "repair6/")))
    joined = []
    counts = Counter()
    by_category = defaultdict(Counter)
    for key, indices in flows.items():
        starts = [i for i in indices if events[i]["ph"] == "s"]
        ends = [i for i in indices if events[i]["ph"] == "f"]
        status = (
            "MATCHED"
            if len(starts) == len(ends) == 1 and len(indices) == 2
            else ("UNMATCHED" if not starts or not ends else "AMBIGUOUS")
        )
        counts[status] += 1
        by_category[str(key[0])][status] += 1
        row = dict(key=list(key), status=status, event_indices=indices)
        if status == "MATCHED":
            s, f = events[starts[0]], events[ends[0]]
            row.update(
                source_intervals=intervals.containing(s),
                destination_intervals=intervals.containing(f),
                host_ranges=ranges.containing(s),
                destination_ranges=ranges.containing(f),
            )
        row["destination_kind"] = destination_kind(row, events)
        joined.append(row)
    matched_by_range = defaultdict(list)
    for j, row in enumerate(joined):
        if row["status"] == "MATCHED":
            for index in row["host_ranges"]:
                matched_by_range[index].append(j)
    replays = []
    for i, e in enumerate(events):
        if e.get("ph") == "X" and e.get("name") in selected:
            role, manager_name = selected[e["name"]]
            enclosing = ranges.containing(e)
            managers = [j for j in enclosing if events[j].get("name") == manager_name
                        and stamp(e) + Decimal(str(e["dur"])) <= stamp(events[j]) + Decimal(str(events[j]["dur"]))]
            links = matched_by_range[i]
            managerlinks = matched_by_range[managers[0]] if len(managers) == 1 else []
            replays.append(
                dict(
                    event_index=i,
                    host_role=role,
                    source_range=e["name"],
                    manager_indices=managers,
                    manager_association="UNIQUE_SAME_THREAD_FULL_CONTAINMENT" if len(managers) == 1 else
                    "MISSING_OR_AMBIGUOUS_NO_MANAGER_FLOW_CLAIM",
                    direct_flow_indices=links,
                    replay_plus_update_flow_indices=managerlinks,
                    status="EXPLICIT_FLOW_ASSOCIATED" if links else "UNRESOLVED_ASSOCIATION",
                    association_scope="HOST_RANGE_ANY_FLOW_ONLY; legacy status is not model execution proof",
                    direct_flow_kinds=dict(Counter(joined[j]["destination_kind"] for j in links)),
                    update_vs_replay_kernel_split="UNRESOLVED",
                )
            )
    # A small fragment is chosen by the entire manager range and explicit flow
    # destinations, not the first N events. Full event indices remain traceable.
    fragment_indices = set()
    if replays:
        chosen = max(replays, key=lambda r: len(r["direct_flow_indices"]))
        hosts = chosen["manager_indices"] or [chosen["event_index"]]
        for h in hosts:
            event = events[h]
            lo = stamp(event)
            hi = lo + Decimal(str(event["dur"]))
            fragment_indices.update(
                i
                for i, e in enumerate(events)
                if "ts" in e
                and e.get("pid") == event.get("pid")
                and e.get("tid") == event.get("tid")
                and lo <= stamp(e) <= hi
            )
        for j in chosen["replay_plus_update_flow_indices"]:
            fragment_indices.update(joined[j]["event_indices"])
            fragment_indices.update(joined[j]["destination_intervals"])
    return dict(
        schema="repair6-flow-analysis-v1",
        event_count=len(events),
        ph=dict(Counter(e.get("ph") for e in events)),
        flow_counts=dict(counts),
        by_category={k: dict(v) for k, v in by_category.items()},
        flows=joined,
        replays=replays,
        replay_roles=list(replay_roles),
        coverage_by_role={role: dict(
            observed_Host_replay_ranges=sum(r["host_role"] == role for r in replays),
            any_direct_flow=sum(r["host_role"] == role and bool(r["direct_flow_indices"]) for r in replays),
            model_execution_context_flow=sum(r["host_role"] == role
                                            and "MODEL_EXECUTION_CONTEXT_FLOW" in r["direct_flow_kinds"]
                                            for r in replays),
            generation_bound_execution_flow="NOT_AVAILABLE_NO_NATIVE_OCCURRENCE_ID",
        ) for role in replay_roles},
        coverage=dict(total_replays=len(replays), direct_matched=sum(bool(r["direct_flow_indices"]) for r in replays)),
        coverage_contract="legacy direct_matched counts any matched flow starting in the Host replay range",
        classified_coverage=dict(
            any_flow_replays=sum(bool(r["direct_flow_indices"]) for r in replays),
            host_queue_event_flow_replays=sum("HOST_QUEUE_EVENT_FLOW" in r["direct_flow_kinds"] for r in replays),
            device_event_flow_replays=sum("DEVICE_EVENT_FLOW" in r["direct_flow_kinds"] for r in replays),
            model_execution_context_flow_replays=sum(
                "MODEL_EXECUTION_CONTEXT_FLOW" in r["direct_flow_kinds"] for r in replays
            ),
            generation_bound_execution_flow="NOT_AVAILABLE_NO_NATIVE_OCCURRENCE_ID",
        ),
        clock_contract="trace-export timestamps only; decimal microseconds; no Host monotonic_ns join",
        device_idle="NOT_ESTABLISHED; kernel-uncovered intervals are not whole-device idle",
        physical_read="NOT_EXPOSED_BY_AVAILABLE_EXPORT",
        task_operand="NOT_EXPOSED_BY_AVAILABLE_EXPORT",
        fragment=[dict(original_event_index=i, event=events[i]) for i in sorted(fragment_indices)],
    )


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--trace", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--replay-role", action="append", choices=("Draft", "Eagle_first", "Eagle_AR", "Target"),
                   help="Explicit Host role; repeat for multiple roles. Default preserves legacy parallel Draft scope.")
    a = p.parse_args()
    if a.trace.stat().st_size > 512 << 20:
        raise ValueError("BLOCKED_RESOURCE: JSON trace exceeds declared 512MiB parser limit")
    data = json.loads(a.trace.read_text())
    events = data["traceEvents"] if isinstance(data, dict) else data
    result = analyze(events, replay_roles=tuple(a.replay_role) if a.replay_role else ("Draft",))
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
