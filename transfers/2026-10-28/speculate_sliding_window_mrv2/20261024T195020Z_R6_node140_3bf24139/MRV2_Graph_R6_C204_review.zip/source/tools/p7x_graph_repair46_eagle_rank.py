# SPDX-License-Identifier: Apache-2.0
"""Named Eagle3 K3 TP2 real Graph anchor, never full numeric/Target acceptance.

Window OFF must establish the actual MRV2 Graph baseline before ON. The worker
uses its real rank, native model shards and first/AR managers. Observation is
CPU metadata and existing manager calls; no new device event/query/D2H/sync.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__=='__main__':
    sys.path[:]=[p for p in sys.path if Path(p or '.').resolve()!=Path(__file__).parent.resolve()]
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

import argparse
import hashlib
import json
import os
import socket
import struct
import time
import uuid
from types import SimpleNamespace

from tools.p7x_graph_repair21_rank import RankWorkerExtension, digest, require, validate_admission, write
from tools.p7x_graph_repair39_service_identity import host_worker_identity
from tools.p7x_graph_repair10_performance import request_metrics

GROUPS=(('short-one',(257,)),('long-three',(2051,771,387)),('short-after-long',(259,)))
SAMPLING=dict(temperature=0,seed=0,min_tokens=32,max_tokens=32,ignore_eos=True)
QWEN36_TARGET=Path('/mnt/share/weight/Qwen3.6-35B-A3B-w8a8')
QWEN36_DRAFT=Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/models/hf_drafts/specdrift-qwen3.6-35b-a3b-eagle3_cda3d86f3681_fc_norm_aux')
QWEN36_PROFILE='QWEN36_W8A8_EAGLE3_K3_FIRSTQ4_ARQ1_TP2_GRAPH_ANCHOR_V1'


def qwen36_identity():
    target,draft=QWEN36_TARGET/'config.json',QWEN36_DRAFT/'config.json'
    require(digest(target)=='93a4693fa9d8392fbfccd4b3c9873f4bfdcb14fdede978b123d07d19675efe99'
            and digest(draft)=='5b9242c2e8603da59527fb9e9dd85f3b5bf1e7beae48b251563bbd442a512c65',
            'fixed shared Qwen3.6 model configs changed')
    cfg=json.loads(draft.read_text())
    require(cfg['architectures']==['LlamaForCausalLMEagle3'] and cfg['num_hidden_layers']==1
            and cfg['hidden_size']==2048 and cfg['head_dim']==256 and cfg['num_key_value_heads']==2
            and cfg['dtype']=='bfloat16' and cfg['vocab_size']==248320 and cfg['fc_norm'] is True
            and cfg['eagle_aux_hidden_state_layer_ids']==cfg['eagle_config']['eagle_aux_hidden_state_layer_ids']==[3,19,35],
            'designated Eagle head/aux/normalization contract changed')
    weight=QWEN36_DRAFT/'model.safetensors'
    with weight.open('rb') as stream:
        size=struct.unpack('<Q',stream.read(8))[0]
        require(0<size<1<<20,'bounded weight header required')
        raw=stream.read(size)
    require(weight.stat().st_size==416819424 and len(raw)==size
            and hashlib.sha256(raw).hexdigest()=='a1c4e6c24a65b4fa4d24bf54237cc25629c2322a788675c9994c7cefc76a09df',
            'fixed Eagle shared weight/header identity changed')
    header=json.loads(raw)
    wanted={'fc.weight':[2048,6144],**{f'fc_norm.{i}.weight':[2048] for i in range(3)}}
    require(all(header[n]['shape']==shape and header[n]['dtype']=='BF16' for n,shape in wanted.items()),
            'Eagle auxiliary projection or individual norms missing')
    derivation=QWEN36_DRAFT/'DERIVATION.json'
    origin=json.loads(derivation.read_text())
    recorded_weight_sha=origin['weight_sha256_reused_from_verified_fc_norm_derivation']
    require(origin['derived_config_sha256']==digest(draft) and origin['weight_bytes']==weight.stat().st_size
            and recorded_weight_sha=='bdf7396fefab462074439e396c078e6060133c944187aedabb12ec8eddd51650',
            'recorded shared weight derivation identity changed')
    return dict(profile=QWEN36_PROFILE,method='eagle3',k=3,first_query=4,ar_query=1,ar_consumers=2,
        target=str(QWEN36_TARGET),draft=str(QWEN36_DRAFT),
        configs=[dict(path=str(p),realpath=str(p.resolve()),sha256=digest(p)) for p in (target,draft)],
        derivation=dict(path=str(derivation),sha256=digest(derivation)),
        weight=dict(path=str(weight),realpath=str(weight.resolve()),bytes=weight.stat().st_size,
                    header_sha256=hashlib.sha256(raw).hexdigest(),recorded_sha256=recorded_weight_sha,
                    full_hash='REUSED_PR_VERIFIED_IDENTITY_NOT_RECOMPUTED'),
        scope='Fixed shared pair/loader headers; actual all-rank Graph/outputs still require device evidence')


def qwen36_configuration(args):
    qwen36_identity()
    additional={} if args.arm=='G_OFF' else dict(draft_window_size=1024,draft_window_graph_replicated_tp_review=True)
    return dict(model=str(QWEN36_TARGET),tensor_parallel_size=2,data_parallel_size=1,enable_expert_parallel=True,
        distributed_executor_backend='mp',worker_extension_cls='tools.p7x_graph_repair46_eagle_rank.EagleRankWorker',
        speculative_config=dict(method='eagle3',model=str(QWEN36_DRAFT),num_speculative_tokens=3,
            draft_tensor_parallel_size=2,enforce_eager=False,enable_adaptive_verification=False),
        additional_config=additional,quantization='ascend',trust_remote_code=True,async_scheduling=False,
        enable_prefix_caching=False,compilation_config=dict(cudagraph_capture_sizes=[1,2,4,8,16],cudagraph_mode='FULL_DECODE_ONLY'),
        enforce_eager=False,gpu_memory_utilization=.6,max_model_len=4096,max_num_batched_tokens=4096,
        max_num_seqs=4,seed=0,disable_log_stats=True)


def configuration(args):
    require(args.arm in ('G_OFF','G_ON') and type(args.tp) is int and args.tp==2,
            'named Eagle K3 TP2 OFF/ON anchor only; no TP or eager substitution')
    if getattr(args,'qwen36_model_pair',False):
        return None,qwen36_configuration(args)
    from tools.p7x_graph_repair34_method_perf import configuration as method_configuration
    fields=dict(vars(args));fields.update(method='eagle3',max_model_len=4096,
        eagle3_pinned_h2d_review=False,pinned_pair_variant=None,native_long_context_review=False)
    _,fixture,kwargs=method_configuration(SimpleNamespace(**fields))
    kwargs['tensor_parallel_size']=2
    kwargs['speculative_config']['draft_tensor_parallel_size']=2
    if args.arm=='G_ON':kwargs['additional_config']['draft_window_graph_replicated_tp_review']=True
    kwargs['worker_extension_cls']='tools.p7x_graph_repair46_eagle_rank.EagleRankWorker'
    require(kwargs['speculative_config']['num_speculative_tokens']==3
            and kwargs['speculative_config']['enforce_eager'] is False and kwargs['enforce_eager'] is False,
            'actual static Graph method differs')
    return fixture,kwargs


class EagleRankWorker(RankWorkerExtension):
    def mrv2_eagle_rank_identity(self,nonce):
        # Outside request generation/capture callbacks; source headers only.
        row=host_worker_identity(self,nonce)
        spec=self.model_runner.speculator
        require(spec.method=='eagle3','another speculative method loaded')
        context=spec.draft_vllm_config.compilation_config.static_forward_context
        layers=sorted(spec.draft_attn_layer_names)
        require(set(layers)<=set(context),'actual Eagle private layer context missing')
        import torch
        geometry={}
        for name in layers:
            value=context[name].kv_cache
            # Do not slice/unbind a device Tensor just to inspect its headers.
            values=[value] if isinstance(value,torch.Tensor) else list(value)
            geometry[name]=[dict(shape=list(t.shape),stride=list(t.stride()),dtype=str(t.dtype),
                storage_offset=t.storage_offset(),data_ptr=t.data_ptr(),device=str(t.device)) for t in values]
        parallel=self.vllm_config.parallel_config
        draft_parallel=spec.draft_vllm_config.parallel_config
        runtime=getattr(spec,'_draft_window_runtime_state',None)
        topology=None if runtime is None else runtime.capability.eager_topology_fingerprint
        row.update(rank=self.rank,local_rank=self.local_rank,world_size=parallel.world_size,
            tp_size=parallel.tensor_parallel_size,draft_tp_size=draft_parallel.tensor_parallel_size,
            nspid=next(line.split()[1:] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('NSpid:')),
            logical_device=self.device.index,visible=os.environ.get('ASCEND_RT_VISIBLE_DEVICES'),
            draft_model=str(spec.draft_model_config.model),
            draft_backend=spec.attn_backend.__module__+'.'+spec.attn_backend.__qualname__,
            draft_layers=layers,draft_kv_geometry=geometry,
            normalized_kv_heads=spec.draft_model_config.get_num_kv_heads(draft_parallel),
            head_size=spec.draft_model_config.get_head_size(),
            topology=None if topology is None else dict(tp_size=topology.tensor_parallel_size,
                tp_rank=topology.tensor_parallel_rank,read_semantics=topology.parallel_read_semantics,
                graph_mode=topology.graph_mode),
            dispatch_records=list(getattr(self,'_mrv2_rank_replay_records',[])),
            window_generations=list(getattr(self,'_mrv2_rank_window_generations',[])),
            window_graph_bindings=list(getattr(self,'_mrv2_rank_window_bindings',[])),
            numeric_capture_enabled=getattr(getattr(spec,'_eagle3_graph_session',None),'numeric_snapshots',None) is not None,
            provider_observer_enabled=getattr(getattr(spec,'_draft_window_graph_binding_provider',None),'observer',None) is not None,
            submission_uncertain=bool(getattr(spec,'_draft_window_graph_submission_uncertain',False)),
            scope='ACTUAL_EAGLE_TP2_HOST_SOURCE_KV_HEADERS_AND_MANAGER_CALLS_NOT_COMPLETION_OR_OPERAND')
        if str(spec.draft_model_config.model)==str(QWEN36_DRAFT):
            from vllm.v1.worker.gpu.spec_decode.eagle.eagle3_utils import get_eagle3_aux_layers_from_config
            model=spec.model.model
            row['qwen36_loaded_pair']=dict(profile=QWEN36_PROFILE,target=self.vllm_config.model_config.model,
                draft=str(spec.draft_model_config.model),aux_layers=list(get_eagle3_aux_layers_from_config(spec.speculative_config)),
                fc_shape=list(model.fc.weight.shape),fc_norm_shapes=[list(norm.weight.shape) for norm in model.fc_norm])
        return row


def validate_ranks(rows,*,arm,nonce,source,pin,after,qwen36=False,numeric_diagnostic=False):
    require(arm in ('G_OFF','G_ON') and type(after) is bool,'named rank check')
    require(type(numeric_diagnostic) is bool and (not numeric_diagnostic or qwen36 and arm=='G_ON'),
            'numeric capture admission is a separate designated Window ON diagnostic')
    require(type(nonce) is str and len(nonce)==32 and all(c in '0123456789abcdef' for c in nonce),
            'exact request nonce required')
    require(isinstance(rows,list) and len(rows)==2 and sorted(x['rank'] for x in rows)==[0,1]
            and all(type(x['rank']) is int for x in rows),'complete two actual ranks required')
    require(len({(x['pid'],x['process_start_ticks']) for x in rows})==2,'rank PID/starttime reused')
    for row in rows:
        require(row['nonce']==nonce and all(type(row[k]) is int and row[k]==2
            for k in ['world_size','tp_size','draft_tp_size']),'rank/world/Draft TP contract differs')
        require(type(row['pid']) is int and row['pid']>0 and str(row['process_start_ticks']).isdigit()
            and row['hostname']==socket.gethostname() and row['boot_id']==Path('/proc/sys/kernel/random/boot_id').read_text().strip()
            and row['namespace']==os.readlink('/proc/self/ns/mnt'),'actual process/host context differs')
        require(type(row['logical_device']) is int and row['logical_device'] in (0,1)
            and type(row['local_rank']) is int and row['local_rank']==row['rank']
            and row['nspid'] and str(row['nspid'][-1])==str(row['pid']),
            'single-host logical rank/PID identity differs')
        require(row['speculator_class']=='vllm_ascend.worker.v2.spec_decode.eagle.speculator.AscendEagleSpeculator'
            and row['actual_method']=='eagle3' and type(row['actual_k']) is int and row['actual_k']==3,
            'actual method/K differs')
        require(row['heavy_observer_enabled'] is numeric_diagnostic and row['submission_uncertain'] is False
            and row['provider_installed'] is (arm=='G_ON'),'observer/safety-provider or uncertainty differs')
        if numeric_diagnostic:
            require(row.get('numeric_capture_enabled') is True and row.get('provider_observer_enabled') is False,
                    'numeric snapshots required separately from forbidden provider observer')
        kv_heads,head_size=(1,256) if qwen36 else (4,128)
        require(row['draft_backend']=='vllm_ascend.attention.attention_v1.AscendAttentionBackend'
            and row['draft_layers'] and set(row['draft_layers'])==set(row['draft_kv_geometry'])
            and type(row['normalized_kv_heads']) is int and row['normalized_kv_heads']==kv_heads
            and row['head_size']==head_size,'actual rank-local dense backend/KV heads differ')
        if qwen36:
            require(len(row['draft_layers'])==1 and row['draft_model']==str(QWEN36_DRAFT)
                and row['qwen36_loaded_pair']==dict(profile=QWEN36_PROFILE,target=str(QWEN36_TARGET),draft=str(QWEN36_DRAFT),
                    aux_layers=[3,19,35],fc_shape=[2048,6144],fc_norm_shapes=[[2048]]*3),
                'actual Qwen3.6 Eagle pair/aux/projection/norms differ')
        for layer,headers in row['draft_kv_geometry'].items():
            require(headers and all(h['dtype']=='torch.bfloat16' and h['shape'] and h['stride']
                and type(h['data_ptr']) is int and h['data_ptr']>0 for h in headers),'KV metadata missing')
            for header in headers:
                shape=header['shape']
                require(all(type(n) is int and n>0 for n in shape)
                    and ((len(shape)==5 and shape[0]==2 and shape[2:]==[128,kv_heads,head_size])
                         or (len(shape)==4 and shape[1:]==[128,kv_heads,head_size]))
                    and len(header['stride'])==len(shape)
                    and type(header['storage_offset']) is int and header['storage_offset']>=0
                    and header['device']=='npu:'+str(row['logical_device']),
                    'rank-local KV shape/device differs from named model shard')
        modules={entry['module']:entry for entry in row['modules']}
        require(len(modules)==len(row['modules']) and {'vllm','vllm_ascend'}<=modules.keys()
            and all(row[key].rsplit('.',1)[0] in modules
                for key in ['worker_class','runner_class','speculator_class']),
            'required actual worker modules missing or repeated')
        require(any(str(Path(source).resolve()) in path and 'vllm_ascend_C' in path
            for path in row['loaded_native']),'candidate native extension not loaded')
        for entry in modules.values():
            require(entry['module'].startswith(('vllm.','vllm_ascend.','tools.'))
                or entry['module'] in ('vllm','vllm_ascend'),'unknown module namespace')
            base=Path(pin if entry['module']=='vllm' or entry['module'].startswith('vllm.') else source).resolve()
            path=Path(entry['path'])
            require(path.is_absolute() and path.resolve().is_relative_to(base)
                and type(entry['bytes']) is int and path.stat().st_size==entry['bytes'] and digest(path)==entry['sha256'],
                'actual rank imports another source')
        for name in ['target','prefill_cudagraph_manager','decode_cudagraph_manager']:
            require(row['graph_inventory'][name]['graphs'],'actual Target/first/AR capture missing')
        if qwen36:
            for name,width in [('prefill_cudagraph_manager',4),('decode_cudagraph_manager',1)]:
                inventory={(d['num_reqs'],d['num_tokens']) for d in row['graph_inventory'][name]['graphs'] if d['mode']=='FULL'}
                require({(n,n*width) for n in (1,2,4)}<=inventory,
                        'named first-pass or AR capture buckets missing')
        if arm=='G_ON':
            require(row['topology']==dict(tp_size=2,tp_rank=row['rank'],read_semantics='replicated',
                graph_mode='FULL_DECODE_ONLY'),'P2 topology replaced or logical lengths partitioned')
            for binding in row['latest_provider_bindings']:
                require(type(binding['ordinal']) is int and binding['ordinal'] in (0,1),'invalid AR ordinal')
            if after:
                require(row['window_generations'] and row['window_graph_bindings'],'actual Window materialize/bind absent')
                require(all(g['tp_size']==2 and g['tp_rank']==row['rank'] for g in row['window_generations']),
                    'runtime source rank changed')
                require(all(g['tp_size']==2 and g['tp_rank']==row['rank'] for g in row['window_graph_bindings']),
                    'capture/runtime binding rank changed')
        if after:
            calls=row['dispatch_records']
            for role in ['target','draft:prefill_cudagraph_manager','draft:decode_cudagraph_manager']:
                require(any(c['role']==role and c['mode']=='FULL' and c['returned'] is True
                    for c in calls),'actual full Graph manager call absent: '+role)
    if arm=='G_ON' and after:
        def logical(row):
            return [{k:g[k] for k in ['global_group_id','requests','actual','padded','window_starts','exact']}
                    for g in row['window_generations']]
        # Generation counters are rank-local namespaces. Compare explicit
        # ordered business identities and values, not bare counter equality.
        require(logical(rows[0])==logical(rows[1]),'replicated logical read views disagree between actual ranks')
    require(len({row['logical_device'] for row in rows})==2,'logical devices reused across ranks')
    return dict(status='PASS_SCOPED_EAGLE_TP2_HOST_RANK_AND_DISPATCH_ANCHOR',ranks=[0,1],
        scope='Headers/owned CPU state/actual manager call records only; not independent numeric/TargetKV, native operand or completion')


def validate_request_metrics(metric, *, allow_unavailable=False):
    """The V2 RequestOutput can omit metrics; never infer acceptance from tokens.

    This exception applies only to the named request/Graph anchor, not to a
    performance or acceptance verdict. A present counter still has to satisfy
    the original numerical counter contract, and the legacy fixture requires it.
    """
    from tools.p7x_graph_repair13_eagle import counts

    require(isinstance(metric, dict) and metric.get('finished') is True,
            'framework metrics request unfinished')
    require('speculative_decoding' in metric, 'missing explicit metric availability')
    value = metric['speculative_decoding']
    if value is None:
        require(allow_unavailable and metric.get('timing') is None
                and metric.get('unavailable_reason') == 'PINNED_RESPONSE_METRICS_NOT_PRESENT',
                'unexplained or required speculative metrics missing')
        return 'NOT_AVAILABLE_PINNED_REQUEST_OUTPUT'
    counts(value)
    return 'AVAILABLE_VALIDATED'


def validate_saved(campaign,execution,*,args,source,pin,admission,request_plan=GROUPS,
                   kwargs_factory=configuration,entrypoint_name='p7x_graph_repair46_eagle_rank.py',
                   numeric_diagnostic=False):
    """Recompute method/config/complete request/rank contracts from saved data.

    The external runner must additionally join every worker to fresh device
    observations and verify clean source, runtime, lease and artifact hashes.
    A producer's embedded check result is deliberately ignored here.
    """
    require(execution['returncode']==0 and execution['signal'] is None and execution['timeout'] is False,
            'actual model execution failed or unfinished')
    require(campaign['pid']==execution['pid'] and campaign['start_ticks']==execution['start_ticks']
            and execution['start_epoch']<=campaign['started_at']<campaign['ended_at']<=execution['end_epoch'],
            'campaign/actual parent lifetime differs')
    require(campaign['status']=='ALL_TWO_RANK_EAGLE_REQUEST_ANCHOR_COMPLETE_NOT_NUMERIC_VALIDATION'
            and campaign['tp']==2 and campaign['arm']==args.arm
            and campaign['source_sha']==admission['source_sha']==args.expected_sha
            and campaign['source_tree']==admission['source_tree'], 'method/source/result differs')
    _,kwargs=kwargs_factory(args)
    require(campaign['kwargs']==kwargs and campaign['config_sha256']==hashlib.sha256(
            json.dumps(kwargs,sort_keys=True).encode()).hexdigest() and campaign['sampling']==SAMPLING,
            'actual configuration/sampling changed')
    qwen36=getattr(args,'qwen36_model_pair',False)
    if qwen36:
        require(campaign['profile_identity']==qwen36_identity() and campaign['qwen36_model_pair'] is True
                and campaign['fixture_sha256'] is campaign['fixture_receipt_sha256'] is None,
                'fixed Qwen3.6 source/model identity differs')
    else:
        require(campaign['fixture_sha256']==digest(args.fixture)
                and campaign['fixture_receipt_sha256']==digest(args.fixture_receipt),'predeclared fixture changed')
    require(campaign['admission_sha256']==digest(args.admission)
            and campaign['script_sha256']==digest(Path(source)/'tools'/entrypoint_name),
            'predeclared input/tool changed')
    before=campaign['before']
    validate_ranks(before['ranks'],arm=args.arm,nonce=before['nonce'],source=source,pin=pin,after=False,
                   qwen36=qwen36,numeric_diagnostic=numeric_diagnostic)
    identities=sorted((r['rank'],r['pid'],r['process_start_ticks']) for r in before['ranks'])
    require(len(campaign['requests'])==len(request_plan),'incomplete declared request groups')
    require(len({before['nonce'],*(row['nonce'] for row in campaign['requests'])})==len(request_plan)+1,
            'worker RPC nonce reused between phases')
    metric_availability = []
    for row,(label,lengths) in zip(campaign['requests'],request_plan):
        require(row['label']==label and row['start_ns']<row['end_ns']
            and row['prompts']==[dict(prompt_token_ids=[100+i]*n) for i,n in enumerate(lengths)],
            'request input/phase differs')
        require(len(row['token_ids'])==len(row['finished'])==len(row['metrics'])==len(lengths)
            and all(v is True for v in row['finished'])
            and all(len(ids)==32 and all(type(t) is int and t>=0 for t in ids) for ids in row['token_ids']),
            'completed output/typed token coverage differs')
        for metric in row['metrics']:
            metric_availability.append(validate_request_metrics(metric, allow_unavailable=qwen36))
        validate_ranks(row['ranks'],arm=args.arm,nonce=row['nonce'],source=source,pin=pin,after=True,
                       qwen36=qwen36,numeric_diagnostic=numeric_diagnostic)
        require(sorted((r['rank'],r['pid'],r['process_start_ticks']) for r in row['ranks'])==identities,
            'worker changed between request groups')
    require(all(left['end_ns']<right['start_ns'] for left,right in
        zip(campaign['requests'],campaign['requests'][1:])), 'request group intervals overlap or reorder')
    if args.arm=='G_ON':
        require(all(any(any(start>0 for start in item['window_starts']) for item in r['window_generations'])
            for r in campaign['requests'][-1]['ranks']),'no actual clipped generation')
    return dict(status='PASS_SCOPED_TWO_RANK_EAGLE_REQUEST_AND_HOST_DISPATCH',ranks=[0,1],
        request_metric_availability=metric_availability,
        acceptance='NOT_ASSESSED_BY_REQUEST_GRAPH_ANCHOR',
        numeric='NOT_ASSESSED',target_kv='NOT_ASSESSED',normal_completion='NOT_INFERRED',
        execution_operand='NOT_PROVEN',physical_read='NOT_PROVEN')


def run(args):
    source=Path(__file__).resolve().parents[1]
    admission=validate_admission(args.admission,source=source,sha=args.expected_sha,tp=2)
    require(not args.output.exists(),'new fixed rank anchor attempt required')
    fixture,kwargs=configuration(args)
    qwen36=getattr(args,'qwen36_model_pair',False)
    if not qwen36:
        from tools.p7x_graph_repair12_contract import verify_fixture_receipt
        verify_fixture_receipt(SimpleNamespace(repair12_fixture_verification=args.fixture_receipt,
            repair12_fixture_verification_sha256=args.fixture_receipt_sha256,expected_sha=args.expected_sha,
            fixture_manifest=args.fixture),fixture)
    args.output.mkdir(parents=True)
    record=dict(status='STARTING',source_sha=args.expected_sha,source_tree=admission['source_tree'],
        script_sha256=digest(__file__),pid=os.getpid(),
        start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],
        started_at=time.time(),arm=args.arm,tp=2,sampling=dict(SAMPLING),
        kwargs=kwargs,config_sha256=hashlib.sha256(json.dumps(kwargs,sort_keys=True).encode()).hexdigest(),
        fixture_sha256=None if qwen36 else digest(args.fixture),
        fixture_receipt_sha256=None if qwen36 else digest(args.fixture_receipt),
        admission_sha256=digest(args.admission),requests=[],native_completion='NOT_PROVEN',
        scope='NAMED_METHOD_RANK_ANCHOR_ONLY_NOT_FULL_NUMERIC_TARGET_OR_PERFORMANCE_ACCEPTANCE')
    if qwen36:record.update(qwen36_model_pair=True,profile_identity=qwen36_identity())
    write(args.output/'campaign.json',record);llm=None
    try:
        import torch_npu  # noqa:F401
        import vllm_ascend.ops  # noqa:F401
        import vllm_ascend.worker.v2.spec_decode  # noqa:F401
        from vllm import LLM,SamplingParams
        llm=LLM(**kwargs);record['startup_complete']=True
        record['installed_observers']=llm.collective_rpc('mrv2_rank_install_dispatch_observer',timeout=90)
        nonce=uuid.uuid4().hex;before=llm.collective_rpc('mrv2_eagle_rank_identity',timeout=90,args=(nonce,))
        validate_ranks(before,arm=args.arm,nonce=nonce,source=source,pin=args.vllm_repo,after=False,qwen36=qwen36)
        record['before']=dict(nonce=nonce,ranks=before)
        for label,lengths in GROUPS:
            prompts=[dict(prompt_token_ids=[100+i]*n) for i,n in enumerate(lengths)]
            start=time.monotonic_ns()
            output=llm.generate(prompts,SamplingParams(**SAMPLING),use_tqdm=False)
            require(len(output)==len(prompts) and all(x.finished and len(x.outputs[0].token_ids)==32
                for x in output),'bounded request did not finish')
            nonce=uuid.uuid4().hex;ranks=llm.collective_rpc('mrv2_eagle_rank_identity',timeout=90,args=(nonce,))
            checked=validate_ranks(ranks,arm=args.arm,nonce=nonce,source=source,pin=args.vllm_repo,after=True,qwen36=qwen36)
            record['requests'].append(dict(label=label,prompts=prompts,start_ns=start,end_ns=time.monotonic_ns(),
                token_ids=[list(x.outputs[0].token_ids) for x in output],finished=[x.finished for x in output],
                metrics=request_metrics(output),nonce=nonce,ranks=ranks,check=checked))
            write(args.output/'campaign.json',record)
        if args.arm=='G_ON':
            require(all(any(any(start>0 for start in item['window_starts']) for item in row['window_generations'])
                for row in record['requests'][-1]['ranks']),'no actual clipped generation observed')
        record['status']='ALL_TWO_RANK_EAGLE_REQUEST_ANCHOR_COMPLETE_NOT_NUMERIC_VALIDATION'
    except BaseException as error:
        import traceback
        record.update(status='EXCEPTION_ISOLATION_REQUIRED',exception_type=type(error).__name__,
            exception_message=str(error),traceback=traceback.format_exc(),unknown_native_submission=llm is not None,
            post_error_device_operations='NONE_BY_THIS_PARENT')
        write(args.output/'campaign.json',record)
        # No second worker RPC, synchronization, restore or suspicious reuse.
        os._exit(74)
    record['ended_at']=time.time();write(args.output/'campaign.json',record)
    try:llm.llm_engine.engine_core.shutdown()
    except BaseException as error:
        record['cleanup_error']=repr(error);write(args.output/'campaign.json',record);return 2
    return 0


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--arm',choices=['G_OFF','G_ON'],required=True);p.add_argument('--tp',type=int,choices=[2],required=True)
    p.add_argument('--qwen36-model-pair',action='store_true',help='Fixed shared Qwen3.6/fc_norm pair; never substitutes the legacy fixture')
    for key in ['admission','vllm-repo','output']:p.add_argument('--'+key,type=Path,required=True)
    for key in ['fixture','fixture-receipt']:p.add_argument('--'+key,type=Path)
    for key in ['expected-sha','run-id','case-id']:p.add_argument('--'+key,required=True)
    for key in ['fixture-sha256','fixture-receipt-sha256']:p.add_argument('--'+key)
    args=p.parse_args()
    require(args.qwen36_model_pair or all(getattr(args,key) is not None for key in
        ('fixture','fixture_receipt','fixture_sha256','fixture_receipt_sha256')),
        'legacy route still requires complete fixed fixture and verification receipt')
    return run(args)

if __name__=='__main__':raise SystemExit(main())
