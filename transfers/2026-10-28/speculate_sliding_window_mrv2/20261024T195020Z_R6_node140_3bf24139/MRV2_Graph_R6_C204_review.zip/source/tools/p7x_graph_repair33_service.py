# SPDX-License-Identifier: Apache-2.0
"""Bounded real official serve/HTTP review; no private model-driver injection.

The client retains actual SSE token-ID deltas, usage and one monotonic clock.
TTFT is first nonempty token delivery. Mean TPOT uses first/last token delivery;
inter-chunk intervals are not a per-token ITL distribution. This is a service
entry/request test, not continuous numerical or last-consumer completion proof.
"""
from __future__ import annotations

# Remove the executable tools/ directory before any standard-library module
# can import random -> bisect. tools/bisect is a local package, not stdlib.
from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import asyncio
import json
import os
import subprocess
import time
import urllib.error
import urllib.request
import uuid

from tools.p7x_graph_repair21_rank import digest, require, validate_admission, write


def serve_argv(python, port, model_name, arm, *, worker_provenance=False):
    require(type(port) is int and 1024 <= port <= 65535 and arm in ("G_OFF", "G_ON", "E_ON"), "service profile")
    require(type(worker_provenance) is bool, "explicit Host provenance boolean required")
    speculative = dict(method="dspark", model="/mnt/share/dspark_qwen3_8b_block7", num_speculative_tokens=7,
                       enforce_eager=arm == "E_ON", enable_adaptive_verification=False)
    additional = {} if arm == "G_OFF" else dict(draft_window_size=1024)
    argv = [python, "-m", "vllm.entrypoints.cli.main", "serve", "/mnt/share/wql/Qwen3-8B",
            "--host", "127.0.0.1", "--port", str(port), "--served-model-name", model_name,
            "--tensor-parallel-size", "1", "--max-model-len", "24576", "--max-num-seqs", "4",
            "--max-num-batched-tokens", "4096", "--block-size", "128", "--gpu-memory-utilization", "0.6",
            "--seed", "0", "--no-async-scheduling", "--no-enable-prefix-caching",
            "--speculative-config", json.dumps(speculative, sort_keys=True),
            "--compilation-config", json.dumps(dict(cudagraph_capture_sizes=[7,14,28,32],
                                                     cudagraph_mode="FULL_DECODE_ONLY"), sort_keys=True),
            "--additional-config", json.dumps(additional, sort_keys=True)]
    if worker_provenance:
        argv += ["--worker-extension-cls", "tools.p7x_graph_repair39_service_identity.ServiceWorkerIdentity"]
    return argv


def worker_identity_rpc(base, nonce):
    body = json.dumps(dict(method="mrv2_service_worker_identity", args=[nonce], timeout=30)).encode()
    req = urllib.request.Request(base + "/collective_rpc", data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=40) as response:
        require(response.status == 200, "Host worker identity RPC failed")
        return json.load(response)["results"]


def stream_summary(events, *, start_ns, end_ns, expected_prompt, expected_output, expected_model=None):
    ids, first, last, usage, intervals, prior = [], None, None, None, [], None
    prompt_seen, response_id = None, None
    for event in events:
        at, value = event["received_ns"], event["data"]
        require(type(at) is int and start_ns <= at <= end_ns and (prior is None or at >= prior),
                "client time-domain/order mismatch")
        prior = at
        require("error" not in value, "server returned a streamed error")
        require(isinstance(value.get("id"),str) and bool(value["id"]), "actual response identity missing")
        if response_id is None:response_id=value["id"]
        require(value["id"] == response_id, "mixed HTTP response chunks")
        require(expected_model is None or value.get("model") == expected_model, "response model identity differs")
        if value.get("usage") is not None:
            require(usage is None, "duplicate terminal usage")
            usage = value["usage"]
        for choice in value.get("choices", []):
            require(type(choice["index"]) is int and choice["index"] == 0, "single-output service contract")
            if choice.get("prompt_token_ids") is not None:
                require(prompt_seen is None, "duplicate prompt identity")
                prompt_seen = choice["prompt_token_ids"]
            delta = choice.get("token_ids")
            require(delta is None or isinstance(delta, list) and all(type(x) is int and x >= 0 for x in delta),
                    "actual token-ID delta required")
            if delta:
                if first is None: first = at
                if last is not None: intervals.append(dict(interval_ns=at-last, delivered_tokens=len(delta)))
                last = at
                ids.extend(delta)
    require(prompt_seen == expected_prompt and len(ids) == expected_output and first is not None and usage is not None,
            "missing actual prompt/token deltas or terminal usage")
    require(all(type(usage[k]) is int and usage[k] >= 0 for k in ("prompt_tokens","completion_tokens","total_tokens")),
            "usage counts must be exact integers")
    require(usage["prompt_tokens"] == len(expected_prompt) and usage["completion_tokens"] == len(ids)
            and usage["total_tokens"] == len(expected_prompt)+len(ids), "usage/token identity contradiction")
    return dict(response_id=response_id,token_ids=ids, usage=usage, elapsed_seconds=(end_ns-start_ns)/1e9,
                ttft_seconds=(first-start_ns)/1e9,
                mean_tpot_seconds=(last-first)/(len(ids)-1)/1e9 if len(ids)>1 else None,
                tpot_definition="Client first-to-last nonempty token delivery span / (actual generated tokens-1)",
                token_itl_distribution="NOT_AVAILABLE_MULTIPLE_TOKENS_MAY_SHARE_SSE_CHUNK",
                observed_inter_chunk_intervals=intervals,
                timestamp_scope="One client monotonic clock; no Host/device clock subtraction")


async def request(session, url, *, model, prompt, output, failure_path=None, data_parallel_rank=None, cache_salt=None):
    from vllm.benchmarks.lib.endpoint_request_func import StreamedResponseHandler
    body = dict(model=model, prompt=prompt, temperature=0, seed=0, max_tokens=output, min_tokens=output,
                ignore_eos=True, stream=True, stream_options=dict(include_usage=True), return_token_ids=True)
    if cache_salt is not None:
        require(isinstance(cache_salt,str) and 0<len(cache_salt)<=128,'bounded explicit cache salt required')
        body['cache_salt']=cache_salt
    routed = {}
    if data_parallel_rank is not None:
        require(type(data_parallel_rank) is int and data_parallel_rank in (0, 1),
                "explicit reviewed DP replica required")
        routed['headers'] = {'X-data-parallel-rank': str(data_parallel_rank)}
    started = time.monotonic_ns()
    events, done = [], False
    try:
        async with session.post(url, json=body, **routed) as response:
            # Error arguments are evaluated even when require() succeeds.
            # Reading text here for HTTP200 would consume the entire SSE body
            # before iter_any(), losing both token timestamps and [DONE].
            if response.status != 200:
                raise ValueError(f"HTTP completion status {response.status}: {(await response.text())[:1000]}")
            handler = StreamedResponseHandler()
            async for chunk in response.content.iter_any():
                for message in handler.add_chunk(chunk):
                    if message.startswith(":"): continue
                    data = message.removeprefix("data: ")
                    if data == "[DONE]": done=True;continue
                    events.append(dict(received_ns=time.monotonic_ns(), data=json.loads(data)))
        ended = time.monotonic_ns()
        require(done, "stream lacks DONE terminal event")
        result = dict(request=body, start_ns=started, end_ns=ended, events=events, terminal_done=done,
                      summary=stream_summary(events, start_ns=started, end_ns=ended,
                                             expected_prompt=prompt, expected_output=output, expected_model=model))
        if routed:
            result['routing_headers'] = routed['headers']
        return result
    except BaseException as error:
        if failure_path is not None:
            # Only after a failed request; no file I/O in successful SSE receive
            # iterations or the model hot path. This is partial client evidence.
            write(failure_path, dict(status="FAILED_PARTIAL_CLIENT_EVENTS", request=body,
                  start_ns=started, end_ns=time.monotonic_ns(), events=events, terminal_done=done,
                  exception_type=type(error).__name__, exception_message=str(error)))
        raise


async def client_groups(base, model, groups, output):
    import aiohttp
    rows=[]
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=240)) as session:
        for phase in ("warmup", "measured"):
            for group_index,group in enumerate(groups):
                start=time.monotonic_ns()
                results=await asyncio.gather(*[request(session,base+"/v1/completions",model=model,
                    prompt=p["prompt_token_ids"],output=group["max_tokens"],
                    failure_path=output/f"failed-{phase}-group{group_index}-request{index}.json")
                    for index,p in enumerate(group["prompts"])])
                row=dict(phase=phase,label=group["label"],group_start_ns=start,group_end_ns=time.monotonic_ns(),results=results)
                rows.append(row);write(output/"requests.json",dict(groups=rows,status="IN_PROGRESS"))
    return rows



def validate_requests(campaign, document, groups, *, expected_server_argv,
                      expected_source=None, expected_vllm_source=None,
                      worker_identity_validator=None,
                      worker_extension_cls='tools.p7x_graph_repair39_service_identity.ServiceWorkerIdentity'):
    require(campaign["status"] == "OFFICIAL_CLI_HTTP_REQUESTS_COMPLETE_NOT_NUMERIC_OR_COMPLETION_PROOF"
            and campaign["server_rc"] in (0, -15) and campaign["server_argv"] == expected_server_argv,
            "official server did not complete the exact declared profile/cleanup")
    require(document["status"] == "COMPLETE" and len(document["groups"]) == 2*len(groups),
            "incomplete warmup/measured group collection")
    count=0
    response_ids=set()
    previous_end=campaign["start_monotonic_ns"]
    model=expected_server_argv[expected_server_argv.index("--served-model-name")+1]
    for row,(phase,group) in zip(document["groups"],[(p,g) for p in ("warmup","measured") for g in groups]):
        require(row["phase"] == phase and row["label"] == group["label"]
                and len(row["results"]) == len(group["prompts"]), "group phase/request coverage differs")
        require(previous_end <= row["group_start_ns"] < row["group_end_ns"] <= campaign["end_monotonic_ns"],
                "old/cross-invocation client group time")
        previous_end=row["group_end_ns"]
        for result,prompt in zip(row["results"],group["prompts"]):
            require(result.get("terminal_done") is True, "actual SSE terminal event missing")
            body=result["request"]
            require(body["model"] == model and body["prompt"] == prompt["prompt_token_ids"] and body["max_tokens"] == body["min_tokens"] == group["max_tokens"]
                    and body["temperature"] == body["seed"] == 0 and body["ignore_eos"] is True
                    and body["stream"] is True and body["return_token_ids"] is True,
                    "actual HTTP request differs from fixed input/sampling/output contract")
            require(row["group_start_ns"] <= result["start_ns"] < result["end_ns"] <= row["group_end_ns"],
                    "request timestamps outside declared client group")
            summary=stream_summary(result["events"],start_ns=result["start_ns"],end_ns=result["end_ns"],
                                   expected_prompt=prompt["prompt_token_ids"],expected_output=group["max_tokens"],expected_model=model)
            require(summary["response_id"] not in response_ids,"cross-request response identity reused")
            response_ids.add(summary["response_id"])
            require(summary == result["summary"], "producer summary contradicts original token/usage/timestamp events")
            if phase=="measured":count+=1
    require(count == campaign["measured_requests"], "actual measured request count differs")
    provenance_enabled = campaign.get("worker_provenance_enabled", False)
    require(type(provenance_enabled) is bool, "typed provenance mode required")
    if provenance_enabled:
        from tools.p7x_graph_repair39_service_identity import validate_worker_identity
        require(expected_source is not None and expected_vllm_source is not None
                and Path(campaign['source_root']).resolve() == Path(expected_source).resolve()
                and Path(campaign['vllm_source_root']).resolve() == Path(expected_vllm_source).resolve(),
                "worker source must be bound outside producer claims")
        require('--worker-extension-cls' in expected_server_argv
                and expected_server_argv[expected_server_argv.index('--worker-extension-cls')+1]
                == worker_extension_cls,
                "undeclared Host observation extension")
        states = campaign["worker_provenance"]
        require(len(states) == 2 and [s['phase'] for s in states] == ['BEFORE_REQUESTS', 'AFTER_REQUESTS'],
                "complete out-of-request Host observations required")
        first_group, last_group = document['groups'][0], document['groups'][-1]
        require(campaign['start_monotonic_ns'] <= states[0]['start_ns'] < states[0]['end_ns']
                <= first_group['group_start_ns'] and last_group['group_end_ns']
                <= states[1]['start_ns'] < states[1]['end_ns'] <= campaign['end_monotonic_ns'],
                "Host identity query overlaps measured HTTP groups or belongs to another invocation")
        validator = validate_worker_identity if worker_identity_validator is None else worker_identity_validator
        identities = [validator(s['results'], nonce=s['nonce'], source=expected_source,
                      vllm_source=expected_vllm_source, arm=campaign['arm']) for s in states]
        require(identities[0] == identities[1], "worker changed across service requests")
    return dict(status="PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS",measured_requests=count,
                dispatch="NOT_INFERRED_FROM_HTTP_SUCCESS",numeric="NOT_ASSESSED",normal_completion="NOT_PROVEN",
                token_itl="NOT_AVAILABLE_SSE_BURSTS")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest="command",required=True)
    run=commands.add_parser("run")
    for name in ("admission","output","requests"):
        run.add_argument("--"+name,type=Path,required=True)
    run.add_argument("--expected-sha",required=True)
    run.add_argument("--arm",choices=("G_OFF","G_ON","E_ON"),required=True)
    run.add_argument("--port",type=int,required=True)
    run.add_argument("--worker-provenance", action="store_true",
                     help="Separate Host-only extension/RPC arm outside measured HTTP groups; default OFF")
    check=commands.add_parser("check")
    for name in ("campaign","requests","records","server-argv","output"):
        check.add_argument("--"+name,type=Path,required=True)
    args=parser.parse_args();source=Path(__file__).resolve().parents[1]
    if args.command == "check":
        result=dict(status="INVALID_EVIDENCE",scope="ARTIFACTS_ONLY_EXTERNAL_PROCESS_DEVICE_JOIN_REQUIRED")
        try:
            campaign=json.loads(args.campaign.read_text())
            require(digest(args.requests) == campaign["requests_sha256"], "original request manifest changed")
            roots = {}
            if campaign.get('worker_provenance_enabled', False):
                admission_path = Path(campaign['admission_path'])
                require(digest(admission_path) == campaign['admission_sha256'], "original service admission changed")
                admission = json.loads(admission_path.read_text())
                require(admission['source_sha'] == campaign['source_sha']
                        and admission['source_tree'] == campaign['source_tree'], "service admission source differs")
                roots = dict(expected_source=source, expected_vllm_source=admission['vllm_checkout'])
            result.update(validate_requests(campaign,json.loads(args.records.read_text()),
                                            json.loads(args.requests.read_text()),
                                            expected_server_argv=json.loads(args.server_argv.read_text()), **roots))
        except (ValueError,KeyError,TypeError,IndexError,OSError) as error:
            result["error"]=f"{type(error).__name__}: {error}"
        write(args.output,result)
        return 0 if result["status"] == "PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS" else 4
    return run_service(args)


def service_device_count(tp, dp):
    require(type(tp) is int and tp in (1, 2, 4, 16)
            and type(dp) is int and (dp == 1 or (tp == 4 and dp == 2)),
            'explicit TP1/2/4/16 DP1 or named TP4/DP2 service required')
    return tp * dp


def validate_service_workload(groups, vocab, *, profile='legacy24k'):
    """Keep legacy limits; admit only the separately declared finite32k pilot."""
    require(profile in ('legacy24k', 'glm32k_2000_n4_c1'), 'unknown service workload profile')
    outputs, maximum = ((256, 512), 24576) if profile == 'legacy24k' else ((2000,), 36864)
    require(1 <= len(groups) <= 4, 'bounded request groups')
    require(all(1 <= len(g['prompts']) <= 4 and type(g['max_tokens']) is int
                and g['max_tokens'] in outputs for g in groups), 'bounded workload')
    if profile != 'legacy24k':
        require(len(groups) == 1 and len(groups[0]['prompts']) == 4
                and type(groups[0].get('concurrency')) is int
                and groups[0]['concurrency'] == 1
                and all(len(p['prompt_token_ids']) == 32000 for p in groups[0]['prompts']),
                'exact32k/2000/n4/c1 pilot required')
    require(all(0 < len(p['prompt_token_ids']) + g['max_tokens'] <= maximum
                and all(type(token) is int and 0 <= token < vocab for token in p['prompt_token_ids'])
                for g in groups for p in g['prompts']), 'input IDs/length outside model/profile contract')


def run_service(args, *, server_argv_builder=None, target_model=None, extra_metadata=None,
                tp=1, ready_timeout_seconds=600, client_runner=None, dp=1,
                identity_collector=None, workload_profile='legacy24k'):
    """Reuse the official CLI/SSE lifecycle; builders only produce server argv."""
    source=Path(__file__).resolve().parents[1]
    devices = service_device_count(tp, dp)
    require(type(ready_timeout_seconds) is int and 0 < ready_timeout_seconds <= 1800,
            'bounded official service readiness required')
    # The legacy receipt's `tp` field counts the complete physical set. The
    # actual model TP and DP are separately retained below; DP2 is not TP8.
    receipt=validate_admission(args.admission,source=source,sha=args.expected_sha,tp=devices)
    require(not args.output.exists(),"new service attempt required");args.output.mkdir(parents=True)
    groups=json.loads(args.requests.read_text())
    target=Path(target_model or "/mnt/share/wql/Qwen3-8B")
    model_config = json.loads((target/"config.json").read_text())
    vocab = model_config.get('text_config', model_config)['vocab_size']
    validate_service_workload(groups, vocab, profile=workload_profile)
    name="graph-r6-"+args.expected_sha[:8]+"-"+args.arm.lower();base=f"http://127.0.0.1:{args.port}"
    builder=serve_argv if server_argv_builder is None else server_argv_builder
    argv=builder(sys.executable,args.port,name,args.arm,worker_provenance=args.worker_provenance)
    require(Path(argv[argv.index("serve")+1]).resolve()==target.resolve(),
            "declared target differs from actual official server argv")
    record=dict(status="STARTING",source_sha=args.expected_sha,source_tree=receipt["source_tree"],arm=args.arm,
                pid=os.getpid(),started_at=time.time(),start_monotonic_ns=time.monotonic_ns(),script_sha256=digest(__file__),server_argv=argv,requests_sha256=digest(args.requests),
                admission_sha256=digest(args.admission),admission_path=str(args.admission),
                device_completion="NOT_INFERRED_FROM_HTTP_OR_EXIT",
                heavy_diagnostics=False,semantic_numeric="NOT_ASSESSED",public_graph_gate="FROZEN",
                source_root=str(source),vllm_source_root=receipt['vllm_checkout'],
                execution_tp=tp,ready_timeout_seconds=ready_timeout_seconds,
                worker_provenance_enabled=args.worker_provenance,worker_provenance=[])
    if dp != 1:
        record.update(execution_dp=dp, physical_device_count=devices)
    if extra_metadata is not None:
        require(type(extra_metadata) is dict and not (set(extra_metadata)&set(record)),
                "method metadata must not replace execution identity or results")
        record.update(extra_metadata)
    write(args.output/"campaign.json",record);server=None
    try:
        with (args.output/"server.stdout.log").open('x') as out,(args.output/"server.stderr.log").open('x') as err:
            server_env=os.environ.copy()
            if args.worker_provenance:
                # Localhost-only development API, explicitly opt-in for this
                # child; never enable it in the normal service/control arm.
                server_env['VLLM_SERVER_DEV_MODE']='1'
            server=subprocess.Popen(argv,cwd=source,env=server_env,stdout=out,stderr=err,start_new_session=True)
            record.update(server_pid=server.pid,server_start_ticks=Path('/proc',str(server.pid),'stat').read_text().rsplit(')',1)[1].split()[19]);write(args.output/"campaign.json",record)
            ready_until=time.monotonic()+ready_timeout_seconds
            while True:
                require(server.poll() is None,"official server exited during startup")
                try:
                    with urllib.request.urlopen(base+"/health",timeout=2) as response:
                        if response.status==200:break
                except (urllib.error.URLError,TimeoutError):pass
                require(time.monotonic()<ready_until,f"server readiness timeout{ready_timeout_seconds}s");time.sleep(2)
            record.update(status="HTTP_READY",ready_at=time.time());write(args.output/"campaign.json",record)
            if args.worker_provenance:
                nonce=uuid.uuid4().hex
                collector = worker_identity_rpc if identity_collector is None else identity_collector
                at=time.monotonic_ns();identity=collector(base,nonce)
                record['worker_provenance'].append(dict(phase='BEFORE_REQUESTS',nonce=nonce,
                                                       start_ns=at,end_ns=time.monotonic_ns(),results=identity))
                write(args.output/"campaign.json",record)
            client = client_groups if client_runner is None else client_runner
            results=asyncio.run(client(base,name,groups,args.output))
            if args.worker_provenance:
                nonce=uuid.uuid4().hex
                at=time.monotonic_ns();identity=collector(base,nonce)
                record['worker_provenance'].append(dict(phase='AFTER_REQUESTS',nonce=nonce,
                                                       start_ns=at,end_ns=time.monotonic_ns(),results=identity))
            write(args.output/"requests.json",dict(status="COMPLETE",groups=results))
            record.update(status="OFFICIAL_CLI_HTTP_REQUESTS_COMPLETE_NOT_NUMERIC_OR_COMPLETION_PROOF",
                          measured_requests=sum(len(g["results"]) for g in results if g["phase"]=="measured"))
    except BaseException as error:
        record.update(status="FAILED",exception_type=type(error).__name__,exception_message=str(error),
                      failure_action="PROCESS_ISOLATION_NO_DEVICE_RECOVERY", method_isolation_required=True)
        raise
    finally:
        if server is not None and server.poll() is None:
            server.terminate()
            try:server.wait(timeout=90)
            except subprocess.TimeoutExpired:record["cleanup"]="OWN_SERVER_STILL_ALIVE_EXTERNAL_SUPERVISOR_MUST_ISOLATE"
        record.update(ended_at=time.time(),end_monotonic_ns=time.monotonic_ns(),server_rc=None if server is None else server.poll())
        write(args.output/"campaign.json",record)
    return 0 if record["status"].startswith("OFFICIAL_CLI_HTTP_REQUESTS_COMPLETE_") and record["server_rc"] is not None else 2


if __name__=="__main__":raise SystemExit(main())
