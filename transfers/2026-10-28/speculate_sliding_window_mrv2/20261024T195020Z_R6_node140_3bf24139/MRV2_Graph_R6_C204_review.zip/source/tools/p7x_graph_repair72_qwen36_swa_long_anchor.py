# SPDX-License-Identifier: Apache-2.0
"""One original SWA Graph long-request baseline before extra Window changes.

The fixed 36,865-token requests cross native4096 and intended32768. This
TP4/DP1 baseline separates native Graph long-request failures from extra
Window failures. It is not DP2, numerical, lifecycle or performance approval.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import json

from tools.p7x_graph_repair21_rank import require, run_anchor, write
from tools.p7x_graph_repair28_rank_anchor_check import check as check_anchor
from tools.p7x_graph_repair70_qwen36_swa_anchor import (
    build_kwargs as original_kwargs, preflight_workers, profile_identity as original_identity, validate_worker,
)

PROFILE = 'QWEN36_SWA6_ORIGINAL_GRAPH_TP4_DP1_LONG36865_V1'
REQUESTS = (('long-one', (36865,)), ('mixed-three', (36865, 8193, 387)))
OUTPUT_TOKENS = 256


def profile_identity():
    return dict(profile=PROFILE, model=original_identity(), max_model_len=40960,
                groups=[dict(label=label, lengths=list(lengths)) for label, lengths in REQUESTS],
                output_tokens=OUTPUT_TOKENS, native_window=4096, extra_window=None,
                scope='Synthetic fixed long-request original Graph baseline; not independent numeric reference')


def build_kwargs(tp, *, window_on_review=False):
    kwargs = original_kwargs(tp, window_on_review=window_on_review)
    kwargs['max_model_len'] = 40960
    return kwargs


def check(planned, execution):
    result = check_anchor(planned, execution, kwargs_factory=build_kwargs, worker_validator=validate_worker,
                          entrypoint_name=Path(__file__).name, request_plan=REQUESTS, output_tokens=OUTPUT_TOKENS)
    if result['status'].startswith('PASS_SCOPED_'):
        plan = json.loads(Path(planned).read_text());argv = plan['argv']
        campaign = json.loads((Path(argv[argv.index('--output')+1])/'campaign.json').read_text())
        require(plan['profile_identity'] == campaign['profile_identity'] == profile_identity(),
                'named long original-model/request identity differs')
        require(campaign['request_contract'] == dict(groups=profile_identity()['groups'],output_tokens=OUTPUT_TOKENS),
                'actual long request contract differs')
        before = campaign['swa_post_capture_preflight'];after = campaign['ranks']
        require(len(before) == 4 and {(v['rank'],v['pid'],v['process_start_ticks']) for v in before}
                == {(v['rank'],v['pid'],v['process_start_ticks']) for v in after},
                'original long baseline changed worker after capture')
        for row in before:validate_worker(row,4)
        result.update(status='PASS_SCOPED_ORIGINAL_SWA_GRAPH_LONG_REQUESTS_TP4_DP1',profile=PROFILE,
                      scope='Original SWA configured4096, actual long requests and all4 Graph dispatch/device identities; '
                            'not numeric, DP2, extra Window, last-reader completion or performance')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('run','check'))
    parser.add_argument('--expected-sha');parser.add_argument('--tp',type=int,choices=(4,),default=4)
    for name in ('admission','output','planned','execution'):
        parser.add_argument('--'+name,type=Path,required=name=='output')
    args = parser.parse_args()
    if args.command == 'run':
        from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay
        require(args.admission is not None and args.expected_sha is not None,'fresh fixed complete admission required')
        receipt = json.loads(args.admission.read_text())
        validate_runtime_overlay(receipt['runtime_manifest']['path'],Path(__file__).resolve().parents[1],
                                 args.expected_sha,receipt['source_tree'])
        args.window_on_review = False
        return run_anchor(args,profile_kwargs=build_kwargs(args.tp),profile_identity=profile_identity(),
                          producer_path=__file__,before_requests=preflight_workers,
                          request_plan=REQUESTS,output_tokens=OUTPUT_TOKENS)
    require(args.planned is not None and args.execution is not None,'saved invocation and process evidence required')
    try:result = check(args.planned,args.execution)
    except (ValueError,KeyError,TypeError,OSError,IndexError) as error:
        result = dict(status='INVALID_EVIDENCE',error=str(error))
    write(args.output,result)
    return 0 if result['status'].startswith('PASS_SCOPED_') else 4


if __name__ == '__main__':
    raise SystemExit(main())
