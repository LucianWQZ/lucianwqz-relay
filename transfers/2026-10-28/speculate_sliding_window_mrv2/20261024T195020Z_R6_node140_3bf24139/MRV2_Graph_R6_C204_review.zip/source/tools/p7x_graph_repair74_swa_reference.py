# SPDX-License-Identifier: Apache-2.0
"""Finite serialized same-prestate SWA Graph/eager reference, TP4/DP1 only.

Three actual request replays (two active1 and one active3) are compared with
the same padded shape, current inputs, full KV prestate and Window32768.
Identical cache views are snapshotted/restored once. Overlapping native/Full
views must agree at every retained shared block. No Target tensor is restored.
This changes diagnostic timing and does not prove normal overlap, ABA,
complete Target isolation, execution operands, physical reads or performance.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import copy
import json
import os
import uuid
from types import MethodType

import torch

from tools.p7x_graph_repair21_rank import digest, require, run_anchor, write
from tools.p7x_graph_repair28_rank_anchor_check import check as check_anchor
from tools.p7x_graph_repair6_storage import CollectionReader, CollectionWriter
from tools.p7x_graph_repair6_submission import NumericMismatch, SubmissionState
from tools.p7x_graph_repair73_qwen36_swa_window_anchor import (
    OUTPUT_TOKENS, REQUESTS, SWAWindowWorker, build_kwargs as anchor_kwargs,
    preflight as anchor_preflight, profile_identity as anchor_identity,
    validate_bound, validate_worker as anchor_worker,
)

PROFILE = 'QWEN36_SWA6_SAME_PRESTATE_3_REAL_REPLAYS_TP4_V1'
OWNED_PROFILE = 'QWEN36_SWA6_ACTIVE3_OWNED_OUTPUT_AND_FIA_STATE_PROBE_V1'
FULL8_PROFILE = 'QWEN36_FULL8_SAME_PRESTATE_3_REAL_REPLAYS_TP4_V1'
FULL8_FAILURE_PROFILE = 'QWEN36_FULL8_FIRST_ATTENTION_OWNED_REPEAT_DISCRIMINATOR_TP4_V1'
WINDOW = 32768
BLOCK = 128
QUOTA = {1: 2, 3: 1}
MAX_DEVICE_SNAPSHOTS = 1 << 30


def identity(owned_failure_probe=False):
    if owned_failure_probe:
        return dict(profile=OWNED_PROFILE,anchor=anchor_identity(),quota={'3':1},
                    scope='Failed active3 discriminator: raw/owned output, last attention query/output and state-only counterfactual; no waiver')
    return dict(profile=PROFILE, anchor=anchor_identity(), quota={str(k):v for k,v in QUOTA.items()},
                scope='Same shape independent eager from full prestate, serialized diagnostic; not ABA or Target join')


def build_kwargs(tp, *, window_on_review=False, owned_failure_probe=False):
    kw = anchor_kwargs(tp, window_on_review=window_on_review)
    kw['additional_config']['draft_window_graph_numeric_diagnostic'] = True
    if owned_failure_probe:kw['additional_config']['draft_window_graph_numeric_owned_output']=True
    kw['worker_extension_cls'] = 'tools.p7x_graph_repair74_swa_reference.SWAReferenceWorker'
    return kw


def row_phases(fields):
    require(set(fields)=={'computed','scheduled','prefill','declared'}
            and len({len(v) for v in fields.values()})==1, 'complete raw CPU phase inputs')
    phases=[]
    for c,s,e,declared in zip(fields['computed'],fields['scheduled'],fields['prefill'],fields['declared']):
        require(all(type(v) is int and v>=0 for v in (c,s,e)) and type(declared) is bool
                and declared==(c<e), 'raw phase counters/flag contradiction')
        phases.append('pure_decode' if c>=e else 'prefill_continuing' if c+s<e else 'prefill_terminal')
    return phases


def project_full(canonical, exact, active, padded, width, phases=None, *, window=WINDOW):
    """Independent CPU construction from canonical full rows, never P3 output."""
    require(canonical.ndim == 2 and canonical.device.type == 'cpu'
            and len(exact) == padded and 0 < active <= padded
            and type(width) is int and width > 0 and type(window) is int and window > 0,
            'full reference geometry')
    table = torch.zeros((padded, width), dtype=canonical.dtype)
    lengths, starts = [0]*padded, []
    phases=['pure_decode']*active if phases is None else phases
    require(len(phases)==active and all(v in ('pure_decode','prefill_continuing','prefill_terminal') for v in phases),
            'explicit per-row reference phase required')
    for row in range(active):
        e = exact[row]
        require(type(e) is int and e >= 8, 'full current exact length')
        first = 0 if phases[row]=='prefill_continuing' else max(e-window,0)//BLOCK
        last = (e+BLOCK-1)//BLOCK
        require(0 <= first < last <= canonical.shape[1] and last-first <= width,
                'independent canonical read extent exceeds table capacity')
        table[row, :last-first] = canonical[row, first:last]
        lengths[row] = e-first*BLOCK
        starts.append(first*BLOCK)
    require(exact[active:] == [0]*(padded-active), 'full padded exact length must be zero')
    return table, lengths, starts


def full_write_errors(before, after, selected, slots):
    """All retained physical positions outside actual query writes are exact."""
    require(before.shape == after.shape and before.dtype == after.dtype
            and before.ndim == 4 and before.shape[0] == len(selected)
            and before.shape[1] == BLOCK, 'retained physical KV geometry')
    allowed = {int(value) for value in slots if value >= 0}
    require(all(value//BLOCK in selected for value in allowed), 'write block omitted from snapshot')
    errors = []
    changed = torch.any(before != after, dim=(-1,-2))
    for row, position in changed.nonzero().tolist():
        if selected[row]*BLOCK+position not in allowed:
            errors.append([selected[row], position])
    return errors


def validate_alias_layout(allocations, *, kv_heads=2):
    values=list(allocations)
    shape = [BLOCK, kv_heads, 128]
    stride = [BLOCK*kv_heads*128, kv_heads*128, 128, 1]
    block_bytes = BLOCK*kv_heads*128*2
    for index,left in enumerate(values):
        require(left['shape'][1:]==shape and left['stride']==stride
                and left['dtype']=='torch.bfloat16' and left['npu_format'] in (0,2),
                'diagnostic requires actual unpacked ND/NCHW cache layout')
        for right in values[index+1:]:
            a,b=left['data_ptr'],right['data_ptr']
            if max(a,b)<min(a+left['shape'][0]*block_bytes,b+right['shape'][0]*block_bytes):
                require((a-b)%block_bytes==0,'overlapping cache views are not aligned to the same physical blocks')


class SWAReplayReference:
    profile_name = PROFILE
    window = WINDOW
    kv_heads = 2
    owned_profile_name = OWNED_PROFILE
    owned_quota_entries = ((3, 1),)

    def reader_plan(self):
        plan = self.owner._draft_window_graph_binding_provider.native_swa_graph_plan
        require(plan is not None, 'actual native SWA reader inventory missing')
        return plan

    def __init__(self, worker, output, contract):
        from tools.p7x_graph_repair25_rank_numeric import host_sample_barrier

        self.worker, self.runner = worker, worker.model_runner
        self.contract,self.barrier,self.step=contract,host_sample_barrier,0
        contract.validate(self.runner.speculator.vllm_config.parallel_config,worker.rank)
        self.owner = self.runner.speculator
        self.manager = self.owner.query_cudagraph_manager
        self.sink = self.owner._draft_graph_output_references
        self.owned=getattr(self.sink,'owned',False)
        self.quota=dict(self.owned_quota_entries) if self.owned else QUOTA
        self.profile=self.owned_profile_name if self.owned else self.profile_name
        tool_path = Path(sys.modules[type(self).__module__].__file__)
        require(self.sink.frozen, 'real capture output sink must be frozen')
        self.output = Path(output)/f'rank-{worker.rank}'
        self.output.mkdir(parents=True, exist_ok=False)
        self.writer = CollectionWriter(self.output/'numeric.json',
            dict(profile=self.profile, rank=worker.rank, source=str(Path(__file__).resolve().parents[1]),
                 tool_sha256=digest(tool_path), reference_helper_sha256=digest(__file__),
                 tolerance=dict(atol=0,rtol=0),
                 timing='EXPLICIT_SERIAL_DIAGNOSTIC_DRAINS', target='NOT_RESTORED_OR_INDEPENDENTLY_JOINED'),
            max_bytes=6*1024**3)
        self.counts = {n:0 for n in self.quota}
        self.submission = SubmissionState()
        self.failed = False
        self.original = self.manager.run_fullgraph
        probe = self
        def replay(manager, desc):
            require(not probe.failed, 'failed numerical branch must not replay')
            s = probe.owner
            n = s.input_batch.num_reqs
            if (getattr(s,'_draft_window_bypass_active',False)
                    or n not in probe.quota or probe.counts[n] >= probe.quota[n]):
                return probe.original(desc)
            live=getattr(s,'_draft_window_live_inputs',None)
            require(live is not None,'real numerical replay missing current prepared inputs')
            if not any(v.source_start_column or v.first_token_offset for v in live.identity.read_descriptor_fingerprint):
                return probe.original(desc)
            try:
                return probe.run(desc)
            except BaseException as error:
                probe.failed = True
                probe.submission.failed(error)
                if probe.submission.pending:
                    s._draft_window_graph_submission_uncertain = True
                # Host-only failure export; no drain, tensor read or recovery.
                probe.writer.close('FAILED')
                write(probe.output/'failure.json',dict(error=repr(error),submission=probe.submission.snapshot()))
                try:
                    probe.barrier(probe.output.parent/'barrier',probe.contract,probe.step+1,
                                  status='FAILED',pending=probe.submission.pending)
                except BaseException as peer_error:
                    error.add_note('Host-only failed-rank notice: '+repr(peer_error))
                raise
        self.manager.run_fullgraph = MethodType(replay,self.manager)

    def drain(self, pending, complete):
        self.submission.submit(pending)
        self.manager.update_stream.synchronize()
        torch.npu.current_stream().synchronize()
        self.submission.complete(complete)

    def run(self, desc):
        from vllm.config.compilation import CUDAGraphMode
        from vllm.v1.worker.gpu.attn_utils import build_slot_mappings_by_layer

        s, n, p = self.owner, self.owner.input_batch.num_reqs, desc.num_reqs
        require(desc.cg_mode == CUDAGraphMode.FULL and desc.num_tokens == p*8, 'actual fixed FULL Q8 descriptor')
        self.drain('PRESTATE_DRAIN_PENDING','PRESTATE_DRAIN_COMPLETE')
        self.submission.submit('PRESTATE_READ_PENDING')
        plan = self.reader_plan()
        exact = s.input_buffers.seq_lens[:p].detach().cpu().tolist()
        fields=dict(computed=s.input_batch.num_computed_prefill_tokens_np[:n].tolist(),
                    scheduled=s.input_batch.num_scheduled_tokens[:n].tolist(),
                    prefill=s.input_batch.prefill_len_np[:n].tolist(),
                    declared=s.input_batch.is_prefilling_np[:n].tolist())
        phases=row_phases(fields)
        gids = [g.gid for g in plan.native_groups]+[plan.full_gid]
        tables = {gid:s.block_tables.input_block_tables[gid][:p].detach().cpu().clone() for gid in gids}
        slots = {gid:s.block_tables.slot_mappings[gid,:desc.num_tokens].detach().cpu().clone() for gid in gids}
        mapping = torch.as_tensor(s.input_batch.idx_mapping_np[:n],dtype=torch.int64)
        counts = {gid:s.block_tables.num_blocks.cpu[gid].index_select(0,mapping).tolist() for gid in gids}
        context = self.runner.compilation_config.static_forward_context
        layer_gid = {name:g.gid for g in plan.native_groups for name in g.layers}
        layer_gid.update({name:plan.full_gid for name in plan.full_layers})
        self.submission.complete('PRESTATE_CPU_FIELDS_READY')
        sample_index=sum(self.counts.values())
        write(self.output/f'prestate-{sample_index:02}-headers.json',self.writer.store.encode(
            dict(exact=exact,tables=tables,slots=slots,counts=counts,actual=n,padded=p,phase_inputs=fields,
                 scope='ACTUAL_PREGRAPH_CPU_FIELDS_BEFORE_TOOL_ASSERTIONS')))
        caches = {}
        for name, gid in layer_gid.items():
            table, write_slots = tables[gid], slots[gid]
            require(write_slots.dtype in (torch.int32,torch.int64) and write_slots.shape == (p*8,)
                    and bool(torch.all(write_slots[:n*8] >= 0)) and bool(torch.all(write_slots[n*8:] == -1)),
                    'active/padded native/Full query slot contract differs')
            selected = {0}|{int(v)//BLOCK for v in write_slots.tolist() if v>=0}
            for row, count in enumerate(counts[gid]):
                require(type(count) is int and 0<count<=table.shape[1], 'canonical per-gid block count')
                selected.update(table[row,:count].tolist())
            for part, tensor in enumerate(context[name].kv_cache):
                key = f'{tensor.data_ptr()}:{tuple(tensor.shape)}:{tuple(tensor.stride())}'
                if key not in caches:
                    caches[key] = dict(tensor=tensor,selected=set(),slots=set(),layers=[])
                caches[key]['selected'].update(selected)
                caches[key]['slots'].update(int(v) for v in write_slots.tolist() if v>=0)
                caches[key]['layers'].append(f'{name}/{part}')
        total = 0
        import torch_npu
        for cache in caches.values():
            t = cache['tensor'];selected = sorted(cache['selected'])
            require(t.ndim==4 and t.shape[1:]==(128,self.kv_heads,128) and t.dtype==torch.bfloat16
                    and tuple(t.stride())==(128*self.kv_heads*128,self.kv_heads*128,128,1)
                    and selected and 0<=selected[0]<=selected[-1]<t.shape[0], 'actual local cache/layout or selected block')
            total += len(selected)*t[0].numel()*t.element_size()
            cache['selected']=selected
            cache['allocation']=dict(shape=list(t.shape),stride=list(t.stride()),storage_offset=t.storage_offset(),
                                    data_ptr=t.data_ptr(),dtype=str(t.dtype),npu_format=int(torch_npu.get_npu_format(t)))
        write(self.output/f'prestate-{sample_index:02}-allocations.json',
              {key:dict(allocation=cache['allocation'],layers=cache['layers'],selected=cache['selected'],
                        slots=sorted(cache['slots'])) for key,cache in caches.items()})
        validate_alias_layout((cache['allocation'] for cache in caches.values()), kv_heads=self.kv_heads)
        factor = 8 if self.profile == FULL8_FAILURE_PROFILE else 6 if self.owned else 4
        require(total*factor<=MAX_DEVICE_SNAPSHOTS, 'bounded native/Full KV snapshot device budget')
        require(self.output.stat().st_dev==self.output.parent.stat().st_dev, 'shared result path changed')
        self.submission.submit('PRESTATE_DEVICE_SNAPSHOT_PENDING')
        for cache in caches.values():
            cache['indices']=torch.tensor(cache['selected'],dtype=torch.int64,device=s.device)
        before = {key:cache['tensor'].index_select(0,cache['indices']) for key,cache in caches.items()}
        inputs = {key:getattr(s.input_buffers,key)[:desc.num_tokens].detach().cpu().clone()
                  for key in ('input_ids','positions')}
        inputs['query_start_loc']=s.input_buffers.query_start_loc[:p+1].detach().cpu().clone()
        torch.npu.current_stream().synchronize()
        self.submission.complete('PRESTATE_SNAPSHOT_COMPLETE')
        self.submission.submit('GRAPH_REPLAY_UPDATE_PENDING')
        returned = self.original(desc)
        require(returned is None,'official manager return contract changed')
        self.manager.update_stream.synchronize();torch.npu.current_stream().synchronize()
        self.submission.complete('GRAPH_DIAGNOSTIC_COMPLETE')
        self.submission.submit('POSTGRAPH_READ_PENDING')
        graph_hidden = self.sink.get(s,desc.num_tokens).detach().cpu().clone()
        def cpu(value):
            if isinstance(value,torch.Tensor):return value.detach().cpu().clone()
            if isinstance(value,dict):return {k:cpu(v) for k,v in value.items()}
            if isinstance(value,(list,tuple)):return [cpu(v) for v in value]
            return value
        owned_evidence=None
        if self.owned:
            owned_evidence=dict(raw_hidden=cpu(self.sink.raw(s,desc.num_tokens)),
                                graph_attention=cpu(self.sink.attention.get(desc.num_tokens)))
        after = {key:cache['tensor'].index_select(0,cache['indices']) for key,cache in caches.items()}
        carrier = s._draft_window_graph_binding_provider.submitted_carriers[0]
        actual = carrier.metadata
        current = carrier.runtime_identity
        sample_id = dict(rank=self.worker.rank,generation=current.generation_id,epoch=current.mapping_epoch,
                         actual=n,padded=p,index=sum(self.counts.values()))
        self.writer.start(sample_id)
        window_table,window_lengths,starts = project_full(tables[plan.full_gid],exact,n,p,
                                                        actual[plan.full_layers[0]].block_tables.shape[1],phases,
                                                        window=self.window)
        reference_meta,actual_headers,reference_headers = {},{},{}
        for name,gid in layer_gid.items():
            value=actual[name];native=gid!=plan.full_gid
            table=tables[gid] if native else window_table
            lengths=exact if native else window_lengths
            reference=copy.copy(value)
            reference.block_tables=table.to(s.device)
            reference.seq_lens=torch.tensor(lengths,dtype=torch.int32,device=s.device)
            reference.seq_lens_cpu=torch.tensor(lengths,dtype=torch.int32)
            reference.seq_lens_list=list(lengths)
            reference_meta[name]=reference
            actual_headers[name]=dict(gid=gid,table=value.block_tables.detach().cpu().clone(),
                exact=list(value.seq_lens_list),slot=value.slot_mapping.detach().cpu().clone(),causal=value.causal,
                positions=value.positions.detach().cpu().clone(),query_start=value.query_start_loc.detach().cpu().clone(),
                cumulative_query=list(value.actual_seq_lengths_q))
            reference_headers[name]=dict(gid=gid,table=table.clone(),exact=list(lengths),slot=slots[gid].clone(),causal=native)
        legacy_reference_meta = reference_meta
        if self.profile_name == FULL8_PROFILE:
            # Full8's reference must follow the normal eager Draft builder.
            # In particular a Target PrefillNoCache enum retained by Graph
            # UPDATE is not an eager cached-reader dispatch instruction.
            reference_meta = self.build_eager_reference_metadata(desc, tables, window_table, window_lengths)
            require(set(reference_meta) == set(reference_headers), 'independent eager reader inventory changed')
            for name, value in reference_meta.items():
                expected = reference_headers[name]
                require(torch.equal(value.block_tables.cpu(), expected['table'])
                        and list(value.seq_lens_list) == expected['exact']
                        and torch.equal(value.slot_mapping.cpu(), expected['slot'])
                        and value.causal is False, 'actual eager builder changed canonical read/write operands')
            self.legacy_reference_meta = legacy_reference_meta
        self.submission.complete('POSTGRAPH_CPU_HEADERS_READY')
        write(self.output/f'postgraph-{sample_index:02}-headers.json',self.writer.store.encode(
            dict(identity=sample_id,actual_metadata=actual_headers,reference_metadata=reference_headers,
                 graph_hidden=graph_hidden,scope='ACTUAL_POSTGRAPH_HEADERS_BEFORE_REFERENCE_ASSERTIONS')))
        for name,value in actual_headers.items():
            expected=reference_headers[name]
            require(torch.equal(value['table'],expected['table']) and value['exact']==expected['exact']
                    and torch.equal(value['slot'],expected['slot']) and value['causal'] is expected['causal'],
                    'actual metadata differs from independent per-group full-state oracle')
        fresh=None
        if self.owned:
            live=s._draft_window_live_inputs
            live.validate_for(live.identity)
            from vllm_ascend.worker.v2.spec_decode.draft_window_eager import AscendDraftAttentionReadInputs
            from vllm_ascend.worker.v2.attn_utils import build_attn_metadata_wrapper
            current_read=AscendDraftAttentionReadInputs(
                block_tables=tuple(live.window_block_table if gid==plan.full_gid else table[:p]
                    for gid,table in enumerate(s.block_tables.input_block_tables)),
                seq_lens=live.device_window_exact,seq_lens_cpu_exact=live.cpu_window_exact,
                seq_lens_cpu_upper_bound=live.cpu_window_upper,
                max_seq_len=int(live.cpu_window_upper[:n].max().item()))
            if self.profile_name == FULL8_PROFILE:
                fresh = reference_meta
            else:
                with build_attn_metadata_wrapper():
                    fresh=s._build_ascend_draft_attn_metadata(read_inputs=current_read,num_reqs=n,
                        num_reqs_padded=p,num_tokens_padded=desc.num_tokens,causal=s._group_causal,
                        query_start_loc_np=None,dcp_local_seq_lens=None)
            from vllm_ascend.worker.v2.spec_decode.draft_window_graph_diagnostics import _metadata_header
            owned_evidence['actual_metadata_headers']={name:_metadata_header(m) for name,m in actual.items()}
            owned_evidence['fresh_draft_builder_headers']={name:_metadata_header(m) for name,m in fresh.items()}
        self.submission.submit('REFERENCE_RESTORE_FORWARD_PENDING')
        for key,cache in caches.items():cache['tensor'].index_copy_(0,cache['indices'],before[key])
        restored = {key:cache['tensor'].index_select(0,cache['indices']) for key,cache in caches.items()}
        self.sink.reference_active=self.owned
        try:
            reference=s._run_model(desc.num_tokens,reference_meta,
                build_slot_mappings_by_layer(s.block_tables.slot_mappings[:,:desc.num_tokens],s.kv_cache_config),
                None,CUDAGraphMode.NONE)
        finally:self.sink.reference_active=False
        torch.npu.current_stream().synchronize()
        self.submission.complete('REFERENCE_DIAGNOSTIC_COMPLETE')
        self.submission.submit('REFERENCE_POSTSTATE_READ_PENDING')
        reference_hidden=reference.detach().cpu().clone()
        reference_after={key:cache['tensor'].index_select(0,cache['indices']) for key,cache in caches.items()}
        if self.owned:
            owned_evidence['reference_attention']=cpu(self.sink.reference_attention)
            owned_evidence['attention_layer_name']=self.sink.attention_layer_name
            write(self.output/f'completed-first-reference-{sample_index:02}.json', self.writer.store.encode(cpu(dict(
                schema='COMPLETED_STAGE_EXCERPT_NOT_MAIN_NUMERIC_ARTIFACT', identity=sample_id,
                scope='Known-completed Graph and first reference; Graph poststate not yet restored; no normal completion claim',
                graph_hidden=graph_hidden, reference_hidden=reference_hidden, owned=owned_evidence,
                caches={key:dict(selected=c['selected'],slots=sorted(c['slots']),layers=c['layers'],
                                before=before[key],restored=restored[key],graph=after[key],reference=reference_after[key])
                        for key,c in caches.items()}))))
            self.submission.complete('FIRST_REFERENCE_SNAPSHOT_EXPORT_COMPLETE')
            if self.profile == FULL8_FAILURE_PROFILE:
                # One bounded, named discriminator. The original Graph/eager
                # verdict and all KV/full-write checks remain unchanged.
                from tools.p7x_graph_repair77_full8_reference import collect_full8_failure_repeat

                owned_evidence['same_prestate_repeat'] = collect_full8_failure_repeat(
                    self, desc, reference_meta, caches, before, cpu)
            changed={name for name in actual if actual[name].attn_state!=fresh[name].attn_state}
            owned_evidence['state_only_counterfactual']=None
            if changed and self.profile != FULL8_FAILURE_PROFILE:
                self.submission.submit('STATE_ONLY_COUNTERFACTUAL_RESTORE_FORWARD_PENDING')
                for key,cache in caches.items():cache['tensor'].index_copy_(0,cache['indices'],before[key])
                counter_before={key:cache['tensor'].index_select(0,cache['indices']) for key,cache in caches.items()}
                counter_meta={name:copy.copy(m) for name,m in reference_meta.items()}
                for name in changed:counter_meta[name].attn_state=fresh[name].attn_state
                self.sink.reference_active=True
                try:
                    counter=s._run_model(desc.num_tokens,counter_meta,
                        build_slot_mappings_by_layer(s.block_tables.slot_mappings[:,:desc.num_tokens],s.kv_cache_config),
                        None,CUDAGraphMode.NONE)
                finally:self.sink.reference_active=False
                torch.npu.current_stream().synchronize()
                self.submission.complete('STATE_ONLY_COUNTERFACTUAL_COMPLETE')
                self.submission.submit('STATE_ONLY_COUNTERFACTUAL_EXPORT_PENDING')
                counter_after={key:cache['tensor'].index_select(0,cache['indices']) for key,cache in caches.items()}
                owned_evidence['state_only_counterfactual']=dict(changed_layers=sorted(changed),
                    scope='SECOND_REFERENCE_STATE_ONLY_NOT_A_PRODUCTION_FIX_OR_REPLACEMENT_ORACLE',
                    hidden=cpu(counter),attention=cpu(self.sink.reference_attention),
                    restored=cpu(counter_before),post=cpu(counter_after))
        self.submission.submit('GRAPH_POSTSTATE_RESTORE_PENDING')
        for key,cache in caches.items():cache['tensor'].index_copy_(0,cache['indices'],after[key])
        torch.npu.current_stream().synchronize()
        self.submission.complete('GRAPH_POSTSTATE_RESTORE_COMPLETE')
        self.submission.submit('COMPLETED_EXPORT_PENDING')
        payload={key:dict(selected=cache['selected'],slots=sorted(cache['slots']),layers=cache['layers'],
            allocation=cache['allocation'],
            before=before[key].cpu(),restored=restored[key].cpu(),graph=after[key].cpu(),reference=reference_after[key].cpu())
                 for key,cache in caches.items()}
        after_inputs={key:getattr(s.input_buffers,key)[:desc.num_tokens].detach().cpu().clone()
                      for key in ('input_ids','positions')}
        after_inputs['query_start_loc']=s.input_buffers.query_start_loc[:p+1].detach().cpu().clone()
        record=dict(identity=sample_id,status='CAPTURED_COMPLETE',profile=self.profile,
            full_gid=plan.full_gid,native_gids=[g.gid for g in plan.native_groups],canonical=tables,block_counts=counts,full_exact=exact,
            window_starts=starts,inputs=inputs,after_inputs=after_inputs,graph_hidden=graph_hidden,reference_hidden=reference_hidden,
            requests=list(current.ordered_request_fingerprint),row_phases=phases,phase_inputs=fields,
            actual_metadata=actual_headers,reference_metadata=reference_headers,caches=payload,
            reference_metadata_source=('ACTUAL_DRAFT_EAGER_BUILDER_WITH_CANONICAL_READS'
                if self.profile_name == FULL8_PROFILE else 'LEGACY_GRAPH_NONREAD_FIELDS_WITH_INDEPENDENT_READS'),
            graph_backend_states={name:getattr(m.attn_state,'name',None if m.attn_state is None else str(m.attn_state))
                                  for name,m in actual.items()},
            reference_backend_states={name:getattr(m.attn_state,'name',None if m.attn_state is None else str(m.attn_state))
                                      for name,m in reference_meta.items()},
            reference_call='REAL_DFLASH_RUN_MODEL_CUDAGRAPH_NONE_AFTER_EXACT_PRESTATE_RESTORE',
            normal_completion='NOT_PROVEN_DIAGNOSTIC_DRAINS',target='NOT_JOINED',physical_read='NOT_OBSERVED')
        if self.owned:record['owned_failure_probe']=owned_evidence
        self.submission.complete('COMPLETED_EXPORT_READY')
        self.writer.finish(record)
        verdict=validate_sample(record)
        write(self.output/f'check-{sample_index:02}.json',verdict)
        if verdict['errors']:
            raise NumericMismatch('; '.join(verdict['errors']))
        self.barrier(self.output.parent/'barrier',self.contract,self.step+1,
                     status='COMPLETED_SAMPLE',pending=False)
        self.step+=1
        self.counts[n]+=1
        if self.counts==self.quota:self.writer.close('COMPLETE')
        return returned

    def snapshot(self):
        return dict(profile=self.profile,counts=dict(self.counts),failed=self.failed,
                    submission=self.submission.snapshot(),collection=str(self.writer.path),
                    manifest_sha256=digest(self.writer.path),scope='SERIAL_DIAGNOSTIC_ONLY')


def validate_sample(record):
    """Read raw values; no producer PASS/status is accepted as the decision."""
    errors=[]
    require(record['profile'] in (PROFILE,OWNED_PROFILE,FULL8_PROFILE,FULL8_FAILURE_PROFILE) and record['reference_call']=='REAL_DFLASH_RUN_MODEL_CUDAGRAPH_NONE_AFTER_EXACT_PRESTATE_RESTORE',
            'independent actual eager invocation missing')
    full8 = record['profile'] in (FULL8_PROFILE, FULL8_FAILURE_PROFILE)
    kv_heads, readers, native_count, window = (1,8,0,1024) if full8 else (2,6,5,WINDOW)
    token_bytes, block_bytes = kv_heads*128*2, BLOCK*kv_heads*128*2
    identity=record['identity'];n,p=identity['actual'],identity['padded']
    h,r=record['graph_hidden'],record['reference_hidden']
    require(h.shape==r.shape and h.ndim==2 and h.shape[0]==p*8 and h.dtype==r.dtype==torch.bfloat16,
            'same-shape BF16 output contract')
    # The new Full8 profile follows the actual DFlash consumer: only active
    # query rows are sampled. The pinned kernel gives padded sample slots
    # query index0 and idx_mapping=-1; propose returns draft_tokens[:num_reqs].
    # Retain padding bytes as descriptive evidence, never relax valid rows or
    # the all-cache/full-write checks. Historical SWA profiles keep their
    # original stronger all-row oracle and original FAIL unchanged.
    valid_rows=n*8 if full8 else p*8
    if (not bool(torch.isfinite(h[:valid_rows]).all() and torch.isfinite(r[:valid_rows]).all())
            or not torch.equal(h[:valid_rows],r[:valid_rows])):errors.append('continuous hidden differs')
    if record['profile'] == FULL8_FAILURE_PROFILE:
        evidence = record['owned_failure_probe']
        repeat = evidence['same_prestate_repeat']
        require(record['identity']['actual'] == record['identity']['padded'] == 1
                and evidence['attention_layer_name'] in record['actual_metadata']
                and evidence['graph_attention'] is not None and evidence['reference_attention'] is not None,
                'missing owned first-reader evidence')
        if not torch.equal(repeat['hidden'], r):
            errors.append('second exact-prestate eager hidden differs')
        for key, cache in record['caches'].items():
            if not torch.equal(repeat['restored'][key], cache['before']):
                errors.append('second reference prestate restore differs '+key)
            if not torch.equal(repeat['post'][key], cache['reference']):
                errors.append('second exact-prestate eager KV differs '+key)
            if full_write_errors(cache['before'], repeat['post'][key], cache['selected'], cache['slots']):
                errors.append('second reference writes outside declared slots '+key)
        native = repeat['functional']
        if native['status'] == 'EXECUTED_TWO_READONLY_CALLS':
            require(len(native['outputs']) == 2 and native['layer'] == evidence['attention_layer_name'],
                    'missing bounded functional pair')
            if not torch.equal(native['query'], native['after_query']) or not torch.equal(native['table'], native['after_table']):
                errors.append('functional query/table input changed')
            if any(not torch.equal(value, native['after'][key]) for key,value in native['before'].items()):
                errors.append('functional cache input changed')
            if not torch.equal(native['outputs'][0], native['outputs'][1]):
                errors.append('same-input functional outputs differ')
        else:
            require(native['status'] == 'SKIPPED_INTERFACE_BRANCH' and native['reason'],
                    'unexplained functional availability')
    padded_hidden_differences=int(torch.count_nonzero(h[n*8:] != r[n*8:]))
    actual,reference=record['actual_metadata'],record['reference_metadata']
    require(len(actual)==len(reference)==readers and set(actual)==set(reference),'complete named actual readers')
    full_gid=record['full_gid'];native=set(record['native_gids']);exact=record['full_exact']
    require(len(native)==native_count and full_gid not in native and len(exact)==p and exact[n:]==[0]*(p-n), 'actual native/Full inventory')
    require(set(record['inputs'])==set(record['after_inputs'])=={'input_ids','positions','query_start_loc'}
            and all(torch.equal(value,record['after_inputs'][key]) for key,value in record['inputs'].items()),
            'same inputs changed across reference')
    phases=row_phases(record['phase_inputs'])
    require(phases==record['row_phases'] and len(phases)==len(record['requests'])==len(set(record['requests']))==n,
            'phase/request identity differs from raw inputs')
    for name,value in actual.items():
        other=reference[name];gid=value['gid'];is_native=gid in native
        require(is_native or gid==full_gid,'foreign reader')
        wanted=record['canonical'][gid]
        lengths=list(exact)
        for row,e in enumerate(exact[:n]):
            pos=record['inputs']['positions'][row*8:(row+1)*8]
            require(torch.equal(pos,torch.arange(e-8,e,dtype=pos.dtype)), 'absolute query positions differ from exact')
            columns=pos.to(torch.int64)//128
            require(int(columns.max())<record['block_counts'][gid][row], 'query write column outside canonical active row')
            wanted_slot=record['canonical'][gid][row].index_select(0,columns).to(torch.int64)*128+pos%128
            require(torch.equal(value['slot'][row*8:(row+1)*8].to(torch.int64),wanted_slot),
                    'Full write slot differs from absolute canonical mapping')
        if not is_native:
            wanted=torch.zeros_like(value['table'])
            for row,e in enumerate(exact[:n]):
                first=0 if phases[row]=='prefill_continuing' else max(e-window,0)//128
                last=(e+127)//128
                wanted[row,:last-first]=record['canonical'][gid][row,first:last]
                lengths[row]=e-first*128
        require(torch.equal(value['table'],wanted) and torch.equal(other['table'],wanted)
                and value['exact']==other['exact']==lengths and value['causal'] is is_native
                and other['causal'] is is_native and torch.equal(value['slot'],other['slot'])
                and value['slot'].shape==(p*8,) and bool(torch.all(value['slot'][:n*8]>=0))
                and bool(torch.all(value['slot'][n*8:]==-1))
                and torch.equal(value['positions'],record['inputs']['positions'])
                and torch.equal(value['query_start'],record['inputs']['query_start_loc'])
                and value['cumulative_query']==[(i+1)*8 for i in range(p)], 'independent read/write metadata differs')
    all_layers=[]
    # Hybrid cache views can overlap with different base addresses/shapes:
    # the actual C177 native K/V ranges lie inside the large Full-V view.
    # Authorize only the union of actual query-write byte addresses, not every
    # position in an overlapping block, and cross-check duplicate snapshots.
    validate_alias_layout((cache['allocation'] for cache in record['caches'].values()), kv_heads=kv_heads)
    all_write_addresses={cache['allocation']['data_ptr']+int(slot)*token_bytes
                         for cache in record['caches'].values() for slot in cache['slots']}
    physical_rows={}
    for key,cache in record['caches'].items():
        all_layers.extend(cache['layers'])
        expected_slots=set();selected={0}
        for layer_part in cache['layers']:
            name,part=layer_part.rsplit('/',1);require(part in ('0','1'),'unknown KV part')
            meta=actual[name];gid=meta['gid'];table=record['canonical'][gid]
            expected_slots.update(int(v) for v in meta['slot'].tolist() if v>=0)
            counts=record['block_counts'][gid]
            require(len(counts)==n and all(type(v) is int and 0<v<=table.shape[1] for v in counts),'canonical block count')
            for row,count in enumerate(counts):selected.update(table[row,:count].tolist())
        selected.update(v//128 for v in expected_slots)
        require(cache['slots']==sorted(expected_slots) and cache['selected']==sorted(selected),
                'retained blocks or allowed writes differ from canonical per-layer operands')
        allocation=cache['allocation']
        require(allocation['shape'][1:]==[128,kv_heads,128] and allocation['dtype']=='torch.bfloat16'
                and allocation['stride']==[128*kv_heads*128,kv_heads*128,128,1]
                and allocation['data_ptr']>0 and max(selected)<allocation['shape'][0], 'actual allocation geometry')
        require(all(t.dtype==torch.bfloat16 and list(t.shape)==[len(selected),128,kv_heads,128]
                    for t in [cache['before'],cache['restored'],cache['graph'],cache['reference']]),
                'retained KV payload shape or dtype differs from actual allocation')
        if not torch.equal(cache['before'],cache['restored']):errors.append('reference prestate restore differs '+key)
        if not torch.equal(cache['graph'],cache['reference']):errors.append('KV poststate differs '+key)
        base=allocation['data_ptr']
        allowed=[(address-base)//token_bytes for address in all_write_addresses
                 if address>=base and (address-base)%token_bytes==0
                 and (address-base)//block_bytes in selected]
        if full_write_errors(cache['before'],cache['graph'],cache['selected'],allowed):errors.append('Graph writes outside declared slots '+key)
        if full_write_errors(cache['before'],cache['reference'],cache['selected'],allowed):errors.append('reference writes outside declared slots '+key)
        for index,block in enumerate(cache['selected']):
            address=base+block*block_bytes
            value={stage:cache[stage][index] for stage in ('before','restored','graph','reference')}
            if address in physical_rows:
                require(all(torch.equal(value[stage],physical_rows[address][stage]) for stage in value),
                        'overlapping physical cache snapshots disagree')
            else:physical_rows[address]=value
    require(set(all_layers)=={f'{name}/{part}' for name in actual for part in (0,1)}
            and len(all_layers)==len(set(all_layers))==readers*2,'full native/Full K/V ownership coverage')
    return dict(errors=errors,readers=readers,kv_parts=readers*2,checked_hidden_rows=valid_rows,
                padded_hidden_differences=padded_hidden_differences,
                scope='RETAINED_BLOCKS_SERIAL_DIAGNOSTIC_NOT_COMPLETE_TARGET_JOIN')


class SWAReferenceWorker(SWAWindowWorker):
    def mrv2_swa_reference_install(self,output,nonce,parent_pid,source_sha):
        from tools.p7x_graph_repair25_rank_numeric import RankContract

        require(not hasattr(self,'_swa_reference'),'duplicate reference install')
        self._swa_reference=SWAReplayReference(self,output,RankContract(4,self.rank,nonce,parent_pid,source_sha))
        return dict(rank=self.rank,output=str(self._swa_reference.output),profile=self._swa_reference.profile)

    def mrv2_rank_snapshot(self):
        row=super().mrv2_rank_snapshot()
        row['swa_reference']=None if not hasattr(self,'_swa_reference') else self._swa_reference.snapshot()
        return row


def preflight(llm,record,output):
    anchor_preflight(llm,record,output)
    nonce=uuid.uuid4().hex
    record['swa_reference_contract']=dict(nonce=nonce,parent_pid=os.getpid(),source_sha=record['source_sha'])
    record['swa_reference_install']=llm.collective_rpc('mrv2_swa_reference_install',
        args=(str(Path(output)/'numeric'),nonce,os.getpid(),record['source_sha']),timeout=90)
    write(Path(output)/'campaign.json',record)


def validate_worker(worker,tp):
    anchor_worker(worker,tp)


def check(planned,execution):
    require('--owned-failure-probe' not in json.loads(Path(planned).read_text())['argv'],
            'owned failure discriminator requires raw analysis, not the three-sample acceptance checker')
    result=check_anchor(planned,execution,kwargs_factory=build_kwargs,worker_validator=validate_worker,
        entrypoint_name=Path(__file__).name,request_plan=REQUESTS,output_tokens=OUTPUT_TOKENS)
    if not result['status'].startswith('PASS_SCOPED_'):return result
    plan=json.loads(Path(planned).read_text());argv=plan['argv'];output=Path(argv[argv.index('--output')+1])
    campaign=json.loads((output/'campaign.json').read_text())
    require(plan['profile_identity']==campaign['profile_identity']==identity(),'fixed numerical scope differs')
    checked=[]
    for worker in campaign['ranks']:
        summary=worker['swa_reference'];path=Path(summary['collection'])
        require(path==output/'numeric'/f"rank-{worker['rank']}"/'numeric.json'
                and digest(path)==summary['manifest_sha256'] and summary['failed'] is False
                and summary['submission']['pending'] is False
                and {int(k):v for k,v in summary['counts'].items()}==QUOTA,'missing numerical completion/quota')
        reader=CollectionReader(path)
        require(reader.execution=='COMPLETE' and len(reader.samples)==3
                and reader.header['profile']==PROFILE and reader.header['rank']==worker['rank']
                and reader.header['source']==str(Path(argv[1]).resolve().parents[1])
                and reader.header['tool_sha256']==digest(argv[1]),'partial or foreign numerical collection')
        records=[reader.record(i) for i in range(3)]
        require({n:sum(r['identity']['actual']==n for r in records) for n in QUOTA}==QUOTA,
                'raw active-row coverage differs from declared quota')
        previous=(-1,-1)
        for record in records:
            require(record['identity']['rank']==worker['rank'],'cross-rank raw sample')
            ident=record['identity'];require(ident['generation']>previous[0] and ident['epoch']>previous[1],
                                            'stale or repeated raw generation')
            previous=(ident['generation'],ident['epoch'])
            bindings=[r for r in worker['swa_extra_window']['records'] if r.get('generation')==ident['generation']
                      and r.get('epoch')==ident['epoch']]
            require(len(bindings)==1 and bindings[0]['kind']=='WINDOW_CURRENT'
                    and all(bindings[0][key]==record[key] for key in ('requests','row_phases','full_exact','window_starts'))
                    and bindings[0]['actual']==ident['actual'] and bindings[0]['padded']==ident['padded']
                    and any(record['window_starts']),'numeric sample lacks its actual clipped Graph binding')
            require(not validate_sample(record)['errors'],'saved raw numerical/Full write mismatch')
            for cache in record['caches'].values():
                for layer_part in cache['layers']:
                    geometry=worker['draft_kv_geometry'][layer_part]
                    require(all(cache['allocation'][key]==geometry[key] for key in ('shape','stride','data_ptr','dtype')),
                            'raw KV snapshot allocation differs from actual worker geometry')
        checked.append(dict(rank=worker['rank'],samples=3,collection=str(path),sha256=digest(path)))
    result.update(status='PASS_SCOPED_SWA_SAME_PRESTATE_NUMERIC_3_PER_RANK_TP4',numeric=checked,
        target_kv='NOT_JOINED',normal_overlap='UNPROVEN_SERIAL_DIAGNOSTIC',physical_read='NOT_OBSERVED')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=('run','check'));parser.add_argument('--expected-sha')
    parser.add_argument('--tp',type=int,choices=(4,),default=4);parser.add_argument('--window-on-review',action='store_true')
    parser.add_argument('--owned-failure-probe',action='store_true')
    for name in ('admission','output','planned','execution'):parser.add_argument('--'+name,type=Path,required=name=='output')
    args=parser.parse_args()
    if args.command=='run':
        require(args.window_on_review is True,'explicit numerical ON only')
        from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay
        receipt=json.loads(args.admission.read_text())
        validate_runtime_overlay(receipt['runtime_manifest']['path'],Path(__file__).resolve().parents[1],args.expected_sha,receipt['source_tree'])
        return run_anchor(args,profile_kwargs=build_kwargs(args.tp,window_on_review=True,
            owned_failure_probe=args.owned_failure_probe),profile_identity=identity(args.owned_failure_probe),
            producer_path=__file__,before_requests=preflight,request_plan=REQUESTS,output_tokens=OUTPUT_TOKENS)
    try:result=check(args.planned,args.execution)
    except (ValueError,KeyError,TypeError,OSError,RuntimeError,IndexError) as error:result=dict(status='INVALID_EVIDENCE',error=str(error))
    write(args.output,result)
    return 0 if result['status'].startswith('PASS_SCOPED_') else 4


if __name__=='__main__':raise SystemExit(main())
