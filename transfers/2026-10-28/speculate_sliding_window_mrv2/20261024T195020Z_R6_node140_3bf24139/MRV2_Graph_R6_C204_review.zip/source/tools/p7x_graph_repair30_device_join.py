# SPDX-License-Identifier: Apache-2.0
"""Join management Host/container PID columns to actual monitored worker identity.

NSpid is relative to the observer's procfs namespace. Its first visible entry is
not necessarily the host PID. Evidence below retains the visible chain and uses
explicit management columns plus the supervisor's recorded PID/starttime.
"""
from __future__ import annotations

from datetime import datetime
import hashlib
import json
from pathlib import Path

from tools.p7x_graph_repair21_rank import digest, require

HOST_PID_SOURCE = "MANAGEMENT_PROCESS_ID_AND_PROCESS_ID_IN_CONTAINER_COLUMNS"


def validate_service_process_environment(observation, *, source, physical):
    """Check observed launch fields without inventing worker Python provenance.

    A service worker's procfs environment can omit PYTHONPATH. Native mappings
    and exact management PID/starttime still support the device association;
    actual Python module files require the separate Host worker identity RPC.
    A present but contradictory PYTHONPATH is always rejected.
    """
    require(type(physical) is int and physical >= 0, "exact physical device required")
    environment = observation["environment"]
    require(isinstance(environment, dict)
            and environment.get("ASCEND_RT_VISIBLE_DEVICES") == str(physical),
            "observed service device visibility differs")
    source = Path(source).resolve()
    path = environment.get("PYTHONPATH")
    require("PYTHONPATH" not in environment or isinstance(path, str) and bool(path)
            and Path(path.split(":")[0]).resolve() == source,
            "present worker PYTHONPATH contradicts fixed source")
    native = observation["actual_loaded_native"]
    require(isinstance(native, list) and all(isinstance(item, str) for item in native),
            "observed native mappings required")
    require(any(Path(item).resolve().is_relative_to(source) and ".so" in Path(item).name
                for item in native), "no native mapping from the fixed candidate")
    return dict(visibility="MATCH_EXPLICIT_PHYSICAL_DEVICE",
                pythonpath="MATCH_FIXED_SOURCE" if path is not None else "NOT_AVAILABLE_IN_PROC_ENVIRONMENT",
                python_module_provenance="NOT_PROVEN_BY_ENVIRONMENT_OR_NATIVE_MAPPING",
                required_python_provenance="SEPARATE_HOST_WORKER_MODULE_IDENTITY_RPC",
                native_scope="PATHS_OBSERVED_RUNTIME_MANIFEST_CHECK_REQUIRED")


def process_event(proof):
    with Path(proof["path"]).open("rb") as stream:
        stream.seek(proof["offset"])
        raw = stream.read(proof["bytes"])
    require(hashlib.sha256(raw).hexdigest() == proof["sha256"], "supervisor process evidence changed")
    return json.loads(raw)


def matching_event(event, worker, host_pid, chip, source_sha, execution):
    try:
        stamp = datetime.fromisoformat(event["utc"])
        if stamp.tzinfo is None:
            return False
        at = stamp.timestamp()
    except (KeyError, ValueError, TypeError):
        return False
    return (event.get("event") == "HEARTBEAT" and event.get("candidate") == source_sha
            and event.get("node") == worker["hostname"] and execution["start_epoch"] <= at <= execution["end_epoch"]
            and any(row["pid"] == worker["pid"] and row["start_ticks"] == worker["process_start_ticks"]
                    for row in event.get("worker_processes", []))
            and any(row["host_pid"] == str(host_pid) and row["container_pid"] == str(worker["pid"])
                    and row.get("board_chip", "").split() == chip for row in event.get("npu_observed_own_pids", [])))


def validate_association(worker, physical, association, chip, *, source_sha, execution):
    require(worker["nspid"] and worker["nspid"][-1] == str(worker["pid"]), "visible namespace PID differs from worker")
    require(
        association["rank"] == worker["rank"] and association["pid"] == worker["pid"]
        and association["physical_id"] == physical, "worker/rank/physical association mismatch")
    host_pid = association["host_pid"]
    require(
        type(host_pid) is int and host_pid > 0 and association["host_pid_source"] == HOST_PID_SOURCE,
        "explicit management host PID source required")
    require(
        association["process_start_ticks"] == worker["process_start_ticks"]
        and association["visible_nspid"] == worker["nspid"], "worker PID/starttime namespace changed")
    require(association["observations"], "no independently saved device observations")
    for observation in association["observations"]:
        path = Path(observation["path"])
        require(digest(path) == observation["sha256"], "management observation changed")
        rows = [[value.strip() for value in line.strip().strip("|").split("|")]
                for line in path.read_text().splitlines()]
        require(any(len(row) >= 5 and row[1] == "Process id" and row[4] == "Process id in container" for row in rows),
                "management PID column semantics not identified")
        require(
            any(
                len(row) >= 5 and row[0].split() == chip and row[1] == str(host_pid) and row[4] == str(worker["pid"])
                for row in rows), "missing exact management chip/HostPID/containerPID")
        event = process_event(observation["process_evidence"])
        require(matching_event(event, worker, host_pid, chip, source_sha, execution),
                "supervisor did not observe this exact PID/starttime/device identity during execution")
    return True


def collect_association(worker, physical, chip, smi_paths, event_path, *, source_sha, execution):
    """Read-only derived index; byte-range proofs retain append-only log history."""
    events = []
    offset = 0
    with Path(event_path).open("rb") as stream:
        limit = Path(event_path).stat().st_size
        while offset < limit:
            raw = stream.readline(limit - offset)
            if not raw:
                break
            try:
                event = json.loads(raw)
            except (ValueError, UnicodeError):
                offset += len(raw)
                continue
            events.append(
                (event, dict(path=str(event_path),
                             offset=offset,
                             bytes=len(raw),
                             sha256=hashlib.sha256(raw).hexdigest())))
            offset += len(raw)
    observations, host_pids = [], set()
    for path in smi_paths:
        path = Path(path)
        for line in path.read_text().splitlines():
            row = [value.strip() for value in line.strip().strip("|").split("|")]
            if len(row) < 5 or row[0].split() != chip or row[4] != str(worker["pid"]):
                continue
            require(row[1].isdigit() and int(row[1]) > 0, "management host PID unavailable")
            host_pid = int(row[1])
            proofs = [
                proof for event, proof in events if matching_event(event, worker, host_pid, chip, source_sha, execution)
            ]
            require(proofs, "management row has no matching supervisor PID/starttime proof")
            host_pids.add(host_pid)
            observations.append(dict(path=str(path), sha256=digest(path), process_evidence=proofs[0]))
    require(len(host_pids) == 1, "missing or contradictory management host PID across observations")
    result = dict(rank=worker["rank"],
                  pid=worker["pid"],
                  physical_id=physical,
                  host_pid=next(iter(host_pids)),
                  host_pid_source=HOST_PID_SOURCE,
                  process_start_ticks=worker["process_start_ticks"],
                  visible_nspid=worker["nspid"],
                  observations=observations)
    validate_association(worker, physical, result, chip, source_sha=source_sha, execution=execution)
    return result
