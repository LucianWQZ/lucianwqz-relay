# SPDX-License-Identifier: Apache-2.0
"""Isolated actual-weight first-projection discrimination, never TP16 model proof.

Prepare bounded CPU slices from the fixed DSpark checkpoint and C158's completed
raw state. A single admitted device runs the production RMSNorm/linear operators
at M8/M16. Only an exact match to both saved first-layer V arrays reproduces the
model's earliest saved divergence. No Window, Graph or precision waiver follows.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
import time

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch

from tools.p7x_graph_repair6_storage import CollectionReader
from tools.p7x_graph_repair6_submission import SubmissionState
from tools.p7x_graph_repair21_rank import digest, require, write


WEIGHTS = Path("/mnt/share/l00887471/graph_vllm/dspark_test/sw-aspark/GLM5.2_dspark/model.safetensors")
SCHEMA = "repair67-first-projection-v1"


def read_header(path):
    with Path(path).open("rb") as stream:
        size = struct.unpack("<Q", stream.read(8))[0]
        require(0 < size <= 4 << 20, "bounded safetensors header required")
        raw = stream.read(size)
    require(len(raw) == size, "truncated header")
    return json.loads(raw), 8 + size, hashlib.sha256(raw).hexdigest()


def read_rows(path, header, base, name, start, stop, expected_shape):
    entry = header[name]
    require(entry["dtype"] == "BF16" and entry["shape"] == list(expected_shape), "actual tensor identity differs")
    shape = entry["shape"]
    require(len(shape) in (1, 2) and type(start) is type(stop) is int and 0 <= start < stop <= shape[0],
            "invalid row slice")
    row_bytes = (shape[1] if len(shape) == 2 else 1) * 2
    a, b = entry["data_offsets"]
    require(type(a) is type(b) is int and 0 <= a < b and b-a == shape[0]*row_bytes
            and base+b <= Path(path).stat().st_size, "invalid tensor byte range")
    with Path(path).open("rb") as stream:
        stream.seek(base+a+start*row_bytes);raw=stream.read((stop-start)*row_bytes)
    require(len(raw) == (stop-start)*row_bytes, "truncated tensor rows")
    tensor = torch.frombuffer(bytearray(raw),dtype=torch.bfloat16).reshape((stop-start,*shape[1:]))
    return tensor,dict(name=name,rows=[start,stop],source_shape=shape,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def prepare(args):
    from safetensors.torch import save_file
    from tools.p7x_graph_repair32_glm_rank import DRAFT_CONFIG_SHA
    source = Path(__file__).resolve().parents[1]
    from tools.p7x_graph_local_candidate import BASE_SHA, _identity
    import subprocess
    tree = subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=source,text=True).strip()
    _identity(source,args.expected_sha,tree,ancestor=BASE_SHA)
    require(not args.output.exists(), "fresh prepared directory required")
    cfg_path=WEIGHTS.parent/"config.json";require(digest(cfg_path)==DRAFT_CONFIG_SHA,"actual Draft config changed")
    cfg=json.loads(cfg_path.read_text());layer=cfg["transformer_layer_config"]
    require(layer["hidden_size"]==6144 and layer["head_dim"]==192
            and layer["num_key_value_heads"]==layer["num_attention_heads"]==64
            and layer["rms_norm_eps"]==1e-5 and layer["attention_bias"] is False,
            "fixed first-layer model geometry differs")
    joint=json.loads(args.joint.read_text())
    require(joint["producer_commit"]==args.producer_sha
            and joint["status"]=="FAIL_VALID_EVIDENCE_EAGER_PADDING_CONTRAST"
            and joint["original_graph_reference_status"]=="PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC",
            "completed discriminating model evidence required")
    reader=CollectionReader(args.collection);record=reader.record(0)
    require(reader.execution=="COMPLETE" and reader.header["source_sha"]==args.producer_sha
            and record["descriptor"]==[1,2,16,8] and record["identity"]["rank"]==0
            and record["status"]=="COMPLETED_PADDING_COMPARISON","wrong completed model sample")
    ids=record["inputs"]["input_ids"];slots=record["full_slots"]
    require(ids.dtype==slots.dtype==torch.int32 and list(ids.shape)==list(slots.shape)==[16]
            and bool((slots[:8]>=0).all()) and bool((slots[8:]==-1).all()),"actual input/Full slots differ")
    header,base,header_hash=read_header(WEIGHTS);st=WEIGHTS.stat();proof=[]
    require(not any("mask_embedding" in key for key in header),"unhandled separate mask embedding")
    def rows(name,a,b,shape):
        data,p=read_rows(WEIGHTS,header,base,name,a,b,shape);proof.append(p);return data
    vectors={token:rows("embed_tokens.weight",token,token+1,[154880,6144])[0]
             for token in sorted(set(ids.tolist()))}
    embeds=torch.stack([vectors[token] for token in ids.tolist()])
    gain=rows("layers.0.input_layernorm.weight",0,6144,[6144])
    qkv=torch.cat([rows(f"layers.0.self_attn.{kind}_proj.weight",0,768,[12288,6144])
                   for kind in ("q","k","v")])
    selected=record["selected_blocks"];key="model.layers.78.self_attn.attn/1"
    def expected_v(stage):
        return torch.stack([record[stage][key][selected.index(int(s)//128),int(s)%128] for s in slots[:8]])
    values=dict(embeds=embeds,weight=qkv,norm_weight=gain,ids=ids,positions=record["inputs"]["positions"],
                expected_v16=expected_v("padded_post_kv"),expected_v8=expected_v("unpadded_post_kv"))
    require(all(bool(torch.isfinite(t).all()) for t in values.values()),"nonfinite prepared input")
    require((st.st_ino,st.st_size,st.st_mtime_ns)==(WEIGHTS.stat().st_ino,WEIGHTS.stat().st_size,WEIGHTS.stat().st_mtime_ns),
            "weights changed during bounded reads")
    args.output.mkdir(parents=True);data=args.output/"input.safetensors";save_file(values,str(data))
    write(args.output/"input.json",dict(schema=SCHEMA,source_sha=args.expected_sha,source_tree=tree,
        tool_sha256=digest(__file__),producer_sha=args.producer_sha,model_shard=0,model_world_size=16,
        actual_device_world_size=1,rms_norm_eps=1e-5,weight_nz_mode=1,
        collection=dict(path=str(args.collection),sha256=digest(args.collection)),
        joint=dict(path=str(args.joint),sha256=digest(args.joint)),
        weight_source=dict(path=str(WEIGHTS),bytes=st.st_size,mtime_ns=st.st_mtime_ns,header_sha256=header_hash,
            bounded_read_slices=proof,full_file_hash="NOT_RECOMPUTED"),
        data=dict(path=str(data),bytes=data.stat().st_size,sha256=digest(data)),
        scope="Actual model shard0 math only, not TP16 execution; exact saved V match required before attribution"))


def completed_forward(embeds,gain,weight,rows,*,norm,linear,drain,state):
    state.submit(f"RMS_LINEAR_M{rows}_PENDING")
    normalized=norm(embeds[:rows],gain,1e-5)[0]
    projected=linear(normalized,weight,None)
    drain()
    state.complete(f"RMS_LINEAR_M{rows}_COMPLETE")
    return normalized,projected


def export_failure_and_isolate(output,state,error,*,exit_fn=os._exit):
    state.failed(error)
    try:
        write(output/"failure.json",dict(error=f"{type(error).__name__}: {error}",submission=state.snapshot()))
    except Exception as flush_error:
        error.add_note(f"Host failure export also failed: {type(flush_error).__name__}: {flush_error}")
    finally:
        if state.pending:
            exit_fn(74)  # Even a Host export failure must not trigger native teardown/recovery.


@torch.inference_mode()
def run(args):
    from safetensors.torch import load_file, save_file
    from tools.p7x_graph_repair21_rank import validate_admission
    from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay
    source=Path(__file__).resolve().parents[1];receipt=json.loads(args.admission.read_text())
    manifest=json.loads((args.input/"input.json").read_text())
    require(manifest["schema"]==SCHEMA and manifest["source_sha"]==args.expected_sha
            and manifest["source_tree"]==receipt["source_tree"] and manifest["tool_sha256"]==digest(__file__)
            and digest(manifest["data"]["path"])==manifest["data"]["sha256"],"prepared input binding changed")
    validate_runtime_overlay(receipt["runtime_manifest"]["path"],source,args.expected_sha,receipt["source_tree"])
    validate_admission(args.admission,source=source,sha=args.expected_sha,tp=1)
    require(not args.output.exists(),"fresh native probe output required");args.output.mkdir(parents=True)
    state=SubmissionState();values={};records=[]
    try:
        import torch_npu
        from vllm_ascend.device.hardware_profile import get_current_hardware_profile, WeightLayoutPolicy
        require(get_current_hardware_profile().weight_layout_policy is not WeightLayoutPolicy.FORCE_NZ,
                "prepared original BF16 ND policy is not this hardware")
        data=load_file(manifest["data"]["path"])
        state.submit("INPUT_UPLOAD_PENDING")
        embeds,gain,weight=(data[key].to("npu:0") for key in ("embeds","norm_weight","weight"))
        torch.npu.current_stream().synchronize();state.complete("INPUT_UPLOAD_COMPLETE")
        fmt=torch_npu.get_npu_format(weight)
        require(fmt==2,"actual weight is not declared original ND; do not force a favorable format")
        import torch.nn.functional as functional
        # Balanced finite repeats, no Graph, Window, sampling or performance claim.
        for ordinal,rows in enumerate((16,8,8,16,16,8)):
            start=time.monotonic_ns()
            normed,projected=completed_forward(embeds,gain,weight,rows,norm=torch_npu.npu_rms_norm,
                linear=functional.linear,drain=torch.npu.current_stream().synchronize,state=state)
            completed=time.monotonic_ns()
            state.submit("COMPLETED_OUTPUT_EXPORT_PENDING")
            values[f"norm_{ordinal}"]=normed.detach().cpu().contiguous().clone()
            values[f"projected_{ordinal}"]=projected.detach().cpu().contiguous().clone()
            state.complete("COMPLETED_OUTPUT_EXPORT_COMPLETE")
            actual=values[f"projected_{ordinal}"][:8,1536:2304].reshape(8,4,192)
            expected=data[f"expected_v{rows}"]
            records.append(dict(ordinal=ordinal,rows=rows,started_ns=start,diagnostic_completed_ns=completed,
                exact_match_to_original_model_v=bool(torch.equal(actual,expected)),
                differing_original_v_elements=int(torch.count_nonzero(actual!=expected))))
        values["witness_v608_weight"]=data["weight"][2144].clone()
        saved=args.output/"outputs.safetensors";save_file(values,str(saved))
        matched=all(row["exact_match_to_original_model_v"] for row in records)
        same_norm=bool(torch.equal(values["norm_0"][:8],values["norm_1"]))
        same_projection=bool(torch.equal(values["projected_0"][:8],values["projected_1"]))
        write(args.output/"result.json",dict(schema=SCHEMA,status="REPRODUCED_ACTUAL_FIRST_V_SHAPE_DIFFERENCE" if matched and not same_projection else "NOT_REPRODUCED_OR_NO_PROJECTION_DIFFERENCE",
            source_sha=args.expected_sha,pid=os.getpid(),start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],
            hostname=os.uname().nodename,visibility=os.environ.get("ASCEND_RT_VISIBLE_DEVICES"),logical_device=0,
            versions=dict(torch=str(torch.__version__),torch_npu=str(torch_npu.__version__)),
            admission_sha256=digest(args.admission),input_manifest_sha256=digest(args.input/"input.json"),
            input_manifest=manifest,weight_format=fmt,actual_device_world_size=1,model_math_shard=0,model_math_world_size=16,
            native_operators=["torch_npu.npu_rms_norm","torch.nn.functional.linear"],
            records=records,normalized_prefix_exact=same_norm,projected_prefix_exact=same_projection,
            first_operator="GEMM_AFTER_IDENTICAL_NORMALIZED_INPUT" if same_norm and not same_projection else "NOT_ESTABLISHED",
            output=dict(path=str(saved),sha256=digest(saved),bytes=saved.stat().st_size),submission=state.snapshot(),
            acceptance="C158_ZERO_TOLERANCE_FAIL_UNCHANGED; NO_GRAPH_OR_NATIVE_PRECISION_WAIVER"))
        # Bounded management association period, outside completed computation.
        time.sleep(10)
    except BaseException as error:
        export_failure_and_isolate(args.output,state,error)
        raise


def check_saved_math(input_dir, result_path):
    """Independent CPU reconstruction; the runner verifies PID/device admission separately."""
    from safetensors import safe_open
    from safetensors.torch import load_file
    manifest=json.loads((input_dir/"input.json").read_text());result=json.loads(result_path.read_text())
    require(manifest["schema"]==result["schema"]==SCHEMA
            and result["input_manifest_sha256"]==digest(input_dir/"input.json")
            and result["source_sha"]==manifest["source_sha"]
            and manifest["data"]["sha256"]==digest(manifest["data"]["path"])
            and result["output"]["sha256"]==digest(result["output"]["path"]),"native math artifacts changed")
    require(not result["submission"]["pending"] and result["submission"]["failure"] is None
            and result["actual_device_world_size"]==1 and result["logical_device"]==0,
            "native math did not finish")
    require(digest(manifest["collection"]["path"])==manifest["collection"]["sha256"]
            and digest(manifest["joint"]["path"])==manifest["joint"]["sha256"],"original model evidence changed")
    data=load_file(manifest["data"]["path"]);output=load_file(result["output"]["path"])
    original=CollectionReader(manifest["collection"]["path"]).record(0)
    require(torch.equal(data["ids"],original["inputs"]["input_ids"]),"probe used different input IDs")
    # Use the installed safetensors reader independently of prepare's byte-offset reader.
    with safe_open(str(WEIGHTS),framework="pt",device="cpu") as weights:
        embedding=weights.get_slice("embed_tokens.weight")
        expected_embeds=torch.cat([embedding[token:token+1] for token in data["ids"].tolist()])
        expected_weight=torch.cat([weights.get_slice(f"layers.0.self_attn.{kind}_proj.weight")[:768]
                                   for kind in ("q","k","v")])
        expected_gain=weights.get_tensor("layers.0.input_layernorm.weight")
    require(torch.equal(data["embeds"],expected_embeds) and torch.equal(data["weight"],expected_weight)
            and torch.equal(data["norm_weight"],expected_gain),"manual prepared weight/embedding slices differ")
    matched=[]
    for ordinal,rows in enumerate((16,8,8,16,16,8)):
        normed,projected=output[f"norm_{ordinal}"],output[f"projected_{ordinal}"]
        require(list(normed.shape)==[rows,6144] and list(projected.shape)==[rows,2304]
                and normed.dtype==projected.dtype==torch.bfloat16
                and bool(torch.isfinite(normed).all()) and bool(torch.isfinite(projected).all()),"native tensor ABI differs")
        post=original['padded_post_kv' if rows==16 else 'unpadded_post_kv']['model.layers.78.self_attn.attn/1']
        expected=torch.stack([post[original['selected_blocks'].index(int(slot)//128),int(slot)%128]
                              for slot in original['full_slots'][:8]])
        matched.append(bool(torch.equal(projected[:8,1536:].reshape(8,4,192),expected)))
    same_norm=torch.equal(output['norm_0'][:8],output['norm_1'])
    different=not torch.equal(output['projected_0'][:8],output['projected_1'])
    repeated=all(torch.equal(output[f'projected_{i}'],output['projected_0' if rows==16 else 'projected_1'])
                 for i,rows in enumerate((16,8,8,16,16,8)))
    require(repeated,"finite native repeats changed; retain all outputs, no first-cause conclusion")
    dot=(output['norm_0'][0].double()*data['weight'][2144].double()).sum()
    return dict(status='REPRODUCED_EARLIEST_MODEL_V_IN_ISOLATED_GEMM' if all(matched) and same_norm and different else 'NOT_REPRODUCED_OR_OTHER_OPERATOR',
        exact_model_v_matches=matched,normalized_prefix_exact=bool(same_norm),projected_prefix_differs=different,
        balanced_repeats_exact=repeated,cpu_float64_witness_dot=float(dot),nearest_bf16_of_cpu_dot=float(dot.to(torch.bfloat16)),
        native_witness_m16=float(output['projected_0'][0,2144]),native_witness_m8=float(output['projected_1'][0,2144]),
        scope='CPU recheck of exact Native output/model V equality plus independent actual weight slices; external process/physical proof separate',
        original_C158_verdict='FAIL_UNCHANGED',normal_graph_completion='NOT_ASSESSED',physical_read='NOT_ASSESSED')


def main():
    parser=argparse.ArgumentParser(description=__doc__);commands=parser.add_subparsers(dest="command",required=True)
    prepare_parser=commands.add_parser("prepare")
    for key in ("collection","joint","output"):prepare_parser.add_argument("--"+key,type=Path,required=True)
    prepare_parser.add_argument("--producer-sha",required=True);prepare_parser.add_argument("--expected-sha",required=True)
    native=commands.add_parser("run")
    for key in ("input","admission","output"):native.add_argument("--"+key,type=Path,required=True)
    native.add_argument("--expected-sha",required=True)
    check=commands.add_parser("check")
    for key in ("input","result","output"):check.add_argument("--"+key,type=Path,required=True)
    args=parser.parse_args();torch.set_num_threads(2)
    if args.command=="prepare":prepare(args)
    elif args.command=="run":run(args)
    else:write(args.output,check_saved_math(args.input,args.result))
    return 0


if __name__=="__main__":
    raise SystemExit(main())
