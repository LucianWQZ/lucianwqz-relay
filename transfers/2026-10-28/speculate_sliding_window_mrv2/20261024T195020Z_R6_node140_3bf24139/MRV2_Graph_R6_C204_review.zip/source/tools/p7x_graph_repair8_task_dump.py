# SPDX-License-Identifier: Apache-2.0
"""Bounded native Graph JSON after successful, explicitly drained MRV2 LIFE.

Uses the installed NPUGraph.debug_dump API (CANN verbose flag 1), whose
version-matched Runtime source copies DEVICE kernel argument blocks to Host.
This native D2H observation is restricted to the already drained diagnostic
path. Added capture association reads existing Host tensor metadata only. No
private handles or Python tensor copies/synchronization/query are introduced;
normal completion, execution occurrence and physical KV reads remain unproven.
"""

from __future__ import annotations

import argparse
import json
import time
import sys
from pathlib import Path

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair6_storage import atomic_json, digest, require, require_space

MAX_EXPORT_BYTES = 32 << 20


FIA_KERNEL = "FusedInferAttentionScore_3b093497fc536d61a77a7a3293a524da_5000000000010200200"


def _captured_parameters():
    from vllm_ascend.compilation.acl_graph import get_draft_graph_params

    return get_draft_graph_params()


def _host_tensor(tensor):
    # Metadata only: no indexing, CPU copy, device query or synchronization.
    return dict(data_ptr=tensor.data_ptr(), shape=list(tensor.shape),
                dtype=str(tensor.dtype), device=str(tensor.device))


def _host_fia_tensor_list(parameter):
    # full_graph_fia retains weak_ref_tensors(key/value), which preserves a
    # single Tensor. Only serialize its metadata as the native one-item list;
    # never iterate/index a Tensor or replace the production parameter.
    tensors = parameter if isinstance(parameter, (list, tuple)) else (parameter,)
    require(len(tensors) == 1, "only one K/V tensor per FIA list supported")
    return [_host_tensor(tensor) for tensor in tensors]


def capture_fia_bindings(spec, desc, parameters, capture_events):
    tokens = desc.num_tokens
    params, handles, events = (getattr(parameters, name)[tokens]
                               for name in ("attn_params", "handles", "events"))
    require(len(params) == len(handles) == len(events) == len(spec.draft_attn_layer_names),
            "captured FIA parameter/handle/event/layer inventory")
    result = []
    for param, handle, event in zip(params, handles, events):
        require(isinstance(param, tuple) and len(param) == 22, "only frozen FIA.out capture tuple supported")
        observed = [r for r in capture_events if r["stage"] == "capture_operator"
                    and r["num_tokens"] == tokens and r["handle_identity"] == id(handle)
                    and r["event_identity"] == id(event)]
        require(len(observed) == 1, "capture handle/event has no unique executing layer")
        captured = observed[0]
        name = captured["layer_name"]
        require(name in spec.draft_attn_layer_names and param[-1] in (None, name), "capture layer identity")
        row = dict(layer_name=name, handle_identity=id(handle), event_identity=id(event),
                   query=_host_tensor(param[0]), key=_host_fia_tensor_list(param[1]),
                   value=_host_fia_tensor_list(param[2]), table=_host_tensor(param[3]),
                   key_parameter_form="TENSOR_SEQUENCE" if isinstance(param[1], (list, tuple)) else "SINGLE_TENSOR",
                   value_parameter_form="TENSOR_SEQUENCE" if isinstance(param[2], (list, tuple)) else "SINGLE_TENSOR",
                   output=_host_tensor(param[11]), retained_capture_kv_lengths=list(param[6]),
                   retained_capture_query_lengths=list(param[7]), host_observed_ns=time.monotonic_ns(),
                   layer_source="executing capture operator joined by handle_identity AND event_identity",
                   parameter_source="get_draft_graph_params.attn_params; existing tensor metadata only")
        require(row["table"]["data_ptr"] == captured["actual_table_address"], "capture table changed")
        result.append(row)
    require({r["layer_name"] for r in result} == set(spec.draft_attn_layer_names), "duplicate/missing captured layer")
    return result


def decode_native_fia(event, requests):
    """Decode the observed CANN9.1 folded ABI, fail closed for other layouts.

    Addr/Data relocation labels establish the argument block base. K/V list
    offsets follow installed AscendC ListTensorDescImpl; only rank3/list1 is
    admitted. Pointer roles are subsequently corroborated against captured Q,
    K, V, table and output, not inferred from task order.
    """
    import re

    require(event["name"] == FIA_KERNEL, "unsupported FIA kernel/tiling ABI")
    a = event["args"]
    require(requests in (1, 2, 4) and a["Task Type"] == "KERNEL_MIX_AIC", "unsupported native task geometry/type")
    text = a["Kernel Args"]
    pattern = re.compile(r"(?:\(placeHolder(Addr|Data)(\d+)\))?(0x[0-9a-fA-F]{16})")
    tokens = list(pattern.finditer(text))
    cursor, words, labels = 0, [], {}
    for match in tokens:
        require(not text[cursor:match.start()].strip(), "unparsed native argument bytes")
        if match.group(1):
            key = (match.group(1), int(match.group(2)))
            require(key not in labels, "duplicate native relocation label")
            labels[key] = len(words)
        words.append(int(match.group(3), 16))
        cursor = match.end()
    require(not text[cursor:].strip() and len(words) * 8 == a["Kernel Args Size"], "native argument size/grammar")
    require(set(labels) == {(kind, i) for kind in ("Addr", "Data") for i in range(5)}, "native relocation inventory")
    bases = {words[labels[("Addr", i)]] - labels[("Data", i)] * 8 for i in range(5)}
    require(len(bases) == 1 and next(iter(bases)) > 0 and next(iter(bases)) % 8 == 0,
            "inconsistent native relocation base")
    require([labels[("Addr", i)] for i in (0, 1, 2, 3, 4)] == [35, 2, 3, 6, 7],
            "unsupported native pointer prefix/layout")

    def tensor_list(index):
        start = labels[("Data", index)]
        offset = words[start]
        require(start + 6 <= len(words) and offset == 40 and words[start + 1] == 0x100000003,
                "unsupported native K/V list layout")
        return dict(data_ptr=words[start + offset // 8], shape=words[start + 2:start + 5])

    q, kv = labels[("Data", 3)], labels[("Data", 4)]
    require(q + requests <= kv and kv + requests <= len(words), "native length array bounds")
    return dict(model_id=a["Model Id"], stream_id=a["Stream Id"], task_id=a["Task Id"],
                argument_block_base=next(iter(bases)), query_ptr=words[1], table_ptr=words[15],
                output_ptr=words[32], key=tensor_list(1), value=tensor_list(2),
                query_lengths=words[q:q + requests], kv_lengths=words[kv:kv + requests])


def native_parameter_bindings(document, life, artifact):
    require(document["schema"] == "repair8-native-graph-json-v2", "native binding needs v2 producer")
    require(document["host_binding_scope"] == "AFTER_SUCCESSFUL_LIFE_DRAINS_METADATA_ONLY", "binding observation phase")
    captures = life["recorder"]["operand_events"]
    names = set(life["draft_layer_names"])
    rows = []
    for record in document["records"]:
        requests, tokens = record["descriptor"]
        bindings = record["captured_fia_bindings"]
        require(len(bindings) == len(names) and {b["layer_name"] for b in bindings} == names,
                "native binding layer inventory")
        require(all(isinstance(b["key"], list) and isinstance(b["value"], list)
                    and len(b["key"]) == len(b["value"]) == 1 for b in bindings), "Host K/V binding list inventory")
        by_pair = {(b["key"][0]["data_ptr"], b["value"][0]["data_ptr"]): b for b in bindings}
        require(len(by_pair) == len(bindings), "ambiguous K/V pointer pair across layers")
        native = json.loads((Path(artifact).parent / record["path"]).read_text())
        require(isinstance(native, list), "unsupported native JSON container")
        tasks = [e for e in native if e.get("name", "").startswith("FusedInferAttentionScore_")]
        require(len(tasks) == len(names), "native FIA task inventory")
        seen = set()
        task_ids = set()
        for event in tasks:
            require(event["pid"] == str(document["identity"]["process_id"]) + " aclGraph", "native process mismatch")
            decoded = decode_native_fia(event, requests)
            pair = (decoded["key"]["data_ptr"], decoded["value"]["data_ptr"])
            require(pair in by_pair, "native K/V pointers not in captured parameters")
            binding = by_pair[pair]
            name = binding["layer_name"]
            require(name not in seen, "native layer consumed twice")
            seen.add(name)
            task_key = tuple(decoded[k] for k in ("model_id", "stream_id", "task_id"))
            require(task_key not in task_ids, "duplicate native task context")
            task_ids.add(task_key)
            capture = [r for r in captures if r["stage"] == "capture_operator" and r["num_tokens"] == tokens
                       and r["layer_name"] == name and r["handle_identity"] == binding["handle_identity"]
                       and r["event_identity"] == binding["event_identity"]]
            require(len(capture) == 1, "capture layer/handle/event association")
            capture = capture[0]
            update = [r for r in captures if r["stage"] == "update_operator" and r["num_tokens"] == tokens
                      and r["layer_name"] == name and r["generation_id"] == record["last_life_generation"]]
            require(len(update) == 1 and update[0]["mapping_epoch"] == record["last_life_epoch"], "last UPDATE layer/generation")
            update = update[0]
            require(record["start_ns"] <= binding["host_observed_ns"] < record["end_ns"], "Host binding interval")
            for field, pointer in (("query", "query_ptr"), ("table", "table_ptr"), ("output", "output_ptr")):
                require(binding[field]["device"] == "npu:0", "Host binding logical device")
                require(binding[field]["data_ptr"] == decoded[pointer], "native " + field + " pointer mismatch")
            require(decoded["table_ptr"] == capture["actual_table_address"] == update["actual_table_address"], "native/operator table")
            require(binding["table"]["shape"] == [requests, 32] and binding["table"]["dtype"] == "torch.int32", "frozen table geometry")
            for field in ("key", "value"):
                require(len(binding[field]) == 1 and binding[field][0]["shape"] == decoded[field]["shape"]
                        and binding[field][0]["dtype"] == "torch.bfloat16"
                        and binding[field][0]["device"] == "npu:0", "native K/V geometry/dtype/device")
            require(decoded["query_lengths"] == binding["retained_capture_query_lengths"]
                    == [7 * (i + 1) for i in range(requests)], "native query lengths")
            require(binding["retained_capture_kv_lengths"] == capture["length_values"], "capture KV length provenance")
            require(decoded["kv_lengths"] == update["length_values"], "native lengths differ from last UPDATE")
            candidates = sorted({r["generation_id"] for r in captures if r["stage"] == "update_operator"
                                 and r["num_tokens"] == tokens and r["layer_name"] == name
                                 and r["length_values"] == decoded["kv_lengths"]})
            rows.append(dict(descriptor=record["descriptor"], layer_name=name, native=decoded,
                             parameter_values_match_host_generation=record["last_life_generation"],
                             capture_values_distinguishable=decoded["kv_lengths"] != capture["length_values"],
                             parameter_generation_candidates=candidates,
                             task_execution_occurrence="UNPROVEN_POST_DRAIN_EXPORT_ONLY"))
        require(seen == names, "missing native layer")
    distinguishable = all(r["capture_values_distinguishable"]
                          and r["parameter_generation_candidates"] == [r["parameter_values_match_host_generation"]] for r in rows)
    return dict(status="DIAGNOSTIC_POST_DRAIN_NATIVE_PARAMETER_BINDING" if distinguishable
                else "OPEN_NATIVE_GENERATION_NOT_DISTINGUISHABLE", tasks=rows,
                execution_occurrence_generation="UNPROVEN", physical_read="UNPROVEN",
                normal_backing_reuse="UNPROVEN")


def completed_graph_dump(spec, lifecycle, output, identity, *, host_bindings=False):
    require(lifecycle is not None and not lifecycle.poisoned, "native dump requires successful LIFE")
    require(lifecycle.records and all(r.get("completion") == "DIAGNOSTIC_COMPLETE"
                                    and r.get("retired") for r in lifecycle.records), "LIFE not drained/retired")
    require(not getattr(spec, "_draft_window_graph_submission_uncertain", False), "uncertain Graph cannot be inspected")
    output = Path(output)
    directory = output.parent / "native-graph-json"
    directory.mkdir(exist_ok=False)
    require_space(directory, 128 << 20)
    records = []
    document = dict(schema="repair8-native-graph-json-v1", identity=identity, records=records,
                    status="PREPARING", source="NPUGraph.debug_dump -> aclmdlRIDebugJsonPrint(flags=1)",
                    collection_phase="AFTER_ALL_DIAGNOSTIC_LIFE_DRAINS_AND_RETIREMENT",
                    normal_timing="NOT_REPRESENTATIVE", native_parameter_version="UNRESOLVED_CAPTURE_VS_LAST_UPDATE",
                    task_operand="UNPROVEN_PENDING_FIELD_ANALYSIS", physical_read="UNPROVEN",
                    native_observation=dict(
                        kernel_argument_d2h="SYNCHRONOUS_DEVICE_TO_HOST_IN_CANN_VERBOSE_API",
                        source_contract="official Runtime v9.1.0 Stream::SetTraceKernelArgs -> Driver::MemCopySync",
                        timing_scope="AFTER_ALL_LIFE_DRAINS; NOT_NORMAL_PATH_OR_DEVICE_COMPLETION_PROOF",
                        additional_host_capture_metadata="NO_PYTHON_TENSOR_COPY_SYNC_OR_QUERY",
                        native_json_ts_dur="SYNTHETIC_LAYOUT_NOT_MEASURED_DEVICE_TIME"))
    atomic_json(output, document)
    if host_bindings:
        document.update(schema="repair8-native-graph-json-v2",
                        host_binding_scope="AFTER_SUCCESSFUL_LIFE_DRAINS_METADATA_ONLY")
        capture_events = json.loads(lifecycle.output.read_text())["recorder"]["operand_events"]
        parameters = _captured_parameters()
    total = 0
    for desc, graph in sorted(spec.query_cudagraph_manager.graphs.items(), key=lambda item: item[0].num_tokens):
        matching = [r for r in lifecycle.records if r["descriptor"] == [desc.num_reqs, desc.num_tokens]]
        require(matching, "no completed LIFE observation for captured descriptor")
        path = directory / f"draft-{desc.num_reqs}-{desc.num_tokens}.json"
        row = dict(descriptor=[desc.num_reqs, desc.num_tokens], path=str(path.relative_to(output.parent)),
                   last_life_generation=matching[-1]["generation"], last_life_epoch=matching[-1]["epoch"],
                   backing=matching[-1]["backing"], status="PREPARING", start_ns=time.monotonic_ns())
        records.append(row)
        atomic_json(output, document)
        try:
            if host_bindings:
                row["captured_fia_bindings"] = capture_fia_bindings(spec, desc, parameters, capture_events)
            graph.debug_dump(str(path))  # Native argument D2H is allowed only after the explicit LIFE drains.
            require(path.is_file(), "native JSON not produced")
            size = path.stat().st_size
            total += size
            require(0 < size and total <= MAX_EXPORT_BYTES, "native JSON exceeds bounded review budget")
            parsed = json.loads(path.read_text())
            require(isinstance(parsed, (dict, list)), "native JSON root type")
            row.update(status="EXPORTED_JSON_NOT_OPERAND_PROOF", bytes=size, sha256=digest(path),
                       end_ns=time.monotonic_ns(), root_type=type(parsed).__name__)
        except Exception as error:
            row.update(status="EXPORT_FAILED", error=repr(error), end_ns=time.monotonic_ns())
            document["status"] = "EXPORT_FAILED"
            atomic_json(output, document)
            return document
        atomic_json(output, document)
    document.update(status="COLLECTED_NO_OPERAND_CLAIM", total_bytes=total)
    atomic_json(output, document)
    return document


def check(document, campaign, launcher, expected, artifact, *, native_bindings=False):
    from tools.p7x_graph_repair5_evidence import audit_execution

    result = dict(status="INVALID_EVIDENCE", task_operand="UNPROVEN", physical_read="UNPROVEN")
    try:
        result["execution"] = audit_execution(document, campaign, launcher, expected, artifact)
        require(result["execution"]["status"] == "EXECUTION_ASSOCIATED", "native export execution not associated")
        require(document["status"] == "COLLECTED_NO_OPERAND_CLAIM", "native export incomplete")
        records = document["records"]
        require({tuple(r["descriptor"]) for r in records} == {(1, 7), (2, 14), (4, 28)}
                and len(records) == 3, "native descriptor inventory")
        life_path = Path(artifact).parent / "mrv2-lifecycle.json"
        life = json.loads(life_path.read_text())
        indexed = campaign["diagnostic_artifacts"][life_path.name]
        require(digest(life_path) == indexed["sha256"] and life_path.stat().st_size == indexed["bytes"], "LIFE hash")
        require(life["identity"] == document["identity"], "native/LIFE identity")
        for row in records:
            path = Path(artifact).parent / row["path"]
            require(path.resolve().is_relative_to(Path(artifact).parent.resolve()), "export outside artifact root")
            require(row["status"] == "EXPORTED_JSON_NOT_OPERAND_PROOF" and digest(path) == row["sha256"]
                    and path.stat().st_size == row["bytes"] > 0, "native JSON bytes/hash/status")
            require(launcher["host_start_ns"] <= row["start_ns"] < row["end_ns"] <= launcher["host_end_ns"], "export interval")
            matching = [r for r in life["records"] if r["descriptor"] == row["descriptor"]]
            require(matching and all(r["completion"] == "DIAGNOSTIC_COMPLETE" and r["retired"] for r in matching), "LIFE completion")
            last = matching[-1]
            require(last["generation"] == row["last_life_generation"] and last["epoch"] == row["last_life_epoch"]
                    and last["backing"] == row["backing"] and last["complete_ns"] < row["start_ns"], "last LIFE/export join")
            json.loads(path.read_text())
        require(sum(r["bytes"] for r in records) == document["total_bytes"] <= MAX_EXPORT_BYTES, "export total budget")
        result.update(status="PASS_SCOPED_NATIVE_JSON_COLLECTION", files=len(records), bytes=document["total_bytes"])
        if native_bindings:
            result["binding"] = native_parameter_bindings(document, life, artifact)
            result.update(status="PASS_DIAGNOSTIC_NATIVE_PARAMETER_BINDING"
                          if result["binding"]["status"] == "DIAGNOSTIC_POST_DRAIN_NATIVE_PARAMETER_BINDING"
                          else "OPEN_NATIVE_GENERATION_NOT_DISTINGUISHABLE",
                          task_operand="POST_DRAIN_EXPORTED_PARAMETERS_ONLY")
    except (KeyError, ValueError, TypeError, OSError, IndexError, AttributeError) as error:
        result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("artifact", "campaign", "launcher", "plan", "output"):
        parser.add_argument("--" + name, required=True, type=Path)
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--native-bindings", action="store_true")
    args = parser.parse_args()
    result = check(json.loads(args.artifact.read_text()), json.loads(args.campaign.read_text()),
                   json.loads(args.launcher.read_text()), json.loads(args.plan.read_text())["cases"][args.case_id],
                   args.artifact, native_bindings=args.native_bindings)
    atomic_json(args.output, result)
    return 0 if result["status"] in ("PASS_SCOPED_NATIVE_JSON_COLLECTION", "PASS_DIAGNOSTIC_NATIVE_PARAMETER_BINDING") else 4


if __name__ == "__main__":
    raise SystemExit(main())
