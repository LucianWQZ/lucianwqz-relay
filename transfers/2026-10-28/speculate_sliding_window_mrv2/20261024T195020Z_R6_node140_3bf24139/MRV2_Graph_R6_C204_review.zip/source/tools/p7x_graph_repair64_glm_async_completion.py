# SPDX-License-Identifier: Apache-2.0
"""Observe existing eager completion decisions, without adding device operations.

One diagnostic service arm uses normal Async overlap. A token proxy forwards
each existing query/wait exactly once and keeps CPU headers only. This is not
a formal performance arm, Graph backing proof, or physical-read observation.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import json
import time
from types import MethodType

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair32_glm_rank import TARGET, profile_identity
from tools.p7x_graph_repair33_service import run_service
from tools.p7x_graph_repair59_glm_service_phases import (
    GLMPhaseWorker, PROFILE as PHASE_PROFILE, phase_serve_argv, check_saved as check_phases,
)

PROFILE = 'GLM_TP16_EAGER_EXISTING_COMPLETION_EVENT_AUDIT_V1'
EXTENSION = 'tools.p7x_graph_repair64_glm_async_completion.GLMCompletionWorker'
MAX_RECORDS = 32768
ACCEPTED = 'PASS_SCOPED_ALL16_EXISTING_EAGER_EVENT_COMPLETION_AND_REUSE'


def handle_header(handle):
    inputs = handle.inputs
    return dict(operation=handle.operation_id, epoch=handle.mapping_epoch,
        requests=list(handle.ordered_request_fingerprint), lane=handle.execution_lane,
        state=handle.state.value, generation=None if inputs is None else inputs.identity.generation_id,
        preparation_started=handle.preparation_started, consumer_started=handle.consumer_started,
        metadata_owned=handle.bound_metadata is not None,
        headers=None if inputs is None else {name: dict(pointer=getattr(inputs, name).data_ptr(),
            shape=list(getattr(inputs, name).shape), dtype=str(getattr(inputs, name).dtype))
            for name in ('window_block_table', 'device_window_exact', 'cpu_window_exact')})


class ExistingCompletionToken:
    """No new event, query, wait or retained tensor/metadata owner."""

    def __init__(self, token, audit, identity):
        self.original, self.audit, self.identity = token, audit, identity

    def is_complete(self):
        # One call to the exact production token. No progress poll is added.
        result = self.original.is_complete()
        self.audit.token_result('QUERY_RETURN', self.identity, complete=result)
        return result

    def wait(self):
        # Only the existing pool-pressure path invokes this method.
        self.original.wait()
        self.audit.token_result('PRESSURE_WAIT_RETURN', self.identity)


class CompletionAudit:
    def __init__(self, spec):
        self.spec = spec
        self.pool = spec._draft_window_async_pool
        require(self.pool is not None and self.pool.capacity == 2
                and all(handle is None for handle in self.pool._active), 'empty two-lane eager pool required')
        self.rows, self.truncated = [], False

    def emit(self, kind, **value):
        if len(self.rows) >= MAX_RECORDS:
            self.truncated = True
            return
        self.rows.append(dict(kind=kind, host_ns=time.monotonic_ns(), **value))

    def token_result(self, kind, identity, **value):
        handle = self.pool._active[identity['lane']]
        owner = None if handle is None else handle_header(handle)
        self.emit(kind, identity=identity, owner=owner, **value)

    def install(self):
        # Worker-only import after normal ops initialization; CLI/read-only
        # parsers must not force the attention/device-op circular import.
        from vllm_ascend.worker.v2.spec_decode.draft_window_async import DraftWindowNPUEventCompletionToken

        audit = self
        for name in ('acquire', 'materialize', 'bind', 'mark_consumer_started', 'submit', 'retire', 'release'):
            original = getattr(self.pool, name)

            def make_wrapper(name, original):
                def invoke(_pool, *args, **kwargs):
                    handle = None if name == 'acquire' else args[0]
                    before = None if handle is None else handle_header(handle)
                    result = original(*args, **kwargs)
                    current = result if name == 'acquire' else handle
                    audit.emit(name.upper()+'_RETURN', before=before, after=handle_header(current),
                        lane_owned=_pool._active[current.execution_lane] is current)
                    return result
                return MethodType(invoke, self.pool)

            setattr(self.pool, name, make_wrapper(name, original))
        factory = self.spec._draft_window_completion_token_factory

        def record_existing_event():
            token = factory()
            require(type(token) is DraftWindowNPUEventCompletionToken and token._recorded,
                    'the unchanged production factory must record the real completion token')
            identity = handle_header(audit.spec._draft_window_async_handle)
            audit.emit('TOKEN_RECORDED', identity=identity,
                token_class=type(token).__module__+'.'+type(token).__qualname__,
                event_class=type(token.event).__module__+'.'+type(token.event).__qualname__)
            return ExistingCompletionToken(token, audit, identity)

        self.spec._draft_window_completion_token_factory = record_existing_event

    def snapshot(self):
        return dict(records=list(self.rows), truncated=self.truncated, capacity=self.pool.capacity,
            added_device_operations='NONE', retained_tensor_owners='NONE_BY_AUDIT',
            completion_factory='UNCHANGED_PRODUCTION_CURRENT_STREAM_EVENT',
            scope='Actual existing event query/wait returns and CPU ownership transitions; no extra query/sync/D2H')


class GLMCompletionWorker(GLMPhaseWorker):
    def mrv2_service_worker_identity(self, nonce):
        if not hasattr(self, '_mrv2_completion_audit'):
            self._mrv2_completion_audit = CompletionAudit(self.model_runner.speculator)
            self._mrv2_completion_audit.install()
        row = super().mrv2_service_worker_identity(nonce)
        row['completion_extension'] = dict(path=__file__, sha256=digest(__file__))
        row['normal_completion_audit'] = self._mrv2_completion_audit.snapshot()
        return row


def serve_argv(python, port, model, arm, *, worker_provenance=False):
    require(arm == 'E_ON', 'normal eager completion is an explicit E_ON-only diagnostic')
    argv = phase_serve_argv(python, port, model, arm, worker_provenance=worker_provenance)
    argv[argv.index('--worker-extension-cls')+1] = EXTENSION
    return argv


def validate_completion(document, sources):
    require(document['truncated'] is False and document['capacity'] == 2
            and document['added_device_operations'] == 'NONE'
            and document['retained_tensor_owners'] == 'NONE_BY_AUDIT'
            and document['completion_factory'] == 'UNCHANGED_PRODUCTION_CURRENT_STREAM_EVENT',
            'incomplete or intrusive completion audit')
    rows = document['records']
    require(rows and all(type(row['host_ns']) is int for row in rows)
            and all(a['host_ns'] < b['host_ns'] for a,b in zip(rows,rows[1:])),
            'complete ordered CPU observations required')
    operations, lanes, reused, waits, pending_queries = {}, {}, {}, 0, 0
    headers = {}
    def source_key(row):
        return (row['epoch'],row['generation'],row['execution_lane'],tuple(row['requests']))
    source_keys=[source_key(row) for row in sources]
    require(source_keys and len(set(source_keys))==len(source_keys), 'current source materializations incomplete')
    actual_keys=[]
    for row in rows:
        kind = row['kind']
        if kind == 'ACQUIRE_RETURN':
            current = row['after']; op, lane = current['operation'], current['lane']
            require(type(op) is type(lane) is type(current['epoch']) is int
                    and lane in (0,1) and op not in operations and lane not in lanes
                    and current['state'] == 'acquired' and row['lane_owned'] is True,
                    'lane acquired while an earlier reader is still owned')
            operations[op] = dict(identity=current, complete=False, events=set(), pointer=None)
            lanes[lane] = op
        elif kind in ('QUERY_RETURN','PRESSURE_WAIT_RETURN','TOKEN_RECORDED'):
            current=row['identity']; op=current['operation']; state=operations[op]
            require(lanes.get(current['lane']) == op and current['headers'] == state['pointer']
                    and current['epoch'] == state['identity']['epoch'], 'completion belongs to another owned operation')
            if kind == 'TOKEN_RECORDED':
                require(current['state'] == 'bound' and current['consumer_started'] is True
                        and current['metadata_owned'] is True and 'TOKEN_RECORDED' not in state['events']
                        and row['event_class'].startswith('torch_npu.') and row['event_class'].endswith('.Event')
                        and row['token_class'].endswith('.DraftWindowNPUEventCompletionToken'),
                        'production reader-tail event missing or not a native NPU token')
            else:
                require('TOKEN_RECORDED' in state['events'] and row['owner'] is not None
                        and row['owner']['operation'] == op and row['owner']['headers'] == state['pointer']
                        and row['owner']['metadata_owned'] is True,
                        'event queried after releasing its actual backing')
                if kind == 'QUERY_RETURN':
                    require(type(row['complete']) is bool, 'actual existing query must return a bool')
                    state['complete'] |= row['complete']
                    pending_queries += int(not row['complete'])
                else:
                    waits += 1
            state['events'].add(kind)
        else:
            before,current=row['before'],row['after'];op=current['operation'];state=operations[op];lane=current['lane']
            require(lanes.get(lane)==op and row['lane_owned'] is (kind!='RELEASE_RETURN'),
                    'pool owner changed before the declared release')
            if kind == 'MATERIALIZE_RETURN':
                require(current['state']=='materialized' and current['preparation_started'] is True
                        and type(current['generation']) is int and current['headers']
                        and all(v['dtype']=='torch.int32' and type(v['pointer']) is int and v['pointer']>0
                                for v in current['headers'].values()), 'current materialized owner missing')
                key=(current['epoch'],current['generation'],lane,tuple(current['requests']))
                require(key in source_keys, 'completion owner is not a real current Window materialization')
                actual_keys.append(key)
                state['pointer']=current['headers']
                # CPU exact vectors are generation-owned allocations. The
                # fixed device lanes may expose different active-row shapes.
                backing={key:current['headers'][key]['pointer']
                         for key in ('window_block_table','device_window_exact')}
                previous=headers.setdefault(lane,backing)
                require(previous==backing, 'bounded device lane backing unexpectedly changed')
            elif kind in ('BIND_RETURN','MARK_CONSUMER_STARTED_RETURN','SUBMIT_RETURN','RETIRE_RETURN'):
                require(current['headers']==state['pointer'] and current['metadata_owned'] is True,
                        'actual reader backing cleared before completion')
                expected={'BIND_RETURN':'bound','MARK_CONSUMER_STARTED_RETURN':'bound',
                          'SUBMIT_RETURN':'submitted','RETIRE_RETURN':'retired'}[kind]
                require(current['state']==expected, 'normal state transition differs')
                if kind=='RETIRE_RETURN':
                    require(state['complete'] and before['state']=='consumer_complete',
                            'retired before the real event query returned true')
            elif kind == 'RELEASE_RETURN':
                require(state['complete'] and 'RETIRE_RETURN' in state['events']
                        and before['state']=='retired' and before['headers']==state['pointer']
                        and current['state']=='free' and current['headers'] is None
                        and current['metadata_owned'] is False, 'backing released without reader completion')
                reused[lane]=reused.get(lane,0)+1;del lanes[lane]
            else:
                raise ValueError('unknown completion audit event: '+kind)
            state['events'].add(kind)
    require(set(headers)=={0,1} and set(reused)=={0,1} and min(reused.values())>=3,
            'both bounded lanes must have actual repeated completed reuse')
    require(len(actual_keys)==len(source_keys) and set(actual_keys)==set(source_keys),
            'completion audit and original source disagree on actual generations')
    require(all(headers[0][key] != headers[1][key] for key in headers[0]),
            'independent lanes alias their table backing')
    return dict(operations=len(operations),completed_releases=sum(reused.values()),
        releases_by_lane=reused,still_owned_operations=list(lanes.values()),existing_pressure_waits=waits,
        actual_pending_query_returns=pending_queries,
        additional_event_queries=0,normal_graph_backing='SOURCE_CONTRACT_SEPARATE',
        native_overlap='NOT_INFERRED_FROM_CPU_OWNERS',
        scope='Existing normal eager event decisions and ownership, not tensor numeric or physical read')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=('run','check'))
    p.add_argument('--arm',choices=('E_ON',),default='E_ON')
    p.add_argument('--expected-sha',required=True);p.add_argument('--port',type=int,required=True)
    for key in ('requests','output','admission','campaign','records','server-argv'):
        p.add_argument('--'+key,type=Path,required=key in ('requests','output'))
    args=p.parse_args()
    if args.command=='run':
        args.worker_provenance=True
        return run_service(args,server_argv_builder=serve_argv,target_model=str(TARGET),tp=16,
            ready_timeout_seconds=1800,extra_metadata=dict(phase_profile=PHASE_PROFILE,
                completion_profile=PROFILE,completion_tool_sha256=digest(__file__),profile_identity=profile_identity()))
    try:
        campaign=json.loads(args.campaign.read_text())
        require(campaign['completion_profile']==PROFILE and campaign['completion_tool_sha256']==digest(__file__),
                'actual completion extension differs')
        # Preserve the complete shared service/phase/feature/rank oracle. The
        # explicit CLI builder changes only this diagnostic extension name.
        result=check_phases(args,worker_extension_cls=EXTENSION,server_argv_builder=serve_argv)
        rows=campaign['worker_provenance'][-1]['results']
        checked=[]
        for row in rows:
            require(row['completion_extension']==dict(path=__file__,sha256=digest(__file__)),
                    'completion observer is not this actual loaded file')
            checked.append(dict(rank=row['rank_snapshot']['rank'],**validate_completion(
                row['normal_completion_audit'],row['rank_snapshot']['window_generations'])))
        require(sorted(row['rank'] for row in checked)==list(range(16)), 'complete actual rank audits required')
        result.update(status=ACCEPTED,completion_audits=checked,token_correctness='C151_FAILURE_SEPARATE',
                      performance='NOT_FORMAL_TIMING',physical_read='NOT_OBSERVED')
    except (ValueError,KeyError,TypeError,IndexError,OSError) as error:
        result=dict(status='INVALID_NORMAL_COMPLETION_EVIDENCE',error=f'{type(error).__name__}: {error}')
    write(args.output,result)
    return 0 if result['status']==ACCEPTED else 4


if __name__=='__main__':
    raise SystemExit(main())
