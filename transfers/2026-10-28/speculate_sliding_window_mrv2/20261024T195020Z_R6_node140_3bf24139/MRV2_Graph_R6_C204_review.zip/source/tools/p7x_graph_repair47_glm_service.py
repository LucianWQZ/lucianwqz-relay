# SPDX-License-Identifier: Apache-2.0
"""Official GLM TP16 HTTP anchor, with explicit out-of-request rank observations.

Prefix is a separate explicit service arm with native API cached-token usage
and CPU proposal phases. Async/FlashComm/DSA-CP retain their existing guards.
CPU dispatch records distinguish actual Draft replay from HTTP success; this
is an audit arm, not an uninstrumented performance or completion proof.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import inspect
import json
import time
from functools import partial
from types import MethodType

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair32_glm_rank import (
    TARGET, build_glm_kwargs, profile_identity, validate_glm_worker,
)
from tools.p7x_graph_repair33_service import run_service, serve_argv, validate_requests
from tools.p7x_graph_repair39_service_identity import host_worker_identity, validate_worker_identity
from tools.p7x_graph_repair40_glm_performance import GLMPerformanceWorker, validate_ranks

EXTENSION = 'tools.p7x_graph_repair47_glm_service.GLMServiceWorker'
MAX_PHASE_RECORDS = 4096


def install_phase_audit(worker, *, detailed=False):
    """CPU InputBatch facts only, at actual propose; not all Target stages."""
    # This producer is also imported by the Host launcher to prepare argv.
    # Load production interfaces only in the pinned actual worker environment.
    from vllm_ascend.worker.v2.spec_decode.draft_window_nongraph import classify_draft_window_batch_phase

    require(type(detailed) is bool, 'explicit CPU-only phase-detail mode required')
    limit = getattr(worker, '_mrv2_phase_record_limit', MAX_PHASE_RECORDS)
    require(type(limit) is int and limit in (MAX_PHASE_RECORDS, 16384), 'bounded declared Host phase audit limit')
    spec = worker.model_runner.speculator
    original = spec.propose
    signature = inspect.signature(original)
    worker._mrv2_service_phases = []
    worker._mrv2_service_phases_truncated = False

    def propose(_spec, *args, **kwargs):
        record = None
        try:
            bound = signature.bind(*args, **kwargs)
            if not bound.arguments.get('dummy_run', False) and not bound.arguments.get('is_profile', False):
                if len(worker._mrv2_service_phases) >= limit:
                    worker._mrv2_service_phases_truncated = True
                else:
                    record = dict(returned=False)
                    worker._mrv2_service_phases.append(record)
                    plan = classify_draft_window_batch_phase(bound.arguments['input_batch'])
                    record.update(batch_phase=plan.batch_phase.value,
                                  row_phases=[phase.value for phase in plan.row_phases],
                                  requests=list(plan.ordered_request_fingerprint))
                    if detailed:
                        batch = bound.arguments['input_batch']
                        n = int(batch.num_reqs)
                        record.update(start_ns=time.monotonic_ns(), raw_cpu_rows=dict(
                            request_ids=list(batch.req_ids[:n]),
                            computed=batch.num_computed_prefill_tokens_np[:n].tolist(),
                            scheduled=batch.num_scheduled_tokens[:n].tolist(),
                            prefill=batch.prefill_len_np[:n].tolist(),
                            is_prefilling=batch.is_prefilling_np[:n].tolist()))
                        record['_source_begin'] = len(worker._mrv2_rank_window_generations)
                        record['_manager_begin'] = len(worker._mrv2_rank_replay_records)
        except (ValueError, RuntimeError, TypeError, AttributeError, KeyError) as error:
            if record is not None:
                record['classification_error'] = repr(error)
        try:
            value = original(*args, **kwargs)
            if record is not None:
                record['returned'] = True
            return value
        finally:
            if detailed and record is not None and '_source_begin' in record:
                record.update(end_ns=time.monotonic_ns(),
                    flags_after={name: bool(getattr(spec, name, False)) for name in (
                        '_draft_window_bypass_active', '_draft_window_prefill_bypass_active')},
                    window_materializations=[dict(row) for row in worker._mrv2_rank_window_generations[
                        record.pop('_source_begin'):]],
                    manager_calls=[dict(row) for row in worker._mrv2_rank_replay_records[
                        record.pop('_manager_begin'):]])

    spec.propose = MethodType(propose, spec)


class GLMServiceWorker(GLMPerformanceWorker):
    def mrv2_service_worker_identity(self, nonce):
        # RPC occurs before/after whole HTTP groups. Existing Host-only dispatch
        # hooks record calls; no tensor read, event query or extra device work.
        if not hasattr(self, '_mrv2_rank_replay_records'):
            self.mrv2_rank_install_dispatch_observer()
        prefix = self.vllm_config.cache_config.enable_prefix_caching
        if prefix and not hasattr(self, '_mrv2_service_phases'):
            install_phase_audit(self, detailed=bool(getattr(self, 'service_phase_details', False)))
        row = host_worker_identity(self, nonce)
        row['rank_snapshot'] = self.mrv2_rank_snapshot()
        spec = self.model_runner.speculator
        capability = getattr(spec, '_draft_window_source_capability', None)
        topology = getattr(capability, 'eager_topology_fingerprint', None)
        provider = getattr(spec, '_draft_window_graph_binding_provider', None)
        row.update(effective_prefix_caching=prefix,
                   source_prefix_caching=None if topology is None else topology.prefix_caching,
                   capture_prefix_modes=sorted({c.capture_identity.fingerprint.prefix_caching
                                                for c in getattr(provider, '_carriers', {}).values()}),
                   proposal_phases=getattr(self, '_mrv2_service_phases', []),
                   proposal_phases_truncated=getattr(self, '_mrv2_service_phases_truncated', False))
        if getattr(self, 'service_phase_details', False):
            row['proposal_phase_detail_schema'] = 2
        return row


def glm_serve_argv(python, port, model_name, arm, *, worker_provenance=False, prefix_caching=False):
    require(arm in ('G_OFF', 'G_ON', 'E_ON'), 'named GLM service arm required')
    require(worker_provenance is True, 'this audit requires explicit all-rank provenance')
    require(type(prefix_caching) is bool, 'typed prefix service configuration required')
    kwargs = build_glm_kwargs(16, window_on_review=arm == 'G_ON')
    if arm == 'E_ON':
        kwargs['speculative_config']['enforce_eager'] = True
        kwargs['additional_config'] = dict(draft_window_size=1024)
    argv = serve_argv(python, port, model_name, arm, worker_provenance=True)
    argv[argv.index('serve')+1] = kwargs['model']
    for flag, value in [('--tensor-parallel-size', '16'),
                        ('--speculative-config', json.dumps(kwargs['speculative_config'], sort_keys=True)),
                        ('--compilation-config', json.dumps(kwargs['compilation_config'], sort_keys=True)),
                        ('--additional-config', json.dumps(kwargs['additional_config'], sort_keys=True)),
                        ('--worker-extension-cls', EXTENSION)]:
        argv[argv.index(flag)+1] = value
    argv += ['--data-parallel-size', '1', '--enable-expert-parallel', '--trust-remote-code',
             '--quantization', 'ascend', '--hf-overrides', json.dumps(kwargs['hf_overrides'], sort_keys=True),
             '--distributed-executor-backend', 'mp']
    if prefix_caching:
        argv[argv.index('--no-enable-prefix-caching')] = '--enable-prefix-caching'
        argv += ['--enable-prompt-tokens-details']
    return argv


def validate_service_workers(rows, *, nonce, source, vllm_source, arm, capture_contract=None):
    require(arm in ('G_OFF', 'G_ON', 'E_ON') and isinstance(rows, list) and len(rows) == 16,
            'complete actual GLM TP16 worker set required')
    snapshots = [row['rank_snapshot'] for row in rows]
    require(all(type(s['rank']) is int and s['tp_size'] == s['world_size'] == 16 for s in snapshots)
            and sorted(s['rank'] for s in snapshots) == list(range(16))
            and len({s['pid'] for s in snapshots}) == 16, 'missing, duplicate or foreign service rank')
    identities = []
    for row, snapshot in zip(rows, snapshots):
        # Reuse only the single-worker Python/native provenance assertions.
        # Complete TP16 topology and GLM geometry are checked independently here.
        identity = validate_worker_identity([row], nonce=nonce, source=source, vllm_source=vllm_source, arm=arm)
        require(snapshot['pid'] == row['pid']
                and snapshot['process_start_ticks'] == row['process_start_ticks'], 'rank/provenance PID mismatch')
        validate_glm_worker(snapshot, 16, draft_graph=arm != 'E_ON', capture_contract=capture_contract)
        identities.append(dict(rank=snapshot['rank'], **identity))
    return dict(status='ALL_16_SERVICE_WORKER_PROVENANCE', workers=sorted(identities, key=lambda x:x['rank']))


def validate_prefix_hits(campaign, document):
    rows = campaign['worker_provenance'][-1]['results']
    require(len(rows) == 16 and all(row['effective_prefix_caching'] is True for row in rows),
            'prefix was requested but not effective on every actual worker')
    if campaign['arm'] != 'G_OFF':
        require(all(row['source_prefix_caching'] is True for row in rows), 'Window source lost prefix identity')
    if campaign['arm'] == 'G_ON':
        require(all(row['capture_prefix_modes'] == [True] for row in rows), 'capture did not retain prefix identity')
    cached = []
    for group in document['groups']:
        for result in group['results']:
            usage = result['summary']['usage']
            count = usage['prompt_tokens_details']['cached_tokens']
            require(type(count) is int and 0 <= count <= usage['prompt_tokens'],
                    'actual server cached-token usage missing or contradictory')
            cached.append(dict(phase=group['phase'], label=group['label'], response_id=result['summary']['response_id'],
                               prompt_tokens=usage['prompt_tokens'], cached_tokens=count))
    require(any(row['cached_tokens'] > 0 for row in cached if row['phase'] == 'measured'),
            'no actual measured prefix hit; configuration alone is insufficient')
    require(all(row['proposal_phases'] and row['proposal_phases_truncated'] is False
                and all(p['returned'] is True and 'classification_error' not in p for p in row['proposal_phases'])
                for row in rows), 'actual proposal phase audit incomplete')
    return dict(status='ACTUAL_SERVER_PREFIX_HITS_AND_RANK_SOURCE_IDENTITY', per_request=cached,
                observed_proposal_batch_phases=sorted({p['batch_phase'] for row in rows for p in row['proposal_phases']}),
                scope='CPU propose stages and actual API cached-token counts; not all Target prefill stages or KV numeric proof')


def check_saved(args):
    source = Path(__file__).resolve().parents[1]
    campaign = json.loads(args.campaign.read_text())
    prefix = getattr(args, 'prefix_caching', False)
    require(campaign.get('prefix_cache_requested', False) is prefix, 'prefix service contract differs')
    require(campaign['execution_tp'] == 16 and campaign['arm'] == args.arm
            and campaign['requests_sha256'] == digest(args.requests), 'exact service workload/arm/topology required')
    receipt_path = Path(campaign['admission_path'])
    require(digest(receipt_path) == campaign['admission_sha256'], 'original admission changed')
    receipt = json.loads(receipt_path.read_text())
    require(receipt['tp'] == 16 and receipt['source_sha'] == args.expected_sha == campaign['source_sha']
            and receipt['source_tree'] == campaign['source_tree'], 'service source/rank receipt differs')
    argv = glm_serve_argv(campaign['server_argv'][0], args.port,
                          campaign['server_argv'][campaign['server_argv'].index('--served-model-name')+1],
                          args.arm, worker_provenance=True, prefix_caching=prefix)
    require(argv == json.loads(args.server_argv.read_text()), 'actual official argv differs')
    result = validate_requests(campaign, json.loads(args.records.read_text()), json.loads(args.requests.read_text()),
                              expected_server_argv=argv, expected_source=source,
                              expected_vllm_source=receipt['vllm_checkout'],
                              worker_identity_validator=validate_service_workers, worker_extension_cls=EXTENSION)
    rows = [row['rank_snapshot'] for row in campaign['worker_provenance'][-1]['results']]
    document = json.loads(args.records.read_text())
    groups = json.loads(args.requests.read_text())
    dispatch = validate_ranks(rows, source=source, pin=receipt['vllm_checkout'], arm=args.arm,
                              need_clip=any(len(p['prompt_token_ids']) > 1024 for g in groups for p in g['prompts']))
    result.update(all_rank_dispatch=dispatch, scope='OFFICIAL_HTTP_AND_ALL_RANK_HOST_DISPATCH_AUDIT',
                  full_feature_combination='NOT_ASSESSED', normal_completion='NOT_PROVEN',
                  execution_operand='NOT_PROVEN', physical_read='NOT_AVAILABLE',
                  acceptance='NOT_AVAILABLE_FROM_THIS_HTTP_COLLECTION')
    if prefix:
        result['prefix_validation'] = validate_prefix_hits(campaign, document)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('run', 'check'))
    parser.add_argument('--arm', choices=('G_OFF', 'G_ON', 'E_ON'), required=True)
    parser.add_argument('--prefix-caching', action='store_true')
    parser.add_argument('--expected-sha', required=True)
    parser.add_argument('--port', type=int, required=True)
    for name in ('requests', 'output'):
        parser.add_argument('--'+name, type=Path, required=True)
    for name in ('admission', 'campaign', 'records', 'server-argv'):
        parser.add_argument('--'+name, type=Path)
    args = parser.parse_args()
    if args.command == 'check':
        require(all(getattr(args, name) is not None for name in ('campaign', 'records', 'server_argv')),
                'complete saved service evidence required')
        try:
            result = check_saved(args)
        except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
            result = dict(status='INVALID_EVIDENCE', error=f'{type(error).__name__}: {error}')
        write(args.output, result)
        return 0 if result['status'] == 'PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS' else 4
    require(args.admission is not None, 'new all-rank admission required')
    args.worker_provenance = True
    return run_service(args, server_argv_builder=partial(glm_serve_argv, prefix_caching=args.prefix_caching),
                       target_model=str(TARGET), tp=16,
                       ready_timeout_seconds=1800,
                       extra_metadata=dict(model_profile=profile_identity(),
                                           service_entrypoint_sha256=digest(__file__),
                                           lightweight_Host_dispatch_audit=True,
                                           prefix_cache_requested=args.prefix_caching,
                                           full_feature_combination='NOT_ASSESSED'))


if __name__ == '__main__':
    raise SystemExit(main())
