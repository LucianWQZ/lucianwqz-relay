# SPDX-License-Identifier: Apache-2.0
"""External all-rank baseline/review anchor join; no numeric extrapolation."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [
        p for p in sys.path
        if Path(p or ".").resolve() != Path(__file__).parent.resolve()
    ]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair21_rank import (
    ANCHOR_REQUEST_PLAN, build_rank_kwargs, digest, require, validate_rank_records, write,
)


def validate_qwen_worker(worker, tp):
    require(
        len(worker["draft_layers"]) == 5
        and len(set(worker["draft_layers"])) == 5
        and set(worker["draft_backend"]) == set(worker["draft_layers"]),
        "Qwen DSpark Draft layer coverage")
    require(
        all(
            name.endswith("attention_v1.AscendAttentionBackend")
            for name in worker["draft_backend"].values()),
        "dense FIA baseline only")
    require(
        len(worker["draft_kv_geometry"]) == 10, "per-layer K/V coverage")
    for geometry in worker["draft_kv_geometry"].values():
        shape = geometry["shape"]
        require(
            len(shape) == 4 and shape[0] > 0
            and shape[1:] == [128, max(1, 8 // tp), 128]
            and geometry["dtype"] == "torch.bfloat16",
            "actual per-rank KV geometry mismatch")


def validate_payload(campaign, expected, execution, receipt, source, *, kwargs_factory=None, worker_validator=None,
                     request_plan=ANCHOR_REQUEST_PLAN, output_tokens=32):
    """Pure payload checks; caller separately verifies source/hash/device facts."""
    tp = expected["tp"]
    require(
        type(tp) is int and tp in (2, 4, 16),
        "declared complete supported rank set required")
    require(
        len(expected["phy_ids"]) == tp and len(set(expected["phy_ids"])) == tp,
        "incomplete physical set")
    require(
        execution["argv"] == expected["argv"] and execution["returncode"] == 0
        and execution["signal"] is None and execution["timeout"] is False,
        "actual invocation incomplete")
    require(campaign["pid"] == execution["pid"] and campaign["tp"] == tp,
            "parent/topology mismatch")
    require(
        execution["start_epoch"] <= campaign["started_at"] <
        campaign["ended_at"] <= execution["end_epoch"],
        "campaign outside actual parent lifetime")
    require(
        campaign["source_sha"] == expected["source_sha"] ==
        receipt["source_sha"] and campaign["source_tree"] ==
        expected["source_tree"] == receipt["source_tree"], "source mismatch")
    review = expected.get("window_on_review", False)
    require(type(review) is bool, "explicit boolean Window review profile required")
    wanted = ("ALL_RANK_WINDOW_ON_REVIEW_ANCHOR_COMPLETED_NOT_NUMERIC_VALIDATION" if review
              else "ALL_RANK_REQUEST_ANCHOR_COMPLETED_NOT_WINDOW_VALIDATION")
    require(campaign["status"] == wanted and campaign["window_on_review"] is review,
            "actual Window arm differs from declared anchor")
    kwargs = (kwargs_factory or build_rank_kwargs)(tp, window_on_review=review)
    require(
        campaign["kwargs"] == kwargs
        and campaign["config_sha256"] == hashlib.sha256(
            json.dumps(kwargs, sort_keys=True).encode()).hexdigest(),
        "actual kwargs differ from independent OFF config")
    require(receipt["tp"] == tp and receipt["phy_ids"] == expected["phy_ids"],
            "admission complete set differs")
    rows = campaign["ranks"]
    checked = validate_rank_records(rows,
                                    tp=tp,
                                    source=source,
                                    vllm_source=receipt["vllm_checkout"],
                                    window=kwargs.get('additional_config',{}).get('draft_window_size') if review else None)
    installed = campaign["installed_observers"]
    require(
        len(installed) == tp
        and sorted(row["rank"] for row in installed) == list(range(tp)),
        "missing observer RPC rank")
    for worker in rows:
        rank = worker["rank"]
        require(
            worker["local_rank"] == worker["logical_device"] == rank
            and worker["draft_tp_size"] == tp,
            "rank/local logical/Draft topology mismatch")
        require(
            worker["visible"] == ",".join(map(str, expected["phy_ids"]))
            and worker["hostname"] == receipt["host"],
            "worker device mask or host differs")
        require(worker["process_start_ticks"].isdigit() and worker["nspid"],
                "actual worker identity missing")
        require(
            next(row for row in installed
                 if row["rank"] == rank)["pid"] == worker["pid"],
            "install/snapshot RPC process differs")
        (worker_validator or validate_qwen_worker)(worker, tp)
        dispatch = worker["dispatch_records"]
        require(
            sum(row["role"].startswith("draft:") and row["returned"]
                for row in dispatch) == worker["draft_replays"]
            and sum(row["role"] == "target" and row["returned"]
                    for row in dispatch) == worker["target_replays"],
            "replay counts contradict actual dispatch records")
        require(
            all(row["mode"] == "FULL" and row["returned"]
                and row["host_start_ns"] < row["host_return_ns"]
                for row in dispatch), "actual full Graph role did not return")
    requests = campaign["requests"]
    require(len(requests) == len(request_plan), "all planned request groups required")
    for request, (label, lengths) in zip(requests, request_plan):
        require(
            request["label"] == label
            and request["start_ns"] < request["end_ns"],
            "request phase mismatch")
        require(
            request["prompts"] == [
                dict(prompt_token_ids=[100 + i] * length)
                for i, length in enumerate(lengths)
            ], "actual input differs")
        require(
            len(request["outputs"]) == len(lengths)
            and all(row["finished"] is True and len(row["token_ids"]) == output_tokens
                    and all(
                        type(token) is int and token >= 0
                        for token in row["token_ids"])
                    for row in request["outputs"]),
            "full request completion/output count")
    return checked


def check(planned_path, execution_path, *, kwargs_factory=None, worker_validator=None,
          entrypoint_name="p7x_graph_repair21_rank.py", request_plan=ANCHOR_REQUEST_PLAN, output_tokens=32):
    result = dict(status="INVALID_EVIDENCE",
                  window="OFF_BASELINE_ONLY",
                  numeric="NOT_ASSESSED",
                  target_kv="NOT_ASSESSED",
                  normal_completion="NOT_INFERRED",
                  physical_read="NOT_PROVEN")
    try:
        expected = json.loads(Path(planned_path).read_text())
        observed = json.loads(Path(execution_path).read_text())
        execution = observed["execution"]
        argv = expected["argv"]
        review = expected.get("window_on_review", False)
        require(type(review) is bool and ("--window-on-review" in argv) is review
                and Path(argv[1]).name == entrypoint_name,
                "explicit original arm/anchor entry required")
        require(argv[argv.index("--tp") + 1] == str(expected["tp"]),
                "argv topology mismatch")
        source = Path(argv[1]).resolve().parents[1]
        output = Path(argv[argv.index("--output") + 1])
        admission = Path(argv[argv.index("--admission") + 1])
        campaign = json.loads((output / "campaign.json").read_text())
        receipt = json.loads(admission.read_text())
        require(
            digest(admission) == expected["admission_sha256"] ==
            campaign["admission_sha256"], "predeclared admission changed")
        require(campaign["script_sha256"] == digest(argv[1]),
                "original producer tool changed")
        from tools.p7x_graph_local_candidate import BASE_SHA, VLLM_SHA, VLLM_TREE, _git, _identity
        _identity(source,
                  expected["source_sha"],
                  expected["source_tree"],
                  ancestor=BASE_SHA)
        _identity(Path(receipt["vllm_checkout"]), VLLM_SHA, VLLM_TREE)
        checked = validate_payload(campaign, expected, execution, receipt,
                                   source, kwargs_factory=kwargs_factory, worker_validator=worker_validator,
                                   request_plan=request_plan, output_tokens=output_tokens)
        from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay
        proof = receipt["runtime_manifest"]
        require(
            digest(proof["path"]) == proof["sha256"],
            "runtime receipt changed")
        validate_runtime_overlay(proof["path"], source, expected["source_sha"],
                                 expected["source_tree"])
        mapping = receipt["mapping_evidence"]
        require(
            digest(mapping["path"]) == mapping["sha256"],
            "saved mapping changed")
        actual = json.loads(Path(
            mapping["path"]).read_text())["mapping_command"]
        require(actual["rc"] == 0, "physical mapping unavailable")
        associations = observed["per_rank_device_association"]
        require(
            len(associations) == expected["tp"]
            and sorted(row["rank"]
                       for row in associations) == list(range(expected["tp"])),
            "missing external rank association")
        for worker in campaign["ranks"]:
            physical = expected["phy_ids"][worker["rank"]]
            chip = [
                line.split()[:2] for line in actual["stdout"].splitlines()
                if len(line.split()) >= 5 and line.split()[2:4] ==
                [str(physical), str(physical)]
            ]
            require(len(chip) == 1, "ambiguous physical chip mapping")
            association = next(row for row in associations
                               if row["rank"] == worker["rank"])
            require(
                association["pid"] == worker["pid"]
                and association["physical_id"] == physical
                and association["observations"],
                "external worker physical mapping missing")
            from tools.p7x_graph_repair30_device_join import validate_association
            validate_association(worker, physical, association, chip[0],
                                 source_sha=expected["source_sha"], execution=execution)
        checker = Path(__file__).resolve().parents[1]
        checker_sha, checker_tree = _git(checker, "rev-parse",
                                         "HEAD"), _git(checker, "rev-parse",
                                                       "HEAD^{tree}")
        _identity(checker, checker_sha, checker_tree, ancestor=BASE_SHA)
        result.update(
            status="PASS_SCOPED_ALL_RANK_WINDOW_ON_REVIEW_ANCHOR" if review else "PASS_SCOPED_ALL_RANK_WINDOW_OFF_ANCHOR",
            window="ON_REVIEW_ACTUAL_ALL_RANK_REQUESTS" if review else "OFF_BASELINE_ONLY",
            ranks=checked["ranks"],
            producer_commit=expected["source_sha"],
            checker_commit=checker_sha,
            checker_tree=checker_tree,
            scope=
            "Actual all-rank Graph dispatch and completed requests; ON additionally validates rank-owned clipped Window generations, not numeric/Target KV/normal completion proof"
        )
    except (ValueError, KeyError, TypeError, OSError, IndexError, RuntimeError,
            StopIteration) as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("planned", "execution", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    result = check(args.planned, args.execution)
    write(args.output, result)
    return 0 if result["status"] in ("PASS_SCOPED_ALL_RANK_WINDOW_OFF_ANCHOR",
                                     "PASS_SCOPED_ALL_RANK_WINDOW_ON_REVIEW_ANCHOR") else 4


if __name__ == "__main__":
    raise SystemExit(main())
