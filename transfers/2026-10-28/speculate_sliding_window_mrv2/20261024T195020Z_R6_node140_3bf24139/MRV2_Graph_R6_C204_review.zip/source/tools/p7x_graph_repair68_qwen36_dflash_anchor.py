# SPDX-License-Identifier: Apache-2.0
"""Named Qwen3.6 Full-DFlash original Graph baseline, before Window evidence.

The designated TP4/DP1 anchor does not qualify the required TP4/DP2 service or
the separate six-layer structural SWA route. It reuses fixed model paths and
the real engine, complete-rank admission, dispatch and external process join.
"""
from __future__ import annotations

import argparse
from collections.abc import Mapping
import hashlib
import json
from pathlib import Path
import struct
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair21_rank import RankWorkerExtension, digest, require, run_anchor, write
from tools.p7x_graph_repair28_rank_anchor_check import check as check_anchor

PROFILE = "QWEN36_W8A8_FULL8_DFLASH_K7_Q8_TP4_DP1_FDO_ANCHOR_V1"
TARGET = Path("/mnt/share/weight/Qwen3.6-35B-A3B-w8a8")
DRAFT = Path("/mnt/weight/Qwen3.6-35B-A3B-DFlash")
TARGET_CONFIG_SHA = "93a4693fa9d8392fbfccd4b3c9873f4bfdcb14fdede978b123d07d19675efe99"
DRAFT_CONFIG_SHA = "d2be70579f0b8e7b109e776dbf14bd88ac5be115d2dabbb20e6373988939f410"
AUX_LAYERS = (1, 10, 19, 28, 37)
CAPTURE = (8, 16, 32)
SPECULATOR = "vllm_ascend.worker.v2.spec_decode.dflash.speculator.AscendDFlashSpeculator"


def validate_model_configs(target, draft):
    text = target["text_config"]
    require(target["architectures"] == ["Qwen3_5MoeForConditionalGeneration"]
            and target["model_type"] == "qwen3_5_moe"
            and text["num_hidden_layers"] == 40 and text["hidden_size"] == 2048
            and text["layer_types"] == ["linear_attention", "linear_attention", "linear_attention", "full_attention"] * 10,
            "actual hybrid Qwen3.6 Target identity differs")
    require(draft["architectures"] == ["DFlashDraftModel"] and draft["model_type"] == "qwen3"
            and draft["num_hidden_layers"] == 8 and draft["hidden_size"] == 2048
            and draft["num_target_layers"] == 40 and draft["vocab_size"] == text["vocab_size"] == 248320
            and draft["num_attention_heads"] == 32 and draft["num_key_value_heads"] == 4
            and draft["head_dim"] == 128 and draft["dtype"] == "bfloat16",
            "actual Full8 BF16 DFlash geometry differs")
    options = draft["dflash_config"]
    require(options["target_layer_ids"] == list(AUX_LAYERS) and options["mask_token_id"] == 248070
            and options.get("causal") is None and options.get("sample_from_anchor", False) is False
            and draft["layer_types"] == ["full_attention"] * 8
            and draft["sliding_window"] is None and draft["use_sliding_window"] is False,
            "Full8 anchor cannot substitute the different six-layer SWA checkpoint")
    require(draft["max_position_embeddings"] >= 4096 and text["max_position_embeddings"] >= 4096,
            "anchor exceeds actual model position range")


def weight_headers(path):
    with Path(path).open("rb") as stream:
        size = struct.unpack("<Q", stream.read(8))[0]
        require(0 < size <= 1 << 20, "bounded Draft weight header required")
        raw = stream.read(size)
    require(len(raw) == size, "truncated Draft header")
    header = json.loads(raw)
    shapes = {"fc.weight": [2048, 10240], "hidden_norm.weight": [2048]}
    for name, shape in shapes.items():
        require(header[name]["dtype"] == "BF16" and header[name]["shape"] == shape,
                "actual Draft aux projection weight geometry differs")
    return dict(bytes=size, sha256=hashlib.sha256(raw).hexdigest(),
                tensors={name: header[name] for name in shapes},
                scope="BOUNDED_HEADER_ONLY_NOT_FULL_WEIGHT_HASH")


def profile_identity():
    require(digest(TARGET/"config.json") == TARGET_CONFIG_SHA
            and digest(DRAFT/"config.json") == DRAFT_CONFIG_SHA, "fixed model config changed")
    validate_model_configs(json.loads((TARGET/"config.json").read_text()), json.loads((DRAFT/"config.json").read_text()))
    files = [TARGET/"config.json", TARGET/"quant_model_description.json",
             TARGET/"quant_model_weights.safetensors.index.json", TARGET/"tokenizer_config.json", DRAFT/"config.json"]
    return dict(profile=PROFILE,
                files=[dict(path=str(p), realpath=str(p.resolve()), bytes=p.stat().st_size, sha256=digest(p)) for p in files],
                draft_weight_header=weight_headers(DRAFT/"model.safetensors"),
                method=dict(method="dflash", k=7, draft_query=8, target_query=8,
                            sample_offset=1, target_layer_ids=list(AUX_LAYERS),
                            auxiliary_output_indices=[i+1 for i in AUX_LAYERS]),
                scope="Fixed existing model/config/header and pinned loader contract; not new device evidence")


def build_kwargs(tp, *, window_on_review=False):
    require(type(tp) is int and tp == 4 and type(window_on_review) is bool, "explicit TP4/DP1 anchor only")
    additional = {}
    if window_on_review:
        additional.update(draft_window_size=1024, draft_window_graph_replicated_tp_review=True)
    return dict(model=str(TARGET), tensor_parallel_size=tp, data_parallel_size=1,
                enable_expert_parallel=True, distributed_executor_backend="mp",
                worker_extension_cls="tools.p7x_graph_repair68_qwen36_dflash_anchor.Qwen36DFlashWorker",
                speculative_config=dict(method="dflash", model=str(DRAFT), num_speculative_tokens=7,
                                        enforce_eager=False, enable_adaptive_verification=False),
                additional_config=additional, quantization="ascend", trust_remote_code=True,
                async_scheduling=False, enable_prefix_caching=False,
                compilation_config=dict(cudagraph_capture_sizes=list(CAPTURE), cudagraph_mode="FULL_DECODE_ONLY"),
                enforce_eager=False, gpu_memory_utilization=0.6, max_model_len=4096,
                max_num_batched_tokens=4096, max_num_seqs=4, seed=0, disable_log_stats=True)


class Qwen36DFlashWorker(RankWorkerExtension):
    def mrv2_rank_snapshot(self):
        row = super().mrv2_rank_snapshot()
        runner, spec = self.model_runner, self.model_runner.speculator
        draft_names = set(spec.draft_attn_layer_names)
        groups, draft_groups = [], []
        for members in runner.attn_groups:
            for group in members:
                own = sorted(set(group.layer_names) & draft_names)
                target = sorted(set(group.layer_names) - draft_names)
                identity = dict(global_group_id=group.kv_cache_group_id,
                                backend=group.backend.__module__+"."+group.backend.__qualname__)
                if own:
                    draft_groups.append(dict(**identity, layers=own))
                if target:
                    groups.append(dict(**identity, layers=target))
        cfg = spec.draft_model_config.hf_config
        causal = spec._group_causal
        row["qwen36_profile"] = dict(profile=PROFILE, target_model=self.vllm_config.model_config.model,
            draft_model=spec.draft_model_config.model, target_groups=groups, draft_groups=draft_groups,
            method=spec.speculative_config.method, k=spec.num_speculative_steps,
            query=spec.num_query_per_req, anchor=spec.sample_from_anchor, noncausal=spec.requires_non_causal,
            layer_types=list(cfg.layer_types), target_layer_ids=list(cfg.dflash_config["target_layer_ids"]),
            mask_token_id=spec.parallel_drafting_token_id, fc_shape=list(spec.model.model.fc.weight.shape),
            model_layer_causal=list(spec.model.get_draft_attn_causal()),
            group_causal=[dict(global_group_id=g["global_group_id"],
                               causal=causal[g["global_group_id"]] if isinstance(causal, Mapping) else causal)
                          for g in draft_groups],
            scope="ACTUAL_NORMALIZED_CONFIG_AND_BUILT_MODEL_HOST_HEADERS_NOT_EXECUTION_OPERANDS")
        return row


def validate_worker(worker, tp):
    require(tp == 4 and worker["speculator_class"] == SPECULATOR, "actual TP4 Ascend DFlash required")
    p = worker["qwen36_profile"]
    require(p["profile"] == PROFILE and p["target_model"] == str(TARGET) and p["draft_model"] == str(DRAFT)
            and p["method"] == "dflash" and type(p["k"]) is type(p["query"]) is int
            and p["k"] == 7 and p["query"] == 8 and p["anchor"] is False and p["noncausal"] is True
            and p["layer_types"] == ["full_attention"]*8 and p["target_layer_ids"] == list(AUX_LAYERS)
            and type(p["mask_token_id"]) is int and p["mask_token_id"] == 248070
            and p["fc_shape"] == [2048, 10240] and len(p["model_layer_causal"]) == 8
            and all(value is False for value in p["model_layer_causal"]),
            "actual method/masks/aux contract differs")
    layers = worker["draft_layers"]
    require(len(layers) == len(set(layers)) == 8 and set(worker["draft_backend"]) == set(layers)
            and all(v.endswith("attention_v1.AscendAttentionBackend") for v in worker["draft_backend"].values())
            and set(worker["draft_kv_geometry"]) == {n+"/"+str(i) for n in layers for i in (0, 1)},
            "complete eight-layer dense FIA Draft required")
    for cache in worker["draft_kv_geometry"].values():
        require(len(cache["shape"]) == 4 and cache["shape"][0] > 0 and cache["shape"][1:] == [128, 1, 128]
                and cache["dtype"] == "torch.bfloat16", "actual TP4 Draft KV geometry differs")
    groups = p["draft_groups"]
    require(len(groups) == 1 and set(groups[0]["layers"]) == set(layers), "Full8 single-group inventory differs")
    gid = groups[0]["global_group_id"]
    require(type(gid) is int and gid >= 0 and p["group_causal"] == [dict(global_group_id=gid, causal=False)]
            and type(p["group_causal"][0]["global_group_id"]) is int
            and p["group_causal"][0]["causal"] is False,
            "actual noncausal group required")
    if worker["window_size"] is not None:
        require(all(g["global_group_id"] == gid for g in worker["window_generations"]+worker["window_graph_bindings"]),
                "Window uses another cache group")
    full, linear = [], []
    for group in p["target_groups"]:
        if group["backend"].endswith("attention_v1.AscendAttentionBackend"):
            full.extend(group["layers"])
        elif group["backend"].endswith("gdn_attn_builder.AscendGDNAttentionBackend"):
            linear.extend(group["layers"])
        else:
            raise ValueError("uninventoried actual Qwen3.6 Target backend")
    require(len(full) == len(set(full)) == 10 and len(linear) == len(set(linear)) == 30
            and not set(full) & set(linear) and not (set(full) | set(linear)) & set(layers),
            "complete independent Target Full/GDN owners required")
    required = {(n, n*8) for n in (1, 2, 4)}
    for key in ("draft_graph_inventory", "target_graph_inventory"):
        require(required <= {(v["requests"], v["tokens"]) for v in worker[key] if v["mode"] == "FULL"},
                "actual Q8 capture bucket missing")


def check(planned, execution):
    result = check_anchor(planned, execution, kwargs_factory=build_kwargs,
                          worker_validator=validate_worker, entrypoint_name=Path(__file__).name)
    if result["status"].startswith("PASS_SCOPED_"):
        try:
            expected = json.loads(Path(planned).read_text())
            argv = expected["argv"]
            campaign = json.loads((Path(argv[argv.index("--output")+1])/"campaign.json").read_text())
            require(expected["profile_identity"] == campaign["profile_identity"] == profile_identity(),
                    "declared/actual fixed Qwen3.6 pair differs")
            result.update(profile=PROFILE, status=result["status"]+"_QWEN36_FULL8_DFLASH_K7_Q8_TP4_DP1")
        except (ValueError, KeyError, TypeError, OSError, struct.error) as error:
            result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run")
    for name in ("admission", "output"):
        run.add_argument("--"+name, type=Path, required=True)
    run.add_argument("--expected-sha", required=True)
    run.add_argument("--tp", type=int, choices=(4,), required=True)
    run.add_argument("--window-on-review", action="store_true")
    saved = sub.add_parser("check")
    for name in ("planned", "execution", "output"):
        saved.add_argument("--"+name, type=Path, required=True)
    args = parser.parse_args()
    if args.command == "run":
        from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay
        receipt = json.loads(args.admission.read_text())
        validate_runtime_overlay(receipt["runtime_manifest"]["path"], Path(__file__).resolve().parents[1],
                                 args.expected_sha, receipt["source_tree"])
        return run_anchor(args, profile_kwargs=build_kwargs(args.tp, window_on_review=args.window_on_review),
                          profile_identity=profile_identity(), producer_path=__file__)
    result = check(args.planned, args.execution)
    write(args.output, result)
    return 0 if result["status"].startswith("PASS_SCOPED_") else 4


if __name__ == "__main__":
    raise SystemExit(main())
