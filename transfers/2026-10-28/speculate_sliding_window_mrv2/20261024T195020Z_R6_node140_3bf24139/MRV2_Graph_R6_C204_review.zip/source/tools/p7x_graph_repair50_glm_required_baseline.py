# SPDX-License-Identifier: Apache-2.0
"""Window-OFF official Draft Graph baseline with required GLM features.

This arm tests the underlying Graph stack before changing Window admission.
All observations are Host objects and existing metadata; no tensor value read,
event query, extra synchronization or device recovery is added.
"""
from __future__ import annotations

import argparse
import inspect
import json
from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair32_glm_rank import TARGET, SP_CAPTURE, SP_CAPTURE_CONTRACT, profile_identity
from tools.p7x_graph_repair33_service import run_service, validate_requests
from tools.p7x_graph_repair40_glm_performance import validate_ranks
from tools.p7x_graph_repair47_glm_service import (
    GLMServiceWorker, glm_serve_argv, validate_prefix_hits, validate_service_workers,
)

PROFILE = 'GLM52_TP16_REQUIRED_FEATURES_WINDOW_OFF_GRAPH_BASELINE_V2_SP_ALIGNED'
EXTENSION = 'tools.p7x_graph_repair50_glm_required_baseline.GLMRequiredFeatureWorker'
CP_MODULE = 'vllm_ascend.attention.context_parallel.sfa_cp.'


def class_name(value):
    return type(value).__module__ + '.' + type(value).__qualname__


def required_serve_argv(python, port, model_name, arm, *, worker_provenance=False):
    require(arm == 'G_OFF', 'underlying all-feature baseline must retain Window OFF')
    argv = glm_serve_argv(python, port, model_name, arm,
                          worker_provenance=worker_provenance, prefix_caching=True)
    argv[argv.index('--no-async-scheduling')] = '--async-scheduling'
    argv += ['--enable-chunked-prefill']
    argv[argv.index('--compilation-config') + 1] = json.dumps(dict(
        cudagraph_capture_sizes=SP_CAPTURE, cudagraph_mode='FULL_DECODE_ONLY',
    ), sort_keys=True)
    argv[argv.index('--additional-config') + 1] = json.dumps(dict(
        enable_dsa_cp=True, enable_flashcomm1=True, multistream_overlap_shared_expert=True,
    ), sort_keys=True)
    argv[argv.index('--worker-extension-cls') + 1] = EXTENSION
    return argv


def install_metadata_audit(worker, builders):
    """Observe the actual non-capture Target builder return, with bounded samples."""
    worker._mrv2_required_metadata = dict(calls=0, cp_context_returns=0, samples=[])

    def wrap(builder):
        original = builder.build
        signature = inspect.signature(original)

        def build(*args, **kwargs):
            result = original(*args, **kwargs)
            row = worker._mrv2_required_metadata
            row['calls'] += 1
            cp = getattr(result, 'dsa_cp_context', None) is not None
            row['cp_context_returns'] += int(cp)
            if len(row['samples']) < 16:
                sample = dict(builder=class_name(builder), metadata=class_name(result),
                              dsa_cp_context_present=cp)
                try:
                    common = signature.bind(*args, **kwargs).arguments['common_attn_metadata']
                    for name in ('num_reqs', 'num_actual_tokens', 'num_input_tokens', 'max_query_len'):
                        value = getattr(common, name, None)
                        if type(value) is int:
                            sample[name] = value
                except (ValueError, TypeError, KeyError, AttributeError) as error:
                    sample['host_observation_error'] = repr(error)
                row['samples'].append(sample)
            return result

        builder.build = build

    for builder in builders:
        wrap(builder)


class GLMRequiredFeatureWorker(GLMServiceWorker):
    def mrv2_service_worker_identity(self, nonce):
        from vllm_ascend.ascend_config import get_ascend_config
        from vllm_ascend.utils import enable_sp

        row = super().mrv2_service_worker_identity(nonce)
        config, runner = self.vllm_config, self.model_runner
        ascend_config = get_ascend_config()
        draft = set(runner.speculator.draft_attn_layer_names)
        graph_session = getattr(runner.speculator, '_draft_window_graph_characterization', None)
        capability = getattr(runner.speculator, '_draft_window_source_capability', None)
        topology = getattr(capability, 'eager_topology_fingerprint', None)
        additional = config.additional_config or {}
        sequence_parallel = enable_sp(config)
        flashcomm_requested = additional.get('enable_flashcomm1') is True
        flashcomm_effective = sequence_parallel and (
            flashcomm_requested or ascend_config.enable_dsa_cp)
        context = runner.compilation_config.static_forward_context
        target_layers, builders, seen = [], [], set()
        for groups in runner.attn_groups:
            for group in groups:
                if not group.backend.__qualname__ == 'AscendSFABackend':
                    continue
                builder = group.get_metadata_builder(0)
                if id(builder) not in seen:
                    builders.append(builder)
                    seen.add(id(builder))
                for name in sorted(set(group.layer_names) - draft):
                    target_layers.append(dict(layer=name, builder=class_name(builder),
                                              impl=class_name(getattr(context[name], 'impl', None))))
        if not hasattr(self, '_mrv2_required_metadata'):
            install_metadata_audit(self, builders)
        row['required_features'] = dict(
            profile=PROFILE, async_scheduling=config.scheduler_config.async_scheduling,
            prefix_caching=config.cache_config.enable_prefix_caching,
            chunked_prefill=config.scheduler_config.enable_chunked_prefill,
            sequence_parallel=sequence_parallel, dsa_cp=ascend_config.enable_dsa_cp,
            flashcomm_requested=flashcomm_requested,
            flashcomm_effective=flashcomm_effective,
            draft_graph_flashcomm=(None if graph_session is None or topology is None
                                   else topology.flashcomm),
            expert_parallel=config.parallel_config.enable_expert_parallel,
            pcp_size=config.parallel_config.prefill_context_parallel_size,
            dcp_size=config.parallel_config.decode_context_parallel_size,
            all2all_backend=config.parallel_config.all2all_backend,
            capture_sizes=list(config.compilation_config.cudagraph_capture_sizes),
            target_layers=target_layers,
            actual_metadata_audit=self._mrv2_required_metadata,
            scope='EFFECTIVE_HOST_CONFIG_AND_ACTUAL_TARGET_METADATA_RETURNS_NOT_NUMERIC_OR_COMPLETION',
        )
        return row


def validate_required_features(rows, *, require_execution, require_graph_window=False):
    require(type(require_execution) is bool and type(require_graph_window) is bool
            and len(rows) == 16, 'complete typed required-feature rank set')
    for row in rows:
        feature = row['required_features']
        require(feature['profile'] == PROFILE, 'named underlying Graph baseline required')
        for key in ('async_scheduling', 'prefix_caching', 'chunked_prefill', 'sequence_parallel',
                    'dsa_cp', 'expert_parallel'):
            require(feature[key] is True, 'requested feature is not actually effective: ' + key)
        require(feature['all2all_backend'] == 'allgather_reducescatter',
                'actual all2all backend differs from the required FlashComm route')
        require(feature['capture_sizes'] == SP_CAPTURE
                and all(type(size) is int for size in feature['capture_sizes']),
                'actual TP16 SP capture configuration lost required active1-to4 coverage')
        require(feature['flashcomm_requested'] is True and feature['flashcomm_effective'] is True,
                'FlashComm was requested but is not effective on this worker')
        expected_graph_flashcomm = True if require_graph_window else None
        require(feature['draft_graph_flashcomm'] is expected_graph_flashcomm,
                'Draft Graph FlashComm identity differs from the selected Window arm')
        require(type(feature['pcp_size']) is int and feature['pcp_size'] == 1
                and type(feature['dcp_size']) is int and feature['dcp_size'] == 1,
                'legacy DSA-CP baseline must not substitute PCP or DCP')
        layers = feature['target_layers']
        require(len(layers) == len({r['layer'] for r in layers}) == 78
                and all(r['builder'] == CP_MODULE + 'AscendSFADSACPMetadataBuilder'
                        and r['impl'] == CP_MODULE + 'AscendSFADSACPImpl' for r in layers),
                'actual complete Target DSA-CP builder/implementation inventory required')
        audit = feature['actual_metadata_audit']
        require(type(audit['calls']) is int and type(audit['cp_context_returns']) is int
                and 0 <= audit['cp_context_returns'] <= audit['calls'], 'typed actual builder counts required')
        if require_execution:
            require(audit['calls'] > 0 and audit['cp_context_returns'] == audit['calls']
                    and audit['samples'] and all(s['metadata'] == CP_MODULE + 'AscendSFADSACPMetadata'
                        and s['dsa_cp_context_present'] is True and 'host_observation_error' not in s
                        for s in audit['samples']), 'no complete actual DSA-CP metadata execution evidence')
    return dict(status='ALL16_EFFECTIVE_FEATURES_AND_TARGET_DSA_CP',
                actual_metadata_execution_required=require_execution,
                FlashComm='EFFECTIVE_HOST_CONFIG_AND_GRAPH_IDENTITY_WHEN_WINDOW_ON',
                FlashComm_limit='NOT_AN_INDEPENDENT_KERNEL_TIMELINE_VERDICT')


def validate_required_workers(rows, **kwargs):
    result = validate_service_workers(rows, capture_contract=SP_CAPTURE_CONTRACT, **kwargs)
    result['required_features'] = validate_required_features(
        rows,
        require_execution=False,
        require_graph_window=kwargs.get('arm') == 'G_ON',
    )
    return result


def check_saved(args):
    source = Path(__file__).resolve().parents[1]
    campaign = json.loads(args.campaign.read_text())
    require(campaign['required_feature_profile'] == PROFILE and campaign['arm'] == args.arm == 'G_OFF'
            and campaign['execution_tp'] == 16 and campaign['requests_sha256'] == digest(args.requests),
            'actual named baseline/workload/ranks differ')
    receipt_path = Path(campaign['admission_path'])
    require(digest(receipt_path) == campaign['admission_sha256'], 'original admission changed')
    receipt = json.loads(receipt_path.read_text())
    require(receipt['tp'] == 16 and receipt['source_sha'] == args.expected_sha == campaign['source_sha']
            and receipt['source_tree'] == campaign['source_tree'], 'source/admission mismatch')
    argv = required_serve_argv(campaign['server_argv'][0], args.port,
        campaign['server_argv'][campaign['server_argv'].index('--served-model-name')+1],
        args.arm, worker_provenance=True)
    require(argv == json.loads(args.server_argv.read_text()), 'actual official feature argv differs')
    document = json.loads(args.records.read_text())
    result = validate_requests(campaign, document, json.loads(args.requests.read_text()),
        expected_server_argv=argv, expected_source=source, expected_vllm_source=receipt['vllm_checkout'],
        worker_identity_validator=validate_required_workers, worker_extension_cls=EXTENSION)
    rows = campaign['worker_provenance'][-1]['results']
    result.update(required_features=validate_required_features(
        rows, require_execution=True, require_graph_window=False),
        prefix=validate_prefix_hits(campaign, document),
        actual_dispatch=validate_ranks([row['rank_snapshot'] for row in rows], source=source,
                                     pin=receipt['vllm_checkout'], arm='G_OFF', need_clip=False,
                                     capture_contract=SP_CAPTURE_CONTRACT),
        scope='UNDERLYING_WINDOW_OFF_GRAPH_SERVICE_FEATURE_BASELINE_NOT_WINDOW_ON_ADAPTATION',
        semantic_numeric='NOT_ASSESSED', normal_completion='NOT_PROVEN',
        execution_operand='NOT_PROVEN', physical_read='NOT_AVAILABLE')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('run', 'check'))
    parser.add_argument('--arm', choices=('G_OFF',), required=True)
    parser.add_argument('--expected-sha', required=True)
    parser.add_argument('--port', type=int, required=True)
    for name in ('requests', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ('admission', 'campaign', 'records', 'server-argv'):
        parser.add_argument('--' + name, type=Path)
    args = parser.parse_args()
    if args.command == 'check':
        try:
            result = check_saved(args)
        except (ValueError, KeyError, TypeError, IndexError, AttributeError, OSError) as error:
            result = dict(status='INVALID_EVIDENCE', error=f'{type(error).__name__}: {error}')
        write(args.output, result)
        return 0 if result['status'] == 'PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS' else 4
    args.worker_provenance = True
    return run_service(args, server_argv_builder=required_serve_argv, target_model=str(TARGET), tp=16,
        ready_timeout_seconds=1800, extra_metadata=dict(model_profile=profile_identity(),
            service_entrypoint_sha256=digest(__file__), required_feature_profile=PROFILE,
            prefix_cache_requested=True, full_feature_combination='WINDOW_OFF_BASELINE_ONLY'))


if __name__ == '__main__':
    raise SystemExit(main())
