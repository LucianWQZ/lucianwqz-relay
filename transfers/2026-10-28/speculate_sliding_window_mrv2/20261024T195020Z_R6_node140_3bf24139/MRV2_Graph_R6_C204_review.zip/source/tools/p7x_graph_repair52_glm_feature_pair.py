# SPDX-License-Identifier: Apache-2.0
"""Join fixed GLM required-feature Window OFF/ON service evidence.

The two services use deterministic sampling and the same request file.  This
checker pairs every raw HTTP request by its declared phase, group, ordinal and
prompt identity, then compares the complete streamed token sequence.  It is a
service-level semantic check.  It does not inspect Draft internal tensors,
Target KV, device completion, execution operands or physical reads.
"""
from __future__ import annotations

import sys
from pathlib import Path

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import hashlib
import json
from typing import Any

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair50_glm_required_baseline import PROFILE as OFF_PROFILE
from tools.p7x_graph_repair51_glm_joint_features import PROFILE as ON_PROFILE

PASS = "PASS_SCOPED_REQUIRED_FEATURE_OFF_ON_SERVICE_TOKEN_PAIR"


def stable_hash(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    return hashlib.sha256(payload).hexdigest()


def request_identity(request: dict[str, Any]) -> dict[str, Any]:
    """Exclude only the arm-specific served model alias."""
    require(isinstance(request, dict), "raw request must be an object")
    identity = {key: value for key, value in request.items() if key != "model"}
    require(
        isinstance(identity.get("prompt"), list)
        and all(type(token) is int for token in identity["prompt"]),
        "complete integer prompt identity required",
    )
    require(identity.get("temperature") == 0, "deterministic temperature required")
    require(type(identity.get("seed")) is int, "explicit deterministic seed required")
    require(identity.get("stream") is True, "actual streaming service request required")
    require(identity.get("return_token_ids") is True, "raw token IDs required")
    return identity


def streamed_tokens(result: dict[str, Any]) -> list[int]:
    require(isinstance(result.get("events"), list) and result["events"], "stream events required")
    tokens: list[int] = []
    terminal = False
    for ordinal, event in enumerate(result["events"]):
        data = event.get("data")
        require(isinstance(data, dict), "stream event data required")
        choices = data.get("choices")
        if choices == []:
            # include_usage emits one non-choice SSE after the terminal choice.
            # Validate it against the actual deltas rather than treating it as
            # an extra completion or silently accepting arbitrary empty events.
            require(terminal and ordinal == len(result["events"]) - 1,
                    "usage must follow the terminal choice and end the stream")
            usage = data.get("usage")
            require(isinstance(usage, dict), "empty choices require terminal usage")
            prompt = result.get("request", {}).get("prompt")
            require(isinstance(prompt, list), "usage needs the original prompt")
            require(all(type(usage.get(key)) is int for key in
                        ("prompt_tokens", "completion_tokens", "total_tokens")),
                    "usage requires exact integer counts")
            require(usage["prompt_tokens"] == len(prompt)
                    and usage["completion_tokens"] == len(tokens)
                    and usage["total_tokens"] == len(prompt) + len(tokens),
                    "usage contradicts the actual prompt or streamed tokens")
            continue
        if choices is not None:
            require(not terminal, "choice after terminal response")
            require(isinstance(choices, list) and len(choices) == 1, "one deterministic choice required")
            choice = choices[0]
            require(choice.get("index") == 0, "choice index differs")
            values = choice.get("token_ids")
            if values is not None:
                require(
                    isinstance(values, list) and all(type(token) is int for token in values),
                    "integer streamed token IDs required",
                )
                tokens.extend(values)
            terminal = terminal or choice.get("finish_reason") is not None
    require(terminal and tokens, "complete nonempty streamed response required")
    return tokens


def raw_rows(document: dict[str, Any]) -> list[dict[str, Any]]:
    require(document.get("status") == "COMPLETE", "complete raw service document required")
    groups = document.get("groups")
    require(isinstance(groups, list) and groups, "raw request groups required")
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str, int]] = set()
    for group in groups:
        phase, label = group.get("phase"), group.get("label")
        require(
            phase in ("warmup", "measured") and isinstance(label, str) and label,
            "typed request phase and label required",
        )
        results = group.get("results")
        require(isinstance(results, list) and results, "group results required")
        for ordinal, result in enumerate(results):
            key = (phase, label, ordinal)
            require(key not in seen, "duplicate request identity")
            seen.add(key)
            identity = request_identity(result.get("request"))
            tokens = streamed_tokens(result)
            rows.append(
                {
                    "key": [phase, label, ordinal],
                    "request_sha256": stable_hash(identity),
                    "prompt_tokens": len(identity["prompt"]),
                    "output_tokens": len(tokens),
                    "output_sha256": stable_hash(tokens),
                    "tokens": tokens,
                }
            )
    return rows


def validate_case(
    *,
    campaign: dict[str, Any],
    result: dict[str, Any],
    expected_sha: str,
    expected_tree: str | None,
    expected_requests_sha: str,
    arm: str,
) -> str:
    profile_key = "required_feature_profile" if arm == "G_OFF" else "combined_feature_profile"
    profile = OFF_PROFILE if arm == "G_OFF" else ON_PROFILE
    require(
        campaign.get("arm") == arm
        and campaign.get(profile_key) == profile
        and campaign.get("source_sha") == expected_sha
        and campaign.get("execution_tp") == 16
        and campaign.get("requests_sha256") == expected_requests_sha,
        f"{arm} producer identity or profile differs",
    )
    tree = campaign.get("source_tree")
    if expected_tree is not None:
        require(tree == expected_tree, f"{arm} source tree differs")
    require(
        result.get("scoped_accepted") is True
        and result.get("source_sha") == expected_sha
        and result.get("source_tree") == tree
        and result.get("artifact", {}).get("status")
        == "PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS"
        and result.get("device_ranks_associated") == 16,
        f"{arm} standalone service verdict or all-rank association missing",
    )
    return tree


def check(args: argparse.Namespace) -> dict[str, Any]:
    requests_sha = digest(args.requests)
    off_campaign = json.loads(args.off_campaign.read_text())
    on_campaign = json.loads(args.on_campaign.read_text())
    off_result = json.loads(args.off_result.read_text())
    on_result = json.loads(args.on_result.read_text())
    tree = validate_case(
        campaign=off_campaign,
        result=off_result,
        expected_sha=args.producer_sha,
        expected_tree=None,
        expected_requests_sha=requests_sha,
        arm="G_OFF",
    )
    validate_case(
        campaign=on_campaign,
        result=on_result,
        expected_sha=args.producer_sha,
        expected_tree=tree,
        expected_requests_sha=requests_sha,
        arm="G_ON",
    )
    off_rows = raw_rows(json.loads(args.off_records.read_text()))
    on_rows = raw_rows(json.loads(args.on_records.read_text()))
    require(len(off_rows) == len(on_rows), "OFF/ON raw request count differs")
    pairs = []
    for off, on in zip(off_rows, on_rows, strict=True):
        require(off["key"] == on["key"], "OFF/ON phase, group or ordinal differs")
        require(
            off["request_sha256"] == on["request_sha256"],
            "OFF/ON request identity differs",
        )
        require(off["tokens"] == on["tokens"], "OFF/ON streamed token sequence differs")
        pairs.append(
            {
                key: off[key]
                for key in (
                    "key",
                    "request_sha256",
                    "prompt_tokens",
                    "output_tokens",
                    "output_sha256",
                )
            }
        )
    require(pairs, "at least one paired service request required")
    return {
        "status": PASS,
        "producer_sha": args.producer_sha,
        "producer_tree": tree,
        "checker_sha": args.checker_sha,
        "requests": {"path": str(args.requests), "sha256": requests_sha},
        "pairs": pairs,
        "pair_count": len(pairs),
        "scope": (
            "Same explicitly bound producer source, deterministic official HTTP requests and complete streamed "
            "token IDs only; warmup and measured rows included"
        ),
        "independent_draft_numeric": "NOT_ASSESSED",
        "target_kv_isolation": "NOT_ASSESSED",
        "normal_completion": "NOT_PROVEN_BY_HTTP_RETURN",
        "execution_operand": "NOT_PROVEN",
        "physical_read": "NOT_AVAILABLE",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("check",))
    parser.add_argument("--producer-sha", required=True)
    parser.add_argument("--checker-sha", required=True)
    for name in (
        "requests",
        "off-campaign",
        "off-records",
        "off-result",
        "on-campaign",
        "on-records",
        "on-result",
        "output",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    try:
        result = check(args)
    except (ValueError, KeyError, TypeError, IndexError, AttributeError, OSError) as error:
        result = {"status": "INVALID_EVIDENCE", "error": f"{type(error).__name__}: {error}"}
    write(args.output, result)
    return 0 if result["status"] == PASS else 4


if __name__ == "__main__":
    raise SystemExit(main())
