# SPDX-License-Identifier: Apache-2.0
"""One saved SWA failure's Full FIA operands, on one device without a model.

Functional, out and task-update Graph calls use the same saved read-only KV.
The original padded batch and an explicitly labelled active-only diagnostic
are kept separate. This cannot waive the model failure or prove model lifetime,
Target isolation, performance, execution operands or a physical read-set.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import json
import os
import time

import torch

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair6_storage import CollectionReader
from tools.p7x_graph_repair6_submission import SubmissionState
from tools.p7x_graph_repair67_dspark_projection_probe import export_failure_and_isolate

SCHEMA = 'repair75-saved-swa-full-fia-v1'
REPEATS = 5
PHASES = ('functional', 'out', 'graph_update')
CASES = (('original_padded4', 4), ('active3_only_diagnostic', 3))


def case_specs(capacity_contrast=False):
    if capacity_contrast:
        return (('original_padded4', 4, 'full'), ('same_storage_bounded_padded4', 4, 'view'),
                ('compact_storage_padded4', 4, 'compact'))
    return tuple((name, padded, 'full') for name, padded in CASES)


def operands(record):
    require(record['status'] == 'CAPTURED_COMPLETE' and record['identity']['rank'] == 0
            and record['identity']['actual'] == 3 and record['identity']['padded'] == 4
            and all(type(record['identity'][key]) is int and record['identity'][key] > 0 for key in ('generation', 'epoch'))
            and len(record['requests']) == len(set(record['requests'])) == len(record['row_phases']) == 3,
            'completed original rank0 active3/padded4 sample required')
    full = next(name for name, meta in record['actual_metadata'].items() if meta['gid'] == record['full_gid'])
    parts = [next(cache for cache in record['caches'].values() if full+'/'+str(i) in cache['layers']) for i in (0, 1)]
    require(parts[0]['selected'] == parts[1]['selected']
            and parts[0]['allocation']['shape'] == parts[1]['allocation']['shape']
            and all(p['allocation']['stride'] == [32768, 256, 128, 1] for p in parts), 'Full K/V allocation differs')
    probe = record['owned_failure_probe']
    values = dict(query=probe['graph_attention']['query'], selected=torch.tensor(parts[0]['selected'], dtype=torch.int64),
        key=parts[0]['graph'], value=parts[1]['graph'], table=record['actual_metadata'][full]['table'],
        model_graph=probe['graph_attention']['output'], model_eager=probe['reference_attention']['output'])
    meta = dict(full_layer=full, full_shape=parts[0]['allocation']['shape'],
        source_formats=[p['allocation']['npu_format'] for p in parts],
        kv_lengths=list(record['actual_metadata'][full]['exact']),
        capture_kv_lengths=probe['graph_attention']['metadata']['seq_lens_list'],
        query_lengths=list(record['actual_metadata'][full]['cumulative_query']),
        source_identity=record['identity'], source_requests=record['requests'], source_phases=record['row_phases'])
    validate_operands(values, meta)
    return values, meta


def validate_operands(values, meta):
    q, k, v, table, selected = (values[name] for name in ('query', 'key', 'value', 'table', 'selected'))
    shape = meta['full_shape']
    require(len(shape) == 4 and type(shape[0]) is int and 0 < shape[0] <= 200000
            and shape[1:] == [128, 2, 128] and meta['source_formats'] in ([0, 0], [2, 2]),
            'declared original Full ND geometry/format differs')
    require(q.dtype == k.dtype == v.dtype == torch.bfloat16 and list(q.shape) == [32, 8, 128]
            and k.shape == v.shape == (selected.numel(), 128, 2, 128)
            and selected.dtype == torch.int64 and selected.ndim == 1 and selected.numel() > 0
            and selected.tolist() == sorted(set(selected.tolist()))
            and 0 <= int(selected[0]) <= int(selected[-1]) < shape[0], 'saved query/KV selection differs')
    require(table.dtype == torch.int32 and table.ndim == 2 and table.shape[0] == 4
            and meta['query_lengths'] == [8, 16, 24, 32]
            and len(meta['kv_lengths']) == len(meta['capture_kv_lengths']) == 4
            and all(type(e) is int and e >= 8 for e in meta['kv_lengths'][:3])
            and meta['kv_lengths'][3] == 0
            and all(type(e) is int and max(meta['kv_lengths']) <= e <= 40960 for e in meta['capture_kv_lengths'])
            and torch.count_nonzero(table[3]) == 0, 'saved active/padded lengths/table differ')
    for row, length in enumerate(meta['kv_lengths'][:3]):
        count = (length+127)//128
        require(count <= table.shape[1] and set(table[row, :count].tolist()) <= set(selected.tolist()),
                'missing saved Full read block; do not replace with zeros')
    require(all(value.device.type == 'cpu' and bool(torch.isfinite(value).all()) for value in values.values()),
            'prepared operand must be finite CPU values')
    require(all(values[name].dtype == q.dtype and values[name].shape == q.shape
                for name in ('model_graph', 'model_eager')), 'original attention outputs missing')


def prepare(args):
    from safetensors.torch import save_file
    reader = CollectionReader(args.collection)
    failure = json.loads((args.collection.parent/'failure.json').read_text())
    require(reader.execution == 'FAILED' and len(reader.samples) == 1 and not failure['submission']['pending'],
            'known-complete failed sample required; never read uncertain submission')
    values, meta = operands(reader.record(0))
    require(not args.output.exists(), 'fresh prepared directory required')
    args.output.mkdir(parents=True)
    data = args.output/'operands.safetensors'
    save_file({k: v.contiguous() for k, v in values.items()}, str(data))
    write(args.output/'input.json', dict(schema=SCHEMA, tool_sha256=digest(__file__),
        collection=dict(path=str(args.collection), sha256=digest(args.collection)),
        failure=dict(path=str(args.collection.parent/'failure.json'), sha256=digest(args.collection.parent/'failure.json')),
        data=dict(path=str(data), bytes=data.stat().st_size, sha256=digest(data)), metadata=meta,
        source_header=reader.header,
        scope='Read-only saved rank0 Full attention operands; unselected KV zero-filled in probe. Original model failure unchanged.'))


def summaries(outputs, cases=CASES):
    result = []
    for name, padded in cases:
        for phase in PHASES:
            sequence = [outputs[f'{name}_{phase}_{i}'] for i in range(REPEATS)]
            require(all(v.dtype == torch.bfloat16 and list(v.shape) == [padded*8, 8, 128] for v in sequence),
                    'native output ABI differs')
            result.append(dict(case=name, phase=phase, finite=all(bool(torch.isfinite(v).all()) for v in sequence),
                exact_to_first=[torch.equal(sequence[0], v) for v in sequence],
                changed_elements=[int(torch.count_nonzero(sequence[0] != v)) for v in sequence],
                max_abs_to_first=[float((sequence[0].float()-v.float()).abs().max()) for v in sequence]))
    return result


@torch.inference_mode()
def run(args):
    import torch_npu
    from safetensors.torch import load_file, save_file
    from tools.p7x_graph_repair21_rank import validate_admission
    from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay

    source = Path(__file__).resolve().parents[1]
    receipt = json.loads(args.admission.read_text())
    manifest = json.loads((args.input/'input.json').read_text())
    require(manifest['schema'] == SCHEMA and manifest['tool_sha256'] == digest(__file__)
            and digest(manifest['data']['path']) == manifest['data']['sha256'], 'prepared input identity changed')
    validate_runtime_overlay(receipt['runtime_manifest']['path'], source, args.expected_sha, receipt['source_tree'])
    validate_admission(args.admission, source=source, sha=args.expected_sha, tp=1)
    require(not args.output.exists(), 'fresh native output required')
    args.output.mkdir(parents=True)
    data = load_file(manifest['data']['path']); meta = manifest['metadata']; validate_operands(data, meta)
    state = SubmissionState(); outputs = {}; retained = []; readbacks = {}; layouts = []
    contrast = args.capacity_contrast
    specs = case_specs(contrast)
    cases = tuple((name, padded) for name, padded, _ in specs)
    try:
        state.submit('SAVED_OPERANDS_UPLOAD_PENDING')
        # The model cache is an ND view over flat storage. Constructing a
        # four-dimensional zeros tensor selects a different base format.
        elements = 1
        for extent in meta['full_shape']: elements *= extent
        key = torch.zeros(elements, dtype=torch.bfloat16, device='npu:0').view(meta['full_shape'])
        value = torch.zeros(elements, dtype=torch.bfloat16, device='npu:0').view(meta['full_shape'])
        indices = data['selected'].to('npu:0')
        key.index_copy_(0, indices, data['key'].to('npu:0'))
        value.index_copy_(0, indices, data['value'].to('npu:0'))
        key = key.view(key.shape[0], 128, 256); value = value.view(value.shape[0], 128, 256)
        torch.npu.synchronize(); state.complete('SAVED_OPERANDS_UPLOAD_COMPLETE')
        formats = [int(torch_npu.get_npu_format(v)) for v in (key, value)]
        write(args.output/'allocation_headers.json', dict(source_formats=meta['source_formats'],
            actual=[dict(shape=list(t.shape), stride=list(t.stride()), format=f, data_ptr=t.data_ptr())
                    for t, f in zip((key, value), formats)], flat_storage=True))
        require(formats == [2, 2], f'probe must retain original ND without format conversion; actual={formats}')
        bound = int(data['selected'][-1])+1
        def snapshot_pair(label, k, v):
            # Bound the gather's visible size as well; do not rely on a large
            # index_select to verify the original large allocation.
            state.submit(label+'_INPUT_READBACK_PENDING')
            readbacks[label+'_key'] = k[:bound].index_select(0, indices).cpu().clone()
            readbacks[label+'_value'] = v[:bound].index_select(0, indices).cpu().clone()
            state.complete(label+'_INPUT_READBACK_COMPLETE')
        if contrast: snapshot_pair('full_before', key, value)
        compact = None
        for name, padded, mode in specs:
            state.submit(name+'_BUFFERS_PENDING')
            case_key, case_value = key, value
            if mode == 'view': case_key, case_value = key[:bound], value[:bound]
            elif mode == 'compact':
                case_key = torch.zeros(bound*128*256, dtype=torch.bfloat16, device='npu:0').view(bound, 128, 256)
                case_value = torch.zeros_like(case_key)
                case_key.index_copy_(0, indices, data['key'].reshape(-1, 128, 256).to('npu:0'))
                case_value.index_copy_(0, indices, data['value'].reshape(-1, 128, 256).to('npu:0'))
                compact = case_key, case_value
            query = data['query'][:padded*8].to('npu:0')
            table = data['table'][:padded].to('npu:0')
            capture_table = torch.zeros_like(table)
            output = torch.empty_like(query); lse = torch.empty(1, dtype=query.dtype, device=query.device)
            qlens = [8*(i+1) for i in range(padded)]
            lengths = meta['kv_lengths'][:padded]; initial = meta['capture_kv_lengths'][:padded]
            common = dict(query=query, key=case_key, value=case_value, atten_mask=None, input_layout='TND', block_size=128,
                num_key_value_heads=2, num_heads=8, scale=128**-.5, sparse_mode=0,
                pre_tokens=2147483647, next_tokens=2147483647, actual_seq_lengths=qlens)
            workspace = torch_npu._npu_fused_infer_attention_score_get_max_workspace(
                **common, block_table=capture_table, actual_seq_lengths_kv=initial)
            torch.npu.synchronize(); state.complete(name+'_BUFFERS_COMPLETE')
            layouts.append(dict(case=name, mode=mode, operands=[dict(shape=list(t.shape),stride=list(t.stride()),
                data_ptr=t.data_ptr(),storage_bytes=t.untyped_storage().nbytes(),format=int(torch_npu.get_npu_format(t)))
                for t in (case_key,case_value)]))
            if contrast:
                if mode == 'compact': snapshot_pair('compact_before', case_key, case_value)
                state.submit(name+'_QUERY_TABLE_BEFORE_READBACK_PENDING')
                readbacks[name+'_query_before'] = query.cpu().clone()
                readbacks[name+'_table_before'] = table.cpu().clone()
                state.complete(name+'_QUERY_TABLE_BEFORE_READBACK_COMPLETE')
            for phase in PHASES[:2]:
                for i in range(REPEATS):
                    state.submit(f'{name}_{phase}_{i}_PENDING')
                    if phase == 'functional':
                        computed = torch_npu.npu_fused_infer_attention_score(
                            **common, block_table=table, actual_seq_lengths_kv=lengths)[0]
                    else:
                        torch_npu.npu_fused_infer_attention_score.out(**common, block_table=table,
                            actual_seq_lengths_kv=lengths, workspace=workspace, out=[output, lse])
                        computed = output
                    torch.npu.synchronize(); state.complete(f'{name}_{phase}_{i}_COMPLETE')
                    outputs[f'{name}_{phase}_{i}'] = computed.detach().cpu().clone()
            state.submit(name+'_GRAPH_CAPTURE_PENDING')
            graph = torch.npu.NPUGraph(); replay = torch.npu.Stream(); update = torch.npu.Stream()
            event = torch.npu.ExternalEvent(); replay.wait_stream(torch.npu.current_stream())
            with torch.npu.graph(graph, stream=replay):
                event.wait(replay); event.reset(replay)
                torch.npu.graph_task_group_begin(replay)
                torch_npu.npu_fused_infer_attention_score.out(**common, block_table=capture_table,
                    actual_seq_lengths_kv=initial, workspace=workspace, out=[output, lse])
                handle = torch.npu.graph_task_group_end(replay)
            state.complete(name+'_GRAPH_CAPTURE_COMPLETE')
            retained.append((graph, replay, update, event, handle, query, table, capture_table,
                             output, lse, workspace, qlens, lengths, initial, case_key, case_value))
            for i in range(REPEATS):
                state.submit(f'{name}_GRAPH_UPDATE_REPLAY_{i}_PENDING')
                update.wait_stream(torch.npu.current_stream())
                with torch.npu.stream(replay): graph.replay()
                with torch.npu.stream(update):
                    torch.npu.graph_task_update_begin(update, handle)
                    torch_npu.npu_fused_infer_attention_score.out(**common, block_table=table,
                        actual_seq_lengths_kv=lengths, workspace=workspace, out=[output, lse])
                    torch.npu.graph_task_update_end(update); event.record(update)
                replay.synchronize(); update.synchronize()
                state.complete(f'{name}_GRAPH_UPDATE_REPLAY_{i}_COMPLETE')
                outputs[f'{name}_graph_update_{i}'] = output.detach().cpu().clone()
            if contrast:
                state.submit(name+'_QUERY_TABLE_AFTER_READBACK_PENDING')
                readbacks[name+'_query_after'] = query.cpu().clone()
                readbacks[name+'_table_after'] = table.cpu().clone()
                state.complete(name+'_QUERY_TABLE_AFTER_READBACK_COMPLETE')
        if contrast:
            snapshot_pair('full_after', key, value)
            snapshot_pair('compact_after', *compact)
            readback_file = args.output/'input_readback.safetensors'
            save_file(readbacks,str(readback_file))
        saved = args.output/'outputs.safetensors'; save_file(outputs, str(saved))
        write(args.output/'result.json', dict(schema=SCHEMA, source_sha=args.expected_sha,
            tool_sha256=digest(__file__),
            pid=os.getpid(), start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
            hostname=os.uname().nodename, visibility=os.environ.get('ASCEND_RT_VISIBLE_DEVICES'), logical_device=0,
            actual_device_world_size=1, model_loaded=False, versions=dict(torch=str(torch.__version__), torch_npu=str(torch_npu.__version__)),
            admission_sha256=digest(args.admission), input_manifest_sha256=digest(args.input/'input.json'),
            device_formats=formats, records=summaries(outputs,cases), submission=state.snapshot(),
            capacity_contrast=contrast, cache_operand_headers=layouts,
            input_readback=None if not contrast else dict(path=str(readback_file),sha256=digest(readback_file)),
            output=dict(path=str(saved), sha256=digest(saved)),
            scope='Saved read-only operands, zero unselected KV; finite serialized functional/out/update-Graph comparison. Original C179/C180 model failures unchanged.'))
        time.sleep(10)  # Management association after completed computation, never model timing.
    except BaseException as error:
        export_failure_and_isolate(args.output, state, error)
        raise


def check(args):
    from safetensors.torch import load_file
    manifest = json.loads((args.input/'input.json').read_text()); result = json.loads(args.result.read_text())
    require(manifest['schema'] == result['schema'] == SCHEMA
            and result['tool_sha256'] == manifest['tool_sha256']
            and result['input_manifest_sha256'] == digest(args.input/'input.json')
            and digest(manifest['collection']['path']) == manifest['collection']['sha256']
            and digest(manifest['failure']['path']) == manifest['failure']['sha256']
            and digest(manifest['data']['path']) == manifest['data']['sha256']
            and digest(result['output']['path']) == result['output']['sha256']
            and not result['submission']['pending'] and result['submission']['failure'] is None
            and result['actual_device_world_size'] == 1 and result['model_loaded'] is False,
            'changed or incomplete original/prepared/native evidence')
    data = load_file(manifest['data']['path']); original = CollectionReader(manifest['collection']['path']).record(0)
    expected, meta = operands(original)
    require(meta == manifest['metadata'] and set(data) == set(expected)
            and all(torch.equal(data[k], v) for k, v in expected.items()), 'prepared values differ from original model sample')
    contrast=result.get('capacity_contrast',False)
    require(type(contrast) is bool,'explicit capacity contrast mode required')
    specs=case_specs(contrast);cases=tuple((name,padded) for name,padded,_ in specs)
    if contrast:
        raw=result['input_readback'];require(digest(raw['path'])==raw['sha256'],'input readback changed')
        readbacks=load_file(raw['path'])
        for owner in ('full','compact'):
            for when in ('before','after'):
                for part in ('key','value'):
                    require(torch.equal(readbacks[f'{owner}_{when}_{part}'],data[part].reshape(-1,128,256)),
                            'uploaded KV differs from saved input or changed during native calls')
        for name,padded,_ in specs:
            for when in ('before','after'):
                require(torch.equal(readbacks[name+'_query_'+when],data['query'][:padded*8])
                        and torch.equal(readbacks[name+'_table_'+when],data['table'][:padded]),
                        'query/table differs from saved input or changed during native calls')
        layouts=result['cache_operand_headers'];bound=int(data['selected'][-1])+1
        require([v['case'] for v in layouts]==[v[0] for v in specs],'missing capacity operand layout')
        for index,row in enumerate(layouts):
            require(row['mode']==specs[index][2],'wrong capacity contrast label')
            for part,actual in enumerate(row['operands']):
                extent=meta['full_shape'][0] if index==0 else bound
                storage_extent=bound if index==2 else meta['full_shape'][0]
                require(actual['shape']==[extent,128,256] and actual['stride']==[32768,256,1]
                        and actual['format']==2 and actual['storage_bytes']==storage_extent*128*256*2,
                        'capacity contrast changed shape/stride/format/storage outside the named variable')
                require((actual['data_ptr']==layouts[0]['operands'][part]['data_ptr']) is (index!=2),
                        'bounded view must retain original backing; compact storage must differ')
    values = load_file(result['output']['path']); records = summaries(values,cases)
    require(records == result['records'], 'producer summary disagrees with saved outputs')
    unstable = [dict(case=v['case'], phase=v['phase']) for v in records if not all(v['exact_to_first'])]
    cross = {name: {phase: dict(different=int(torch.count_nonzero(values[f'{name}_functional_0'] != values[f'{name}_{phase}_0'])),
        max_abs=float((values[f'{name}_functional_0'].float()-values[f'{name}_{phase}_0'].float()).abs().max()))
        for phase in PHASES[1:]} for name, _ in cases}
    status = ('NONFINITE_NATIVE_RESULT' if not all(v['finite'] for v in records) else
              'REPRODUCED_FIA_REPEAT_DIVERGENCE_ON_FIXED_OPERANDS' if unstable else
              'STABLE_NATIVE_GRAPH_EAGER_DIFFERENCE_ON_FIXED_OPERANDS' if any(v['different'] for c in cross.values() for v in c.values()) else
              'NOT_REPRODUCED_WITH_ISOLATED_READONLY_KV')
    return dict(status=status, records=records, unstable_phases=unstable, cross_phase=cross,
        capacity_contrast=contrast,device_inputs_readback_exact=contrast,
        original_model_failure='UNCHANGED_NO_WAIVER', normal_completion='NOT_ASSESSED', performance='NOT_ASSESSED',
        scope='Independent CPU hashes/value checks and native repeat comparison; device/process association verified separately')


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('command', choices=('prepare', 'run', 'check'))
    for name in ('collection', 'input', 'admission', 'result', 'output'):
        parser.add_argument('--'+name, type=Path, required=name == 'output')
    parser.add_argument('--expected-sha')
    parser.add_argument('--capacity-contrast', action='store_true',
                        help='Original padded4 plus bounded visible extent and compact ND storage; verify input readbacks')
    args = parser.parse_args(); torch.set_num_threads(2)
    if args.command == 'prepare': prepare(args)
    elif args.command == 'run': run(args)
    else: write(args.output, check(args))


if __name__ == '__main__': main()
