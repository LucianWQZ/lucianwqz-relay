# SPDX-License-Identifier: Apache-2.0
"""Strict single-scenario reproduction, never a complete matrix/ABA receipt."""
from __future__ import annotations

import json
from pathlib import Path

from tools.p7x_graph_repair6_storage import CollectionReader, require
from tools.p7x_graph_repair15_eagle_numeric_check import validate_binding_schema, validate_sample
from tools.p7x_graph_repair23_eagle_target import (
    PROFILE, base_target_keys, case_plan, expected_layer_counts, selected_reproduction_cases, validate_target_sample,
)

REPRO = "target-padded2-ar-padded1"
PASS = "PASS_SCOPED_EAGLE3_PADDING_REPRODUCTION_ONLY"


def validate_headers(summary, target, numeric, identity):
    selected = selected_reproduction_cases(REPRO)
    require(summary["identity"] == target["identity"] == numeric["identity"] == identity,
            "single-case source/process/engine identity differs")
    require(summary["status"] == "COMPLETE_DECLARED_REPRODUCTION" and summary["reproduction"] == REPRO
            and summary["expected_cases"] == target["cases"] == selected
            and summary["samples"] == 1 and summary["sample_limit"] is None,
            "explicit single-case reproduction scope required")
    require(target["capture_profile"] == summary["profile"] == PROFILE
            and summary["extra_sync"] is True and summary["numerical_reference"] is True,
            "serial diagnostic profile required")
    # The numerical writer retains the complete frozen blueprint, and is
    # deliberately incomplete. The three actual consumers below are separately
    # verified; they cannot be presented as the complete 42-consumer collection.
    validate_binding_schema(numeric)
    require(numeric["controlled_cases"] == case_plan() and numeric["expected_samples"] == 42,
            "unaltered complete numerical blueprint required")
    return selected[0]


def check_reproduction(output, campaign, expected):
    result = dict(status="INVALID_EVIDENCE", full_target="NOT_FULL_OR_DOUBLE_ARM",
                  full_numeric_matrix="NOT_ASSESSED", ABA="NOT_ASSESSED_SINGLE_SCENARIO",
                  normal_overlap="NOT_PROVEN", physical_read="NOT_PROVEN")
    try:
        require(expected.get("eagle3_target_repro") is True and campaign["arm"] == "G_ON",
                "explicit ON padding reproduction plan required")
        output = Path(output)
        summary = json.loads((output / "eagle-target-run.json").read_text())
        target, numeric = CollectionReader(output / "eagle-target.json"), CollectionReader(output / "eagle-numeric.json")
        case = validate_headers(summary, target.header, numeric.header, campaign["identity"])
        require(target.execution == "EXECUTED_SCOPED_NOT_GATE_CLOSURE" and len(target.samples) == 1
                and not target.incomplete(0), "single committed Target case required")
        require(numeric.execution == "INCOMPLETE_COVERAGE" and len(numeric.samples) == 3
                and all(not numeric.incomplete(i) for i in range(3)), "three committed consumers required")
        inventory = target.header["inventory"]
        counts = expected_layer_counts(expected)
        require(target.header["fixture_id"] == "eagle3-fixture:"+expected["method_fixture_sha256"],
                "frozen fixture differs from planned reproduction")
        require(all(len(inventory[role+"_layers"]) == len(set(inventory[role+"_layers"])) == counts[role]
                    for role in ("target", "draft")), "complete actual model layer inventory required")
        require(set(inventory["configured_layers"]) == set(inventory["target_layers"]) | set(inventory["draft_layers"])
                and not set(inventory["target_layers"]) & set(inventory["draft_layers"]), "model owner inventory mismatch")
        require(numeric.header["layers"] == inventory["draft_layers"], "numeric/actual Draft layer ownership mismatch")
        from tools.p7x_graph_repair5_target import sample_identity
        sample = target.record(0)
        require(sample["identity"] == sample_identity(case, target.header["fixture_id"])
                and sample["generation"] == 9, "original scenario index/identity must not be relabelled")
        require(base_target_keys(sample) == {name+"/"+kind for name in inventory["target_layers"] for kind in ("K","V")},
                "sample lacks complete actual Target K/V layers")
        validate_target_sample(sample)  # Full Target input/metadata/KV and actual Full slot checks unchanged.
        rows = [validate_sample(numeric.record(i), numeric.header) for i in range(3)]
        require(all(row["numeric_match"] and row["write_scope_match"] and row["group"] == REPRO for row in rows)
                and [row["step"] for row in rows] == [0, 1, 2]
                and [row["padded"] for row in rows] == [2, 1, 1]
                and len({row["epoch"] for row in rows}) == 1
                and [row["generation"] for row in rows] == list(range(rows[0]["generation"], rows[0]["generation"]+3)),
                "padding transition numerical/KV/consumer identity mismatch")
        terminal = json.loads((output / "eagle-numeric-summary.json").read_text())
        require(terminal["identity"] == campaign["identity"] and terminal["complete"] is False
                and terminal["submission"]["pending"] is False and terminal["submission"]["failure"] is None,
                "reproduction has incomplete or uncertain diagnostic submission")
        result.update(status=PASS, scenario=REPRO, target_samples=1, consumers=rows,
                      scope="Only original scenario9, first-pass pad2 then AR1/AR2 pad1; serial reference, not full matrix/ABA")
    except (ValueError, KeyError, TypeError, IndexError, OSError, RuntimeError) as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result
