# SPDX-License-Identifier: Apache-2.0
"""Official joint-feature GLM service controls with framework acceptance.

Each invocation is one cell of the existing six balanced three-arm orders.
The common HTTP/SSE lifecycle, immutable request contract and rank/device join
remain required. Counter reset is a Host-only RPC after all warmup requests;
no tensor observer, numerical reference, event query or device sync is added.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import asyncio
import json
import time
import urllib.request

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair32_glm_rank import SP_CAPTURE, SP_CAPTURE_CONTRACT, TARGET, profile_identity
from tools.p7x_graph_repair33_service import request, run_service, validate_requests
from tools.p7x_graph_repair40_glm_performance import THREE_ARM_ORDERS, acceptance, validate_ranks
from tools.p7x_graph_repair47_glm_service import glm_serve_argv, validate_prefix_hits
from tools.p7x_graph_repair50_glm_required_baseline import (
    EXTENSION, validate_required_features, validate_required_workers,
)

PROFILE = "GLM_TP16_JOINT_FEATURE_HTTP_THREE_ARM_6CYCLE_V1"


def validate_order(arm, repetition, position):
    require(type(repetition) is int and 1 <= repetition <= 6
            and type(position) is int and 1 <= position <= 3
            and THREE_ARM_ORDERS[repetition - 1][position - 1] == arm,
            "actual cell differs from declared balanced three-arm order")


def joint_serve_argv(python, port, model_name, arm, *, worker_provenance=False):
    argv = glm_serve_argv(python, port, model_name, arm,
                         worker_provenance=worker_provenance, prefix_caching=True)
    argv[argv.index("--no-async-scheduling")] = "--async-scheduling"
    argv += ["--enable-chunked-prefill", "--per-request-spec-decode-metrics", "detailed",
             "--enable-per-request-metrics"]
    argv[argv.index("--compilation-config") + 1] = json.dumps(dict(
        cudagraph_capture_sizes=SP_CAPTURE, cudagraph_mode="FULL_DECODE_ONLY"), sort_keys=True)
    index = argv.index("--additional-config") + 1
    additional = json.loads(argv[index])
    additional.update(enable_dsa_cp=True, enable_flashcomm1=True, multistream_overlap_shared_expert=True)
    if arm == "E_ON":
        additional["draft_window_parallel_eager_review"] = True
    argv[index] = json.dumps(additional, sort_keys=True)
    argv[argv.index("--worker-extension-cls") + 1] = EXTENSION
    return argv


async def measured_client_groups(base, model, groups, output):
    """Reuse the ordinary request collector, with a pre-measurement Host reset."""
    import aiohttp

    rows = []
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=240)) as session:
        for phase in ("warmup", "measured"):
            if phase == "measured":
                body = json.dumps(dict(method="mrv2_glm_perf_reset", args=[], timeout=30)).encode()
                rpc = urllib.request.Request(base + "/collective_rpc", data=body,
                                             headers={"Content-Type": "application/json"})
                start = time.monotonic_ns()
                with urllib.request.urlopen(rpc, timeout=40) as response:
                    require(response.status == 200, "Host counter reset RPC failed")
                    result = json.load(response)["results"]
                write(output / "measurement-counter-reset.json", dict(
                    start_ns=start, end_ns=time.monotonic_ns(), results=result,
                    scope="HOST_COUNTERS_ONLY_NO_DEVICE_OPERATION"))
            for group_index, group in enumerate(groups):
                start = time.monotonic_ns()
                results = await asyncio.gather(*[
                    request(session, base + "/v1/completions", model=model,
                            prompt=prompt["prompt_token_ids"], output=group["max_tokens"],
                            failure_path=output / f"failed-{phase}-group{group_index}-request{index}.json")
                    for index, prompt in enumerate(group["prompts"])])
                rows.append(dict(phase=phase, label=group["label"], group_start_ns=start,
                                 group_end_ns=time.monotonic_ns(), results=results))
                write(output / "requests.json", dict(groups=rows, status="IN_PROGRESS"))
    return rows


def terminal_metrics(result):
    metrics = [event["data"]["metrics"] for event in result["events"]
               if event["data"].get("usage") is not None and event["data"].get("metrics") is not None]
    require(len(metrics) == 1 and isinstance(metrics[0], dict)
            and metrics[0].get("speculative_decoding") is not None,
            "unique actual framework terminal acceptance metrics missing")
    return metrics[0], acceptance(metrics[0]["speculative_decoding"])


def performance_groups(document):
    summaries = []
    for group in document["groups"]:
        if group["phase"] != "measured":
            continue
        requests = []
        for result in group["results"]:
            metrics, counts = terminal_metrics(result)
            summary = result["summary"]
            requests.append(dict(response_id=summary["response_id"],
                prompt_tokens=summary["usage"]["prompt_tokens"],
                output_tokens=summary["usage"]["completion_tokens"],
                cached_tokens=summary["usage"]["prompt_tokens_details"]["cached_tokens"],
                client_elapsed_seconds=summary["elapsed_seconds"], client_ttft_seconds=summary["ttft_seconds"],
                client_mean_tpot_seconds=summary["mean_tpot_seconds"],
                client_tpot_definition=summary["tpot_definition"],
                client_token_itl=summary["token_itl_distribution"],
                framework_metrics=metrics, acceptance=counts))
        elapsed = (group["group_end_ns"] - group["group_start_ns"]) / 1e9
        require(elapsed > 0 and requests, "completed measured group required")
        emitted = sum(row["output_tokens"] for row in requests)
        proposed = sum(row["acceptance"]["proposed"] for row in requests)
        accepted = sum(row["acceptance"]["accepted"] for row in requests)
        steps = sum(row["acceptance"]["verification_request_steps"] for row in requests)
        summaries.append(dict(label=group["label"], requests=requests, elapsed_seconds=elapsed,
            input_tokens=sum(row["prompt_tokens"] for row in requests), output_tokens=emitted,
            output_tokens_per_second=emitted / elapsed, proposed=proposed, accepted=accepted,
            verification_request_steps=steps, acceptance_rate=accepted / proposed,
            mean_acceptance_length_including_bonus=1 + accepted / steps,
            elapsed_definition="One client monotonic group span; concurrent request durations are not summed"))
    require(bool(summaries), "no measured performance groups")
    return summaries


def check_saved(args):
    validate_order(args.arm, args.repetition, args.order_position)
    source = Path(__file__).resolve().parents[1]
    campaign = json.loads(args.campaign.read_text())
    require(campaign["performance_profile"] == PROFILE and campaign["arm"] == args.arm
            and type(campaign["repetition"]) is int and type(campaign["order_position"]) is int
            and campaign["repetition"] == args.repetition and campaign["order_position"] == args.order_position
            and campaign["source_sha"] == args.expected_sha
            and campaign["requests_sha256"] == digest(args.requests), "joint performance cell identity differs")
    receipt_path = Path(campaign["admission_path"])
    require(digest(receipt_path) == campaign["admission_sha256"], "original admission changed")
    receipt = json.loads(receipt_path.read_text())
    require(receipt["source_sha"] == campaign["source_sha"] and receipt["source_tree"] == campaign["source_tree"]
            and receipt["tp"] == 16, "complete source/rank admission differs")
    argv = joint_serve_argv(campaign["server_argv"][0], args.port,
        campaign["server_argv"][campaign["server_argv"].index("--served-model-name") + 1],
        args.arm, worker_provenance=True)
    require(argv == json.loads(args.server_argv.read_text()), "actual joint performance argv differs")
    document = json.loads(args.records.read_text())
    result = validate_requests(campaign, document, json.loads(args.requests.read_text()),
        expected_server_argv=argv, expected_source=source, expected_vllm_source=receipt["vllm_checkout"],
        worker_identity_validator=validate_required_workers, worker_extension_cls=EXTENSION)
    rows = campaign["worker_provenance"][-1]["results"]
    reset = json.loads(args.records.with_name("measurement-counter-reset.json").read_text())
    groups = document["groups"]
    warmup = [group for group in groups if group["phase"] == "warmup"]
    measured = [group for group in groups if group["phase"] == "measured"]
    require(reset["scope"] == "HOST_COUNTERS_ONLY_NO_DEVICE_OPERATION"
            and warmup[-1]["group_end_ns"] <= reset["start_ns"] < reset["end_ns"]
            <= measured[0]["group_start_ns"], "Host reset was not between complete warmup and timing")
    expected_pids = {row["rank_snapshot"]["rank"]: row["pid"] for row in rows}
    actual = reset["results"]
    require(len(actual) == 16 and {row["rank"]: row["pid"] for row in actual} == expected_pids
            and all(row["reset"] == "HOST_COUNTERS_ONLY_NO_DEVICE_OPERATION" for row in actual),
            "reset does not belong to the complete actual worker set")
    result.update(required_features=validate_required_features(
        rows, require_execution=True, require_graph_window=args.arm == "G_ON"),
        prefix=validate_prefix_hits(campaign, document),
        measured_host_dispatch=validate_ranks([row["rank_snapshot"] for row in rows],
            source=source, pin=receipt["vllm_checkout"], arm=args.arm, need_clip=args.arm != "G_OFF",
            capture_contract=SP_CAPTURE_CONTRACT, eager_async_lanes=args.arm == "E_ON"),
        performance_groups=performance_groups(document), performance_profile=PROFILE,
        repetition=args.repetition, order_position=args.order_position,
        count_scope="Measured interval after Host-only reset; not summed over TP ranks",
        cache_scope="Actual per-request cached-token counts reported; warmup uses same workload",
        numeric="NOT_ASSESSED", normal_completion="NOT_PROVEN", physical_read="NOT_AVAILABLE")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("run", "check"))
    parser.add_argument("--arm", choices=("G_OFF", "G_ON", "E_ON"), required=True)
    parser.add_argument("--repetition", type=int, required=True)
    parser.add_argument("--order-position", type=int, required=True)
    parser.add_argument("--expected-sha", required=True)
    parser.add_argument("--port", type=int, required=True)
    for name in ("requests", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    for name in ("admission", "campaign", "records", "server-argv"):
        parser.add_argument("--" + name, type=Path)
    args = parser.parse_args()
    validate_order(args.arm, args.repetition, args.order_position)
    if args.command == "check":
        try:
            result = check_saved(args)
        except (ValueError, KeyError, TypeError, IndexError, AttributeError, OSError) as error:
            result = dict(status="INVALID_EVIDENCE", error=f"{type(error).__name__}: {error}")
        write(args.output, result)
        return 0 if result["status"] == "PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS" else 4
    args.worker_provenance = True
    return run_service(args, server_argv_builder=joint_serve_argv, target_model=str(TARGET),
        tp=16, ready_timeout_seconds=1800, client_runner=measured_client_groups,
        extra_metadata=dict(model_profile=profile_identity(), performance_profile=PROFILE,
            repetition=args.repetition, order_position=args.order_position,
            joint_performance_entrypoint_sha256=digest(__file__), prefix_cache_requested=True,
            measurement="NORMAL_HTTP_NO_NUMERIC_REFERENCE_NO_LIFE_SYNC_NO_PROFILER"))


if __name__ == "__main__":
    raise SystemExit(main())
