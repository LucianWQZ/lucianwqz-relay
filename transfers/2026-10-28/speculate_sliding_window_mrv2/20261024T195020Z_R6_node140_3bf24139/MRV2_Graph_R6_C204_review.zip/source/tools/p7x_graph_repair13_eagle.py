#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Static-K Eagle3 migration/dispatch anchor; no continuous-numeric verdict.

First pass Q=K+1 and K-1 merged AR consumers Q=1 are independent managers.
Baseline arms and the default-off experimental Graph/Window-ON anchor keep
Target Graph unchanged. No arm provides a continuous-numeric verdict or opens
the public Graph gate.
"""

from __future__ import annotations

import argparse
import copy
from contextlib import ExitStack
import hashlib
import json
import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair5_evidence import audit_execution, file_sha, require
from tools.p7x_graph_repair6_storage import atomic_json

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = dict(
    method="eagle3",
    k=3,
    first_pass_query=4,
    ar_query=1,
    ar_consumers=2,
    causal=True,
    window=1024,
    block=128,
    capture_sizes=[1, 2, 4, 8, 16],
)


def validate_contract(document):
    require(
        isinstance(document, dict)
        and document == CONTRACT
        and set(document) == set(CONTRACT)
        and all(type(document[k]) is type(v) for k, v in CONTRACT.items())
        and all(type(n) is int for n in document["capture_sizes"]),
        "exact static Eagle3 contract",
    )


def configure(base, arm):
    require(arm in ("G_OFF", "E_ON", "G_ON"), "unknown Eagle3 arm")
    config = copy.deepcopy(base)
    config["max_model_len"] = 8192
    config["speculative_config"] = dict(
        model=base["speculative_config"]["model"],
        method="eagle3",
        num_speculative_tokens=3,
        enforce_eager=arm == "E_ON",
    )
    config["compilation_config"]["cudagraph_capture_sizes"] = list(CONTRACT["capture_sizes"])
    config["additional_config"] = {} if arm == "G_OFF" else dict(draft_window_size=1024)
    config["per_request_spec_decode_metrics"] = "detailed"
    # A separate statistics arm: framework CPU timestamps, no new NPU reads.
    config["disable_log_stats"] = False
    require(
        config["enforce_eager"] is False and not config["async_scheduling"] and not config["enable_prefix_caching"],
        "fixed Target/prefix/async policy",
    )
    return config


def counts(value):
    drafted, accepted = value["per_step_drafted"], value["per_step_accepted"]
    require(value["num_spec_tokens"] == 3 and len(value["acceptance_histogram"]) == 4, "Eagle3 K3 counters")
    require(all(type(n) is int and n >= 0 for n in value["acceptance_histogram"]), "Eagle3 histogram dtype")
    require(drafted and len(drafted) == len(accepted), "Eagle3 scheduled steps")
    require(
        all(type(d) is int and type(a) is int and 0 <= a <= d <= 3 and d > 0 for d, a in zip(drafted, accepted)),
        "Eagle3 actual proposed/accepted",
    )
    require([accepted.count(i) for i in range(4)] == value["acceptance_histogram"], "Eagle3 histogram")
    require(
        (sum(drafted), sum(accepted), len(drafted))
        == (value["num_draft_tokens"], value["num_accepted_draft_tokens"], value["num_spec_steps"]),
        "Eagle3 totals",
    )
    require(
        abs(value["draft_acceptance_rate"] - sum(accepted) / sum(drafted)) < 1e-12
        and abs(value["mean_acceptance_length"] - (1 + sum(accepted) / len(drafted))) < 1e-12,
        "Eagle3 acceptance excludes bonus; acceptance length includes bonus",
    )
    return dict(proposed=sum(drafted), accepted=sum(accepted), verification_request_steps=len(drafted))


def add_cases(cases, inputs, output, repo, python, source_sha, receipt_path, receipt_sha, *, pinned_h2d_review=False):
    require(type(pinned_h2d_review) is bool, "explicit pinned H2D plan bool required")
    fixture = inputs / "eagle3-k3-fixture.json"
    request = inputs / "requests/eagle3-k3-anchor.json"
    require(fixture.exists() and request.exists(), "explicit Eagle3 inputs")
    for arm in ("G_OFF", "E_ON", "G_ON"):
        name = "EAGLE3_" + arm
        case = copy.deepcopy(cases["A0"])
        mode = "A0" if arm == "G_OFF" else "B-observer-off"
        case["argv"] = [
            python,
            str(repo / "tools/p7x_graph_repair13_eagle.py"),
            "run",
            "--case",
            mode,
            "--case-id",
            name,
            "--attempt",
            "1",
            "--run-id",
            case["acceptance_identity"]["run_id"],
            "--expected-sha",
            source_sha,
            "--arm",
            arm,
            "--fixture",
            str(fixture),
            "--fixture-sha256",
            file_sha(fixture),
            "--fixture-receipt",
            str(receipt_path),
            "--fixture-receipt-sha256",
            receipt_sha,
            "--requests",
            str(request),
            "--vllm-repo",
            cases["A0"]["argv"][cases["A0"]["argv"].index("--vllm-repo") + 1],
            "--output",
            str(output / name),
        ]
        if pinned_h2d_review and arm == "G_ON":
            case["argv"].append("--eagle3-pinned-h2d-review")
            case["eagle3_pinned_h2d_review"] = True
        case["launch_argv"] = [
            python,
            str(repo / "tools/p7x_graph_repair2.py"),
            "launch",
            "--run-id",
            case["acceptance_identity"]["run_id"],
            "--case-id",
            name,
            "--attempt",
            "1",
            "--mode",
            mode,
            "--timeout",
            "1200",
            "--output",
            str(output / "launchers" / name),
            "--",
            *case["argv"],
        ]
        case["acceptance_identity"].update(case_id=name, driver_mode=mode)
        case.update(
            case_id=name,
            driver_mode=mode,
            outputs=str(output / name),
            timeout_seconds=1200,
            dependencies=["CONFIG_EAGLE3"] if arm == "G_OFF" else ["CONFIG_EAGLE3", "EAGLE3_G_OFF"],
            request_path=str(request),
            requests_sha256=file_sha(request),
            method_fixture_sha256=file_sha(fixture),
            eagle3_contract=copy.deepcopy(CONTRACT),
            eagle3_arm=arm,
            selection="OPT_IN_EAGLE3_DEFAULT_OFF_GRAPH_WINDOW_ANCHOR"
            if arm == "G_ON" else "OPT_IN_EAGLE3_BASELINE_NOT_GRAPH_WINDOW_VALIDATION",
        )
        case["validation_commands"] = [
            dict(
                kind="read_only_acceptance",
                timeout=120,
                argv=[
                    python,
                    str(repo / "tools/p7x_graph_repair13_eagle.py"),
                    "check",
                    "--artifact",
                    str(output / name / "profile.json"),
                    "--campaign",
                    str(output / name / "campaign.json"),
                    "--launcher",
                    str(output / "launchers" / name / "launcher.json"),
                    "--plan",
                    str(output / "case-plan.json"),
                    "--case-id",
                    name,
                    "--output",
                    str(output / name / "eagle3-joint.json"),
                ],
            )
        ]
        case.pop("check_argv", None)
        case.pop("additional_checks", None)
        cases[name] = case
    from tools.p7x_graph_repair19_eagle_unwind import POINTS
    for point in POINTS:
        source, name = "EAGLE3_G_ON", "UNWIND_EAGLE3_" + point
        case = json.loads(json.dumps(cases[source]).replace(source, name))
        for field in ("argv", "launch_argv"):
            case[field].extend(["--eagle3-unwind", point])
        case.update(eagle3_unwind_point=point,
                    selection="OPT_IN_REAL_EAGLE3_PYTHON_UNWIND",
                    dependencies=["CONFIG_EAGLE3", source])
        case["validation_commands"] = [
            dict(kind="read_only_acceptance",
                 timeout=120,
                 argv=[
                     python,
                     str(repo / "tools/p7x_graph_repair19_eagle_unwind.py"), "--artifact",
                     str(output / name / "eagle-unwind.json"), "--campaign",
                     str(output / name / "campaign.json"), "--launcher",
                     str(output / "launchers" / name / "launcher.json"), "--plan",
                     str(output / "case-plan.json"), "--case-id", name, "--output",
                     str(output / name / "eagle-unwind-joint.json")
                 ])
        ]
        cases[name] = case
    from tools.p7x_graph_repair35_eagle_abort import add_cases as add_abort_cases
    add_abort_cases(cases, repo, output, python)
    source_name, numeric_name = "EAGLE3_G_ON", "EAGLE3_NUMERIC"

    def numeric_clone(value):
        if isinstance(value, str):
            return value.replace(source_name, numeric_name)
        if isinstance(value, list):
            return [numeric_clone(v) for v in value]
        if isinstance(value, dict):
            return {k: numeric_clone(v) for k, v in value.items()}
        return value

    numeric = numeric_clone(copy.deepcopy(cases[source_name]))
    numeric["argv"].append("--eagle3-numeric")
    numeric["launch_argv"].append("--eagle3-numeric")
    numeric.update(eagle3_numeric=True,
                   selection="OPT_IN_CAPTURE_COPIES_AND_SERIAL_EAGLE3_REFERENCE",
                   dependencies=["CONFIG_EAGLE3", source_name])
    numeric.setdefault("resource_policy", {})["minimum_launch_free_bytes"] = max(
        numeric.get("resource_policy", {}).get("minimum_launch_free_bytes", 0), 8 << 30)
    cases[numeric_name] = numeric
    life_name = "EAGLE3_LIFE"
    life = json.loads(json.dumps(cases[source_name]).replace(source_name, life_name))
    for field in ("argv", "launch_argv"):
        life[field].append("--eagle3-life")
    life.update(eagle3_life=True,
                selection="OPT_IN_REAL_EAGLE3_SERIAL_21_PROPOSAL_LIFE",
                dependencies=["CONFIG_EAGLE3", source_name, numeric_name])
    cases[life_name] = life
    target_requests = inputs / "requests/eagle3-controlled-target.json"
    if target_requests.exists():
        from tools.p7x_graph_repair23_eagle_target import case_plan
        require(json.loads(target_requests.read_text()) == case_plan(), "exact Eagle Target request contract")
        for arm in ("G_OFF", "G_ON"):
            for prefix in (1, None):
                name = "EAGLE3_TARGET_" + ("PREFIX_" if prefix else "") + ("ON" if arm == "G_ON" else "OFF")
                source = "EAGLE3_" + arm
                case = json.loads(json.dumps(cases[source]).replace(source, name))
                for field in ("argv", "launch_argv"):
                    argv = case[field]
                    argv[argv.index("--requests") + 1] = str(target_requests)
                    argv += ["--eagle3-target"]
                    if prefix:
                        argv += ["--eagle3-target-prefix", "1"]
                dependencies = ["CONFIG_EAGLE3", source
                                ] if prefix else ["EAGLE3_TARGET_PREFIX_OFF", "EAGLE3_TARGET_PREFIX_ON"]
                case.update(eagle3_target=True,
                            eagle3_target_prefix=prefix,
                            dependencies=dependencies,
                            request_path=str(target_requests),
                            requests_sha256=file_sha(target_requests),
                            selection="OPT_IN_EAGLE_CONTROLLED_TARGET_SERIAL_REFERENCE_NOT_NORMAL_PERFORMANCE")
                case["timeout_seconds"] = 1200 if prefix else 3600
                case["launch_argv"][case["launch_argv"].index("--timeout") + 1] = "900" if prefix else "3300"
                cases[name] = case
        # One named real failure can be replayed without loading and exporting
        # the preceding nine scenarios. Its checker never claims full coverage.
        name = "EAGLE3_TARGET_PADDING_REPRO_ON"
        source = "EAGLE3_TARGET_ON"
        case = json.loads(json.dumps(cases[source]).replace(source, name))
        for field in ("argv", "launch_argv"):
            case[field].append("--eagle3-padding-repro")
        case.update(eagle3_target_repro=True, dependencies=["CONFIG_EAGLE3", "EAGLE3_G_ON"],
                    selection="OPT_IN_SINGLE_PADDING_REPRO_NOT_FULL_MATRIX", timeout_seconds=1200)
        case["launch_argv"][case["launch_argv"].index("--timeout") + 1] = "900"
        cases[name] = case
    for arm in ("G_OFF", "G_ON", "E_ON"):
        source = "EAGLE3_" + arm
        name = "EAGLE3_SCHED_" + arm
        # All embedded argv/output/checker identities move together. The
        # frozen requests stay unchanged; this is a separate scheduler profile.
        case = json.loads(json.dumps(cases[source]).replace(source, name))
        for field in ("argv", "launch_argv"):
            case[field].append("--scheduler-phases")
        case.update(scheduler_phases=True,
                    selection="OPT_IN_ACTUAL_CHUNKED_SCHEDULER_PHASES",
                    dependencies=["CONFIG_EAGLE3", source])
        cases[name] = case
    case = copy.deepcopy(cases["CONFIG"])
    case.update(
        case_id="CONFIG_EAGLE3",
        outputs=str(output / "CONFIG_EAGLE3"),
        dependencies=["P0"],
        selection="READ_ONLY_REAL_EAGLE3_FRAMEWORK_CONFIGURATION",
        validation_commands=[],
    )
    case["argv"] = [
        python,
        str(repo / "tools/p7x_graph_repair13_eagle.py"),
        "config",
        "--plan",
        str(output / "case-plan.json"),
        "--output",
        str(output / "CONFIG_EAGLE3" / "config.json"),
    ]
    case.pop("launch_argv", None)
    case.setdefault("acceptance_identity",
                    copy.deepcopy(cases["A0"]["acceptance_identity"]))["case_id"] = "CONFIG_EAGLE3"
    cases["CONFIG_EAGLE3"] = case


def configuration(args):
    from tools.p7x_graph_repair2 import build_llm_kwargs, parse_args

    require(file_sha(args.fixture) == args.fixture_sha256, "frozen Eagle3 fixture hash")
    fixture = json.loads(args.fixture.read_text())
    require(fixture["schema"] == "r5-eagle3-k3-fixture-v1", "not the declared static Eagle3 fixture")
    validate_contract(fixture["method_contract"])
    base = parse_args([
        "run",
        "--case",
        args.case,
        "--case-id",
        args.case_id,
        "--run-id",
        args.run_id,
        "--attempt",
        args.attempt,
        "--expected-sha",
        args.expected_sha,
        "--target-model",
        fixture["target_model"],
        "--draft-model",
        fixture["draft_model"],
        "--vllm-repo",
        str(args.vllm_repo),
        "--fixture-manifest",
        str(args.fixture),
        "--output",
        str(args.output),
        "--repair5-capture-profile",
        "target4",
    ])
    config = configure(build_llm_kwargs(base), args.arm)
    pinned_h2d = getattr(args, "eagle3_pinned_h2d_review", False)
    require(type(pinned_h2d) is bool, "explicit pinned H2D experiment bool required")
    if pinned_h2d:
        require(args.arm == "G_ON", "pinned H2D review is a separate Eagle Graph/Window ON experiment")
        config["additional_config"]["draft_window_graph_eagle_pinned_h2d_review"] = True
    require(not getattr(args, "eagle3_padding_repro", False) or getattr(args, "eagle3_target", False),
            "padding reproduction requires the controlled Target entry")
    if getattr(args, "eagle3_numeric", False):
        require(args.arm == "G_ON", "Eagle3 numeric requires actual Graph/Window ON")
        config["additional_config"]["draft_window_graph_numeric_diagnostic"] = True
    if getattr(args, "eagle3_target", False):
        require(
            args.arm in ("G_OFF", "G_ON") and not args.eagle3_numeric and not args.scheduler_phases
            and not args.eagle3_life and args.eagle3_unwind is None,
            "Eagle Target requires its separate controlled process")
        require(args.eagle3_target_prefix in (None, 1), "only declared one-sample Target prefix")
        require(not getattr(args, "eagle3_padding_repro", False) or args.arm == "G_ON" and args.eagle3_target_prefix is None,
                "padding repro cannot replace an OFF arm, prefix or complete matrix")
        if args.arm == "G_ON":
            config["additional_config"]["draft_window_graph_numeric_diagnostic"] = True
    if getattr(args, "scheduler_phases", False):
        require(not getattr(args, "eagle3_numeric", False), "scheduler arm must not install numeric copies/drains")
        from tools.p7x_graph_repair16_scheduler import configure as scheduler_configure
        config = scheduler_configure(config)
    if getattr(args, "eagle3_unwind", None) is not None:
        require(args.arm == "G_ON" and not args.eagle3_numeric and not args.scheduler_phases,
                "Eagle3 unwind requires its separate Graph/Window ON process")
    if getattr(args, "eagle3_life", False):
        require(
            args.arm == "G_ON" and not args.eagle3_numeric and not args.scheduler_phases and args.eagle3_unwind is None,
            "Eagle LIFE requires its separate serial diagnostic process")
    if getattr(args, "eagle3_abort", None) is not None:
        require(args.arm == "G_ON" and not args.eagle3_numeric and not args.scheduler_phases
                and not args.eagle3_life and args.eagle3_unwind is None and not args.eagle3_target,
                "Eagle abort requires a separate disposable Graph/Window ON process")
    return base, fixture, config


def eagle3_bank_snapshot(spec):
    """Host identities/state only; no synchronization, query or tensor reads."""
    session = getattr(spec, "_eagle3_graph_session", None)
    if session is None:
        return dict(installed=False)
    transfers = []
    for transfer in session.controller.transfers:
        carrier = session.provider._require_registered_capture(transfer.capture_identity)
        transfers.append(dict(
            step=transfer.step, generation=transfer.generation, mapping_epoch=transfer.mapping_epoch,
            table_address=transfer.capture_identity.backing_identity.window_block_table.data_ptr,
            state=carrier.state.name, observation=transfer.observation,
        ))
    return dict(installed=True, quarantined=session.controller.quarantined,
                capture_count=len(session._captures), output_reference_count=len(session.captured_outputs),
                updated_transfers=transfers, scope="HOST_BINDING_AND_UPDATE_NOT_DEVICE_COMPLETION")


def run(args):
    from tools.p7x_graph_repair2 import (
        PINNED_VLLM,
        PINNED_VLLM_TREE,
        _git,
        _manager_inventory,
        configure_run_environment,
    )
    from tools.p7x_graph_repair5_profile import RequestProfiler, warmup_requests
    from tools.p7x_graph_repair10_performance import final_window_state, request_metrics
    from tools.p7x_graph_repair12_contract import verify_fixture_receipt

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    sha, tree = _git(ROOT, "rev-parse", "HEAD"), _git(ROOT, "rev-parse", "HEAD^{tree}")
    require(sha == args.expected_sha and not _git(ROOT, "status", "--porcelain"), "clean exact Eagle3 candidate")
    require(
        _git(args.vllm_repo, "rev-parse", "HEAD") == PINNED_VLLM
        and _git(args.vllm_repo, "rev-parse", "HEAD^{tree}") == PINNED_VLLM_TREE
        and not _git(args.vllm_repo, "status", "--porcelain"),
        "unchanged vLLM pin",
    )
    base, fixture, config = configuration(args)
    verify_fixture_receipt(
        SimpleNamespace(
            repair12_fixture_verification=args.fixture_receipt,
            repair12_fixture_verification_sha256=args.fixture_receipt_sha256,
            expected_sha=sha,
            fixture_manifest=args.fixture,
        ),
        fixture,
    )
    entries = json.loads(args.requests.read_text())
    if getattr(args, "eagle3_target", False):
        from tools.p7x_graph_repair23_eagle_target import case_plan
        require(entries == case_plan(), "frozen Eagle controlled Target scenarios")
    else:
        require(len(entries) == 3 and all(e["max_tokens"] == 64 for e in entries), "declared Eagle3 64-token anchor")
    configure_run_environment(base, output)
    import vllm
    from vllm import LLM, SamplingParams

    import vllm_ascend

    identity = dict(
        run_id=args.run_id,
        case_id=args.case_id,
        attempt_id=args.attempt,
        driver_mode=args.case,
        source_sha=sha,
        source_tree=tree,
        vllm_sha=PINNED_VLLM,
        process_id=os.getpid(),
        engine_id=None,
    )
    record = dict(
        identity=identity,
        method_contract=CONTRACT,
        arm=args.arm,
        status="STARTED",
        startup_complete=False,
        llm_kwargs=config,
        config_sha256=hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest(),
        fixture_sha256=file_sha(args.fixture),
        observer_enabled=False,
        outputs=[],
        request_manifest=dict(sha256=file_sha(args.requests), entries=entries),
        imports=dict(vllm=vllm.__file__, vllm_ascend=vllm_ascend.__file__),
        timing_scope="SEPARATE_FRAMEWORK_STATS_ARM_NOT_PERFORMANCE_BASELINE",
    )
    llm = spec = None
    atomic_json(output / "progress.json", dict(identity=identity, phase="BEFORE_STARTUP"))
    try:
        llm = LLM(**config)
        core = llm.llm_engine.engine_core.engine_core
        runner = core.model_executor.driver_worker.worker.model_runner
        spec = runner.speculator
        identity["engine_id"] = id(core)
        require(
            type(spec).__name__ == "AscendEagleSpeculator" and spec.num_speculative_steps == 3,
            "actual Eagle3 factory/static-K identity",
        )
        record.update(
            speculator=f"{type(spec).__module__}.{type(spec).__name__}",
            first_pass_inventory=_manager_inventory(spec.prefill_cudagraph_manager),
            ar_inventory=_manager_inventory(spec.decode_cudagraph_manager),
            target_inventory=_manager_inventory(runner.cudagraph_manager),
            startup_complete=True,
        )
        atomic_json(output / "progress.json", dict(identity=identity, phase="STARTUP_COMPLETE"))
        with RequestProfiler(runner, output, identity, enabled=False) as probe, ExitStack() as diagnostic_stack:
            if getattr(args, "eagle3_target", False):
                from tools.p7x_graph_repair23_eagle_target import run_controlled
                record["timing_scope"] = "CONTROLLED_EAGLE_TARGET_AND_SERIAL_REFERENCE_NOT_PERFORMANCE"
                record["target_run"] = run_controlled(runner,
                                                      core.scheduler,
                                                      output,
                                                      identity,
                                                      args.arm,
                                                      record["fixture_sha256"],
                                                      probe,
                                                      prefix=args.eagle3_target_prefix,
                                                      repro="target-padded2-ar-padded1" if getattr(args, "eagle3_padding_repro", False) else None)
            else:
                warmup_requests(llm, SamplingParams, entries, probe, all_groups=True)
                numeric = None
                if args.eagle3_numeric:
                    from tools.p7x_graph_repair15_eagle_numeric import EagleContinuousReference
                    numeric = diagnostic_stack.enter_context(
                        EagleContinuousReference(runner, core.scheduler, output / "eagle-numeric.json", identity,
                                                 entries))
                    record["timing_scope"] = "CAPTURED_D2D_COPIES_AND_SERIAL_REFERENCE_NOT_NORMAL_PERFORMANCE"
                scheduler_rows = None
                life = None
                if args.eagle3_life:
                    from tools.p7x_graph_repair22_eagle_life import EagleLifecycle
                    life = diagnostic_stack.enter_context(EagleLifecycle(spec, output / "eagle-life.json", identity))
                    record["timing_scope"] = "SERIAL_EAGLE3_LIFE_SYNC_AND_READ_BANK_D2H_NOT_NORMAL_PERFORMANCE"
                if args.scheduler_phases:
                    from tools.p7x_graph_repair16_scheduler import SchedulerRows
                    scheduler_rows = diagnostic_stack.enter_context(SchedulerRows(spec))
                    record["timing_scope"] = "CPU_SCHEDULER_OBSERVATIONS_NOT_NORMAL_PERFORMANCE"
                    record["scheduler_rows"] = scheduler_rows.rows
                if args.eagle3_unwind is not None:
                    from tools.p7x_graph_repair19_eagle_unwind import EagleUnwind
                    diagnostic_stack.enter_context(
                        EagleUnwind(spec, output / "eagle-unwind.json", identity, args.eagle3_unwind))
                    record["timing_scope"] = "SEPARATE_EAGLE3_PYTHON_UNWIND_NOT_NORMAL_PERFORMANCE"
                if getattr(args, "eagle3_abort", None) is not None:
                    from tools.p7x_graph_repair35_eagle_abort import EagleAbort
                    diagnostic_stack.enter_context(
                        EagleAbort(spec, output / "eagle-abort.json", identity, args.eagle3_abort, record))
                    record["timing_scope"] = "DISPOSABLE_EAGLE_PROCESS_ABORT_NOT_NORMAL_PERFORMANCE"
                probe.begin_active()
                for entry in entries:
                    if numeric is not None:
                        numeric.set_group(entry["label"])
                    if scheduler_rows is not None:
                        scheduler_rows.group = entry["label"]
                    if life is not None:
                        life.group = entry["label"]
                    start = time.monotonic_ns()
                    with probe.group(entry["label"]):
                        results = llm.generate(
                            entry["prompts"],
                            SamplingParams(temperature=0.0, seed=0, ignore_eos=True, max_tokens=64),
                            use_tqdm=False,
                        )
                    record["outputs"].append(
                        dict(
                            label=entry["label"],
                            prompts=entry["prompts"],
                            start_ns=start,
                            end_ns=time.monotonic_ns(),
                            token_ids=[x.outputs[0].token_ids for x in results],
                            prompt_token_ids=[x.prompt_token_ids for x in results],
                            metrics=request_metrics(results),
                            window_identity=final_window_state(spec),
                            graph_window_banks=eagle3_bank_snapshot(spec) if args.arm == "G_ON" else None,
                        ))
                    atomic_json(
                        output / "progress.json",
                        dict(
                            identity=identity,
                            phase="REQUEST_GROUP_COMPLETED",
                            completed_groups=len(record["outputs"]),
                            label=entry["label"],
                        ),
                    )
        record["status"] = "OK"
    except BaseException as error:
        import traceback
        record.update(status="EXCEPTION",
                      exception_type=type(error).__name__,
                      exception_message=str(error),
                      exception_traceback=traceback.format_exc())
    finally:
        uncertain = bool(getattr(spec, "_draft_window_graph_submission_uncertain", False))
        record["pinned_h2d_staging"] = pinned_h2d_state(spec)
        record.update(graph_submission_uncertain=uncertain, method_isolation_required=record["status"] != "OK")
        record["diagnostic_artifacts"] = diagnostic_artifact_index(output)
        atomic_json(output / "campaign.json", record)
        if uncertain or record["method_isolation_required"]:
            record["diagnostic_quarantine"] = "PROCESS_EXIT_74_NO_REUSE"
            atomic_json(output / "campaign.json", record)
            os._exit(74)
        if llm is not None:
            try:
                llm.llm_engine.engine_core.shutdown()
            except Exception as error:
                record["cleanup_error"] = repr(error)
                atomic_json(output / "campaign.json", record)
    return 0 if record["status"] == "OK" and not record.get("cleanup_error") else 2


def pinned_h2d_state(spec):
    """Export CPU headers only, including after a possible partial copy error."""
    try:
        workspace = getattr(getattr(spec, "_draft_window_runtime_state", None), "workspace", None)
        if workspace is None:
            return dict(enabled=False, submitted_copies=0, pending_sources=[],
                        successful_source_owner="NOT_ENABLED", completion="NOT_INFERRED_FROM_COPY_RETURN")
        return workspace.pinned_h2d_review_state()
    except Exception as error:
        return dict(status="HOST_STATE_EXPORT_UNAVAILABLE", error_type=type(error).__name__, error=str(error))


def validate_pinned_h2d_state(observation, enabled):
    require(type(enabled) is bool, "typed H2D review selection required")
    if observation is None and not enabled:
        return dict(enabled=False, observation="HISTORICAL_DEFAULT_OFF_NOT_RECORDED")
    require(isinstance(observation, dict) and observation.get("enabled") is enabled
            and type(observation["submitted_copies"]) is int and observation["pending_sources"] == []
            and observation["completion"] == "NOT_INFERRED_FROM_COPY_RETURN",
            "actual pinned H2D policy or uncertain Host-source ownership differs")
    if enabled:
        require(observation["submitted_copies"] > 0
                and observation["successful_source_owner"] == "FRAMEWORK_PINNED_ALLOCATOR_STREAM_RECORD",
                "pinned H2D experiment did not execute the owned source path")
    else:
        require(observation["submitted_copies"] == 0, "default-off arm submitted experimental H2D copies")
    return observation


def diagnostic_artifact_index(output):
    """Index real produced files after execution; never infer completeness from existence."""
    result = {}
    for path in (output / "profile.json", output / "eagle-target.json", output / "eagle-target-run.json",
                 output / "eagle-numeric.json", output / "eagle-numeric-summary.json",
                 output / "eagle-numeric-contract-failure.json", output / "eagle-numeric-failure.json",
                 output / "eagle-unwind.json", output / "eagle-life.json",
                 *sorted(output.glob("eagle-contract-*.json")), *sorted(output.glob("eagle-completed-phases*.json")),
                 *sorted(output.glob("eagle-reference-restores*.json"))):
        if path.exists():
            result[path.name] = dict(bytes=path.stat().st_size, sha256=file_sha(path))
    return result


def validate_artifact_index(output, campaign, names):
    for name in names:
        path = output / name
        index = campaign["diagnostic_artifacts"][name]
        require(index["bytes"] == path.stat().st_size and index["sha256"] == file_sha(path),
                "controlled Target artifact changed: " + name)


def check(document, campaign, launcher, expected, artifact):
    result = audit_execution(document, campaign, launcher, expected, artifact)
    if result["status"] != "EXECUTION_ASSOCIATED":
        return result
    try:
        validate_contract(campaign["method_contract"])
        validate_contract(expected["eagle3_contract"])
        require(campaign["arm"] == expected["eagle3_arm"], "Eagle3 arm")
        arm, config = campaign["arm"], campaign["llm_kwargs"]
        argv = expected["argv"]
        arguments = parse_args(argv[argv.index("run"):])
        _, _, frozen_config = configuration(arguments)
        require(frozen_config == config, "exact actual Eagle3 configuration")
        result["pinned_h2d_staging"] = validate_pinned_h2d_state(
            campaign.get("pinned_h2d_staging"), arguments.eagle3_pinned_h2d_review
        )
        require(campaign["speculator"].endswith(".AscendEagleSpeculator"), "Eagle3 actual factory")
        require(campaign["fixture_sha256"] == expected["method_fixture_sha256"], "Eagle3 fixture identity")
        requests = json.loads(Path(expected["request_path"]).read_text())
        require(
            file_sha(expected["request_path"]) == expected["requests_sha256"]
            and campaign["request_manifest"]["entries"] == requests,
            "actual Eagle3 requests",
        )
        if expected.get("eagle3_target", False):
            from tools.p7x_graph_repair23_eagle_target import check_arm
            output = Path(expected["outputs"])
            for name in ("eagle-target.json", "eagle-target-run.json", "eagle-numeric.json"):
                path = output / name
                if name == "eagle-numeric.json" and arm == "G_OFF":
                    require(not path.exists(), "OFF cannot claim Window numerical reference")
                    continue
                validate_artifact_index(output, campaign, (name,))
            require(campaign["outputs"] == [], "controlled Target cannot masquerade as natural request output")
            if expected.get("eagle3_target_repro", False):
                from tools.p7x_graph_repair31_eagle_padding import check_reproduction
                result.update(check_reproduction(output, campaign, expected))
            else:
                result.update(check_arm(output, campaign, launcher, expected))
            return result
        require(len(requests) == len(campaign["outputs"]) == 3, "all Eagle3 request groups")
        totals = []
        for request, output in zip(requests, campaign["outputs"]):
            require(output["label"] == request["label"] and output["prompts"] == request["prompts"], "Eagle3 prompts")
            require(len(output["token_ids"]) == len(output["metrics"]) == len(request["prompts"]), "Eagle3 cardinality")
            require(len(output["prompt_token_ids"]) == len(request["prompts"]), "Eagle3 input cardinality")
            for submitted, used in zip(request["prompts"], output["prompt_token_ids"]):
                require(
                    isinstance(used, list) and used and all(type(t) is int and t >= 0 for t in used),
                    "actual Eagle3 input token IDs",
                )
                if isinstance(submitted, dict):
                    require(submitted["prompt_token_ids"] == used, "Eagle3 submitted/used inputs")
            require(
                launcher["host_start_ns"] <= output["start_ns"] < output["end_ns"] <= launcher["host_end_ns"],
                "Eagle3 request interval",
            )
            for tokens, metric in zip(output["token_ids"], output["metrics"]):
                require(len(tokens) == 64 and all(type(t) is int and t >= 0 for t in tokens), "Eagle3 output length")
                require(metric["finished"] is True, "Eagle3 request incomplete")
                totals.append(counts(metric["speculative_decoding"]))
        active = [c for c in document["calls"] if c["active"]]
        route_counts = {
            route: sum(c["label"] == route + "_REPLAY_SUBMIT" for c in active)
            for route in ("Target", "Draft_first_pass", "Draft_AR")
        }
        require(route_counts["Target"] > 0, "actual Target Graph replay")
        require(
            all(route_counts[r] > 0 if arm in ("G_OFF", "G_ON") else route_counts[r] == 0
                for r in ("Draft_first_pass", "Draft_AR")),
            "actual separate Eagle3 Draft dispatch",
        )
        if arm in ("E_ON", "G_ON"):
            require(
                any(o["window_identity"] and any(d["source_start_column"] * 128 + d["first_token_offset"] > 0
                                                 for d in o["window_identity"]["read_descriptors"])
                    for o in campaign["outputs"]),
                "real Eagle3 S>0",
            )
        if arm == "G_ON":
            for output in campaign["outputs"]:
                banks = output["graph_window_banks"]
                require(banks["installed"] and not banks["quarantined"], "actual Eagle3 bank owner")
                require(banks["capture_count"] == 9 and banks["output_reference_count"] == 9,
                        "all real first-pass/AR capture outputs retained")
                require(len(banks["updated_transfers"]) == 3, "all K real bank transfers after UPDATE")
                transfers = banks["updated_transfers"]
                require([t["step"] for t in transfers] == [0, 1, 2], "actual AR step ordinals")
                require(len({t["table_address"] for t in transfers}) == 3, "independent per-consumer banks")
                require(len({t["mapping_epoch"] for t in transfers}) == 1, "one actual proposal epoch")
                require(all(t["state"] == "UPDATED" for t in transfers), "actual backend UPDATE attribution")
        numeric_result = None
        life_result = None
        scheduler_result = None
        if expected.get("scheduler_phases", False):
            from tools.p7x_graph_repair16_scheduler import check_rows
            require(campaign["timing_scope"] == "CPU_SCHEDULER_OBSERVATIONS_NOT_NORMAL_PERFORMANCE",
                    "scheduler arm is separate from normal performance")
            scheduler_result = check_rows(campaign["scheduler_rows"], arm, launcher)
        if expected.get("eagle3_numeric", False):
            from tools.p7x_graph_repair15_eagle_numeric_check import check_collection
            require(campaign["timing_scope"] == "CAPTURED_D2D_COPIES_AND_SERIAL_REFERENCE_NOT_NORMAL_PERFORMANCE",
                    "numeric arm cannot be classified as normal performance")
            numeric_path = Path(expected["outputs"]) / "eagle-numeric.json"
            require(campaign["diagnostic_artifacts"][numeric_path.name]["sha256"] == file_sha(numeric_path),
                    "actual numeric manifest producer hash")
            numeric_result = check_collection(numeric_path, campaign["identity"])
            require(numeric_result["status"] == "PASS_SCOPED_EAGLE3_SERIAL_CONTINUOUS", str(numeric_result))
        if expected.get("eagle3_life", False):
            from tools.p7x_graph_repair22_eagle_life import check_rows as check_life_rows
            life_path = Path(expected["outputs"]) / "eagle-life.json"
            require(campaign["timing_scope"] == "SERIAL_EAGLE3_LIFE_SYNC_AND_READ_BANK_D2H_NOT_NORMAL_PERFORMANCE",
                    "LIFE diagnostic cannot be classified as normal overlap or performance")
            indexed = campaign["diagnostic_artifacts"][life_path.name]
            require(indexed["bytes"] == life_path.stat().st_size and indexed["sha256"] == file_sha(life_path),
                    "actual LIFE artifact bytes/hash")
            life_document = json.loads(life_path.read_text())
            require(life_document["identity"] == campaign["identity"], "LIFE execution identity")
            require(
                all(launcher["host_start_ns"] <= row["retire"]["ns"] <= row["completion_ns"] <= launcher["host_end_ns"]
                    for row in life_document["records"]), "LIFE events outside actual child interval")
            life_result = check_life_rows(life_document)
        result.update(
            status="PASS_SCOPED_EAGLE3_GRAPH_WINDOW_ANCHOR" if arm == "G_ON" else "PASS_SCOPED_EAGLE3_BASELINE_ANCHOR",
            arm=arm,
            route_counts=route_counts,
            counts=totals,
            numeric=numeric_result if numeric_result is not None else "NOT_ASSESSED",
            life=life_result if life_result is not None else "NOT_ASSESSED",
            scheduler=scheduler_result if scheduler_result is not None else "NOT_ASSESSED",
            full_target="NOT_ASSESSED",
            graph_window_on="DEFAULT_OFF_EXPERIMENTAL_ANCHOR_ONLY" if arm == "G_ON" else "NOT_ENABLED",
            physical_read="NOT_PROVEN",
        )
    except (ValueError, KeyError, TypeError, IndexError) as error:
        result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    run_parser = sub.add_parser("run")
    for name in ("fixture", "fixture-receipt", "requests", "output", "vllm-repo"):
        run_parser.add_argument("--" + name, type=Path, required=True)
    for name in ("fixture-sha256", "fixture-receipt-sha256", "expected-sha", "run-id", "case-id", "attempt", "case"):
        run_parser.add_argument("--" + name, required=True)
    run_parser.add_argument("--arm", choices=("G_OFF", "E_ON", "G_ON"), required=True)
    run_parser.add_argument("--eagle3-target",
                            action="store_true",
                            help="separate controlled complete Target/serial Eagle reference, not normal serving")
    run_parser.add_argument("--eagle3-pinned-h2d-review", action="store_true",
                            help="default-off owned pinned length H2D experiment; does not open the public Graph gate")
    run_parser.add_argument("--eagle3-target-prefix", type=int, choices=(1, ), default=None)
    run_parser.add_argument("--eagle3-padding-repro", action="store_true",
                            help="only the named padding transition; never complete Target/ABA coverage")
    run_parser.add_argument("--eagle3-numeric",
                            action="store_true",
                            help="capture-copy and serial reference diagnostic; not normal timing or ABA")
    run_parser.add_argument("--eagle3-life",
                            action="store_true",
                            help="separate 21-proposal first/AR diagnostic with explicit stream sync and bank D2H")
    run_parser.add_argument("--scheduler-phases",
                            action="store_true",
                            help="separate chunked-prefill CPU phase observations; no device copies/drains")
    from tools.p7x_graph_repair19_eagle_unwind import POINTS
    run_parser.add_argument("--eagle3-unwind",
                            choices=POINTS,
                            help="separate disposable Python unwind probe, default off; never native corruption")
    from tools.p7x_graph_repair35_eagle_abort import POINTS as ABORT_POINTS
    run_parser.add_argument("--eagle3-abort", choices=ABORT_POINTS,
                            help="default-off disposable child exit73; no native corruption or Python unwind")
    checker = sub.add_parser("check")
    for name in ("artifact", "campaign", "launcher", "plan", "output"):
        checker.add_argument("--" + name, type=Path, required=True)
    checker.add_argument("--case-id", required=True)
    config_parser = sub.add_parser("config")
    config_parser.add_argument("--plan", type=Path, required=True)
    config_parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args(argv)


def checker_exit_status(result):
    """Map only explicit, fully checked scoped verdicts to command acceptance."""
    return 0 if result.get("status") in (
        "PASS_SCOPED_EAGLE3_BASELINE_ANCHOR", "PASS_SCOPED_EAGLE3_GRAPH_WINDOW_ANCHOR",
        "PASS_SCOPED_EAGLE3_TARGET_PREFIX", "PASS_SCOPED_EAGLE3_TARGET_ARM",
        "PASS_SCOPED_EAGLE3_PADDING_REPRODUCTION_ONLY",
    ) else 4


def main():
    args = parse_args()
    if args.command == "run":
        return run(args)
    if args.command == "config":
        from tools.p7x_graph_repair7 import config_matrix

        plan = json.loads(args.plan.read_text())
        plan["cases"] = {k: v for k, v in plan["cases"].items()
                         if k.startswith("EAGLE3_") or k.startswith("UNWIND_EAGLE3_")}
        result = config_matrix(plan, framework=True, include_method_anchors=True)
        atomic_json(args.output, result)
        return 0 if result["status"] == "CONFIGS_VALID" else 2
    # Read-only CPU tensor comparison is small-payload work. The machine's
    # default hundreds of OpenMP workers made identical checks hit 120s while
    # the existing bounded recheck entry completed in ~13s with two threads.
    # Model/config execution above retains its existing thread configuration.
    import torch
    torch.set_num_threads(2)
    result = check(
        json.loads(args.artifact.read_text()),
        json.loads(args.campaign.read_text()),
        json.loads(args.launcher.read_text()),
        json.loads(args.plan.read_text())["cases"][args.case_id],
        args.artifact,
    )
    atomic_json(args.output, result)
    return checker_exit_status(result)


if __name__ == "__main__":
    raise SystemExit(main())
