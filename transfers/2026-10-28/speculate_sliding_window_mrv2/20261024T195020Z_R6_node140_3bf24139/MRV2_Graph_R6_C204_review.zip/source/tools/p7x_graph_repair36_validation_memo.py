# SPDX-License-Identifier: Apache-2.0
"""Separate default-off Host-header memo correctness and balanced comparisons.

These compare G_ON baseline versus G_ON memo. They do not rename either arm
G_OFF/E_ON or replace the independent three-arm performance matrix.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import re
import sys
from pathlib import Path

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair5_evidence import require
from tools.p7x_graph_repair6_storage import atomic_json


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def add_cases(cases, inputs, output, repo, python):
    marker = inputs / "validation-memo36.json"
    if not marker.exists():
        return
    declaration = json.loads(marker.read_text())
    require(declaration['schema'] == 'r6-validation-header-memo-v1' and declaration['enabled'] is True
            and type(declaration['repetitions']) is int and declaration['repetitions'] == 6,
            'exact default-off finite header-memo declaration')
    labels = declaration['labels']
    require(1 <= len(labels) <= 3 and len(set(labels)) == len(labels)
            and all(re.fullmatch(r'[a-z][a-z0-9_]{0,23}', label) for label in labels),
            'bounded declared workload labels')

    def clone(source, name, memo):
        def rewrite(value):
            if isinstance(value, str): return value.replace(source, name)
            if isinstance(value, list): return [rewrite(v) for v in value]
            if isinstance(value, dict): return {k: rewrite(v) for k, v in value.items()}
            return value
        case = rewrite(copy.deepcopy(cases[source]))
        if memo:
            for field in ('argv', 'launch_argv'):
                case[field].append('--repair36-validation-memo')
        case.update(validation_memo_experiment=memo,
                    selection='OPT_IN_VALIDATION_HEADER_MEMO_NOT_DEFAULT')
        cases[name] = case
        return case

    for source, name in [('NUMERIC_SENTINEL', 'NUMERIC_MEMO_SENTINEL'),
                          ('NUMERIC_TARGET4', 'NUMERIC_MEMO_TARGET4'), ('LIFE', 'LIFE_MEMO')]:
        case = clone(source, name, True)
        if source != 'NUMERIC_SENTINEL':
            case['dependencies'] = list(dict.fromkeys([*case['dependencies'], 'NUMERIC_MEMO_SENTINEL']))
    for label in labels:
        for repetition in range(1, 7):
            order = ['BASE', 'MEMO'] if repetition % 2 else ['MEMO', 'BASE']
            source = f'PERF27_{label}_{repetition:02}_G_ON'
            require(source in cases, 'matching fixed request performance source absent')
            for position, variant in enumerate(order, 1):
                name = f'PERF36_{label}_{repetition:02}_{variant}'
                case = clone(source, name, variant == 'MEMO')
                prior = case.pop('balanced_performance')
                case['memo_validation_comparison'] = dict(schema='r6-validation-header-memo-v1', label=label,
                    repetition=repetition, position=position, order=order, variant=variant,
                    max_model_len=prior['max_model_len'], declaration_path=str(marker),
                    declaration_sha256=digest(marker), scope='SAME_WINDOW_BASELINE_VS_MEMO_NOT_THREE_ARM')
                case['dependencies'] = list(dict.fromkeys([*case['dependencies'], 'NUMERIC_MEMO_SENTINEL']))
                for command in case['validation_commands']:
                    command['argv'] = [a.replace('p7x_graph_repair27_balanced_perf.py',
                        'p7x_graph_repair36_validation_memo.py') for a in command['argv']]


def check(campaign, launcher, profile, expected, artifact):
    from tools.p7x_graph_repair10_performance import check as performance_check
    result = performance_check(campaign, launcher, profile, expected, artifact)
    if result.get('status') != 'PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE':
        return result
    try:
        spec = expected['memo_validation_comparison'];marker=Path(spec['declaration_path'])
        require(digest(marker) == spec['declaration_sha256'], 'memo declaration changed')
        declaration=json.loads(marker.read_text());repeat=spec['repetition']
        require(declaration['schema'] == spec['schema'] == 'r6-validation-header-memo-v1'
                and declaration['enabled'] is True and type(declaration['repetitions']) is int
                and declaration['repetitions'] == 6 and spec['label'] in declaration['labels']
                and type(repeat) is int and 1 <= repeat <= 6, 'declared balanced workload/repetition')
        order=['BASE','MEMO'] if repeat % 2 else ['MEMO','BASE'];position=spec['position']
        require(type(position) is int and 1 <= position <= 2 and spec['order'] == order
                and order[position-1] == spec['variant']
                and expected['validation_memo_experiment'] is (spec['variant']=='MEMO')
                and expected['performance_arm']=='G_ON', 'same-Window baseline/memo identity')
        require(campaign['llm_kwargs']['max_model_len']==spec['max_model_len']
                and expected['argv'][expected['argv'].index('--repair5-profile')+1]=='control'
                and profile['profiler_enabled'] is False, 'normal control only, no collector')
        result['memo_validation_comparison']=spec
        result['inference']='One named control cell; actual AB/BA dispatch and aggregate gain checked separately'
    except (KeyError, ValueError, TypeError, OSError, IndexError) as error:
        result.update(status='INVALID_EVIDENCE', error=str(error))
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('campaign','launcher','profile','plan','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--case-id',required=True);args=parser.parse_args()
    result=check(json.loads(args.campaign.read_text()),json.loads(args.launcher.read_text()),
                 json.loads(args.profile.read_text()),json.loads(args.plan.read_text())['cases'][args.case_id],
                 args.profile)
    atomic_json(args.output,result)
    return 0 if result['status']=='PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE' else 4


if __name__=='__main__':raise SystemExit(main())
