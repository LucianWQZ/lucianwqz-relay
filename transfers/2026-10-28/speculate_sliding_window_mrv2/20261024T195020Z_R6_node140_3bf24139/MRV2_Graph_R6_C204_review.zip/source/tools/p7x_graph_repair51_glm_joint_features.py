# SPDX-License-Identifier: Apache-2.0
"""Official GLM TP16 Window-ON service with all required feature flags.

This is a bounded Host-observation arm.  It proves that the real service entry
admits Draft Graph Window together with async scheduling, prefix caching,
chunked prefill and the effective Target SP/DSA-CP/FlashComm path.  It does not
replace the independent numeric, completion-edge, operand or physical-read
contracts.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [
        p
        for p in sys.path
        if Path(p or ".").resolve() != Path(__file__).parent.resolve()
    ]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair32_glm_rank import TARGET, SP_CAPTURE, SP_CAPTURE_CONTRACT, profile_identity
from tools.p7x_graph_repair33_service import run_service, validate_requests
from tools.p7x_graph_repair40_glm_performance import validate_ranks
from tools.p7x_graph_repair47_glm_service import (
    glm_serve_argv,
    validate_prefix_hits,
)
from tools.p7x_graph_repair50_glm_required_baseline import (
    EXTENSION,
    validate_required_features,
    validate_required_workers,
)

PROFILE = "GLM52_TP16_WINDOW_ON_REQUIRED_FEATURES_V2_SP_ALIGNED"


def joint_serve_argv(
    python: str,
    port: int,
    model_name: str,
    arm: str,
    *,
    worker_provenance: bool = False,
) -> list[str]:
    require(arm == "G_ON", "joint required-feature service must retain Window ON")
    argv = glm_serve_argv(
        python,
        port,
        model_name,
        arm,
        worker_provenance=worker_provenance,
        prefix_caching=True,
    )
    argv[argv.index("--no-async-scheduling")] = "--async-scheduling"
    argv += ["--enable-chunked-prefill"]
    argv[argv.index("--compilation-config") + 1] = json.dumps(dict(
        cudagraph_capture_sizes=SP_CAPTURE, cudagraph_mode="FULL_DECODE_ONLY",
    ), sort_keys=True)
    additional_index = argv.index("--additional-config") + 1
    additional = json.loads(argv[additional_index])
    additional.update(
        enable_dsa_cp=True,
        enable_flashcomm1=True,
        multistream_overlap_shared_expert=True,
    )
    argv[additional_index] = json.dumps(additional, sort_keys=True)
    argv[argv.index("--worker-extension-cls") + 1] = EXTENSION
    return argv


def check_saved(args: argparse.Namespace) -> dict:
    source = Path(__file__).resolve().parents[1]
    campaign = json.loads(args.campaign.read_text())
    require(
        campaign["combined_feature_profile"] == PROFILE
        and campaign["arm"] == args.arm == "G_ON"
        and campaign["execution_tp"] == 16
        and campaign["requests_sha256"] == digest(args.requests),
        "actual joint workload, arm or rank set differs",
    )
    receipt_path = Path(campaign["admission_path"])
    require(
        digest(receipt_path) == campaign["admission_sha256"],
        "original admission changed",
    )
    receipt = json.loads(receipt_path.read_text())
    require(
        receipt["tp"] == 16
        and receipt["source_sha"] == args.expected_sha == campaign["source_sha"]
        and receipt["source_tree"] == campaign["source_tree"],
        "source or admission differs",
    )
    argv = joint_serve_argv(
        campaign["server_argv"][0],
        args.port,
        campaign["server_argv"][
            campaign["server_argv"].index("--served-model-name") + 1
        ],
        args.arm,
        worker_provenance=True,
    )
    require(
        argv == json.loads(args.server_argv.read_text()),
        "actual joint service argv differs",
    )
    document = json.loads(args.records.read_text())
    result = validate_requests(
        campaign,
        document,
        json.loads(args.requests.read_text()),
        expected_server_argv=argv,
        expected_source=source,
        expected_vllm_source=receipt["vllm_checkout"],
        worker_identity_validator=validate_required_workers,
        worker_extension_cls=EXTENSION,
    )
    rows = campaign["worker_provenance"][-1]["results"]
    result.update(
        required_features=validate_required_features(
            rows, require_execution=True, require_graph_window=True
        ),
        prefix=validate_prefix_hits(campaign, document),
        actual_dispatch=validate_ranks(
            [row["rank_snapshot"] for row in rows],
            source=source,
            pin=receipt["vllm_checkout"],
            arm="G_ON",
            need_clip=True,
            capture_contract=SP_CAPTURE_CONTRACT,
        ),
        scope=(
            "OFFICIAL_GLM_TP16_WINDOW_ON_HTTP_AND_ALL_RANK_HOST_DISPATCH_"
            "WITH_EFFECTIVE_REQUIRED_TARGET_FEATURES"
        ),
        semantic_numeric="NOT_ASSESSED_BY_THIS_SERVICE_ARM",
        normal_completion="NOT_PROVEN_BY_HOST_REQUEST_RETURN",
        execution_operand="NOT_PROVEN",
        physical_read="NOT_AVAILABLE",
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("run", "check"))
    parser.add_argument("--arm", choices=("G_ON",), required=True)
    parser.add_argument("--expected-sha", required=True)
    parser.add_argument("--port", type=int, required=True)
    for name in ("requests", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    for name in ("admission", "campaign", "records", "server-argv"):
        parser.add_argument("--" + name, type=Path)
    args = parser.parse_args()
    if args.command == "check":
        require(
            all(
                getattr(args, name) is not None
                for name in ("campaign", "records", "server_argv")
            ),
            "complete saved joint service evidence required",
        )
        try:
            result = check_saved(args)
        except (
            ValueError,
            KeyError,
            TypeError,
            IndexError,
            AttributeError,
            OSError,
        ) as error:
            result = {
                "status": "INVALID_EVIDENCE",
                "error": f"{type(error).__name__}: {error}",
            }
        write(args.output, result)
        return 0 if result["status"] == "PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS" else 4
    require(args.admission is not None, "new all-rank admission required")
    args.worker_provenance = True
    return run_service(
        args,
        server_argv_builder=joint_serve_argv,
        target_model=str(TARGET),
        tp=16,
        ready_timeout_seconds=1800,
        extra_metadata={
            "model_profile": profile_identity(),
            "service_entrypoint_sha256": digest(__file__),
            "combined_feature_profile": PROFILE,
            "prefix_cache_requested": True,
            "full_feature_combination": "WINDOW_ON_REQUIRED_FEATURES",
        },
    )


if __name__ == "__main__":
    raise SystemExit(main())
