# SPDX-License-Identifier: Apache-2.0
"""Opt-in actual TP16 joint-feature Python unwind, using the existing C1 probe.

Faults remain simultaneous on all ranks. Existing CP-builder Host audits are
exported after unwind without a device RPC, synchronization, tensor read or
recovery. This tests isolation, not normal last-consumer completion.
"""
import os
from pathlib import Path

from tools.p7x_graph_repair21_rank import require, write
from tools.p7x_graph_repair41_rank_unwind import RankUnwindWorker
from tools.p7x_graph_repair50_glm_required_baseline import (
    GLMRequiredFeatureWorker, validate_required_features,
)


class GLMJointUnwindWorker(RankUnwindWorker, GLMRequiredFeatureWorker):
    def mrv2_rank_unwind_identity(self, payload):
        require(payload['profile'] == 'glm_k8_required', 'explicit joint unwind profile required')
        row = super().mrv2_rank_unwind_identity(payload)
        actual = self.mrv2_service_worker_identity(payload['nonce'])
        row['required_features'] = actual['required_features']
        from tools.p7x_graph_repair39_service_identity import _loaded_module
        if not any(entry['module'] == __name__ for entry in row['module_sources']):
            row['module_sources'].append(_loaded_module(__name__))
        write(Path(payload['root']) / f"rank-{self.rank}" / 'identity.json', row)
        # The audit sub-dict is updated by already installed CPU-only wrappers.
        self._mrv2_unwind_features = row['required_features']
        return row

    def mrv2_rank_arm_unwind(self, payload):
        require(payload['profile'] == 'glm_k8_required' and hasattr(self, '_mrv2_unwind_features'),
                'joint worker identity must precede arming')
        identity = super().mrv2_rank_arm_unwind(payload)
        if payload['mode'] == 'python_unwind':
            self._mrv2_rank_unwind_probe.required_feature_host_evidence = dict(
                rank=self.rank, pid=os.getpid(), process_start_ticks=identity['process_start_ticks'],
                required_features=self._mrv2_unwind_features,
                scope='EXISTING_CPU_HEADERS_AND_BUILDER_RETURNS_NOT_DEVICE_COMPLETION')
        return identity


def validate_joint_features(workers, *, terminals=None):
    require(len(workers) == 16 and all(type(row['rank']) is int for row in workers)
            and sorted(row['rank'] for row in workers) == list(range(16)),
            'complete actual joint-feature rank set required')
    rows = workers
    if terminals is not None:
        require(len(terminals) == len(workers), 'every actual rank terminal is required')
        rows = []
        for worker, terminal in zip(workers, terminals):
            require('required_feature_export_error' not in terminal, 'joint Host export failed')
            evidence = terminal['required_feature_host_evidence']
            require(type(evidence['rank']) is int and type(evidence['pid']) is int
                    and evidence['rank'] == worker['rank'] and evidence['pid'] == worker['pid']
                    and evidence['process_start_ticks'] == worker['process_start_ticks']
                    and evidence['scope'] == 'EXISTING_CPU_HEADERS_AND_BUILDER_RETURNS_NOT_DEVICE_COMPLETION',
                    'joint terminal belongs to another worker')
            original, final = worker['required_features'], evidence['required_features']
            require(set(original) == set(final) and all(
                final[key] == original[key] for key in original if key != 'actual_metadata_audit'),
                'effective joint feature configuration changed during fault')
            rows.append(dict(rank=worker['rank'], required_features=final))
    return validate_required_features(rows, require_execution=terminals is not None,
                                      require_graph_window=True)
