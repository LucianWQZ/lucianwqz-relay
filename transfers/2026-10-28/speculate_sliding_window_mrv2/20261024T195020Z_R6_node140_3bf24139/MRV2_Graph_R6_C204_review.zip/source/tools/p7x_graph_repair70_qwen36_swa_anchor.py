# SPDX-License-Identifier: Apache-2.0
"""Original Graph baseline for the designated six-layer structural SWA Draft.

This first TP4/DP1 anchor has Window OFF. It establishes the real model,
per-layer causal/native-window and capture/dispatch path before any extra
Window adapter. Its short requests do not prove effective SWA clipping,
long-context numerical semantics, DP2 or extra-Window ownership.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import hashlib
import json
import struct

from tools.p7x_graph_repair21_rank import digest, require, run_anchor, write
from tools.p7x_graph_repair28_rank_anchor_check import check as check_anchor
from tools.p7x_graph_repair68_qwen36_dflash_anchor import (
    TARGET, TARGET_CONFIG_SHA, Qwen36DFlashWorker, build_kwargs as full_kwargs,
)

PROFILE = 'QWEN36_SWA6_DFLASH_K7_Q8_TP4_DP1_ORIGINAL_GRAPH_ANCHOR_V1'
DRAFT = Path('/mnt/share/z00937950/project/speculate_sliding_window_mrv2/models/hf_drafts/'
             'Qwen3.6-35B-A3B-DFlash-SWA_f181eece646a')
DRAFT_CONFIG_SHA = '20784b063040f7871efec4bf63342e5cb941907925943540176dfbb8aaf186dc'
AUX = (1, 6, 11, 16, 22, 27, 32, 37)
LAYERS = ('sliding_attention',) * 5 + ('full_attention',)


def validate_configs(target, draft):
    text = target['text_config']
    require(target['architectures'] == ['Qwen3_5MoeForConditionalGeneration']
            and target['model_type'] == 'qwen3_5_moe'
            and text['num_hidden_layers'] == 40 and text['hidden_size'] == 2048
            and text['layer_types'] == ['linear_attention', 'linear_attention', 'linear_attention', 'full_attention'] * 10,
            'named mixed Full/GDN Target required')
    require(draft['architectures'] == ['DFlashDraftModel'] and draft['model_type'] == 'qwen3'
            and draft['num_hidden_layers'] == 6 and draft['hidden_size'] == 2048
            and draft['num_target_layers'] == 40 and draft['num_attention_heads'] == 32
            and draft['num_key_value_heads'] == 8 and draft['head_dim'] == 128
            and draft['vocab_size'] == text['vocab_size'] == 248320
            and draft['dtype'] == 'bfloat16' and tuple(draft['layer_types']) == LAYERS
            and draft['sliding_window'] == 4096 and draft['use_sliding_window'] is True,
            'fixed BF16 six-layer five-SWA/one-Full Draft required')
    options = draft['dflash_config']
    require(options['target_layer_ids'] == list(AUX) and options['mask_token_id'] == 248077
            and options.get('causal') is None and options.get('sample_from_anchor', False) is False
            and text['max_position_embeddings'] >= 4096 and draft['max_position_embeddings'] >= 4096,
            'designated native SWA auxiliary/mask/position contract differs')


def profile_identity():
    require(digest(TARGET/'config.json') == TARGET_CONFIG_SHA
            and digest(DRAFT/'config.json') == DRAFT_CONFIG_SHA, 'fixed model configuration changed')
    validate_configs(json.loads((TARGET/'config.json').read_text()), json.loads((DRAFT/'config.json').read_text()))
    weight = DRAFT/'model.safetensors'
    with weight.open('rb') as stream:
        size = struct.unpack('<Q', stream.read(8))[0]
        require(0 < size <= 1 << 20, 'bounded Draft weight header required')
        raw = stream.read(size)
    require(len(raw) == size, 'truncated Draft weight header')
    header = json.loads(raw)
    require(header['fc.weight']['dtype'] == 'BF16' and header['fc.weight']['shape'] == [2048, 16384]
            and header['hidden_norm.weight']['dtype'] == 'BF16'
            and header['hidden_norm.weight']['shape'] == [2048], 'actual eight-aux projection differs')
    index=DRAFT.parent/'DOWNLOAD_INDEX.json'
    selected=[row for row in json.loads(index.read_text())['models'] if row['id']=='QWEN36_DFLASH_SWA']
    require(len(selected)==1,'one shared PR-owned download identity required')
    declaration={key:selected[0][key] for key in ('path','realpath','repo','revision','bytes','sha256','target')}
    require(declaration['path']==str(DRAFT) and declaration['realpath']==str(DRAFT.resolve())
            and declaration['repo']=='z-lab/Qwen3.6-35B-A3B-DFlash'
            and declaration['revision']=='f181eece646affea2c38b2765f1aaa01a9734ccd'
            and declaration['bytes']==weight.stat().st_size==771819674
            and declaration['sha256']=='1fb90ef50a32bfb8dd2abfe601dd3608d6d5b59dc342820a98830f76f8cd72b7'
            and declaration['target']==str(TARGET),'shared fixed model pair/download declaration differs')
    return dict(profile=PROFILE, files=[dict(path=str(p),realpath=str(p.resolve()),bytes=p.stat().st_size,
                sha256=digest(p)) for p in (TARGET/'config.json',TARGET/'quant_model_description.json',
                    TARGET/'quant_model_weights.safetensors.index.json',TARGET/'tokenizer_config.json',DRAFT/'config.json')],
                shared_download=dict(index=str(index),declared_identity=declaration,
                    scope='PR_VERIFIED_DOWNLOAD_DECLARATION; CURRENT_HEADER_AND_SIZE_RECHECKED_NOT_FULL_WEIGHT_HASH'),
                weight=dict(path=str(weight),bytes=weight.stat().st_size,header_bytes=size,
                            header_sha256=hashlib.sha256(raw).hexdigest(),scope='BOUNDED_HEADER_NOT_FULL_WEIGHT_HASH'),
                method=dict(method='dflash',k=7,query=8,sample_offset=1,layer_types=list(LAYERS),
                            native_window=4096,target_layer_ids=list(AUX),mask_token=248077),
                scope='Existing PR-indexed fixed weight; no download, no model execution claim')


def build_kwargs(tp, *, window_on_review=False):
    require(tp == 4 and type(tp) is int and window_on_review is False,
            'original SWA Graph OFF TP4/DP1 anchor only; extra Window is separate')
    kwargs = full_kwargs(tp)
    kwargs['speculative_config']['model'] = str(DRAFT)
    kwargs['worker_extension_cls'] = 'tools.p7x_graph_repair70_qwen36_swa_anchor.Qwen36SWAWorker'
    return kwargs


class Qwen36SWAWorker(Qwen36DFlashWorker):
    def mrv2_rank_snapshot(self):
        row = super().mrv2_rank_snapshot()
        spec = self.model_runner.speculator
        row['qwen36_profile']['profile'] = PROFILE
        row['qwen36_profile']['model_layer_native_windows'] = [
            layer.self_attn.attn.impl.sliding_window for layer in spec.model.model.layers]
        row['qwen36_profile']['actual_draft_layer_names'] = list(spec.model.get_draft_kv_cache_layer_names())
        row['qwen36_profile']['actual_draft_kernel_blocks'] = [
            dict(global_group_id=gid,block_size=int(spec.block_tables.kernel_block_sizes[gid]))
            for gid in spec.draft_kv_cache_group_ids]
        return row


def validate_worker(worker, tp):
    require(tp == 4 and worker['window_size'] is None and worker['window_provider_installed'] is False
            and worker['heavy_observer_enabled'] is False
            and worker['speculator_class'] == 'vllm_ascend.worker.v2.spec_decode.dflash.speculator.AscendDFlashSpeculator',
            'actual original OFF TP4 Ascend DFlash required')
    validate_geometry(worker,tp)


def validate_geometry(worker,tp):
    """Model/group geometry shared by separately gated original/Window arms."""
    require(tp == 4,'actual TP4 SWA geometry required')
    p = worker['qwen36_profile']
    require(p['profile'] == PROFILE and p['target_model'] == str(TARGET) and p['draft_model'] == str(DRAFT)
            and p['method'] == 'dflash' and type(p['k']) is type(p['query']) is int
            and p['k'] == 7 and p['query'] == 8 and p['anchor'] is False and p['noncausal'] is True
            and tuple(p['layer_types']) == LAYERS and p['target_layer_ids'] == list(AUX)
            and p['mask_token_id'] == 248077 and p['fc_shape'] == [2048,16384]
            and p['model_layer_causal'] == [True]*5+[False]
            and all(type(value) is bool for value in p['model_layer_causal'])
            and p['model_layer_native_windows'] == [4096]*5+[None],
            'actual six-layer per-layer native-window/causal/aux contract differs')
    layers = worker['draft_layers']
    require(len(layers) == len(set(layers)) == 6 and set(worker['draft_backend']) == set(layers)
            and all(v.endswith('attention_v1.AscendAttentionBackend') for v in worker['draft_backend'].values())
            and set(worker['draft_kv_geometry']) == {n+'/'+str(i) for n in layers for i in (0,1)},
            'all six Draft layers and original K/V required')
    for value in worker['draft_kv_geometry'].values():
        require(len(value['shape']) == 4 and value['shape'][0] > 0 and value['shape'][1:] == [128,2,128]
                and value['dtype'] == 'torch.bfloat16', 'actual TP4 native SWA KV geometry differs')
    groups = p['draft_groups']
    # The fixed hybrid-cache planner can partition the five identical SWA
    # layers into five singleton groups (alongside singleton Target Mamba
    # groups). Model layer type does not require one merged cache group.
    members = [name for group in groups for name in group['layers']]
    require(2 <= len(groups) <= 6 and all(group['layers'] for group in groups)
            and all(type(v['global_group_id']) is int and v['global_group_id']>=0 for v in groups)
            and len({v['global_group_id'] for v in groups}) == len(groups)
            and len(members) == len(set(members)) == 6 and set(members) == set(layers),
            'distinct complete non-overlapping SWA/Full group ownership required')
    ordered=p['actual_draft_layer_names']
    require(len(ordered)==len(set(ordered))==6 and set(ordered)==set(layers),
            'actual model layer order missing')
    causal_by_layer=dict(zip(ordered,p['model_layer_causal']))
    require(all(len({causal_by_layer[name] for name in group['layers']}) == 1 for group in groups),
            'one KV group mixes causal SWA and noncausal Full layers')
    expected = {group['global_group_id']:causal_by_layer[group['layers'][0]] for group in groups}
    require({v['global_group_id']:v['causal'] for v in p['group_causal']} == expected
            and len(p['group_causal']) == len(expected)
            and all(type(v['causal']) is bool for v in p['group_causal'])
            and {v['global_group_id']:v['block_size'] for v in p['actual_draft_kernel_blocks']}
                == {gid:128 for gid in expected}
            and len(p['actual_draft_kernel_blocks']) == len(expected),
            'actual group causality lost during engine construction')
    full=[];linear=[]
    for group in p['target_groups']:
        if group['backend'].endswith('attention_v1.AscendAttentionBackend'):full+=group['layers']
        elif group['backend'].endswith('gdn_attn_builder.AscendGDNAttentionBackend'):linear+=group['layers']
        else:raise ValueError('uninventoried Target backend')
    require(len(full) == len(set(full)) == 10 and len(linear) == len(set(linear)) == 30
            and not set(full)&set(linear) and not (set(full)|set(linear))&set(layers),
            'independent complete Target Full/GDN owners required')
    required={(n,n*8) for n in (1,2,4)}
    for key in ('target_graph_inventory','draft_graph_inventory'):
        require(required <= {(v['requests'],v['tokens']) for v in worker[key] if v['mode']=='FULL'},
                'real Q8 capture inventory missing')


def preflight_workers(llm, record, output):
    rows=llm.collective_rpc('mrv2_rank_snapshot',timeout=90)
    record['swa_post_capture_preflight']=rows
    write(Path(output)/'campaign.json',record)
    require(len(rows)==4 and {row['rank'] for row in rows}==set(range(4))
            and len({row['pid'] for row in rows})==4,'actual complete post-capture worker set required')
    for row in rows:validate_worker(row,4)


def check(planned, execution):
    result = check_anchor(planned,execution,kwargs_factory=build_kwargs,worker_validator=validate_worker,
                          entrypoint_name=Path(__file__).name)
    if result['status'].startswith('PASS_SCOPED_'):
        plan=json.loads(Path(planned).read_text());argv=plan['argv']
        campaign=json.loads((Path(argv[argv.index('--output')+1])/'campaign.json').read_text())
        require(plan['profile_identity'] == campaign['profile_identity'] == profile_identity(),
                'actual fixed SWA profile differs')
        preflight=campaign['swa_post_capture_preflight']
        require(len(preflight)==4 and {row['rank'] for row in preflight}==set(range(4))
                and {(row['rank'],row['pid'],row['process_start_ticks']) for row in preflight}
                    == {(row['rank'],row['pid'],row['process_start_ticks']) for row in campaign['ranks']},
                'SWA preflight/final actual worker identity changed')
        for row in preflight:validate_worker(row,4)
        result.update(status=result['status']+'_QWEN36_SWA6_TP4_DP1',profile=PROFILE,
                      scope='Original OFF model/capture/dispatch only; not effective SWA clipping, numerical, extra Window, DP2, reader completion or performance')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=('run','check'))
    parser.add_argument('--expected-sha');parser.add_argument('--tp',type=int,choices=(4,),default=4)
    for name in ('admission','output','planned','execution'):parser.add_argument('--'+name,type=Path,required=name=='output')
    args=parser.parse_args()
    if args.command=='run':
        require(args.admission is not None and args.expected_sha is not None,'fresh admission/source required')
        from tools.p7x_graph_repair25_rank_numeric import validate_runtime_overlay
        receipt=json.loads(args.admission.read_text())
        validate_runtime_overlay(receipt['runtime_manifest']['path'],Path(__file__).resolve().parents[1],args.expected_sha,receipt['source_tree'])
        args.window_on_review=False
        return run_anchor(args,profile_kwargs=build_kwargs(args.tp),profile_identity=profile_identity(),
                          producer_path=__file__,before_requests=preflight_workers)
    require(args.planned is not None and args.execution is not None,'saved planned/execution required')
    try:result=check(args.planned,args.execution)
    except (ValueError,KeyError,TypeError,OSError,IndexError) as error:result=dict(status='INVALID_EVIDENCE',error=str(error))
    write(args.output,result)
    return 0 if result['status'].startswith('PASS_SCOPED_') else 4


if __name__ == '__main__':
    raise SystemExit(main())
