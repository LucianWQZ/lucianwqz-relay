# SPDX-License-Identifier: Apache-2.0
"""Original Draft eager / Window OFF baseline for the C151 token difference.

Target Graph and the required GLM features remain enabled. Reuses the actual
CLI/SSE service, phase observer and provenance checks. This diagnostic fourth
arm is not a performance cell or a waiver of the failed three-arm token join.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import json

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair32_glm_rank import SP_CAPTURE_CONTRACT, TARGET, profile_identity, validate_glm_worker
from tools.p7x_graph_repair33_service import run_service, validate_requests
from tools.p7x_graph_repair39_service_identity import validate_worker_identity
from tools.p7x_graph_repair50_glm_required_baseline import validate_required_features
from tools.p7x_graph_repair59_glm_service_phases import GLMPhaseWorker, phase_serve_argv, validate_actual_phases

PROFILE = 'GLM_TP16_REQUIRED_ACTUAL_PHASES_DRAFT_EAGER_WINDOW_OFF_BASELINE_V1'
EXTENSION = 'tools.p7x_graph_repair63_glm_eager_off_baseline.GLMEagerOffBaselineWorker'
ACCEPTED = 'PASS_SCOPED_EAGER_OFF_BASELINE_SERVICE_NOT_TOKEN_CORRECTNESS'


def baseline_serve_argv(python, port, model, arm, *, worker_provenance=False):
    require(arm == 'E_OFF' and worker_provenance is True, 'explicit observed E_OFF baseline required')
    argv = phase_serve_argv(python, port, model, 'G_OFF', worker_provenance=worker_provenance)
    index = argv.index('--speculative-config') + 1
    spec = json.loads(argv[index])
    spec['enforce_eager'] = True
    argv[index] = json.dumps(spec, sort_keys=True)
    additional = json.loads(argv[argv.index('--additional-config') + 1])
    require('draft_window_size' not in additional and 'draft_window_parallel_eager_review' not in additional,
            'original eager OFF baseline cannot install Window')
    argv[argv.index('--worker-extension-cls') + 1] = EXTENSION
    return argv


class GLMEagerOffBaselineWorker(GLMPhaseWorker):
    def mrv2_service_worker_identity(self, nonce):
        row = super().mrv2_service_worker_identity(nonce)
        row['eager_off_extension'] = dict(path=__file__, sha256=digest(__file__))
        return row


def validate_workers(rows, *, nonce, source, vllm_source, arm):
    require(arm == 'E_OFF' and isinstance(rows, list) and len(rows) == 16,
            'complete explicit eager OFF workers required')
    ranks = [row['rank_snapshot']['rank'] for row in rows]
    require(all(type(rank) is int for rank in ranks) and sorted(ranks) == list(range(16)),
            'missing, duplicate or untyped rank')
    snapshots = [row['rank_snapshot'] for row in rows]
    require(len({s['pid'] for s in snapshots}) == 16, 'rank PID reused')
    extension = Path(source) / 'tools/p7x_graph_repair63_glm_eager_off_baseline.py'
    identities = []
    for row, snapshot in zip(rows, snapshots):
        # This shared helper checks Python/native provenance and provider OFF,
        # not execution mode. Actual Draft eager and no Window are independently
        # required below, without fabricating a Graph registry or modifying rows.
        identity = validate_worker_identity([row], nonce=nonce, source=source,
                                            vllm_source=vllm_source, arm='G_OFF')
        require(row['eager_off_extension'] == dict(path=str(extension), sha256=digest(extension)),
                'actual eager OFF extension is not this fixed source')
        require(snapshot['pid'] == row['pid'] and snapshot['process_start_ticks'] == row['process_start_ticks']
                and snapshot['world_size'] == snapshot['tp_size'] == snapshot['draft_tp_size'] == 16
                and Path(snapshot['ascend_source']).resolve() == Path(source).resolve() / 'vllm_ascend/__init__.py'
                and Path(snapshot['vllm_source']).resolve() == Path(vllm_source).resolve() / 'vllm/__init__.py',
                'actual rank/provenance/topology/source differs')
        require(row['actual_method'] == 'dspark' and row['actual_k'] == row['actual_query_width'] == 8
                and row['actual_sample_from_anchor'] is True
                and row['speculator_class'] == snapshot['speculator_class']
                and snapshot['speculator_class'].endswith('.dspark.speculator.AscendDSparkSpeculator'),
                'original separate DSpark K8/Q8 method required')
        validate_glm_worker(snapshot, 16, draft_graph=False, capture_contract=SP_CAPTURE_CONTRACT)
        require(snapshot['window_size'] is None and snapshot['window_provider_installed'] is False
                and snapshot['heavy_observer_enabled'] is False and snapshot['submission_uncertain'] is False
                and not snapshot['window_generations'] and not snapshot['window_graph_bindings']
                and snapshot['eager_async_pool'] is None, 'eager OFF baseline contains a Window owner or activity')
        identities.append(dict(rank=snapshot['rank'], **identity))
    validate_required_features(rows, require_execution=False, require_graph_window=False)
    return dict(status='ALL16_ORIGINAL_EAGER_OFF_PROVENANCE',
                workers=sorted(identities, key=lambda row: row['rank']))


def validate_dispatch(rows):
    counts = []
    for row in rows:
        snapshot = row['rank_snapshot']
        require(type(snapshot['draft_replays']) is int and snapshot['draft_replays'] == 0
                and type(snapshot['draft_eager_forward_returns']) is int and snapshot['draft_eager_forward_returns'] > 0
                and type(snapshot['target_replays']) is int and snapshot['target_replays'] > 0,
                'actual eager Draft / Graph Target execution missing')
        calls = snapshot['dispatch_records']
        require(len(calls) == snapshot['target_replays']
                and all(c['role'] == 'target' and c['mode'] == 'FULL' and c['returned'] is True
                        and c['host_start_ns'] < c['host_return_ns'] for c in calls),
                'eager OFF contains a hidden Draft Graph or contradictory Target calls')
        require(all(not sample['window_materializations'] and not sample['manager_calls']
                    for sample in row['proposal_phases']), 'proposal submitted a Draft Graph or Window')
        counts.append((snapshot['target_replays'], snapshot['draft_eager_forward_returns']))
    require(len(counts) == 16 and len(set(counts)) == 1, 'all-rank baseline work differs')
    # The shared OFF classifier only tests CPU business phases and no Window
    # source. It does not require Graph calls; eager mode is checked above.
    phases = validate_actual_phases(rows, 'G_OFF')
    return dict(ranks=16, Draft_Graph=0, Target_Graph_Host_calls=counts[0][0],
        Draft_eager_Host_returns=counts[0][1], phases=phases,
        scope='Existing Host dispatch and CPU rows, not device occurrence or completion')


def prefix_hits(document, rows):
    require(all(row['effective_prefix_caching'] is True for row in rows), 'prefix caching is not effective')
    values = []
    for group in document['groups']:
        for result in group['results']:
            usage = result['summary']['usage']
            cached = usage['prompt_tokens_details']['cached_tokens']
            require(type(cached) is int and 0 <= cached <= usage['prompt_tokens'], 'invalid actual cached token usage')
            values.append(dict(phase=group['phase'], label=group['label'],
                               cached_tokens=cached, prompt_tokens=usage['prompt_tokens']))
    require(any(row['cached_tokens'] > 0 for row in values), 'no actual baseline prefix hit')
    return values


def check_saved(args):
    source = Path(__file__).resolve().parents[1]
    campaign = json.loads(args.campaign.read_text())
    receipt = json.loads(Path(campaign['admission_path']).read_text())
    require(campaign['source_sha'] == args.expected_sha and campaign['arm'] == 'E_OFF'
            and campaign['baseline_profile'] == PROFILE and campaign['baseline_tool_sha256'] == digest(__file__)
            and campaign['profile_identity'] == profile_identity()
            and campaign['requests_sha256'] == digest(args.requests)
            and campaign['admission_sha256'] == digest(campaign['admission_path'])
            and receipt['source_sha'] == campaign['source_sha']
            and receipt['source_tree'] == campaign['source_tree'] and receipt['tp'] == 16,
            'actual original eager OFF source/model/admission differs')
    name = campaign['server_argv'][campaign['server_argv'].index('--served-model-name') + 1]
    argv = baseline_serve_argv(campaign['server_argv'][0], args.port, name, 'E_OFF', worker_provenance=True)
    require(argv == json.loads(args.server_argv.read_text()), 'actual original eager OFF CLI differs')
    document = json.loads(args.records.read_text())
    result = validate_requests(campaign, document, json.loads(args.requests.read_text()),
        expected_server_argv=argv, expected_source=source, expected_vllm_source=receipt['vllm_checkout'],
        worker_identity_validator=validate_workers, worker_extension_cls=EXTENSION)
    rows = campaign['worker_provenance'][-1]['results']
    result.update(status=ACCEPTED, required_features=validate_required_features(rows,
        require_execution=True, require_graph_window=False), actual_dispatch=validate_dispatch(rows),
        prefix_hits=prefix_hits(document, rows), token_correctness='NOT_ASSESSED_KEEP_C151_FAILURE',
        performance='NOT_A_FORMAL_PERFORMANCE_CELL', physical_read='NOT_OBSERVED')
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=('run', 'check'))
    p.add_argument('--arm', choices=('E_OFF',), default='E_OFF')
    p.add_argument('--port', type=int, required=True)
    p.add_argument('--expected-sha', required=True)
    for key in ('requests', 'output', 'admission', 'campaign', 'records', 'server-argv'):
        p.add_argument('--' + key, type=Path, required=key in ('requests', 'output'))
    args = p.parse_args()
    if args.command == 'run':
        args.worker_provenance = True
        return run_service(args, server_argv_builder=baseline_serve_argv, target_model=str(TARGET), tp=16,
            ready_timeout_seconds=1800, extra_metadata=dict(baseline_profile=PROFILE,
                baseline_tool_sha256=digest(__file__), profile_identity=profile_identity()))
    try:
        result = check_saved(args)
    except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
        result = dict(status='INVALID_EAGER_OFF_BASELINE_EVIDENCE', error=f'{type(error).__name__}: {error}')
    write(args.output, result)
    return 0 if result['status'] == ACCEPTED else 4


if __name__ == '__main__':
    raise SystemExit(main())
