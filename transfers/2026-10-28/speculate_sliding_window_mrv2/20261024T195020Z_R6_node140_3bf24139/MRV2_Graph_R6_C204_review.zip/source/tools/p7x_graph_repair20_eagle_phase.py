# SPDX-License-Identifier: Apache-2.0
"""Default-off, completed-Graph Eagle evidence; no normal-path installation.

Persist every completed consumer before checking the first numeric sample.
This adds diagnostic D2H and storage after an explicit successful drain. It is
neither a normal-overlap proof nor an execution-operand/physical-read probe.
"""
from __future__ import annotations

from collections.abc import Mapping

import torch

from tools.p7x_graph_repair6_storage import require


def tensor_layout(tensor):
    result = dict(
        object_id=id(tensor),
        shape=list(tensor.shape),
        dtype=str(tensor.dtype),
        device=str(tensor.device),
        stride=list(tensor.stride()),
        storage_offset=tensor.storage_offset(),
        data_ptr=tensor.data_ptr(),
        storage_data_ptr=tensor.untyped_storage().data_ptr(),
        storage_bytes=tensor.untyped_storage().nbytes(),
        contiguous=tensor.is_contiguous(),
        npu_format="NOT_APPLICABLE_CPU",
    )
    if tensor.device.type in ("npu", "privateuseone"):
        import torch_npu

        query = getattr(torch_npu, "get_npu_format", None)
        result["npu_format"] = int(query(tensor)) if query is not None else "NOT_AVAILABLE_IN_INSTALLED_API"
    return result


def tree_layout(value):
    if isinstance(value, torch.Tensor):
        return tensor_layout(value)
    if isinstance(value, Mapping):
        return {str(k): tree_layout(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [tree_layout(v) for v in value]
    return value


def export_completed_phase(writer, *, identity, states, identities, identity_records, outputs, caches, final, selected,
                           context, submission):
    completion = submission.snapshot()
    require(not completion["pending"] and completion["phase"] == "COMPLETED_GRAPH_POSTSTATE_SNAPSHOT_COMPLETE",
            "completed Graph drain and merged poststate required before diagnostic device export")
    require(len(identities) == len(identity_records) and len(identities) in (1, 2), "completed consumer inventory")
    require(selected and selected == sorted(set(selected)), "complete unique physical block selection")
    require(set(final) == set(caches), "merged actual cache inventory")
    consumers = []
    for capture, record in zip(identities, identity_records):
        state = states[capture]
        require(state.before is not None and state.after is not None, "completed consumer snapshot missing")
        require(set(state.before["kv"]) == set(state.after) == set(caches), "completed consumer KV inventory")
        before = dict(state.before)
        before["kv"] = {key: value[:len(selected)] for key, value in before["kv"].items()}
        if "legacy_capture_pool_kv" in before:
            before["legacy_capture_pool_kv"] = {
                key: value[:len(selected)] for key, value in before["legacy_capture_pool_kv"].items()
            }
        legacy_output = getattr(state, 'legacy_capture_pool_outputs', None)
        consumers.append(
            dict(
                identity=record,
                before=before,
                post_kv={
                    key: value[:len(selected)]
                    for key, value in state.after.items()
                },
                outputs=outputs[capture],
                legacy_capture_pool_outputs=legacy_output,
                output_layouts=dict(owned=tree_layout(outputs[capture]), legacy=tree_layout(legacy_output)),
                actual_indices=state.indices,
                captured_sources=[tensor_layout(value) for value in state.capture_sources],
                snapshot_destinations=dict(before=tree_layout(state.before), after=tree_layout(state.after)),
                source_lifetime="RETAINED_IN_CAPTURE_STATE_TUPLE_FOR_CAPTURED_PROGRAM_LIFETIME",
            ))
    record = dict(identity=identity,
                  status="COMPLETED_CAPTURE_EXPORT_NOT_NUMERIC_PASS",
                  selected_physical_blocks=selected,
                  consumers=consumers,
                  merged_actual_kv=final,
                  actual_cache_layout=tree_layout(caches),
                  context=context,
                  completion=completion,
                  scope="ALL_COMPLETED_CONSUMERS_BEFORE_COMPARISON; EXPLICIT_DRAIN_AND_EXTRA_D2H",
                  physical_read="NOT_PROVEN",
                  normal_overlap="UNPROVEN")
    submission.submit("COMPLETED_PHASE_EVIDENCE_EXPORT_PENDING")
    writer.start(identity)
    writer.finish(record)
    submission.complete("COMPLETED_PHASE_EVIDENCE_EXPORT_COMPLETE")
