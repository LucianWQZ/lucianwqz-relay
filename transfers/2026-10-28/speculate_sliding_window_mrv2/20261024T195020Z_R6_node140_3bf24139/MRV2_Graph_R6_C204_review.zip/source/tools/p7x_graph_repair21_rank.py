# SPDX-License-Identifier: Apache-2.0
"""Bounded real multi-worker Graph baseline, with explicit all-rank evidence.

Window OFF is the reference baseline. The explicit default-off TP2 review
arm retains real rank-owned carriers; neither arm opens the public Graph gate.
Worker RPC inspects Host metadata and wraps existing dispatch methods only.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from types import MethodType

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    sha = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 << 20), b""):
            sha.update(block)
    return sha.hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def validate_rank_records(records, *, tp, source, vllm_source, window):
    require(len(records) == tp, "missing rank records")
    require(all(type(row["rank"]) is int for row in records), "rank must be an explicit integer")
    require(sorted(row["rank"] for row in records) == list(range(tp)), "duplicate or missing rank")
    require(len({row["pid"] for row in records}) == tp, "worker PID reused across ranks")
    for row in records:
        require(row["world_size"] == row["tp_size"] == tp, "rank world/topology mismatch")
        require(row["window_size"] == window, "effective Window differs from requested arm")
        require(
            Path(row["ascend_source"]).resolve() == Path(source).resolve() / "vllm_ascend/__init__.py",
            "worker imports another Ascend source")
        require(
            Path(row["vllm_source"]).resolve() == Path(vllm_source).resolve() / "vllm/__init__.py",
            "worker imports another vLLM source")
        require(row["draft_graph_inventory"] and row["target_graph_inventory"], "rank lacks captured Graph inventory")
        require(row["draft_replays"] > 0 and row["target_replays"] > 0, "rank did not replay both actual Graph roles")
        require(row["draft_kv_geometry"], "rank lacks actual Draft KV geometry")
        require(not row["submission_uncertain"], "rank reports uncertain submission")
    if window is not None:
        for row in records:
            require(
                row.get("window_provider_installed") and not row.get("heavy_observer_enabled"),
                "rank lacks observer-off Window provider")
            generations = row.get("window_generations", [])
            require(generations and any(any(start > 0 for start in item["window_starts"]) for item in generations),
                    "rank has no actual clipped Window generation")
            require(all(item["tp_size"] == tp and item["tp_rank"] == row["rank"] for item in generations),
                    "runtime generation has cross-rank identity")
            bindings = row.get("window_graph_bindings", [])
            require(bindings and all(item["tp_size"] == tp and item["tp_rank"] == row["rank"] for item in bindings),
                    "actual replay lacks rank-owned Window binding")
        shared_fields = ("generation", "epoch", "requests", "actual", "padded", "window_starts", "exact")
        normalized = [[{
            key: item[key]
            for key in shared_fields
        } for item in row["window_generations"]] for row in records]
        require(all(items == normalized[0] for items in normalized), "rank Window source generations disagree")
    return dict(status="ALL_RANK_HOST_DISPATCH_AND_REQUEST_ANCHOR",
                ranks=tp,
                scope="Not continuous numerical, Target KV isolation, normal completion or physical-read proof")


def install_window_materialization_observer(worker, runtime):
    """Observe the actual owner lane using CPU-owned values only."""
    original = runtime.materialize

    def materialize(current, **kwargs):
        value = original(**kwargs)
        identity, topology = value.identity, value.identity.topology_fingerprint
        block = current.capability.inventory.groups[0].kernel_block_size
        worker._mrv2_rank_window_generations.append(dict(
            generation=identity.generation_id, execution_lane=identity.execution_lane,
            global_group_id=identity.global_group_id, epoch=identity.mapping_epoch,
            phase=identity.phase.value, step=identity.step,
            row_phases=list(identity.row_phase_fingerprint),
            requests=list(identity.ordered_request_fingerprint),
            actual=value.actual_request_count, padded=value.padded_request_count,
            tp_size=topology.tensor_parallel_size, tp_rank=topology.tensor_parallel_rank,
            window_starts=[desc.source_start_column * block + desc.first_token_offset
                           for desc in identity.read_descriptor_fingerprint],
            exact=value.cpu_window_exact.tolist(),
            evidence_scope="CPU-owned source state; no added D2H/synchronize"))
        return value

    runtime.materialize = MethodType(materialize, runtime)


def eager_async_pool_snapshot(speculator):
    pool = getattr(speculator, "_draft_window_async_pool", None)
    if pool is None:
        return None
    lanes = []
    for runtime in pool._runtimes:
        topology = runtime.topology_fingerprint
        lanes.append(dict(lane=runtime.execution_lane, runtime_id=id(runtime),
            table_address=runtime.workspace.window_block_table.data_ptr(),
            tp_rank=topology.tensor_parallel_rank, tp_size=topology.tensor_parallel_size,
            graph_mode=topology.graph_mode, async_scheduling=topology.async_scheduling,
            sequence_parallel=topology.sequence_parallel, dsa_context_parallel=topology.dsa_context_parallel,
            flashcomm=topology.flashcomm, prefix_caching=topology.prefix_caching))
    return dict(capacity=pool.capacity, lanes=lanes, scope="HOST_HEADERS_NOT_EVENT_COMPLETION")


class RankWorkerExtension:
    """No constructor or new process-global state; mixed into the real worker."""

    def mrv2_rank_install_dispatch_observer(self):
        require(not hasattr(self, "_mrv2_rank_replay_records"), "rank observer already installed")
        self._mrv2_rank_replay_records = []
        runner = self.model_runner
        owners = [("target", getattr(runner, "cudagraph_manager", None))]
        speculator = runner.speculator
        self._mrv2_rank_window_generations = []
        self._mrv2_rank_window_bindings = []
        pool = getattr(speculator, "_draft_window_async_pool", None)
        runtime = getattr(speculator, "_draft_window_runtime_state", None)
        # An Async eager owner materializes through independent lane runtimes;
        # wrapping its unused initial runtime would falsely report no Window.
        runtimes = tuple(pool._runtimes) if pool is not None else (() if runtime is None else (runtime,))
        for runtime in runtimes:
            install_window_materialization_observer(self, runtime)
        for name in ("query_cudagraph_manager", "prefill_cudagraph_manager", "decode_cudagraph_manager"):
            manager = getattr(speculator, name, None)
            if manager is not None:
                owners.append(("draft:" + name, manager))
        require(owners[0][1] is not None and len(owners) > 1, "actual Graph managers unavailable")
        for role, manager in owners:
            original = manager.run_fullgraph

            def replay(_manager, descriptor, *, original=original, role=role):
                record = dict(role=role,
                              num_tokens=descriptor.num_tokens,
                              num_reqs=descriptor.num_reqs,
                              mode=descriptor.cg_mode.name,
                              host_start_ns=time.monotonic_ns(),
                              returned=False)
                self._mrv2_rank_replay_records.append(record)
                value = original(descriptor)
                provider = getattr(speculator, "_draft_window_graph_binding_provider", None)
                if (role.startswith("draft:") and provider is not None
                        and not getattr(speculator, "_draft_window_dp_dummy_active", False)):
                    # A DP idle replay uses baseline operands. The provider may
                    # still own the preceding real carrier; do not relabel that
                    # carrier as a new business submission in this Host audit.
                    for carrier in provider.submitted_carriers:
                        identity = carrier.runtime_identity
                        require(identity is not None, "returned replay has no Window runtime binding")
                        self._mrv2_rank_window_bindings.append(
                            dict(generation=identity.generation_id,
                                 global_group_id=carrier.capture_identity.fingerprint.global_group_id,
                                 epoch=identity.mapping_epoch,
                                 tp_size=identity.tensor_parallel_size,
                                 tp_rank=identity.tensor_parallel_rank,
                                 capture_bucket=list(carrier.capture_identity.fingerprint.capture_bucket),
                                 table_address=carrier.capture_identity.backing_identity.window_block_table.data_ptr,
                                 scope="Host binding/return only; not device completion or execution operand"))
                record.update(returned=True, host_return_ns=time.monotonic_ns())
                return value

            manager.run_fullgraph = MethodType(replay, manager)
        return dict(rank=self.rank,
                    pid=os.getpid(),
                    roles=[role for role, _ in owners],
                    overhead="Host-only dispatch records; no sync/D2H/event query; correctness anchor, not performance")

    def mrv2_rank_snapshot(self):
        import torch
        import vllm
        import vllm_ascend
        runner, speculator = self.model_runner, self.model_runner.speculator
        config = self.vllm_config

        def inventory(manager):
            if manager is None:
                return []
            return [
                dict(mode=desc.cg_mode.name, tokens=desc.num_tokens, requests=desc.num_reqs) for desc in manager.graphs
            ]

        draft_inventory = []
        for name in ("query_cudagraph_manager", "prefill_cudagraph_manager", "decode_cudagraph_manager"):
            draft_inventory += [dict(role=name, **row) for row in inventory(getattr(speculator, name, None))]
        layers = sorted(speculator.draft_attn_layer_names)
        # Parallel DSpark/DFlash stores Draft layers in the runner's shared
        # forward context. Eagle's draft_vllm_config/attn_backend attributes
        # are a different method interface and must not be assumed here.
        context = runner.compilation_config.static_forward_context
        require(set(layers) <= set(context), "actual shared-context Draft layer inventory missing")
        backends = speculator.attn_backends
        require(set(backends) == set(layers), "actual per-layer Draft backend inventory missing")
        kv = {}
        for name in layers:
            for i, tensor in enumerate(context[name].kv_cache):
                kv[f"{name}/{i}"] = dict(shape=list(tensor.shape),
                                         dtype=str(tensor.dtype),
                                         stride=list(tensor.stride()),
                                         data_ptr=tensor.data_ptr(),
                                         device=str(tensor.device))
        records = list(getattr(self, "_mrv2_rank_replay_records", []))
        maps = Path("/proc/self/maps").read_text()
        loaded = sorted({
            line.split()[-1]
            for line in maps.splitlines()
            if any(key in line for key in ("libruntime_v100", "vllm_ascend_C", "libtorch_npu", "custom_transformer"))
        })
        nspid = next((line.split()[1:]
                      for line in Path("/proc/self/status").read_text().splitlines() if line.startswith("NSpid:")), [])
        return dict(rank=self.rank,
                    local_rank=self.local_rank,
                    world_size=config.parallel_config.world_size,
                    tp_size=config.parallel_config.tensor_parallel_size,
                    pid=os.getpid(),
                    nspid=nspid,
                    process_start_ticks=Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()[19],
                    hostname=socket.gethostname(),
                    logical_device=torch.npu.current_device(),
                    visible=os.environ.get("ASCEND_RT_VISIBLE_DEVICES"),
                    ascend_source=vllm_ascend.__file__,
                    vllm_source=vllm.__file__,
                    worker_class=type(self).__module__ + "." + type(self).__qualname__,
                    speculator_class=type(speculator).__module__ + "." + type(speculator).__qualname__,
                    window_size=config.additional_config.get("draft_window_size"),
                    window_provider_installed=hasattr(speculator, "_draft_window_graph_binding_provider"),
                    heavy_observer_enabled=bool(
                        getattr(getattr(speculator, "_draft_window_graph_characterization", None), "recorder", None)
                        and speculator._draft_window_graph_characterization.recorder.enabled),
                    window_generations=list(getattr(self, "_mrv2_rank_window_generations", [])),
                    window_graph_bindings=list(getattr(self, "_mrv2_rank_window_bindings", [])),
                    eager_async_pool=eager_async_pool_snapshot(speculator),
                    draft_backend={
                        name: backend.__module__ + "." + backend.__qualname__
                        for name, backend in backends.items()
                    },
                    draft_layers=layers,
                    draft_tp_size=speculator.speculative_config.draft_parallel_config.tensor_parallel_size,
                    draft_model_config=speculator.draft_model_config.model,
                    draft_kv_geometry=kv,
                    draft_graph_inventory=draft_inventory,
                    target_graph_inventory=inventory(getattr(runner, "cudagraph_manager", None)),
                    dispatch_records=records,
                    draft_replays=sum(row["role"].startswith("draft:") and row["returned"] for row in records),
                    target_replays=sum(row["role"] == "target" and row["returned"] for row in records),
                    submission_uncertain=bool(getattr(speculator, "_draft_window_graph_submission_uncertain", False)),
                    loaded_native=loaded,
                    device_completion="NOT_INFERRED_FROM_RPC_OR_HOST_RETURN")


def live_owner(owner):
    try:
        stat = Path("/proc", str(owner["pid"]), "stat").read_text().rsplit(")", 1)[1].split()
        return stat[19] == owner["process_start_ticks"]
    except (OSError, KeyError, ValueError):
        return False


def validate_admission(path, *, source, sha, tp):
    from tools.p7x_graph_local_candidate import BASE_SHA, VLLM_SHA, VLLM_TREE, _identity
    from tools.p7x_graph_repair7_device import inspect
    receipt = json.loads(Path(path).read_text())
    require(receipt["schema"] == "repair21-complete-rank-admission-v1", "unknown rank admission schema")
    require(receipt["source_sha"] == sha and receipt["tp"] == tp, "source/topology admission mismatch")
    _identity(source, sha, receipt["source_tree"], ancestor=BASE_SHA)
    _identity(Path(receipt["vllm_checkout"]), VLLM_SHA, VLLM_TREE)
    current = inspect()
    require(current["hostname"] == receipt["host"] and current["boot_id"] == receipt["boot_id"], "host/boot changed")
    require(current["namespace"] == receipt["namespace"], "namespace changed")
    now = time.time()
    require(receipt["issued_at"] <= now < receipt["expires_at"] and now - receipt["issued_at"] <= 120,
            "stale rank admission")
    authorization = receipt["authorization"]
    require(digest(authorization["path"]) == authorization["sha256"], "authorization changed")
    auth = json.loads(Path(authorization["path"]).read_text())
    require(auth["schema"] == "mrv2-user-device-authorization-v1", "authorization schema")
    require(auth["authority"] == "USER_INSTRUCTION_NO_ADMIN_SIGNATURE", "authorization provenance")
    require(auth["hostname"] == current["hostname"] and auth["boot_id"] == current["boot_id"],
            "authorization host mismatch")
    require(now < auth["deadline_epoch_seconds"] and receipt["expires_at"] <= auth["deadline_epoch_seconds"],
            "reservation expired")
    phys = receipt["phy_ids"]
    require(
        len(phys) == tp and len(set(phys)) == tp and all(type(p) is int and p in auth["host_phy_ids"] for p in phys),
        "incomplete or unauthorized complete rank set")
    require(
        current["visibility"] == dict(ASCEND_RT_VISIBLE_DEVICES=",".join(map(str, phys)), ASCEND_VISIBLE_DEVICES=None),
        "rank visibility changed")
    mapping = current.get("mapping_command", {})
    require(mapping.get("rc") == 0, "live physical mapping unavailable")
    chip_mapping = {}
    for physical in phys:
        require(current["nodes"].get(f"/dev/davinci{physical}") == receipt["nodes"][str(physical)],
                "device node changed")
        matches = [
            parts for parts in (line.split() for line in mapping["stdout"].splitlines())
            if len(parts) >= 5 and parts[2:4] == [str(physical), str(physical)]
        ]
        require(len(matches) == 1, "physical mapping missing or ambiguous")
        chip_mapping[physical] = matches[0][:2]
    q = subprocess.run(["npu-smi", "info"], capture_output=True, text=True, timeout=15)
    require(q.returncode == 0, "live occupancy query failed")
    # Conservative initial all-rank baseline: require selected board pairs idle.
    # This criterion is stated explicitly; it does not infer other chips' leases.
    require(all(f"No running processes found in NPU {p // 2}" in q.stdout for p in phys), "selected rank set occupied")
    require(set(receipt["leases"]) == set(map(str, phys)), "complete-set lease missing")
    require(set(receipt["probes"]) == set(map(str, phys)), "complete-set physical probes missing")
    for physical in phys:
        lease = receipt["leases"][str(physical)]
        owner = json.loads(Path(lease["path"]).read_text())
        require(owner["token"] == lease["token"] and owner["status"] == "HELD", "lease identity changed")
        require(owner["host"] == current["hostname"] and owner["session"] == receipt["session"],
                "lease holder mismatch")
        require(physical in owner["phy_ids"] and owner["candidate"] == sha, "lease rank/source mismatch")
        require(receipt["expires_at"] <= datetime.fromisoformat(owner["lease_deadline"]).timestamp(), "lease expired")
        age = now - datetime.fromisoformat(owner["heartbeat_at"]).timestamp()
        require(0 <= age <= 60, "lease heartbeat stale")
        require(live_owner(owner), "lease supervisor process identity changed")
        probe = receipt["probes"][str(physical)]
        require(digest(probe["path"]) == probe["sha256"], "physical probe evidence changed")
        evidence = json.loads(Path(probe["path"]).read_text())
        require(
            evidence["physical_id"] == physical and evidence["returncode"] == 0 and evidence["value"] == 1024
            and evidence["logical_device"] == 0, "physical compute probe failed")
        require(evidence["host_pid"] > 0 and evidence["container_pid"] > 0 and evidence["observations"],
                "probe PID not associated with management evidence")
        require(evidence["boot_id"] == current["boot_id"] and evidence["namespace"] == current["namespace"],
                "probe from another boot/namespace")
        for observation in evidence["observations"]:
            require(digest(observation["path"]) == observation["sha256"], "probe management evidence changed")
            rows = [[part.strip() for part in line.strip().strip("|").split("|")]
                    for line in Path(observation["path"]).read_text().splitlines()]
            require(
                any(
                    len(row) >= 5 and row[0].split() == chip_mapping[physical] and row[1] == str(evidence["host_pid"])
                    and row[4] == str(evidence["container_pid"]) for row in rows), "probe PID/chip observation missing")
    require(
        digest(receipt["runtime_manifest"]["path"]) == receipt["runtime_manifest"]["sha256"],
        "runtime manifest changed")
    return receipt


def build_rank_kwargs(tp, *, window_on_review=False):
    kwargs = dict(model="/mnt/share/wql/Qwen3-8B",
                  tensor_parallel_size=tp,
                  distributed_executor_backend="mp",
                  worker_extension_cls="tools.p7x_graph_repair21_rank.RankWorkerExtension",
                  speculative_config=dict(method="dspark",
                                          model="/mnt/share/dspark_qwen3_8b_block7",
                                          num_speculative_tokens=7,
                                          enable_adaptive_verification=False),
                  additional_config={},
                  async_scheduling=False,
                  enable_prefix_caching=False,
                  compilation_config=dict(cudagraph_capture_sizes=[7, 14, 28, 32], cudagraph_mode="FULL_DECODE_ONLY"),
                  enforce_eager=False,
                  gpu_memory_utilization=0.6,
                  max_model_len=4096,
                  max_num_batched_tokens=4096,
                  max_num_seqs=4,
                  seed=0,
                  disable_log_stats=True)
    if window_on_review:
        require(type(tp) is int and tp in (2, 4, 16), "explicit complete replicated TP2/4/16 review topology required")
        kwargs["additional_config"].update(draft_window_size=1024, draft_window_graph_replicated_tp_review=True)
    return kwargs


def isolate_failed_parent(record, output, error, *, model_initialized, exit_process=os._exit):
    """Export Host facts, then isolate an initialized failed model without RPC."""
    record.update(status="FAILED",
                  ended_at=time.time(),
                  exception_type=type(error).__name__,
                  exception_message=str(error),
                  failure_action="PARENT_EXIT74_NO_DEVICE_RECOVERY" if model_initialized else "PRE_MODEL_RAISE",
                  completion="NOT_INFERRED_FROM_EXCEPTION_OR_PROCESS_EXIT")
    write(Path(output) / "campaign.json", record)
    if model_initialized:
        exit_process(74)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--admission", type=Path, required=True)
    parser.add_argument("--expected-sha", required=True)
    parser.add_argument("--tp", type=int, choices=(2, 4, 16), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--window-on-review", action="store_true")
    args = parser.parse_args()
    return run_anchor(args)


ANCHOR_REQUEST_PLAN = (("short-one", (257,)), ("long-three", (2051, 771, 387)))


def run_anchor(args, *, profile_kwargs=None, profile_identity=None, producer_path=None, before_requests=None,
               request_plan=ANCHOR_REQUEST_PLAN, output_tokens=32):
    """Reuse admission, actual model/RPC requests and isolation for a named profile.

    Profiles supply their own strict model/backend contract and independent
    checker. They cannot inherit the Qwen-specific external checker verdict.
    """
    source = Path(__file__).resolve().parents[1]
    receipt = validate_admission(args.admission, source=source, sha=args.expected_sha, tp=args.tp)
    require(not args.output.exists(), "new attempt directory required")
    args.output.mkdir(parents=True)
    record = dict(kind=("REAL_MP_DSPARK_WINDOW_ON_REVIEW_GRAPH_ANCHOR"
                        if args.window_on_review else "REAL_MP_DSPARK_WINDOW_OFF_GRAPH_ANCHOR"),
                  source_sha=args.expected_sha,
                  source_tree=receipt["source_tree"],
                  tp=args.tp,
                  window_on_review=args.window_on_review,
                  requests=[],
                  status="STARTING",
                  pid=os.getpid(),
                  started_at=time.time(),
                  script_sha256=digest(producer_path or __file__),
                  admission_sha256=digest(args.admission))
    if profile_identity is not None:
        record["profile_identity"] = profile_identity
        record["kind"] = "REAL_MP_NAMED_PROFILE_GRAPH_ANCHOR"
    write(args.output / "campaign.json", record)
    llm = None
    try:
        import torch_npu  # noqa: F401
        import vllm_ascend.ops  # noqa: F401; established circular-import-safe startup
        import vllm_ascend.worker.v2.spec_decode  # noqa: F401
        from vllm import LLM, SamplingParams
        kwargs = (build_rank_kwargs(args.tp, window_on_review=args.window_on_review)
                  if profile_kwargs is None else profile_kwargs)
        require(type(output_tokens) is int and 0 < output_tokens <= 512
                and 1 <= len(request_plan) <= 4 and len({label for label, _ in request_plan}) == len(request_plan)
                and all(isinstance(label, str) and label and 1 <= len(lengths) <= kwargs['max_num_seqs']
                        and all(type(length) is int and 0 < length
                                and length+output_tokens <= kwargs['max_model_len'] for length in lengths)
                        for label, lengths in request_plan), 'named bounded anchor request contract required')
        if request_plan != ANCHOR_REQUEST_PLAN or output_tokens != 32:
            record['request_contract'] = dict(groups=[dict(label=label, lengths=list(lengths))
                                                       for label, lengths in request_plan], output_tokens=output_tokens)
        record["kwargs"] = kwargs
        record["config_sha256"] = hashlib.sha256(json.dumps(kwargs, sort_keys=True).encode()).hexdigest()
        llm = LLM(**kwargs)
        record["installed_observers"] = llm.collective_rpc("mrv2_rank_install_dispatch_observer", timeout=90)
        if before_requests is not None:
            # A named method may persist actual post-capture geometry before
            # the first request. A rejected header must not start inference.
            before_requests(llm, record, args.output)
        params = SamplingParams(temperature=0, max_tokens=output_tokens, min_tokens=output_tokens, ignore_eos=True)
        for label, lengths in request_plan:
            prompts = [dict(prompt_token_ids=[100 + i] * length) for i, length in enumerate(lengths)]
            start = time.monotonic_ns()
            outputs = llm.generate(prompts, params, use_tqdm=False)
            require(
                len(outputs) == len(prompts) and all(row.finished and len(row.outputs[0].token_ids) == output_tokens
                                                     for row in outputs), "request completion/output count")
            record["requests"].append(
                dict(label=label,
                     prompts=prompts,
                     start_ns=start,
                     end_ns=time.monotonic_ns(),
                     outputs=[
                         dict(request_id=row.request_id,
                              token_ids=list(row.outputs[0].token_ids),
                              finished=row.finished) for row in outputs
                     ]))
            write(args.output / "campaign.json", record)
        record["ranks"] = llm.collective_rpc("mrv2_rank_snapshot", timeout=90)
        record["joint"] = validate_rank_records(record["ranks"],
                                                tp=args.tp,
                                                source=source,
                                                vllm_source=receipt["vllm_checkout"],
                                                window=kwargs.get('additional_config',{}).get('draft_window_size')
                                                if args.window_on_review else None)
        record["status"] = ("ALL_RANK_WINDOW_ON_REVIEW_ANCHOR_COMPLETED_NOT_NUMERIC_VALIDATION"
                            if args.window_on_review else "ALL_RANK_REQUEST_ANCHOR_COMPLETED_NOT_WINDOW_VALIDATION")
    except BaseException as error:
        isolate_failed_parent(record, args.output, error, model_initialized=llm is not None)
        raise
    finally:
        record["ended_at"] = time.time()
        write(args.output / "campaign.json", record)
        if llm is not None and record["status"].startswith("ALL_RANK_"):
            llm.llm_engine.engine_core.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
