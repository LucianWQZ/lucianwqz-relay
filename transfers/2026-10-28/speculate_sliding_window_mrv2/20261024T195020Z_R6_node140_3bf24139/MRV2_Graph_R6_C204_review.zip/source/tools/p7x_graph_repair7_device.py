#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Fail-closed physical device admission with distinct authorization sources.

inspect never initializes torch/NPU. The original owner receipt remains valid.
The user-authorized path requires a bounded reservation record, live mapping,
fresh resource evidence and an observed probe PID; it does not claim an admin
signature or infer a physical ID merely from process logical npu:0.
"""

import argparse
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair5_evidence import file_sha as digest
from tools.p7x_graph_repair5_evidence import require


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def inspect():
    nodes = {}
    for p in Path("/dev").glob("davinci*"):
        st = p.stat()
        nodes[str(p)] = dict(major=os.major(st.st_rdev), minor=os.minor(st.st_rdev))
    result = dict(
        pid=os.getpid(),
        parent_pid=os.getppid(),
        hostname=socket.gethostname(),
        time_ns=time.time_ns(),
        nodes=nodes,
        visibility={k: os.environ.get(k) for k in ("ASCEND_RT_VISIBLE_DEVICES", "ASCEND_VISIBLE_DEVICES")},
        namespace=os.readlink("/proc/self/ns/mnt") if Path("/proc/self/ns/mnt").exists() else None,
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        if Path("/proc/sys/kernel/random/boot_id").exists()
        else None,
    )
    try:
        p = subprocess.run(["npu-smi", "info", "-m"], capture_output=True, text=True, timeout=15)
        result["mapping_command"] = dict(
            argv=["npu-smi", "info", "-m"], rc=p.returncode, stdout=p.stdout, stderr=p.stderr
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        result["mapping_error"] = str(error)
    result["status"] = "READ_ONLY_INVENTORY_NOT_ADMISSION"
    return result


def validate_receipt(receipt, current, run_id, *, now=None, require_probe=True):
    now = time.time() if now is None else now
    user_authorized = receipt.get("schema") == "repair7-user-authorized-device-v1"
    authorized_phy_ids = list(range(8))  # Legacy owner receipt scope remains unchanged.
    require(user_authorized or receipt.get("schema") == "repair7-device-receipt-v1", "unknown receipt schema")
    require(receipt["run_id"] == run_id, "run identity")
    if user_authorized:
        require("allocation_owner" not in receipt, "user instruction is not an owner receipt")
        record = receipt["user_authorization"]
        require(digest(record["path"]) == record["sha256"], "changed user authorization record")
        authorization = json.loads(Path(record["path"]).read_text())
        require(authorization.get("schema") == "mrv2-user-device-authorization-v1", "authorization schema")
        require(authorization.get("authority") == "USER_INSTRUCTION_NO_ADMIN_SIGNATURE", "authorization provenance")
        authorized_phy_ids = authorization.get("host_phy_ids")
        require(
            isinstance(authorized_phy_ids, list)
            and all(type(physical) is int for physical in authorized_phy_ids)
            and authorized_phy_ids in (list(range(8)), list(range(8, 16))),
            "authorization scope",
        )
        require(
            type(receipt["host_phy_id"]) is int and receipt["host_phy_id"] in authorized_phy_ids,
            "unauthorized physical device",
        )
        if authorized_phy_ids == list(range(8, 16)):
            require(
                bool(authorization.get("hostname")) and authorization["hostname"] == current.get("hostname"),
                "authorization host mismatch",
            )
            require(
                bool(authorization.get("boot_id")) and authorization["boot_id"] == current.get("boot_id"),
                "authorization boot mismatch",
            )
        require(now < authorization["deadline_epoch_seconds"], "user reservation expired")
        require(receipt["expires_at"] <= authorization["deadline_epoch_seconds"], "receipt exceeds reservation")
        require(
            current["visibility"]
            == {"ASCEND_RT_VISIBLE_DEVICES": str(receipt["host_phy_id"]), "ASCEND_VISIBLE_DEVICES": None},
            "unrestricted or ambiguous visibility",
        )
        mapping = current.get("mapping_command", {})
        require(mapping.get("rc") == 0, "live physical mapping unavailable")
        physical = receipt["host_phy_id"]
        mapped = any(
            len(parts) >= 5 and parts[2:4] == [str(physical), str(physical)] and parts[4] == "Ascend910"
            for parts in (line.split() for line in mapping["stdout"].splitlines())
        )
        require(mapped, "live npu-smi does not map selected logical/physical chip")
        require(set(receipt["allocated_nodes"]) == {f"/dev/davinci{physical}"}, "selected node mismatch")
        require(
            now - receipt["resource_observed_at"] <= 120 and now >= receipt["resource_observed_at"],
            "stale resource evidence",
        )
        resource_text = Path(receipt["resource_evidence"][0]["path"]).read_text()
        require(
            f"No running processes found in NPU {physical // 2}" in resource_text, "selected NPU has another process"
        )
        live_resources = subprocess.run(["npu-smi", "info"], capture_output=True, text=True, timeout=15)
        require(live_resources.returncode == 0, "live resource query failed")
        require(
            f"No running processes found in NPU {physical // 2}" in live_resources.stdout,
            "selected NPU is occupied now",
        )
    else:
        require(receipt["allocation_owner"].strip(), "allocation identity")
    require(receipt["issued_at"] <= now < receipt["expires_at"] <= receipt["issued_at"] + 3600, "expired receipt")
    require(
        type(receipt["host_phy_id"]) is int and receipt["host_phy_id"] in authorized_phy_ids,
        "unauthorized physical device",
    )
    require(receipt["tp"] == 1 and len(receipt["allocated_nodes"]) == 1, "TP1 requires one allocated chip")
    require(current["namespace"] is not None and current["boot_id"] is not None, "unknown host/container identity")
    for key in ("namespace", "boot_id", "visibility"):
        require(receipt[key] == current[key], "mapping changed: " + key)
    for node, geometry in receipt["allocated_nodes"].items():
        require(current["nodes"].get(node) == geometry, "device node changed")
    require(receipt["mapping_evidence"] and receipt["resource_evidence"], "missing mapping/resource evidence")
    for row in receipt["mapping_evidence"] + receipt["resource_evidence"]:
        require(digest(row["path"]) == row["sha256"], "changed admission evidence")
    if require_probe:
        probe = receipt["probe"]
        require(probe["host_pid"] > 0 and probe["container_pid"] > 0 and probe["command"], "missing own probe PID")
        require(probe["start_ns"] < probe["end_ns"] and probe["host_phy_id"] == receipt["host_phy_id"], "probe mapping")
        require(probe["status"] == "EXITED" and probe["returncode"] == 0, "probe incomplete")
        require(probe["host_process_evidence"] and probe["pid_namespace_evidence"], "cannot link probe to host PID")
        for row in (probe["host_process_evidence"], probe["pid_namespace_evidence"]):
            require(digest(row["path"]) == row["sha256"], "probe evidence changed")
        if user_authorized:
            probe_result = json.loads(Path(probe["pid_namespace_evidence"]["path"]).read_text())
            require(probe_result["pid"] == probe["container_pid"] and probe_result["rc"] == 0, "probe process mismatch")
            require(probe_result["visibility"] == str(receipt["host_phy_id"]), "probe visibility mismatch")
            require(
                '"value": 1024.0' in probe_result["stdout"] and '"logical_device": 0' in probe_result["stdout"],
                "probe computation missing",
            )
            require(
                any(row["smi_mentions_pid"] for row in probe_result["observations"]), "probe PID not observed on NPU"
            )
            require(
                any(
                    len(fields) >= 5
                    and fields[0].split() == [str(receipt["host_phy_id"] // 2), str(receipt["host_phy_id"] % 2)]
                    and fields[1] == str(probe["host_pid"])
                    and fields[4] == str(probe["container_pid"])
                    for fields in (
                        [field.strip() for field in line.strip().strip("|").split("|")]
                        for line in Path(probe["host_process_evidence"]["path"]).read_text().splitlines()
                    )
                ),
                "probe host/container PID not on selected physical chip",
            )
    return dict(
        status="ADMITTED_BY_USER_AUTHORIZATION_AND_MACHINE_EVIDENCE"
        if user_authorized
        else "ADMITTED_BY_OWNER_MAPPING_RECEIPT",
        physical_id=receipt["host_phy_id"],
        proof_boundary="user reservation plus live npu-smi and observed probe PID; no administrator signature"
        if user_authorized
        else "owner supplied mapping/PID evidence; not independently inferred from logical ID",
    )


def validate_admission(plan, case_id):
    require(
        bool(plan.get("device_admission_receipt")) and bool(plan.get("device_admission_sha256")),
        "BLOCKED_DEVICE_MAPPING: no current admission receipt",
    )
    path = Path(plan["device_admission_receipt"])
    require(digest(path) == plan["device_admission_sha256"], "receipt changed")
    receipt = json.loads(path.read_text())
    result = validate_receipt(receipt, inspect(), plan["run_id"])
    require(receipt["source_sha"] == plan["commit"] and receipt["case_id"] == case_id, "new case needs fresh admission")
    require(receipt["source_tree"] == plan["tree"], "receipt source tree mismatch")
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("command", choices=("inspect", "check", "probe"))
    p.add_argument("--receipt", type=Path)
    p.add_argument("--run-id")
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    inventory = inspect()
    if a.command == "inspect":
        result = inventory
    else:
        if not a.receipt or not a.run_id:
            p.error("receipt and run-id required")
        receipt = json.loads(a.receipt.read_text())
        result = validate_receipt(receipt, inventory, a.run_id, require_probe=a.command != "probe")
        if a.command == "probe":
            # Only AFTER read-only allocation mapping is attested. No model.
            import torch
            import torch_npu  # noqa: F401

            result.update(pid=os.getpid(), command=sys.argv, start_ns=time.time_ns(), inventory=inventory)
            atomic_json(a.output, dict(result, status="PROBE_STARTED_NEEDS_HOST_PID_CORRELATION"))
            value = torch.ones(1024, device="npu:0")
            result.update(
                value=float(value.sum().cpu()),
                end_ns=time.time_ns(),
                status="PROBE_FINISHED_NEEDS_HOST_PID_CORRELATION",
            )
    atomic_json(a.output, result)


if __name__ == "__main__":
    main()
