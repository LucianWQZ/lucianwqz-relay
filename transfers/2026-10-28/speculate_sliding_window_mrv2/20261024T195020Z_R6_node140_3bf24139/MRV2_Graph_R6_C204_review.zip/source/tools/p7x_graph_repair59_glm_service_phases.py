# SPDX-License-Identifier: Apache-2.0
"""Bounded actual GLM scheduler phase arm, reusing the existing CPU audit.

Records already owned CPU row counters and structurally associated Window
materializations/manager calls. No tensor observer, extra copy, event query or
synchronization. This separate arm is not normal performance or KV numerical
acceptance. The normal performance worker does not enable detailed phase rows.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import json

from tools.p7x_graph_repair16_scheduler import phase_from_rows
from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair32_glm_rank import TARGET, SP_CAPTURE_CONTRACT, profile_identity
from tools.p7x_graph_repair33_service import run_service, validate_requests
from tools.p7x_graph_repair40_glm_performance import validate_ranks
from tools.p7x_graph_repair47_glm_service import validate_prefix_hits
from tools.p7x_graph_repair50_glm_required_baseline import (
    GLMRequiredFeatureWorker, validate_required_features, validate_required_workers,
)
from tools.p7x_graph_repair56_glm_joint_performance import joint_serve_argv

PROFILE = 'GLM_TP16_REQUIRED_FEATURE_ACTUAL_PHASES_V1'
EXTENSION = 'tools.p7x_graph_repair59_glm_service_phases.GLMPhaseWorker'


class GLMPhaseWorker(GLMRequiredFeatureWorker):
    service_phase_details = True


def phase_serve_argv(python, port, model, arm, *, worker_provenance=False):
    argv = joint_serve_argv(python, port, model, arm, worker_provenance=worker_provenance)
    argv[argv.index('--max-num-batched-tokens') + 1] = '256'
    argv[argv.index('--worker-extension-cls') + 1] = EXTENSION
    return argv


def validate_actual_phases(workers, arm):
    """Independently classify CPU facts; never trust a mixed label alone."""
    require(arm in ('G_OFF', 'G_ON', 'E_ON') and len(workers) == 16,
            'named phase arm and all16 actual workers required')
    require(all(type(row['rank_snapshot']['rank']) is int for row in workers),
            'actual rank IDs must be integers')
    normalized, summaries = [], []
    for worker in sorted(workers, key=lambda row: row['rank_snapshot']['rank']):
        rank = worker['rank_snapshot']['rank']
        rows = worker['proposal_phases']
        require(worker['proposal_phase_detail_schema'] == 2 and rows
                and worker['proposal_phases_truncated'] is False,
                'complete detailed CPU scheduler evidence missing')
        phases, sequence, previous_epoch = set(), [], -1
        for row in rows:
            raw = row['raw_cpu_rows']
            actual, batch = phase_from_rows(raw)
            require(row['returned'] is True and 'classification_error' not in row
                    and row['row_phases'] == actual and row['batch_phase'] == batch
                    and row['requests'] == raw['request_ids']
                    and type(row['start_ns']) is type(row['end_ns']) is int
                    and row['start_ns'] < row['end_ns']
                    and set(row['flags_after']) == {'_draft_window_bypass_active',
                                                   '_draft_window_prefill_bypass_active'}
                    and all(value is False for value in row['flags_after'].values()),
                    'scheduler phase labels, return, time or bypass reset contradict CPU facts')
            sources = row['window_materializations']
            graphs = [call for call in row['manager_calls'] if call['role'].startswith('draft:')]
            require(all(call['returned'] is True and call['mode'] == 'FULL'
                        and row['start_ns'] <= call['host_start_ns'] < call['host_return_ns']
                        <= row['end_ns'] for call in graphs), 'unreturned or unassociated Draft manager call')
            continuing = all(phase == 'prefill_continuing' for phase in actual)
            if arm == 'G_OFF':
                require(not sources, 'Window OFF materialized Window inputs')
            elif continuing:
                require(not sources and not graphs, 'all-continuing batch lost its full-read eager baseline')
            else:
                require(len(sources) == 1, 'eligible parallel proposal lacks its unique current source')
                source = sources[0]
                require(source['requests'] == raw['request_ids'] and source['row_phases'] == actual
                        and source['tp_rank'] == rank and source['tp_size'] == 16
                        and source['actual'] == len(actual)
                        and source['actual'] <= source['padded'] <= 4
                        and len(source['exact']) == source['padded']
                        and len(source['window_starts']) == source['actual']
                        and all(type(value) is int and value >= 0 for value in (
                            source['exact'] + source['window_starts']))
                        and type(source['epoch']) is int and source['epoch'] > previous_epoch,
                        'phase/source row identity, rank, exact geometry or epoch differs')
                require(all(source['window_starts'][index] == 0 for index, phase in enumerate(actual)
                            if phase == 'prefill_continuing'), 'continuing row was cropped in a mixed batch')
                previous_epoch = source['epoch']
                if arm == 'G_ON':
                    require(len(graphs) == 1 and graphs[0]['num_reqs'] == source['padded']
                            and graphs[0]['num_tokens'] == source['padded'] * 8,
                            'actual parallel Graph manager/source bucket association missing')
            if arm == 'E_ON':
                require(not graphs, 'Draft eager control submitted a Draft Graph')
            phases.update(actual)
            phases.add(batch)
            sequence.append(dict(raw_cpu_rows=raw, batch_phase=batch, row_phases=actual,
                source=[{key: item[key] for key in ('epoch', 'requests', 'actual', 'padded',
                    'window_starts', 'exact', 'row_phases')} for item in sources]))
        require({'pure_decode', 'prefill_continuing', 'prefill_terminal', 'mixed'} <= phases,
                'actual workload did not hit every declared scheduler phase')
        require(len({tuple(row['raw_cpu_rows']['request_ids']) for row in rows}) > 1,
                'no actual request-set replacement observed')
        normalized.append(sequence)
        summaries.append(dict(rank=rank, proposals=len(rows), phases=sorted(phases)))
    require([row['rank'] for row in summaries] == list(range(16)), 'rank set is incomplete or duplicated')
    require(all(sequence == normalized[0] for sequence in normalized), 'actual all-rank business phases differ')
    return dict(status='PASS_SCOPED_ACTUAL_GLM_PHASES_AND_SOURCE_ASSOCIATION', ranks=summaries,
        scope='CPU rows and actual Host manager/source calls; not per-phase tensor numeric or device completion',
        normal_completion='SOURCE_CONTRACT_SEPARATE', execution_operand='NOT_OBSERVED', physical_read='NOT_OBSERVED')


def check_saved(args, *, worker_extension_cls=EXTENSION, server_argv_builder=phase_serve_argv):
    source = Path(__file__).resolve().parents[1]
    campaign = json.loads(args.campaign.read_text())
    require(campaign['phase_profile'] == PROFILE and campaign['arm'] == args.arm
            and campaign['source_sha'] == args.expected_sha
            and campaign['requests_sha256'] == digest(args.requests), 'phase source/workload differs')
    receipt = json.loads(Path(campaign['admission_path']).read_text())
    require(digest(campaign['admission_path']) == campaign['admission_sha256']
            and receipt['source_sha'] == campaign['source_sha'] and receipt['tp'] == 16,
            'actual phase admission differs')
    name = campaign['server_argv'][campaign['server_argv'].index('--served-model-name') + 1]
    argv = server_argv_builder(campaign['server_argv'][0], args.port, name, args.arm, worker_provenance=True)
    require(argv == json.loads(args.server_argv.read_text()), 'actual phase CLI differs')
    document = json.loads(args.records.read_text())
    result = validate_requests(campaign, document, json.loads(args.requests.read_text()),
        expected_server_argv=argv, expected_source=source, expected_vllm_source=receipt['vllm_checkout'],
        worker_identity_validator=validate_required_workers, worker_extension_cls=worker_extension_cls)
    rows = campaign['worker_provenance'][-1]['results']
    result.update(required_features=validate_required_features(rows, require_execution=True,
                    require_graph_window=args.arm == 'G_ON'),
        prefix=validate_prefix_hits(campaign, document),
        phases=validate_actual_phases(rows, args.arm),
        actual_dispatch=validate_ranks([row['rank_snapshot'] for row in rows], source=source,
            pin=receipt['vllm_checkout'], arm=args.arm, need_clip=args.arm != 'G_OFF',
            capture_contract=SP_CAPTURE_CONTRACT, eager_async_lanes=args.arm == 'E_ON'),
        performance='NOT_A_PERFORMANCE_ARM', numerical='NOT_PHASE_TENSOR_COMPARISON')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('run', 'check'))
    parser.add_argument('--arm', choices=('G_OFF', 'G_ON', 'E_ON'), required=True)
    parser.add_argument('--expected-sha', required=True)
    parser.add_argument('--port', type=int, required=True)
    for name in ('requests', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ('admission', 'campaign', 'records', 'server-argv'):
        parser.add_argument('--' + name, type=Path)
    args = parser.parse_args()
    if args.command == 'check':
        try:
            result = check_saved(args)
        except (ValueError, KeyError, TypeError, IndexError, AttributeError, OSError) as error:
            result = dict(status='INVALID_EVIDENCE', error=f'{type(error).__name__}: {error}')
        write(args.output, result)
        return 0 if result['status'] == 'PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS' else 4
    args.worker_provenance = True
    return run_service(args, server_argv_builder=phase_serve_argv, target_model=str(TARGET),
        tp=16, ready_timeout_seconds=1800,
        extra_metadata=dict(model_profile=profile_identity(), phase_profile=PROFILE,
            phase_entrypoint_sha256=digest(__file__), prefix_cache_requested=True,
            measurement='SEPARATE_CPU_PHASE_AUDIT_NOT_NORMAL_PERFORMANCE'))


if __name__ == '__main__':
    raise SystemExit(main())
