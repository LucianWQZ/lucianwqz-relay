# SPDX-License-Identifier: Apache-2.0
"""Bounded same-prestate eager Q8 versus padded Q16 discrimination.

Extends the existing three-sample completed CP diagnostic. Its original
Graph/eager-Q16 oracle is unchanged. A second actual eager backbone call uses
the real E_ON metadata assembler at active1/padded1, after restoring the exact
same pre-KV. Every completed poststate is retained, including block0. This is
serial diagnosis, never normal Async safety or performance evidence.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import inspect
import json
import os
import time
from contextlib import ExitStack
from types import MethodType

import torch

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair25_rank_numeric import build_parser, check_external as common_check, run_controlled
from tools.p7x_graph_repair55_glm_cp_numeric import (
    GLMCPNumericWorker, PROFILE, build_kwargs as cp_kwargs, check_payload as cp_check_payload,
    model_contract, validate_fixture, validate_worker,
)
from tools.p7x_graph_repair6_storage import CollectionReader, CollectionWriter, CHUNK
from tools.p7x_graph_repair6_submission import SubmissionState

CONTRAST = 'GLM_CP_SAME_PRESTATE_EAGER_Q16_VS_Q8_V1'
EXTENSION = 'tools.p7x_graph_repair65_glm_eager_padding.GLMPaddingWorker'
ACCEPTED = 'PASS_SCOPED_CP_GRAPH_AND_EAGER_PADDING_SENTINEL'


def build_kwargs(arm, tp):
    require(arm == 'ON' and tp == 16, 'one explicit complete TP16 Window ON prefix only')
    result=cp_kwargs(arm,tp)
    result['worker_extension_cls']=EXTENSION
    return result


def metadata_snapshot(values):
    rows={}
    for name,m in values.items():
        row=dict(metadata_class=type(m).__module__+'.'+type(m).__qualname__,
            causal=m.causal,actual_seq_lengths_q=list(m.actual_seq_lengths_q),
            seq_lens_list=list(m.seq_lens_list),num_actual_tokens=m.num_actual_tokens,
            num_decodes=m.num_decodes,num_prefills=m.num_prefills,num_decode_tokens=m.num_decode_tokens)
        for key in ('block_tables','seq_lens','seq_lens_cpu','slot_mapping','query_start_loc'):
            value=getattr(m,key)
            row[key]=None if value is None else value.detach().cpu().clone()
            row[key+'_header']=None if value is None else dict(shape=list(value.shape),dtype=str(value.dtype),
                stride=list(value.stride()),storage_offset=value.storage_offset(),data_ptr=value.data_ptr())
        rows[name]=row
    return rows


def active_eager_metadata(owner, reference):
    """Call the real eager metadata seam; do not hand-edit metadata fields."""
    from vllm_ascend.worker.v2.attn_utils import build_attn_metadata_wrapper, build_draft_attn_metadata_factory
    from vllm_ascend.worker.v2.spec_decode.draft_window_eager import (
        AscendDraftAttentionReadInputs, _isolate_draft_metadata_from_target,
    )
    nr=owner.input_batch.num_reqs;query=owner.num_query_per_req
    require(nr==1 and query==8 and set(reference)==set(owner.draft_attn_layer_names),
            'named single-active DSpark Q8 reference required')
    first=next(iter(reference.values()))
    live=owner._draft_window_live_inputs
    gid=live.identity.global_group_id
    require(type(gid) is int and 0<=gid<len(owner.block_tables.input_block_tables)
            and all(m.causal is False and m.actual_seq_lengths_q==[8,16]
                    and len(m.seq_lens_list)==2 and m.seq_lens_list[1]==0 for m in reference.values()),
            'actual padded noncausal reference metadata differs')
    tables=tuple(first.block_tables[:nr] if i==gid else value[:nr]
                 for i,value in enumerate(owner.block_tables.input_block_tables))
    exact=torch.tensor(first.seq_lens_list[:nr],dtype=torch.int32)
    upper=live.cpu_window_upper[:nr].clone()
    read=AscendDraftAttentionReadInputs(block_tables=tables,seq_lens=exact.to(owner.device),
        seq_lens_cpu_exact=exact,seq_lens_cpu_upper_bound=upper,max_seq_len=int(upper.max().item()))
    with ExitStack() as stack:
        stack.enter_context(build_attn_metadata_wrapper())
        stack.enter_context(build_draft_attn_metadata_factory(owner.input_buffers.positions,query,
                           torch.from_numpy(owner.input_batch.is_prefilling_np)))
        result=owner._build_ascend_draft_attn_metadata(num_reqs=nr,num_reqs_padded=nr,
            num_tokens_padded=nr*query,read_inputs=read,causal=owner._group_causal,
            query_start_loc_np=None,dcp_local_seq_lens=None)
    return _isolate_draft_metadata_from_target(result,owner.model_state.attn_metadata)


class PaddingContrast:
    def __init__(self,runner,payload,rank):
        self.runner,self.owner,self.payload,self.rank=runner,runner.speculator,payload,rank
        self.output=Path(payload['output'])/f'rank-{rank}'/'eager-padding'/'collection.json'
        self.original=self.owner._run_model
        self.writer=None
        self.submission=SubmissionState()
        self.samples=0

    def __enter__(self):
        probe=self
        def forward(_owner,num_tokens,metadata,slots,num_tokens_across_dp,cudagraph_runtime_mode):
            try:
                return probe.run(num_tokens,metadata,slots,num_tokens_across_dp,cudagraph_runtime_mode)
            except BaseException as error:
                probe.submission.failed(error)
                # Only Host state; the outer unchanged ContinuousReference
                # also marks its pending reference and isolates the child.
                write(probe.output.with_name('failure.json'),probe.submission.snapshot())
                raise
        self.owner._run_model=MethodType(forward,self.owner)
        return self

    def run(self,num_tokens,metadata,slots,num_tokens_across_dp,mode):
        from vllm.config.compilation import CUDAGraphMode
        from vllm.v1.worker.gpu.attn_utils import build_slot_mappings_by_layer
        s=self.owner;live=s._draft_window_live_inputs
        require(s.method=='dspark' and s.num_query_per_req==8 and s.num_speculative_steps==8
                and s.input_batch.num_reqs==1 and num_tokens==16 and mode==CUDAGraphMode.NONE
                and num_tokens_across_dp is None and live is not None,
                'contrast must run only in the declared completed Graph reference seam')
        gid=live.identity.global_group_id
        require(gid==s.draft_kv_cache_group_id and len(s.draft_attn_layer_names)==5,
                'actual Draft source group/layers differ')
        context=self.runner.compilation_config.static_forward_context
        caches={f'{name}/{i}':t for name in sorted(s.draft_attn_layer_names)
                for i,t in enumerate(context[name].kv_cache)}
        self.submission.submit('PAD_CONTRAST_PRESTATE_PENDING')
        full=s.block_tables.input_block_tables[gid][:2].detach().cpu().clone()
        mapping=torch.as_tensor(s.input_batch.idx_mapping_np[:1],dtype=torch.int64)
        valid=s.block_tables.num_blocks.cpu[gid].index_select(0,mapping).tolist()
        full_slots=s.block_tables.slot_mappings[gid,:16].detach().cpu().clone()
        selected=sorted(set(full[0,:valid[0]].tolist())|{int(v)//128 for v in full_slots.tolist() if v>=0}|{0})
        indices=torch.tensor(selected,dtype=torch.int64,device=s.device)
        snapshot_bytes=sum(len(selected)*t[0].numel()*t.element_size() for t in caches.values())
        require(snapshot_bytes*5<=1<<30,'bounded padding snapshots exceed1GiB/rank')
        before={k:t.index_select(0,indices) for k,t in caches.items()}
        inputs={key:getattr(s.input_buffers,key)[:16].detach().cpu().clone() for key in ('input_ids','positions')}
        query_layout=s.input_buffers.query_start_loc[:3].detach().cpu().clone()
        original_metadata=metadata_snapshot(metadata)
        torch.npu.current_stream().synchronize()
        self.submission.complete('PAD_CONTRAST_PRESTATE_COMPLETE')
        if self.writer is None:
            # Three declared A/B/A_prime samples, six worst-case KV copies
            # plus bounded metadata/output and serializer chunk reserve.
            limit=3*(6*snapshot_bytes+(16+8)*6144*2+CHUNK)
            self.writer=CollectionWriter(self.output,dict(contrast=CONTRAST,source_sha=self.payload['source_sha'],
                source_tree=self.payload['source_tree'],nonce=self.payload['nonce'],rank=self.rank,pid=os.getpid(),
                process_start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],
                tool=dict(path=__file__,sha256=digest(__file__)),scope='SERIAL_COMPLETED_EXTRA_REFERENCE_NOT_NORMAL_OVERLAP',
                atol=0.0,rtol=0.0),max_bytes=limit)
        identity=dict(rank=self.rank,nonce=self.payload['nonce'],generation=live.identity.generation_id,
                      epoch=live.identity.mapping_epoch,ordinal=self.samples)
        self.writer.start(identity)
        self.submission.submit('PADDED_ACTUAL_EAGER_FORWARD_PENDING')
        padded_start=time.monotonic_ns()
        padded=self.original(num_tokens,metadata,slots,None,mode)
        padded_return=time.monotonic_ns()
        preserved=padded.detach().clone()
        torch.npu.current_stream().synchronize()
        padded_complete=time.monotonic_ns()
        self.submission.complete('PADDED_ACTUAL_EAGER_COMPLETE')
        padded_cpu=preserved.detach().cpu().clone()
        padded_post={k:t.index_select(0,indices) for k,t in caches.items()}
        torch.npu.current_stream().synchronize()
        # All restoration below follows an explicitly completed forward. No
        # finally restores, unconfirmed device reads, or next unsafe consumer.
        self.submission.submit('UNPADDED_RESTORE_BUILD_AND_FORWARD_PENDING')
        for key,t in caches.items():t.index_copy_(0,indices,before[key])
        restored_before={k:t.index_select(0,indices) for k,t in caches.items()}
        unpadded_metadata=active_eager_metadata(s,metadata)
        unpadded_start=time.monotonic_ns()
        unpadded=self.original(8,unpadded_metadata,
            build_slot_mappings_by_layer(s.block_tables.slot_mappings[:,:8],s.kv_cache_config),None,mode)
        unpadded_return=time.monotonic_ns()
        torch.npu.current_stream().synchronize()
        unpadded_complete=time.monotonic_ns()
        self.submission.complete('UNPADDED_ACTUAL_EAGER_COMPLETE')
        unpadded_cpu=unpadded.detach().cpu().clone()
        unpadded_post={k:t.index_select(0,indices) for k,t in caches.items()}
        unpadded_meta=metadata_snapshot(unpadded_metadata)
        torch.npu.current_stream().synchronize()
        self.submission.submit('PADDED_POSTSTATE_RESTORE_PENDING')
        for key,t in caches.items():t.index_copy_(0,indices,padded_post[key])
        final={k:t.index_select(0,indices) for k,t in caches.items()}
        torch.npu.current_stream().synchronize()
        self.submission.complete('PADDED_POSTSTATE_RESTORE_COMPLETE')
        require(all(torch.equal(getattr(s.input_buffers,k)[:16].cpu(),value) for k,value in inputs.items())
                and torch.equal(s.block_tables.slot_mappings[gid,:16].cpu(),full_slots)
                and torch.equal(s.input_buffers.query_start_loc[:3].cpu(),query_layout)
                and torch.equal(s.block_tables.input_block_tables[gid][:2].cpu(),full),
                'extra reference changed real input/absolute position/Full slots')
        method=inspect.unwrap(self.original.__func__)
        method_path=Path(inspect.getfile(method)).resolve()
        record=dict(identity=identity,status='COMPLETED_PADDING_COMPARISON',actual_group=gid,
            descriptor=[1,2,16,8],canonical_table=full,valid=valid,full_slots=full_slots,selected_blocks=selected,
            inputs=inputs,original_query_layout=query_layout,padded_output=padded_cpu,unpadded_output=unpadded_cpu,
            pre_kv=before,restored_pre_kv=restored_before,padded_post_kv=padded_post,
            unpadded_post_kv=unpadded_post,final_restored_kv=final,
            padded_metadata=original_metadata,unpadded_metadata=unpadded_meta,
            actual_eager_method=dict(module=method.__module__,qualname=method.__qualname__,
                path=str(method_path),sha256=digest(method_path)),
            native_calls=[dict(tokens=16,mode='NONE',start_ns=padded_start,return_ns=padded_return,
                               diagnostic_complete_ns=padded_complete),
                          dict(tokens=8,mode='NONE',start_ns=unpadded_start,return_ns=unpadded_return,
                               diagnostic_complete_ns=unpadded_complete)],
            submission=self.submission.snapshot(),native_paths='TWO_ACTUAL_EAGER_BACKBONE_CALLS_NO_SAMPLING',
            completion='EXPLICIT_DIAGNOSTIC_CURRENT_STREAM_DRAINS')
        self.writer.finish(record)
        self.samples+=1
        return preserved  # Actual first eager result, protected before the second call.

    def __exit__(self,kind,*_):
        self.owner._run_model=self.original
        if self.writer is not None:self.writer.close('COMPLETE' if kind is None and self.samples==3 else 'EXECUTION_FAILED')


class GLMPaddingWorker(GLMCPNumericWorker):
    def mrv2_rank_controlled(self,payload):
        require(payload['arm']=='ON' and payload['sample_limit']==3,'only declared A/B/A_prime prefix')
        with PaddingContrast(self.model_runner,payload,self.rank) as contrast:
            result=super().mrv2_rank_controlled(payload)
        result['padding_artifact']=dict(path=str(contrast.output),sha256=digest(contrast.output),
                                        bytes=contrast.output.stat().st_size)
        return result


def check_contrast(record,reference):
    require(record['status']=='COMPLETED_PADDING_COMPARISON' and record['descriptor']==[1,2,16,8]
            and record['submission']['pending'] is False and record['submission']['failure'] is None
            and record['completion']=='EXPLICIT_DIAGNOSTIC_CURRENT_STREAM_DRAINS'
            and record['native_paths']=='TWO_ACTUAL_EAGER_BACKBONE_CALLS_NO_SAMPLING', 'unconfirmed padding reference')
    calls=record['native_calls']
    require(len(calls)==2 and [c['tokens'] for c in calls]==[16,8]
            and all(c['mode']=='NONE' and all(type(c[key]) is int for key in ('start_ns','return_ns','diagnostic_complete_ns'))
                    and c['start_ns']<c['return_ns']<=c['diagnostic_complete_ns'] for c in calls)
            and calls[0]['diagnostic_complete_ns']<calls[1]['start_ns'],
            'independent ordered actual eager calls missing')
    require(record['selected_blocks']==reference['selected_blocks']
            and torch.equal(record['padded_output'],reference['reference'])
            and record['identity']['generation']==reference['generation']
            and record['identity']['epoch']==reference['epoch'], 'extra reference not the actual original completed sample')
    require(record['valid']==reference['valid']
            and record['canonical_table'].tolist()==reference['canonical_table']
            and torch.equal(record['full_slots'],reference['reference_inputs']['slot_mapping'])
            and torch.equal(record['original_query_layout'],reference['reference_inputs']['query_start_loc'])
            and set(record['inputs'])=={'input_ids','positions'}
            and all(torch.equal(value,reference['reference_inputs'][key]) for key,value in record['inputs'].items())
            and record['actual_group']==reference['runtime_identity']['global_group_id'],
            'canonical prestate or Full input identity differs')
    keys=set(reference['reference_pre_kv'])
    require(len(keys)==10 and all(set(record[field])==keys for field in (
        'pre_kv','restored_pre_kv','padded_post_kv','unpadded_post_kv','final_restored_kv')),
        'complete five-layer K/V coverage required')
    for key in record['pre_kv']:
        require(torch.equal(record['pre_kv'][key],record['restored_pre_kv'][key])
                and torch.equal(record['pre_kv'][key],reference['reference_pre_kv'][key])
                and torch.equal(record['padded_post_kv'][key],reference['reference_post_kv'][key])
                and torch.equal(record['padded_post_kv'][key],record['final_restored_kv'][key]),
                'reference prestate or restoration association failed')
    a,c=record['padded_output'][:8],record['unpadded_output']
    require(list(a.shape)==list(c.shape)==[8,6144] and a.dtype==c.dtype==torch.bfloat16,
            'actual GLM hidden output geometry differs')
    layers={key.rsplit('/',1)[0] for key in keys}
    require(set(record['unpadded_metadata'])==set(record['padded_metadata'])==layers,
            'complete actual metadata layers required')
    for name,m in record['unpadded_metadata'].items():
        old=record['padded_metadata'][name]
        require(m['causal'] is old['causal'] is False and m['actual_seq_lengths_q']==[8]
                and m['seq_lens_list']==old['seq_lens_list'][:1]
                and torch.equal(m['block_tables'],old['block_tables'][:1])
                and torch.equal(m['seq_lens'],old['seq_lens'][:1])
                and torch.equal(m['slot_mapping'],record['full_slots'][:8]),
                'actual eager assembler changed Window reads or Full writes')
        require(m['num_actual_tokens']==8 and m['num_prefills']==0 and m['num_decodes']==1
                and torch.equal(m['seq_lens_cpu'],torch.tensor(m['seq_lens_list'],dtype=torch.int32))
                and m['query_start_loc'].tolist()==[0,8], 'actual single-row eager layout differs')
        for key in ('block_tables','seq_lens','seq_lens_cpu','slot_mapping','query_start_loc'):
            value,header=m[key],m[key+'_header']
            require(value.dtype==torch.int32 and header['shape']==list(value.shape)
                    and header['dtype']==str(value.dtype) and type(header['data_ptr']) is int
                    and header['data_ptr']>0 and type(header['storage_offset']) is int
                    and header['storage_offset']>=0 and len(header['stride'])==value.ndim,
                    'actual eager tensor header/dtype contradicts its saved value')
    changed=[]
    finite=bool(torch.isfinite(a).all() and torch.isfinite(c).all())
    for key,padded in record['padded_post_kv'].items():
        unpadded=record['unpadded_post_kv'][key]
        require(padded.shape==unpadded.shape and padded.dtype==unpadded.dtype==torch.bfloat16,
                'K/V geometry differs across calls')
        require(list(padded.shape)==[len(record['selected_blocks']),128,4,192], 'rank-local K/V layout differs')
        finite=finite and bool(torch.isfinite(unpadded).all())
        for i,block in enumerate(record['selected_blocks']):
            count=int(torch.count_nonzero(padded[i]!=unpadded[i]))
            if count:changed.append(dict(layer_component=key,physical_block=block,different_elements=count))
    equal=bool(torch.equal(a,c)) and not changed
    return dict(identity=record['identity'],status='PASS' if equal and finite else 'FAIL',finite=finite,
        hidden_different_elements=int(torch.count_nonzero(a!=c)),changed_blocks=changed,atol=0.0,rtol=0.0)


def check_payload(path,payload,worker):
    result=cp_check_payload(path,payload,worker)
    root=Path(path).parent
    parent=json.loads((Path(payload['output'])/'parent-execution.json').read_text())
    response=next(row for row in parent['rpc_results'] if row['rank']==worker['rank'])
    artifact=root/'eager-padding/collection.json'
    require(response['padding_artifact']==dict(path=str(artifact),sha256=digest(artifact),bytes=artifact.stat().st_size),
            'extra padding collection differs from actual worker RPC response')
    extra=CollectionReader(artifact);original=CollectionReader(root/'numeric-reference.json');h=extra.header
    require(extra.execution=='COMPLETE' and len(extra.samples)==len(original.samples)==3
            and h['contrast']==CONTRAST and h['source_sha']==payload['source_sha']
            and h['source_tree']==payload['source_tree'] and h['nonce']==payload['nonce']
            and h['pid']==worker['pid'] and h['rank']==worker['rank']
            and h['process_start_ticks']==worker['process_start_ticks']
            and h['tool']==dict(path=__file__,sha256=digest(__file__)), 'extra padding rank/source association failed')
    pairs=[]
    for i in range(3):
        record=extra.record(i)
        method=record['actual_eager_method'];method_path=Path(__file__).resolve().parents[1]/'vllm_ascend/worker/v2/spec_decode/dspark/speculator.py'
        require(method==dict(module='vllm_ascend.worker.v2.spec_decode.dspark.speculator',
            qualname='AscendDSparkSpeculator._run_model',path=str(method_path),sha256=digest(method_path)),
            'actual eager method is not this loaded production source')
        pairs.append(check_contrast(record,original.record(i)))
    result['eager_padding_contrast']=dict(status='PASS' if all(p['status']=='PASS' and p['finite'] for p in pairs) else 'FAIL',pairs=pairs)
    return result


def check_external(planned,execution):
    result=common_check(planned,execution,profile=PROFILE,kwargs_factory=build_kwargs,
        model_contract_factory=model_contract,fixture_validator=validate_fixture,payload_checker=check_payload,
        extra_worker_validator=validate_worker,allow_external_only=True)
    if result['status']=='PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC':
        result['original_graph_reference_status']=result['status']
        result['status']=(ACCEPTED if all(c['eager_padding_contrast']['status']=='PASS' for c in result['checks'])
                          else 'FAIL_VALID_EVIDENCE_EAGER_PADDING_CONTRAST')
    result.update(padding_tool_sha256=digest(__file__),scope='Original CP Graph/eager16 oracle plus separate actual eager8/16 same-prestate contrast; no natural trajectory waiver',
                  physical_read='NOT_OBSERVED',normal_overlap='NOT_PROVEN')
    return result


def main():
    args=build_parser().parse_args()
    if args.command=='check':
        torch.set_num_threads(2);result=check_external(args.planned,args.execution);write(args.output,result)
        return 0 if result['status']==ACCEPTED else 4
    require(args.command=='run' and args.tp==16 and args.arm=='ON' and args.repair6_target_prefix==3,
            'only one declared TP16 Window ON padding prefix; no full campaign or OFF arm')
    return run_controlled(args,profile=PROFILE,kwargs_factory=build_kwargs,
        model_contract_factory=model_contract,fixture_validator=validate_fixture,payload_checker=check_payload,
        extra_worker_validator=validate_worker,producer_path=__file__,defer_payload_validation=args.external_payload_check_only)


if __name__=='__main__':
    raise SystemExit(main())
