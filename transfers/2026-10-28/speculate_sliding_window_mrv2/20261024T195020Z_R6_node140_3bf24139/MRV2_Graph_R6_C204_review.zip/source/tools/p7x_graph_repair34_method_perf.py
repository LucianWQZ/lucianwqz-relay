# SPDX-License-Identifier: Apache-2.0
"""Independent normal method performance profiles, preserving old anchors.

Each method retains its real K/query/causal/model contract. Six balanced repeats
are normal controls; a separate optional profiler arm never counts as a repeat.
No continuous reference, Target dump, LIFE drain or native verbose sink is used.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace, MappingProxyType

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair21_rank import digest, require, validate_admission, write
from tools.p7x_graph_repair27_balanced_perf import ORDERS

METHODS = MappingProxyType(dict(
    dflash=MappingProxyType(dict(k=15, first_query=16, ar_query=None, ar_consumers=0, causal=False)),
    eagle3=MappingProxyType(dict(k=3, first_query=4, ar_query=1, ar_consumers=2, causal=True)),
    dspark_q8=MappingProxyType(dict(k=7, first_query=8, ar_query=None, ar_consumers=0,
                                  causal=False, sample_from_anchor=False, sample_offset=1))))


def dspark_q8_configuration(args):
    """Reuse the existing owned no-anchor model view, never patch shared weights."""
    from tools.p7x_graph_repair2 import build_llm_kwargs, parse_args
    from tools.p7x_graph_repair17_dspark_q8 import validate_model_view
    require(digest(args.fixture)==args.fixture_sha256, 'immutable Q8 fixture changed')
    fixture=json.loads(args.fixture.read_text())
    validate_model_view(fixture)
    base=parse_args(['run','--case',args.case,'--case-id',args.case_id,'--run-id',args.run_id,
                    '--attempt',args.attempt,'--expected-sha',args.expected_sha,
                    '--target-model',fixture['target_model'],'--draft-model',fixture['draft_model'],
                    '--vllm-repo',str(args.vllm_repo),'--fixture-manifest',str(args.fixture),
                    '--output',str(args.output),'--repair5-capture-profile','dspark_k7_noanchor_q8'])
    kwargs=build_llm_kwargs(base)
    kwargs['per_request_spec_decode_metrics']='detailed'
    kwargs['speculative_config']['enforce_eager']=args.arm=='E_ON'
    return base,fixture,kwargs


def capacity(config, maximum):
    nested=config.get("transformer_layer_config")
    parts=[config]+([nested] if isinstance(nested,dict) else [])
    limits=[p["max_position_embeddings"] for p in parts if p.get("max_position_embeddings") is not None]
    require(limits and all(type(n) is int and n>=maximum for n in limits), "native model position capacity exceeded")
    require(all(p.get("rope_scaling") is None and (p.get("rope_parameters") or {}).get("rope_type","default")=="default"
                for p in parts), "performance profile cannot invent RoPE extension")


def validate_cell(method,arm,maximum,entries,repeat,position,profile,*,pinned_pair_variant=None,
                  native_long_context_review=False):
    require(method in METHODS and arm in ("G_OFF","G_ON","E_ON"), "named independent method/arm required")
    require(type(native_long_context_review) is bool, "explicit native long-context review policy")
    require(type(maximum) is int and maximum in ((40960,) if native_long_context_review else (4096,24576)),
            "bounded native short/long profile; 40960 requires the named review policy")
    require(type(profile) is bool, "explicit boolean profiler flag")
    if pinned_pair_variant is not None:
        require(type(pinned_pair_variant) is str and pinned_pair_variant in ('BASE','OWNED')
                and method=='eagle3' and arm=='G_ON', "owned pinned pair requires actual Eagle Graph/Window ON")
    if profile:
        require(type(repeat) is int and type(position) is int and repeat==0 and position==0, "profiler arm is separate from balanced controls")
    elif pinned_pair_variant is not None:
        require(type(repeat) is int and type(position) is int and 1<=repeat<=6 and 1<=position<=2,
                "six-repetition pair needs actual 1/2 order position")
        order=('BASE','OWNED') if repeat%2 else ('OWNED','BASE')
        require(order[position-1]==pinned_pair_variant, "actual BASE/OWNED balanced pair order mismatch")
    else:
        require(type(repeat) is int and 1<=repeat<=6 and type(position) is int and 1<=position<=3
                and ORDERS[repeat-1][position-1]==arm, "six-repetition balanced arm order mismatch")
    require(len(entries)==1 and type(entries[0]["max_tokens"]) is int and entries[0]["max_tokens"] in (256,512),
            "one independently reported bounded workload per cell")
    group=entries[0];require(1<=len(group["prompts"])<=4, "only declared captured request capacity")
    if native_long_context_review:
        require(pinned_pair_variant is None and len(group['prompts'])==1 and group['max_tokens']==512,
                "native long review is one independent fixed-budget workload, not a staging pair")
    for prompt in group["prompts"]:
        ids=prompt["prompt_token_ids"]
        require(isinstance(ids,list) and ids and all(type(t) is int and t>=0 for t in ids)
                and len(ids)+group["max_tokens"]<=maximum, "fixed input IDs/length outside native profile")
        if native_long_context_review:
            require(32000<=len(ids)<=32769, "named native long workload requires its approximately32K input")
    return METHODS[method].copy()


class RequestIdCapture:
    """Observe the real input processor's assignment; no suffix guessing.

    The instance hook is outside worker execution. It calls the original
    function once and reads the assigned Host request fields only.
    """
    def __init__(self, processor):
        import inspect
        self.processor=processor
        self.original=processor.assign_request_id
        self.had_attribute='assign_request_id' in vars(processor)
        self.saved=vars(processor).get('assign_request_id')
        self.active=False;self.rows=[]
        source=Path(inspect.getfile(type(processor))).resolve()
        self.source=dict(class_path=type(processor).__module__+'.'+type(processor).__qualname__,
                         path=str(source),sha256=digest(source))
        def observe(request):
            result=self.original(request)
            if self.active:
                self.rows.append(dict(external_id=request.external_req_id,internal_id=request.request_id,
                                      assigned_ns=time.monotonic_ns()))
            return result
        self.hook=observe;processor.assign_request_id=observe

    def begin(self):
        self.rows=[];self.active=True

    def finish(self):
        self.active=False
        return dict(scope='ACTUAL_INPUT_PROCESSOR_ASSIGNMENT_HOST',source=self.source,rows=list(self.rows))

    def restore(self):
        self.active=False
        if self.processor.assign_request_id is not self.hook:
            return False
        if self.had_attribute:self.processor.assign_request_id=self.saved
        else:del self.processor.assign_request_id
        return True


def validate_window_history(profile,output,*,arm,pin):
    """Whole measured request group, not its last remaining request alone."""
    mapping=output['request_id_mapping']
    require(mapping['scope']=='ACTUAL_INPUT_PROCESSOR_ASSIGNMENT_HOST', 'request assignment scope differs')
    source=mapping['source'];path=Path(pin)/'vllm/v1/engine/input_processor.py'
    require(source['class_path']=='vllm.v1.engine.input_processor.InputProcessor'
            and Path(source['path']).resolve()==path.resolve() and source['sha256']==digest(path),
            'actual pinned input assignment source differs')
    rows=mapping['rows'];external=[x['request_id'] for x in output['metrics']]
    require(len(rows)==len(external) and all(type(r['external_id']) is str and r['external_id']
            and type(r['internal_id']) is str and r['internal_id']
            and type(r['assigned_ns']) is int and output['start_ns']<=r['assigned_ns']<=output['end_ns']
            for r in rows), 'actual request assignment/time coverage differs')
    require(len(set(external))==len(external) and {r['external_id'] for r in rows}==set(external)
            and len({r['internal_id'] for r in rows})==len(rows), 'request IDs missing, duplicated or crossed')
    internal={r['internal_id'] for r in rows}
    history=[c for c in profile['calls'] if c.get('active') is True
             and c['label']=='Draft_retire_host' and c.get('request_group')==output['label']]
    if arm=='G_OFF':
        require(not history, 'Window OFF unexpectedly retired Window state')
        return dict(clipped=False,retired_host_generations=0,request_ids=sorted(internal),
                    scope='WINDOW_OFF_NO_WINDOW_RETIREMENT_EXPECTED')
    require(history, 'measured request group has no actual Window history')
    observed=set();shapes=set();max_start=0;seen=set()
    for call in history:
        require(type(call['start_ns']) is int and type(call['end_ns']) is int
            and output['start_ns']<=call['start_ns']<call['end_ns']<=output['end_ns']
            and call['window_scope']=='ACTUAL_RETIRED_HOST_IDENTITY_NOT_DEVICE_COMPLETION_OR_OPERAND',
            'retirement outside measured interval or scope changed')
        require(type(call['generation']) is int and call['generation']>=0
            and type(call['mapping_epoch']) is int and call['mapping_epoch']>=0,
            'untyped generation/epoch')
        n,p=call['window_active'],call['window_padded'];ids=call['window_request_ids'];desc=call['window_read_descriptors']
        require(type(n) is int and type(p) is int and 0<n<=p<=4 and len(ids)==len(set(ids))==len(desc)==n
            and all(type(request) is str and request in internal for request in ids),
            'actual active/padded/request descriptor coverage differs')
        observed.update(ids);shapes.add((n,p));seen.add((call['generation'],call['mapping_epoch']))
        for d in desc:
            require(set(d)=={'global_group_id','source_start_column','first_token_offset','required_columns',
                             'safe_extent_tokens','valid_num_blocks','source_row_width'}
                and all(type(v) is int and v>=0 for v in d.values())
                and d['global_group_id']==0 and d['first_token_offset']<128
                and d['source_start_column']+d['required_columns']<=d['valid_num_blocks']<=d['source_row_width'],
                'read descriptor geometry/type invalid')
            max_start=max(max_start,d['source_start_column']*128+d['first_token_offset'])
    require(observed==internal,'some completed requests have no measured Window generation')
    return dict(clipped=max_start>0,max_window_start=max_start,retired_host_generations=len(history),
                distinct_generation_epochs=len(seen),active_padded=sorted(map(list,shapes)),request_ids=sorted(observed),
                scope='MEASURED_HOST_RETIRED_MATERIALIZED_IDENTITIES_NOT_COMPLETION_EXECUTION_OPERAND_OR_PHYSICAL_READ')


def configuration(args):
    require(args.method in METHODS and args.arm in ("G_OFF","G_ON","E_ON"), "explicit method configuration required")
    require(type(getattr(args,'window_history',False)) is bool, 'explicit Window history bool required')
    pinned_h2d = getattr(args, 'eagle3_pinned_h2d_review', False)
    require(type(pinned_h2d) is bool and (not pinned_h2d or (args.method == 'eagle3' and args.arm == 'G_ON')),
            'pinned H2D review requires its explicit Eagle Graph/Window ON cell')
    variant=getattr(args,'pinned_pair_variant',None)
    if variant is not None:
        require(type(variant) is str and variant in ('BASE','OWNED') and args.method=='eagle3' and args.arm=='G_ON'
                and pinned_h2d is (variant=='OWNED'), "pair variant and actual staging policy differ")
    long_review=getattr(args,'native_long_context_review',False)
    require(type(long_review) is bool and type(args.max_model_len) is int
            and args.max_model_len in ((40960,) if long_review else (4096,24576))
            and long_review is (args.max_model_len==40960)
            and (not long_review or not pinned_h2d),
            "native long review must retain its own capacity and default copy policy")
    fields=dict(fixture=args.fixture,fixture_sha256=args.fixture_sha256,expected_sha=args.expected_sha,
                vllm_repo=args.vllm_repo,output=args.output,arm=args.arm,case="A0" if args.arm=="G_OFF" else "B-observer-off",
                run_id=args.run_id,case_id=args.case_id,attempt="1",eagle3_target=False,eagle3_numeric=False,
                eagle3_life=False,eagle3_unwind=None,scheduler_phases=False,eagle3_padding_repro=False,
                eagle3_pinned_h2d_review=pinned_h2d)
    if args.method=="dflash":
        from tools.p7x_graph_repair11_method_anchor import configuration as legacy
        base,kwargs=legacy(SimpleNamespace(**fields));fixture=json.loads(args.fixture.read_text())
        require(fixture["schema"]=="r4-dflash-k15-q16-fixture-v1", "frozen DFlash fixture required")
    elif args.method=='eagle3':
        from tools.p7x_graph_repair13_eagle import configuration as legacy
        base,fixture,kwargs=legacy(SimpleNamespace(**fields))
    else:
        base,fixture,kwargs=dspark_q8_configuration(SimpleNamespace(**fields))
    for model in (kwargs["model"],kwargs["speculative_config"]["model"]):
        capacity(json.loads((Path(model)/"config.json").read_text()),args.max_model_len)
    kwargs["max_model_len"]=args.max_model_len
    expected_additional = {} if args.arm == "G_OFF" else dict(draft_window_size=1024)
    if pinned_h2d:
        expected_additional['draft_window_graph_eagle_pinned_h2d_review'] = True
    require(kwargs["enforce_eager"] is False and kwargs["speculative_config"]["enforce_eager"] is (args.arm=="E_ON")
            and kwargs["speculative_config"]["num_speculative_tokens"]==METHODS[args.method]["k"]
            and kwargs["compilation_config"]["cudagraph_mode"]=="FULL_DECODE_ONLY"
            and kwargs["additional_config"]==expected_additional,
            "normal profile cannot change method or install heavy diagnostics")
    return base,fixture,kwargs


def acceptance(method,metrics):
    require(metrics is not None, "framework detailed acceptance metrics unavailable")
    require(all(type(metrics[k]) is int and metrics[k]>=0 for k in
                ('num_spec_tokens','num_draft_tokens','num_accepted_draft_tokens','num_spec_steps'))
            and all(type(n) is int and n>=0 for n in metrics['acceptance_histogram']),
            "framework counters/histogram must retain integer ownership")
    if method=="dflash":
        from tools.p7x_graph_repair11_method_anchor import validate_counts
        checked=validate_counts(metrics)
    elif method=='eagle3':
        from tools.p7x_graph_repair13_eagle import counts
        checked=counts(metrics)
    else:
        from tools.p7x_graph_repair10_performance import acceptance_counts
        values=acceptance_counts(metrics)
        checked=dict(proposed=values['proposed_draft_tokens'],accepted=values['accepted_draft_tokens'],
                     verification_request_steps=values['verification_request_steps'])
    k=METHODS[method]["k"];drafted=metrics["per_step_drafted"];accepted=metrics["per_step_accepted"]
    checked.update(rate=checked["accepted"]/checked["proposed"],
                   mean_acceptance_length_including_bonus=1+checked["accepted"]/checked["verification_request_steps"],
                   proposed_per_position=[sum(n>i for n in drafted) for i in range(k)],
                   accepted_per_position=[sum(n>i for n in accepted) for i in range(k)],
                   denominator="Scheduled per-request proposals after grammar adjustment; accepted from sampler before stop/length trimming; bonus and padding excluded; never infer emitted acceptance from output count")
    return checked



def isolating_profiler_type():
    from tools.p7x_graph_repair5_profile import RequestProfiler

    class IsolatingRequestProfiler(RequestProfiler):
        def __exit__(self,*exc):
            if exc[0] is None:
                return super().__exit__(*exc)
            # Unknown failed native submission: preserve the collector object
            # for immediate process isolation. Do not stop/drain it or trigger
            # a destructor by dropping its last reference during unwinding.
            self._unclosed_profiler_after_error=self.profiler
            self.profiler=None
            self.native_cleanup_skipped_after_error=True
            try:
                super().__exit__(*exc)  # Host wrapper restore/export only.
            except BaseException as export_error:
                self.host_export_error=repr(export_error)
            return False  # Preserve the original forward/config/storage error.

    return IsolatingRequestProfiler


def normal_observation_state(spec):
    """Respect the distinct parallel/Eagle session ownership contracts.

    Eagle3GraphSession has a provider/controller, not a parallel recorder.
    Observation OFF must leave the safety provider installed and have no
    tensor snapshot sink or source observer. This is Host state only.
    """
    parallel = getattr(spec, "_draft_window_graph_characterization", None)
    eagle = getattr(spec, "_eagle3_graph_session", None)
    require(parallel is None or eagle is None, "one method cannot own both session kinds")
    session = parallel if parallel is not None else eagle
    if session is None:
        return dict(provider_installed=False, heavy_observer_enabled=False, session_kind="NONE")
    provider = getattr(spec, "_draft_window_graph_binding_provider", None)
    require(session.owner is spec and session.provider is provider and provider is not None,
            "normal observer-off session lost its method-owned safety provider")
    require(provider.observer is None, "normal measurement cannot install a source observer")
    if parallel is not None:
        require(parallel.recorder.enabled is False, "normal performance requires parallel recorder OFF")
    else:
        require(eagle.numeric_snapshots is None, "normal Eagle performance cannot install tensor snapshots")
    return dict(provider_installed=True, heavy_observer_enabled=False,
                session_kind="PARALLEL" if parallel is not None else "EAGLE3")


def run(args):
    source=Path(__file__).resolve().parents[1]
    receipt=validate_admission(args.admission,source=source,sha=args.expected_sha,tp=1)
    require(not args.output.exists(), "new normal method performance attempt required")
    entries=json.loads(args.requests.read_text())
    contract=validate_cell(args.method,args.arm,args.max_model_len,entries,args.repetition,args.order_position,args.profile,
                           pinned_pair_variant=getattr(args,'pinned_pair_variant',None),
                           native_long_context_review=getattr(args,'native_long_context_review',False))
    base,fixture,kwargs=configuration(args)
    from tools.p7x_graph_repair12_contract import verify_fixture_receipt
    verify_fixture_receipt(SimpleNamespace(repair12_fixture_verification=args.fixture_receipt,
        repair12_fixture_verification_sha256=args.fixture_receipt_sha256,expected_sha=args.expected_sha,
        fixture_manifest=args.fixture),fixture)
    from tools.p7x_graph_repair2 import configure_run_environment, _manager_inventory
    configure_run_environment(base,args.output)
    import torch_npu  # noqa:F401
    import vllm_ascend.ops  # noqa:F401
    import vllm_ascend.worker.v2.spec_decode  # noqa:F401
    from vllm import LLM,SamplingParams
    from tools.p7x_graph_repair5_profile import warmup_requests
    from tools.p7x_graph_repair10_performance import final_window_state,request_metrics
    args.output.mkdir(parents=True,exist_ok=True)
    identity=dict(run_id=args.run_id,case_id=args.case_id,attempt_id="1",source_sha=args.expected_sha,
                  source_tree=receipt["source_tree"],process_id=os.getpid(),driver_mode=base.case,engine_id=None)
    record=dict(identity=identity,method=args.method,method_contract=contract,arm=args.arm,status="STARTING",
                script_sha256=digest(__file__),fixture_sha256=digest(args.fixture),requests_sha256=digest(args.requests),
                requests=entries,llm_kwargs=kwargs,config_sha256=hashlib.sha256(json.dumps(kwargs,sort_keys=True).encode()).hexdigest(),
                repetition=args.repetition,order_position=args.order_position,profile=args.profile,outputs=[],
                pinned_pair_variant=getattr(args,'pinned_pair_variant',None),
                native_long_context_review=getattr(args,'native_long_context_review',False),
                timing_scope="PROFILED_REQUEST_STAGE_ONLY" if args.profile else "NORMAL_CONTROL_NO_REFERENCE_LIFE_SYNC_OR_PROFILER",
                normal_completion="NOT_INFERRED_FROM_HOST_RETURN",physical_read="NOT_PROVEN",
                window_history_enabled=getattr(args,'window_history',False))
    llm=spec=probe=id_capture=None;write(args.output/'campaign.json',record)
    try:
        llm=LLM(**kwargs);core=llm.llm_engine.engine_core.engine_core
        runner=core.model_executor.driver_worker.worker.model_runner;spec=runner.speculator;identity['engine_id']=id(core)
        if record['window_history_enabled']:
            id_capture=RequestIdCapture(llm.llm_engine.input_processor)
        require(spec.num_speculative_steps==contract['k'], "actual factory K differs")
        if args.method=='dflash':
            require(type(spec).__name__=='AscendDFlashSpeculator' and spec.num_query_per_req==16, "actual DFlash factory/query")
            inventory=dict(draft=_manager_inventory(spec.query_cudagraph_manager))
        elif args.method=='eagle3':
            require(type(spec).__name__=='AscendEagleSpeculator', "actual Eagle factory")
            inventory=dict(first=_manager_inventory(spec.prefill_cudagraph_manager),ar=_manager_inventory(spec.decode_cudagraph_manager))
        else:
            from tools.p7x_graph_repair12_contract import method_for_profile
            parallel_contract=method_for_profile('dspark_k7_noanchor_q8')
            require(type(spec).__name__=='AscendDSparkSpeculator', 'actual Q8 DSpark factory')
            parallel_contract.validate_owner(spec)
            record['runtime_parallel_contract']=dict(contract=parallel_contract.document(),
                actual_query=spec.num_query_per_req,actual_sample_from_anchor=spec.sample_from_anchor)
            inventory=dict(draft=_manager_inventory(spec.query_cudagraph_manager))
        observation = normal_observation_state(spec)
        provider = observation["provider_installed"]
        require(args.arm!='G_ON' or provider, "Graph ON requires actual observer-off safety provider")
        record.update(startup_complete=True,speculator=type(spec).__module__+'.'+type(spec).__name__,
                      speculator_python_source=sys.modules[type(spec).__module__].__file__,
                      runner_python_source=sys.modules[type(runner).__module__].__file__,inventory=inventory,
                      target_inventory=_manager_inventory(runner.cudagraph_manager),heavy_observer_enabled=False,
                      window_provider_installed=provider, normal_observation_state=observation)
        write(args.output/'campaign.json',record)
        with isolating_profiler_type()(runner,args.output,identity,enabled=args.profile,materialize_ranges=args.profile,
                                      window_history=record['window_history_enabled']) as probe:
            record['warmup']=warmup_requests(llm,SamplingParams,entries,probe,all_groups=True)
            probe.begin_active()
            for entry in entries:
                if id_capture is not None:id_capture.begin()
                start=time.monotonic_ns()
                with probe.group(entry['label']):
                    outputs=llm.generate(entry['prompts'],SamplingParams(temperature=0,seed=0,ignore_eos=True,
                        min_tokens=entry['max_tokens'],max_tokens=entry['max_tokens']),use_tqdm=False)
                end=time.monotonic_ns()
                record['outputs'].append(dict(label=entry['label'],start_ns=start,end_ns=end,
                    actual_input_ids=[o.prompt_token_ids for o in outputs],token_ids=[list(o.outputs[0].token_ids) for o in outputs],
                    finished=[o.finished for o in outputs],metrics=request_metrics(outputs),window_identity=final_window_state(spec),
                    request_id_mapping=id_capture.finish() if id_capture is not None else None))
                write(args.output/'campaign.json',record)
        record['status']='REQUESTS_COMPLETED'
    except BaseException as error:
        import traceback
        record.update(status='EXCEPTION',exception_type=type(error).__name__,exception_message=str(error),traceback=traceback.format_exc())
    finally:
        record['request_id_capture_restored']=id_capture.restore() if id_capture is not None else True
        if not record['request_id_capture_restored']:record['cleanup_error']='Host request ID observation hook replaced unexpectedly'
        from tools.p7x_graph_repair13_eagle import pinned_h2d_state
        record['pinned_h2d_staging'] = pinned_h2d_state(spec)
        record['profile_native_cleanup_skipped_after_error']=bool(getattr(probe,'native_cleanup_skipped_after_error',False))
        record['profile_host_export_error']=getattr(probe,'host_export_error',None)
        record['profile_native_cleanup_failed']=bool(getattr(probe,'native_cleanup_failed',False))
        record['graph_submission_uncertain']=bool(getattr(spec,'_draft_window_graph_submission_uncertain',False))
        record['method_isolation_required']=record['status']!='REQUESTS_COMPLETED'
        write(args.output/'campaign.json',record)
        if record['graph_submission_uncertain'] or record['method_isolation_required']:
            os._exit(74)
        if llm is not None:
            try:llm.llm_engine.engine_core.shutdown()
            except Exception as error:record['cleanup_error']=repr(error);write(args.output/'campaign.json',record)
    return 0 if not record.get('cleanup_error') else 2



def check_artifacts(campaign,profile,args):
    entries=json.loads(args.requests.read_text())
    history=getattr(args,'window_history',False)
    require(type(history) is bool and campaign.get('window_history_enabled',False) is history
            and profile.get('window_history_enabled',False) is history,
            'request Window history observation differs from actual declaration')
    if history:require(campaign['request_id_capture_restored'] is True,'Host request assignment hook not restored')
    contract=validate_cell(args.method,args.arm,args.max_model_len,entries,args.repetition,args.order_position,args.profile,
                           pinned_pair_variant=getattr(args,'pinned_pair_variant',None),
                           native_long_context_review=getattr(args,'native_long_context_review',False))
    _,fixture,kwargs=configuration(args)
    staging = getattr(args, 'eagle3_pinned_h2d_review', False)
    from tools.p7x_graph_repair13_eagle import validate_pinned_h2d_state
    validate_pinned_h2d_state(campaign.get('pinned_h2d_staging'), staging)
    variant=getattr(args,'pinned_pair_variant',None)
    long_review=getattr(args,'native_long_context_review',False)
    require(type(campaign.get('native_long_context_review',False)) is bool
            and campaign.get('native_long_context_review',False) is long_review,
            "saved native long-context policy differs from actual command")
    require(campaign.get('pinned_pair_variant')==variant, "saved pair variant differs from actual command")
    if variant is not None:
        require(type(campaign.get('pinned_pair_variant')) is str
                and type(campaign.get('pinned_h2d_staging')) is dict,
                "paired controls require actual variant and workspace policy observation")
    require(campaign["status"]=="REQUESTS_COMPLETED" and campaign["startup_complete"] is True
            and not campaign["graph_submission_uncertain"] and not campaign["method_isolation_required"]
            and not campaign.get("cleanup_error"), "actual method request/cleanup did not complete")
    require(campaign["identity"]["source_sha"]==args.expected_sha and campaign["method"]==args.method
            and campaign["method_contract"]==contract and campaign["arm"]==args.arm
            and all(type(campaign['method_contract'][k]) is type(v) for k,v in contract.items())
            and campaign["requests_sha256"]==digest(args.requests) and campaign["requests"]==entries
            and campaign["fixture_sha256"]==digest(args.fixture) and campaign["llm_kwargs"]==kwargs
            and campaign["config_sha256"]==hashlib.sha256(json.dumps(kwargs,sort_keys=True).encode()).hexdigest()
            ==hashlib.sha256(json.dumps(campaign['llm_kwargs'],sort_keys=True).encode()).hexdigest(),
            "independent source/model/config/request contract differs")
    require(type(campaign['repetition']) is int and type(campaign['order_position']) is int
            and campaign["repetition"]==args.repetition and campaign["order_position"]==args.order_position
            and campaign["profile"] is args.profile and campaign["heavy_observer_enabled"] is False,
            "normal/profile/balanced repetition scope changed")
    require(profile["identity"]==campaign["identity"] and profile["python_worker_pid"]==campaign["identity"]["process_id"]
            and profile["profiler_enabled"] is args.profile and profile["detailed_diagnostic"] is False,
            "different actual worker/profile or heavy diagnostic configuration")
    require(profile["scope"]=="NORMAL_OBSERVER_OFF" and profile["counter_length_experiment"] is False,
            "normal performance cannot silently use serialized or counter experiments")
    source=Path(getattr(args,"producer_source",Path(__file__).resolve().parents[1]))
    owner,name={'eagle3':('eagle','AscendEagleSpeculator'),
                'dflash':('dflash','AscendDFlashSpeculator'),
                'dspark_q8':('dspark','AscendDSparkSpeculator')}[args.method]
    if args.method=='dspark_q8':
        from tools.p7x_graph_repair12_contract import method_for_profile,validate_method_document
        validate_method_document('dspark_k7_noanchor_q8',campaign['runtime_parallel_contract']['contract'])
        require(campaign['runtime_parallel_contract']==dict(
                    contract=method_for_profile('dspark_k7_noanchor_q8').document(),
                    actual_query=8,actual_sample_from_anchor=False)
                and campaign['runtime_parallel_contract']['actual_sample_from_anchor'] is False
                and type(campaign['runtime_parallel_contract']['actual_query']) is int,
                'actual DSpark Q8/query/sample offset contract differs')
        inventories=[campaign['target_inventory']]
        if args.arm!='E_ON':inventories.append(campaign['inventory']['draft'])
        for inventory in inventories:
            graphs=inventory['graphs']
            require(isinstance(graphs,list) and all(type(x['num_reqs']) is int and type(x['num_tokens']) is int
                        for x in graphs), 'actual Q8 capture inventory absent or untyped')
            require({(1,8),(2,16),(4,32)} <= {
                        (x['num_reqs'],x['num_tokens']) for x in graphs if x['mode']=='FULL'},
                    'actual Q8 Target/Draft capture buckets incomplete')
    require(campaign["speculator"]==f"vllm_ascend.worker.v2.spec_decode.{owner}.speculator.{name}"
            and Path(campaign["speculator_python_source"]).resolve()==source/"vllm_ascend/worker/v2/spec_decode"/owner/"speculator.py",
            "actual method worker imports another implementation")
    require(args.arm!='G_ON' or campaign["window_provider_installed"] is True,
            "observer-off Graph safety provider missing")
    require(campaign["normal_observation_state"] == dict(
                provider_installed=args.arm == "G_ON", heavy_observer_enabled=False,
                session_kind=("EAGLE3" if args.method == "eagle3" else "PARALLEL") if args.arm == "G_ON" else "NONE")
            and all(type(campaign['normal_observation_state'][k]) is bool
                    for k in ('provider_installed','heavy_observer_enabled')),
            "actual method session/observer-off ownership contract differs")
    require(campaign["warmup"]["policy"]=="ALL_DECLARED_GROUPS"
            and len(campaign["warmup"]["groups"])==len(entries), "complete declared warmup required")
    counts=[];output_tokens=0;elapsed=0;inputs=0;cropped=False;window_history=[]
    require(len(campaign["outputs"])==len(entries), "missing workload output")
    for warm,entry,output in zip(campaign["warmup"]["groups"],entries,campaign["outputs"]):
        require(warm["label"]==entry["label"] and warm["max_tokens"]==entry["max_tokens"]
                and len(warm["token_ids"])==len(entry["prompts"])
                and all(len(t)==entry["max_tokens"] for t in warm["token_ids"]), "warmup length/shape differs")
        require(output["label"]==entry["label"] and output["actual_input_ids"]==[p["prompt_token_ids"] for p in entry["prompts"]]
                and len(output["token_ids"])==len(output["metrics"])==len(output["finished"])==len(entry["prompts"])
                and all(x is True for x in output["finished"]), "actual inputs/request completion/cardinality")
        require(type(output["start_ns"]) is int and type(output["end_ns"]) is int
                and output["start_ns"]<output["end_ns"], "request clock scope")
        elapsed+=(output["end_ns"]-output["start_ns"])/1e9
        inputs+=sum(len(p["prompt_token_ids"]) for p in entry["prompts"])
        for tokens,metric in zip(output["token_ids"],output["metrics"]):
            require(len(tokens)==entry["max_tokens"] and all(type(t) is int and t>=0 for t in tokens)
                    and metric["finished"] is True, "actual measured output contract")
            output_tokens+=len(tokens);counts.append(acceptance(args.method,metric["speculative_decoding"]))
        if history:
            observed=validate_window_history(profile,output,arm=args.arm,pin=args.vllm_repo)
            window_history.append(dict(label=output['label'],**observed))
            cropped=cropped or observed['clipped']
        elif args.arm!='G_OFF':
            state=output["window_identity"]
            require(state is not None and state["active"]==len(entry["prompts"]), "actual current Window state required")
            cropped=cropped or any(x["source_start_column"]*128+x["first_token_offset"]>0 for x in state["read_descriptors"])
    if args.arm!='G_OFF' and any(len(p["prompt_token_ids"])>1024 for g in entries for p in g["prompts"]):
        require(cropped, "long request did not prove actual clipping")
    calls=[c for c in profile["calls"] if c["active"]]
    target=sum(c["label"]=="Target_REPLAY_SUBMIT" for c in calls)
    first=sum(c["label"]=="Draft_first_pass_REPLAY_SUBMIT" for c in calls)
    ar=sum(c["label"]=="Draft_AR_REPLAY_SUBMIT" for c in calls)
    parallel=sum(c["label"]=="Draft_REPLAY_SUBMIT" for c in calls)
    require(target>0, "actual Target Graph dispatch missing")
    if args.arm=='E_ON': require(first+ar+parallel==0, "same-Window eager arm replayed Draft Graph")
    elif args.method in ('dflash','dspark_q8'):require(parallel>0 and first+ar==0, "actual parallel method Graph dispatch missing")
    else:require(first>0 and ar>0 and parallel==0, "actual Eagle first/AR Graph dispatch missing")
    proposed=sum(x["proposed"] for x in counts);accepted=sum(x["accepted"] for x in counts);steps=sum(x["verification_request_steps"] for x in counts)
    return dict(status="PASS_SCOPED_NAMED_METHOD_PERFORMANCE_AND_ACCEPTANCE",method=args.method,arm=args.arm,
        pinned_pair_variant=variant,
        native_long_context_review=long_review,
        window_history=window_history if history else 'LEGACY_FINAL_IDENTITY_CONTRACT',
        input_tokens=inputs,output_tokens=output_tokens,elapsed_seconds=elapsed,output_tokens_per_second=output_tokens/elapsed,
        accepted=accepted,proposed=proposed,acceptance_rate=accepted/proposed,verification_request_steps=steps,
        mean_acceptance_length_including_bonus=1+accepted/steps,per_request_counts=counts,
        host_dispatch=dict(Target=target,Draft_parallel=parallel,Draft_first=first,Draft_AR=ar),clipped=cropped,
        measurement="PROFILED_NOT_NORMAL_CONTROL" if args.profile else "NORMAL_CONTROL_LIGHT_HOST_DISPATCH_WRAPPERS",
        ttft="NOT_AVAILABLE_OFFLINE_GROUP_API",tpot="NOT_AVAILABLE_OFFLINE_GROUP_API",itl="NOT_AVAILABLE_OFFLINE_GROUP_API",
        device_execution_occurrence="NOT_INFERRED_FROM_HOST_DISPATCH",normal_reuse="NOT_PROVEN",physical_read="NOT_PROVEN",
        scope="Raw artifact checks only; independent admission/source/process/device/time join required")


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--method',choices=tuple(METHODS),required=True)
    parser.add_argument('--arm',choices=('G_OFF','G_ON','E_ON'),required=True)
    for name in ('admission','fixture','fixture-receipt','requests','vllm-repo','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ('expected-sha','fixture-sha256','fixture-receipt-sha256','run-id','case-id'):
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--max-model-len',type=int,choices=(4096,24576,40960),required=True)
    parser.add_argument('--repetition',type=int,required=True);parser.add_argument('--order-position',type=int,required=True)
    parser.add_argument('--profile',action='store_true')
    parser.add_argument('--eagle3-pinned-h2d-review',action='store_true')
    parser.add_argument('--native-long-context-review',action='store_true',
                        help='separate approximately32K/one-request/512-output profile; both models must natively allow40960 with no RoPE extension')
    parser.add_argument('--window-history',action='store_true',
                        help='explicit Host-only measured retirement/request-assignment evidence for mixed/replaced requests; no extra device operation')
    parser.add_argument('--pinned-pair-variant',choices=('BASE','OWNED'),default=None,
                        help='separate same-Window BASE/OWNED experiment; order-position is the actual pair position')
    return run(parser.parse_args())


if __name__=='__main__':raise SystemExit(main())
