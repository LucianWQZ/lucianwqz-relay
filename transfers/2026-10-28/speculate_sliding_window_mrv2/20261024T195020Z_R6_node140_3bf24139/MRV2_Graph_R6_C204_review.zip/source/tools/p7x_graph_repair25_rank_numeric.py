# SPDX-License-Identifier: Apache-2.0
"""Explicit TP2/TP4/TP16 controlled diagnostics with real parent/RPC/worker joins.

This is not a serving or performance path. Ordinary diagnostic stream drains,
full KV snapshots, rank-local recorders and Host-only sample barriers are named.
No launcher PID is relabelled as a worker PID. Default TP1 tools retain guards.
"""
from __future__ import annotations

import argparse
import copy
from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack
from dataclasses import asdict, dataclass
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import socket
import sys
import time
import traceback
from types import SimpleNamespace

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair4_target import LiveTargetAdapter
from tools.p7x_graph_repair5_target import ControlledTarget, case_plan, draft_target_isolation_errors
from tools.p7x_graph_repair21_rank import RankWorkerExtension, build_rank_kwargs, digest, require, validate_admission, write

PROFILE = "target4"


@dataclass(frozen=True)
class RankContract:
    world_size: int
    rank: int
    nonce: str
    parent_pid: int
    source_sha: str

    def validate(self, parallel, actual_rank):
        require(type(self.world_size) is int and self.world_size in (2, 4, 16), "explicit complete TP2/4/16 diagnostic contract required")
        require(
            type(self.rank) is int and self.rank in range(self.world_size) and self.rank == actual_rank,
            "actual rank differs from diagnostic owner")
        require(
            type(parallel.tensor_parallel_size) is int and type(parallel.world_size) is int
            and parallel.tensor_parallel_size == parallel.world_size == self.world_size,
            "actual Target TP/world differs from complete rank set")
        require(
            all(
                type(getattr(parallel, key)) is int and getattr(parallel, key) == 1
                for key in ("data_parallel_size", "pipeline_parallel_size", "prefill_context_parallel_size",
                            "decode_context_parallel_size")), "rank diagnostic requires DP/PP/PCP/DCP1")
        require(len(self.nonce) == 32 and all(c in "0123456789abcdef" for c in self.nonce), "RPC nonce required")
        require(
            type(self.parent_pid) is int and self.parent_pid > 0 and len(self.source_sha) == 40,
            "parent/source identity required")


class RankTargetAdapter(LiveTargetAdapter):

    def __init__(self, runner, *, rank_contract, actual_rank, **kwargs):
        self.rank_contract, self.actual_rank = rank_contract, actual_rank
        super().__init__(runner, **kwargs)

    def _validate_topology(self, parallel):
        self.rank_contract.validate(parallel, self.actual_rank)
        spec = self.runner.speculator
        require(spec.speculative_config.draft_parallel_config.tensor_parallel_size == self.rank_contract.world_size,
                "actual Draft TP differs from Target TP")
        require(spec.method == "dspark", "this first rank diagnostic declares DSpark only")


def validate_barrier(rows, contract, step):
    require(
        len(rows) == contract.world_size and all(type(row["rank"]) is int for row in rows)
        and sorted(row["rank"] for row in rows) == list(range(contract.world_size)),
        "sample barrier missing or duplicate rank")
    require(
        all(row["nonce"] == contract.nonce and row["source_sha"] == contract.source_sha
            and row["world_size"] == contract.world_size and row["step"] == step
            for row in rows), "Host sample barrier identity mismatch")
    require(all(row["status"] == "COMPLETED_SAMPLE" and not row["submission_pending"] for row in rows),
            "peer sample failed or submission unknown; no next sample")


def host_sample_barrier(root, contract, step, *, status, pending, timeout=180):
    """Only Host files after each completed sample; never a device barrier."""
    root = Path(root)
    write(
        root / f"step-{step:03}-rank-{contract.rank}.json",
        dict(**asdict(contract),
             step=step,
             status=status,
             submission_pending=pending,
             pid=os.getpid(),
             at=time.time(),
             clock_domain="HOST_WALL_NOT_DEVICE"))
    if status != "COMPLETED_SAMPLE" or pending:
        raise RuntimeError("local sample failed/unknown; Host-only isolation")
    deadline = time.monotonic() + timeout
    paths = [root / f"step-{step:03}-rank-{rank}.json" for rank in range(contract.world_size)]
    while not all(path.is_file() for path in paths):
        if time.monotonic() >= deadline:
            raise TimeoutError("Host-only rank sample barrier timeout; no new device submission")
        time.sleep(0.1)
    validate_barrier([json.loads(path.read_text()) for path in paths], contract, step)


class RankControlledTarget(ControlledTarget):

    def __init__(self, *args, rank_contract, barrier_root, **kwargs):
        self.rank_contract, self.barrier_root, self._barriered = rank_contract, barrier_root, 0
        super().__init__(*args, **kwargs)

    def _save(self, result, output):
        super()._save(result, output)
        if len(self.records) <= self._barriered:
            return
        self._barriered = len(self.records)
        pending = bool(
            getattr(self.runner.speculator, "_draft_window_graph_submission_uncertain", False)
            or self.numeric_probe is not None and self.numeric_probe.submission.pending)
        host_sample_barrier(
            self.barrier_root,
            self.rank_contract,
            self._barriered,
            status="COMPLETED_SAMPLE" if self.records[-1]["status"] == "CAPTURED_COMPLETE" else "FAILED",
            pending=pending)


def build_diagnostic_kwargs(arm, tp=2):
    require(arm in ("ON", "OFF"), "explicit rank diagnostic arm required")
    kwargs = build_rank_kwargs(tp, window_on_review=arm == "ON")
    kwargs["worker_extension_cls"] = "tools.p7x_graph_repair25_rank_numeric.RankNumericWorker"
    kwargs["num_gpu_blocks_override"] = 256
    if arm == "ON":
        kwargs["additional_config"]["draft_window_graph_numeric_diagnostic"] = True
    return kwargs


def model_layer_contract(fixture, kwargs):
    manifest = json.loads(Path(fixture).read_text())
    configs = {}
    for role, model in (("target", kwargs["model"]), ("draft", kwargs["speculative_config"]["model"])):
        path = Path(model) / "config.json"
        entries = [row for row in manifest["files"] if Path(row["path"]) == path]
        require(len(entries) == 1 and digest(path) == entries[0]["sha256"], "actual model config not fixture verified")
        config = json.loads(path.read_text())
        count = config.get("num_hidden_layers")
        require(type(count) is int and count > 0, "actual model layer inventory not declared")
        heads, hidden, attention = config.get("num_key_value_heads"), config.get("hidden_size"), config.get("num_attention_heads")
        require(all(type(value) is int and value > 0 for value in (heads, hidden, attention))
                and hidden % attention == 0, "explicit dense model head geometry required")
        head_size = config.get("head_dim", hidden // attention)
        require(type(head_size) is int and head_size > 0, "explicit dense head dimension required")
        configs[role] = dict(path=str(path), sha256=digest(path), layers=count,
                             kv_heads=heads, head_size=head_size)
    return configs


def validate_rank_kv_geometry(worker, payload):
    """Validate real local cache geometry against independently hashed model config."""
    tp, config = payload["world_size"], payload["model_configs"]["draft"]
    heads = config["kv_heads"]
    require(type(heads) is int and heads > 0 and (heads % tp == 0 or tp % heads == 0),
            "dense KV head shard/replica topology is not integral")
    local_heads = max(1, heads // tp)
    layers = worker["draft_layers"]
    require(len(layers) == len(set(layers)) == config["layers"], "complete rank-local Draft layers required")
    require(set(worker["draft_backend"]) == set(layers)
            and all(value == "vllm_ascend.attention.attention_v1.AscendAttentionBackend"
                    for value in worker["draft_backend"].values()), "actual rank backend is not declared dense FIA")
    geometry = worker["draft_kv_geometry"]
    require(set(geometry) == {f"{layer}/{kind}" for layer in layers for kind in (0, 1)},
            "complete rank-local K/V geometry required")
    for entry in geometry.values():
        shape = entry["shape"]
        require(len(shape) == 4 and shape[0] > 0 and shape[1:] == [128, local_heads, config["head_size"]]
                and entry["dtype"] == "torch.bfloat16", "actual dense per-rank KV shard/replica geometry differs")


def validate_worker_set(rows, payload, source, vllm):
    tp = payload["world_size"]
    require(type(tp) is int and tp in (2, 4, 16), "explicit RPC complete world size required")
    require(
        len(rows) == tp and all(type(row["rank"]) is int for row in rows)
        and sorted(row["rank"] for row in rows) == list(range(tp)), "complete real declared worker set required")
    require(len({row["pid"] for row in rows}) == tp, "worker PID reused")
    for row in rows:
        RankContract(tp, row["rank"], payload["nonce"], payload["parent_pid"], payload["source_sha"]).validate(
            SimpleNamespace(tensor_parallel_size=row["tp_size"], world_size=row["world_size"], **row["parallel_sizes"]),
            row["rank"])
        require(
            row["ascend_source"] == str(Path(source) / "vllm_ascend/__init__.py")
            and row["vllm_source"] == str(Path(vllm) / "vllm/__init__.py"), "actual worker import mismatch")
        require(row["draft_tp_size"] == tp and row["draft_graph_inventory"] and row["target_graph_inventory"],
                "rank lacks actual Draft/Target capture")
        validate_rank_kv_geometry(row, payload)
        require(not row["submission_uncertain"] and row["process_start_ticks"], "rank unsafe or process unbound")
        require(row["nonce"] == payload["nonce"], "rank preflight RPC nonce mismatch")
        require(row["window_size"] == (1024 if payload["arm"] == "ON" else None),
                "effective rank Window differs from requested arm")
        require(
            bool(row["window_provider_installed"]) == (payload["arm"] == "ON") and not row["heavy_observer_enabled"],
            "preflight observer/provider policy mismatch")
        require(
            row["boot_id"] == payload["boot_id"] and row["mount_namespace"] == payload["mount_namespace"]
            and row["hostname"] == payload["hostname"], "worker host/boot/namespace mismatch")
        require(row["visible"] == payload["visible"] and row["logical_device"] == row["local_rank"] == row["rank"],
                "actual rank visibility/logical device mismatch")
    return True


def validate_runtime_overlay(path, source, sha, tree):
    manifest = json.loads(Path(path).read_text())
    require(manifest["source_sha"] == sha and manifest["source_tree"] == tree, "runtime source identity mismatch")
    for entry in manifest["overlay"]:
        target = Path(entry["target"])
        require(
            target == Path(source) / entry["relative_path"] and target.stat().st_size == entry["bytes"]
            and digest(target) == entry["sha256"], "runtime overlay changed")
    return dict(path=str(path), sha256=digest(path))


def install_rank_local_recorder(spec, output):
    """Wire the disabled rank-owned recorder before the first controlled scope.

    Global heavy observation stays off during capture. Enabling only the
    recorder flag later is insufficient: provider callbacks also need its exact
    observer owner. This private disposable diagnostic does not invent capture
    events or alter production stream ordering.
    """
    session = getattr(spec, "_draft_window_graph_characterization", None)
    require(session is not None and session.owner is spec, "rank recorder session owner mismatch")
    recorder, provider = session.recorder, session.provider
    runtime = spec._draft_window_runtime_state
    require(provider is spec._draft_window_graph_binding_provider
            and provider._runtime_state is runtime and recorder._provider is provider,
            "rank recorder/provider/runtime owner mismatch")
    require(not recorder.enabled and provider.observer is None, "rank recorder already active or observer occupied")
    require(runtime._active_inputs is None and runtime.metadata_store._entry is None
            and runtime.quarantined_identity is None
            and not getattr(spec, "_draft_window_graph_submission_uncertain", False),
            "rank recorder must attach before any active or quarantined proposal")
    path = Path(output) / "rank-characterization.json"
    require(path.parent.is_dir() and not path.exists(), "fresh rank artifact destination required")
    recorder._artifact_path = path
    provider._observer = recorder
    recorder.enabled = True
    return dict(provider_identity=id(provider), recorder_id=recorder.recorder_id,
                artifact=str(path), scope="POST_CAPTURE_PRE_CONTROLLED_PROPOSAL_RUNTIME_CALLBACKS_ONLY")


class RankNumericWorker(RankWorkerExtension):
    diagnostic_profile = PROFILE
    controlled_type = RankControlledTarget

    def _validate_method_owner(self, spec):
        require(spec.method == "dspark" and spec.sample_from_anchor is True and spec.num_query_per_req == 7,
                "actual DSpark K7/anchor/Q7 required")

    def _target_adapter(self, current, contract, **kwargs):
        return RankTargetAdapter(current, rank_contract=contract, actual_rank=self.rank, **kwargs)

    def mrv2_rank_numeric_preflight(self, payload):
        contract = RankContract(payload["world_size"], self.rank, payload["nonce"], payload["parent_pid"], payload["source_sha"])
        contract.validate(self.vllm_config.parallel_config, self.rank)
        require(not hasattr(self, "_rank_numeric_payload"), "rank diagnostic is one-shot per disposable engine")
        require(payload["scheduler_counts"] == dict(requests=0, running=0, waiting=0),
                "actual parent scheduler was not empty")
        require(payload["profile"] == self.diagnostic_profile and payload["arm"] in ("ON", "OFF"), "exact method/profile arm")
        spec = self.model_runner.speculator
        self._validate_method_owner(spec)
        require(payload["arm"] == "OFF" or hasattr(spec, "_draft_window_graph_binding_provider"),
                "Window ON lacks actual provider")
        self._rank_numeric_payload = dict(payload)
        row = self.mrv2_rank_snapshot()
        import torch
        import torch_npu
        row["runtime_versions"] = dict(python=sys.version,
                                       executable=sys.executable,
                                       torch=str(torch.__version__),
                                       torch_npu=str(torch_npu.__version__))
        runtime = json.loads(Path(payload["runtime_manifest"]["path"]).read_text())
        require(
            digest(payload["runtime_manifest"]["path"]) == payload["runtime_manifest"]["sha256"],
            "worker runtime manifest changed")
        overlay = {entry["target"]: entry for entry in runtime["overlay"]}
        local_native = [path for path in row["loaded_native"] if str(Path(__file__).resolve().parents[1]) in path]
        require(
            local_native and all(path in overlay and digest(path) == overlay[path]["sha256"] for path in local_native),
            "actual worker native extension differs from fixed runtime")
        row["loaded_native_hashes"] = [{"path": path, "sha256": digest(path)} for path in row["loaded_native"]]
        row.update(nonce=payload["nonce"],
                   boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                   mount_namespace=os.readlink('/proc/self/ns/mnt'),
                   parallel_sizes={
                       key: getattr(self.vllm_config.parallel_config, key)
                       for key in ("data_parallel_size", "pipeline_parallel_size", "prefill_context_parallel_size",
                                   "decode_context_parallel_size")
                   })
        return row

    def mrv2_rank_controlled(self, payload):
        require(payload == self._rank_numeric_payload, "RPC payload changed after complete worker preflight")
        import torch
        from tools.p7x_graph_repair6_numeric import ContinuousReference
        from tools.p7x_graph_repair6_storage import atomic_json
        runner, spec = self.model_runner, self.model_runner.speculator
        contract = RankContract(payload["world_size"], self.rank, payload["nonce"], payload["parent_pid"], payload["source_sha"])
        output = Path(payload["output"]) / f"rank-{self.rank}"
        require(not output.exists(), "new rank output required")
        output.mkdir(parents=True)
        identity = dict(run_id=payload["run_id"],
                        case_id=f"RANK_CONTROLLED_{payload['arm']}_{self.rank}",
                        attempt_id="1",
                        source_sha=payload["source_sha"],
                        source_tree=payload["source_tree"],
                        process_id=os.getpid(),
                        engine_id=payload["engine_id"],
                        driver_mode="RANK_RPC_DIAGNOSTIC")
        record = dict(identity=identity,
                      rank=self.rank,
                      rank_contract=asdict(contract),
                      payload=payload,
                      nonce=payload["nonce"],
                      started_at=time.time(),
                      worker_start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                      state="STARTING",
                      impact="SERIAL_REFERENCE_FULL_KV_D2H_HOST_BARRIER_NOT_PERFORMANCE",
                      observer_installation="RANK_LOCAL_AFTER_CAPTURE_NOT_SHARED_GLOBAL_OBSERVER")
        write(output / "rank-execution.json", record)
        numeric = controlled = None
        try:
            scheduler_view = SimpleNamespace(requests={}, running=[], waiting=[])
            # The values are an immutable parent snapshot, associated with this
            # nonce and exclusive non-serving engine. The worker does not own or
            # pretend to independently read the scheduler object.
            record["scheduler_authority"] = "ACTUAL_EMPTY_PARENT_SNAPSHOT_EXCLUSIVE_RPC_ENGINE"
            session = getattr(spec, "_draft_window_graph_characterization", None)
            if payload["arm"] == "ON":
                record["rank_local_observer"] = install_rank_local_recorder(spec, output)
            with ExitStack() as stack:
                stack.enter_context(torch.inference_mode())
                if payload["arm"] == "ON":
                    numeric = stack.enter_context(
                        ContinuousReference(runner,
                                            scheduler_view,
                                            output / "numeric-reference.json",
                                            identity,
                                            provenance=dict(fixture_id=payload["fixture_sha256"],
                                                            profile=self.diagnostic_profile,
                                                            config_sha256=payload["config_sha256"],
                                                            sample_limit=payload["sample_limit"])))
                    record["numeric_contract"] = numeric.provenance
                controlled = self.controlled_type(runner,
                                                  fixture_id=payload["fixture_sha256"],
                                                  arm=payload["arm"],
                                                  scheduler=scheduler_view,
                                                  identity=identity,
                                                  profile=self.diagnostic_profile,
                                                  bounded_store=True,
                                                  numeric_probe=numeric,
                                                  sample_limit=payload["sample_limit"],
                                                  rank_contract=contract,
                                                  barrier_root=Path(payload["output"]) / "host-sample-barriers",
                                                  adapter_factory=lambda current, **kwargs: self._target_adapter(current, contract, **kwargs))
                controlled.execute(output / "controlled-target.json", include_draft=True)
            record.update(state="COMPLETED",
                          completed_at=time.time(),
                          snapshot=None if session is None else session.recorder.snapshot(),
                          worker=self.mrv2_rank_snapshot(),
                          graph_submission_uncertain=False)
        except BaseException as error:
            record.update(state="FAILED",
                          exception_type=type(error).__name__,
                          exception_message=str(error),
                          exception_traceback=traceback.format_exc(),
                          completed_at=time.time(),
                          graph_submission_uncertain=bool(
                              getattr(spec, "_draft_window_graph_submission_uncertain", False)
                              or numeric is not None and numeric.poisoned or controlled is not None and any(
                                  r.get("status") in ("FORWARD_FAILED", "CORE_RUNTIME_FAILED")
                                  for r in controlled.probe.records)))
        for path in output.glob('*.json'):
            if path.name != "rank-execution.json":
                record.setdefault("artifact_index", {})[path.name] = dict(bytes=path.stat().st_size,
                                                                          sha256=digest(path))
        write(output / "rank-execution.json", record)
        if record["graph_submission_uncertain"]:
            # Only Host export above. No RPC completion, shutdown wait, device
            # recovery/sync or further generation after uncertain submission.
            os._exit(74)
        return dict(rank=self.rank,
                    pid=os.getpid(),
                    nonce=payload["nonce"],
                    state=record["state"],
                    path=str(output / "rank-execution.json"),
                    sha256=digest(output / "rank-execution.json"))


def rank_numeric_campaign(document, payload, *, profile=PROFILE):
    """Adapt the already hash-checked rank index to the unchanged R6 checker."""
    require("numeric-summary.json" in document["artifact_index"], "rank numeric summary index missing")
    return dict(capture_profile=profile,
                config_sha256=payload["config_sha256"],
                numeric_contract=document["numeric_contract"],
                snapshot=document["snapshot"],
                diagnostic_artifacts=document["artifact_index"])


def check_rank_payload(path, payload, worker, *, profile=PROFILE, record_validator=None,
                       isolation_validator=None, component_keys=None):
    from tools.p7x_graph_repair6_numeric_check import check_collection
    from tools.p7x_graph_repair6_storage import CollectionReader
    from tools.p7x_graph_repair15_eagle_numeric_check import independent_write_deltas
    document = json.loads(Path(path).read_text())
    require(
        document["state"] == "COMPLETED" and document["payload"] == payload and document["rank"] == worker["rank"]
        and document["identity"]["process_id"] == worker["pid"]
        and document["worker_start_ticks"] == worker["process_start_ticks"], "rank execution association failed")
    require(not document["graph_submission_uncertain"], "rank submission unknown")
    require(document["rank_contract"] == asdict(RankContract(payload["world_size"], worker["rank"],
        payload["nonce"], payload["parent_pid"], payload["source_sha"])), "stored rank contract differs from actual RPC owner")
    require(
        all(document["worker"][key] == worker[key]
            for key in ("rank", "pid", "process_start_ticks", "ascend_source", "vllm_source", "world_size", "tp_size",
                        "draft_tp_size")), "post-execution worker source/topology/process changed")
    output = Path(path).parent
    for name, entry in document["artifact_index"].items():
        artifact = output / name
        require(entry == dict(bytes=artifact.stat().st_size, sha256=digest(artifact)), "rank artifact index changed")
    reader = CollectionReader(output / "controlled-target.json")
    count = payload["sample_limit"] or len(case_plan(profile))
    require(reader.execution == "EXECUTED_SCOPED_NOT_GATE_CLOSURE" and len(reader.samples) == count,
            "rank Target coverage incomplete")
    require(reader.header["identity"] == document["identity"] and reader.header["capture_profile"] == profile,
            "rank Target header identity mismatch")
    from tools.p7x_graph_repair5_target import validate_controlled_record, sample_identity
    inventory = reader.header["inventory"]
    require(
        all(
            len(inventory[role +
                          "_layers"]) == len(set(inventory[role +
                                                           "_layers"])) == payload["model_configs"][role]["layers"]
            for role in ("target", "draft")),
        "complete per-rank Target/Draft layer inventory differs from verified configs")
    require(
        set(inventory["configured_layers"]) == set(inventory["target_layers"]) | set(inventory["draft_layers"]),
        "incomplete per-rank model ownership")
    from tools.p7x_graph_repair4_target import _write_coverage
    for index, case in enumerate(case_plan(profile)[:count]):
        require(not reader.incomplete(index), "uncommitted rank sample")
        sample = reader.record(index)
        require(
            sample["status"] == "CAPTURED_COMPLETE"
            and sample["identity"] == sample_identity(case, payload["fixture_sha256"]),
            "rank Target case identity mismatch")
        (validate_controlled_record if record_validator is None else record_validator)(sample)
        expected_keys = ({name + "/" + kind for name in inventory["target_layers"] for kind in ("K", "V")}
                         if component_keys is None else component_keys(sample))
        require(set(sample["checkpoint"]["kv_keys"]) == expected_keys, "incomplete per-rank Target KV checkpoint")
        require(sample["outside_before"] == sample["outside_after"], "Target changed outside mapped blocks")
        coverage = _write_coverage(sample["checkpoint"]["kv_before"], sample["checkpoint"]["kv_after"],
                                   sample["checkpoint"]["write_slots"])
        require(not any(row["changed_outside_write_slots"] for row in coverage.values()),
                "Target changed outside Full slots")
        require("target_after_draft" in sample and not (draft_target_isolation_errors(sample, 7) if isolation_validator is None else isolation_validator(sample)),
                "Draft polluted Target/full-write state")
    result = dict(rank=worker["rank"],
                  target_samples=count,
                  full_target="SINGLE_ARM_NOT_JOINED",
                  numerical="NOT_APPLICABLE_OFF")
    if payload["arm"] == "ON":
        numeric = CollectionReader(output / "numeric-reference.json")
        campaign = rank_numeric_campaign(document, payload, profile=profile)
        expected = dict(capture_profile=profile,
                        fixture_sha256=payload["fixture_sha256"],
                        numeric_samples=payload["sample_limit"],
                        argv=payload["parent_argv"])
        if profile != PROFILE:
            from tools.p7x_graph_repair12_contract import method_for_profile
            expected["method_contract"] = method_for_profile(profile).document()
        verdict = check_collection(numeric, campaign, expected)
        require(
            verdict["status"]
            == ("PASS_NUMERIC_SENTINEL_ONLY" if payload["sample_limit"] else "PASS_DIAGNOSTIC_CONTINUOUS_REFERENCE")
            and verdict["aba"] == "PASS_SCOPED", "rank numerical/ABA acceptance failed: " + str(verdict))
        logical = []
        for index in range(len(numeric.samples)):
            sample = numeric.record(index)
            runtime = sample["runtime_identity"]
            topology = runtime["topology_fingerprint"]
            require(topology["tensor_parallel_size"] == payload["world_size"] and topology["tensor_parallel_rank"] == worker["rank"],
                    "numeric source belongs to another rank")
            require(topology["parallel_read_semantics"] == "replicated", "unknown rank read semantics")
            logical.append(
                dict(generation=sample["generation"],
                     epoch=sample["epoch"],
                     case_identity=sample["case_identity"],
                     active=sample["active"],
                     descriptor=sample["descriptor"],
                     exact=sample["exact"],
                     oracle=sample["oracle"],
                     requests=runtime["ordered_request_fingerprint"]))
            normalized = dict(sample,
                              actual_slots={
                                  name: sample["inputs"]["slot_mapping"]
                                  for name in document["numeric_contract"]["draft_layers"]
                              })
            require(not independent_write_deltas(normalized, document["numeric_contract"]),
                    "rank Graph/reference changed bytes outside independent Full slots")
        result["numerical"] = verdict
        result["logical_generations"] = logical
    return result


def validate_fixture_plan(plan_path, fixture):
    from tools.p7x_graph_local_candidate import FIXTURE_SHA, validate_local_plan
    plan = json.loads(Path(plan_path).read_text())
    validate_local_plan(plan)
    manifest = json.loads(Path(plan["local_candidate_manifest"]).read_text())
    require(digest(fixture) == FIXTURE_SHA == digest(manifest["fixture_manifest"]), "frozen fixture identity mismatch")
    return dict(plan=str(plan_path),
                plan_sha256=digest(plan_path),
                manifest=plan["local_candidate_manifest"],
                manifest_sha256=plan["local_candidate_manifest_sha256"],
                source_sha=plan["commit"],
                fixture_sha256=FIXTURE_SHA,
                scope="Reuse verified immutable fixture file hashes/stat; NOT reuse device execution")


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run")
    for name in ("admission", "output", "fixture", "fixture-plan"):
        run.add_argument("--" + name, type=Path, required=True)
    run.add_argument("--tp", type=int, choices=(2, 4, 16), default=2)
    run.add_argument("--expected-sha", required=True)
    run.add_argument("--rpc-nonce", required=True)
    run.add_argument("--arm", choices=("ON", "OFF"), required=True)
    run.add_argument("--repair6-target-prefix", type=int, choices=(3, ), default=None)
    run.add_argument("--external-payload-check-only", action="store_true",
                     help="Explicit producer collection only; complete external payload check remains mandatory")
    check = commands.add_parser("check")
    for name in ("planned", "execution", "output"):
        check.add_argument("--" + name, type=Path, required=True)
    join = commands.add_parser("join")
    for name in ("off-planned", "off-execution", "on-planned", "on-execution", "output"):
        join.add_argument("--" + name, type=Path, required=True)
    return parser


def _initialize_cpu_payload_worker():
    # Spawn never inherits a device/runtime state from the parent. Each CPU
    # reader owns its own tensor/checker objects and a bounded intra-op pool.
    import torch
    torch.set_num_threads(2)


def _check_rank_response(item):
    response, worker, payload, output, nonce, checker = item
    path = Path(output) / f"rank-{worker['rank']}" / "rank-execution.json"
    require(response["path"] == str(path) and response["sha256"] == digest(path)
            and response["pid"] == worker["pid"] and response["nonce"] == nonce,
            "RPC terminal worker/attempt association mismatch")
    return checker(path, payload, worker)


def check_response_payloads(responses, workers, payload, output, nonce, checker, *, cpu_workers=1):
    """Same complete per-rank validator and input order, optionally on CPU spawn.

    Source/runtime/RPC-set/device proofs remain in the outer checker. No rank,
    tensor, tolerance or failure is filtered. Only the read-only work placement
    changes; ordinary users keep the original serial default.
    """
    require(type(cpu_workers) is int and 1 <= cpu_workers <= 4, "bounded explicit CPU worker count required")
    items = [(response, next(w for w in workers if w["rank"] == response["rank"]),
              payload, str(output), nonce, checker) for response in responses]
    if cpu_workers == 1:
        return [_check_rank_response(item) for item in items]
    require(callable(checker) and "<locals>" not in getattr(checker, "__qualname__", "<locals>"),
            "parallel payload validator must be an importable named function")
    with ProcessPoolExecutor(max_workers=cpu_workers, mp_context=multiprocessing.get_context("spawn"),
                             initializer=_initialize_cpu_payload_worker) as pool:
        return list(pool.map(_check_rank_response, items))


def check_external(planned_path, execution_path, *, profile=PROFILE, kwargs_factory=None,
                   model_contract_factory=None, fixture_validator=None,
                   payload_checker=None, extra_worker_validator=None, allow_external_only=False,
                   cpu_workers=1):
    """Fresh CPU process rechecks payloads and independent supervisor association."""
    kwargs_factory = build_diagnostic_kwargs if kwargs_factory is None else kwargs_factory
    model_contract_factory = model_layer_contract if model_contract_factory is None else model_contract_factory
    fixture_validator = validate_fixture_plan if fixture_validator is None else fixture_validator
    payload_checker = check_rank_payload if payload_checker is None else payload_checker
    result = dict(status="INVALID_EVIDENCE",
                  normal_reuse="UNPROVEN",
                  physical_read="NOT_PROVEN",
                  target_scope="SINGLE_ARM_NOT_OFF_ON_JOINED")
    try:
        expected = json.loads(Path(planned_path).read_text())
        observed = json.loads(Path(execution_path).read_text())
        execution = observed["execution"]
        argv = expected["argv"]
        args = build_parser().parse_args(argv[2:])
        require(
            args.command == "run" and execution["argv"] == argv and execution["returncode"] == 0
            and not execution["timeout"] and execution["signal"] is None, "parent invocation did not complete")
        parent = json.loads((args.output / "parent-execution.json").read_text())
        external_only = bool(args.external_payload_check_only)
        require(not external_only or allow_external_only, "external-only producer mode not admitted by this protocol")
        expected_state = ("ALL_RANK_ARTIFACTS_COLLECTED_REQUIRES_EXTERNAL_CHECK" if external_only
                          else "ALL_RANK_SCOPED_CONTROLLED_PASS")
        require(
            parent["argv"] == argv[1:] and parent["pid"] == execution["pid"]
            and parent["state"] == expected_state, "parent execution/PID/state mismatch")
        if external_only:
            require(parent["payload_validation_mode"] == "EXTERNAL_ONLY_NO_PRODUCER_NUMERIC_PASS"
                    and parent["engine_shutdown_complete"] is True,
                    "external-only producer did not complete isolated engine shutdown")
        require(execution["start_epoch"] <= parent["started_at"] < parent["ended_at"] <= execution["end_epoch"],
                "parent timestamps outside actual supervisor process")
        receipt = json.loads(args.admission.read_text())
        require(parent["process_start_ticks"] == execution["start_ticks"], "parent PID starttime mismatch")
        require(parent["admission_sha256"] == expected["admission_sha256"] == digest(args.admission),
                "predeclared admission changed")
        require(
            parent["source_sha"] == expected["source_sha"] == args.expected_sha == receipt["source_sha"]
            and parent["source_tree"] == expected["source_tree"] == receipt["source_tree"], "source identity mismatch")
        require(parent["nonce"] == args.rpc_nonce == expected["rpc_nonce"], "RPC nonce changed")
        payload = parent["payload"]
        independent_kwargs = kwargs_factory(args.arm, args.tp)
        require(
            parent["kwargs"] == independent_kwargs and payload["config_sha256"] == hashlib.sha256(
                json.dumps(independent_kwargs, sort_keys=True).encode()).hexdigest(),
            "actual config differs from independently reconstructed arm")
        require(
            payload["model_configs"] == model_contract_factory(args.fixture, independent_kwargs)
            and payload["fixture_sha256"] == digest(args.fixture) and payload["profile"] == profile,
            "model/fixture/profile identity mismatch")
        require(
            payload["source_sha"] == args.expected_sha and payload["source_tree"] == expected["source_tree"]
            and payload["nonce"] == args.rpc_nonce and payload["parent_pid"] == execution["pid"]
            and payload["parent_argv"] == argv[1:] and payload["output"] == str(args.output)
            and payload["sample_limit"] == args.repair6_target_prefix and payload["arm"] == args.arm
            and payload["world_size"] == receipt["tp"] == args.tp
            and len(expected["phy_ids"]) == len(set(expected["phy_ids"])) == args.tp,
            "actual RPC arguments differ from predeclared invocation")
        require(payload["scheduler_counts"] == dict(requests=0, running=0, waiting=0), "exclusive scheduler contract")
        source = Path(argv[1]).resolve().parents[1]
        from tools.p7x_graph_local_candidate import _identity, _git, BASE_SHA, VLLM_SHA, VLLM_TREE
        _identity(source, args.expected_sha, expected["source_tree"], ancestor=BASE_SHA)
        checker_repo = Path(__file__).resolve().parents[1]
        checker_sha, checker_tree = _git(checker_repo, "rev-parse", "HEAD"), _git(checker_repo, "rev-parse",
                                                                                  "HEAD^{tree}")
        _identity(checker_repo, checker_sha, checker_tree, ancestor=BASE_SHA)
        _identity(Path(receipt["vllm_checkout"]), VLLM_SHA, VLLM_TREE)
        require(
            fixture_validator(args.fixture_plan, args.fixture) == parent["fixture_proof"], "fixture proof changed")
        require(
            validate_runtime_overlay(receipt["runtime_manifest"]["path"], source, args.expected_sha,
                                     expected["source_tree"]) == payload["runtime_manifest"], "runtime changed")
        require(
            payload["hostname"] == receipt["host"] and payload["boot_id"] == receipt["boot_id"]
            and payload["mount_namespace"] == receipt["namespace"]
            and payload["visible"] == ",".join(map(str, receipt["phy_ids"]))
            and payload["run_id"] == "r6-rank-controlled-" + receipt["session"],
            "RPC runtime/node/run differs from admitted execution")
        workers = parent["workers"]
        validate_worker_set(workers, payload, source, receipt["vllm_checkout"])
        if extra_worker_validator is not None:
            for worker in workers:
                extra_worker_validator(worker, args.tp)
        mapping_evidence = receipt["mapping_evidence"]
        require(digest(mapping_evidence["path"]) == mapping_evidence["sha256"], "saved mapping changed")
        mapping = json.loads(Path(mapping_evidence["path"]).read_text())["mapping_command"]
        require(mapping["rc"] == 0, "actual physical mapping unavailable")
        chip_mapping = {}
        for physical in expected["phy_ids"]:
            matches = [
                parts for parts in (line.split() for line in mapping["stdout"].splitlines())
                if len(parts) >= 5 and parts[2:4] == [str(physical), str(physical)]
            ]
            require(len(matches) == 1, "physical mapping missing or ambiguous")
            chip_mapping[physical] = matches[0][:2]
        associations = observed["per_rank_device_association"]
        require(sorted(row["rank"] for row in associations) == list(range(args.tp)), "missing independent worker/device association")
        for worker in workers:
            physical = expected["phy_ids"][worker["rank"]]
            association = next(row for row in associations if row["rank"] == worker["rank"])
            require(
                association["pid"] == worker["pid"] and association["physical_id"] == physical
                and association["observations"], "worker physical mapping not externally observed")
            from tools.p7x_graph_repair30_device_join import validate_association
            validate_association(worker, physical, association, chip_mapping[physical],
                                 source_sha=expected["source_sha"], execution=execution)
        responses = parent["rpc_results"]
        require(len(responses) == args.tp and sorted(row["rank"] for row in responses) == list(range(args.tp)), "missing RPC terminal rank")
        checks = check_response_payloads(responses, workers, payload, args.output,
                                        args.rpc_nonce, payload_checker, cpu_workers=cpu_workers)
        if args.arm == "ON":
            require(all(row["logical_generations"] == checks[0]["logical_generations"] for row in checks),
                    "all-rank logical source generations differ")
        result.update(
            status="PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC",
            ranks=args.tp,
            arm=args.arm,
            samples_per_rank=args.repair6_target_prefix or len(case_plan(profile)),
            checks=checks,
            producer_commit=args.expected_sha,
            checker_commit=checker_sha,
            checker_tree=checker_tree,
            checker_tool_sha256=digest(__file__),
            scope=
            "Saved exact worker/device association plus independently re-read complete CPU payloads; not normal asynchronous safety"
        )
    except (ValueError, KeyError, TypeError, OSError, IndexError, RuntimeError) as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result


def validate_complete_target_comparison(paired, expected_count=12):
    """R6 comparator emits SAMPLE_COMPLETE; external execution remains separate.

    Do not accept a renamed PASS, partial prefix, count-only summary, changed
    scope or a failed/absent pair. The caller must first join both real arms.
    """
    require(type(expected_count) is int and expected_count > 0, "explicit full pair count required")
    require(
        paired["status"] == "SAMPLE_COMPLETE"
        and type(paired["complete_pairs"]) is int and paired["complete_pairs"] == expected_count
        and paired["execution"] == ["EXECUTED_SCOPED_NOT_GATE_CLOSURE"] * 2
        and paired["numerical_scope"] == "CONTROLLED_FULL_TARGET"
        and paired["campaign"] == "REQUIRES_EXTERNAL_EXECUTION_JOIN"
        and len(paired["pairs"]) == expected_count
        and all(row["status"] == "PASS" and not row.get("errors") and not row.get("error")
                for row in paired["pairs"]),
        "rank complete Target comparison failed")


def join_target_arms(off_planned, off_execution, on_planned, on_execution, output):
    """Full per-rank pairing follows both independent external execution checks."""
    result = dict(status="INVALID_EVIDENCE", normal_overlap="UNPROVEN", physical_read="NOT_PROVEN", ranks=[])
    try:
        externals = [check_external(off_planned, off_execution), check_external(on_planned, on_execution)]
        result["external_arms"] = externals
        require(
            all(row["status"] == "PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC" and row["samples_per_rank"] == 12
                for row in externals), "both complete all-rank arms required before Target pairing")
        plans = [json.loads(Path(path).read_text()) for path in (off_planned, on_planned)]
        args = [build_parser().parse_args(plan["argv"][2:]) for plan in plans]
        require([arg.arm for arg in args] == ["OFF", "ON"] and all(arg.repair6_target_prefix is None for arg in args),
                "full OFF/ON arm identities required; prefixes cannot be joined as complete")
        require(plans[0]["source_sha"] == plans[1]["source_sha"] and plans[0]["source_tree"] == plans[1]["source_tree"],
                "Target pair source mismatch")
        require(args[0].tp == args[1].tp and all(row["ranks"] == args[0].tp for row in externals),
                "Target pair topology/rank count mismatch")
        parents = [json.loads((arg.output / "parent-execution.json").read_text()) for arg in args]
        require(
            parents[0]["payload"]["run_id"] == parents[1]["payload"]["run_id"]
            and parents[0]["payload"]["nonce"] != parents[1]["payload"]["nonce"]
            and parents[0]["payload"]["model_configs"] == parents[1]["payload"]["model_configs"],
            "shared campaign but independent arm execution/model identity required")
        from tools.p7x_graph_repair6 import compare
        for rank in range(args[0].tp):
            workers = [next(row for row in parent["workers"] if row["rank"] == rank) for parent in parents]
            require(workers[0]["runtime_versions"] == workers[1]["runtime_versions"],
                    "rank runtime version differs across arms")
            require(workers[0]["loaded_native_hashes"] == workers[1]["loaded_native_hashes"],
                    "actual native identity differs across arms")
            paired = compare(args[0].output / f"rank-{rank}" / "controlled-target.json",
                             args[1].output / f"rank-{rank}" / "controlled-target.json",
                             timeout=1200,
                             progress=Path(output).with_name(f"rank-{rank}-target-pairs-progress.json"))
            result["ranks"].append(dict(rank=rank, comparison=paired))
            validate_complete_target_comparison(paired, 12)
        result.update(
            status=f"PASS_SCOPED_TP{args[0].tp}_COMPLETE_TARGET_12_PAIRS_PER_RANK",
            tp=args[0].tp,
            producer_commit=plans[0]["source_sha"],
            scope=
            "Two independently joined arms/rank, controlled synthetic KV; not natural trajectories or normal overlap")
    except (ValueError, KeyError, TypeError, OSError, IndexError, RuntimeError) as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result


def main():
    args = build_parser().parse_args()
    if args.command in ("check", "join"):
        # CPU-only stored-tensor work; do not change the model/worker run arm.
        import torch
        torch.set_num_threads(2)
    if args.command == "join":
        result = join_target_arms(args.off_planned, args.off_execution, args.on_planned, args.on_execution, args.output)
        write(args.output, result)
        return 0 if result["status"] == f"PASS_SCOPED_TP{result.get('tp')}_COMPLETE_TARGET_12_PAIRS_PER_RANK" else 4
    if args.command == "check":
        result = check_external(args.planned, args.execution)
        write(args.output, result)
        return 0 if result["status"] == "PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC" else 4
    return run_controlled(args)


def collected_rank_identity(path, response, worker, payload):
    """Small Host terminal record only; never a numerical or Target PASS.

    Native-unknown or failed workers must take process isolation, not normal
    shutdown. Tensor payloads remain untrusted until the external checker reads
    the full collection, references, write coverage and all rank associations.
    """
    require(response["path"] == str(path) and response["sha256"] == digest(path)
            and response["pid"] == worker["pid"] and response["nonce"] == payload["nonce"],
            "collected RPC terminal identity differs")
    doc = json.loads(Path(path).read_text())
    require(doc["state"] == "COMPLETED" and doc["graph_submission_uncertain"] is False
            and doc["payload"] == payload and type(doc["rank"]) is int and doc["rank"] == worker["rank"]
            and type(doc["identity"]["process_id"]) is int and doc["identity"]["process_id"] == worker["pid"]
            and doc["worker_start_ticks"] == worker["process_start_ticks"],
            "worker did not finish its declared diagnostic; isolate without new device work")
    require(doc["worker"]["submission_uncertain"] is False, "worker completion unknown")
    return dict(rank=worker["rank"], status="COLLECTED_NOT_NUMERICALLY_ACCEPTED",
                path=str(path), sha256=digest(path), payload_validation="EXTERNAL_PENDING")


def run_controlled(args, *, profile=PROFILE, kwargs_factory=None,
                   model_contract_factory=None, fixture_validator=None,
                   payload_checker=None, extra_worker_validator=None, producer_path=None, defer_payload_validation=False):
    kwargs_factory = build_diagnostic_kwargs if kwargs_factory is None else kwargs_factory
    model_contract_factory = model_layer_contract if model_contract_factory is None else model_contract_factory
    fixture_validator = validate_fixture_plan if fixture_validator is None else fixture_validator
    payload_checker = check_rank_payload if payload_checker is None else payload_checker
    require(type(defer_payload_validation) is bool and args.external_payload_check_only is defer_payload_validation,
            "producer CPU validation mode differs from explicitly declared CLI")
    source = Path(producer_path or __file__).resolve().parents[1]
    require(
        len(args.rpc_nonce) == 32 and all(c in "0123456789abcdef" for c in args.rpc_nonce),
        "explicit RPC nonce required")
    passive_receipt = json.loads(args.admission.read_text())
    fixture_proof = fixture_validator(args.fixture_plan, args.fixture)
    runtime_proof = validate_runtime_overlay(passive_receipt["runtime_manifest"]["path"], source, args.expected_sha,
                                             passive_receipt["source_tree"])
    # Hashing a native overlay can take time on shared storage. Perform the
    # fresh mapping/occupancy/lease/time admission AFTER these passive reads.
    receipt = validate_admission(args.admission, source=source, sha=args.expected_sha, tp=args.tp)
    require(runtime_proof == receipt["runtime_manifest"], "runtime receipt changed during passive verification")
    require(not args.output.exists(), 'new parent output required')
    args.output.mkdir(parents=True)
    parent = dict(pid=os.getpid(),
                  process_start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                  argv=sys.argv,
                  source_sha=args.expected_sha,
                  source_tree=receipt['source_tree'],
                  admission_sha256=digest(args.admission),
                  nonce=args.rpc_nonce,
                  started_at=time.time(),
                  state='STARTING',
                  fixture_proof=fixture_proof)
    write(args.output / 'parent-execution.json', parent)
    llm = None
    try:
        import torch_npu  # noqa: F401
        import vllm_ascend.ops  # noqa: F401; established circular-import-safe load
        import vllm_ascend.worker.v2.spec_decode  # noqa: F401
        from vllm import LLM
        kwargs = kwargs_factory(args.arm, args.tp)
        model_configs = model_contract_factory(args.fixture, kwargs)
        parent['kwargs'] = copy.deepcopy(kwargs)
        llm = LLM(**kwargs)
        core = llm.llm_engine.engine_core.engine_core
        scheduler = core.scheduler
        counts = {key: len(getattr(scheduler, key)) for key in ('requests', 'running', 'waiting')}
        require(counts == dict(requests=0, running=0, waiting=0), 'real parent scheduler not empty')
        payload = dict(world_size=args.tp,
                       nonce=parent['nonce'],
                       parent_pid=os.getpid(),
                       parent_argv=sys.argv,
                       run_id='r6-rank-controlled-' + receipt['session'],
                       source_sha=args.expected_sha,
                       source_tree=receipt['source_tree'],
                       output=str(args.output),
                       profile=profile,
                       arm=args.arm,
                       fixture_sha256=digest(args.fixture),
                       config_sha256=hashlib.sha256(json.dumps(parent["kwargs"], sort_keys=True).encode()).hexdigest(),
                       sample_limit=args.repair6_target_prefix,
                       scheduler_counts=counts,
                       engine_id=id(core),
                       model_configs=model_configs,
                       runtime_manifest=runtime_proof,
                       hostname=socket.gethostname(),
                       boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                       mount_namespace=os.readlink('/proc/self/ns/mnt'),
                       visible=os.environ.get('ASCEND_RT_VISIBLE_DEVICES'))
        parent['payload'] = payload
        parent['installed'] = llm.collective_rpc('mrv2_rank_install_dispatch_observer', timeout=90)
        workers = llm.collective_rpc('mrv2_rank_numeric_preflight', timeout=90, args=(payload, ))
        validate_worker_set(workers, payload, source, receipt['vllm_checkout'])
        if extra_worker_validator is not None:
            for worker in workers:
                extra_worker_validator(worker, args.tp)
        parent['workers'] = workers
        write(args.output / 'parent-execution.json', parent)
        outcomes = llm.collective_rpc('mrv2_rank_controlled', timeout=3300, args=(payload, ))
        require(sorted(row['rank'] for row in outcomes) == list(range(args.tp)), 'all-rank RPC terminal responses required')
        parent['rpc_results'] = outcomes
        checks = []
        for row in outcomes:
            worker = next(item for item in workers if item['rank'] == row['rank'])
            require(
                Path(row['path']) == args.output / f"rank-{row['rank']}" / "rank-execution.json",
                "rank RPC result points to a different attempt")
            require(
                row['nonce'] == payload['nonce'] and row['pid'] == worker['pid']
                and digest(row['path']) == row['sha256'], 'RPC result not associated with actual preflight worker')
            if defer_payload_validation:
                checks.append(collected_rank_identity(Path(row['path']), row, worker, payload))
            else:
                checks.append(payload_checker(row['path'], payload, worker))
        if args.arm == 'ON' and not defer_payload_validation:
            require(all(row["logical_generations"] == checks[0]["logical_generations"] for row in checks),
                    "all-rank logical source generations differ; physical block IDs are not required equal")
        parent.update(state=('ALL_RANK_ARTIFACTS_COLLECTED_REQUIRES_EXTERNAL_CHECK' if defer_payload_validation
                             else 'ALL_RANK_SCOPED_CONTROLLED_PASS'),
                      payload_validation_mode=('EXTERNAL_ONLY_NO_PRODUCER_NUMERIC_PASS' if defer_payload_validation
                                               else 'PRODUCER_AND_EXTERNAL'),
                      checks=checks, ended_at=time.time(), engine_shutdown_complete=False,
                      scope='SERIAL_DIAGNOSTIC; Target single arm only; normal reuse/unmeasured topologies/physical read NOT PROVEN')
        write(args.output / 'parent-execution.json', parent)
        llm.llm_engine.engine_core.shutdown()
        parent.update(engine_shutdown_complete=True, engine_shutdown_completed_at=time.time(), ended_at=time.time())
        write(args.output / 'parent-execution.json', parent)
        return 0
    except BaseException as error:
        parent.update(state='FAILED_PROCESS_ISOLATION',
                      ended_at=time.time(),
                      exception_type=type(error).__name__,
                      exception_message=str(error),
                      exception_traceback=traceback.format_exc())
        write(args.output / 'parent-execution.json', parent)
        if llm is not None:
            os._exit(74)  # Supervisor isolates this whole process tree, no post-failure device RPC/recovery.
        raise


if __name__ == '__main__':
    raise SystemExit(main())
