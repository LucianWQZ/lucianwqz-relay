# SPDX-License-Identifier: Apache-2.0
"""Finite same-instance repeats for the existing three-arm GLM HTTP profile.

Two independent instances per arm, in forward/reverse arm blocks, each run
three repeats. These are six measured repeats, not six independent boots.
The native prefix-cache reset must succeed while idle before each request group;
actual cached-token counts must be zero. Prefix-hit compatibility is covered
separately. All resets/RPC snapshots are outside client measurement spans.
Results remain diagnostic while the named numerical/normal-Graph acceptance
questions are open. No performance threshold or correctness waiver is added.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import asyncio
import hashlib
import json
import time
import urllib.request
import uuid

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair32_glm_rank import SP_CAPTURE_CONTRACT, TARGET, profile_identity
from tools.p7x_graph_repair33_service import request, run_service, validate_requests, worker_identity_rpc
from tools.p7x_graph_repair40_glm_performance import validate_ranks
from tools.p7x_graph_repair50_glm_required_baseline import (
    GLMRequiredFeatureWorker, validate_required_features, validate_required_workers,
)
from tools.p7x_graph_repair56_glm_joint_performance import joint_serve_argv, performance_groups

PROFILE = 'GLM_TP16_MATCHED_HTTP_2_INSTANCE_BLOCKS_3_WITHIN_REPEATS_COLD_PREFIX_SALT_V3'
PRODUCT_PROFILE = 'GLM_TP16_PRODUCT_32000_2000_N4_C1_FORWARD_BLOCK_PILOT_V1'
EXTENSION = 'tools.p7x_graph_repair71_glm_matched_performance.MatchedPerformanceWorker'
PRODUCT_EXTENSION = 'tools.p7x_graph_repair71_glm_matched_performance.Product32kPerformanceWorker'
ORDERS = (('G_OFF', 'G_ON', 'E_ON'), ('E_ON', 'G_ON', 'G_OFF'))
REPEATS = 3


class MatchedPerformanceWorker(GLMRequiredFeatureWorker):
    def mrv2_glm_perf_reset(self):
        result = super().mrv2_glm_perf_reset()
        # Only diagnostic Python lists are cleared. Runtime generations,
        # provider banks, pending readers and device events remain untouched.
        self._mrv2_service_phases.clear()
        self._mrv2_service_phases_truncated = False
        result['phase_audit_reset'] = 'HOST_LISTS_ONLY'
        return result


class Product32kPerformanceWorker(MatchedPerformanceWorker):
    # Four2000-output requests can issue at most8000 one-token proposals.
    # This bounded Host audit remains outside the model/device hot operations.
    _mrv2_phase_record_limit = 16384


def validate_product32k_groups(groups):
    require(isinstance(groups,list) and len(groups) == 1 and groups[0]['label'] == 'product32k-out2000-n4-c1'
            and type(groups[0]['max_tokens']) is int and groups[0]['max_tokens'] == 2000
            and type(groups[0]['concurrency']) is int and groups[0]['concurrency'] == 1
            and len(groups[0]['prompts']) == 4
            and all(len(p['prompt_token_ids']) == 32000
                    and all(type(token) is int and token >= 0 for token in p['prompt_token_ids'])
                    for p in groups[0]['prompts']), 'fixed32K/2000/four-request sequential pilot required')


def validate_position(arm, block, position):
    require(type(block) is int and block in (1, 2) and type(position) is int and position in (1, 2, 3)
            and ORDERS[block-1][position-1] == arm, 'not the fixed forward/reverse instance order')


def server_argv(python, port, name, arm, *, worker_provenance=False, product32k_pilot=False):
    require(type(product32k_pilot) is bool, 'explicit workload pilot flag required')
    argv = joint_serve_argv(python, port, name, arm, worker_provenance=worker_provenance)
    argv[argv.index('--worker-extension-cls')+1] = PRODUCT_EXTENSION if product32k_pilot else EXTENSION
    if product32k_pilot:
        argv[argv.index('--max-model-len')+1] = '36864'
    return argv


def post_json(base, route, body=None):
    req = urllib.request.Request(base+route, data=b'' if body is None else json.dumps(body).encode(),
                                 headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=45) as response:
        require(response.status == 200, 'official cache/RPC endpoint failed')
        return json.load(response)


def cache_salt(repeat, group, prompt):
    require(type(repeat) is type(group) is type(prompt) is int and 0<=repeat<=REPEATS
            and group>=0 and prompt>=0,'fixed repeat/group/prompt cache namespace required')
    # These are public synthetic benchmark namespaces, not authentication.
    # Identical across arms/instances; unique within and between request groups.
    return hashlib.sha256(f'{PROFILE}/{repeat}/{group}/{prompt}'.encode()).hexdigest()


def validate_request_salts(document,groups):
    seen=set()
    for ordinal,row in enumerate(document['groups']):
        repeat,group=divmod(ordinal,len(groups))
        require(len(row['results'])==len(groups[group]['prompts']),'salted request count differs')
        for index,result in enumerate(row['results']):
            salt=result['request'].get('cache_salt')
            require(salt==cache_salt(repeat,group,index) and salt not in seen,
                    'missing, changed or shared per-request cold-cache namespace')
            seen.add(salt)


async def client(base, model, groups, output):
    import aiohttp

    rows, boundaries = [], []
    # Blocking out-of-request RPC/reset calls can outlive HTTP keepalive.
    # Never replay a completion after a transport error; use a fresh connection.
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=300),
                                     connector=aiohttp.TCPConnector(force_close=True)) as session:
        for repeat in range(REPEATS+1):
            phase = 'warmup' if repeat == 0 else 'measured'
            boundary = None
            if repeat:
                start = time.monotonic_ns()
                reset = post_json(base, '/reset_prefix_cache')
                require(type(reset.get('success')) is bool and reset['success'],
                        'idle native prefix reset refused; no forced reset or timed retry')
                counters = post_json(base, '/collective_rpc',
                                    dict(method='mrv2_glm_perf_reset', args=[], timeout=30))['results']
                boundary = dict(repeat=repeat, start_ns=start, end_ns=time.monotonic_ns(),
                                prefix_reset=reset, counter_reset=counters, group_prefix_resets=[])
                boundaries.append(boundary)
                write(output/'repeat-boundaries.json', boundaries)
            for group_index, group in enumerate(groups):
                if repeat and group_index:
                    # Groups deliberately share prompt prefixes. Resetting only
                    # once per repeat would turn later groups into cache hits.
                    start = time.monotonic_ns()
                    reset = post_json(base, '/reset_prefix_cache')
                    require(type(reset.get('success')) is bool and reset['success'],
                            'idle per-group prefix reset refused; no forced reset or timed retry')
                    boundary['group_prefix_resets'].append(dict(group_index=group_index,label=group['label'],
                        start_ns=start,end_ns=time.monotonic_ns(),prefix_reset=reset))
                    write(output/'repeat-boundaries.json', boundaries)
                start = time.monotonic_ns()
                async def one(index, prompt):
                    return await request(session, base+'/v1/completions', model=model,
                            prompt=prompt['prompt_token_ids'], output=group['max_tokens'],
                            cache_salt=cache_salt(repeat,group_index,index),
                            failure_path=output/f'failed-r{repeat}-g{group_index}-p{index}.json')
                if group.get('concurrency') == 1:
                    results = [await one(index,p) for index,p in enumerate(group['prompts'])]
                else:
                    results = await asyncio.gather(*[one(index,p) for index,p in enumerate(group['prompts'])])
                rows.append(dict(phase=phase, repeat=repeat, label=group['label'], group_start_ns=start,
                                 group_end_ns=time.monotonic_ns(), results=results))
                write(output/'requests.json', dict(status='IN_PROGRESS', groups=rows))
            if boundary is not None:
                nonce = uuid.uuid4().hex
                start = time.monotonic_ns()
                actual = worker_identity_rpc(base, nonce)
                boundary['after'] = dict(nonce=nonce, start_ns=start, end_ns=time.monotonic_ns(), results=actual)
                write(output/'repeat-boundaries.json', boundaries)
    return rows


def repeat_slices(document, groups):
    require(document['status'] == 'COMPLETE' and len(document['groups']) == (REPEATS+1)*len(groups),
            'missing, extra or incomplete within-instance repeat')
    rows = document['groups']
    for repeat in range(REPEATS+1):
        section = rows[repeat*len(groups):(repeat+1)*len(groups)]
        require(all(type(row['repeat']) is int and row['repeat'] == repeat
                    and row['phase'] == ('warmup' if repeat == 0 else 'measured')
                    and row['label'] == group['label'] for row, group in zip(section, groups)),
                'repeat phase/ordering/workload identity differs')
    # These are views of original rows, not rewritten SSE/timestamps/requests.
    return [rows[:len(groups)]+rows[i*len(groups):(i+1)*len(groups)] for i in range(1, REPEATS+1)]


def validate_boundary(boundary, section, previous_end, expected_pids):
    require(boundary['prefix_reset'] == {'success': True}
            and type(boundary['prefix_reset']['success']) is bool
            and previous_end <= boundary['start_ns'] < boundary['end_ns'] <= section[0]['group_start_ns'],
            'cache/counter reset failed or overlaps timing')
    reset = boundary['counter_reset']
    require(len(reset) == 16 and {v['rank']: v['pid'] for v in reset} == expected_pids
            and all(v['reset'] == 'HOST_COUNTERS_ONLY_NO_DEVICE_OPERATION'
                    and v['phase_audit_reset'] == 'HOST_LISTS_ONLY' for v in reset),
            'reset did not cover the actual sixteen workers or modified its contract')
    resets=boundary['group_prefix_resets']
    require(len(resets)==len(section)-1,'missing or extra per-group prefix reset')
    for index,(reset,row) in enumerate(zip(resets,section[1:]),1):
        require(type(reset['group_index']) is int and reset['group_index']==index
                and reset['label']==row['label'] and reset['prefix_reset']=={'success':True}
                and type(reset['prefix_reset']['success']) is bool
                and section[index-1]['group_end_ns']<=reset['start_ns']<reset['end_ns']<=row['group_start_ns'],
                'per-group cache reset missing, refused, foreign or overlapping measured request')
    after = boundary['after']
    require(section[-1]['group_end_ns'] <= after['start_ns'] < after['end_ns'],
            'worker snapshot overlaps measured requests')
    require({v['rank_snapshot']['rank']: v['pid'] for v in after['results']} == expected_pids
            and len(after['results']) == 16, 'worker changed within repeated instance')
    return after


def check_saved(args):
    validate_position(args.arm, args.instance_block, args.order_position)
    source = Path(__file__).resolve().parents[1]
    campaign = json.loads(args.campaign.read_text())
    groups = json.loads(args.requests.read_text())
    document = json.loads(args.records.read_text())
    pilot = getattr(args, 'product32k_pilot', False)
    if pilot:
        validate_product32k_groups(groups)
        require(args.instance_block == 1, 'this bounded pilot does not claim reverse-block completion')
        require(all(left['end_ns'] <= right['start_ns'] for row in document['groups']
                    for left,right in zip(row['results'],row['results'][1:])), 'actual requests were not sequential')
    require(campaign['performance_profile'] == (PRODUCT_PROFILE if pilot else PROFILE) and campaign['instance_block'] == args.instance_block
            and campaign['order_position'] == args.order_position and campaign['within_instance_repeats'] == REPEATS
            and campaign['source_sha'] == args.expected_sha and campaign['requests_sha256'] == digest(args.requests),
            'fixed repeated instance identity differs')
    receipt_path = Path(campaign['admission_path'])
    require(digest(receipt_path) == campaign['admission_sha256'], 'original admission changed')
    receipt = json.loads(receipt_path.read_text())
    require(receipt['tp'] == 16 and receipt['source_sha'] == args.expected_sha
            and receipt['source_tree'] == campaign['source_tree'], 'complete source/rank binding differs')
    argv = server_argv(campaign['server_argv'][0], args.port,
                       campaign['server_argv'][campaign['server_argv'].index('--served-model-name')+1],
                       args.arm, worker_provenance=True, product32k_pilot=pilot)
    require(argv == json.loads(args.server_argv.read_text()), 'actual official argv differs')
    slices = repeat_slices(document, groups)
    validate_request_salts(document,groups)
    ids = [v['summary']['response_id'] for row in document['groups'] for v in row['results']]
    count = sum(len(group['prompts']) for group in groups)
    require(len(ids) == len(set(ids)) and campaign['measured_requests'] == REPEATS*count,
            'cross-repeat response reused or overall request count differs')
    boundaries = json.loads(args.records.with_name('repeat-boundaries.json').read_text())
    require(len(boundaries) == REPEATS and all(type(v['repeat']) is int for v in boundaries)
            and [v['repeat'] for v in boundaries] == list(range(1, REPEATS+1)),
            'missing or duplicate repeat boundary')
    final = campaign['worker_provenance'][-1]['results']
    expected_pids = {v['rank_snapshot']['rank']: v['pid'] for v in final}
    result, repeats = {}, []
    previous_end = slices[0][len(groups)-1]['group_end_ns']
    for index, (view, boundary) in enumerate(zip(slices, boundaries), 1):
        section = view[len(groups):]
        # The global total above is checked before the common single-cycle
        # validator checks this exact warmup/measurement row view.
        result = validate_requests(dict(campaign, measured_requests=count), dict(status='COMPLETE', groups=view),
            groups, expected_server_argv=argv, expected_source=source,
            expected_vllm_source=receipt['vllm_checkout'],
            worker_identity_validator=validate_required_workers, worker_extension_cls=PRODUCT_EXTENSION if pilot else EXTENSION)
        after = validate_boundary(boundary, section, previous_end, expected_pids)
        validate_required_workers(after['results'], nonce=after['nonce'], source=source,
                                  vllm_source=receipt['vllm_checkout'], arm=args.arm)
        require(all(v['summary']['usage']['prompt_tokens_details']['cached_tokens'] == 0
                    for row in section for v in row['results']), 'cold-prefix workload actually hit cache')
        repeats.append(dict(within_instance_repeat=index,
            performance_groups=performance_groups(dict(groups=section)),
            required_features=validate_required_features(after['results'], require_execution=True,
                                                        require_graph_window=args.arm == 'G_ON'),
            measured_host_dispatch=validate_ranks([v['rank_snapshot'] for v in after['results']],
                source=source, pin=receipt['vllm_checkout'], arm=args.arm, need_clip=args.arm != 'G_OFF',
                capture_contract=SP_CAPTURE_CONTRACT, eager_async_lanes=args.arm == 'E_ON')))
        previous_end = after['end_ns']
    result.update(status='PASS_SCOPED_DIAGNOSTIC_REPEATED_HTTP_PERFORMANCE', performance_profile=PRODUCT_PROFILE if pilot else PROFILE,
        instance_block=args.instance_block, order_position=args.order_position, repeats=repeats,
        measured_requests=REPEATS*count, sample_unit='THREE_WITHIN_ONE_INSTANCE_NOT_THREE_INDEPENDENT_BOOTS',
        cache_scope='PREFIX_ENGINE_ON_NATIVE_IDLE_GROUP_RESET_AND_FIXED_REQUEST_SALT_ZERO_ACTUAL_CACHED_TOKENS',
        client_transport='FRESH_TCP_PER_REQUEST_NO_COMPLETION_RETRY_CONNECT_TIME_INCLUDED',
        release_performance='NOT_APPROVED', numerical_acceptance='R6_C151_TOKEN_01_REMAINS_OPEN',
        normal_graph_completion='SOURCE_CONTRACT_APPLICABILITY_SEPARATE',
        count_scope='Per-request framework metrics; never sum replicated TP counters')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('run', 'check'))
    parser.add_argument('--arm', choices=('G_OFF', 'G_ON', 'E_ON'), required=True)
    parser.add_argument('--instance-block', type=int, choices=(1, 2), required=True)
    parser.add_argument('--order-position', type=int, choices=(1, 2, 3), required=True)
    parser.add_argument('--expected-sha', required=True)
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--product32k-pilot', action='store_true')
    for name in ('requests', 'output', 'admission', 'campaign', 'records', 'server-argv'):
        parser.add_argument('--'+name, type=Path, required=name in ('requests', 'output'))
    args = parser.parse_args()
    validate_position(args.arm, args.instance_block, args.order_position)
    if args.product32k_pilot:
        require(args.instance_block == 1, 'forward-block pilot only; not five/six balanced-repeat acceptance')
        validate_product32k_groups(json.loads(args.requests.read_text()))
    if args.command == 'check':
        try:
            result = check_saved(args)
        except (ValueError, KeyError, TypeError, IndexError, AttributeError, OSError) as error:
            result = dict(status='INVALID_EVIDENCE', error=f'{type(error).__name__}: {error}')
        write(args.output, result)
        return 0 if result['status'] == 'PASS_SCOPED_DIAGNOSTIC_REPEATED_HTTP_PERFORMANCE' else 4
    args.worker_provenance = True
    def build_server(*pos, **kw):
        return server_argv(*pos, **kw, product32k_pilot=args.product32k_pilot)
    return run_service(args, server_argv_builder=build_server, target_model=str(TARGET), tp=16,
        workload_profile='glm32k_2000_n4_c1' if args.product32k_pilot else 'legacy24k',
        ready_timeout_seconds=1800, client_runner=client,
        extra_metadata=dict(performance_profile=PRODUCT_PROFILE if args.product32k_pilot else PROFILE,
            model_profile=profile_identity(),runtime_max_model_len=36864 if args.product32k_pilot else 24576,
            cohort_status='FORWARD_BLOCK_PILOT_NOT_FULL_BALANCED_GROUP' if args.product32k_pilot else 'TWO_DECLARED_INSTANCE_BLOCKS',
            instance_block=args.instance_block, order_position=args.order_position,
            within_instance_repeats=REPEATS, entrypoint_sha256=digest(__file__),
            measurement='NORMAL_HTTP_NO_NUMERICAL_REFERENCE_NO_LIFE_SYNC_NO_PROFILER',
            cache_scope='PREFIX_ENGINE_ON_NATIVE_RESET_BEFORE_EACH_REPEAT'))


if __name__ == '__main__':
    raise SystemExit(main())
