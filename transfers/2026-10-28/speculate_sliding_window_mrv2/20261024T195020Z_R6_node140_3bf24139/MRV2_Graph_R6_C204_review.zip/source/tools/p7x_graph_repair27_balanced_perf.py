# SPDX-License-Identifier: Apache-2.0
"""Six balanced normal-performance repeats; legacy requests/contracts unchanged.

This explicit DSpark K7/Target4 profile reuses the existing normal producer and
strict performance/acceptance checker. It neither changes dispatch nor reads a
device tensor. Concurrency is a separate workload, never pooled as noise removal.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
from pathlib import Path
import re
import sys

if __name__ == "__main__":
    sys.path[:] = [
        p for p in sys.path
        if Path(p or ".").resolve() != Path(__file__).parent.resolve()
    ]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair10_performance import check as check_performance
from tools.p7x_graph_repair6_storage import atomic_json, require

ARMS = ("G_OFF", "G_ON", "E_ON")
ORDERS = tuple(itertools.permutations(ARMS))
SCHEMA = "r6-dspark-q7-balanced-performance-v1"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_declaration(declaration):
    require(declaration["schema"] == SCHEMA,
            "explicit DSpark Q7 balanced profile required")
    require(
        type(declaration["repetitions"]) is int
        and declaration["repetitions"] == len(ORDERS),
        "exact six repeats cover every three-arm order")
    workloads = declaration["workloads"]
    require(1 <= len(workloads) <= 4,
            "bounded independently reported workloads")
    require(
        len({row["label"]
             for row in workloads}) == len(workloads), "duplicate workload")
    for row in workloads:
        require(
            re.fullmatch(r"[a-z][a-z0-9_]{0,23}", row["label"]) is not None,
            "safe workload label")
        require(row["template"] in ("short", "long", "long16"),
                "unknown normal performance template")
    return workloads


def rewrite(value, old_name, new_name, old_request, new_request):
    if isinstance(value, str):
        return value.replace(old_name,
                             new_name).replace(old_request, str(new_request))
    if isinstance(value, list):
        return [
            rewrite(v, old_name, new_name, old_request, new_request)
            for v in value
        ]
    if isinstance(value, dict):
        return {
            k: rewrite(v, old_name, new_name, old_request, new_request)
            for k, v in value.items()
        }
    return value


def add_request_profile_cases(cases, inputs, output):
    """Separate bounded profiles of the exact short control request groups.

    Never turn a normal repetition into a profiled sample. The legacy producer,
    full execution join and strict performance checker remain in the plan.
    """
    marker = inputs / "request-profile27.json"
    if not marker.exists():
        return []
    declaration = json.loads(marker.read_text())
    require(declaration["schema"] == "r6-dspark-short-request-profile-v1",
            "explicit separate request profiling contract required")
    labels = declaration["labels"]
    require(1 <= len(labels) <= 2 and len(set(labels)) == len(labels), "bounded unique profiling workloads")
    order = []
    for label in labels:
        require(re.fullmatch(r"[a-z][a-z0-9_]{0,23}", label) is not None, "safe profile workload label")
        request = inputs / f"requests/performance27-{label}.json"
        groups = json.loads(request.read_text())
        require(len(groups) == 1 and type(groups[0]["max_tokens"]) is int
                and groups[0]["max_tokens"] in (256, 512), "one exact bounded control workload")
        prompts = groups[0]["prompts"]
        require(1 <= len(prompts) <= 4, "captured profiling request capacity")
        for prompt in prompts:
            ids = prompt["prompt_token_ids"]
            require(ids and all(type(t) is int and t >= 0 for t in ids)
                    and len(ids) + groups[0]["max_tokens"] <= 12288, "native short profile token contract")
        for arm in ARMS:
            source = f"PERF10_{arm}_short_01"
            name = f"PROFILE27_{label}_{arm}"
            require(source in cases and name not in cases, "new profile requires its real normal template")
            original = cases[source]
            case = rewrite(copy.deepcopy(original), source, name, original["request_path"], request)
            for field in ("argv", "launch_argv"):
                argv = case[field]
                index = argv.index("--repair5-profile")
                require(argv[index + 1] == "control", "normal template must remain unprofiled")
                argv[index + 1] = "normal"
                require("--repair8-materialize-ranges" not in argv, "profile ranges already configured")
                argv.append("--repair8-materialize-ranges")
            case.update(request_path=str(request), requests_sha256=digest(request), outputs=str(output/name),
                        selection="OPT_IN_PROFILED_REQUEST_NOT_NORMAL_REPETITION",
                        request_profile_sidecar=dict(label=label, declaration_path=str(marker),
                            declaration_sha256=digest(marker), measurement="PROFILED_NOT_NORMAL_CONTROL",
                            contract="Same exact request tokens/lengths and sampling; no numeric/Target dump/LIFE sync"))
            cases[name] = case
            order.append(name)
    return order


def add_cases(cases, inputs, output, repo, python):
    profiles = add_request_profile_cases(cases, inputs, output)
    marker = inputs / "balanced-performance27.json"
    if not marker.exists():
        return profiles
    declaration = json.loads(marker.read_text())
    workloads = validate_declaration(declaration)
    order = []
    for workload in workloads:
        label, template = workload["label"], workload["template"]
        request = inputs / f"requests/performance27-{label}.json"
        groups = json.loads(request.read_text())
        require(
            groups and len({row["label"]
                            for row in groups}) == len(groups)
            and len(groups) <= 8, "bounded unique request groups")
        for group in groups:
            require(
                type(group["max_tokens"]) is int
                and group["max_tokens"] in (256, 512), "decode output budget")
            require(1 <= len(group["prompts"]) <= 4,
                    "bounded independent concurrency")
            for prompt in group["prompts"]:
                tokens = prompt["prompt_token_ids"]
                require(
                    tokens and all(
                        type(token) is int and token >= 0 for token in tokens),
                    "pretokenized immutable input required")
                max_len = 24576 if template == "long16" else 12288
                require(
                    len(tokens) + group["max_tokens"] <= max_len,
                    "request exceeds declared native limit")
        for repetition, arms in enumerate(ORDERS, 1):
            for position, arm in enumerate(arms, 1):
                source = (f"PERF18_{arm}_long16_01" if template == "long16"
                          else f"PERF10_{arm}_{template}_01")
                require(source in cases,
                        "declared normal template missing: " + source)
                name = f"PERF27_{label}_{repetition:02}_{arm}"
                require(name not in cases,
                        "immutable performance case already exists")
                original = cases[source]
                case = rewrite(copy.deepcopy(original), source, name,
                               original["request_path"], request)
                require(case["performance_arm"] == arm, "source arm mismatch")
                # R18's flag validates native position capacity. Its historical
                # three-repeat experiment identity is NOT attributed to R27.
                capacity = case.pop("long_context_profile", None)
                case.update(
                    request_path=str(request),
                    requests_sha256=digest(request),
                    outputs=str(output / name),
                    performance_repetition=repetition,
                    selection="OPT_IN_R6_BALANCED_NORMAL_PERFORMANCE",
                    balanced_performance=dict(
                        schema=SCHEMA,
                        label=label,
                        template=template,
                        repetition=repetition,
                        order_position=position,
                        order_index=len(order),
                        arm_order=list(arms),
                        declaration_path=str(marker),
                        declaration_sha256=digest(marker),
                        max_model_len=24576 if template == "long16" else 12288,
                        native_capacity_template=capacity,
                        scope="DIAGNOSTIC_REVIEW_NOT_RELEASE_APPROVAL"))
                require(
                    all(values[values.index("--repair5-profile") +
                               1] == "control"
                        for values in (case["argv"], case["launch_argv"])),
                    "control must not enable profiler")
                for command in case["validation_commands"]:
                    command["argv"] = [
                        value.replace("p7x_graph_repair10_performance.py",
                                      "p7x_graph_repair27_balanced_perf.py")
                        for value in command["argv"]
                    ]
                cases[name] = case
                order.append(name)
    return order + profiles


def check(campaign, launcher, profile, expected, artifact):
    result = check_performance(campaign, launcher, profile, expected, artifact)
    if result.get("status") != "PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE":
        return result
    try:
        spec = expected["balanced_performance"]
        marker = Path(spec["declaration_path"])
        require(
            digest(marker) == spec["declaration_sha256"],
            "balanced declaration changed")
        declaration = json.loads(marker.read_text())
        workloads = validate_declaration(declaration)
        workload = next(row for row in workloads
                        if row["label"] == spec["label"])
        repeat, position = spec["repetition"], spec["order_position"]
        require(
            type(repeat) is int and 1 <= repeat <= len(ORDERS),
            "repeat outside predeclared six")
        require(
            type(position) is int and 1 <= position <= len(ARMS),
            "arm position")
        arms = list(ORDERS[repeat - 1])
        require(
            spec["arm_order"] == arms
            and arms[position - 1] == expected["performance_arm"],
            "arm/order mismatch")
        require(
            workload["template"] == spec["template"]
            and spec["schema"] == SCHEMA, "workload identity mismatch")
        require(
            campaign["llm_kwargs"]["max_model_len"] == spec["max_model_len"],
            "actual max length mismatch")
        require(
            expected["argv"][expected["argv"].index("--repair5-profile") +
                             1] == "control", "normal control only")
        require(not profile.get("trace_paths"),
                "profiler output must have a separate measurement identity")
        result.update(
            balanced_performance=spec,
            inference=
            "This one cell passed data checks; actual balanced dispatch and aggregate comparison are separate"
        )
    except (ValueError, KeyError, TypeError, OSError, IndexError,
            StopIteration) as error:
        result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("campaign", "profile", "launcher", "plan", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    result = check(json.loads(args.campaign.read_text()),
                   json.loads(args.launcher.read_text()),
                   json.loads(args.profile.read_text()),
                   json.loads(args.plan.read_text())["cases"][args.case_id],
                   args.profile)
    atomic_json(args.output, result)
    return 0 if result[
        "status"] == "PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE" else 4


if __name__ == "__main__":
    raise SystemExit(main())
