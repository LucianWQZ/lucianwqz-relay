# SPDX-License-Identifier: Apache-2.0
"""Default-off serialized Eagle lifecycle evidence; never normal timing proof."""
from __future__ import annotations

import time
from types import MethodType

from tools.p7x_graph_repair6_storage import atomic_json, require


def check_rows(document):
    require(document["schema"] == "r6-eagle-life-v1" and document["complete"], "incomplete Eagle LIFE")
    rows = document["records"]
    require(document["layers"] and len(document["layers"]) == len(set(document["layers"])), "complete layer inventory")
    require(len(rows) == 63 and document["completed_proposals"] == 21, "21 complete three-consumer proposals required")
    epochs, generations, banks = [], [], {}
    counts = {label: 0 for label in ("short-one", "long-three", "return-short-four")}
    for start in range(0, len(rows), 3):
        group = rows[start:start + 3]
        require([row["runtime"]["step"] for row in group] == [0, 1, 2], "all actual first/AR consumer ordinals")
        require(len({row["runtime"]["mapping_epoch"] for row in group}) == 1, "mixed proposal epochs")
        epoch = group[0]["runtime"]["mapping_epoch"]
        require(not epochs or epoch > epochs[-1], "proposal epoch not increasing")
        epochs.append(epoch)
        require(
            len({tuple(row["runtime"]["ordered_request_fingerprint"])
                 for row in group}) == 1, "request identity changed within proposal")
        group_generations = [row["runtime"]["generation_id"] for row in group]
        require(group_generations == list(range(group_generations[0], group_generations[0] + 3)),
                "consumer generations are not consecutive")
        require(not generations or group_generations[0] > generations[-1], "generation reused")
        generations += group_generations
        label = group[0]["group"]
        require(label in counts and all(row["group"] == label for row in group), "wrong lifecycle request group")
        counts[label] += 1
        addresses = []
        for row in group:
            runtime, capture = row["runtime"], row["capture"]
            step = runtime["step"]
            require(row["state"] == "UPDATED" and row["completion"] == "UPDATE_STREAM_AND_CURRENT_STREAM_SYNCHRONIZED",
                    "Host UPDATED alone is not diagnostic completion")
            require(
                capture["fingerprint"]["method"] == "eagle3"
                and capture["fingerprint"]["query_width"] == (4 if step == 0 else 1), "method-specific first/AR query")
            require(capture["consumer_ordinal"] == (0 if step == 0 else step - 1), "capture consumer differs")
            address = capture["backing_identity"]["window_block_table"]["data_ptr"]
            addresses.append(address)
            key = (capture["fingerprint"]["capture_descriptor"], capture["consumer_ordinal"])
            if key in banks:
                require(banks[key] == address, "registered backing address changed")
            banks[key] = address
            require(row["retire"]["identity"]["generation_id"] == runtime["generation_id"],
                    "real retirement attribution")
            require(row["retire"]["ns"] <= row["completion_ns"], "retirement/completion ordering")
            require(set(row["layers"]) == set(document["layers"]), "missing actual layer binding")
            for layer in row["layers"].values():
                require(
                    layer["exact_dtype"] == layer["cpu_exact_dtype"] == layer["metadata_exact_dtype"] == "torch.int32"
                    and layer["table_dtype"] == "torch.int32", "exact typed read-bank ABI")
                require(layer["device_exact"] == layer["cpu_exact"] == layer["metadata_exact"],
                        "generation exact lengths differ")
                require(layer["cpu_exact"] == row["retire"]["source_cpu_exact"],
                        "bank exact differs from this retired source generation")
                require(layer["device_table"] == layer["metadata_table"], "layer binding differs from captured bank")
                require(layer["slot_dtype"] == document["slot_dtype"] and layer["causal"] is True,
                        "actual Eagle layer write/causal contract")
        require(len(set(addresses)) == 3, "different real consumers share one read bank")
    require(set(counts.values()) == {7}, "seven proposals per short/long/replacement group")
    require(document["pending_epoch"] is None and document["quarantined"] is False,
            "unfinished or quarantined lifecycle")
    require(document["normal_overlap"] == "NOT_PROVEN" and document["extra_synchronization"] is True,
            "serialized diagnostic must not claim normal completion")
    return dict(status="PASS_SCOPED_EAGLE3_SERIAL_LIFE",
                proposals=21,
                consumers=63,
                group_counts=counts,
                normal_overlap="NOT_PROVEN",
                physical_read="NOT_PROVEN")


class EagleLifecycle:

    def __init__(self, owner, output, identity):
        self.owner, self.output, self.identity = owner, output, dict(identity)
        self.session = owner._eagle3_graph_session
        self.group = None
        self.pending_epoch = None
        self.counts = {label: 0 for label in ("short-one", "long-three", "return-short-four")}
        self.records, self.retirements, self.saved = [], {}, []
        self.uncertain = False

    def replace(self, owner, name, wrapper):
        self.saved.append((owner, name, name in vars(owner), vars(owner).get(name)))
        setattr(owner, name, MethodType(wrapper, owner))

    def __enter__(self):
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe
        probe = self
        runtime = self.session.controller.runtime
        original_retire = runtime.retire_generation

        def retire(_runtime, identity):
            source_exact = None
            if identity.mapping_epoch == probe.pending_epoch:
                inputs = runtime._active_inputs
                require(inputs is not None and inputs.identity == identity, "actual retirement source identity")
                # CPU-owned exact values only, before scratch reuse. No D2H,
                # device operation or completion inference at this boundary.
                source_exact = inputs.cpu_window_exact[:identity.padded_request_count].tolist()
            value = original_retire(identity)
            if identity.mapping_epoch == probe.pending_epoch:
                probe.retirements[identity.generation_id] = dict(
                    identity=_json_safe(identity),
                    ns=time.monotonic_ns(),
                    source_cpu_exact=source_exact,
                    scope="ACTUAL_HOST_RETIRE_RETURN_NOT_DEVICE_COMPLETION")
            return value

        self.replace(runtime, "retire_generation", retire)
        for first, manager in ((True, self.owner.prefill_cudagraph_manager), (False,
                                                                              self.owner.decode_cudagraph_manager)):
            original = manager.run_fullgraph

            def call(_manager, desc, *, first=first, original=original, manager=manager):
                context = probe.owner._eagle3_window_proposal_context
                if context is None or desc.cg_mode.name != "FULL" or probe.group not in probe.counts:
                    return original(desc)
                epoch = context.mapping_epoch
                if first:
                    if probe.counts[probe.group] >= 7:
                        return original(desc)
                    require(probe.pending_epoch is None, "unfinished previous LIFE proposal")
                    probe.pending_epoch = epoch
                elif probe.pending_epoch != epoch:
                    return original(desc)
                try:
                    # If replay/update throws, do not synchronize or inspect
                    # the device. Only the Host isolation in __exit__ follows.
                    probe.uncertain = True
                    result = original(desc)
                    require(result is None, "legal manager None return")
                    import torch
                    manager.update_stream.synchronize()
                    torch.npu.current_stream().synchronize()
                    probe.uncertain = False
                    completed = time.monotonic_ns()
                    carriers = probe.session.provider.submitted_carriers
                    require(len(carriers) == (1 if first else 2), "actual LIFE consumer inventory")
                    for carrier in carriers:
                        identity = carrier.runtime_identity
                        read = carrier.read_inputs
                        require(identity.generation_id in probe.retirements, "real source retirement missing")
                        # Known-completed diagnostic branch only. D2H failures
                        # become uncertain too; no later device recovery.
                        probe.uncertain = True
                        exact = read.device_window_exact.detach().cpu().tolist()
                        table = read.window_block_table.detach().cpu().tolist()
                        layers = {
                            name:
                            dict(device_exact=exact,
                                 cpu_exact=read.cpu_window_exact.tolist(),
                                 exact_dtype=str(read.device_window_exact.dtype),
                                 cpu_exact_dtype=str(read.cpu_window_exact.dtype),
                                 metadata_exact_dtype=str(metadata.seq_lens.dtype),
                                 table_dtype=str(read.window_block_table.dtype),
                                 metadata_exact=metadata.seq_lens_list,
                                 device_table=table,
                                 metadata_table=metadata.block_tables.detach().cpu().tolist(),
                                 slot_dtype=str(metadata.slot_mapping.dtype),
                                 causal=metadata.causal)
                            for name, metadata in carrier.metadata.items() if metadata is not None
                        }
                        probe.uncertain = False
                        probe.records.append(
                            dict(group=probe.group,
                                 capture=_json_safe(carrier.capture_identity),
                                 runtime=_json_safe(identity),
                                 state=carrier.state.name,
                                 layers=layers,
                                 descriptor=[desc.num_reqs, desc.num_tokens],
                                 completion_ns=completed,
                                 completion="UPDATE_STREAM_AND_CURRENT_STREAM_SYNCHRONIZED",
                                 retire=probe.retirements[identity.generation_id]))
                    if not first:
                        probe.counts[probe.group] += 1
                        probe.pending_epoch = None
                    probe.flush(complete=False)
                    return result
                except BaseException:
                    if probe.uncertain:
                        probe.owner._draft_window_graph_submission_uncertain = True
                        probe.session.controller.quarantine("Eagle LIFE diagnostic submission/completion unknown")
                    raise

            self.replace(manager, "run_fullgraph", call)
        return self

    def flush(self, *, complete):
        atomic_json(
            self.output,
            dict(schema="r6-eagle-life-v1",
                 identity=self.identity,
                 records=self.records,
                 layers=sorted(self.owner.draft_attn_layer_names),
                 slot_dtype=str(self.owner.block_tables.slot_mappings.dtype),
                 group_counts=self.counts,
                 completed_proposals=sum(self.counts.values()),
                 pending_epoch=self.pending_epoch,
                 complete=complete,
                 quarantined=self.session.controller.quarantined,
                 uncertain=self.uncertain,
                 normal_overlap="NOT_PROVEN",
                 extra_synchronization=True,
                 scope="PER_PHASE_UPDATE_AND_CURRENT_STREAM_SYNC_AND_READ_BANK_D2H_SERIAL_DIAGNOSTIC"))

    def __exit__(self, kind, *_):
        for owner, name, existed, value in reversed(self.saved):
            if existed:
                setattr(owner, name, value)
            else:
                delattr(owner, name)
        complete = not kind and set(self.counts.values()) == {7} and self.pending_epoch is None and not self.uncertain
        self.flush(complete=complete)
        if not kind:
            require(complete, "Eagle LIFE did not complete all declared proposals")
