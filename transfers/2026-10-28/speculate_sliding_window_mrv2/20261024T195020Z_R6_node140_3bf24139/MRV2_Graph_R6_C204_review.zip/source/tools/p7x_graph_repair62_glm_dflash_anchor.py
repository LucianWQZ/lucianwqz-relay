# SPDX-License-Identifier: Apache-2.0
"""Named GLM/DFlash loader and real all-rank Draft Graph anchor.

This is a separate K15/Q16 method contract. It reuses admission, model
execution and the external rank join, without relabelling DSpark evidence.
It is not the required-feature service, numerical or lifecycle acceptance.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair21_rank import digest, require, run_anchor, write
from tools.p7x_graph_repair28_rank_anchor_check import check as check_anchor
from tools.p7x_graph_repair32_glm_rank import (
    GLMRankWorker, QUANT_SHA, TARGET, TARGET_CONFIG_SHA, build_glm_kwargs,
)

PROFILE = "GLM52_W4A8_DFLASH_K15_Q16_FULL_NONCAUSAL_TP16_FDO_ANCHOR_V1"
DRAFT = Path("/mnt/weight/GLM-5.2-FP8-DFlash")
DRAFT_CONFIG_SHA = "1710dbc1059353f3b3e5641a61bc7973353253e5201a78c6012f1fb6e793bbe0"
CAPTURE = (16, 32, 64)
AUX_LAYERS = (1, 20, 38, 56, 75)
SPECULATOR = "vllm_ascend.worker.v2.spec_decode.dflash.speculator.AscendDFlashSpeculator"


def validate_model_configs(target, draft):
    require(target["architectures"] == ["GlmMoeDsaForCausalLM"]
            and target["model_type"] == "glm_moe_dsa"
            and target["num_hidden_layers"] == 78 and target["hidden_size"] == 6144,
            "actual GLM Target contract differs")
    require(draft["architectures"] == ["DFlashDraftModel"]
            and draft["model_type"] == "qwen3" and draft["num_hidden_layers"] == 5
            and draft["hidden_size"] == draft["target_hidden_size"] == 6144
            and draft["num_attention_heads"] == draft["num_key_value_heads"] == 64
            and draft["head_dim"] == 64 and draft["num_target_layers"] == 78
            and draft["dtype"] == "bfloat16" and draft["vocab_size"] == 154880,
            "actual BF16 GLM DFlash geometry differs; directory name is not dtype evidence")
    cfg = draft["dflash_config"]
    require(cfg["target_layer_ids"] == list(AUX_LAYERS) and cfg["mask_token_id"] == 154821
            and cfg.get("sample_from_anchor", False) is False
            and cfg.get("causal") is None
            and draft["layer_types"] == ["full_attention"] * 5
            and draft["use_sliding_window"] is False and draft["sliding_window"] is None,
            "DFlash aux, mask, anchor or full-attention contract differs")
    require(target["max_position_embeddings"] >= 4096
            and draft["max_position_embeddings"] >= 4096,
            "anchor exceeds model position capability")


def weight_headers(path):
    """Read only the bounded safetensors header, never the large tensor data."""
    with Path(path).open("rb") as stream:
        size = struct.unpack("<Q", stream.read(8))[0]
        require(0 < size <= 1 << 20, "invalid or unbounded safetensors header")
        raw = stream.read(size)
    require(len(raw) == size, "truncated safetensors header")
    header = json.loads(raw)
    expected = {"fc.weight": [6144, 30720], "embed_tokens.weight": [154880, 6144]}
    for key, shape in expected.items():
        require(header[key]["dtype"] == "BF16" and header[key]["shape"] == shape,
                "actual DFlash weight header/aux FC geometry differs")
    return dict(header_bytes=size, header_sha256=hashlib.sha256(raw).hexdigest(),
                tensors={key: header[key] for key in expected},
                scope="HEADER_ONLY_NOT_FULL_WEIGHT_HASH_OR_EXECUTED_AUX_BINDING")


def profile_identity():
    require(digest(TARGET / "config.json") == TARGET_CONFIG_SHA
            and digest(TARGET / "quant_model_description.json") == QUANT_SHA
            and digest(DRAFT / "config.json") == DRAFT_CONFIG_SHA,
            "fixed GLM DFlash model configuration changed")
    validate_model_configs(json.loads((TARGET / "config.json").read_text()),
                           json.loads((DRAFT / "config.json").read_text()))
    paths = [TARGET / "config.json", TARGET / "quant_model_description.json",
             TARGET / "quant_model_weights.safetensors.index.json", TARGET / "tokenizer_config.json",
             DRAFT / "config.json"]
    return dict(profile=PROFILE,
        files=[dict(path=str(p), bytes=p.stat().st_size, sha256=digest(p)) for p in paths],
        draft_weight_header=weight_headers(DRAFT / "model.safetensors"),
        method=dict(method="dflash", k=15, draft_query=16, target_query=16,
                    sample_from_anchor=False, sample_offset_contract=1,
                    target_layer_ids=list(AUX_LAYERS), auxiliary_output_indices=[i + 1 for i in AUX_LAYERS]),
        scope="Fixed config/header and pinned loader contract; not a full weight hash or device result")


def build_kwargs(tp, *, window_on_review=False):
    kwargs = build_glm_kwargs(tp, window_on_review=window_on_review)
    kwargs["speculative_config"].update(method="dflash", model=str(DRAFT), num_speculative_tokens=15)
    kwargs["compilation_config"]["cudagraph_capture_sizes"] = list(CAPTURE)
    kwargs["worker_extension_cls"] = "tools.p7x_graph_repair62_glm_dflash_anchor.GLMDFlashWorker"
    return kwargs


class GLMDFlashWorker(GLMRankWorker):
    def mrv2_rank_snapshot(self):
        # The parent reads the actual speculator and actual Target/Draft groups;
        # only the declared profile label is changed, never its measured fields.
        row = super().mrv2_rank_snapshot()
        spec = self.model_runner.speculator
        row["glm_profile"]["profile"] = PROFILE
        cfg = spec.draft_model_config.hf_config
        row["dflash_method"] = dict(method=spec.speculative_config.method,
            target_layer_ids=list(cfg.dflash_config["target_layer_ids"]),
            mask_token_id=spec.parallel_drafting_token_id,
            fc_weight_shape=list(spec.model.model.fc.weight.shape),
            aux_scope="NORMALIZED_CONFIG_AND_BUILT_FC_HEADER_NOT_PER_LAYER_EXECUTION")
        return row


def validate_worker(worker, tp):
    require(type(tp) is int and tp == 16 and worker.get("speculator_class") == SPECULATOR,
            "actual all16 Ascend DFlash speculator required")
    p, m = worker["glm_profile"], worker["dflash_method"]
    require(p["profile"] == PROFILE and type(p["k"]) is type(p["draft_query"]) is int
            and p["k"] == 15 and p["draft_query"] == 16
            and p["sample_from_anchor"] is False and p["noncausal"] is True
            and p["target_model"] == str(TARGET) and p["draft_model"] == str(DRAFT)
            and m["method"] == "dflash" and m["target_layer_ids"] == list(AUX_LAYERS)
            and type(m["mask_token_id"]) is int and m["mask_token_id"] == 154821
            and m["fc_weight_shape"] == [6144, 30720], "actual DFlash method/aux contract differs")
    layers = worker["draft_layers"]
    require(len(layers) == len(set(layers)) == 5
            and set(worker["draft_backend"]) == set(layers)
            and all(v.endswith("attention_v1.AscendAttentionBackend") for v in worker["draft_backend"].values())
            and set(worker["draft_kv_geometry"]) == {name + "/" + str(kv) for name in layers for kv in (0, 1)},
            "complete actual five-layer dense FIA Draft required")
    for value in worker["draft_kv_geometry"].values():
        shape = value["shape"]
        require(len(shape) == 4 and shape[0] > 0 and shape[1:] == [128, 4, 64]
                and value["dtype"] == "torch.bfloat16", "DFlash rank-local KV geometry differs")
    groups = p["draft_groups"]
    require(len(groups) == 1 and set(groups[0]["layers"]) == set(layers)
            and groups[0]["backend"].endswith("attention_v1.AscendAttentionBackend"),
            "actual Draft cache group differs")
    gid = groups[0]["global_group_id"]
    require(type(gid) is int and gid >= 0
            and p["normalized_layer_types"] == ["full_attention"] * 5
            and p["normalized_causal_override"] is None
            and len(p["actual_layer_causal"]) == 5
            and all(value is False for value in p["actual_layer_causal"])
            and p["group_causal"] == [dict(global_group_id=gid, causal=False)]
            and all(type(row["global_group_id"]) is int and row["causal"] is False
                    for row in p["group_causal"])
            and p["mask_source"] == "NORMALIZED_CONFIG_ACTUAL_MODEL_AND_SPECULATOR_GROUP_MASKS",
            "actual full-attention layer/group masks differ")
    if worker["window_size"] is not None:
        require(all(item["global_group_id"] == gid for item in
                    worker["window_generations"] + worker["window_graph_bindings"]),
                "Window uses another cache group")
    targets = p["target_groups"]
    main = [g for g in targets if g["backend"].endswith("sfa_v1.AscendSFABackend")]
    indexer = [g for g in targets if g["backend"].endswith("indexer.AscendSFAIndexerBackend")]
    main_layers = [name for g in main for name in g["layers"]]
    indexer_layers = [name for g in indexer for name in g["layers"]]
    require(len(targets) == len(main) + len(indexer)
            and len(main_layers) == len(set(main_layers)) == 78
            and len(indexer_layers) == len(set(indexer_layers)) == 21
            and not set(main_layers + indexer_layers) & set(layers)
            and not set(main_layers) & set(indexer_layers), "complete independent Target SFA/indexer owners required")
    required = {(n, n * 16) for n in (1, 2, 4)}
    for key in ("draft_graph_inventory", "target_graph_inventory"):
        inventory = {(row["requests"], row["tokens"]) for row in worker[key] if row["mode"] == "FULL"}
        require(required <= inventory, "actual DFlash/Target Q16 capture bucket missing")


def check(planned, execution):
    result = check_anchor(planned, execution, kwargs_factory=build_kwargs,
                          worker_validator=validate_worker, entrypoint_name=Path(__file__).name)
    if result["status"].startswith("PASS_SCOPED_"):
        try:
            expected = json.loads(Path(planned).read_text())
            argv = expected["argv"]
            campaign = json.loads((Path(argv[argv.index("--output") + 1]) / "campaign.json").read_text())
            require(expected["profile_identity"] == campaign["profile_identity"] == profile_identity(),
                    "declared and actual DFlash identities differ")
            result.update(profile=PROFILE, status=result["status"] + "_GLM_DFLASH_K15_Q16")
        except (ValueError, KeyError, TypeError, OSError, struct.error) as error:
            result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    commands = p.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run")
    for key in ("admission", "output"):
        run.add_argument("--" + key, type=Path, required=True)
    run.add_argument("--tp", type=int, choices=(16,), required=True)
    run.add_argument("--expected-sha", required=True)
    run.add_argument("--window-on-review", action="store_true")
    saved = commands.add_parser("check")
    for key in ("planned", "execution", "output"):
        saved.add_argument("--" + key, type=Path, required=True)
    args = p.parse_args()
    if args.command == "run":
        return run_anchor(args, profile_kwargs=build_kwargs(args.tp, window_on_review=args.window_on_review),
                          profile_identity=profile_identity(), producer_path=__file__)
    result = check(args.planned, args.execution)
    write(args.output, result)
    return 0 if result["status"].startswith("PASS_SCOPED_") else 4


if __name__ == "__main__":
    raise SystemExit(main())
