# SPDX-License-Identifier: Apache-2.0
"""Explicit Host-only service worker identity, outside measured HTTP groups.

Opt-in through the standard worker-extension CLI. No model/manager wrapping,
device operation, tensor value read, event query or completion inference.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import socket
import sys


def _require(value, message):
    if not value:
        raise ValueError(message)


def _loaded_module(name):
    module = sys.modules.get(name)
    _require(module is not None and getattr(module, "__file__", None), "required worker module not loaded: " + name)
    path = Path(module.__file__).resolve()
    return dict(module=name, path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def _capture_inventory(manager):
    if manager is None:
        return dict(graphs=[])
    return dict(graphs=[dict(mode=d.cg_mode.name, num_reqs=d.num_reqs, num_tokens=d.num_tokens,
                             uniform_token_count=d.uniform_token_count)
                        for d in getattr(manager, "graphs", {})])


def host_worker_identity(worker, nonce):
    """Read already existing Python objects and /proc only; never import a model."""
    _require(isinstance(nonce, str) and len(nonce) == 32 and all(c in "0123456789abcdef" for c in nonce),
             "exact request nonce required")
    runner = worker.model_runner
    spec = runner.speculator
    _require(spec is not None, "actual speculative worker is required")
    names = ["vllm", "vllm_ascend", type(worker).__module__, type(runner).__module__, type(spec).__module__]
    provider = getattr(spec, "_draft_window_graph_binding_provider", None)
    parallel = getattr(spec, "_draft_window_graph_characterization", None)
    eagle = getattr(spec, "_eagle3_graph_session", None)
    _require(parallel is None or eagle is None, "ambiguous method session")
    session = parallel if parallel is not None else eagle
    if provider is not None:
        _require(session is not None and session.owner is spec and session.provider is provider,
                 "actual method session/provider ownership differs")
        names.append(type(provider).__module__)
    heavy = bool(provider is not None and provider.observer is not None)
    if parallel is not None:
        heavy |= parallel.recorder.enabled is not False
    if eagle is not None:
        heavy |= eagle.numeric_snapshots is not None
    native = sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines()
                     if any(key in line for key in ('vllm_ascend_C', 'libruntime_v100', 'libtorch_npu',
                                                    'custom_transformer'))})
    start = Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19]
    config = getattr(spec, "speculative_config", None)
    graph_inventory = dict(target=_capture_inventory(getattr(runner, "cudagraph_manager", None)))
    for name in ("query_cudagraph_manager", "prefill_cudagraph_manager", "decode_cudagraph_manager"):
        graph_inventory[name] = _capture_inventory(getattr(spec, name, None))
    bindings = []
    for carrier in getattr(provider, "_carriers", {}).values():
        capture, runtime = carrier.capture_identity, carrier.runtime_identity
        attribution = carrier.backend_attribution
        bindings.append(dict(bucket=list(capture.fingerprint.capture_bucket), ordinal=capture.consumer_ordinal,
            generation=None if runtime is None else runtime.generation_id,
            epoch=None if runtime is None else runtime.mapping_epoch,
            update_function=None if attribution is None else attribution.update_function_path))
    return dict(nonce=nonce, pid=os.getpid(), process_start_ticks=start, hostname=socket.gethostname(),
                boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                namespace=os.readlink('/proc/self/ns/mnt'),
                modules=[_loaded_module(name) for name in dict.fromkeys(names)], loaded_native=native,
                worker_class=type(worker).__module__ + '.' + type(worker).__qualname__,
                runner_class=type(runner).__module__ + '.' + type(runner).__qualname__,
                speculator_class=type(spec).__module__ + '.' + type(spec).__qualname__,
                provider_installed=provider is not None, heavy_observer_enabled=heavy,
                actual_method=getattr(spec,"method",None),
                actual_k=getattr(config,"num_speculative_tokens",None),
                actual_query_width=getattr(spec,"num_query_per_req",None),
                actual_sample_from_anchor=getattr(spec,"sample_from_anchor",None),
                graph_inventory=graph_inventory, latest_provider_bindings=bindings,
                graph_state_scope="HOST_CAPTURE_REGISTRY_AND_UPDATE_ATTRIBUTION_NOT_EXECUTION_OCCURRENCE",
                scope='HOST_OBJECTS_AND_LOADED_FILES_ONLY_NOT_DISPATCH_OR_DEVICE_COMPLETION',
                device_observation='EXTERNAL_PROCESS_DEVICE_JOIN_REQUIRED')


class ServiceWorkerIdentity:
    def mrv2_service_worker_identity(self, nonce):
        return host_worker_identity(self, nonce)


def validate_worker_identity(rows, *, nonce, source, vllm_source, arm):
    _require(arm in ('G_OFF', 'G_ON', 'E_ON') and isinstance(rows, list) and len(rows) == 1,
             "exact TP1 service identity required")
    row = rows[0]
    _require(row['nonce'] == nonce and type(row['pid']) is int and row['pid'] > 0
             and isinstance(row['process_start_ticks'], str) and row['process_start_ticks'].isdigit(),
             "service identity nonce/PID/start-time mismatch")
    _require(row['scope'] == 'HOST_OBJECTS_AND_LOADED_FILES_ONLY_NOT_DISPATCH_OR_DEVICE_COMPLETION'
             and row['device_observation'] == 'EXTERNAL_PROCESS_DEVICE_JOIN_REQUIRED', "identity scope changed")
    _require(type(row['provider_installed']) is bool and row['provider_installed'] is (arm == 'G_ON')
             and row['heavy_observer_enabled'] is False, "observer-off safety provider differs from arm")
    modules = {entry['module']: entry for entry in row['modules']}
    _require(len(modules) == len(row['modules']) and 'vllm' in modules and 'vllm_ascend' in modules,
             "duplicate/missing actual worker module")
    for key in ('worker_class', 'runner_class', 'speculator_class'):
        _require(row[key].rsplit('.', 1)[0] in modules, "actual worker class module missing")
    for name, entry in modules.items():
        root = Path(source if name == 'vllm_ascend' or name.startswith('vllm_ascend.') else vllm_source).resolve()
        _require(name in ('vllm', 'vllm_ascend') or name.startswith(('vllm.', 'vllm_ascend.')),
                 "unknown worker module namespace")
        path = Path(entry['path'])
        _require(path.is_absolute() and path.resolve().is_relative_to(root), "worker imported another source")
        data = path.read_bytes()
        _require(type(entry['bytes']) is int and entry['bytes'] == len(data)
                 and entry['sha256'] == hashlib.sha256(data).hexdigest(), "worker module bytes/hash changed")
    _require(any(str(Path(source).resolve()) in path and 'vllm_ascend_C' in path
                 for path in row['loaded_native']), "actual candidate native extension not loaded")
    return dict(status='PASS_SCOPED_DIRECT_WORKER_PYTHON_PROVENANCE_AND_OBSERVER_OFF_STATE',
                pid=row['pid'], process_start_ticks=row['process_start_ticks'],
                device_execution_occurrence='NOT_PROVEN', normal_completion='NOT_PROVEN')
