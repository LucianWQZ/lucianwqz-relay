# SPDX-License-Identifier: Apache-2.0
"""Default-off Eagle process-isolation probes at actual first/merged-AR seams.

These deliberately terminate a disposable model child. They do not simulate
native corruption, validate Python exception unfolding, or certify normal
completion. Only after_completion drains, before the fault, as a diagnostic.
"""
from __future__ import annotations

import argparse
import copy
import os
import sys
import time
from pathlib import Path
from types import MethodType

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair5_evidence import audit_execution, file_sha, require
from tools.p7x_graph_repair6_storage import atomic_json

POINTS = ("before_replay", "after_replay", "after_update", "after_completion")


class EagleAbort:
    def __init__(self, owner, output, identity, point, campaign):
        require(point in POINTS, "unknown Eagle abort point")
        self.owner, self.output, self.identity = owner, Path(output), dict(identity)
        self.point, self.campaign = point, campaign
        self.session = owner._eagle3_graph_session
        self.saved, self.current = [], None

    def replace(self, owner, name, call):
        self.saved.append((owner, name, name in vars(owner), vars(owner).get(name)))
        setattr(owner, name, MethodType(call, owner))

    def __enter__(self):
        probe = self
        for first, manager in ((True, self.owner.prefill_cudagraph_manager),
                               (False, self.owner.decode_cudagraph_manager)):
            original = manager.run_fullgraph

            def run(_manager, desc, *, first=first, manager=manager, original=original):
                context = probe.owner._eagle3_window_proposal_context
                eligible = (context is not None and desc.cg_mode.name == "FULL"
                            and not probe.owner._eagle3_window_bypass_active)
                if eligible and not first:
                    eligible = (probe.session.controller._first_pass_is_graph
                                and any(t.step == 0 and t.mapping_epoch == context.mapping_epoch
                                        for t in probe.session.controller.transfers))
                if not eligible:
                    return original(desc)
                probe.current = (first, manager, desc, context)
                try:
                    result = original(desc)
                    require(result is None, "legal Eagle manager None return")
                    if not first and probe.point in ("after_update", "after_completion"):
                        complete = probe.point == "after_completion"
                        if complete:
                            # Intentionally serial diagnostic BEFORE the fault.
                            # No recovery/sync/D2H occurs after a fault.
                            import torch
                            probe.owner.prefill_cudagraph_manager.update_stream.synchronize()
                            manager.update_stream.synchronize()
                            torch.npu.current_stream().synchronize()
                        probe.inject(replay_returned=True, update_returned=True, completed=complete)
                    return result
                finally:
                    probe.current = None

            self.replace(manager, "run_fullgraph", run)
            if first:
                for graph in manager.graphs.values():
                    original_replay = graph.replay

                    def replay(_graph, *, graph=graph, original_replay=original_replay):
                        selected = probe.current is not None and probe.current[0]
                        if selected:
                            require(probe.current[1].graphs[probe.current[2]] is graph,
                                    "actual first Graph object mismatch")
                            if probe.point == "before_replay":
                                probe.inject(replay_returned=False, update_returned=False, completed=False)
                        result = original_replay()
                        if selected and probe.point == "after_replay":
                            probe.inject(replay_returned=True, update_returned=False, completed=False)
                        return result

                    self.replace(graph, "replay", replay)
        return self

    def inject(self, *, replay_returned, update_returned, completed):
        from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import _json_safe
        first, manager, desc, context = self.current
        transfers = [t for t in self.session.controller.transfers if t.mapping_epoch == context.mapping_epoch]
        banks = []
        for transfer in transfers:
            carrier = self.session.provider._require_registered_capture(transfer.capture_identity)
            banks.append(dict(step=transfer.step, generation=transfer.generation,
                              epoch=transfer.mapping_epoch, capture=_json_safe(carrier.capture_identity),
                              runtime=_json_safe(carrier.runtime_identity), state=carrier.state.name))
        selected = banks[0 if first else -1]
        row = dict(point=self.point, ns=time.monotonic_ns(), epoch=context.mapping_epoch,
                   request_ids=list(context.ordered_request_ids), descriptor=[desc.num_reqs, desc.num_tokens],
                   manager_route="first" if first else "merged_ar", banks=banks,
                   selected_generation=selected["generation"],
                   selected_backing=selected["capture"]["backing_identity"]["window_block_table"]["data_ptr"],
                   first_graph_replay_returned=replay_returned,
                   current_manager_update_returned=update_returned,
                   explicit_diagnostic_drain_complete=completed,
                   host_materialize_stream=self.session.controller._stream,
                   update_stream=int(manager.update_stream.npu_stream),
                   submission_scope=("NO_FIRST_GRAPH_REPLAY_PRIOR_PREPARATION_MAY_BE_ENQUEUED"
                                     if not replay_returned else "EXPLICIT_DIAGNOSTIC_DRAIN_BEFORE_ABORT"
                                     if completed else "SUBMITTED_COMPLETION_UNKNOWN"))
        self.session.controller.quarantine("Eagle disposable abort: " + self.point)
        self.owner._draft_window_graph_submission_uncertain = True
        document = dict(schema="r6-eagle-abort-v1", identity=self.identity, record=row,
                        process_isolation_required=True, host_quarantined=self.session.controller.quarantined,
                        post_fault_device_operations="NONE_BY_PROBE", reuse="FORBIDDEN_PROCESS_EXIT_73",
                        python_exception_unfolding="NOT_EXERCISED", native_corruption="NOT_SIMULATED",
                        normal_overlap="NOT_PROVEN")
        atomic_json(self.output, document)
        partial = dict(self.campaign, status="ABORT_PARTIAL", identity=self.identity,
                       abort_point=self.point, abort_artifact=dict(path=str(self.output),
                       bytes=self.output.stat().st_size, sha256=file_sha(self.output)),
                       isolation="PROCESS_EXIT_73_NO_REUSE")
        atomic_json(self.output.with_name("abort-campaign.json"), partial)
        os._exit(73)

    def __exit__(self, *_):
        for owner, name, existed, value in reversed(self.saved):
            if existed:
                setattr(owner, name, value)
            else:
                delattr(owner, name)


def check(document, campaign, launcher, expected, artifact):
    result = audit_execution(document, campaign, launcher, expected, artifact, abort=True)
    if result["status"] != "EXECUTION_ASSOCIATED":
        return result
    try:
        point = expected["eagle3_abort_point"]
        require(point in POINTS and expected["acceptance_identity"]["case_id"] == "ABORT_EAGLE3_" + point,
                "named Eagle abort point")
        require(document["schema"] == "r6-eagle-abort-v1", "exact abort schema")
        indexed = campaign["abort_artifact"]
        require(Path(indexed["path"]).resolve() == Path(artifact).resolve()
                and indexed["bytes"] == Path(artifact).stat().st_size and indexed["sha256"] == file_sha(artifact),
                "partial artifact bytes/hash mismatch")
        require(campaign["abort_point"] == point and campaign["isolation"] == "PROCESS_EXIT_73_NO_REUSE",
                "actual partial point/isolation")
        row = document["record"]
        require(row["point"] == point and launcher["host_start_ns"] <= row["ns"] <= launcher["host_end_ns"],
                "actual fault point/time")
        first = point in POINTS[:2]
        require(type(row["epoch"]) is int and row["epoch"] >= 0 and row["request_ids"]
                and len(set(row["request_ids"])) == len(row["request_ids"]), "actual proposal identity")
        require(row["manager_route"] == ("first" if first else "merged_ar"), "actual manager route")
        banks = row["banks"]
        require([b["step"] for b in banks] == ([0] if first else [0, 1, 2]), "complete actual consumer set")
        generations = [b["generation"] for b in banks]
        require(all(type(g) is int and g >= 0 for g in generations)
                and generations == list(range(generations[0], generations[0] + len(banks))),
                "actual consecutive generations")
        addresses = []
        for b in banks:
            step, capture, runtime = b["step"], b["capture"], b["runtime"]
            fp = capture["fingerprint"]
            require(b["epoch"] == row["epoch"] == runtime["mapping_epoch"]
                    and b["generation"] == runtime["generation_id"] and runtime["step"] == step
                    and list(runtime["ordered_request_fingerprint"]) == row["request_ids"],
                    "actual carrier/runtime identity")
            require(fp["method"] == "eagle3" and fp["query_width"] == (4 if step == 0 else 1)
                    and fp["route"] == ("eagle3_first_pass" if step == 0 else "eagle3_ar_step")
                    and capture["consumer_ordinal"] == (0 if step == 0 else step - 1)
                    and fp["capture_bucket"][1] == fp["capture_bucket"][0] * fp["query_width"],
                    "actual per-consumer capture identity")
            require(b["state"] == ("SUBMITTED" if first else "UPDATED"), "Host submission/update state")
            address = capture["backing_identity"]["window_block_table"]["data_ptr"]
            require(type(address) is int and address > 0, "actual backing address")
            addresses.append(address)
        selected = banks[0 if first else -1]
        require(len(set(addresses)) == len(banks)
                and row["selected_generation"] == selected["generation"]
                and row["selected_backing"] == addresses[0 if first else -1]
                and row["descriptor"] == selected["capture"]["fingerprint"]["capture_bucket"],
                "selected actual bank/descriptor")
        require(row["first_graph_replay_returned"] is (point != "before_replay")
                and row["current_manager_update_returned"] is (not first)
                and row["explicit_diagnostic_drain_complete"] is (point == "after_completion"),
                "replay/update/completion boundaries")
        require(type(row["host_materialize_stream"]) is int and type(row["update_stream"]) is int,
                "Host stream identities")
        require(document["process_isolation_required"] is True and document["host_quarantined"] is True
                and document["post_fault_device_operations"] == "NONE_BY_PROBE"
                and document["reuse"] == "FORBIDDEN_PROCESS_EXIT_73"
                and document["python_exception_unfolding"] == "NOT_EXERCISED"
                and document["native_corruption"] == "NOT_SIMULATED"
                and document["normal_overlap"] == "NOT_PROVEN", "process isolation scope")
        result.update(status="PASS_SCOPED_EAGLE3_ABORT_PROCESS_ISOLATION", point=point,
                      generations=generations, submission_scope=row["submission_scope"],
                      normal_overlap="NOT_PROVEN", native_partial_submission="NOT_SIMULATED")
    except (ValueError, KeyError, TypeError, IndexError) as error:
        result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def add_cases(cases, repo, output, python):
    for point in POINTS:
        source, name = "EAGLE3_G_ON", "ABORT_EAGLE3_" + point
        case = copy.deepcopy(cases[source])
        def clone(value):
            if isinstance(value, str):
                return value.replace(source, name)
            if isinstance(value, list):
                return [clone(v) for v in value]
            if isinstance(value, dict):
                return {k: clone(v) for k, v in value.items()}
            return value
        case = clone(case)
        for field in ("argv", "launch_argv"):
            case[field].extend(["--eagle3-abort", point])
        case.update(eagle3_abort_point=point, selection="OPT_IN_DISPOSABLE_EAGLE3_PROCESS_ABORT",
                    dependencies=["CONFIG_EAGLE3", source, "EAGLE3_LIFE"])
        case["validation_commands"] = [dict(kind="read_only_acceptance", timeout=120,
            argv=[python, str(repo / "tools/p7x_graph_repair35_eagle_abort.py"),
                  "--artifact", str(output / name / "eagle-abort.json"),
                  "--campaign", str(output / name / "abort-campaign.json"),
                  "--launcher", str(output / "launchers" / name / "launcher.json"),
                  "--plan", str(output / "case-plan.json"), "--case-id", name,
                  "--output", str(output / name / "eagle-abort-joint.json")])]
        cases[name] = case


def main():
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("artifact", "campaign", "launcher", "plan", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    result = check(json.loads(args.artifact.read_text()), json.loads(args.campaign.read_text()),
                   json.loads(args.launcher.read_text()),
                   json.loads(args.plan.read_text())["cases"][args.case_id], args.artifact)
    atomic_json(args.output, result)
    return 0 if result["status"] == "PASS_SCOPED_EAGLE3_ABORT_PROCESS_ISOLATION" else 4


if __name__ == "__main__":
    raise SystemExit(main())
