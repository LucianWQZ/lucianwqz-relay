#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Separate DFlash K15/Q16 anchor, never a DSpark fixture or full correctness verdict."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import sys
import time
from pathlib import Path

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair5_evidence import audit_execution, file_sha, require
from tools.p7x_graph_repair6_storage import atomic_json

ROOT = Path(__file__).resolve().parents[1]


def configure(base, arm):
    require(arm in ("G_OFF", "G_ON", "E_ON"), "DFlash arm")
    config = copy.deepcopy(base)
    config["max_model_len"] = 8192
    config["compilation_config"]["cudagraph_capture_sizes"] = [16, 32, 64]
    config["speculative_config"].update(method="dflash", num_speculative_tokens=15, enforce_eager=arm == "E_ON")
    config["additional_config"] = {} if arm == "G_OFF" else {"draft_window_size": 1024}
    config["per_request_spec_decode_metrics"] = "detailed"
    require(
        config["enforce_eager"] is False and not config["async_scheduling"] and not config["enable_prefix_caching"],
        "anchor frozen Target/topology policy",
    )
    return config


def validate_counts(value):
    drafted, accepted = value["per_step_drafted"], value["per_step_accepted"]
    require(value["num_spec_tokens"] == 15 and len(value["acceptance_histogram"]) == 16, "DFlash K15 metrics")
    require(drafted and len(drafted) == len(accepted), "actual method steps")
    require(
        all(type(d) is int and type(a) is int and 0 <= a <= d <= 15 and d > 0 for d, a in zip(drafted, accepted)),
        "method scheduled lengths",
    )
    require([accepted.count(i) for i in range(16)] == value["acceptance_histogram"], "method histogram")
    require(
        value["num_draft_tokens"] == sum(drafted)
        and value["num_accepted_draft_tokens"] == sum(accepted)
        and value["num_spec_steps"] == len(drafted),
        "method totals",
    )
    require(
        abs(value["draft_acceptance_rate"] - sum(accepted) / sum(drafted)) < 1e-12
        and abs(value["mean_acceptance_length"] - (1 + sum(accepted) / len(drafted))) < 1e-12,
        "method rates and bonus definition",
    )
    return dict(proposed=sum(drafted), accepted=sum(accepted), verification_request_steps=len(drafted))


def check(document, campaign, launcher, expected, artifact):
    result = audit_execution(document, campaign, launcher, expected, artifact)
    if result["status"] != "EXECUTION_ASSOCIATED":
        return result
    try:
        require(campaign["method"] == "dflash" and campaign["query_width"] == 16, "actual DFlash route/Q")
        require(
            campaign["speculator"] == "vllm_ascend.worker.v2.spec_decode.dflash.speculator.AscendDFlashSpeculator",
            "actual method speculator",
        )
        arm = expected["method_anchor_arm"]
        require(
            campaign["arm"] == arm and campaign["llm_kwargs"]["speculative_config"]["method"] == "dflash",
            "method arm/config",
        )
        require(campaign["fixture_sha256"] == expected["method_fixture_sha256"], "separate method fixture")
        config = campaign["llm_kwargs"]
        require(
            config["enforce_eager"] is False
            and config["speculative_config"]["num_speculative_tokens"] == 15
            and config["speculative_config"]["enforce_eager"] is (arm == "E_ON")
            and config["compilation_config"]["cudagraph_capture_sizes"] == [16, 32, 64]
            and config["additional_config"] == ({} if arm == "G_OFF" else {"draft_window_size": 1024}),
            "separate method actual configuration",
        )
        require(campaign["observer_enabled"] is False, "method heavy observer off")
        requests = json.loads(Path(expected["request_path"]).read_text())
        require(
            file_sha(Path(expected["request_path"])) == expected["requests_sha256"]
            and campaign["request_manifest"]["entries"] == requests,
            "method actual request bytes",
        )
        require(
            campaign["observer_installation"]["enabled"] is False
            and (campaign["observer_installation"]["installed"] if arm == "G_ON" else True),
            "actual observer/session state",
        )
        calls = [x for x in document["calls"] if x["active"]]
        drafts = [x for x in calls if x["label"] == "Draft_REPLAY_SUBMIT"]
        targets = [x for x in calls if x["label"] == "Target_REPLAY_SUBMIT"]
        require(bool(targets) and (not drafts if arm == "E_ON" else bool(drafts)), "method actual dispatch")
        target_keys = {(x["num_reqs"], x["num_tokens"]) for x in campaign["target_inventory"]["graphs"]}
        require({(1, 16), (2, 32), (4, 64)} <= target_keys, "method actual Target capture inventory")
        require({(1, 16), (4, 64)} <= {tuple(x["descriptor"]) for x in targets}, "method real Target1/4 replay")
        if arm != "E_ON":
            require({(1, 16), (4, 64)} <= {tuple(x["descriptor"]) for x in drafts}, "method real Draft1/4 replay")

        if arm != "E_ON":
            inventory = {(x["num_reqs"], x["num_tokens"]) for x in campaign["draft_inventory"]["graphs"]}
            require({(1, 16), (2, 32), (4, 64)} <= inventory, "DFlash capture inventory")
        require(len(campaign["outputs"]) == 3, "declared method groups")
        counts = []
        for output, request in zip(campaign["outputs"], requests):
            require(
                output["label"] == request["label"] and output["prompts"] == request["prompts"],
                "method request content",
            )
            require(len(output["token_ids"]) == len(output["prompts"]) == len(output["metrics"]), "method requests")
            require(all(len(t) == 64 for t in output["token_ids"]), "separate anchor output length")
            require(
                launcher["host_start_ns"] <= output["start_ns"] < output["end_ns"] <= launcher["host_end_ns"],
                "method request execution interval",
            )
            counts.extend(validate_counts(x["speculative_decoding"]) for x in output["metrics"])
        if arm != "G_OFF":
            state = campaign["outputs"][-1]["window_identity"]
            require(
                state
                and any(
                    d["source_start_column"] * 128 + d["first_token_offset"] > 0 for d in state["read_descriptors"]
                ),
                "method real Window S>0",
            )
            require(
                any(
                    x["label"] == "Draft_retire_host"
                    and x.get("generation") == state["generation"]
                    and x.get("mapping_epoch") == state["epoch"]
                    and x.get("request_group") == campaign["outputs"][-1]["label"]
                    and campaign["outputs"][-1]["start_ns"]
                    <= x["start_ns"]
                    < x["end_ns"]
                    <= campaign["outputs"][-1]["end_ns"]
                    for x in calls
                ),
                "method Host identity association",
            )
        result.update(
            status="PASS_SCOPED_DFLASH_K15_Q16_ANCHOR",
            arm=arm,
            counts=counts,
            draft_replays=len(drafts),
            target_replays=len(targets),
            numeric="NOT_ASSESSED",
            full_target_invariants="NOT_ASSESSED",
            normal_completion="SOURCE_CONTRACT_REVIEW_SEPARATE",
            physical_read="NOT_PROVEN",
        )
    except (ValueError, KeyError, TypeError, IndexError) as error:
        result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def configuration(args):
    from tools.p7x_graph_repair2 import build_llm_kwargs
    from tools.p7x_graph_repair2 import parse_args as base_parser

    require(file_sha(args.fixture) == args.fixture_sha256, "method immutable fixture before config/model")
    fixture = json.loads(args.fixture.read_text())
    base = base_parser(
        [
            "run",
            "--case",
            args.case,
            "--case-id",
            args.case_id,
            "--run-id",
            args.run_id,
            "--attempt",
            args.attempt,
            "--expected-sha",
            args.expected_sha,
            "--target-model",
            fixture["target_model"],
            "--draft-model",
            fixture["draft_model"],
            "--vllm-repo",
            str(args.vllm_repo),
            "--fixture-manifest",
            str(args.fixture),
            "--output",
            str(args.output),
            "--repair5-capture-profile",
            "target4",
            "--repair5-profile",
            "control",
            "--repair10-performance-arm",
            args.arm,
        ]
    )
    return base, configure(build_llm_kwargs(base), args.arm)


def add_cases(cases, inputs, output, repo, python):
    fixture, request = inputs / "dflash-k15-q16-fixture.json", inputs / "requests/dflash-k15-q16-anchor.json"
    if not fixture.exists() or not request.exists():
        return
    fixture_sha, request_sha = file_sha(fixture), file_sha(request)
    for arm in ("G_OFF", "G_ON", "E_ON"):
        name, mode = "METHOD_DFLASH_" + arm, "A0" if arm == "G_OFF" else "B-observer-off"
        case = copy.deepcopy(cases["A0"])
        case["argv"] = [
            python,
            str(repo / "tools/p7x_graph_repair11_method_anchor.py"),
            "run",
            "--run-id",
            case["acceptance_identity"]["run_id"],
            "--case-id",
            name,
            "--attempt",
            "1",
            "--expected-sha",
            case["acceptance_identity"]["source_sha"],
            "--case",
            mode,
            "--arm",
            arm,
            "--fixture",
            str(fixture),
            "--fixture-sha256",
            fixture_sha,
            "--requests",
            str(request),
            "--vllm-repo",
            cases["A0"]["argv"][cases["A0"]["argv"].index("--vllm-repo") + 1],
            "--output",
            str(output / name),
        ]
        prefix = case["launch_argv"][: case["launch_argv"].index("--") + 1]
        prefix = [v.replace(str(output / "A0"), str(output / name)) for v in prefix]
        prefix[prefix.index("--output") + 1] = str(output / "launchers" / name)
        prefix[prefix.index("--case-id") + 1] = name
        prefix[prefix.index("--mode") + 1] = mode
        prefix[prefix.index("--timeout") + 1] = "900"
        case["launch_argv"] = prefix + case["argv"]
        case["acceptance_identity"].update(case_id=name, driver_mode=mode)
        case.update(
            case_id=name,
            outputs=str(output / name),
            timeout_seconds=900,
            dependencies=["CONFIG_DFLASH"],
            request_path=str(request),
            requests_sha256=request_sha,
            method_anchor_arm=arm,
            method_fixture_sha256=fixture_sha,
            capture_profile="dflash_k15_q16",
            numeric_samples=None,
            selection="OPT_IN_SEPARATE_DFLASH_METHOD_ANCHOR",
        )
        case["validation_commands"] = [
            dict(
                kind="read_only_acceptance",
                timeout=180,
                argv=[
                    python,
                    str(repo / "tools/p7x_graph_repair11_method_anchor.py"),
                    "check",
                    "--profile",
                    str(output / name / "profile.json"),
                    "--campaign",
                    str(output / name / "campaign.json"),
                    "--launcher",
                    prefix[prefix.index("--output") + 1] + "/launcher.json",
                    "--plan",
                    str(output / "case-plan.json"),
                    "--case-id",
                    name,
                    "--output",
                    str(output / name / "method-joint.json"),
                ],
            )
        ]
        cases[name] = case
    cases["CONFIG_DFLASH"] = dict(
        argv=[
            python,
            str(repo / "tools/p7x_graph_repair11_method_anchor.py"),
            "config",
            "--plan",
            str(output / "case-plan.json"),
            "--output",
            str(output / "DFlash_Config_Matrix.json"),
        ],
        timeout_seconds=300,
        dependencies=[],
        validation_commands=[],
        selection="MODEL_FREE_DFLASH_FRAMEWORK_CONFIG",
        requires_device_admission=True,
    )


def run(args):
    from tools.p7x_graph_repair2 import (
        PINNED_VLLM,
        PINNED_VLLM_TREE,
        _git,
        _manager_inventory,
        configure_run_environment,
    )
    from tools.p7x_graph_repair5_profile import RequestProfiler, warmup_requests
    from tools.p7x_graph_repair10_performance import final_window_state, request_metrics

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    sha, tree = _git(ROOT, "rev-parse", "HEAD"), _git(ROOT, "rev-parse", "HEAD^{tree}")
    require(sha == args.expected_sha and not _git(ROOT, "status", "--porcelain"), "method clean exact source")
    require(
        _git(args.vllm_repo, "rev-parse", "HEAD") == PINNED_VLLM
        and _git(args.vllm_repo, "rev-parse", "HEAD^{tree}") == PINNED_VLLM_TREE
        and not _git(args.vllm_repo, "status", "--porcelain"),
        "method unchanged vLLM pin",
    )
    require(file_sha(args.fixture) == args.fixture_sha256, "method immutable fixture before model load")
    fixture = json.loads(args.fixture.read_text())
    require(fixture["schema"] == "r4-dflash-k15-q16-fixture-v1", "not a DSpark fixture")
    require(len(fixture["files"]) >= 9, "complete separate target/draft fixture inventory")
    for entry in fixture["files"]:
        path = Path(entry["path"])
        require(
            path.stat().st_size == entry["bytes"] and file_sha(path) == entry["sha256"], "method fixture bytes/hash"
        )
    entries = json.loads(args.requests.read_text())
    require(len(entries) == 3 and all(x["max_tokens"] == 64 for x in entries), "independent anchor requests")
    base, config = configuration(args)
    configure_run_environment(base, output)
    import vllm
    from vllm import LLM, SamplingParams

    import vllm_ascend

    identity = dict(
        run_id=args.run_id,
        case_id=args.case_id,
        attempt_id=args.attempt,
        driver_mode=args.case,
        source_sha=sha,
        source_tree=tree,
        vllm_sha=PINNED_VLLM,
        process_id=os.getpid(),
        engine_id=None,
    )
    record = dict(
        identity=identity,
        method="dflash",
        arm=args.arm,
        status="STARTED",
        startup_complete=False,
        llm_kwargs=config,
        config_sha256=hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest(),
        fixture_sha256=file_sha(args.fixture),
        fixture=fixture,
        observer_enabled=False,
        outputs=[],
        request_manifest=dict(sha256=file_sha(args.requests), entries=entries),
        imports=dict(vllm=vllm.__file__, vllm_ascend=vllm_ascend.__file__),
    )
    llm = probe = spec = None
    atomic_json(output / "progress.json", dict(identity=identity, phase="BEFORE_STARTUP"))
    try:
        llm = LLM(**config)
        core = llm.llm_engine.engine_core.engine_core
        runner = core.model_executor.driver_worker.worker.model_runner
        spec = runner.speculator
        identity["engine_id"] = id(core)
        record.update(
            model_runner=f"{type(runner).__module__}.{type(runner).__name__}",
            speculator=f"{type(spec).__module__}.{type(spec).__name__}",
            query_width=spec.num_query_per_req,
            draft_inventory=_manager_inventory(spec.query_cudagraph_manager),
            target_inventory=_manager_inventory(runner.cudagraph_manager),
            startup_complete=True,
        )
        record["draft_backbone"] = f"{type(spec.model).__module__}.{type(spec.model).__name__}"
        record["draft_backbone_source"] = getattr(sys.modules.get(type(spec.model).__module__), "__file__", None)
        session = getattr(spec, "_draft_window_graph_characterization", None)
        record["observer_installation"] = dict(
            installed=session is not None, enabled=session.recorder.enabled if session is not None else False
        )
        require(spec.num_query_per_req == 16 and record["speculator"].endswith(".AscendDFlashSpeculator"), "DFlash Q16")
        atomic_json(output / "progress.json", dict(identity=identity, phase="STARTUP_COMPLETE"))
        with RequestProfiler(runner, output, identity, enabled=False) as probe:
            warmup_requests(llm, SamplingParams, entries, probe, all_groups=True)
            probe.begin_active()
            for entry in entries:
                start = time.monotonic_ns()
                with probe.group(entry["label"]):
                    results = llm.generate(
                        entry["prompts"],
                        SamplingParams(temperature=0.0, seed=0, ignore_eos=True, max_tokens=64),
                        use_tqdm=False,
                    )
                end = time.monotonic_ns()
                record["outputs"].append(
                    dict(
                        label=entry["label"],
                        prompts=entry["prompts"],
                        token_ids=[x.outputs[0].token_ids for x in results],
                        metrics=request_metrics(results),
                        start_ns=start,
                        end_ns=end,
                        window_identity=final_window_state(spec),
                    )
                )
        record["status"] = "OK"
    except BaseException as error:
        record.update(status="EXCEPTION", exception_type=type(error).__name__, exception_message=str(error))
    finally:
        uncertain = bool(getattr(spec, "_draft_window_graph_submission_uncertain", False))
        record["graph_submission_uncertain"] = uncertain
        record["method_isolation_required"] = record["status"] != "OK"
        path = output / "profile.json"
        if path.exists():
            record["diagnostic_artifacts"] = {path.name: dict(bytes=path.stat().st_size, sha256=file_sha(path))}
        atomic_json(output / "campaign.json", record)
        if uncertain or record["method_isolation_required"]:
            record["diagnostic_quarantine"] = "PROCESS_EXIT_74_NO_REUSE"
            atomic_json(output / "campaign.json", record)
            os._exit(74)
        if llm is not None:
            try:
                llm.llm_engine.engine_core.shutdown()
            except Exception as error:
                record["cleanup_error"] = repr(error)
                atomic_json(output / "campaign.json", record)
    return 0 if record["status"] == "OK" and not record.get("cleanup_error") else 2


def parse_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    a = sub.add_parser("run")
    for name in ("run-id", "case-id", "attempt", "expected-sha", "case", "arm", "fixture-sha256"):
        a.add_argument("--" + name, required=True)
    for name in ("fixture", "requests", "vllm-repo", "output"):
        a.add_argument("--" + name, type=Path, required=True)
    c = sub.add_parser("config")
    c.add_argument("--plan", type=Path, required=True)
    c.add_argument("--output", type=Path, required=True)
    a = sub.add_parser("check")
    for name in ("profile", "campaign", "launcher", "plan", "output"):
        a.add_argument("--" + name, type=Path, required=True)
    a.add_argument("--case-id", required=True)
    return p.parse_args(argv)


def main():
    args = parse_args()
    if args.command == "config":
        from tools.p7x_graph_repair7 import config_matrix

        plan = json.loads(args.plan.read_text())
        plan["cases"] = {k: v for k, v in plan["cases"].items() if k.startswith("METHOD_DFLASH_")}
        result = config_matrix(plan, framework=True, include_method_anchors=True)
        atomic_json(args.output, result)
        return 0 if result["status"] == "CONFIGS_VALID" else 4
    if args.command == "run":
        return run(args)
    result = check(
        *[json.loads(q.read_text()) for q in (args.profile, args.campaign, args.launcher)],
        json.loads(args.plan.read_text())["cases"][args.case_id],
        args.profile,
    )
    atomic_json(args.output, result)
    return 0 if result["status"] == "PASS_SCOPED_DFLASH_K15_Q16_ANCHOR" else 4


if __name__ == "__main__":
    raise SystemExit(main())
