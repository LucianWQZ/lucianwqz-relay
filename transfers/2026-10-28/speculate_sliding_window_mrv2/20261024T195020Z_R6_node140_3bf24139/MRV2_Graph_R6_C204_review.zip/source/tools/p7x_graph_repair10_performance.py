#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Independent bounded 256/512-token performance contract; frozen checks unchanged.

Acceptance comes from the pinned scheduler's response metrics, after its normal
sample transfer. This tool adds no device read, event query or synchronization.
Graph/eager applies only to Draft; Target remains FULL_DECODE_ONLY in every arm.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from dataclasses import asdict, is_dataclass
from pathlib import Path

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.p7x_graph_repair5_evidence import audit_execution
from tools.p7x_graph_repair6_storage import atomic_json, require


def configure(config, args):
    arm = args.repair10_performance_arm
    require(args.case == ("A0" if arm == "G_OFF" else "B-observer-off"), "performance driver/arm mismatch")
    require(args.repair5_capture_profile == "target4", "performance requires independent Target4 profile")
    require(args.repair5_profile in ("control", "normal"), "performance requires normal bounded request observer")
    if getattr(args, "repair18_long_context", False):
        from tools.p7x_graph_repair18_long_context import validate_model_capacity
        validate_model_capacity(args)
    else:
        require(4096 <= args.repair10_max_model_len <= 16384, "bounded performance max length")
    require(
        not any(
            getattr(args, k, False)
            for k in (
                "target_probe",
                "full_target_probe",
                "repair5_lifecycle",
                "repair5_controlled_target",
                "repair5_controlled_mrv2",
                "repair6_numeric_reference",
                "repair6_target_store",
                "repair6_normal_lifecycle",
                "repair10_metadata_unwind",
                "repair10_metadata_store_unwind",
                "repair8_task_dump",
                "repair9_materialize_unwind",
            )
        ),
        "performance cannot include heavy diagnostics",
    )
    config["max_model_len"] = args.repair10_max_model_len
    config["speculative_config"]["enforce_eager"] = arm == "E_ON"
    config["per_request_spec_decode_metrics"] = "detailed"
    require(config["enforce_eager"] is False, "Target execution policy must remain Graph")


def request_metrics(results):
    records = []
    for result in results:
        value = getattr(result.outputs[0], "spec_decode_metrics", None)
        timing = getattr(result, "metrics", None)
        records.append(
            dict(
                request_id=result.request_id,
                finished=result.finished,
                finish_reason=result.outputs[0].finish_reason,
                speculative_decoding=value.to_dict() if value is not None else None,
                timing=asdict(timing) if is_dataclass(timing) else None,
                unavailable_reason=None if value is not None else "PINNED_RESPONSE_METRICS_NOT_PRESENT",
            )
        )
    return records


def final_window_state(speculator):
    """Read immutable Host identity after generate; never read a device tensor.

    This proves only that an actual materialized proposal used S>0. It is not
    device completion, an execution-occurrence link or a physical read-set.
    Captured after the request elapsed interval, equally for Graph/eager ON.
    """
    runtime = getattr(speculator, "_draft_window_runtime_state", None)
    identity = getattr(runtime, "_last_retired_identity", None)
    if identity is None:
        return None
    return dict(
        generation=identity.generation_id,
        epoch=identity.mapping_epoch,
        active=identity.actual_request_count,
        padded=identity.padded_request_count,
        read_descriptors=[asdict(d) for d in identity.read_descriptor_fingerprint],
        evidence_kind="HOST_MATERIALIZED_IDENTITY_NOT_DEVICE_COMPLETION",
    )


def acceptance_counts(metrics):
    """Cross-check detailed values against the pinned response histogram.

    Draft acceptance excludes the bonus; mean acceptance length includes it.
    Proposed counts are actual scheduled lengths (not padded bucket * K).
    """
    h = metrics["acceptance_histogram"]
    drafted, accepted = metrics["per_step_drafted"], metrics["per_step_accepted"]
    require(len(h) == 8 and all(type(n) is int and n >= 0 for n in h), "acceptance histogram")
    require(len(drafted) == len(accepted) == sum(h) and bool(drafted), "acceptance step coverage")
    require(
        all(type(d) is int and type(a) is int and 0 <= a <= d <= 7 and d > 0 for d, a in zip(drafted, accepted)),
        "actual draft/accepted lengths",
    )
    require([accepted.count(i) for i in range(8)] == h, "histogram/detailed contradiction")
    d, a, n = sum(drafted), sum(accepted), len(drafted)
    require(
        metrics["num_draft_tokens"] == d
        and metrics["num_accepted_draft_tokens"] == a
        and metrics["num_spec_steps"] == n
        and metrics["num_spec_tokens"] == 7,
        "acceptance counters",
    )
    require(abs(metrics["draft_acceptance_rate"] - a / d) < 1e-12, "draft acceptance rate")
    require(abs(metrics["mean_acceptance_length"] - (1 + a / n)) < 1e-12, "bonus acceptance length")
    return dict(
        proposed_draft_tokens=d,
        accepted_draft_tokens=a,
        verification_request_steps=n,
        proposed_per_position=[sum(v > i for v in drafted) for i in range(7)],
        accepted_per_position=[sum(v > i for v in accepted) for i in range(7)],
    )


def check(campaign, launcher, profile, expected, artifact):
    result = audit_execution(profile, campaign, launcher, expected, artifact)
    if result["status"] != "EXECUTION_ASSOCIATED":
        return result
    try:
        requests = json.loads(Path(expected["request_path"]).read_bytes())
        require(
            hashlib.sha256(Path(expected["request_path"]).read_bytes()).hexdigest() == expected["requests_sha256"],
            "performance request hash",
        )
        require(campaign["request_manifest"]["entries"] == requests, "performance request content")
        require([r["label"] for r in requests] == [r["label"] for r in campaign["outputs"]], "all request groups")
        arm = expected["performance_arm"]
        if expected.get("long_context_profile") is not None:
            require(campaign["llm_kwargs"]["max_model_len"] == expected["long_context_profile"]["max_model_len"],
                    "actual long-context model limit")
            require("--repair18-long-context" in expected["argv"], "explicit long-context admission flag")
        config = campaign["llm_kwargs"]
        actual_config_hash = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
        require(actual_config_hash == campaign["config_sha256"] == expected["expected_llm_kwargs_sha256"],
                "actual performance kwargs differ from independently prepared case")
        require(
            config["enforce_eager"] is False and config["speculative_config"]["enforce_eager"] == (arm == "E_ON"),
            "Target/Draft execution policy",
        )
        require(config["compilation_config"]["cudagraph_capture_sizes"] == [7, 14, 28, 32], "Target4 profile")
        require(
            config["additional_config"].get("draft_window_size") == (None if arm == "G_OFF" else 1024), "Window arm"
        )
        require(
            config["additional_config"].get("draft_window_graph_single_metadata", False)
            is expected.get("single_metadata_experiment", False),
            "single-metadata prototype must have its own declared configuration identity",
        )
        require(config["additional_config"].get("draft_window_graph_validation_memo", False)
                is expected.get("validation_memo_experiment", False),
                "header memo must have its own declared configuration identity")
        if expected.get("validation_memo_experiment", False):
            require(campaign["provider_installed"] is True
                    and campaign["observer_installation"].get("validation_identity_memo_enabled") is True,
                    "header memo was not enabled on the actual provider")
        require(not campaign["observer_installation"]["recorder_enabled"], "heavy observer must be off")
        require(
            campaign["warmup"].get("policy") == "ALL_DECLARED_GROUPS"
            and len(campaign["warmup"]["groups"]) == len(requests),
            "all-group warmup",
        )
        active = [c for c in profile["calls"] if c["active"]]
        draft_replays = [c for c in active if c["label"] == "Draft_REPLAY_SUBMIT"]
        target_replays = [c for c in active if c["label"] == "Target_REPLAY_SUBMIT"]
        require(bool(target_replays), "actual Target Graph replay missing")
        require(not draft_replays if arm == "E_ON" else bool(draft_replays), "actual Draft execution mode")
        cropped = any(
            d["source_start_column"] * 128 + d["first_token_offset"] > 0
            for c in active
            for d in c.get("window_descriptors", [])
        )
        # Eager's descriptors are reported separately below; absence is explicit.
        if arm == "G_ON" and expected["performance_workload"] == "long":
            require(cropped, "actual Window crop S>0 missing")
        cells = []
        for request, output in zip(requests, campaign["outputs"]):
            require(request["max_tokens"] in (256, 512), "independent output token contract")
            require(output["prompts"] == request["prompts"], "request prompts")
            require(
                launcher["host_start_ns"] <= output["host_start_ns"] < output["host_end_ns"] <= launcher["host_end_ns"],
                "request clock/launch interval",
            )
            count = len(request["prompts"])
            require(
                len(output["token_ids"])
                == len(output["prompt_token_ids"])
                == len(output["performance_metrics"])
                == count,
                "request cardinality",
            )
            measurements = []
            for submitted, prompt, tokens, response in zip(
                request["prompts"], output["prompt_token_ids"], output["token_ids"], output["performance_metrics"]
            ):
                require(prompt and all(type(t) is int and t >= 0 for t in prompt), "input tokens")
                if isinstance(submitted, dict):
                    require(prompt == submitted["prompt_token_ids"], "actual input token IDs differ from submitted workload")
                require(
                    len(tokens) == request["max_tokens"] and all(type(t) is int and t >= 0 for t in tokens),
                    "output tokens",
                )
                require(response["finished"] is True, "unfinished request")
                measurements.append(acceptance_counts(response["speculative_decoding"]))
            elapsed = (output["host_end_ns"] - output["host_start_ns"]) / 1e9
            cells.append(
                dict(
                    label=request["label"],
                    requests=count,
                    input_tokens=sum(map(len, output["prompt_token_ids"])),
                    output_tokens=sum(map(len, output["token_ids"])),
                    elapsed_seconds=elapsed,
                    output_tokens_per_second=sum(map(len, output["token_ids"])) / elapsed,
                    acceptance=measurements,
                )
            )
        eager_crops = []
        if arm == "E_ON" and expected["performance_workload"] == "long":
            for output in campaign["outputs"]:
                state = output["window_runtime_after_request"]
                require(
                    state["evidence_kind"] == "HOST_MATERIALIZED_IDENTITY_NOT_DEVICE_COMPLETION"
                    and state["generation"] >= 0
                    and state["epoch"] >= 0,
                    "actual eager Window identity",
                )
                require(0 < state["active"] <= state["padded"] <= 4, "eager active/padded identity")
                require(
                    any(
                        c["label"] == "Draft_retire_host"
                        and c.get("request_group") == output["label"]
                        and c.get("generation") == state["generation"]
                        and c.get("mapping_epoch") == state["epoch"]
                        and output["host_start_ns"] <= c["start_ns"] < c["end_ns"] <= output["host_end_ns"]
                        for c in active
                    ),
                    "eager identity not from this measured request",
                )
                eager_crops.append(
                    any(d["source_start_column"] * 128 + d["first_token_offset"] > 0 for d in state["read_descriptors"])
                )
            require(any(eager_crops), "actual eager Window crop S>0 missing")
        result.update(
            status="PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE",
            arm=arm,
            cells=cells,
            draft_replays=len(draft_replays),
            target_replays=len(target_replays),
            actual_graph_window_crop=cropped,
            actual_eager_window_crop=any(eager_crops) if eager_crops else None,
            physical_read="NOT_PROVEN",
            numeric="NOT_ASSESSED",
            normal_completion="SOURCE_CONTRACT_REVIEW_SEPARATE",
        )
    except (ValueError, KeyError, TypeError, OSError, IndexError) as error:
        result.update(status="INVALID_EVIDENCE", error=str(error))
    return result


def add_cases(cases, inputs, output, repo, python):
    for workload in ("short", "long", "natural", "stability"):
        request = inputs / f"requests/performance10-{workload}.json"
        if not request.exists():
            continue
        rows = json.loads(request.read_text())
        require(rows and len({r["label"] for r in rows}) == len(rows), "unique performance groups")
        if workload == "stability":
            require(len(rows) <= 24, "bounded stability group count")
        require(all(r["max_tokens"] in (256, 512) and 1 <= len(r["prompts"]) <= 4 for r in rows), "bounded workload")
        for arm in ("G_OFF", "G_ON", "E_ON"):
            for repeat in range(1, 5):
                source = "PROFILE_OFF_long_control" if arm == "G_OFF" else "PROFILE_ON_long_control"
                name = f"PERF10_{arm}_{workload}_{repeat:02}" if repeat < 4 else f"PROFILE10_{arm}_{workload}"
                old = cases[source]

                def replace(value, source=source, name=name, old_request=old["request_path"], request=request):
                    if isinstance(value, str):
                        return value.replace(source, name).replace(old_request, str(request))
                    if isinstance(value, list):
                        return [replace(v) for v in value]
                    if isinstance(value, dict):
                        return {k: replace(v) for k, v in value.items()}
                    return value

                case = replace(copy.deepcopy(old))
                for field in ("argv", "launch_argv"):
                    values = case[field]
                    values[values.index("--repair5-profile") + 1] = "control" if repeat < 4 else "normal"
                    values.extend(
                        [
                            "--repair10-performance-arm",
                            arm,
                            "--repair10-max-model-len",
                            "12288",
                            "--repair9-warmup-all",
                            "--repair5-capture-profile",
                            "target4",
                        ]
                    )
                    if repeat == 4 and arm == "G_ON":
                        values.append("--repair8-materialize-ranges")
                case.update(
                    request_path=str(request),
                    requests_sha256=hashlib.sha256(request.read_bytes()).hexdigest(),
                    outputs=str(output / name),
                    performance_arm=arm,
                    performance_workload=workload,
                    performance_repetition=repeat if repeat < 4 else None,
                    selection="OPT_IN_BOUNDED_PERFORMANCE10_NOT_FROZEN_NUMERIC",
                )
                case["validation_commands"] = [
                    dict(
                        kind="read_only_acceptance",
                        timeout=120,
                        argv=[
                            python,
                            str(repo / "tools/p7x_graph_repair10_performance.py"),
                            "--campaign",
                            str(output / name / "campaign.json"),
                            "--profile",
                            str(output / name / "profile.json"),
                            "--launcher",
                            str(output / "launchers" / name / "launcher.json"),
                            "--plan",
                            str(output / "case-plan.json"),
                            "--case-id",
                            name,
                            "--output",
                            str(output / name / "performance-joint.json"),
                        ],
                    )
                ]
                case.pop("check_argv", None)
                case.pop("additional_checks", None)
                cases[name] = case


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("campaign", "profile", "launcher", "plan", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    profile = json.loads(args.profile.read_text())
    result = check(
        json.loads(args.campaign.read_text()),
        json.loads(args.launcher.read_text()),
        profile,
        json.loads(args.plan.read_text())["cases"][args.case_id],
        args.profile,
    )
    atomic_json(args.output, result)
    return 0 if result["status"] == "PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE" else 4


if __name__ == "__main__":
    raise SystemExit(main())
