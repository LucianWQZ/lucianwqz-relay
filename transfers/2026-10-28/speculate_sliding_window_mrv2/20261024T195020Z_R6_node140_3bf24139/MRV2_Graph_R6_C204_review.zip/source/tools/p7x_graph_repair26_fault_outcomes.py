# SPDX-License-Identifier: Apache-2.0
"""Host-only distinction between an accepted disposable Python fault and unknown failure.

An accepted fault permits a fresh process for the next planned case. It never
permits recovery, completion claims or reuse of the old process/backing.
"""
from pathlib import Path


def expected_parallel_python_isolation(case, campaign, launcher, checker, runner, *, artifact_sha256,
                                       old_process_gone, old_device_pid_absent):
    result = dict(status="NOT_ESTABLISHED", allow_fresh_process=False, old_backing_reuse="FORBIDDEN",
                  prior_device_completion="NOT_INFERRED", native_partial_submission="NOT_SIMULATED_BY_THIS_TEST")

    def require(value, message):
        if not value:
            raise ValueError(message)

    try:
        point = case.get("unwind_point")
        require(point in ("before_replay", "after_replay", "after_update", "after_completion"), "unknown fault point")
        require(case["case_id"] in (f"UNWIND_DSPARK_Q8_{point}", f"UNWIND_DFLASH_{point}", f"UNWIND_{point}"),
                "not a declared parallel Python fault case")
        argv = case["argv"]
        require(argv[argv.index("--repair8-unwind-at") + 1] == point, "planned injection point mismatch")
        require(campaign["exception_type"] == "InjectedGraphUnwindError"
                and campaign["exception_message"] == "REPAIR8_PYTHON_UNWIND:" + point,
                "not the planned Python injection")
        identity = campaign["identity"]
        expected = case["acceptance_identity"]
        require(all(identity[key] == expected[key] for key in (
            "run_id", "case_id", "attempt_id", "source_sha", "source_tree", "driver_mode")),
                "case/source/run identity mismatch")
        require(launcher["argv"] == argv and launcher["pid"] == identity["process_id"]
                and launcher["returncode"] == 74 and launcher["signal"] is None and launcher["timeout"] is False,
                "not the exact isolated child exit")
        require(runner["status"] == "SCOPED_COMMANDS_ACCEPTED" and runner["dependency_satisfied"] is True
                and runner["source_identity"] == [identity["run_id"],identity["source_sha"],identity["source_tree"]],
                "runner did not accept this source/run")
        require(any(record["returncode"] == 0 and not record["timeout"]
                    and any(Path(value).name == "p7x_graph_repair8_unwind.py" for value in record["argv"])
                    for record in runner["records"]), "dedicated Python isolation checker missing")
        require(checker["status"] == "PASS_SCOPED_PYTHON_UNWIND_ISOLATION" and checker["point"] == point
                and checker["native_partial_submission"] == "NOT_SIMULATED"
                and checker["execution"]["status"] == "EXECUTION_ASSOCIATED",
                "dedicated isolation verdict or execution association invalid")
        require(checker["execution"]["artifact_sha256"] == artifact_sha256
                == campaign["diagnostic_artifacts"]["python-unwind.json"]["sha256"], "fault artifact changed")
        require(old_process_gone is True and old_device_pid_absent is True,
                "old process/device PID not confirmed released")
        require(campaign["diagnostic_quarantine"] == "PROCESS_EXIT_74_NO_REUSE",
                "old process/backing isolation was not retained")
        result.update(status="EXPECTED_PYTHON_FAULT_PROCESS_ISOLATED", allow_fresh_process=True,
                      point=point, producer_sha=identity["source_sha"], producer_pid=identity["process_id"],
                      scope="Only next independent planned case; no old device state recovery or completion inference")
    except (ValueError,KeyError,TypeError,IndexError) as error:
        result["error"] = str(error)
    return result
