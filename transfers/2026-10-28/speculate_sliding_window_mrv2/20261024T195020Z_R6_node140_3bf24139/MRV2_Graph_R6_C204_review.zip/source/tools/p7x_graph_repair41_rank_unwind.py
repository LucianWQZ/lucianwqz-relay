# SPDX-License-Identifier: Apache-2.0
"""Explicit, disposable multi-rank Python failures; default product path unchanged.

A selected-rank rejection is before any new proposal. Real proposal unwind is
injected at the SAME point on ALL ranks, preserving collective call order. No
hardware corruption or unmatched one-rank native failure is simulated. After
failure only Host exports and process isolation are allowed, never device RPC,
drain, D2H, KV restore or reuse. The original R8 probe supplies the real C1 hook.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import hashlib
import json
import os
import time
import traceback
from types import MethodType
import uuid

from tools.p7x_graph_repair21_rank import (
    RankWorkerExtension, build_rank_kwargs, digest, isolate_failed_parent, require, validate_admission, write,
)
from tools.p7x_graph_repair8_unwind import POINTS, ProposalUnwindProbe

MODES = ("preparation_reject", "python_unwind")
PROFILES = {"qwen_target4": dict(k=7, query=7), "glm_k8": dict(k=8, query=8),
            "glm_k8_required": dict(k=8, query=8)}


def validate_payload(payload):
    require(payload["mode"] in MODES and payload["profile"] in PROFILES, "named rank-fault mode/profile required")
    require(type(payload["tp"]) is int and payload["tp"] in (2, 4, 16), "complete TP2/4/16 only")
    require(not payload["profile"].startswith("glm_") or payload["tp"] == 16,
            "GLM profile requires actual TP16")
    for key, size in (("nonce", 32), ("source_sha", 40)):
        value = payload[key]
        require(isinstance(value, str) and len(value) == size
                and all(char in "0123456789abcdef" for char in value), "exact source/nonce required")
    require(type(payload["parent_pid"]) is int and payload["parent_pid"] > 0
            and Path(payload["root"]).is_absolute(), "parent and absolute output required")
    require(all(isinstance(payload[key],str) and bool(payload[key]) for key in ['host','boot_id','namespace']),
            'explicit executing host/boot/namespace required')
    if payload["mode"] == "preparation_reject":
        require(type(payload["selected_rank"]) is int and 0 <= payload["selected_rank"] < payload["tp"]
                and payload["point"] is None, "selected rejection must precede proposals")
    else:
        require(payload["selected_rank"] is None and payload["point"] in POINTS,
                "native-path Python injection must apply to ALL ranks at the same point")


def fault_kwargs(profile, tp):
    require(profile in PROFILES and type(tp) is int and tp in (2, 4, 16), "named fixed rank profile required")
    if profile == "glm_k8_required":
        require(tp == 16, "joint GLM fault profile cannot lower TP")
        from tools.p7x_graph_repair55_glm_cp_numeric import build_kwargs
        kwargs = build_kwargs("ON", tp)
        kwargs["worker_extension_cls"] = "tools.p7x_graph_repair57_glm_joint_unwind.GLMJointUnwindWorker"
        return kwargs
    if profile == "glm_k8":
        require(tp == 16, "GLM fault profile cannot lower TP")
        from tools.p7x_graph_repair32_glm_rank import build_glm_kwargs
        kwargs = build_glm_kwargs(tp, window_on_review=True)
    else:
        kwargs = build_rank_kwargs(tp, window_on_review=True)
    kwargs["worker_extension_cls"] = "tools.p7x_graph_repair41_rank_unwind.RankUnwindWorker"
    return kwargs


class InjectedRankPreparationError(RuntimeError):
    pass


def already_initialized_soc_version(npu):
    """Optional applicability fact from the already admitted/initialized worker.

    Never initialize an unallocated default device to answer a platform query.
    This function is called only by the separate pre-fault Host RPC, never by
    capture/replay callbacks, normal performance or error-unwind code.
    """
    require(npu.is_initialized() is True, 'refuse a platform query that could initialize another device')
    value = npu.get_soc_version()
    require(type(value) is int, 'installed SoC API must return its actual integer code')
    return dict(api='torch_npu.npu.get_soc_version', value=value, already_initialized=True,
                scope='INSTALLED_API_APPLICABILITY_FACT_NOT_RUNTIME_BRANCH_OR_PHYSICAL_READ_PROOF')


def rank_host_error_export_barrier(payload, *, timeout=60):
    """Bounded Host-file coordination after errors; no device operation/RPC.

    Prevent the first escaping worker exception from killing peers before they
    export the same already-unwound fault. This is diagnostic coordination,
    never a normal completion edge or permission to submit more work.
    """
    require(type(timeout) in (int,float) and 0 < timeout <= 60, 'bounded Host export timeout required')
    paths = [Path(payload['root'])/f'rank-{rank}/terminal.json' for rank in range(payload['tp'])]
    deadline = time.monotonic()+timeout
    while not all(path.exists() for path in paths):
        if time.monotonic() >= deadline:
            return dict(status='HOST_EXPORT_TIMEOUT_ISOLATION_REQUIRED', present=[str(p) for p in paths if p.exists()],
                        native_completion='NOT_PROVEN', post_fault_device_operations='NONE')
        time.sleep(min(0.5,timeout))
    expected = {row['rank']:row for row in payload['worker_processes']}
    require(len(expected) == payload['tp'] and set(expected) == set(range(payload['tp'])),
            'complete pre-fault worker map required for Host export barrier')
    proofs=[]
    for rank,path in enumerate(paths):
        identity=json.loads(path.read_text())['identity']
        validate_fault_identity(identity,expected[rank],payload)
        proofs.append(dict(rank=rank,path=str(path),sha256=digest(path)))
    return dict(status='ALL_RANK_HOST_ERROR_EXPORTS_PRESENT_NOT_DEVICE_COMPLETION', proofs=proofs,
                native_completion='NOT_PROVEN', post_fault_device_operations='NONE')


def install_execute_error_export(runner, probe, terminal_path, identity, payload=None):
    """Observe only an exception AFTER the actual proposal scope unwinds."""
    # Pinned MRV2 can propose in sample_tokens after execute_model returns.
    # Cover both entry points, including nested calls, with one Host export.
    originals = {name: getattr(runner, name) for name in ("execute_model", "sample_tokens")}
    require(all(callable(method) for method in originals.values()), "both real runner entry points required")
    export_started = False

    def export_once(error, entrypoint):
        nonlocal export_started
        if export_started:
            return
        export_started = True
        for name, original in originals.items():
            setattr(runner, name, original)  # Host restoration; no model step.
        terminal = dict(identity=identity, exception_type=type(error).__name__,
                        exception_message=str(error), caught_ns=time.monotonic_ns(),
                        entrypoint=entrypoint, guarded_entrypoints=list(originals),
                        scope="HOST_ERROR_EXPORT_THEN_PROCESS_ISOLATION",
                        post_fault_device_operations="NONE_BY_THIS_WRAPPER")
        try:
            probe.__exit__(type(error), error, error.__traceback__)
        except BaseException as export_error:
            terminal["probe_export_error"] = repr(export_error)
        # The opt-in joint profile attaches existing CPU metadata-audit facts.
        # Serialization rejects non-JSON objects; never read tensors or run RPC.
        joint = getattr(probe, "required_feature_host_evidence", None)
        if isinstance(joint, dict):
            try:
                terminal["required_feature_host_evidence"] = json.loads(json.dumps(joint))
            except (TypeError, ValueError) as export_error:
                terminal["required_feature_export_error"] = str(export_error)
        try:
            write(terminal_path, terminal)
            if payload is not None:
                try:
                    barrier=rank_host_error_export_barrier(payload)
                except (ValueError,KeyError,OSError) as export_error:
                    barrier=dict(status='INVALID_PEER_HOST_EXPORT',error=repr(export_error))
                write(Path(terminal_path).parent/'host-error-barrier.json',barrier)
        except OSError as export_error:
            print("rank Host terminal export failed: " + repr(export_error), file=sys.stderr, flush=True)

    def guard(entrypoint):
        original = originals[entrypoint]

        def execute(_runner, *args, **kwargs):
            try:
                return original(*args, **kwargs)
            except BaseException as error:
                export_once(error, entrypoint)
                raise

        return MethodType(execute, runner)

    for name in originals:
        setattr(runner, name, guard(name))


class RankUnwindWorker(RankWorkerExtension):
    def mrv2_rank_unwind_identity(self, payload):
        validate_payload(payload)
        row = self.mrv2_rank_snapshot()  # Before faults; existing Host headers only.
        import torch_npu
        from tools.p7x_graph_repair39_service_identity import _loaded_module
        runner, spec = self.model_runner, self.model_runner.speculator
        names = ['vllm', 'vllm_ascend', type(self).__module__, type(runner).__module__, type(spec).__module__,
                 type(spec._draft_window_graph_binding_provider).__module__]
        require(row["world_size"] == row["tp_size"] == payload["tp"], "actual rank topology differs")
        row.update(nonce=payload["nonce"], source_sha=payload["source_sha"],
                   boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                   namespace=os.readlink('/proc/self/ns/mnt'),
                   runner_class=type(runner).__module__+'.'+type(runner).__qualname__,
                   soc_api=already_initialized_soc_version(torch_npu.npu),
                   module_sources=[_loaded_module(name) for name in dict.fromkeys(names)])
        root = Path(payload["root"])/f"rank-{row['rank']}"
        write(root/"identity.json", row)
        return row

    def mrv2_rank_arm_unwind(self, payload):
        validate_payload(payload)
        require(not hasattr(self, "_mrv2_rank_unwind_probe"), "rank-fault injection already armed")
        rank = self.rank
        identity = dict(rank=rank, world_size=payload["tp"], pid=os.getpid(),
                        process_start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                        nonce=payload["nonce"], source_sha=payload["source_sha"],
                        mode=payload["mode"], point=payload["point"])
        root = Path(payload["root"])/f"rank-{rank}"
        if payload["mode"] == "preparation_reject":
            rejected = rank == payload["selected_rank"]
            write(root/"preparation.json", dict(identity=identity,
                  status="INJECTED_BEFORE_NEW_PROPOSAL" if rejected else "PEER_HOST_PREPARATION_RETURNED",
                  new_proposal_submitted=False, exception="REPAIR41_PREPARATION:"+payload["nonce"] if rejected else None))
            if rejected:
                raise InjectedRankPreparationError("REPAIR41_PREPARATION:"+payload["nonce"])
            return identity
        spec = self.model_runner.speculator
        require(spec.method == "dspark" and spec.num_query_per_req == PROFILES[payload["profile"]]["query"],
                "actual parallel DSpark query differs")
        probe = ProposalUnwindProbe(spec, root/"unwind.json", identity, payload["point"])
        probe.__enter__()
        self._mrv2_rank_unwind_probe = probe  # Retain owners until process isolation.
        install_execute_error_export(self.model_runner, probe, root/"terminal.json", identity, payload)
        write(root/"armed.json", dict(identity=identity, status="ALL_RANK_SAME_POINT_ARMED",
                                     native_corruption=False, heavy_observer=False))
        return identity


def validate_worker_set(workers, payload, source, pin):
    validate_payload(payload)
    require(len(workers) == payload["tp"] and all(type(row["rank"]) is int for row in workers)
            and sorted(row["rank"] for row in workers) == list(range(payload["tp"])),
            "missing or duplicate actual worker rank")
    require(len({(row["pid"], row["process_start_ticks"]) for row in workers}) == payload["tp"],
            "reused worker PID/starttime across ranks")
    kwargs = fault_kwargs(payload['profile'], payload['tp'])
    for row in workers:
        require(row["nonce"] == payload["nonce"] and row["source_sha"] == payload["source_sha"]
                and type(row["pid"]) is int and row["pid"] > 0
                and isinstance(row["process_start_ticks"], str) and row["process_start_ticks"].isdigit()
                and row["world_size"] == row["tp_size"] == row["draft_tp_size"] == payload["tp"],
                "actual source/rank/process/topology identity differs")
        require(all(type(row[key]) is int for key in ['world_size','tp_size','draft_tp_size','logical_device'])
                and row['hostname'] == payload['host'] and row['boot_id'] == payload['boot_id']
                and row['namespace'] == payload['namespace'], 'actual worker host/boot/namespace or typed rank differs')
        require(Path(row["ascend_source"]).resolve().is_relative_to(Path(source).resolve())
                and Path(row["vllm_source"]).resolve().is_relative_to(Path(pin).resolve()), "worker imported another source")
        require(row["window_size"] == 1024 and row["window_provider_installed"] is True
                and row["heavy_observer_enabled"] is False and row["submission_uncertain"] is False,
                "normal observer-off Window owner not ready before injection")
        require(row['speculator_class'] == 'vllm_ascend.worker.v2.spec_decode.dspark.speculator.AscendDSparkSpeculator'
                and Path(row['draft_model_config']).resolve() == Path(kwargs['speculative_config']['model']).resolve(),
                'actual method/model differs from the named fault profile')
        modules = {entry['module']: entry for entry in row['module_sources']}
        require(len(modules) == len(row['module_sources']) and {'vllm', 'vllm_ascend'} <= modules.keys()
                and all(row[key].rsplit('.',1)[0] in modules for key in ['worker_class','runner_class','speculator_class']),
                'actual worker/runner/method module identity missing')
        for name, entry in modules.items():
            root = Path(pin if name == 'vllm' or name.startswith('vllm.') else source).resolve()
            require(name in ['vllm','vllm_ascend'] or name.startswith(('vllm.','vllm_ascend.','tools.')),
                    'unexpected worker module namespace')
            path = Path(entry['path'])
            require(path.is_absolute() and path.resolve().is_relative_to(root)
                    and type(entry['bytes']) is int and path.stat().st_size == entry['bytes']
                    and digest(path) == entry['sha256'], 'actual worker module source/hash differs')
        require(row["draft_graph_inventory"] and row["target_graph_inventory"], "actual Graph inventories missing")
    if payload['profile'] == 'glm_k8_required':
        from tools.p7x_graph_repair57_glm_joint_unwind import validate_joint_features
        validate_joint_features(workers)


def validate_unwind_document(document, terminal, worker, payload):
    identity = document["identity"]
    validate_fault_identity(identity, worker, payload)
    require(identity == terminal["identity"] and identity["rank"] == worker["rank"]
            and identity["pid"] == worker["pid"] and identity["process_start_ticks"] == worker["process_start_ticks"]
            and identity["nonce"] == payload["nonce"] and identity["source_sha"] == payload["source_sha"],
            "unwind record belongs to another process/invocation")
    point = payload["point"]
    require(document["schema"] == "repair8-python-unwind-v1" and document["point"] == point
            and document['status'] == 'HOST_EXPORTED_ISOLATION_REQUIRED'
            and type(document['isolated_exit_required']) is int and document['isolated_exit_required'] == 74
            and terminal["exception_type"] == "InjectedGraphUnwindError"
            and terminal["exception_message"] == "REPAIR8_PYTHON_UNWIND:"+point
            and "probe_export_error" not in terminal, "actual injected error/export differs")
    record, state, guard = document["record"], document["state"], document["next_scope_guard"]
    binding = record["carrier_binding"]
    generation = record['generation_identity']
    required_generation = {'generation_id', 'mapping_epoch', 'ordered_request_fingerprint', 'actual_request_count',
        'padded_request_count', 'normalized_method', 'global_group_id', 'read_descriptor_fingerprint',
        'provider_id', 'provider_version', 'source_identity', 'execution_lane', 'phase', 'step',
        'topology_fingerprint', 'row_phase_fingerprint'}
    require(required_generation <= generation.keys() and generation['normalized_method'] == 'dspark'
            and generation['source_identity'] and generation['read_descriptor_fingerprint']
            and generation['ordered_request_fingerprint'] == binding['ordered_request_fingerprint']
            and generation['actual_request_count'] == binding['actual_request_count']
            and generation['padded_request_count'] == binding['padded_request_count'],
            'complete actual source/generation/requests missing')
    topology = generation['topology_fingerprint']
    require(type(topology['tensor_parallel_size']) is int and topology['tensor_parallel_size'] == payload['tp']
            and type(topology['tensor_parallel_rank']) is int and topology['tensor_parallel_rank'] == worker['rank']
            and topology['parallel_read_semantics'] == 'replicated'
            and topology['graph_mode'] == 'FULL_DECODE_ONLY', 'actual per-rank topology fingerprint differs')
    require(all(type(row[key]) is int for row, key in [
        (record, 'generation'), (record, 'epoch'), (record, 'before_replay_ns'), (record, 'injected_ns'),
        (guard, 'ns'), (record['generation_identity'], 'generation_id'),
        (record['generation_identity'], 'mapping_epoch'), (binding, 'generation_id'), (binding, 'mapping_epoch')]),
        'exact integer generation/epoch/Host timestamps required')
    require(record["injected_point"] == point and type(record["generation"]) is int
            and type(record["epoch"]) is int and record["generation_identity"]["generation_id"] == record["generation"]
            and record["generation_identity"]["mapping_epoch"] == record["epoch"]
            and binding["generation_id"] == record["generation"] and binding["mapping_epoch"] == record["epoch"]
            and type(binding["tensor_parallel_rank"]) is int and binding["tensor_parallel_rank"] == worker["rank"]
            and type(binding["tensor_parallel_size"]) is int and binding["tensor_parallel_size"] == payload["tp"],
            "generation/epoch/actual rank binding differs")
    require(record["descriptor"] in [[n, n*PROFILES[payload["profile"]]["query"]] for n in (1, 2, 4)],
            "real per-method Draft capture descriptor differs")
    require(all(type(value) is int for value in record['descriptor']), 'descriptor booleans/floats are invalid')
    backing = record['backing']['window_block_table']
    require(type(backing['data_ptr']) is int and backing['data_ptr'] > 0
            and backing['device'] == f"npu:{worker['logical_device']}"
            and len(backing['shape']) == 2 and all(type(n) is int and n > 0 for n in backing['shape'])
            and backing['shape'][0] == record['descriptor'][0], 'actual per-rank read backing header missing')
    require(state["quarantined_identity"] == record["generation_identity"]
            and len(record["quarantine_calls"]) == 1
            and record["quarantine_calls"][0]["identity"] == record["generation_identity"]
            and all(state[key] is True for key in ['active_backing_retained', 'live_inputs_cleared',
                                                  'proposal_context_cleared', 'graph_submission_uncertain']),
            "actual production C1 quarantine/retained ownership missing")
    require(guard["rejected"] is True and guard["body_entered"] is False
            and "backing is quarantined" in guard["exception"]
            and record["before_replay_ns"] <= record["injected_ns"] < guard["ns"],
            "next scope was not rejected by Host guard")
    require(document["post_fault_device_operations"] == "NONE_BY_THIS_PROBE"
            and terminal["post_fault_device_operations"] == "NONE_BY_THIS_WRAPPER",
            "post-fault device recovery not allowed")
    require(record["replay_called"] is (point != "before_replay")
            and record["replay_returned"] is (point != "before_replay")
            and record["update_returned"] is (point in ('after_update', 'after_completion')), "wrong submit branch")
    if point == 'after_completion':
        require(record["completion"] == "DIAGNOSTIC_STREAM_DRAIN_BEFORE_EXCEPTION"
                and record["update_return_ns"] <= record["complete_ns"] < record["injected_ns"], "diagnostic drain missing")
    else:
        require(record["completion"] == 'UNPROVEN' and 'complete_ns' not in record, "Host return became completion claim")
    return dict(rank=worker['rank'], generation=record['generation'], epoch=record['epoch'],
                point=point, status='PASS_RAW_C1_STATE_EXTERNAL_PROCESS_DEVICE_JOIN_REQUIRED')


def validate_fault_identity(identity, worker, payload):
    require(type(identity['rank']) is int and identity['rank'] == worker['rank']
            and type(identity['world_size']) is int and identity['world_size'] == payload['tp']
            and type(identity['pid']) is int and identity['pid'] == worker['pid']
            and identity['process_start_ticks'] == worker['process_start_ticks']
            and identity['source_sha'] == payload['source_sha'] and identity['nonce'] == payload['nonce']
            and identity['mode'] == payload['mode'] and identity['point'] == payload['point'],
            'fault belongs to another rank/source/process/invocation')


def check_saved_fault(campaign, execution, *, source, pin):
    """Read complete rank files; a matching exit code alone is never accepted."""
    payload = campaign['payload']
    validate_payload(payload)
    expected_kwargs = fault_kwargs(payload['profile'], payload['tp'])
    require(campaign['kwargs'] == expected_kwargs
            and campaign['config_sha256'] == hashlib.sha256(json.dumps(expected_kwargs, sort_keys=True).encode()).hexdigest()
            == hashlib.sha256(json.dumps(campaign['kwargs'], sort_keys=True).encode()).hexdigest(),
            'actual fixed model/mode/TP/sampling configuration differs')
    require(type(execution['returncode']) is int and execution['returncode'] == 74
            and execution['signal'] is None and execution['timeout'] is False,
            'not an expected finite isolated exit74')
    require(campaign['status'] == 'FAILED' and campaign['startup_complete'] is True
            and campaign['failure_action'] == 'PARENT_EXIT74_NO_DEVICE_RECOVERY'
            and campaign['post_failure_device_RPC'] == 'FORBIDDEN'
            and campaign['native_partial_submission'] == 'NOT_SIMULATED', 'failed-engine isolation scope differs')
    require(campaign['exception_type'] not in ('TimeoutError','FutureTimeoutError','CancelledError','KeyboardInterrupt','SystemExit')
            and not any(text in campaign['exception_message'].lower() for text in ['timed out','rpc timeout','timeout occurred']),
            'timeout/cancellation is not successful error propagation')
    expected_stage = 'ARM_RPC_PENDING' if payload['mode'] == 'preparation_reject' else 'GENERATE_PENDING'
    require(campaign['stage'] == expected_stage, 'failure occurred before the intended invocation')
    if payload['mode'] == 'preparation_reject':
        require(campaign['arm_rpc_returned'] is False, 'RPC returned normally; do not accept our did-not-propagate error')
    else:
        require(campaign['arm_rpc_returned'] is True and campaign['generate_returned'] is False,
                'generate returned normally; do not accept our did-not-trigger error')
    workers = campaign['workers']
    validate_worker_set(workers, payload, source, pin)
    root = Path(payload['root'])
    checks = []
    logical_generations = []
    valid_barrier_exports = 0
    joint_terminals = []
    for worker in workers:
        directory = root/f"rank-{worker['rank']}"
        require(json.loads((directory/'identity.json').read_text()) == worker, 'saved rank identity differs from RPC')
        if payload['mode'] == 'preparation_reject':
            path = directory/'preparation.json'
            row = json.loads(path.read_text()) if path.exists() else None
            if row is not None:
                validate_fault_identity(row['identity'], worker, payload)
                require(row['new_proposal_submitted'] is False, 'preparation branch submitted a proposal')
            if worker['rank'] == payload['selected_rank']:
                require(row is not None, 'selected rejection file absent')
                require(row['status'] == 'INJECTED_BEFORE_NEW_PROPOSAL' and row['new_proposal_submitted'] is False
                        and row['identity']['nonce'] == payload['nonce'] and row['identity']['pid'] == worker['pid']
                        and row['exception'] == 'REPAIR41_PREPARATION:'+payload['nonce'], 'selected rank rejection missing')
                checks.append(dict(rank=worker['rank'], status='SELECTED_PRE_PROPOSAL_REJECTION_RECORDED'))
            else:
                # The executor can stop peers as soon as one real RPC fails.
                # No invented all-peer preparation PASS when a file is absent.
                require(row is None or row['status'] == 'PEER_HOST_PREPARATION_RETURNED'
                        and row['exception'] is None, 'peer record contradicts selected-rank rejection')
                checks.append(dict(rank=worker['rank'], status='PEER_HOST_RETURN_RECORDED' if row is not None
                                   else 'NOT_REPORTED_AFTER_PROPAGATED_REJECTION'))
            require(not (directory/'unwind.json').exists(), 'preparation rejection unexpectedly entered proposal unwind')
        else:
            armed = json.loads((directory/'armed.json').read_text())
            validate_fault_identity(armed['identity'], worker, payload)
            require(armed['status'] == 'ALL_RANK_SAME_POINT_ARMED' and armed['identity']['nonce'] == payload['nonce']
                    and armed['identity']['rank'] == worker['rank'], 'actual all-rank installation incomplete')
            document = json.loads((directory/'unwind.json').read_text())
            terminal = json.loads((directory/'terminal.json').read_text())
            joint_terminals.append(terminal)
            barrier_path = directory/'host-error-barrier.json'
            if barrier_path.exists():
                barrier = json.loads(barrier_path.read_text())
                require(barrier['status'] == 'ALL_RANK_HOST_ERROR_EXPORTS_PRESENT_NOT_DEVICE_COMPLETION'
                        and barrier['post_fault_device_operations'] == 'NONE' and barrier['native_completion'] == 'NOT_PROVEN'
                        and len(barrier['proofs']) == payload['tp']
                        and all(type(proof['rank']) is int for proof in barrier['proofs'])
                        and sorted(proof['rank'] for proof in barrier['proofs']) == list(range(payload['tp'])),
                        'all-rank Host error export incomplete')
                for proof in barrier['proofs']:
                    require(Path(proof['path']) == root/f"rank-{proof['rank']}/terminal.json"
                            and digest(proof['path']) == proof['sha256'], 'peer error export bytes/path changed')
                valid_barrier_exports += 1
            checked = validate_unwind_document(document, terminal, worker, payload)
            require(all(type(value) is int for value in [campaign['generate_ns'],campaign['end_ns'],terminal['caught_ns']])
                    and campaign['generate_ns'] <= document['record']['before_replay_ns']
                    <= document['record']['injected_ns'] <= terminal['caught_ns']
                    <= document['next_scope_guard']['ns'] <= campaign['end_ns'], 'fault outside actual parent invocation')
            binding = document['record']['carrier_binding']
            logical_generations.append({key:binding[key] for key in ['generation_id','mapping_epoch',
                'ordered_request_fingerprint','actual_request_count','padded_request_count']})
            checks.append(checked)
    # Once one rank has atomically indexed ALL terminal files, the executor may
    # terminate peers before they write their own duplicate index. Every peer's
    # actual C1/terminal files above remain mandatory; missing indexes are not a
    # fabricated peer PASS or a device-completion claim.
    require(payload['mode'] != 'python_unwind' or valid_barrier_exports > 0,
            'no completed all-rank Host export index before propagation')
    require(not logical_generations or all(item == logical_generations[0] for item in logical_generations),
            'ranks did not unwind the same logical proposal')
    required_features = None
    if payload['profile'] == 'glm_k8_required' and payload['mode'] == 'python_unwind':
        from tools.p7x_graph_repair57_glm_joint_unwind import validate_joint_features
        required_features = validate_joint_features(workers, terminals=joint_terminals)
    result = dict(status='PASS_RAW_RANK_FAULT_ARTIFACTS_EXTERNAL_ALL_RANK_PROCESS_DEVICE_JOIN_REQUIRED',
                mode=payload['mode'], point=payload['point'], ranks=len(workers), checks=checks,
                normal_completion='NOT_PROVEN', native_partial_submission='NOT_SIMULATED',
                single_rank_native_failure='NOT_SIMULATED', physical_read='UNPROVEN')
    if required_features is not None:
        result['required_features'] = required_features
    return result


def run(args):
    source = Path(__file__).resolve().parents[1]
    receipt = validate_admission(args.admission, source=source, sha=args.expected_sha, tp=args.tp)
    require(not args.output.exists(), "new disposable fault attempt required")
    payload = dict(mode=args.mode, point=args.point, selected_rank=args.selected_rank,
                   profile=args.model_profile, tp=args.tp, nonce=uuid.uuid4().hex,
                   source_sha=args.expected_sha, parent_pid=os.getpid(), root=str(args.output),
                   host=receipt['host'],boot_id=receipt['boot_id'],namespace=receipt['namespace'])
    validate_payload(payload)
    args.output.mkdir(parents=True)
    record = dict(status='STARTING', source_sha=args.expected_sha, source_tree=receipt['source_tree'],
                  pid=os.getpid(), start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                  started_at=time.time(), start_ns=time.monotonic_ns(), payload=payload,
                  admission_sha256=digest(args.admission), script_sha256=digest(__file__),
                  scope='Explicit Python failure injection, not native corruption or normal performance',
                  native_partial_submission='NOT_SIMULATED', post_failure_device_RPC='FORBIDDEN')
    write(args.output/'campaign.json', record)
    llm = None
    initialization_attempted = False
    try:
        import torch_npu  # noqa:F401
        import vllm_ascend.ops  # noqa:F401
        import vllm_ascend.worker.v2.spec_decode  # noqa:F401
        from vllm import LLM, SamplingParams
        kwargs = fault_kwargs(args.model_profile, args.tp)
        record.update(kwargs=kwargs, config_sha256=hashlib.sha256(json.dumps(kwargs, sort_keys=True).encode()).hexdigest())
        record['stage'] = 'STARTUP_PENDING'
        initialization_attempted = True
        llm = LLM(**kwargs)
        record.update(engine_id=id(llm.llm_engine), startup_complete=True)
        record['stage'] = 'IDENTIFY_RPC_PENDING'
        workers = llm.collective_rpc('mrv2_rank_unwind_identity', timeout=90, args=(payload,))
        validate_worker_set(workers, payload, source, receipt['vllm_checkout'])
        payload['worker_processes'] = [{key:worker[key] for key in ['rank','pid','process_start_ticks']} for worker in workers]
        record['workers'] = workers
        record.update(stage='ARM_RPC_PENDING', arm_rpc_returned=False)
        write(args.output/'campaign.json', record)
        armed = llm.collective_rpc('mrv2_rank_arm_unwind', timeout=60, args=(payload,))
        record['arm_rpc_returned'] = True
        require(args.mode == 'python_unwind' and len(armed) == args.tp
                and sorted(row['rank'] for row in armed) == list(range(args.tp)),
                'selected preparation rejection did not propagate or ranks not armed')
        record.update(armed=armed, request=dict(input_token_ids=[301]*1153, output_limit=32),
                      stage='GENERATE_PENDING', generate_returned=False, generate_ns=time.monotonic_ns())
        write(args.output/'campaign.json', record)
        llm.generate([dict(prompt_token_ids=[301]*1153)],
                     SamplingParams(temperature=0, max_tokens=32, min_tokens=32, ignore_eos=True), use_tqdm=False)
        record['generate_returned'] = True
        raise RuntimeError('DECLARED_PYTHON_FAULT_DID_NOT_TRIGGER')
    except BaseException as error:
        record.update(exception_traceback=traceback.format_exc(), end_ns=time.monotonic_ns())
        # Existing audited Host export + exit74 contract; never shutdown or RPC
        # an initialized failed engine to gather more data.
        isolate_failed_parent(record, args.output, error, model_initialized=initialization_attempted)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--admission', type=Path, required=True)
    parser.add_argument('--expected-sha', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--tp', type=int, choices=(2, 4, 16), required=True)
    parser.add_argument('--model-profile', choices=tuple(PROFILES), required=True)
    parser.add_argument('--mode', choices=MODES, required=True)
    parser.add_argument('--point', choices=POINTS)
    parser.add_argument('--selected-rank', type=int)
    return run(parser.parse_args())


if __name__ == '__main__':
    raise SystemExit(main())
