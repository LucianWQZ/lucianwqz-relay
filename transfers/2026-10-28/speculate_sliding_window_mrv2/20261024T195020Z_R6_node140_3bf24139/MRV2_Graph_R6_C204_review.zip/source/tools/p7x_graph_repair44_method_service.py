# SPDX-License-Identifier: Apache-2.0
"""Named DFlash/Eagle official CLI service trials; no model-driver injection.

The shared SSE lifecycle retains original events and independent worker-source
RPCs. These token-ID completion requests do not validate the chat endpoint,
continuous KV numerics, native operands, physical reads or device completion.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import copy
import json
from types import SimpleNamespace

from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair33_service import run_service, serve_argv, validate_requests


def declared_method_contract(method, doc):
    """Read each actual schema; never add missing fields to frozen fixtures."""
    if method == "dflash":
        from tools.p7x_graph_repair12_contract import method_for_profile, validate_method_document

        require(doc["schema"] == "r4-dflash-k15-q16-fixture-v1", "DFlash fixture schema")
        expected = dict(method="dflash", K=15, Q=16, capture_sizes=[16, 32, 64], W=1024, block=128, TP=1)
        require(all(type(doc[key]) is type(value) and doc[key] == value for key, value in expected.items())
                and all(type(x) is int for x in doc["capture_sizes"]),
                "actual R4 DFlash K/Q/capture/Window contract")
        if "method_contract" in doc:
            validate_method_document("dflash_k15_q16", doc["method_contract"])
        return method_for_profile("dflash_k15_q16").document()
    else:
        require(method == "eagle3", "named service method")
        from tools.p7x_graph_repair13_eagle import validate_contract

        require(doc["schema"] == "r5-eagle3-k3-fixture-v1", "Eagle fixture schema")
        validate_contract(doc["method_contract"])
        return copy.deepcopy(doc["method_contract"])


def method_configuration(method, fixture, fixture_sha256, arm):
    require(method in ("dflash", "eagle3") and arm in ("G_OFF", "G_ON", "E_ON"), "named method/arm")
    require(digest(fixture) == fixture_sha256, "method fixture changed")
    doc = json.loads(Path(fixture).read_text())
    declared_method_contract(method, doc)
    if method == "dflash":
        from tools.p7x_graph_repair11_method_anchor import configure
    else:
        from tools.p7x_graph_repair13_eagle import configure
    base = dict(model=doc["target_model"], speculative_config=dict(model=doc["draft_model"],
                enable_adaptive_verification=False), compilation_config=dict(cudagraph_mode="FULL_DECODE_ONLY",
                cudagraph_capture_sizes=[7, 14, 28, 32]), additional_config=dict(draft_window_size=1024),
                enforce_eager=False, async_scheduling=False, enable_prefix_caching=False, disable_log_stats=False)
    cfg = configure(base, arm)
    from tools.p7x_graph_repair34_method_perf import capacity

    for model in (doc["target_model"], doc["draft_model"]):
        capacity(json.loads((Path(model)/"config.json").read_text()), 24576)
    cfg["max_model_len"] = 24576
    return doc, cfg


def method_serve_argv(python, port, model_name, arm, *, method, fixture, fixture_sha256, worker_provenance=False):
    doc, cfg = method_configuration(method, fixture, fixture_sha256, arm)
    argv = serve_argv(python, port, model_name, arm, worker_provenance=worker_provenance)
    argv[argv.index("serve")+1] = doc["target_model"]
    argv[argv.index("--max-model-len")+1] = str(cfg["max_model_len"])
    for key in ("speculative_config", "compilation_config", "additional_config"):
        argv[argv.index("--"+key.replace("_", "-"))+1] = json.dumps(cfg[key], sort_keys=True)
    require("--enforce-eager" not in argv and "--no-async-scheduling" in argv
            and "--no-enable-prefix-caching" in argv, "frozen target/feature policy")
    return argv


def fixture_and_builder(args):
    doc, _ = method_configuration(args.method, args.fixture, args.fixture_sha256, args.arm)
    from tools.p7x_graph_repair12_contract import verify_fixture_receipt

    verify_fixture_receipt(SimpleNamespace(repair12_fixture_verification=args.fixture_receipt,
        repair12_fixture_verification_sha256=args.fixture_receipt_sha256, expected_sha=args.expected_sha,
        fixture_manifest=args.fixture), doc)

    def builder(python, port, name, arm, *, worker_provenance=False):
        return method_serve_argv(python, port, name, arm, method=args.method, fixture=args.fixture,
                                fixture_sha256=args.fixture_sha256, worker_provenance=worker_provenance)

    return doc, builder


def check_saved(args):
    result = dict(status="INVALID_EVIDENCE", scope="OFFICIAL_METHOD_SERVICE_ARTIFACTS_ONLY_EXTERNAL_JOIN_REQUIRED")
    try:
        source = Path(__file__).resolve().parents[1]
        doc, builder = fixture_and_builder(args)
        campaign = json.loads(args.campaign.read_text())
        argv = json.loads(args.server_argv.read_text())
        require(argv == builder(argv[0], int(argv[argv.index("--port")+1]),
                    argv[argv.index("--served-model-name")+1], args.arm, worker_provenance=True),
                "expected server method/config argv changed")
        require(campaign["source_sha"] == args.expected_sha and campaign["service_method"] == args.method
                and campaign["service_method_contract"] == declared_method_contract(args.method, doc)
                and campaign["method_fixture_sha256"] == digest(args.fixture)
                and campaign["method_fixture_receipt_sha256"] == digest(args.fixture_receipt)
                and campaign["requests_sha256"] == digest(args.requests)
                and campaign["worker_provenance_enabled"] is True, "service method/fixture/source differs")
        require(campaign["method_entrypoint_sha256"] == digest(__file__)
                and campaign["script_sha256"] == digest(source/"tools/p7x_graph_repair33_service.py"),
                "method or common service script changed")
        admission = Path(campaign["admission_path"])
        require(digest(admission) == campaign["admission_sha256"], "service admission changed")
        receipt = json.loads(admission.read_text())
        require(receipt["source_sha"] == args.expected_sha and receipt["source_tree"] == campaign["source_tree"]
                and Path(receipt["vllm_checkout"]).resolve() == args.vllm_repo.resolve(), "service source/pin receipt")
        checked = validate_requests(campaign, json.loads(args.records.read_text()), json.loads(args.requests.read_text()),
                    expected_server_argv=argv, expected_source=source, expected_vllm_source=args.vllm_repo)
        wanted = ("vllm_ascend.worker.v2.spec_decode.eagle.speculator.AscendEagleSpeculator" if args.method=="eagle3"
                  else "vllm_ascend.worker.v2.spec_decode.dflash.speculator.AscendDFlashSpeculator")
        require(all(s["results"][0]["speculator_class"] == wanted for s in campaign["worker_provenance"]),
                "actual official worker used another speculative method")
        for state in campaign["worker_provenance"]:
            worker=state["results"][0]
            k=3 if args.method=="eagle3" else 15
            require(worker["actual_method"]==args.method and type(worker["actual_k"]) is int and worker["actual_k"]==k,
                    "actual official method/K differs")
            if args.method=="dflash":
                require(type(worker["actual_query_width"]) is int and worker["actual_query_width"]==16
                        and worker["actual_sample_from_anchor"] is False, "actual DFlash query/sample offset contract")
            require(worker["graph_inventory"]["target"]["graphs"], "actual Target capture inventory absent")
            names=("prefill_cudagraph_manager","decode_cudagraph_manager") if args.method=="eagle3" else ("query_cudagraph_manager",)
            require(all(bool(worker["graph_inventory"][key]["graphs"]) is (args.arm!="E_ON") for key in names),
                    "actual Draft Graph/eager inventory differs")
        if args.arm=="G_ON":
            after=campaign["worker_provenance"][-1]["results"][0]
            require(any(type(x["generation"]) is int and x["update_function"] is not None
                        for x in after["latest_provider_bindings"]), "no actual runtime UPDATE attribution after requests")
        result.update(checked, method=args.method, method_contract=declared_method_contract(args.method, doc),
                      acceptance="NOT_AVAILABLE_FROM_THIS_HTTP_COLLECTION", chat_endpoint="NOT_ASSESSED",
                      device_execution_occurrence="NOT_INFERRED_FROM_SERVICE_COMPLETION")
    except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("run", "check"))
    parser.add_argument("--method", choices=("dflash", "eagle3"), required=True)
    parser.add_argument("--arm", choices=("G_OFF", "G_ON", "E_ON"), required=True)
    for key in ("fixture", "fixture-receipt", "vllm-repo", "requests", "output"):
        parser.add_argument("--"+key, type=Path, required=True)
    for key in ("fixture-sha256", "fixture-receipt-sha256", "expected-sha"):
        parser.add_argument("--"+key, required=True)
    parser.add_argument("--admission", type=Path); parser.add_argument("--port", type=int)
    for key in ("campaign", "records", "server-argv"):
        parser.add_argument("--"+key, type=Path)
    args=parser.parse_args()
    if args.command=="check":
        require(all(getattr(args,k) is not None for k in ("campaign","records","server_argv")), "checker paths")
        result=check_saved(args); write(args.output,result)
        return 0 if result["status"]=="PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS" else 4
    require(args.admission is not None and args.port is not None, "run admission/port required")
    doc,builder=fixture_and_builder(args); args.worker_provenance=True
    return run_service(args, server_argv_builder=builder, target_model=doc["target_model"], extra_metadata=dict(
        service_method=args.method, service_method_contract=declared_method_contract(args.method, doc),
        service_contract_source="SCHEMA_NATIVE_FIELDS_AND_NAMED_RUNTIME_CONTRACT_NOT_ADDED_TO_FROZEN_FIXTURE",
        method_fixture_sha256=digest(args.fixture), method_fixture_receipt_sha256=digest(args.fixture_receipt),
        method_entrypoint_sha256=digest(__file__)))


if __name__=="__main__":
    raise SystemExit(main())
