# SPDX-License-Identifier: Apache-2.0
"""Named GLM DFlash K15/Q16 continuous reference and heterogeneous Target join.

Reuses the actual rank RPC, capture-output sink, canonical-prestate eager
reference and chunked artifact/checker path. This serial diagnostic is separate
from required-feature service, normal lifecycle and performance acceptance.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch

from tools.p7x_graph_repair12_contract import method_for_profile
from tools.p7x_graph_repair21_rank import digest, require, write
from tools.p7x_graph_repair25_rank_numeric import (
    RankControlledTarget, RankNumericWorker, build_parser, check_external as common_check,
    check_rank_payload, run_controlled,
)
from tools.p7x_graph_repair37_glm_target import (
    DFLASH_PROFILE as PROFILE, GLMControlledTarget, GLMTargetAdapter,
    isolation_errors as glm_isolation, validate_record as glm_record,
)
from tools.p7x_graph_repair38_glm_numeric import component_keys, join_arms
from tools.p7x_graph_repair62_glm_dflash_anchor import (
    DRAFT, DRAFT_CONFIG_SHA, TARGET, TARGET_CONFIG_SHA, GLMDFlashWorker,
    build_kwargs as anchor_kwargs, profile_identity, validate_worker as anchor_validate_worker,
)


def build_kwargs(arm, tp):
    require(arm in ("ON", "OFF"), "explicit GLM DFlash Window arm required")
    result = anchor_kwargs(tp, window_on_review=arm == "ON")
    result["worker_extension_cls"] = "tools.p7x_graph_repair66_glm_dflash_numeric.GLMDFlashNumericWorker"
    if arm == "ON":
        result["additional_config"]["draft_window_graph_numeric_diagnostic"] = True
    return result


def validate_fixture(plan_path, fixture):
    plan, manifest = (json.loads(Path(p).read_text()) for p in (plan_path, fixture))
    require(plan["schema"] == "glm66-frozen-diagnostic-plan-v1"
            and manifest["schema"] == "glm66-model-identity-v1"
            and plan["fixture_manifest"] == str(fixture)
            and plan["fixture_sha256"] == digest(fixture)
            and plan["profile"] == manifest["profile"] == PROFILE,
            "named DFlash source/model plan differs")
    from tools.p7x_graph_local_candidate import BASE_SHA, _identity
    _identity(Path(plan["source"]), plan["source_sha"], plan["source_tree"], ancestor=BASE_SHA)
    expected = profile_identity()
    require(plan["profile_identity"] == manifest["profile_identity"] == expected,
            "actual GLM DFlash config/header identity differs")
    return dict(plan=str(plan_path), plan_sha256=digest(plan_path), fixture_sha256=digest(fixture),
                source_sha=plan["source_sha"], source_tree=plan["source_tree"], profile_identity=expected,
                scope="FIXED_CONFIG_INDEX_AND_DFLASH_WEIGHT_HEADER_NOT_NEW_FULL_WEIGHT_HASH")


def model_contract(fixture, kwargs):
    manifest = json.loads(Path(fixture).read_text())
    require(manifest["profile"] == PROFILE and manifest["profile_identity"] == profile_identity()
            and kwargs["model"] == str(TARGET) and kwargs["speculative_config"]["model"] == str(DRAFT),
            "actual model pair differs from the named GLM DFlash fixture")
    return dict(target=dict(path=str(TARGET / "config.json"), sha256=TARGET_CONFIG_SHA,
                            layers=99, decoder_layers=78, indexer_owners=21, backend="SFA_PLUS_INDEXER"),
                draft=dict(path=str(DRAFT / "config.json"), sha256=DRAFT_CONFIG_SHA,
                           layers=5, kv_heads=64, head_size=64, k=15, query=16, sample_offset=1))


class GLMDFlashRankControlledTarget(RankControlledTarget, GLMControlledTarget):
    """Reuse all completed-sample barriers, Full slots and Target ownership."""


class GLMDFlashNumericWorker(RankNumericWorker, GLMDFlashWorker):
    diagnostic_profile = PROFILE
    controlled_type = GLMDFlashRankControlledTarget

    def _validate_method_owner(self, spec):
        require(spec.method == "dflash" and spec.requires_non_causal is True,
                "actual noncausal DFlash method required")
        require(type(spec.draft_kv_cache_group_id) is int and spec.draft_kv_cache_group_id == 0,
                "this controlled fixture requires the observed unified group0; do not write another group's state")
        method_for_profile(PROFILE).validate_owner(spec)

    def _target_adapter(self, current, contract, **kwargs):
        return GLMTargetAdapter(current, rank_contract=contract, actual_rank=self.rank,
                                method_profile=PROFILE, **kwargs)


def validate_record(record):
    return glm_record(record, profile=PROFILE)


def isolation_errors(record):
    return glm_isolation(record, profile=PROFILE)


def validate_worker(worker, tp):
    anchor_validate_worker(worker, tp)
    groups = worker["glm_profile"]["draft_groups"] + worker["glm_profile"]["target_groups"]
    require(all(type(group["global_group_id"]) is int and group["global_group_id"] == 0 for group in groups),
            "this named controlled fixture requires actual unified group0; anchor supports a wider inventory")


def check_payload(path, payload, worker):
    validate_worker(worker, 16)
    require(payload["profile"] == PROFILE and payload["world_size"] == 16,
            "named complete GLM DFlash rank/profile required")
    return check_rank_payload(path, payload, worker, profile=PROFILE,
        record_validator=validate_record, isolation_validator=isolation_errors, component_keys=component_keys)


def check_external(planned, execution):
    result = common_check(planned, execution, profile=PROFILE, kwargs_factory=build_kwargs,
        model_contract_factory=model_contract, fixture_validator=validate_fixture,
        payload_checker=check_payload, extra_worker_validator=validate_worker, allow_external_only=True,
        cpu_workers=4)
    if result["status"].startswith("PASS_SCOPED_"):
        try:
            expected = json.loads(Path(planned).read_text())
            args = build_parser().parse_args(expected["argv"][2:])
            proof = validate_fixture(args.fixture_plan, args.fixture)
            require(all(proof[k] == expected[k] for k in ("source_sha", "source_tree")),
                    "DFlash fixture is not this producer")
        except (ValueError, KeyError, TypeError, OSError) as error:
            result.update(status="INVALID_EVIDENCE", error=str(error))
    result.update(profile=PROFILE, glm_dflash_numeric_tool_sha256=digest(__file__),
                  normal_overlap="UNPROVEN", physical_read="NOT_OBSERVED",
                  target_binding_scope="COMPLETED_SFA_INDEXER_METADATA_NOT_EXECUTION_OPERANDS")
    return result


def main():
    args = build_parser().parse_args()
    if args.command in ("check", "join"):
        torch.set_num_threads(2)
        result = (check_external(args.planned, args.execution) if args.command == "check" else
                  join_arms(args, profile=PROFILE, external_checker=check_external,
                            validator_for_rank=lambda rank: validate_record, isolation_validator=isolation_errors,
                            cpu_workers=4))
        write(args.output, result)
        return 0 if result["status"].startswith("PASS_SCOPED_") else 4
    require(args.tp == 16 and validate_fixture(args.fixture_plan, args.fixture)["source_sha"] == args.expected_sha,
            "fixed complete TP16 GLM DFlash producer required")
    return run_controlled(args, profile=PROFILE, kwargs_factory=build_kwargs,
        model_contract_factory=model_contract, fixture_validator=validate_fixture, payload_checker=check_payload,
        extra_worker_validator=validate_worker, producer_path=__file__,
        defer_payload_validation=args.external_payload_check_only)


if __name__ == "__main__":
    raise SystemExit(main())
