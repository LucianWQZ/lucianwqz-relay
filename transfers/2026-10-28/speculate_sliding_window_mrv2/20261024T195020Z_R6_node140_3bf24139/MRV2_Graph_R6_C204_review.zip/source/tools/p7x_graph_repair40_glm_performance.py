# SPDX-License-Identifier: Apache-2.0
"""All-rank GLM TP16 controls, separate from KV dumps and service metrics.

The original six OFF/ON pairs keep their exact contract. A separately named
six-cycle contract adds the real rank-owned eager control already available
in the P7 source. No production gate or topology is changed by this tool.
"""
from __future__ import annotations

import sys
from pathlib import Path

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import functools
import hashlib
import json
import os
import time
from types import MethodType

from tools.p7x_graph_repair21_rank import digest, require, validate_admission, write
from tools.p7x_graph_repair32_glm_rank import GLMRankWorker, build_glm_kwargs, profile_identity, validate_glm_worker
from tools.p7x_graph_repair34_method_perf import capacity

K = 8
PAIR_CONTRACT = 'GLM_OFF_ON_6PAIR_V1'
THREE_ARM_CONTRACT = 'GLM_GRAPH_EAGER_6CYCLE_V1'
THREE_ARM_ORDERS = (
    ('G_OFF', 'G_ON', 'E_ON'), ('E_ON', 'G_OFF', 'G_ON'), ('G_ON', 'E_ON', 'G_OFF'),
    ('E_ON', 'G_ON', 'G_OFF'), ('G_OFF', 'E_ON', 'G_ON'), ('G_ON', 'G_OFF', 'E_ON'),
)


class HostRangeHooks:
    """Host ranges only; the official worker owns the sole native profiler."""
    def __init__(self, entries):
        self.originals = []
        for owner, name, label in entries:
            original = getattr(owner, name)
            require(callable(original), 'actual Host range function absent: '+name)
            self.originals.append((owner, name, original, label))

    @staticmethod
    def _wrap(original, label):
        @functools.wraps(original)
        def call(*args, **kwargs):
            from torch.profiler import record_function
            with record_function(label):
                return original(*args, **kwargs)
        return call

    def install(self):
        for owner, name, original, label in self.originals:
            setattr(owner, name, self._wrap(original, label))

    def restore(self):
        for owner, name, original, _ in reversed(self.originals):
            setattr(owner, name, original)
        return [label for _, _, _, label in self.originals]


def validate_workload(arm, maximum, groups, repetition, position, profiled, *, comparison_contract=PAIR_CONTRACT):
    require(comparison_contract in (PAIR_CONTRACT, THREE_ARM_CONTRACT), 'named comparison contract required')
    allowed = ('G_OFF', 'G_ON') if comparison_contract == PAIR_CONTRACT else ('G_OFF', 'G_ON', 'E_ON')
    require(arm in allowed, 'standalone eager is absent from the original two-arm contract; no TP substitution')
    require(type(maximum) is int and maximum in (4096, 24576), 'bounded native short/16K profile required')
    require(type(profiled) is bool and type(repetition) is int and type(position) is int, 'typed profile/repetition')
    if profiled:
        require(arm == 'G_ON' and repetition == position == 0, 'separate representative ON profile only')
    else:
        positions = (1, 2) if comparison_contract == PAIR_CONTRACT else (1, 2, 3)
        require(1 <= repetition <= 6 and position in positions, 'six declared balanced repeats required')
        order = (('G_OFF', 'G_ON') if repetition % 2 else ('G_ON', 'G_OFF')) if comparison_contract == PAIR_CONTRACT else THREE_ARM_ORDERS[repetition-1]
        require(arm == order[position-1], 'declared balanced pair order differs')
    require(isinstance(groups, list) and len(groups) == 1, 'one independent workload per cell')
    g = groups[0]
    require(type(g['max_tokens']) is int and g['max_tokens'] in (256, 512)
            and 1 <= len(g['prompts']) <= 4, 'bounded output and captured active capacity')
    for p in g['prompts']:
        ids = p['prompt_token_ids']
        require(isinstance(ids, list) and ids and all(type(x) is int and x >= 0 for x in ids)
                and len(ids)+g['max_tokens'] <= maximum, 'actual fixed input IDs/capacity differ')


def acceptance(metrics):
    require(metrics is not None and type(metrics['num_spec_tokens']) is int and metrics['num_spec_tokens'] == K,
            'actual GLM DSpark K8 metrics required')
    h, drafted, accepted = (metrics[k] for k in ('acceptance_histogram', 'per_step_drafted', 'per_step_accepted'))
    require(len(h) == K+1 and all(type(x) is int and x >= 0 for x in h), 'exact K8 histogram')
    require(len(drafted) == len(accepted) == sum(h) and bool(drafted), 'request verification step coverage')
    require(all(type(d) is int and type(a) is int and 0 <= a <= d <= K and d > 0
                for d, a in zip(drafted, accepted)), 'actual proposals exclude padding/bonus')
    require(h == [accepted.count(i) for i in range(K+1)], 'histogram/detailed accepted counts contradict')
    proposed, total, steps = sum(drafted), sum(accepted), len(drafted)
    for name, value in [('num_draft_tokens', proposed), ('num_accepted_draft_tokens', total), ('num_spec_steps', steps)]:
        require(type(metrics[name]) is int and metrics[name] == value, 'framework counter differs: ' + name)
    require(abs(metrics['draft_acceptance_rate']-total/proposed) < 1e-12
            and abs(metrics['mean_acceptance_length']-(1+total/steps)) < 1e-12, 'reported acceptance rate differs')
    return dict(proposed=proposed, accepted=total, verification_request_steps=steps,
                rate=total/proposed, mean_acceptance_length_including_bonus=1+total/steps,
                proposed_per_position=[sum(d > i for d in drafted) for i in range(K)],
                accepted_per_position=[sum(a > i for a in accepted) for i in range(K)],
                definition='Scheduled proposals after grammar adjustment; sampler accepted before stop trimming; bonus/padding excluded')


class GLMPerformanceWorker(GLMRankWorker):
    def mrv2_rank_install_dispatch_observer(self):
        installed = super().mrv2_rank_install_dispatch_observer()
        self._mrv2_draft_eager_returns = 0
        spec = self.model_runner.speculator
        if spec.speculative_config.enforce_eager:
            original = spec._run_model

            def eager(_spec, *args, **kwargs):
                value = original(*args, **kwargs)
                self._mrv2_draft_eager_returns += 1
                return value

            spec._run_model = MethodType(eager, spec)
        return installed

    def mrv2_rank_snapshot(self):
        row = super().mrv2_rank_snapshot()
        row['draft_eager_forward_returns'] = getattr(self, '_mrv2_draft_eager_returns', 0)
        return row

    def mrv2_glm_profile_host_ranges(self, start):
        require(type(start) is bool, 'typed Host instrumentation state required')
        if start:
            require(getattr(self, '_glm_perf_ranges', None) is None, 'Host ranges already installed')
            spec = self.model_runner.speculator
            runtime = spec._draft_window_runtime_state
            provider = spec._draft_window_graph_binding_provider
            manager = spec.query_cudagraph_manager
            module = sys.modules[type(manager).__module__]
            hooks = HostRangeHooks([
                (runtime, 'materialize', 'Draft_materialize'),
                (spec, '_snapshot_prepared_draft_seq_lens', 'Draft_exact_length_snapshot'),
                (provider, 'bind_read_carrier', 'Draft_metadata_bind'),
                (module, 'update_full_graph_params', 'Draft_UPDATE_CALL'),
                (runtime, 'retire_generation', 'Draft_retire_host'),
            ])
            hooks.install()
            self._glm_perf_ranges = hooks
            return dict(rank=self.rank, scope='HOST_RANGES_ONLY_OFFICIAL_WORKER_IS_SOLE_NATIVE_PROFILER')
        hooks = self._glm_perf_ranges
        require(hooks is not None, 'Host ranges were not started')
        names = hooks.restore()
        self._glm_perf_ranges = None
        return dict(rank=self.rank, ranges=names, restored=True)

    def mrv2_glm_perf_reset(self):
        require(hasattr(self, '_mrv2_rank_replay_records'), 'actual dispatch observer not installed')
        self._mrv2_rank_replay_records.clear()
        self._mrv2_rank_window_generations.clear()
        self._mrv2_rank_window_bindings.clear()
        self._mrv2_draft_eager_returns = 0
        return dict(rank=self.rank, pid=os.getpid(), reset='HOST_COUNTERS_ONLY_NO_DEVICE_OPERATION')


def configuration(args):
    groups = json.loads(args.requests.read_text())
    validate_workload(args.arm, args.max_model_len, groups, args.repetition, args.order_position, args.profile,
                      comparison_contract=getattr(args, 'comparison_contract', PAIR_CONTRACT))
    kwargs = build_glm_kwargs(16, window_on_review=args.arm == 'G_ON')
    if args.arm == 'E_ON':
        kwargs['speculative_config']['enforce_eager'] = True
        kwargs['additional_config'] = dict(draft_window_size=1024)
    target_config = json.loads((Path(kwargs['model'])/'config.json').read_text())
    require(all(token < target_config['vocab_size'] for group in groups for p in group['prompts']
                for token in p['prompt_token_ids']), 'input token outside actual GLM vocabulary')
    for model in (kwargs['model'], kwargs['speculative_config']['model']):
        capacity(json.loads((Path(model)/'config.json').read_text()), args.max_model_len)
    kwargs.update(worker_extension_cls='tools.p7x_graph_repair40_glm_performance.GLMPerformanceWorker',
                  max_model_len=args.max_model_len, per_request_spec_decode_metrics='detailed')
    if args.profile:
        model_output = args.campaign.parent if getattr(args, 'command', 'run') == 'check' else args.output
        kwargs['profiler_config'] = dict(profiler='torch', torch_profiler_dir=str(model_output/'profiles'),
                                        torch_profiler_with_stack=False, torch_profiler_record_shapes=False,
                                        torch_profiler_with_memory=False)
    return groups, kwargs


def validate_joint_eager_async_sources(rows):
    """Check rank-local lane ownership before comparing logical request state.

    Each real P3 lane owns its own generation counter. Async completion may
    select a different free lane on another rank. Those local counters cannot
    be compared as a globally assigned generation, while the ordered business
    epoch, request rows, exact lengths and read descriptors must still agree.
    """
    for row in rows:
        pool = row.get('eager_async_pool')
        require(isinstance(pool, dict) and pool.get('scope') == 'HOST_HEADERS_NOT_EVENT_COMPLETION',
                'actual eager Async owner headers missing')
        capacity, lanes = pool.get('capacity'), pool.get('lanes')
        require(type(capacity) is int and capacity > 0 and isinstance(lanes, list)
                and len(lanes) == capacity and sorted(lane['lane'] for lane in lanes) == list(range(capacity)),
                'complete independent eager lane set required')
        for key in ('runtime_id', 'table_address'):
            require(all(type(lane[key]) is int and lane[key] > 0 for lane in lanes)
                    and len({lane[key] for lane in lanes}) == capacity,
                    'eager lanes alias an owner or backing')
        for lane in lanes:
            require(type(lane['lane']) is int and type(lane['tp_rank']) is int
                    and lane['tp_rank'] == row['rank'] and type(lane['tp_size']) is int
                    and lane['tp_size'] == 16 and lane['graph_mode'] == 'NONE'
                    and all(lane[key] is True for key in ('async_scheduling', 'sequence_parallel',
                        'dsa_context_parallel', 'flashcomm', 'prefix_caching')),
                    'eager lane lost the actual joint executor topology')
        previous, previous_epoch = {}, -1
        for item in row['window_generations']:
            lane, generation, epoch = item.get('execution_lane'), item['generation'], item['epoch']
            require(type(lane) is int and 0 <= lane < capacity and type(generation) is int
                    and generation >= 0 and generation > previous.get(lane, -1)
                    and type(epoch) is int and epoch > previous_epoch,
                    'stale, duplicate or foreign eager lane generation')
            require(type(item.get('step')) is int and item['step'] >= 0
                    and isinstance(item.get('phase'), str) and item['phase'],
                    'actual eager phase/step identity missing')
            previous[lane], previous_epoch = generation, epoch


def validate_ranks(rows, *, source, pin, arm, need_clip, capture_contract=None, eager_async_lanes=False):
    require(type(eager_async_lanes) is bool and (not eager_async_lanes or arm == 'E_ON'),
            'explicit joint eager Async source contract required')
    require(isinstance(rows, list) and len(rows) == 16
            and all(type(x['rank']) is int for x in rows)
            and sorted(x['rank'] for x in rows) == list(range(16)), 'all sixteen real ranks required')
    require(all(type(x['pid']) is int and x['pid'] > 0 for x in rows)
            and len({x['pid'] for x in rows}) == 16, 'duplicate/invalid worker PID')
    if eager_async_lanes:
        validate_joint_eager_async_sources(rows)
    normalized = []
    for row in sorted(rows, key=lambda x: x['rank']):
        if capture_contract is not None:
            validate_glm_worker(row, 16, draft_graph=arm != 'E_ON', capture_contract=capture_contract)
        elif arm == 'E_ON':
            validate_glm_worker(row, 16, draft_graph=False)
        else:
            validate_glm_worker(row, 16)
        require(all(type(row[k]) is int and row[k] == 16 for k in ('tp_size', 'world_size', 'draft_tp_size'))
                and Path(row['ascend_source']).resolve() == Path(source).resolve()/'vllm_ascend/__init__.py'
                and Path(row['vllm_source']).resolve() == Path(pin).resolve()/'vllm/__init__.py', 'rank source/topology differs')
        require(row['heavy_observer_enabled'] is False and row['submission_uncertain'] is False
                and type(row['target_replays']) is int and row['target_replays'] > 0
                and type(row['draft_replays']) is int
                and (row['draft_replays'] == 0 if arm == 'E_ON' else row['draft_replays'] > 0),
                'actual normal all-rank dispatch missing/uncertain')
        require(row['window_size'] == (None if arm == 'G_OFF' else 1024), 'wrong Window arm')
        if arm != 'G_OFF':
            require(row['window_provider_installed'] is (arm == 'G_ON') and row['window_generations']
                    and (bool(row['window_graph_bindings']) if arm == 'G_ON' else not row['window_graph_bindings']),
                    'observer-off provider/source/binding missing or wrong execution mode')
            if arm == 'E_ON':
                require(type(row.get('draft_eager_forward_returns')) is int and row['draft_eager_forward_returns'] > 0,
                        'actual eager Draft forward did not return')
            require(all(x['tp_rank'] == row['rank'] and x['tp_size'] == 16 for x in row['window_generations']),
                    'cross-rank Window source')
            require(all(x['tp_rank'] == row['rank'] and x['tp_size'] == 16 for x in row['window_graph_bindings']),
                    'cross-rank Window binding')
            if need_clip:
                require(any(any(s > 0 for s in x['window_starts']) for x in row['window_generations']), 'long did not clip')
            keys = ('generation', 'epoch', 'requests', 'actual', 'padded', 'window_starts', 'exact')
            if eager_async_lanes:
                keys = ('global_group_id', 'epoch', 'phase', 'step', 'requests',
                        'actual', 'padded', 'window_starts', 'exact')
            normalized.append([{k: x[k] for k in keys} for x in row['window_generations']])
        else:
            require(row['window_provider_installed'] is False and not row['window_generations']
                    and not row['window_graph_bindings'], 'OFF control contains Window provider/activity')
    require(not normalized or all(x == normalized[0] for x in normalized), 'logical all-rank Window generations differ')
    require(len({(x['draft_replays'], x['target_replays']) for x in rows}) == 1, 'all-rank Host dispatch work differs')
    if arm == 'E_ON':
        require(len({x['draft_eager_forward_returns'] for x in rows}) == 1, 'eager work differs across ranks')
    return dict(ranks=16, Draft=rows[0]['draft_replays'], Target=rows[0]['target_replays'],
                Draft_eager=rows[0].get('draft_eager_forward_returns', 0),
                source_generation_contract=('RANK_LOCAL_ASYNC_LANE_AND_SHARED_BUSINESS_EPOCH'
                    if eager_async_lanes else 'SINGLE_RUNTIME_SHARED_GENERATION'),
                count_scope='Per-rank Host manager calls, not summed over ranks or direct device occurrence')


def check_campaign(campaign, args):
    groups, kwargs = configuration(args)
    contract = getattr(args, 'comparison_contract', PAIR_CONTRACT)
    require(campaign.get('comparison_contract', PAIR_CONTRACT) == contract, 'comparison contract differs')
    require(campaign['status'] == 'NORMAL_REQUEST_COMPLETE' and campaign['startup_complete'] is True
            and campaign['source_sha'] == args.expected_sha
            and campaign['arm'] == args.arm
            and campaign['kwargs'] == kwargs and campaign['requests'] == groups
            and campaign['config_sha256'] == hashlib.sha256(json.dumps(kwargs, sort_keys=True).encode()).hexdigest()
            and campaign['requests_sha256'] == digest(args.requests)
            and campaign['profile_identity'] == profile_identity(), 'source/config/request/model identity differs')
    require(type(campaign['repetition']) is int and type(campaign['order_position']) is int
            and campaign['repetition'] == args.repetition and campaign['order_position'] == args.order_position
            and campaign['profile'] is args.profile and campaign['heavy_diagnostics'] is False,
            'normal/profile/repetition scope changed')
    group = groups[0]
    require(len(campaign['warmup_outputs']) == len(group['prompts'])
            and all(len(t) == group['max_tokens'] for t in campaign['warmup_outputs'])
            and campaign['warmup_input_ids'] == [p['prompt_token_ids'] for p in group['prompts']]
            and len(campaign['warmup_finished']) == len(group['prompts'])
            and all(x is True for x in campaign['warmup_finished']), 'full-workload warmup absent')
    output = campaign['measured']
    require(output['input_ids'] == [x['prompt_token_ids'] for x in group['prompts']]
            and len(output['tokens']) == len(output['metrics']) == len(output['finished']) == len(group['prompts'])
            and all(x is True for x in output['finished'])
            and type(output['start_ns']) is int and type(output['end_ns']) is int
            and campaign['start_monotonic_ns'] <= output['start_ns'] < output['end_ns'] <= campaign['end_monotonic_ns'],
            'actual request inputs/coverage/time differ')
    require(type(campaign['warmup_start_ns']) is int and type(campaign['warmup_end_ns']) is int
            and campaign['start_monotonic_ns'] <= campaign['startup_end_ns'] <= campaign['warmup_start_ns'] < campaign['warmup_end_ns']
            <= output['start_ns'], 'warmup did not precede the measured workload')
    if args.profile:
        for key in ('host_range_start', 'host_range_stop'):
            require(all(type(x['rank']) is int for x in campaign[key])
                    and sorted(x['rank'] for x in campaign[key]) == list(range(16)), 'Host ranges missing rank')
        require(all(x['scope'] == 'HOST_RANGES_ONLY_OFFICIAL_WORKER_IS_SOLE_NATIVE_PROFILER'
                    for x in campaign['host_range_start']), 'Host/native profiler ownership differs')
        ranges = ['Draft_materialize', 'Draft_exact_length_snapshot', 'Draft_metadata_bind',
                  'Draft_UPDATE_CALL', 'Draft_retire_host']
        require(all(x['restored'] is True and x['ranges'] == ranges for x in campaign['host_range_stop']),
                'Host range restoration failed')
    for tokens in output['tokens']:
        require(len(tokens) == group['max_tokens'] and all(type(x) is int and x >= 0 for x in tokens), 'exact output budget')
    counts = [acceptance(x['speculative_decoding']) for x in output['metrics']]
    require(all(x['finished'] is True for x in output['metrics']), 'framework request did not finish')
    work = validate_ranks(campaign['ranks'], source=getattr(args, 'producer_source', Path(__file__).resolve().parents[1]),
                          pin=campaign['vllm_checkout'], arm=args.arm,
                          need_clip=any(len(p['prompt_token_ids']) > 1024 for p in group['prompts']))
    elapsed = (output['end_ns']-output['start_ns'])/1e9
    proposed, accepted, steps = (sum(x[k] for x in counts) for k in ('proposed', 'accepted', 'verification_request_steps'))
    emitted = sum(len(t) for t in output['tokens'])
    return dict(status='PASS_SCOPED_GLM_TP16_NORMAL_WORKLOAD_AND_ACCEPTANCE', arm=args.arm,
                elapsed_seconds=elapsed, output_tokens=emitted, output_tokens_per_second=emitted/elapsed,
                input_tokens=sum(len(x['prompt_token_ids']) for x in group['prompts']),
                proposed=proposed, accepted=accepted, verification_request_steps=steps,
                acceptance_rate=accepted/proposed, mean_acceptance_length_including_bonus=1+accepted/steps,
                per_request_counts=counts, all_rank_host_dispatch=work,
                measurement='PROFILED_NOT_NORMAL_REPEAT' if args.profile else 'NORMAL_LIGHT_HOST_COUNTERS',
                profiling_collection='REQUIRES_RAW_ALL_RANK_TRACE_AUDIT' if args.profile else 'NOT_ENABLED',
                comparison_contract=contract,
                standalone_eager_comparison='EXPLICIT_THREE_ARM_CONTRACT' if contract == THREE_ARM_CONTRACT else 'NOT_AVAILABLE_IN_ORIGINAL_TWO_ARM_CONTRACT',
                ttft='NOT_AVAILABLE_OFFLINE_API', tpot='NOT_AVAILABLE_OFFLINE_API', itl='NOT_AVAILABLE_OFFLINE_API',
                device_completion='NOT_PROVEN', execution_operand='NOT_PROVEN', physical_read='NOT_PROVEN',
                scope='Artifacts only; independent source/admission/process/device/time join still required')


def run(args):
    source = Path(__file__).resolve().parents[1]
    receipt = validate_admission(args.admission, source=source, sha=args.expected_sha, tp=16)
    require(not args.output.exists(), 'new normal GLM case directory required')
    groups, kwargs = configuration(args)
    args.output.mkdir(parents=True)
    record = dict(status='STARTING', source_sha=args.expected_sha, source_tree=receipt['source_tree'],
                  pid=os.getpid(), script_sha256=digest(__file__), admission_sha256=digest(args.admission),
                  kwargs=kwargs, requests=groups, requests_sha256=digest(args.requests), arm=args.arm,
                  profile=args.profile, repetition=args.repetition, order_position=args.order_position,
                  comparison_contract=getattr(args, 'comparison_contract', PAIR_CONTRACT),
                  heavy_diagnostics=False, vllm_checkout=receipt['vllm_checkout'], profile_identity=profile_identity(),
                  config_sha256=hashlib.sha256(json.dumps(kwargs, sort_keys=True).encode()).hexdigest(),
                  started_at=time.time(),
                  start_monotonic_ns=time.monotonic_ns())
    write(args.output/'campaign.json', record)
    llm = None
    try:
        import torch_npu  # noqa: F401
        import vllm_ascend.ops  # noqa: F401
        import vllm_ascend.worker.v2.spec_decode  # noqa: F401
        from vllm import LLM, SamplingParams
        from tools.p7x_graph_repair10_performance import request_metrics
        llm = LLM(**kwargs)
        record.update(startup_complete=True, startup_end_ns=time.monotonic_ns())
        write(args.output/'campaign.json', record)
        installed = llm.collective_rpc('mrv2_rank_install_dispatch_observer', timeout=90)
        require(sorted(x['rank'] for x in installed) == list(range(16)), 'observer missing rank')
        group = groups[0]
        params = SamplingParams(temperature=0, seed=0, ignore_eos=True,
                                min_tokens=group['max_tokens'], max_tokens=group['max_tokens'])
        record['warmup_start_ns'] = time.monotonic_ns()
        outputs = llm.generate(group['prompts'], params, use_tqdm=False)
        record['warmup_end_ns'] = time.monotonic_ns()
        record['warmup_outputs'] = [list(x.outputs[0].token_ids) for x in outputs]
        record['warmup_input_ids'] = [x.prompt_token_ids for x in outputs]
        record['warmup_finished'] = [x.finished for x in outputs]
        reset = llm.collective_rpc('mrv2_glm_perf_reset', timeout=90)
        require(sorted(x['rank'] for x in reset) == list(range(16)), 'counter reset missing rank')
        if args.profile:
            record['host_range_start'] = llm.collective_rpc('mrv2_glm_profile_host_ranges', timeout=90, args=(True,))
            llm.start_profile(profile_prefix='r6_glm_tp16_G_ON')
        start = time.monotonic_ns()
        outputs = llm.generate(group['prompts'], params, use_tqdm=False)
        end = time.monotonic_ns()
        record['measured'] = dict(start_ns=start, end_ns=end, input_ids=[x.prompt_token_ids for x in outputs],
                                  tokens=[list(x.outputs[0].token_ids) for x in outputs],
                                  finished=[x.finished for x in outputs], metrics=request_metrics(outputs))
        if args.profile:
            llm.stop_profile()  # Successful request only; never a failed-forward cleanup.
            record['host_range_stop'] = llm.collective_rpc('mrv2_glm_profile_host_ranges', timeout=90, args=(False,))
        record['ranks'] = llm.collective_rpc('mrv2_rank_snapshot', timeout=90)
        record.update(status='NORMAL_REQUEST_COMPLETE', end_monotonic_ns=time.monotonic_ns(), ended_at=time.time())
        write(args.output/'campaign.json', record)
        # Same exact independent read-only artifact checker before normal shutdown.
        record['producer_check'] = check_campaign(record, args)
        write(args.output/'campaign.json', record)
        llm.llm_engine.engine_core.shutdown()
        return 0
    except BaseException as error:
        import traceback
        record.update(status='FAILED_PROCESS_ISOLATION', exception_type=type(error).__name__,
                      exception_message=str(error), traceback=traceback.format_exc(),
                      end_monotonic_ns=time.monotonic_ns(), failure_action='HOST_EXPORT_ONLY_NO_NATIVE_RECOVERY_OR_PROFILER_STOP')
        write(args.output/'campaign.json', record)
        if llm is not None:
            os._exit(74)
        raise


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=('run', 'check'))
    for name in ('requests', 'output'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--admission', type=Path)
    p.add_argument('--campaign', type=Path)
    p.add_argument('--expected-sha', required=True)
    p.add_argument('--arm', choices=('G_OFF', 'G_ON', 'E_ON'), required=True)
    p.add_argument('--comparison-contract', choices=(PAIR_CONTRACT, THREE_ARM_CONTRACT), default=PAIR_CONTRACT)
    p.add_argument('--max-model-len', type=int, choices=(4096, 24576), required=True)
    p.add_argument('--repetition', type=int, required=True)
    p.add_argument('--order-position', type=int, required=True)
    p.add_argument('--profile', action='store_true')
    a = p.parse_args()
    if a.command == 'run':
        require(a.admission is not None, 'real complete-set admission required')
        return run(a)
    require(a.campaign is not None, 'original normal campaign required')
    result = dict(status='INVALID_EVIDENCE')
    try:
        result = check_campaign(json.loads(a.campaign.read_text()), a)
    except (ValueError, KeyError, OSError, TypeError, IndexError) as error:
        result.update(error=str(error))
    write(a.output, result)
    return 0 if result['status'].startswith('PASS_SCOPED_') else 4


if __name__ == '__main__':
    raise SystemExit(main())
