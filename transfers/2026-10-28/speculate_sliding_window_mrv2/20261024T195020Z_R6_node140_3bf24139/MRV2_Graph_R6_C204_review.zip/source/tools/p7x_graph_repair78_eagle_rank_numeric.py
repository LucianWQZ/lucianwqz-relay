# SPDX-License-Identifier: Apache-2.0
"""Designated Qwen3.6 Eagle TP2 per-consumer serial numerical diagnostic.

Reuse the existing owned first/AR snapshots, canonical reference and raw
checker. Parent scheduler ownership is read from the real idle engine before
installation. Host checkpoints coordinate both ranks before collective work;
they are not production completion edges or device-execution observations.
"""
from __future__ import annotations

from pathlib import Path
import sys

if __name__ == '__main__':
    sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != Path(__file__).parent.resolve()]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
from dataclasses import asdict
import hashlib
import json
import os
import time
import traceback
from types import SimpleNamespace
import uuid

from tools import p7x_graph_repair46_eagle_rank as anchor
from tools.p7x_graph_repair15_eagle_numeric import EagleContinuousReference
from tools.p7x_graph_repair15_eagle_numeric_check import check_collection
from tools.p7x_graph_repair21_rank import digest, require, validate_admission, write
from tools.p7x_graph_repair25_rank_numeric import RankContract, validate_barrier
from tools.p7x_graph_repair6_storage import CollectionReader
from tools.p7x_graph_repair6_submission import NumericMismatch

PROFILE = 'QWEN36_EAGLE_K3_TP2_FIRST_AND_TWO_AR_NUMERIC_9_V1'
GROUPS = (('short-one', (257,)), ('long-three', (2051, 771, 387)),
          ('boundary-four', (1025, 513, 129, 127)))
STAGES = ('graph-ready', 'reference-ready', 'sample-done')


def configuration(args):
    require(args.arm == 'G_ON' and args.tp == 2 and args.qwen36_model_pair is True,
            'only the designated two-rank K3 Window ON numerical contract')
    _, kwargs = anchor.configuration(args)
    kwargs['additional_config']['draft_window_graph_numeric_diagnostic'] = True
    kwargs['worker_extension_cls'] = 'tools.p7x_graph_repair78_eagle_rank_numeric.EagleNumericWorker'
    return None, kwargs


def publish_failure(root, contract, error, pending):
    path = Path(root)/f'failed-rank-{contract.rank}.json'
    if not path.exists():
        write(path, dict(**asdict(contract), pid=os.getpid(), exception_type=type(error).__name__,
                         error=str(error), submission_pending=bool(pending), at=time.time(),
                         scope='HOST_ONLY_PEER_STOP_NOTICE_NO_DEVICE_RECOVERY'))


def checkpoint(root, contract, stage, step, *, timeout=180):
    require(stage in STAGES and type(step) is int and 0 <= step < 9, 'named consumer checkpoint required')
    root = Path(root)
    label = 3*step + STAGES.index(stage)
    write(root/f'step-{label:03}-rank-{contract.rank}.json',
          dict(**asdict(contract), step=label, stage=stage, consumer=step, status='COMPLETED_SAMPLE',
               submission_pending=False, pid=os.getpid(), at=time.time(),
               scope='ONLY_NAMED_HOST_PREPARATION_OR_COMPLETED_DIAGNOSTIC_STAGE_NOT_DEVICE_EVENT'))
    paths = [root/f'step-{label:03}-rank-{rank}.json' for rank in range(contract.world_size)]
    deadline = time.monotonic()+timeout
    while True:
        require(not any((root/f'failed-rank-{rank}.json').exists() for rank in range(contract.world_size)),
                'peer diagnostic failed; no further device submission')
        if all(path.is_file() for path in paths):
            rows = [json.loads(path.read_text()) for path in paths]
            validate_barrier(rows, contract, label)
            require(all(row['stage'] == stage and row['consumer'] == step for row in rows),
                    'peer consumer/stage differs')
            return
        if time.monotonic() >= deadline:
            raise TimeoutError('bounded Host Eagle rank checkpoint; no subsequent submission')
        time.sleep(.1)


class RankEagleReference(EagleContinuousReference):
    def __init__(self, *args, rank_contract, checkpoint_root, **kwargs):
        self.rank_contract, self.checkpoint_root = rank_contract, Path(checkpoint_root)
        super().__init__(*args, **kwargs)

    def _record_rank_failure(self, error):
        publish_failure(self.checkpoint_root, self.rank_contract, error, self.submission.pending)

    def _rank_checkpoint(self, stage, step, *, success=True):
        require(not self.submission.pending, 'Host checkpoint cannot claim an incomplete diagnostic submission')
        if not success:
            error = NumericMismatch('completed Eagle numerical sample differs; peers must stop')
            self._record_rank_failure(error)
            raise error
        checkpoint(self.checkpoint_root, self.rank_contract, stage, step)


def validate_idle_payload(payload, parallel, rank):
    contract = RankContract(2, rank, payload['nonce'], payload['parent_pid'], payload['source_sha'])
    contract.validate(parallel, rank)
    require(payload['profile'] == PROFILE and payload['scheduler_counts'] == dict(requests=0, running=0, waiting=0)
            and type(payload['engine_id']) is int and payload['engine_id'] > 0
            and payload['groups'] == [[label, list(lengths)] for label, lengths in GROUPS],
            'actual exclusive parent scheduler/model request contract differs')
    return contract


class EagleNumericWorker(anchor.EagleRankWorker):
    def mrv2_eagle_numeric_install(self, payload):
        import torch
        require(not hasattr(self, '_eagle_numeric'), 'one-shot per disposable worker')
        contract = validate_idle_payload(payload, self.vllm_config.parallel_config, self.rank)
        require(self.model_runner.speculator._eagle3_window_proposal_context is None,
                'worker already has an active proposal')
        identity = dict(source_sha=payload['source_sha'], source_tree=payload['source_tree'],
                        process_id=os.getpid(), engine_id=payload['engine_id'], run_id=payload['run_id'],
                        case_id=f'EAGLE_TP2_NUMERIC_RANK_{self.rank}', attempt_id='1',
                        driver_mode='ACTUAL_SERVICE_REQUESTS_WITH_SERIAL_RANK_DIAGNOSTIC')
        output = Path(payload['output'])/'numeric'/f'rank-{self.rank}'/'eagle-numeric.json'
        output.parent.mkdir(parents=True, exist_ok=False)
        # This view is the immutable, nonce-bound parent snapshot. The worker
        # does not pretend to read or own the actual scheduler object.
        scheduler = SimpleNamespace(**{key: [] for key in payload['scheduler_counts']})
        self._eagle_numeric = RankEagleReference(self.model_runner, scheduler, output, identity,
            [dict(label=label, prompts=[{} for _ in lengths]) for label, lengths in GROUPS],
            rank_contract=contract, checkpoint_root=Path(payload['output'])/'host-checkpoints')
        self._eagle_numeric_payload = payload
        try:
            with torch.inference_mode():
                self._eagle_numeric.__enter__()
        except BaseException as error:
            self._eagle_numeric._record_rank_failure(error)
            if self._eagle_numeric.submission.pending: os._exit(74)
            raise
        return dict(rank=self.rank, path=str(output), identity=identity,
                    scheduler_authority='ACTUAL_EMPTY_PARENT_SNAPSHOT_EXCLUSIVE_NON_SERVING_ENGINE')

    def mrv2_eagle_numeric_group(self, label):
        self._eagle_numeric.set_group(label)
        return dict(rank=self.rank, group=label)

    def mrv2_eagle_numeric_finish(self):
        probe = self._eagle_numeric
        require(not probe.submission.pending and not probe.failed, 'failed/uncertain diagnostic cannot finish')
        probe.__exit__(None)
        path = probe.output.with_name('eagle-numeric-summary.json')
        summary = json.loads(path.read_text())
        require(summary['complete'] is True and len(summary['samples']) == 9, 'all nine consumers required')
        return dict(rank=self.rank, collection=str(probe.output), collection_sha256=digest(probe.output),
                    summary=str(path), summary_sha256=digest(path), identity=probe.identity)


def run(args):
    source = Path(__file__).resolve().parents[1]
    receipt = validate_admission(args.admission, source=source, sha=args.expected_sha, tp=2)
    require(not args.output.exists(), 'new attempt directory required')
    args.output.mkdir(parents=True)
    _, kwargs = configuration(args)
    record = dict(status='STARTING', source_sha=args.expected_sha, source_tree=receipt['source_tree'],
        script_sha256=digest(__file__), pid=os.getpid(),
        start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19], started_at=time.time(),
        arm='G_ON', tp=2, sampling=dict(anchor.SAMPLING), kwargs=kwargs,
        config_sha256=hashlib.sha256(json.dumps(kwargs,sort_keys=True).encode()).hexdigest(),
        qwen36_model_pair=True, profile_identity=anchor.qwen36_identity(), numeric_profile=PROFILE,
        fixture_sha256=None, fixture_receipt_sha256=None, admission_sha256=digest(args.admission),
        requests=[], scope='SERIAL_CAPTURE_COPIES_AND_REAL_EAGER_REFERENCE_NOT_NORMAL_OVERLAP_OR_PERFORMANCE')
    write(args.output/'campaign.json', record)
    llm = None
    try:
        import torch_npu  # noqa: F401
        import vllm_ascend.ops  # noqa: F401
        import vllm_ascend.worker.v2.spec_decode  # noqa: F401
        from vllm import LLM, SamplingParams
        llm = LLM(**kwargs)
        core = llm.llm_engine.engine_core.engine_core
        counts = {key: len(getattr(core.scheduler,key)) for key in ('requests','running','waiting')}
        require(counts == dict(requests=0,running=0,waiting=0), 'actual parent scheduler not empty')
        record['installed_observers'] = llm.collective_rpc('mrv2_rank_install_dispatch_observer', timeout=90)
        nonce = uuid.uuid4().hex
        before = llm.collective_rpc('mrv2_eagle_rank_identity', timeout=90, args=(nonce,))
        record['before'] = dict(nonce=nonce,ranks=before)
        write(args.output/'campaign.json',record)
        anchor.validate_ranks(before,arm='G_ON',nonce=nonce,source=source,pin=args.vllm_repo,after=False,
                              qwen36=True,numeric_diagnostic=True)
        payload = dict(profile=PROFILE,nonce=uuid.uuid4().hex,parent_pid=os.getpid(),source_sha=args.expected_sha,
            source_tree=receipt['source_tree'],run_id=args.run_id,engine_id=id(core),scheduler_counts=counts,
            groups=[[label,list(lengths)] for label,lengths in GROUPS],output=str(args.output))
        record['numeric_payload'] = payload
        record['numeric_installed'] = llm.collective_rpc('mrv2_eagle_numeric_install',timeout=180,args=(payload,))
        write(args.output/'campaign.json',record)
        for label,lengths in GROUPS:
            llm.collective_rpc('mrv2_eagle_numeric_group',timeout=90,args=(label,))
            prompts=[dict(prompt_token_ids=[100+i]*n) for i,n in enumerate(lengths)]
            start=time.monotonic_ns()
            outputs=llm.generate(prompts,SamplingParams(**anchor.SAMPLING),use_tqdm=False)
            require(len(outputs)==len(prompts) and all(x.finished and len(x.outputs[0].token_ids)==32 for x in outputs),
                    'real bounded service request did not finish')
            nonce=uuid.uuid4().hex
            ranks=llm.collective_rpc('mrv2_eagle_rank_identity',timeout=90,args=(nonce,))
            record['requests'].append(dict(label=label,prompts=prompts,start_ns=start,end_ns=time.monotonic_ns(),
                token_ids=[list(x.outputs[0].token_ids) for x in outputs],finished=[x.finished for x in outputs],
                metrics=anchor.request_metrics(outputs),nonce=nonce,ranks=ranks))
            write(args.output/'campaign.json',record)
            anchor.validate_ranks(ranks,arm='G_ON',nonce=nonce,source=source,pin=args.vllm_repo,after=True,
                                  qwen36=True,numeric_diagnostic=True)
        record['numeric_finished']=llm.collective_rpc('mrv2_eagle_numeric_finish',timeout=90)
        record['status']='ALL_TWO_RANK_EAGLE_REQUEST_ANCHOR_COMPLETE_NOT_NUMERIC_VALIDATION'
    except BaseException as error:
        record.update(status='EXCEPTION_ISOLATION_REQUIRED',exception_type=type(error).__name__,
                      exception_message=str(error),traceback=traceback.format_exc(),
                      unknown_native_submission=llm is not None,post_error_device_operations='NONE_BY_THIS_PARENT')
        write(args.output/'campaign.json',record)
        os._exit(74)  # No post-error worker RPC, recovery drain or suspicious reuse.
    record['ended_at']=time.time()
    write(args.output/'campaign.json',record)
    llm.llm_engine.engine_core.shutdown()
    return 0


def check_numeric(campaign, execution, *, args, source, pin, admission):
    result=anchor.validate_saved(campaign,execution,args=args,source=source,pin=pin,admission=admission,
        request_plan=GROUPS,kwargs_factory=configuration,entrypoint_name=Path(__file__).name,
        numeric_diagnostic=True)
    require(campaign['numeric_profile']==PROFILE and len(campaign['numeric_finished'])==2,
            'all rank numerical indices required')
    checked=[]
    for row in campaign['numeric_finished']:
        rank=row['rank']
        require(type(rank) is int and rank in (0,1), 'typed complete numerical rank required')
        worker=next(w for w in campaign['before']['ranks'] if w['rank']==rank)
        identity=dict(source_sha=campaign['source_sha'],source_tree=campaign['source_tree'],process_id=worker['pid'],
            engine_id=campaign['numeric_payload']['engine_id'],run_id=args.run_id,
            case_id=f'EAGLE_TP2_NUMERIC_RANK_{rank}',attempt_id='1',
            driver_mode='ACTUAL_SERVICE_REQUESTS_WITH_SERIAL_RANK_DIAGNOSTIC')
        path=Path(row['collection'])
        require(path==args.output/'numeric'/f'rank-{rank}'/'eagle-numeric.json'
                and digest(path)==row['collection_sha256'] and row['identity']==identity,
                'collection path/hash/source identity differs')
        verdict=check_collection(path,identity)
        require(verdict['status']=='PASS_SCOPED_EAGLE3_SERIAL_CONTINUOUS',
                'raw per-consumer numerical or Full-write checker failed: '+json.dumps(verdict))
        reader=CollectionReader(path)
        for index in range(9):
            sample=reader.record(index);runtime=sample['runtime_identity']
            actual=next(group for group in campaign['requests'] if group['label']==sample['group'])
            current=next(w for w in actual['ranks'] if w['rank']==rank)
            bindings=[b for b in current['window_graph_bindings']
                      if (b['generation'],b['epoch'])==(runtime['generation_id'],runtime['mapping_epoch'])]
            proposals=[g for g in current['window_generations'] if g['epoch']==runtime['mapping_epoch'] and g['step']==0]
            require(len(bindings)==len(proposals)==1,'missing/duplicate actual consumer binding or proposal')
            binding,proposal=bindings[0],proposals[0]
            require(binding['capture_bucket']==sample['descriptor']
                    and binding['global_group_id']==reader.header['global_group_id']==proposal['global_group_id']
                    and proposal['requests']==runtime['ordered_request_fingerprint']
                    and proposal['actual']==sample['active']
                    and proposal['window_starts']==[o['S'] for o in sample['oracle']],
                    'numeric consumer differs from actual Host proposal/bank binding')
        checked.append(dict(rank=rank,collection=str(path),sha256=digest(path),verdict=verdict))
    require(sorted(row['rank'] for row in checked)==[0,1],'complete distinct two numerical ranks')
    result.update(status='PASS_SCOPED_QWEN36_EAGLE_TP2_9_CONSUMERS_SERIAL_NUMERIC',numeric=checked,
                  normal_overlap='UNPROVEN_SERIAL_DIAGNOSTIC',
                  scope='Actual TP2 firstQ4 and both ARQ1 consumers; independent canonical same-prestate eager and '
                        'retained Full-write checks; not complete Target isolation/ABA/normal overlap/performance')
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--admission',type=Path,required=True);p.add_argument('--vllm-repo',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--expected-sha',required=True)
    p.add_argument('--run-id',required=True);p.add_argument('--case-id',required=True)
    p.add_argument('--qwen36-model-pair',action='store_true',required=True)
    p.add_argument('--arm',choices=['G_ON'],default='G_ON');p.add_argument('--tp',type=int,choices=[2],default=2)
    args=p.parse_args()
    return run(args)


if __name__=='__main__':raise SystemExit(main())
