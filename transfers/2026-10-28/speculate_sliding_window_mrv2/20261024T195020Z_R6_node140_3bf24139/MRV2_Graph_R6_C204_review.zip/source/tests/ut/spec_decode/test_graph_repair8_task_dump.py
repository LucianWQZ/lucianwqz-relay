# SPDX-License-Identifier: Apache-2.0
"""Native export safety gates, immutable index, corruption rejection; CPU only."""

import json
from types import SimpleNamespace
from typing import NamedTuple

import pytest

from tools import p7x_graph_repair8_task_dump as tool
from tools.p7x_graph_repair6_storage import digest


class Descriptor(NamedTuple):
    num_reqs: int
    num_tokens: int


def fixture(tmp_path):
    calls, records, graphs = [], [], {}
    for requests in (1, 2, 4):
        desc = Descriptor(requests, requests * 7)

        def dump(path, desc=desc):
            calls.append(desc)
            from pathlib import Path

            Path(path).write_text(json.dumps(dict(tasks=[dict(task_id=desc.num_tokens)])))

        graphs[desc] = SimpleNamespace(debug_dump=dump)
        records.append(dict(descriptor=list(desc), completion="DIAGNOSTIC_COMPLETE", retired=True,
                            generation=requests, epoch=requests, backing=dict(owner_id=42), complete_ns=1))
    lifecycle = SimpleNamespace(poisoned=False, records=records)
    spec = SimpleNamespace(query_cudagraph_manager=SimpleNamespace(graphs=graphs))
    return spec, lifecycle, calls, tmp_path / "task-dump-index.json"


@pytest.mark.parametrize("unsafe", ["quarantine", "no_record", "pending", "not_retired", "uncertain"])
def test_no_native_call_or_output_for_unsafe_life(tmp_path, unsafe):
    spec, life, calls, path = fixture(tmp_path)
    if unsafe == "quarantine":
        life.poisoned = True
    elif unsafe == "no_record":
        life.records = []
    elif unsafe == "pending":
        life.records[0]["completion"] = "UNPROVEN"
    elif unsafe == "not_retired":
        life.records[0]["retired"] = False
    else:
        spec._draft_window_graph_submission_uncertain = True
    with pytest.raises(ValueError):
        tool.completed_graph_dump(spec, life, path, {})
    assert not calls and not path.exists() and not (tmp_path / "native-graph-json").exists()


@pytest.mark.parametrize("damage", [None, "native_hash", "life_hash", "generation", "descriptor"])
def test_export_index_and_reject_corrupted_joins(monkeypatch, tmp_path, damage):
    import tools.p7x_graph_repair5_evidence as evidence

    # External association is tested independently; here exercise native/LIFE
    # joins using bytes actually written by the exporter and real hash checks.
    monkeypatch.setattr(evidence, "audit_execution", lambda *a, **kw: dict(status="EXECUTION_ASSOCIATED"))
    spec, life, calls, path = fixture(tmp_path)
    doc = tool.completed_graph_dump(spec, life, path, dict(process_id=123))
    assert len(calls) == 3 and doc["task_operand"] == "UNPROVEN_PENDING_FIELD_ANALYSIS"
    life_path = tmp_path / "mrv2-lifecycle.json"
    life_path.write_text(json.dumps(dict(identity=doc["identity"], records=life.records)))
    campaign = dict(diagnostic_artifacts={life_path.name: dict(bytes=life_path.stat().st_size, sha256=digest(life_path))})
    if damage == "native_hash":
        (tmp_path / doc["records"][0]["path"]).write_text("{}")
    elif damage == "life_hash":
        life_path.write_text("{}")
    elif damage == "generation":
        doc["records"][0]["last_life_generation"] += 1
    elif damage == "descriptor":
        doc["records"][0]["descriptor"] = [4, 32]
    launcher = dict(host_start_ns=0, host_end_ns=10**30)
    result = tool.check(doc, campaign, launcher, {}, path)
    assert (result["status"] == "PASS_SCOPED_NATIVE_JSON_COLLECTION") is (damage is None), result


def test_oversized_export_is_preserved_and_stops_more_exports(monkeypatch, tmp_path):
    spec, life, calls, path = fixture(tmp_path)
    monkeypatch.setattr(tool, "MAX_EXPORT_BYTES", 1)
    result = tool.completed_graph_dump(spec, life, path, {})
    assert result["status"] == "EXPORT_FAILED" and len(calls) == 1
    assert (tmp_path / result["records"][0]["path"]).is_file()
    assert json.loads(path.read_text())["records"][0]["status"] == "EXPORT_FAILED"
