# SPDX-License-Identifier: Apache-2.0
"""Opt-in output references are not a new graph output/completion contract."""

from contextlib import contextmanager
from types import SimpleNamespace

import pytest
import torch
from vllm.config.compilation import CUDAGraphMode

from vllm_ascend.worker.v2.spec_decode.dflash.speculator import AscendDFlashSpeculator
from vllm_ascend.worker.v2.spec_decode.draft_window_graph_diagnostics import DraftGraphOutputReferences
from vllm_ascend.worker.v2.spec_decode.dspark.speculator import AscendDSparkSpeculator


@pytest.mark.parametrize("owner_type,query", [(AscendDSparkSpeculator, 7), (AscendDFlashSpeculator, 16)])
def test_real_forward_default_off_and_retained_capture_references(monkeypatch, owner_type, query):
    import vllm.v1.worker.gpu.spec_decode.dflash.speculator as upstream

    @contextmanager
    def context(*args, **kwargs):
        yield

    monkeypatch.setattr(upstream, "set_forward_context", context)
    owner = owner_type.__new__(owner_type)
    owner.vllm_config = object()
    owner.input_buffers = SimpleNamespace(input_ids=torch.arange(4 * query), positions=torch.arange(4 * query))

    class Model(torch.nn.Module):
        def forward(self, input_ids, positions, inputs_embeds):
            return torch.stack((input_ids, positions), 1).to(torch.bfloat16)

    owner.model = Model()
    assert owner._run_model(query, {}, {}, None).shape == (query, 2)
    assert not hasattr(owner, "_draft_graph_output_references")
    sink = owner._draft_graph_output_references = DraftGraphOutputReferences(owner)
    outputs = {}
    for n in (query, 2 * query, 4 * query):
        owner._run_model(n, {}, {}, None)  # eager warmup not captured
        assert n not in sink.outputs
        outputs[n] = owner._run_model(n, {}, {}, None, CUDAGraphMode.FULL)
    sink.freeze([query, 2 * query, 4 * query])
    assert all(sink.get(owner, n) is outputs[n] for n in outputs)
    with pytest.raises(RuntimeError, match="owner/scope"):
        sink.retain(owner, query, outputs[query])
    with pytest.raises(RuntimeError, match="foreign"):
        sink.get(object(), query)


def test_inventory_missing_bucket_and_wrong_output_rejected():
    owner = object()
    sink = DraftGraphOutputReferences(owner)
    with pytest.raises(RuntimeError, match="output contract"):
        sink.retain(owner, 7, None)
    sink.retain(owner, 7, torch.zeros(7, 4))
    with pytest.raises(RuntimeError, match="inventory"):
        sink.freeze([7, 14, 28])


def test_owned_mode_preserves_both_original_and_copied_output():
    owner=object();sink=DraftGraphOutputReferences(owner,owned=True)
    value=torch.zeros(8,4);sink.retain(owner,8,value);value.fill_(3);sink.freeze([8])
    assert torch.count_nonzero(sink.get(owner,8))==0
    assert torch.all(sink.raw(owner,8)==3)
    assert sink.get(owner,8).data_ptr()!=sink.raw(owner,8).data_ptr()


def test_one_attention_probe_records_real_dispatch_parameters_without_update_hook():
    from types import SimpleNamespace as N
    owner=object();sink=DraftGraphOutputReferences(owner,owned=True)
    class Impl:
        def _get_fia_params(self,key,value,metadata,kv_cache=None):
            if metadata.attn_state.name=='PrefillNoCache':return key,value,128,None,[8]
            return torch.zeros(32,128,1,2),torch.zeros(32,128,1,2),128,metadata.block_tables,[8201]
        def forward_fused_infer_attention(self,query,key,value,metadata,output,kv_cache=None):
            self._get_fia_params(key,value,metadata,kv_cache)
            return output.copy_(query*2)
    def meta(state):
        return N(attn_state=N(name=state),causal=False,seq_lens_list=[8201],actual_seq_lengths_q=[8],
                 num_actual_tokens=8,num_prefills=1,num_decodes=0,max_query_len=8,
                 block_tables=torch.zeros(1,128,dtype=torch.int32),attn_mask=None)
    impl=Impl();sink.install_attention_probe(impl);sink.collecting=True
    query=torch.ones(8,1,2);output=torch.zeros_like(query)
    impl.forward_fused_infer_attention(query,query,query,meta('ChunkedPrefill'),output)
    output.fill_(99);query.fill_(5)
    saved=sink.attention[8]
    assert torch.all(saved['query']==1) and torch.all(saved['output']==2)
    assert saved['parameters']['table'] is not None
    sink.collecting=False;sink.reference_active=True
    impl.forward_fused_infer_attention(query,query,query,meta('PrefillNoCache'),output)
    assert sink.reference_attention['parameters']['table'] is None
    assert sink.reference_attention['parameters']['key']['shape']==[8,1,2]
    assert torch.all(saved['output']==2)  # Reference did not replace captured evidence.
    with pytest.raises(RuntimeError,match='single-layer'):sink.install_attention_probe(impl)


def test_attention_probe_seam_matches_actual_backend():
    import inspect
    from vllm_ascend.attention.attention_v1 import AscendAttentionBackendImpl
    assert list(inspect.signature(AscendAttentionBackendImpl.forward_fused_infer_attention).parameters)==[
        'self','query','key','value','attn_metadata','output','kv_cache']
    assert list(inspect.signature(AscendAttentionBackendImpl._get_fia_params).parameters)==[
        'self','key','value','attn_metadata','kv_cache']


def test_owned_probe_selects_actual_reader_and_preserves_swa_full_selection():
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph_diagnostics import owned_attention_probe_layer

    owner = SimpleNamespace(_draft_window_source_capability=SimpleNamespace(native_swa_graph=None),
                            draft_attn_layer_names=['layer41', 'layer40'], _group_causal={3: False})
    assert owned_attention_probe_layer(owner) == 'layer40'
    for flags in (True, {3: True}, {}, {3: 0}):
        owner._group_causal = flags
        with pytest.raises(RuntimeError):
            owned_attention_probe_layer(owner)
    owner._draft_window_source_capability.native_swa_graph = SimpleNamespace(full_layers=('swa_last_full',))
    assert owned_attention_probe_layer(owner) == 'swa_last_full'


def test_owned_query_snapshot_precedes_an_aliasing_decoder():
    sink = DraftGraphOutputReferences(object(), owned=True)
    class Impl:
        def _get_fia_params(self, key, value, metadata, kv_cache=None):
            return key, value, 128, None, [8]
        def forward_fused_infer_attention(self, query, key, value, metadata, output, kv_cache=None):
            query.add_(10)
            return output.copy_(query)
    impl = Impl()
    sink.install_attention_probe(impl)
    sink.collecting = True
    meta = SimpleNamespace(attn_state=SimpleNamespace(name='PrefillNoCache'), causal=False,
        seq_lens_list=[8], actual_seq_lengths_q=[8], num_actual_tokens=8, num_prefills=1,
        num_decodes=0, max_query_len=8, block_tables=None, attn_mask=None)
    query = torch.ones(8, 1, 2)
    impl.forward_fused_infer_attention(query, query, query, meta, torch.zeros_like(query))
    assert torch.all(sink.attention[8]['query'] == 1)
    assert torch.all(sink.attention[8]['output'] == 11)


@pytest.mark.parametrize("method", ["dspark", "dflash"])
def test_capture_configuration_gate_is_not_bypass(monkeypatch, method):
    import importlib

    module = importlib.import_module(f"vllm_ascend.worker.v2.spec_decode.{method}.speculator")
    owner_type = AscendDSparkSpeculator if method == "dspark" else AscendDFlashSpeculator

    owner = owner_type.__new__(owner_type)
    owner.vllm_config = SimpleNamespace(additional_config={"draft_window_graph_numeric_diagnostic": True})
    monkeypatch.setattr(module, "experimental_draft_window_graph_characterization_enabled", lambda: False)
    with pytest.raises(RuntimeError, match="experimental Graph gate"):
        owner.capture()
    assert not hasattr(owner, "_draft_graph_output_references")
