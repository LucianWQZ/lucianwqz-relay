# SPDX-License-Identifier: Apache-2.0
"""Accepted fault ≠ normal completion; arbitrary failures never authorize continuation."""
import copy

import pytest

from tools.p7x_graph_repair26_fault_outcomes import expected_parallel_python_isolation


def evidence(point):
    identity=dict(run_id="run",case_id=f"UNWIND_DSPARK_Q8_{point}",attempt_id="1",
                  source_sha="a"*40,source_tree="b"*40,driver_mode="B-observer-off")
    case=dict(case_id=identity["case_id"],unwind_point=point,acceptance_identity=identity,
              argv=["python","driver","run","--repair8-unwind-at",point])
    campaign=dict(identity=dict(identity,process_id=123),exception_type="InjectedGraphUnwindError",
                  exception_message="REPAIR8_PYTHON_UNWIND:"+point,graph_submission_uncertain=True,
                  diagnostic_quarantine="PROCESS_EXIT_74_NO_REUSE",
                  diagnostic_artifacts={"python-unwind.json":dict(sha256="hash")})
    launcher=dict(argv=case["argv"],pid=123,returncode=74,signal=None,timeout=False)
    checker=dict(status="PASS_SCOPED_PYTHON_UNWIND_ISOLATION",point=point,native_partial_submission="NOT_SIMULATED",
                 execution=dict(status="EXECUTION_ASSOCIATED",artifact_sha256="hash"))
    runner=dict(status="SCOPED_COMMANDS_ACCEPTED",dependency_satisfied=True,
                source_identity=["run","a"*40,"b"*40],
                records=[dict(argv=["python","p7x_graph_repair8_unwind.py"],returncode=0,timeout=False)])
    return case,campaign,launcher,checker,runner


@pytest.mark.parametrize("point", ["before_replay","after_replay","after_update","after_completion"])
def test_only_new_process_allowed_old_backing_and_completion_stay_unproven(point):
    result=expected_parallel_python_isolation(*evidence(point),artifact_sha256="hash",
                                             old_process_gone=True,old_device_pid_absent=True)
    assert result["allow_fresh_process"] and result["status"]=="EXPECTED_PYTHON_FAULT_PROCESS_ISOLATED"
    assert result["old_backing_reuse"]=="FORBIDDEN" and result["prior_device_completion"]=="NOT_INFERRED"


@pytest.mark.parametrize("damage", ["other_exception","wrong_point","source","pid","timeout","signal","exit",
                                    "checker_missing","unjoined","hash","native_failure","quarantine","live","unknown_device"])
def test_wrong_or_incomplete_fault_outcome_keeps_global_stop(damage):
    case,campaign,launcher,checker,runner=copy.deepcopy(evidence("after_update"))
    gone=device=True
    if damage=="other_exception":campaign["exception_type"]="RuntimeError"
    elif damage=="wrong_point":campaign["exception_message"]="REPAIR8_PYTHON_UNWIND:after_replay"
    elif damage=="source":runner["source_identity"][1]="c"*40
    elif damage=="pid":launcher["pid"]=456
    elif damage=="timeout":launcher["timeout"]=True
    elif damage=="signal":launcher["signal"]=9
    elif damage=="exit":launcher["returncode"]=-9
    elif damage=="checker_missing":runner["records"]=[]
    elif damage=="unjoined":checker["execution"]["status"]="INVALID_EVIDENCE"
    elif damage=="hash":checker["execution"]["artifact_sha256"]="changed"
    elif damage=="native_failure":checker["native_partial_submission"]="UNKNOWN_NATIVE"
    elif damage=="quarantine":campaign["diagnostic_quarantine"]="RECOVERED"
    elif damage=="live":gone=False
    else:device=None
    result=expected_parallel_python_isolation(case,campaign,launcher,checker,runner,artifact_sha256="hash",
                                             old_process_gone=gone,old_device_pid_absent=device)
    assert not result["allow_fresh_process"] and result["status"]=="NOT_ESTABLISHED"
