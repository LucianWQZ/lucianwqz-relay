# SPDX-License-Identifier: Apache-2.0
"""GLM's named K8/SFA/indexer contract rejects dense ABI and damaged evidence."""
import copy
from types import SimpleNamespace

import pytest
import torch

from tools.p7x_graph_repair12_contract import method_for_profile, validate_method_document
from tools.p7x_graph_repair37_glm_target import (
    COMPONENTS, INDEXER, ORIGIN, PROFILE, SFA, GLMControlledTarget,
    heterogeneous_resource_plan, isolation_errors, validate_components, validate_record,
)
from tools.p7x_graph_repair4_target import FullForwardCheckpointer, _snapshot, _snapshot_value
from tools.p7x_graph_repair5_target import case_plan, sample_identity


def components():
    return [dict(name=f"target.{kind}.{i}", metadata_class=kind, global_group_id=0,
                 caches=tuple(torch.zeros(2, 128, 1, dim, dtype=torch.bfloat16) for _, dim in COMPONENTS[kind]))
            for kind, count in ((SFA, 78), (INDEXER, 21)) for i in range(count)]


def test_named_method_preserves_old_profiles_and_distinguishes_glm_target_q9():
    method = method_for_profile(PROFILE)
    assert (method.k, method.draft_query, method.target_query, method.sample_offset) == (8, 8, 9, 0)
    assert method.sample_from_anchor and not method.causal
    assert method_for_profile("target4").draft_query == 7
    assert method_for_profile("dspark_k7_noanchor_q8").target_query == 8
    cases = case_plan(PROFILE)
    assert len(cases) == 14 and all(case["query_width"] == 9 for case in cases)
    assert cases[-2]["ends"][0]+8 == 1024 and cases[-1]["ends"][0]+8 == 1152
    bad = method.document(); bad["k"] = 7
    with pytest.raises(ValueError): validate_method_document(PROFILE, bad)
    with pytest.raises(ValueError): method_for_profile("glm-inferred-from-shape")


@pytest.mark.parametrize("damage", ["missing", "duplicate", "c8", "head", "dtype", "stride", "offset", "group", "alias"])
def test_all_177_components_required_and_corrupt_native_layout_rejected(damage):
    rows = components()
    assert len(validate_components(rows)) == 177
    if damage == "missing": rows.pop()
    elif damage == "duplicate": rows[-1]["name"] = rows[0]["name"]
    elif damage == "c8": rows[-1]["caches"] += (torch.zeros(2,128,1,1),)
    elif damage == "head": rows[-1]["caches"] = (torch.zeros(2,128,2,128,dtype=torch.bfloat16),)
    elif damage == "dtype": rows[-1]["caches"] = (rows[-1]["caches"][0].float(),)
    elif damage == "stride": rows[0]["caches"] = tuple(t.transpose(0,1) for t in rows[0]["caches"])
    elif damage == "offset": rows[-1]["caches"] = (torch.zeros(3,128,1,128,dtype=torch.bfloat16)[1:],)
    elif damage == "group": rows[-1]["global_group_id"] = 1
    else: rows[-1]["caches"] = rows[-2]["caches"]
    with pytest.raises(ValueError): validate_components(rows)


def test_budget_sums_real_heterogeneous_components_without_dedup_or_dense_multiplier():
    caches = validate_components(components())
    budget = heterogeneous_resource_plan(case_plan(PROFILE), caches, hidden_size=6144, vocab_size=154880,
                                         metadata_bytes=1024, sample_limit=3)
    assert budget["bytes_per_block"] == (78*(512+64)+21*128)*128*2
    assert budget["component_count"] == 177 and len(budget["samples"]) == 3
    assert not budget["compression_assumed"] and not budget["content_dedup_assumed"]
    assert budget["phases"]["both_arms_retained"] > budget["required_free_bytes"]
    with pytest.raises(ValueError): heterogeneous_resource_plan(case_plan(PROFILE), {}, hidden_size=1,vocab_size=1,metadata_bytes=0)


@pytest.fixture(scope="module")
def complete_record():
    rows = components(); kv = validate_components(rows)
    table = torch.tensor([[1]],dtype=torch.int32)
    slots = torch.arange(128+23,128+32,dtype=torch.int32)
    lengths = [32]; case = case_plan(PROFILE)[3]
    case = dict(case,step=0)
    names = [row["name"] for row in rows]
    layers = {row["name"]:dict(metadata_class=row["metadata_class"],num_actual_tokens=9,block_size=128,
            seq_lens=torch.tensor(lengths,dtype=torch.int32),declared_exact_lengths=lengths,
            cum_query_lens=torch.tensor([9],dtype=torch.int32),slot_mapping=slots,block_table=table) for row in rows}
    inputs = dict(input_ids=torch.full((9,),17,dtype=torch.int32),positions=torch.arange(23,32,dtype=torch.int64),
        query_start_loc=torch.tensor([0,9],dtype=torch.int32),seq_lens=torch.tensor([32],dtype=torch.int32),is_padding=torch.zeros(9,dtype=torch.bool),
        req_ids=['row-0'],num_reqs=1,num_tokens=9,descriptor=(9,1,9,9),layers=layers,target_layer_names=names)
    writes={key:slots for key in kv};blocks={key:torch.tensor([1],dtype=torch.int64) for key in kv}
    reads={key:dict(table=table,lengths=lengths) for key in kv}
    probe = FullForwardCheckpointer(fixture_id="host",max_bytes=200*1024**2,max_records=1)
    hidden = torch.ones((9,2),dtype=torch.bfloat16)
    def forward():
        for tensor in kv.values(): tensor[1,23:32].fill_(1)
        return hidden
    probe.run(forward,inputs=inputs,kv_access=lambda:kv,write_slots=writes,synchronize=lambda:None,
              origin=ORIGIN,block_ids=blocks,declared_reads=reads)
    checkpoint=probe.records[0]
    record=dict(identity=sample_identity(case,"host"),generation=0,checkpoint=checkpoint,
                hidden=hidden.clone(),logits=torch.ones(9,4),block_owners={1:("row-0",0)},
                outside_before={"host":"same"},outside_after={"host":"same"})
    record["target_after_draft"]=dict(root_same=True,outside=record["outside_after"],kv=checkpoint["kv_after"],
        inputs=checkpoint["inputs"],draft_slots=torch.arange(160,168,dtype=torch.int64),
        draft_positions=torch.arange(32,40,dtype=torch.int64),draft_query=torch.tensor([0,8],dtype=torch.int32))
    record["target_post_forward_inputs"]=checkpoint["inputs"]
    record["target_metadata_owner_after_target"]={"host-owner":1}
    record["target_metadata_owner_after_draft"]={"host-owner":1}
    return record


def test_real_checkpoint_shape_revalidates_every_component_and_isolation(complete_record):
    assert len(validate_record(complete_record)) == 99
    assert isolation_errors(complete_record) == []


@pytest.mark.parametrize("damage", ["origin","missing_component","length","slot","output","outside","kv_write","dtype"])
def test_saved_status_cannot_hide_damaged_glm_evidence(complete_record,damage):
    bad = copy.deepcopy(complete_record)
    checkpoint=bad["checkpoint"]
    if damage == "origin": checkpoint["origin"]="LIVE_ASCEND_TARGET_FULL_GRAPH"
    elif damage == "missing_component": checkpoint["kv_keys"].pop()
    elif damage in ("length","slot","dtype"):
        data=_snapshot_value(checkpoint["inputs"])
        name=data["target_layer_names"][-1]
        if damage == "length": data["layers"][name]["seq_lens"]=torch.tensor([31],dtype=torch.int32)
        elif damage == "slot": data["layers"][name]["slot_mapping"]=torch.zeros(9,dtype=torch.int64)
        else: data["input_ids"]=data["input_ids"].long()
        checkpoint["inputs"]=_snapshot(data,[200*1024**2])
    elif damage == "output": bad["hidden"][0,0]=2
    elif damage == "outside": bad["outside_after"]={"host":"changed"}
    else:
        first=next(iter(checkpoint["kv_after"]["tensors"].values()))
        first["data"][0,0,0,0]=1
    with pytest.raises(ValueError): validate_record(bad)


@pytest.mark.parametrize("limit", [3,None])
def test_glm_k8_uses_real_continuous_reference_storage_checker_with_exact_dtype(monkeypatch,tmp_path,limit):
    from tests.ut.spec_decode.test_graph_repair6_numeric_pipeline import produce, joined
    from tools.p7x_graph_repair6 import joint
    path,contract,snapshot=produce(monkeypatch,tmp_path,sample_limit=limit,profile=PROFILE)
    campaign,launcher,plan=joined(path,contract,snapshot)
    if limit:
        plan["numeric_samples"]=3
        plan["argv"] += ["--repair6-target-prefix","3"]
        plan["launch_argv"] += ["--repair6-target-prefix","3"]
        launcher["argv"]=plan["argv"]
    result=joint(path,campaign,launcher,plan,"numeric")
    assert result["status"] == ("PASS_NUMERIC_SENTINEL_ONLY" if limit else "PASS_DIAGNOSTIC_CONTINUOUS_REFERENCE"),result
    assert result["aba"] == "PASS_SCOPED"


def test_live_metadata_view_observes_real_rebindings_and_headers_without_device_read(monkeypatch):
    import tools.p7x_graph_repair37_glm_target as module
    first=torch.tensor([32],dtype=torch.int32)
    m=SimpleNamespace(seq_lens=first,slot_mapping=torch.arange(9))
    runner=SimpleNamespace(model_state=SimpleNamespace(attn_metadata={"target":m}))
    monkeypatch.setattr(module,"metadata_values",lambda x:dict(metadata_class=SFA,seq_lens=x.seq_lens,slot_mapping=x.slot_mapping))
    view=module.LiveTargetMetadata(runner,["target"])
    old=view.identities()
    assert view['target']['seq_lens'] is first
    m.seq_lens=first.clone()
    assert view['target']['seq_lens'] is m.seq_lens and view.identities()!=old
    runner.model_state.attn_metadata=dict(runner.model_state.attn_metadata)
    with pytest.raises(ValueError):view.identities()


@pytest.mark.parametrize("damage",["owner","read_table","query_lengths","metadata_field"])
def test_target_post_forward_baseline_rejects_after_draft_metadata_rebind_or_pollution(complete_record,damage):
    bad=copy.deepcopy(complete_record)
    if damage == "owner":bad['target_metadata_owner_after_draft']={'host-owner':2}
    else:
        data=_snapshot_value(bad['target_after_draft']['inputs'])
        name=data['target_layer_names'][0]
        if damage == "read_table":data['layers'][name]['block_table']=torch.tensor([[0]],dtype=torch.int32)
        elif damage == "query_lengths":data['layers'][name]['cum_query_lens']=torch.tensor([8],dtype=torch.int32)
        else:data['layers'][name]['unexpected']=True
        bad['target_after_draft']['inputs']=_snapshot(data,[200*1024**2])
    with pytest.raises(ValueError):isolation_errors(bad)
