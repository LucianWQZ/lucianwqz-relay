# SPDX-License-Identifier: Apache-2.0
import copy
import hashlib
import json

import pytest

from tools.p7x_graph_repair21_rank import build_rank_kwargs
from tools.p7x_graph_repair28_rank_anchor_check import validate_payload


def test_initialized_failure_exports_host_evidence_and_never_claims_recovery(
        tmp_path):
    from tools.p7x_graph_repair21_rank import isolate_failed_parent
    exits = []
    record = dict(status="STARTING", source_sha="candidate", pid=200)
    isolate_failed_parent(record,
                          tmp_path,
                          RuntimeError("unknown native submission"),
                          model_initialized=True,
                          exit_process=exits.append)
    saved = json.loads((tmp_path / "campaign.json").read_text())
    assert exits == [
        74
    ] and saved["exception_message"] == "unknown native submission"
    assert saved["failure_action"] == "PARENT_EXIT74_NO_DEVICE_RECOVERY"
    assert not saved["status"].startswith("ALL_RANK_")
    assert saved["completion"] == "NOT_INFERRED_FROM_EXCEPTION_OR_PROCESS_EXIT"


def test_pre_model_failure_does_not_fake_model_or_device_execution(tmp_path):
    from tools.p7x_graph_repair21_rank import isolate_failed_parent
    exits = []
    record = dict(status="STARTING")
    isolate_failed_parent(record,
                          tmp_path,
                          ValueError("config"),
                          model_initialized=False,
                          exit_process=exits.append)
    assert not exits and record["failure_action"] == "PRE_MODEL_RAISE"


def evidence(tp, review=False):
    expected = dict(tp=tp,
                    phy_ids=list(range(tp)),
                    argv=["python", "rank"],
                    source_sha="sha",
                    source_tree="tree")
    if review:
        expected["window_on_review"] = True
    execution = dict(argv=expected["argv"],
                     returncode=0,
                     signal=None,
                     timeout=False,
                     pid=90,
                     start_epoch=10,
                     end_epoch=30)
    receipt = dict(source_sha="sha",
                   source_tree="tree",
                   tp=tp,
                   phy_ids=list(range(tp)),
                   host="node",
                   vllm_checkout="/pin")
    layers = [f"layer{i}" for i in range(5)]
    dispatch = [
        dict(role=role,
             returned=True,
             mode="FULL",
             host_start_ns=100,
             host_return_ns=200) for role in ("target", "draft:query")
    ]
    ranks = [
        dict(rank=r,
             local_rank=r,
             logical_device=r,
             pid=200 + r,
             nspid=[str(1000 + r), str(200 + r)],
             process_start_ticks=str(100 + r),
             hostname="node",
             world_size=tp,
             tp_size=tp,
             draft_tp_size=tp,
             window_size=None,
             ascend_source="/source/vllm_ascend/__init__.py",
             vllm_source="/pin/vllm/__init__.py",
             visible=",".join(map(str, range(tp))),
             draft_layers=layers,
             draft_backend={
                 layer:
                 "vllm_ascend.attention.attention_v1.AscendAttentionBackend"
                 for layer in layers
             },
             draft_graph_inventory=[dict(tokens=7)],
             target_graph_inventory=[dict(tokens=8)],
             draft_replays=1,
             target_replays=1,
             submission_uncertain=False,
             dispatch_records=copy.deepcopy(dispatch),
             draft_kv_geometry={
                 f"{layer}/{kv}":
                 dict(shape=[256, 128, max(1, 8 // tp), 128],
                      dtype="torch.bfloat16")
                 for layer in layers
                 for kv in range(2)
             }) for r in range(tp)
    ]
    requests = [
        dict(label=label,
             start_ns=100,
             end_ns=200,
             prompts=[
                 dict(prompt_token_ids=[100 + i] * n)
                 for i, n in enumerate(lengths)
             ],
             outputs=[
                 dict(finished=True, token_ids=[17] * 32) for _ in lengths
             ]) for label, lengths in (("short-one", [257]),
                                       ("long-three", [2051, 771, 387]))
    ]
    if review:
        for row in ranks:
            row.update(window_size=1024, window_provider_installed=True, heavy_observer_enabled=False,
                       window_generations=[dict(generation=1,epoch=1,requests=["a"],actual=1,padded=1,
                                                window_starts=[1024],exact=[1027],tp_size=tp,tp_rank=row["rank"])],
                       window_graph_bindings=[dict(tp_size=tp,tp_rank=row["rank"])])
    kwargs = build_rank_kwargs(tp, window_on_review=review)
    campaign = dict(
        pid=90,
        tp=tp,
        started_at=11,
        ended_at=29,
        source_sha="sha",
        source_tree="tree",
        status="ALL_RANK_WINDOW_ON_REVIEW_ANCHOR_COMPLETED_NOT_NUMERIC_VALIDATION" if review else "ALL_RANK_REQUEST_ANCHOR_COMPLETED_NOT_WINDOW_VALIDATION",
        window_on_review=review,
        kwargs=kwargs,
        config_sha256=hashlib.sha256(
            json.dumps(kwargs, sort_keys=True).encode()).hexdigest(),
        ranks=ranks,
        installed_observers=[dict(rank=r, pid=200 + r) for r in range(tp)],
        requests=requests)
    return campaign, expected, execution, receipt


@pytest.mark.parametrize("tp", [2, 4, 16])
def test_explicit_on_anchor_requires_each_real_rank_clipping_and_bindings(tp):
    c,p,e,r = evidence(tp, review=True)
    assert validate_payload(c,p,e,r,"/source")["ranks"] == tp
    for damage in ("provider", "observer", "clipped", "binding", "epoch", "arm", "mode"):
        bad = copy.deepcopy(c)
        row = bad["ranks"][-1]
        if damage == "provider": row["window_provider_installed"] = False
        elif damage == "observer": row["heavy_observer_enabled"] = True
        elif damage == "clipped": row["window_generations"][0]["window_starts"] = [0]
        elif damage == "binding": row["window_graph_bindings"][0]["tp_rank"] = 0
        elif damage == "epoch": row["window_generations"][0]["epoch"] = 2
        elif damage == "arm": bad["window_on_review"] = False
        else: row["dispatch_records"][0]["mode"] = "NONE"
        with pytest.raises(ValueError): validate_payload(bad,p,e,r,"/source")


@pytest.mark.parametrize("tp", [2, 4, 16])
def test_complete_rank_set_uses_real_per_rank_kv_geometry(tp):
    c, p, e, r = evidence(tp)
    result = validate_payload(c, p, e, r, "/source")
    assert result["ranks"] == tp and "Not continuous numerical" in result[
        "scope"]


@pytest.mark.parametrize("damage", [
    "rank_missing", "rank_duplicate", "wrong_draft_tp", "rank0_only_replay",
    "wrong_kv_heads", "wrong_backend", "wrong_source", "signal", "timeout",
    "wrong_kwargs", "short_output", "wrong_prompt", "unexpected_window",
    "duplicate_phy", "false_counter", "missing_rpc_rank"
])
def test_incomplete_cross_rank_or_changed_workload_rejected(damage):
    c, p, e, r = evidence(4)
    if damage == "rank_missing": c["ranks"].pop()
    if damage == "rank_duplicate": c["ranks"][1]["rank"] = 0
    if damage == "wrong_draft_tp": c["ranks"][1]["draft_tp_size"] = 2
    if damage == "rank0_only_replay": c["ranks"][1]["draft_replays"] = 0
    if damage == "wrong_kv_heads":
        c["ranks"][1]["draft_kv_geometry"]["layer0/0"]["shape"][2] = 4
    if damage == "wrong_backend":
        c["ranks"][1]["draft_backend"]["layer0"] = "unvalidated.SFA"
    if damage == "wrong_source":
        c["ranks"][1]["ascend_source"] = "/old/vllm_ascend/__init__.py"
    if damage == "signal": e.update(returncode=-9, signal=9)
    if damage == "timeout": e["timeout"] = True
    if damage == "wrong_kwargs": c["kwargs"]["tensor_parallel_size"] = 2
    if damage == "short_output":
        c["requests"][1]["outputs"][0]["token_ids"].pop()
    if damage == "wrong_prompt":
        c["requests"][0]["prompts"][0]["prompt_token_ids"][0] = 99
    if damage == "unexpected_window": c["window_on_review"] = True
    if damage == "duplicate_phy": p["phy_ids"][1] = 0
    if damage == "false_counter": c["ranks"][1]["draft_replays"] = 9
    if damage == "missing_rpc_rank": c["installed_observers"].pop()
    with pytest.raises(ValueError):
        validate_payload(c, p, e, r, "/source")
