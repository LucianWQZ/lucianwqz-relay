# SPDX-License-Identifier: Apache-2.0
"""Real C1 finally + runtime quarantine; native Graph/Event calls replaced."""

import hashlib
import json
import os
from types import SimpleNamespace

import pytest
import torch
from vllm.config.compilation import CUDAGraphMode

from tests.ut.spec_decode.test_graph_repair4_integration import _batch, _lifetime_fixture, _publish_in_scope
from tools.p7x_graph_repair6_runner import adjudicate_records, run_case
from tools.p7x_graph_repair8_unwind import InjectedGraphUnwindError, POINTS, ProposalUnwindProbe


def host_unwind(monkeypatch, tmp_path, point):
    owner, session, manager, descriptors, _ = _lifetime_fixture(monkeypatch)
    owner.query_cudagraph_manager = manager
    manager.max_num_reqs = 8
    manager._capture_descs = {CUDAGraphMode.FULL: list(descriptors.values())}
    session.recorder.enabled = False
    events = []

    class Event:
        def record(self, stream):
            events.append("record")

        def synchronize(self):
            events.append("sync")

        def query(self):
            pytest.fail("no query allowed")

    monkeypatch.setattr(torch.npu, "Event", Event if point == "after_completion" else
                        lambda: pytest.fail("uncertain branch must not drain"))
    monkeypatch.setattr(torch.npu, "current_stream", lambda: SimpleNamespace(npu_stream=1))
    path = tmp_path / "unwind.json"
    probe = ProposalUnwindProbe(owner, path, {}, point)
    _batch(owner, 1)
    with pytest.raises(InjectedGraphUnwindError), probe:
        with owner._draft_window_proposal_scope(owner.input_batch, dummy_run=False, is_profile=False):
            _publish_in_scope(owner, descriptors[1])
            manager.run_fullgraph(descriptors[1])
    document = json.loads(path.read_text())
    return owner, probe, document, events


@pytest.mark.parametrize("point", POINTS)
def test_real_c1_exception_unwinding_preserves_backing_and_rejects_next_use(monkeypatch, tmp_path, point):
    owner, probe, document, events = host_unwind(monkeypatch, tmp_path, point)
    state, record, guard = document["state"], document["record"], document["next_scope_guard"]
    assert state["quarantined_identity"] == record["generation_identity"]
    assert state["active_backing_retained"] and state["live_inputs_cleared"] and state["proposal_context_cleared"]
    assert state["graph_submission_uncertain"] and len(record["quarantine_calls"]) == 1
    assert guard["rejected"] and not guard["body_entered"] and "backing is quarantined" in guard["exception"]
    assert events == (["record", "record", "sync", "sync"] if point == "after_completion" else [])
    assert probe.poisoned and not probe.saved
    assert "quarantine_generation" not in vars(owner._draft_window_runtime_state)
    # The next entry was rejected before epoch.begin or a second materialize.
    assert owner._draft_window_runtime_state._next_generation_id == 1


def outcomes():
    return [dict(argv=["python", "launch"], returncode=73, timeout=False, kind="launch", status="EXECUTION_FAILED"),
            dict(argv=["python", "/fixed/tools/p7x_graph_repair5.py", "check-diagnostic", "--kind", "abort"],
                 returncode=0, timeout=False, kind="read_only_acceptance", status="COMMAND_COMPLETED_NOT_GATE_PASS")]


@pytest.mark.parametrize("bad", [None, "wrong_kind", "no_checker", "timeout", "signal", "wrong_exit", "bad_evidence"])
def test_published_abort_checker_contract_and_negative_outcomes(bad):
    records = outcomes()
    if bad == "wrong_kind":
        records[1]["argv"][-1] = "lifecycle"
    elif bad == "no_checker":
        records.pop()
    elif bad == "timeout":
        records[0]["timeout"] = True
    elif bad == "signal":
        records[0]["returncode"] = -9
    elif bad == "wrong_exit":
        records[0]["returncode"] = 74
    elif bad == "bad_evidence":
        records[1]["returncode"] = 4
    result = adjudicate_records(dict(cases={"ABORT_before_replay": {}}), "ABORT_before_replay", records)
    assert result["dependency_satisfied"] is (bad is None)


def test_existing_attempt_result_cannot_be_reassociated_after_dependency_failure(tmp_path):
    directory = tmp_path / "A0"
    directory.mkdir()
    original = b'{"dependency_satisfied": true, "source_identity": ["old"]}'
    (directory / "runner-result.json").write_bytes(original)
    with pytest.raises(ValueError, match="output already exists"):
        run_case(dict(cases={"A0": dict(dependencies=["CONFIG"])}), "A0", tmp_path)
    assert (directory / "runner-result.json").read_bytes() == original


def test_unwind_plan_and_driver_default_off():
    from tools.p7x_graph_repair2 import parse_args

    args = parse_args(["run", "--case", "B-observer-off", "--run-id", "r", "--attempt", "1",
                       "--expected-sha", "a" * 40, "--vllm-repo", "/pin", "--target-model", "/target",
                       "--draft-model", "/draft", "--fixture-manifest", "/fixture", "--output", "/output"])
    assert args.repair8_unwind_at == "none"


@pytest.mark.parametrize("damage", [None, "pid", "point", "guard", "quarantine", "completion", "signal", "exit"])
def test_joint_requires_real_c1_state_and_external_execution(monkeypatch, tmp_path, damage):
    from tools.p7x_graph_repair8_unwind import check

    _, _, doc, _ = host_unwind(monkeypatch, tmp_path, "after_replay")
    identity = dict(run_id="host-r", case_id="UNWIND_after_replay", attempt_id="1",
                    source_sha="a" * 40, source_tree="b" * 40, driver_mode="B-observer-off",
                    process_id=os.getpid(), engine_id=123)
    doc["identity"] = identity
    argv = ["python", "/fixed/tools/p7x_graph_repair2.py", "run", "--case-id", identity["case_id"]]
    expected = dict(acceptance_identity=identity, argv=argv, launch_argv=["launch", "--", *argv],
                    outputs=str(tmp_path), requests_sha256="c" * 64, unwind_point="after_replay")
    launcher = dict(identity, pid=os.getpid(), argv=argv, requests_sha256="c" * 64,
                    host_start_ns=doc["record"]["before_replay_ns"] - 1000,
                    host_end_ns=doc["next_scope_guard"]["ns"] + 1000,
                    status="EXITED", signal=None, timeout=False, returncode=74)
    campaign = dict(identity=identity, startup_complete=True, status="EXCEPTION",
                    exception_type="InjectedGraphUnwindError", exception_message="REPAIR8_PYTHON_UNWIND:after_replay",
                    request_manifest=dict(sha256="c" * 64), diagnostic_quarantine="PROCESS_EXIT_74_NO_REUSE")
    if damage == "pid":
        launcher["pid"] += 1
    elif damage == "point":
        doc["record"]["injected_point"] = "before_replay"
    elif damage == "guard":
        doc["next_scope_guard"]["body_entered"] = True
    elif damage == "quarantine":
        doc["record"]["quarantine_calls"] = []
    elif damage == "completion":
        doc["record"]["completion"] = "DIAGNOSTIC_STREAM_DRAIN_BEFORE_EXCEPTION"
    elif damage == "signal":
        launcher["signal"] = 9
    elif damage == "exit":
        launcher["returncode"] = 0
    path = tmp_path / "python-unwind.json"
    path.write_text(json.dumps(doc))
    campaign["diagnostic_artifacts"] = {path.name: dict(
        bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())}
    result = check(doc, campaign, launcher, expected, path)
    assert (result["status"] == "PASS_SCOPED_PYTHON_UNWIND_ISOLATION") is (damage is None), result
