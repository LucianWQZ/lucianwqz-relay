# SPDX-License-Identifier: Apache-2.0
"""Host wrapping/schema tests; native profiler and Graph execution substituted."""

import json
import sys
from types import SimpleNamespace

import pytest

from tests.ut.spec_decode.test_graph_repair5_contracts import load
from tests.ut.spec_decode.test_graph_repair5_review import actual_candidates


@pytest.mark.parametrize("enabled", [False, True])
def test_request_profiler_active_window_real_dispatch_no_eager_flag(monkeypatch, tmp_path, enabled):
    tool = load("p7x_graph_repair5_profile")
    calls = []

    class NativeProfiler:
        def __init__(self, **kwargs):
            assert kwargs["record_shapes"] is False and kwargs["profile_memory"] is False

        def __enter__(self):
            calls.append("profiler_start")
            return self

        def __exit__(self, *exc):
            calls.append("profiler_stop")

        def step(self):
            calls.append("step")

    monkeypatch.setitem(
        sys.modules,
        "torch_npu",
        SimpleNamespace(
            __version__="HOST_STUB",
            profiler=SimpleNamespace(
                profile=NativeProfiler,
                tensorboard_trace_handler=lambda _: lambda p: None,
                ProfilerActivity=SimpleNamespace(CPU="CPU", NPU="NPU"),
            ),
        ),
    )
    manager = actual_candidates(7, [7, 14, 28])
    # Native executions substituted, real dispatch not substituted.
    manager.graphs = {
        d: SimpleNamespace(replay=lambda: calls.append("native_replay"))
        for d in manager._capture_descs[next(iter(manager._capture_descs))]
    }
    manager.run_fullgraph = lambda d: manager.graphs[d].replay()
    spec = SimpleNamespace(query_cudagraph_manager=manager)

    def propose(*args, **kwargs):
        assert not kwargs.get("is_profile")
        manager.run_fullgraph(manager.dispatch(1, 7, 7, 0))

    spec.propose = propose
    target = SimpleNamespace(run_fullgraph=lambda: None, graphs={})
    runner = SimpleNamespace(speculator=spec, cudagraph_manager=target)
    original = spec.propose
    with tool.RequestProfiler(runner, tmp_path, {"pid": 1}, enabled=enabled) as profile:
        with profile.group("warmup"):
            spec.propose()
        profile.begin_active()
        with profile.group("active"):
            spec.propose()
    assert spec.propose is original
    assert calls.count("native_replay") == 2
    assert ("profiler_start" in calls) is enabled
    data = json.loads((tmp_path / "profile.json").read_text())
    assert data["status"] == "GRAPH_REPLAY_OBSERVED"
    assert data["host_statistics"]["Draft_REPLAY_SUBMIT"]["samples"] == 1
    assert data["physical_read"] == "NOT_PROVEN"


def test_profiling_rejects_heavy_observer(tmp_path):
    tool = load("p7x_graph_repair5_profile")
    runner = SimpleNamespace(
        speculator=SimpleNamespace(
            _draft_window_graph_characterization=SimpleNamespace(recorder=SimpleNamespace(enabled=True))
        )
    )
    with pytest.raises(ValueError, match="observer OFF"):
        tool.RequestProfiler(runner, tmp_path, {}, enabled=True).__enter__()


def test_autoregressive_first_pass_and_merged_ar_are_separate_cpu_ranges(tmp_path):
    """Real wrapper, substituted device execution; never invent one query manager."""
    tool = load("p7x_graph_repair5_profile")
    def manager(width):
        desc = SimpleNamespace(num_reqs=1, num_tokens=width)
        graph = SimpleNamespace(replay=lambda: None)
        return SimpleNamespace(graphs={0: graph}, run_fullgraph=lambda d: graph.replay()), desc

    first, first_desc = manager(4)
    ar, ar_desc = manager(1)
    # Actual descriptors are hashable dataclasses; only .num_reqs/.num_tokens
    # are needed by the Host replay wrappers in this test.
    first.graphs = {type("Desc", (), dict(num_reqs=1, num_tokens=4))(): first.graphs[0]}
    ar.graphs = {type("Desc", (), dict(num_reqs=1, num_tokens=1))(): ar.graphs[0]}
    first_graph, ar_graph = next(iter(first.graphs.values())), next(iter(ar.graphs.values()))
    first.run_fullgraph = lambda d: first_graph.replay()
    ar.run_fullgraph = lambda d: ar_graph.replay()
    spec = SimpleNamespace(prefill_cudagraph_manager=first, decode_cudagraph_manager=ar,
                           propose=lambda: (first.run_fullgraph(first_desc), ar.run_fullgraph(ar_desc)))
    runner = SimpleNamespace(
        speculator=spec, cudagraph_manager=SimpleNamespace(graphs={}, run_fullgraph=lambda d: None)
    )
    with tool.RequestProfiler(runner, tmp_path, {}, enabled=False) as profile:
        profile.begin_active()
        with profile.group("actual-ar"):
            spec.propose()
    data = json.loads((tmp_path / "profile.json").read_text())
    labels = [c["label"] for c in data["calls"] if c["active"]]
    assert "Draft_first_pass_REPLAY_SUBMIT" in labels
    assert "Draft_AR_REPLAY_SUBMIT" in labels
    assert "Draft_REPLAY_SUBMIT" not in labels
    assert data["status"] == "GRAPH_REPLAY_OBSERVED"


def test_streaming_csv_analysis_does_not_add_overlapping_durations(tmp_path):
    tool = load("p7x_graph_repair5_profile")
    (tmp_path / "tasks.csv").write_text("Name,Duration(us),Stream ID\nMemcpy,10,1\nWait,5,2\n")
    result = tool.analyze_csv([tmp_path])
    assert result["files"][0]["nonempty"]["Stream ID"] == 2
    assert result["device_idle"].startswith("UNRESOLVED")
    assert result["totals"][f"{tmp_path / 'tasks.csv'}:copy"]["duration_us_sum"] == 10
    (tmp_path / "unknown.csv").write_text("Name,Duration\nMemcpy,1000\n")
    result = tool.analyze_csv([tmp_path])
    assert not any("unknown.csv" in key for key in result["totals"])


def test_streaming_pack_verify_and_corruption(tmp_path):
    tool = load("p7x_graph_repair5_pack")
    source = tmp_path / "source"
    source.mkdir()
    (source / "payload.bin").write_bytes(b"x" * (5 * 1024 * 1024))
    (source / "identity.json").write_text('{"source":"host_test"}')
    path = tmp_path / "evidence.zip"
    assert tool.pack(source, path)["status"] == "VERIFIED"
    assert tool.verify(path)["members"] == 4
    with pytest.raises(ValueError):
        tool.safe_name("../outside")


def test_eagle_materialize_ranges_use_actual_epoch_snapshot_and_module_update_alias(monkeypatch,tmp_path):
    """Real Host wrappers, substituted model execution; no new device action."""
    import torch
    from types import ModuleType
    tool=load('p7x_graph_repair5_profile')
    name='test_eagle_actual_graph_manager_module';module=ModuleType(name)
    module.update_full_graph_params=lambda **kwargs:None
    original_update=module.update_full_graph_params
    monkeypatch.setitem(sys.modules,name,module)
    monkeypatch.setattr(torch.npu,'Event',lambda:pytest.fail('profiling must not add device events'))
    class Manager:
        __module__=name
        def __init__(self,width):
            self.desc=type('Desc',(),dict(num_reqs=1,num_tokens=width))()
            self.graphs={self.desc:SimpleNamespace(replay=lambda:None)}
        def run_fullgraph(self,desc):
            self.graphs[desc].replay()
            module.update_full_graph_params(draft_window_graph_update_binding=binding)
    first,ar=Manager(4),Manager(1)
    identity=SimpleNamespace(generation_id=12,mapping_epoch=3)
    carrier=SimpleNamespace(runtime_identity=identity,capture_identity=SimpleNamespace(consumer_ordinal=1))
    binding=SimpleNamespace(route=SimpleNamespace(name='EAGLE3_AR_STEP'),carriers=[carrier])
    workspace=SimpleNamespace(materialize=lambda:None,build_inputs=lambda:None)
    runtime=SimpleNamespace(workspace=workspace,materialize=lambda:None,materialize_serialized_step=lambda:None,retire_generation=lambda identity:None)
    spec=SimpleNamespace(_eagle3_graph_session=SimpleNamespace(),_eagle3_window_epoch_source=SimpleNamespace(validate=lambda:None),
        _eagle3_window_proposal_context=SimpleNamespace(mapping_epoch=3),_draft_window_runtime_state=runtime,
        prefill_cudagraph_manager=first,decode_cudagraph_manager=ar,build_draft_attn_metadatas=lambda:None,
        _snapshot_eagle3_decode_step_one=lambda:None)
    def materialize():
        spec._eagle3_window_epoch_source.validate();runtime.materialize();runtime.materialize_serialized_step()
        workspace.materialize();workspace.build_inputs();return SimpleNamespace(identity=identity)
    spec._materialize_eagle3_first_pass=materialize;spec._materialize_eagle3_decode_step=materialize
    def propose():
        spec._materialize_eagle3_first_pass();spec.build_draft_attn_metadatas();first.run_fullgraph(first.desc);runtime.retire_generation(identity)
        spec._snapshot_eagle3_decode_step_one();spec._materialize_eagle3_decode_step();spec.build_draft_attn_metadatas();ar.run_fullgraph(ar.desc);runtime.retire_generation(identity)
    spec.propose=propose
    runner=SimpleNamespace(speculator=spec,cudagraph_manager=SimpleNamespace(graphs={},run_fullgraph=lambda:None))
    with tool.RequestProfiler(runner,tmp_path,{},enabled=False,materialize_ranges=True) as probe:
        probe.begin_active();spec.propose()
    data=json.loads((tmp_path/'profile.json').read_text())
    assert module.update_full_graph_params is original_update and not probe.saved
    assert data['host_statistics']['Draft_materialize']['samples']==2
    assert data['host_statistics']['Draft_UPDATE_CALL']['samples']==2
    assert data['host_statistics']['Draft_materialize_exact_length_snapshot']['samples']==1
    assert all(row['status']=='OBSERVED' for row in data['host_subrange_coverage'].values())
    updates=[row for row in data['calls'] if row['label']=='Draft_UPDATE_CALL']
    assert all(row['host_update_bindings']==[dict(generation=12,epoch=3,consumer_ordinal=1)] for row in updates)
    assert all(row['binding_scope']=='ACTUAL_HOST_UPDATE_ARGUMENT_NOT_DEVICE_OCCURRENCE_OR_OPERAND' for row in updates)
    assert data['physical_read']==data['completion']=='NOT_PROVEN'


def test_eagle_window_off_still_profiles_its_actual_update_alias(monkeypatch,tmp_path):
    from types import ModuleType
    tool=load('p7x_graph_repair5_profile')
    name='test_eagle_off_graph_module';module=ModuleType(name)
    module.update_full_graph_params=lambda:None;original=module.update_full_graph_params
    monkeypatch.setitem(sys.modules,name,module)
    class Manager:
        __module__=name
        def __init__(self,width):
            self.desc=type('Desc',(),dict(num_reqs=1,num_tokens=width))()
            self.graphs={self.desc:SimpleNamespace(replay=lambda:None)}
        def run_fullgraph(self,desc):
            self.graphs[desc].replay();module.update_full_graph_params()
    first,ar=Manager(4),Manager(1)
    spec=SimpleNamespace(prefill_cudagraph_manager=first,decode_cudagraph_manager=ar,
        build_draft_attn_metadatas=lambda:None,propose=lambda:(first.run_fullgraph(first.desc),ar.run_fullgraph(ar.desc)))
    runner=SimpleNamespace(speculator=spec,cudagraph_manager=SimpleNamespace(graphs={},run_fullgraph=lambda:None))
    with tool.RequestProfiler(runner,tmp_path,{},enabled=False,materialize_ranges=True) as probe:
        probe.begin_active();spec.propose()
    data=json.loads((tmp_path/'profile.json').read_text())
    assert data['host_subrange_coverage']['Draft_UPDATE_CALL']['status']=='OBSERVED'
    assert data['host_statistics']['Draft_UPDATE_CALL']['samples']==2
    assert data['host_subrange_coverage']['Draft_materialize']['expected_minimum']==0
    assert module.update_full_graph_params is original


def test_failed_native_submission_skips_profiler_stop_and_exports_host_facts(tmp_path):
    tool=load('p7x_graph_repair5_profile');stops=[]
    native=SimpleNamespace(__exit__=lambda *args:stops.append('FORBIDDEN_NATIVE_STOP'))
    def failed():raise RuntimeError('original failed native submission')
    spec=SimpleNamespace(propose=failed,query_cudagraph_manager=SimpleNamespace(graphs={},run_fullgraph=lambda:None))
    runner=SimpleNamespace(speculator=spec,cudagraph_manager=SimpleNamespace(graphs={},run_fullgraph=lambda:None))
    probe=tool.RequestProfiler(runner,tmp_path,{},enabled=False)
    with pytest.raises(RuntimeError,match='original failed native submission'):
        with probe:
            probe.profiler=native
            spec.propose()
    assert not stops and probe._unclosed_profiler_after_error is native
    assert probe.native_cleanup_skipped_after_error and not probe.saved
    result=json.loads((tmp_path/'profile.json').read_text())
    assert result['status']=='FAILED_HOST_EXPORT_ONLY' and result['native_cleanup_skipped_after_error']


def test_error_export_failure_does_not_mask_original_model_exception(monkeypatch,tmp_path):
    tool=load('p7x_graph_repair5_profile')
    def failed():raise RuntimeError('original forward failure')
    spec=SimpleNamespace(propose=failed,query_cudagraph_manager=SimpleNamespace(graphs={},run_fullgraph=lambda:None))
    runner=SimpleNamespace(speculator=spec,cudagraph_manager=SimpleNamespace(graphs={},run_fullgraph=lambda:None))
    probe=tool.RequestProfiler(runner,tmp_path,{},enabled=False)
    from pathlib import Path
    original=Path.write_text
    def write(self,*args,**kwargs):
        if self.name=='profile.json':raise OSError('export full')
        return original(self,*args,**kwargs)
    monkeypatch.setattr(Path,'write_text',write)
    with pytest.raises(RuntimeError,match='original forward failure'):
        with probe:spec.propose()
    assert 'export full' in probe.host_export_error and not probe.saved
    assert spec.propose is failed


def test_native_stop_failure_is_retained_and_never_retried(tmp_path):
    tool=load('p7x_graph_repair5_profile');calls=[]
    def stop(*args):calls.append('stop');raise RuntimeError('native Stop failed')
    native=SimpleNamespace(__exit__=stop)
    spec=SimpleNamespace(propose=lambda:None,query_cudagraph_manager=SimpleNamespace(graphs={},run_fullgraph=lambda:None))
    runner=SimpleNamespace(speculator=spec,cudagraph_manager=SimpleNamespace(graphs={},run_fullgraph=lambda:None))
    probe=tool.RequestProfiler(runner,tmp_path,{},enabled=False)
    with pytest.raises(RuntimeError,match='native Stop failed'):
        with probe:probe.profiler=native;spec.propose()
    assert calls==['stop'] and probe._unclosed_profiler_after_error is native
    assert not probe.saved and probe.native_cleanup_failed
    data=json.loads((tmp_path/'profile.json').read_text())
    assert data['status']=='FAILED_HOST_EXPORT_ONLY' and data['native_cleanup_failed']
    assert not data['native_cleanup_skipped_after_error']
