# SPDX-License-Identifier: Apache-2.0
"""Host-only validation memo: no values, no epoch persistence, no device work."""
from types import SimpleNamespace

import pytest
import torch

import vllm_ascend.worker.v2.spec_decode.draft_window_graph as module
from vllm_ascend.worker.v2.spec_decode.draft_window_graph import DraftWindowGraphBindingProvider as Provider


def specimen(layers=7):
    read = SimpleNamespace(window_block_table=torch.zeros(4, 9, dtype=torch.int32),
        device_window_exact=torch.tensor([1024, 513, 0, 0], dtype=torch.int32),
        cpu_window_exact=torch.tensor([1024, 513, 0, 0], dtype=torch.int32))
    write = module.DraftWindowGraphWriteSideReference(slot_mapping=torch.arange(28, dtype=torch.int32),
        positions=torch.arange(28, dtype=torch.int64), query_start_loc=torch.tensor([0, 7, 14, 14, 14], dtype=torch.int32),
        actual_seq_lengths_q=(7, 14, 21, 28), attn_state=object(), num_actual_tokens=28, causal=False)
    metadata = {f"layer-{i}": SimpleNamespace(block_tables=read.window_block_table,
        seq_lens=read.device_window_exact, seq_lens_cpu=read.cpu_window_exact,
        seq_lens_list=read.cpu_window_exact.tolist(), slot_mapping=write.slot_mapping,
        positions=write.positions, query_start_loc=write.query_start_loc,
        actual_seq_lengths_q=list(write.actual_seq_lengths_q), attn_state=write.attn_state,
        num_actual_tokens=28, causal=False) for i in range(layers)}
    return metadata, read, write, module._write_side_snapshot(write)


def validate(args, enabled):
    return Provider._validate_metadata_uses_carrier(*args, validation_identity_memo=enabled)


def test_shared_tensors_have_identical_verdict_with_fewer_header_reads(monkeypatch):
    args = specimen();original = module._tensor_identity;calls = []
    def identity(tensor):
        calls.append(id(tensor));return original(tensor)
    monkeypatch.setattr(module, "_tensor_identity", identity)
    validate(args, False);baseline = len(calls);calls.clear()
    validate(args, True);memoized = len(calls)
    assert baseline > memoized * 4
    # All seven distinct layer objects are still checked. No identity memo is
    # retained in the provider or carried to the following validation.
    calls.clear();validate(args, True);assert len(calls) == memoized


@pytest.mark.parametrize("enabled", [False, True])
@pytest.mark.parametrize("damage", ['table','device_exact','cpu_exact','list','slot','position','query','query_values',
    'causal','state','count','write_mutation'])
def test_last_distinct_layer_and_full_write_mutation_are_still_rejected(enabled, damage):
    args = specimen();metadata, read, write, _ = args;layer=metadata['layer-6']
    if damage == 'table':layer.block_tables=read.window_block_table.clone()
    if damage == 'device_exact':layer.seq_lens=read.device_window_exact.clone()
    if damage == 'cpu_exact':layer.seq_lens_cpu=read.cpu_window_exact.clone()
    if damage == 'list':layer.seq_lens_list=[999,513,0,0]
    if damage == 'slot':layer.slot_mapping=write.slot_mapping.clone()
    if damage == 'position':layer.positions=write.positions.clone()
    if damage == 'query':layer.query_start_loc=write.query_start_loc.clone()
    if damage == 'query_values':layer.actual_seq_lengths_q=[7,14,21,21]
    if damage == 'causal':layer.causal=True
    if damage == 'state':layer.attn_state=object()
    if damage == 'count':layer.num_actual_tokens=21
    if damage == 'write_mutation':write.positions.add_(1)
    with pytest.raises(RuntimeError):validate(args,enabled)


def test_next_call_reads_new_exact_values_and_headers():
    args=specimen();validate(args,True);metadata,read,write,_=args
    read.cpu_window_exact[0]=1000
    with pytest.raises(RuntimeError,match='exact length values'):validate(args,True)
    for layer in metadata.values():layer.seq_lens_list=read.cpu_window_exact.tolist()
    validate(args,True)
    # Header shape/storage mutation across calls is not hidden by a stale memo.
    metadata['layer-6'].slot_mapping=write.slot_mapping[1:]
    with pytest.raises(RuntimeError,match='slot mapping'):validate(args,True)


def test_factory_default_off_and_false_values_do_not_enable_header_memo():
    from vllm_ascend.ascend_config import AscendConfig
    for value in [False,'false','0']:
        assert AscendConfig(sparse_kv_offload_config=SimpleNamespace(enabled=False),
            draft_window_graph_validation_memo=value).draft_window_graph_validation_memo is False
    assert module._validation_tensor_identity_reader(False) is module._tensor_identity
    with pytest.raises(TypeError):module._validation_tensor_identity_reader('false')


def test_performance_checker_rejects_undeclared_memo_without_weakening_hash():
    import hashlib,json
    from tests.ut.spec_decode.test_graph_repair10_performance import specimen
    from tools.p7x_graph_repair10_performance import check
    from tempfile import TemporaryDirectory
    from pathlib import Path
    with TemporaryDirectory() as directory:
        campaign,launcher,profile,expected,artifact=specimen(Path(directory))
        campaign['llm_kwargs']['additional_config']['draft_window_graph_validation_memo']=True
        assert check(campaign,launcher,profile,expected,artifact)['status']=='INVALID_EVIDENCE'
        value=hashlib.sha256(json.dumps(campaign['llm_kwargs'],sort_keys=True).encode()).hexdigest()
        campaign['config_sha256']=expected['expected_llm_kwargs_sha256']=value
        result=check(campaign,launcher,profile,expected,artifact)
        assert result['status']=='INVALID_EVIDENCE' and 'own declared configuration' in result['error']
        expected['validation_memo_experiment']=True
        assert check(campaign,launcher,profile,expected,artifact)['status']=='INVALID_EVIDENCE'
        campaign['provider_installed']=True
        campaign['observer_installation']['validation_identity_memo_enabled']=True
        assert check(campaign,launcher,profile,expected,artifact)['status']=='PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE'
        campaign['config_sha256']='0'*64
        assert check(campaign,launcher,profile,expected,artifact)['status']=='INVALID_EVIDENCE'


def test_memo_plan_keeps_exact_requests_and_balances_six_pair_orders(tmp_path):
    import json
    from tools.p7x_graph_repair36_validation_memo import add_cases
    declaration=dict(schema='r6-validation-header-memo-v1',enabled=True,labels=['short1'],repetitions=6)
    (tmp_path/'validation-memo36.json').write_text(json.dumps(declaration))
    def source(name):
        argv=['python','producer','run','--case-id',name,'--repair5-profile','control']
        return dict(argv=argv,launch_argv=['launch','--',*argv],dependencies=['B0'],
                    acceptance_identity=dict(case_id=name),request_path='unchanged-request.json',requests_sha256='c'*64,
                    validation_commands=[dict(argv=['python','p7x_graph_repair27_balanced_perf.py'])])
    cases={name:source(name) for name in ['NUMERIC_SENTINEL','NUMERIC_TARGET4','LIFE']}
    for rep in range(1,7):
        name=f'PERF27_short1_{rep:02}_G_ON';cases[name]=source(name)
        cases[name]['balanced_performance']=dict(max_model_len=12288)
    add_cases(cases,tmp_path,tmp_path,tmp_path,'python')
    positions=[]
    for rep in range(1,7):
        for variant in ['BASE','MEMO']:
            case=cases[f'PERF36_short1_{rep:02}_{variant}'];meta=case['memo_validation_comparison']
            assert case['request_path']=='unchanged-request.json' and case['requests_sha256']=='c'*64
            assert ('--repair36-validation-memo' in case['argv']) is (variant=='MEMO')
            assert case['launch_argv'][case['launch_argv'].index('--')+1:]==case['argv']
            assert 'balanced_performance' not in case and 'NUMERIC_MEMO_SENTINEL' in case['dependencies']
            if variant=='MEMO':positions.append(meta['position'])
    assert positions.count(1)==positions.count(2)==3
    declaration['repetitions']=5;(tmp_path/'validation-memo36.json').write_text(json.dumps(declaration))
    with pytest.raises(ValueError):add_cases({},tmp_path,tmp_path,tmp_path,'python')


def test_actual_installation_is_explicit_and_default_off():
    from tests.ut.spec_decode.test_draft_window_graph_carrier import _runtime_fixture
    for value in [False, "false", True]:
        runtime, _, _ = _runtime_fixture()
        owner = SimpleNamespace(_draft_window_runtime_state=runtime,
            vllm_config=SimpleNamespace(additional_config={"draft_window_graph_validation_memo": value}))
        provider = module.install_draft_window_graph_binding_provider(owner)
        assert provider._validation_identity_memo is (value is True)
