# SPDX-License-Identifier: Apache-2.0
"""CPU scheduling cannot skip association checks, failures or alter rank order."""
import json
import os

import pytest

from tools.p7x_graph_repair21_rank import digest
from tools.p7x_graph_repair25_rank_numeric import check_response_payloads


def payload_checker(path, payload, worker):
    # A real per-process file read makes this exercise spawn and exception
    # transport, not just an executor stub. Model arithmetic is unchanged.
    value = json.loads(path.read_text())
    if not value['valid']:
        raise ValueError(f"damaged rank{worker['rank']} numeric evidence")
    return dict(rank=worker['rank'], value=value['values'], process=os.getpid())


def records(tmp_path):
    workers, responses = [], []
    for rank in (3, 1, 2, 0):
        path = tmp_path/f'rank-{rank}'/'rank-execution.json'
        path.parent.mkdir()
        path.write_text(json.dumps(dict(valid=True, values=[rank, rank+7])))
        workers.append(dict(rank=rank, pid=100+rank))
        responses.append(dict(rank=rank, pid=100+rank, path=str(path), sha256=digest(path), nonce='nonce'))
    return workers, responses


def normalized(values):
    return [{k:v for k,v in row.items() if k!='process'} for row in values]


def test_actual_cpu_spawn_preserves_every_rank_and_input_order(tmp_path):
    workers, responses = records(tmp_path)
    serial = check_response_payloads(responses, workers, {}, tmp_path, 'nonce', payload_checker)
    parallel = check_response_payloads(responses, workers, {}, tmp_path, 'nonce', payload_checker, cpu_workers=2)
    assert normalized(parallel) == normalized(serial)
    assert [row['rank'] for row in parallel] == [3,1,2,0]
    assert all(row['process'] != os.getpid() for row in parallel)


@pytest.mark.parametrize('damage', ['association','numeric'])
def test_spawn_propagates_rank_association_and_numeric_failures(tmp_path, damage):
    workers, responses = records(tmp_path)
    if damage == 'association':
        responses[2]['pid'] += 1
        expected = 'RPC terminal worker/attempt'
    else:
        path = tmp_path/'rank-2/rank-execution.json'
        path.write_text(json.dumps(dict(valid=False)))
        responses[2]['sha256'] = digest(path)
        expected = 'damaged rank2 numeric evidence'
    for count in (1,2):
        with pytest.raises(ValueError, match=expected):
            check_response_payloads(responses, workers, {}, tmp_path, 'nonce', payload_checker, cpu_workers=count)


@pytest.mark.parametrize('count', [False,0,5,-1])
def test_unbounded_or_untyped_parallelism_is_rejected(tmp_path,count):
    workers,responses=records(tmp_path)
    with pytest.raises(ValueError,match='bounded explicit CPU worker'):
        check_response_payloads(responses,workers,{},tmp_path,'nonce',payload_checker,cpu_workers=count)
