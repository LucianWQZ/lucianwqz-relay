# SPDX-License-Identifier: Apache-2.0
"""Actual cache-hit usage and CPU phase evidence, not configuration-only PASS."""
import copy
import json
from types import SimpleNamespace as N

import pytest

from tools import p7x_graph_repair47_glm_service as tool
from tests.ut.spec_decode.test_draft_window_nongraph import _batch


@pytest.mark.parametrize('arm',['G_OFF','G_ON','E_ON'])
def test_prefix_cli_is_real_and_keeps_the_requested_draft_mode(arm):
    argv=tool.glm_serve_argv('/python',18149,'prefix-service',arm,worker_provenance=True,prefix_caching=True)
    assert '--enable-prefix-caching' in argv and '--no-enable-prefix-caching' not in argv
    assert '--enable-prompt-tokens-details' in argv
    assert json.loads(argv[argv.index('--speculative-config')+1])['enforce_eager'] is (arm=='E_ON')
    assert '--no-async-scheduling' in argv  # Separate contract still enforced.


def cache_evidence():
    row=dict(effective_prefix_caching=True,source_prefix_caching=True,capture_prefix_modes=[True],
             proposal_phases=[dict(returned=True,batch_phase='pure_decode')],proposal_phases_truncated=False)
    campaign=dict(arm='G_ON',worker_provenance=[dict(results=[copy.deepcopy(row) for _ in range(16)])])
    document=dict(groups=[dict(phase=phase,label='long8193',results=[dict(summary=dict(response_id=phase,
        usage=dict(prompt_tokens=8193,prompt_tokens_details=dict(cached_tokens=count))))])
        for phase,count in [('warmup',0),('measured',8192)]])
    return campaign,document


def test_true_cached_tokens_are_separate_from_prefix_configuration():
    campaign,document=cache_evidence();result=tool.validate_prefix_hits(campaign,document)
    assert result['per_request'][1]['cached_tokens']==8192
    assert 'not all Target' in result['scope']


@pytest.mark.parametrize('damage',['not_effective','wrong_source','wrong_capture','zero_hit','missing_usage',
                                  'bool_count','too_many','missing_phase','truncated','classification_error'])
def test_configuration_or_corrupt_cache_evidence_cannot_claim_a_hit(damage):
    campaign,document=cache_evidence();row=campaign['worker_provenance'][-1]['results'][-1]
    usage=document['groups'][-1]['results'][0]['summary']['usage']
    if damage=='not_effective':row['effective_prefix_caching']=False
    elif damage=='wrong_source':row['source_prefix_caching']=False
    elif damage=='wrong_capture':row['capture_prefix_modes']=[False]
    elif damage=='zero_hit':usage['prompt_tokens_details']['cached_tokens']=0
    elif damage=='missing_usage':del usage['prompt_tokens_details']
    elif damage=='bool_count':usage['prompt_tokens_details']['cached_tokens']=True
    elif damage=='too_many':usage['prompt_tokens_details']['cached_tokens']=8194
    elif damage=='missing_phase':row['proposal_phases']=[]
    elif damage=='truncated':row['proposal_phases_truncated']=True
    else:row['proposal_phases'][0]['classification_error']='invalid input batch'
    with pytest.raises((ValueError,KeyError)):tool.validate_prefix_hits(campaign,document)


def test_phase_observation_is_cpu_only_preserves_none_and_skips_dummy_profile():
    calls=[]
    class Spec:
        def propose(self,input_batch,dummy_run=False,is_profile=False):
            calls.append(input_batch);return None
    spec=Spec();worker=N(model_runner=N(speculator=spec));tool.install_phase_audit(worker)
    batch=_batch(req_ids=('continue','decode'),computed=(32,80),scheduled=(16,1),prompt=(80,80))
    assert spec.propose(batch) is None
    assert spec.propose(batch,dummy_run=True) is None
    assert spec.propose(batch,is_profile=True) is None
    assert len(calls)==3 and len(worker._mrv2_service_phases)==1
    row=worker._mrv2_service_phases[0]
    assert row['batch_phase']=='mixed' and row['row_phases']==['prefill_continuing','pure_decode']
    assert row['returned'] is True and 'classification_error' not in row


def test_phase_recording_never_replaces_real_failure_or_blocks_on_record_limit(monkeypatch):
    failure=RuntimeError('real proposal error');calls=[]
    class Spec:
        def propose(self,input_batch):
            calls.append(input_batch)
            if len(calls)==3:raise failure
            return None
    spec=Spec();worker=N(model_runner=N(speculator=spec));monkeypatch.setattr(tool,'MAX_PHASE_RECORDS',1)
    tool.install_phase_audit(worker)
    batch=_batch(req_ids=('decode',),computed=(80,),scheduled=(1,),prompt=(80,))
    spec.propose(batch);spec.propose(batch)
    with pytest.raises(RuntimeError) as caught:spec.propose(batch)
    assert caught.value is failure and len(calls)==3
    assert worker._mrv2_service_phases_truncated is True and len(worker._mrv2_service_phases)==1
