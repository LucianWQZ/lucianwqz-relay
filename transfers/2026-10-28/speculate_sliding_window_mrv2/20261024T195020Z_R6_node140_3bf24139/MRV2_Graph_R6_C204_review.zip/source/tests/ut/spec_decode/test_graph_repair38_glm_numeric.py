# SPDX-License-Identifier: Apache-2.0
"""GLM rank integration is explicit and cannot silently change the Qwen ABI."""
import json
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair12_contract import method_for_profile
from tools.p7x_graph_repair25_rank_numeric import RankControlledTarget, RankNumericWorker, PROFILE as QWEN
from tools.p7x_graph_repair32_glm_rank import GLMRankWorker
from tools.p7x_graph_repair37_glm_target import PROFILE, GLMControlledTarget
from tools.p7x_graph_repair38_glm_numeric import (
    GLMNumericWorker,GLMRankControlledTarget,build_kwargs,check_external,model_contract,validate_fixture,
)


def test_explicit_glm_worker_uses_existing_real_rank_chain_without_mutating_default():
    assert GLMNumericWorker.diagnostic_profile == PROFILE and RankNumericWorker.diagnostic_profile == QWEN
    assert GLMNumericWorker.controlled_type is GLMRankControlledTarget
    assert GLMNumericWorker.mrv2_rank_snapshot is GLMRankWorker.mrv2_rank_snapshot
    assert GLMRankControlledTarget._save is RankControlledTarget._save
    assert GLMRankControlledTarget._resource_plan is GLMControlledTarget._resource_plan
    assert GLMRankControlledTarget._target_slots_by_layer is GLMControlledTarget._target_slots_by_layer
    old=RankNumericWorker.__new__(RankNumericWorker)
    new=GLMNumericWorker.__new__(GLMNumericWorker)
    owner=SimpleNamespace(method="dspark",sample_from_anchor=True,num_query_per_req=8,num_speculative_steps=8,
                          requires_non_causal=True)
    new._validate_method_owner(owner)
    with pytest.raises(ValueError): old._validate_method_owner(owner)
    owner.num_query_per_req=7;owner.num_speculative_steps=7
    old._validate_method_owner(owner)
    with pytest.raises(ValueError): new._validate_method_owner(owner)


@pytest.mark.parametrize("arm",["ON","OFF"])
def test_glm_real_engine_config_keeps_target_quantization_masks_and_exact_method(arm):
    kwargs=build_kwargs(arm,16)
    assert kwargs["speculative_config"]["num_speculative_tokens"] == 8
    assert kwargs["worker_extension_cls"] == "tools.p7x_graph_repair38_glm_numeric.GLMNumericWorker"
    assert kwargs["quantization"] == "ascend" and kwargs["enable_expert_parallel"]
    assert kwargs["compilation_config"]["cudagraph_capture_sizes"] == [8,16,32,36]
    assert kwargs["additional_config"].get("draft_window_graph_numeric_diagnostic",False) == (arm == "ON")
    assert "causal" not in kwargs.get("hf_overrides",{})
    for tp in (True,1,2,4,8):
        with pytest.raises(ValueError): build_kwargs(arm,tp)
    with pytest.raises(ValueError): build_kwargs("UNKNOWN",16)


def test_fixture_verification_is_small_hash_index_and_explicit_source_not_qwen_alias(tmp_path,monkeypatch):
    import tools.p7x_graph_repair38_glm_numeric as module
    import tools.p7x_graph_local_candidate as local
    from tools.p7x_graph_repair21_rank import digest
    observed=[]
    monkeypatch.setattr(local,"_identity",lambda *a,**k:observed.append((a,k)))
    identity=dict(profile="GLM",files=[dict(path="config",sha256="f"*64,bytes=3)])
    monkeypatch.setattr(module,"profile_identity",lambda:identity)
    fixture=tmp_path/'glm.json';fixture.write_text(json.dumps(dict(schema="glm38-model-identity-v1",profile_identity=identity)))
    plan=tmp_path/'plan.json';data=dict(schema="glm38-frozen-diagnostic-plan-v1",fixture_sha256=digest(fixture),
         fixture_manifest=str(fixture),profile_identity=identity,source="/fixed-glm",source_sha="a"*40,source_tree="b"*40)
    plan.write_text(json.dumps(data))
    result=validate_fixture(plan,fixture)
    assert result['source_sha'] == "a"*40 and observed[0][0][1:] == ("a"*40,"b"*40)
    for damage in ("hash","profile","schema"):
        bad=dict(data)
        if damage == "hash":bad['fixture_sha256']='0'*64
        elif damage == "profile":bad['profile_identity']={}
        else:bad['schema']='old-qwen-plan'
        plan.write_text(json.dumps(bad))
        with pytest.raises(ValueError):validate_fixture(plan,fixture)


def test_external_glm_join_supplies_separate_validators_and_reports_source_contract(monkeypatch):
    import tools.p7x_graph_repair38_glm_numeric as module
    observed={}
    def common(*args,**kwargs):
        observed.update(kwargs);return dict(status="INVALID_EVIDENCE",error="damaged external worker join")
    monkeypatch.setattr(module,"common_check_external",common)
    result=check_external("/missing-planned","/missing-execution")
    assert result["status"] == "INVALID_EVIDENCE" and result["error"] == "damaged external worker join"
    assert observed["profile"] == PROFILE and observed["kwargs_factory"] is build_kwargs
    assert observed["model_contract_factory"] is model_contract and observed["fixture_validator"] is validate_fixture
    assert observed["payload_checker"] is module.check_payload
    assert result["target_binding_scope"] == "SOURCE_OWNED_SFA_INPUTS_NOT_NATIVE_EXECUTION_OPERANDS"
