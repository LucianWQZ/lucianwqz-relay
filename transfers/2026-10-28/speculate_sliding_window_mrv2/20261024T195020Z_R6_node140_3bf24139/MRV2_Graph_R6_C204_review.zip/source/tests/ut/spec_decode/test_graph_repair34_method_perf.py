# SPDX-License-Identifier: Apache-2.0
"""Different methods cannot inherit DSpark K7 counters or fake balanced samples."""
import copy

import pytest

from tools.p7x_graph_repair34_method_perf import METHODS,acceptance,capacity,validate_cell


def workload():
    return [dict(label='short',prompts=[dict(prompt_token_ids=[100]*257)],max_tokens=256)]


@pytest.mark.parametrize('method',['dflash','eagle3','dspark_q8'])
@pytest.mark.parametrize('arm,position',[('G_OFF',1),('G_ON',2),('E_ON',3)])
def test_named_native_long_review_retains_own_capacity_and_balanced_order(method,arm,position):
    rows=[dict(label='native32k',prompts=[dict(prompt_token_ids=[100]*32769)],max_tokens=512)]
    assert validate_cell(method,arm,40960,rows,1,position,False,
                         native_long_context_review=True)==METHODS[method]
    with pytest.raises(ValueError):
        validate_cell(method,arm,40960,rows,1,position,False)


@pytest.mark.parametrize('damage',['short','overbound','batch','output','old_capacity','false_string','pair'])
def test_native_long_review_cannot_alias_existing_profiles_or_unbounded_requests(damage):
    rows=[dict(label='native32k',prompts=[dict(prompt_token_ids=[100]*32769)],max_tokens=512)]
    maximum=40960;flag=True;pair=None
    if damage=='short':rows[0]['prompts'][0]['prompt_token_ids']=[100]*257
    elif damage=='overbound':rows[0]['prompts'][0]['prompt_token_ids']=[100]*32770
    elif damage=='batch':rows[0]['prompts']*=2
    elif damage=='output':rows[0]['max_tokens']=256
    elif damage=='old_capacity':maximum=24576
    elif damage=='false_string':flag='false'
    else:pair='BASE'
    with pytest.raises(ValueError):
        validate_cell('eagle3','G_ON',maximum,rows,1,2,False,
                      native_long_context_review=flag,pinned_pair_variant=pair)


def test_native_long_review_never_invents_native_model_or_rope_capacity():
    cfg=dict(transformer_layer_config=dict(max_position_embeddings=40960,rope_scaling=None))
    capacity(cfg,40960)
    bad=copy.deepcopy(cfg);bad['transformer_layer_config']['max_position_embeddings']=32768
    with pytest.raises(ValueError):capacity(bad,40960)
    bad=copy.deepcopy(cfg);bad['transformer_layer_config']['rope_scaling']={'type':'yarn','factor':2}
    with pytest.raises(ValueError):capacity(bad,40960)


@pytest.mark.parametrize('repeat', range(1,7))
def test_owned_pinned_pair_uses_actual_two_cell_order_not_a_three_arm_slot(repeat):
    order=('BASE','OWNED') if repeat%2 else ('OWNED','BASE')
    for position,variant in enumerate(order,1):
        result=validate_cell('eagle3','G_ON',4096,workload(),repeat,position,False,pinned_pair_variant=variant)
        assert result==METHODS['eagle3']
        with pytest.raises(ValueError,match='pair order'):
            validate_cell('eagle3','G_ON',4096,workload(),repeat,3-position,False,pinned_pair_variant=variant)


@pytest.mark.parametrize('method,arm,repeat,position,variant', [
    ('dflash','G_ON',1,1,'BASE'), ('eagle3','E_ON',1,1,'BASE'),
    ('eagle3','G_ON',True,1,'BASE'), ('eagle3','G_ON',1,True,'BASE'),
    ('eagle3','G_ON',1,3,'OWNED'), ('eagle3','G_ON',1,1,True),
    ('eagle3','G_ON',1,1,'UNDECLARED'),
])
def test_pair_cannot_alias_another_method_arm_type_or_legacy_slot(method,arm,repeat,position,variant):
    with pytest.raises(ValueError):
        validate_cell(method,arm,4096,workload(),repeat,position,False,pinned_pair_variant=variant)


def test_pair_profiler_is_still_separate_from_normal_repeats():
    assert validate_cell('eagle3','G_ON',4096,workload(),0,0,True,pinned_pair_variant='OWNED')==METHODS['eagle3']
    with pytest.raises(ValueError):
        validate_cell('eagle3','G_ON',4096,workload(),1,2,True,pinned_pair_variant='OWNED')


@pytest.mark.parametrize('variant,enabled', [('BASE',True), ('OWNED',False), (True,True), ('other',False)])
def test_pair_configuration_rejects_a_different_actual_copy_policy_before_loading_models(variant,enabled):
    from types import SimpleNamespace
    from tools.p7x_graph_repair34_method_perf import configuration

    with pytest.raises(ValueError,match='pair variant'):
        configuration(SimpleNamespace(method='eagle3',arm='G_ON',eagle3_pinned_h2d_review=enabled,
                                      pinned_pair_variant=variant))


@pytest.mark.parametrize('method,k,q', [('dflash',15,16),('eagle3',3,4),('dspark_q8',7,8)])
def test_named_method_keeps_its_distinct_k_and_query_contract(method,k,q):
    contract=validate_cell(method,'G_OFF',4096,workload(),1,1,False)
    assert contract['k']==k and contract['first_query']==q
    with pytest.raises(TypeError):METHODS[method]['k']=7
    with pytest.raises(ValueError):validate_cell(method,'G_ON',4096,workload(),1,1,False)
    with pytest.raises(ValueError):validate_cell(method,'G_ON',4096,workload(),1,2,True)
    assert validate_cell(method,'G_ON',4096,workload(),0,0,True)==contract


@pytest.mark.parametrize('damage',['output','prompt','capacity','repeat','position','profile_bool','profile_repeat_bool','method'])
def test_non_frozen_or_mislabelled_normal_workload_refused(damage):
    rows=workload();method='dflash';maximum=4096;repeat=1;position=1;profile=False
    if damage=='output':rows[0]['max_tokens']=16
    elif damage=='prompt':rows[0]['prompts'][0]['prompt_token_ids']=[True]
    elif damage=='capacity':maximum=24576;rows[0]['prompts'][0]['prompt_token_ids']=[100]*24576
    elif damage=='repeat':repeat=True
    elif damage=='position':position=2
    elif damage=='profile_bool':profile='false'
    elif damage=='profile_repeat_bool':profile=True;repeat=False;position=0
    else:method='dspark_k7'
    with pytest.raises(ValueError):validate_cell(method,'G_OFF',maximum,rows,repeat,position,profile)


def test_native_capacity_checks_nested_eagle_model_and_never_changes_rope():
    cfg=dict(transformer_layer_config=dict(max_position_embeddings=32768,rope_parameters=dict(rope_type='default')))
    capacity(cfg,24576)
    bad=copy.deepcopy(cfg);bad['transformer_layer_config']['max_position_embeddings']=8192
    with pytest.raises(ValueError):capacity(bad,24576)
    bad=copy.deepcopy(cfg);bad['transformer_layer_config']['rope_parameters']['rope_type']='linear'
    with pytest.raises(ValueError):capacity(bad,24576)
    with pytest.raises(ValueError):capacity(dict(rope_theta=1000000),24576)


@pytest.mark.parametrize('arm',['G_OFF','G_ON','E_ON'])
def test_q8_real_configuration_uses_only_owned_config_view(tmp_path,arm):
    import json
    from types import SimpleNamespace
    from tools import p7x_graph_repair34_method_perf as perf
    from tools.p7x_graph_repair12_contract import method_for_profile
    target=tmp_path/'target';target.mkdir();(target/'config.json').write_text('{"max_position_embeddings":32768}')
    original=tmp_path/'original.json';original.write_text('{"max_position_embeddings":32768,"sample_from_anchor":true}')
    weights=tmp_path/'weights.safetensors';weights.write_bytes(b'unit-test-only-not-model-weights')
    view=tmp_path/'owned-view';view.mkdir();config=view/'config.json'
    config.write_text('{"max_position_embeddings":32768,"sample_from_anchor":false}')
    (view/'model.safetensors').symlink_to(weights)
    doc=dict(schema='r5-dspark-noanchor-q8-fixture-v1',target_model=str(target),draft_model=str(view),
             method_contract=method_for_profile('dspark_k7_noanchor_q8').document(),
             source_config=str(original),source_config_sha256=perf.digest(original),weight_source=str(weights),
             files=[dict(path=str(config),sha256=perf.digest(config)),dict(path=str(weights),sha256=perf.digest(weights))])
    fixture=tmp_path/'fixture.json';fixture.write_text(json.dumps(doc))
    args=SimpleNamespace(method='dspark_q8',arm=arm,fixture=fixture,fixture_sha256=perf.digest(fixture),
                         expected_sha='a'*40,vllm_repo=tmp_path/'pin',output=tmp_path/'output',
                         run_id='unit-config',case_id='unit-Q8',max_model_len=24576)
    base,actual,kwargs=perf.configuration(args)
    assert base.repair5_capture_profile=='dspark_k7_noanchor_q8' and actual==doc
    assert kwargs['speculative_config']['model']==str(view)
    assert kwargs['speculative_config']['num_speculative_tokens']==7
    assert kwargs['speculative_config']['enforce_eager'] is (arm=='E_ON')
    assert kwargs['compilation_config']==dict(cudagraph_mode='FULL_DECODE_ONLY',cudagraph_capture_sizes=[8,16,32])
    assert kwargs['additional_config']==({} if arm=='G_OFF' else {'draft_window_size':1024})
    assert kwargs['max_model_len']==24576 and kwargs['per_request_spec_decode_metrics']=='detailed'
    assert kwargs['gpu_memory_utilization']==0.8
    assert json.loads(original.read_text())['sample_from_anchor'] is True
    config.write_text(original.read_text())
    with pytest.raises(ValueError,match='only explicit sampling config change'):perf.configuration(args)


def test_absolute_cli_exposes_named_q8_without_loading_a_model(tmp_path):
    import subprocess,sys
    from pathlib import Path
    from tools import p7x_graph_repair34_method_perf as perf
    result=subprocess.run([sys.executable,str(Path(perf.__file__).resolve()),'--help'],
                          cwd=tmp_path,capture_output=True,text=True,timeout=30)
    assert result.returncode==0,result.stderr
    assert 'dspark_q8' in result.stdout


@pytest.mark.parametrize('method',['dflash','eagle3','dspark_q8'])
def test_actual_short_final_proposals_and_bonus_are_separate_from_draft_rate(method):
    k=METHODS[method]['k'];drafted=[k,k-2,1];accepted=[k,0,1]
    metrics=dict(num_spec_tokens=k,per_step_drafted=drafted,per_step_accepted=accepted,
        acceptance_histogram=[accepted.count(i) for i in range(k+1)],num_draft_tokens=sum(drafted),
        num_accepted_draft_tokens=sum(accepted),num_spec_steps=3,draft_acceptance_rate=sum(accepted)/sum(drafted),
        mean_acceptance_length=1+sum(accepted)/3)
    result=acceptance(method,metrics)
    assert result['rate']==(k+1)/(2*k-1)
    assert result['mean_acceptance_length_including_bonus']==1+(k+1)/3
    assert result['proposed_per_position'][0]==3 and result['accepted_per_position'][0]==2
    for field,value in [('num_spec_tokens',7 if k!=7 else 8),('num_draft_tokens',sum(drafted)+1),('draft_acceptance_rate',1.0)]:
        bad=copy.deepcopy(metrics);bad[field]=value
        with pytest.raises(ValueError):acceptance(method,bad)
    with pytest.raises(ValueError):acceptance(method,None)


@pytest.mark.parametrize('method',['dflash','dspark_q8'])
def test_independent_artifact_reader_rejects_wrong_worker_and_diagnostic_contamination(tmp_path,monkeypatch,method):
    import hashlib,json
    from types import SimpleNamespace
    from tools import p7x_graph_repair34_method_perf as perf
    request=tmp_path/'requests.json';request.write_text(json.dumps(workload()))
    fixture=tmp_path/'fixture.json';fixture.write_text('{}')
    args=SimpleNamespace(method=method,arm='G_OFF',max_model_len=4096,repetition=1,order_position=1,profile=False,
        requests=request,fixture=fixture,expected_sha='a'*40,producer_source=tmp_path)
    kwargs={'frozen':'method config','diagnostic':False}
    monkeypatch.setattr(perf,'configuration',lambda args:(None,{},kwargs))
    k=METHODS[method]['k'];n=255;metric=dict(num_spec_tokens=k,per_step_drafted=[k]*n,per_step_accepted=[0]*n,
        acceptance_histogram=[n]+[0]*k,num_draft_tokens=k*n,num_accepted_draft_tokens=0,num_spec_steps=n,
        draft_acceptance_rate=0,mean_acceptance_length=1)
    identity=dict(source_sha='a'*40,process_id=123)
    c=dict(status='REQUESTS_COMPLETED',startup_complete=True,graph_submission_uncertain=False,
        method_isolation_required=False,identity=identity,method=method,method_contract=dict(METHODS[method]),
        normal_observation_state=dict(provider_installed=False,heavy_observer_enabled=False,session_kind='NONE'),
        arm='G_OFF',requests_sha256=perf.digest(request),requests=workload(),fixture_sha256=perf.digest(fixture),
        llm_kwargs=kwargs,config_sha256=hashlib.sha256(json.dumps(kwargs,sort_keys=True).encode()).hexdigest(),
        repetition=1,order_position=1,profile=False,heavy_observer_enabled=False,window_provider_installed=False,
        speculator='vllm_ascend.worker.v2.spec_decode.dflash.speculator.AscendDFlashSpeculator',
        speculator_python_source=str(tmp_path/'vllm_ascend/worker/v2/spec_decode/dflash/speculator.py'),
        warmup=dict(policy='ALL_DECLARED_GROUPS',groups=[dict(label='short',max_tokens=256,token_ids=[[100]*256])]),
        outputs=[dict(label='short',actual_input_ids=[[100]*257],token_ids=[[100]*256],finished=[True],start_ns=100,end_ns=200,
                      metrics=[dict(finished=True,speculative_decoding=metric)],window_identity=None)])
    if method=='dspark_q8':
        from tools.p7x_graph_repair12_contract import method_for_profile
        c.update(speculator='vllm_ascend.worker.v2.spec_decode.dspark.speculator.AscendDSparkSpeculator',
                 speculator_python_source=str(tmp_path/'vllm_ascend/worker/v2/spec_decode/dspark/speculator.py'),
                 runtime_parallel_contract=dict(contract=method_for_profile('dspark_k7_noanchor_q8').document(),
                                                actual_query=8,actual_sample_from_anchor=False))
        captured=dict(graphs=[dict(mode='FULL',num_reqs=n,num_tokens=8*n) for n in [1,2,4]])
        c.update(target_inventory=copy.deepcopy(captured),inventory=dict(draft=copy.deepcopy(captured)))
    profile=dict(identity=identity,python_worker_pid=123,profiler_enabled=False,detailed_diagnostic=False,
        scope='NORMAL_OBSERVER_OFF',counter_length_experiment=False,
        calls=[dict(active=True,label=label) for label in ['Target_REPLAY_SUBMIT','Draft_REPLAY_SUBMIT'] for _ in range(255)])
    result=perf.check_artifacts(c,profile,args)
    assert result['output_tokens']==256 and result['verification_request_steps']==255
    for damaged in ['source','scope','input','finished','counts','bool_order','bool_contract','config_type','observer_type']:
        cc,pp=copy.deepcopy(c),copy.deepcopy(profile)
        if damaged=='source':cc['speculator_python_source']='/old/speculator.py'
        elif damaged=='scope':pp['scope']='DIAGNOSTIC_SERIALIZED'
        elif damaged=='input':cc['outputs'][0]['actual_input_ids'][0][0]=101
        elif damaged=='finished':cc['outputs'][0]['finished'][0]=False
        elif damaged=='counts':cc['outputs'][0]['metrics'][0]['speculative_decoding']['num_draft_tokens']+=1
        elif damaged=='bool_order':cc['repetition']=True
        elif damaged=='bool_contract':cc['method_contract']['causal']=0
        elif damaged=='config_type':cc['llm_kwargs']['diagnostic']=0
        else:cc['normal_observation_state']['provider_installed']=0
        with pytest.raises(ValueError):perf.check_artifacts(cc,pp,args)
    if method=='dspark_q8':
        for field,value in [('actual_query',7),('actual_sample_from_anchor',True),('actual_sample_from_anchor',0)]:
            cc=copy.deepcopy(c);cc['runtime_parallel_contract'][field]=value
            with pytest.raises(ValueError):perf.check_artifacts(cc,copy.deepcopy(profile),args)
        for damage in ['missing_target','missing_draft','wrong_width','contract_bool']:
            cc=copy.deepcopy(c)
            if damage=='missing_target':cc['target_inventory']['graphs'].pop()
            elif damage=='missing_draft':cc['inventory']['draft']['graphs'].pop()
            elif damage=='wrong_width':cc['inventory']['draft']['graphs'][0]['num_tokens']=7
            else:cc['runtime_parallel_contract']['contract']['sample_offset']=True
            with pytest.raises(ValueError):perf.check_artifacts(cc,copy.deepcopy(profile),args)


def test_failed_forward_never_stops_native_profiler_or_masks_original_error(monkeypatch):
    from tools.p7x_graph_repair34_method_perf import isolating_profiler_type
    from tools.p7x_graph_repair5_profile import RequestProfiler
    calls=[]
    class Native:
        def __exit__(self,*exc):calls.append('NATIVE_STOP')
    def parent_exit(self,*exc):
        if self.profiler is not None:self.profiler.__exit__(*exc)
        calls.append('HOST_EXPORT')
        raise OSError('Host export unavailable')
    monkeypatch.setattr(RequestProfiler,'__exit__',parent_exit)
    cls=isolating_profiler_type();probe=cls.__new__(cls);native=Native();probe.profiler=native
    failure=RuntimeError('unknown failed native forward')
    assert probe.__exit__(RuntimeError,failure,None) is False
    assert calls==['HOST_EXPORT'] and probe._unclosed_profiler_after_error is native
    assert probe.native_cleanup_skipped_after_error and 'Host export unavailable' in probe.host_export_error
    probe=cls.__new__(cls);probe.profiler=Native();calls.clear()
    with pytest.raises(OSError):probe.__exit__(None,None,None)
    assert calls==['NATIVE_STOP','HOST_EXPORT']


def test_actual_eagle_session_has_no_parallel_recorder_and_keeps_safety_provider():
    from types import SimpleNamespace as N
    from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_capture import Eagle3GraphSession
    from tools.p7x_graph_repair34_method_perf import normal_observation_state
    spec=N();provider=N(observer=None);session=object.__new__(Eagle3GraphSession)
    session.owner=spec;session.provider=provider;session.numeric_snapshots=None
    spec._eagle3_graph_session=session;spec._draft_window_graph_binding_provider=provider
    assert not hasattr(session,'recorder')
    assert normal_observation_state(spec)==dict(provider_installed=True,heavy_observer_enabled=False,session_kind='EAGLE3')
    provider.observer=N()
    with pytest.raises(ValueError,match='source observer'):normal_observation_state(spec)
    provider.observer=None;session.numeric_snapshots=object()
    with pytest.raises(ValueError,match='tensor snapshots'):normal_observation_state(spec)
    session.numeric_snapshots=None;spec._draft_window_graph_binding_provider=N(observer=None)
    with pytest.raises(ValueError,match='safety provider'):normal_observation_state(spec)


def test_parallel_normal_session_requires_disabled_recorder_and_owned_provider():
    from types import SimpleNamespace as N
    from tools.p7x_graph_repair34_method_perf import normal_observation_state
    spec=N();provider=N(observer=None)
    spec._draft_window_graph_binding_provider=provider
    spec._draft_window_graph_characterization=N(owner=spec,provider=provider,recorder=N(enabled=False))
    assert normal_observation_state(spec)['session_kind']=='PARALLEL'
    spec._draft_window_graph_characterization.recorder.enabled=True
    with pytest.raises(ValueError,match='recorder OFF'):normal_observation_state(spec)
    assert normal_observation_state(N())['session_kind']=='NONE'
