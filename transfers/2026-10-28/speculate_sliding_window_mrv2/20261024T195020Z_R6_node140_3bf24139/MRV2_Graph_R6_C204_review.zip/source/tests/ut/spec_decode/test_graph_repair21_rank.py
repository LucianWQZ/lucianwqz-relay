# SPDX-License-Identifier: Apache-2.0
"""All-rank admission/dispatch anchors reject partial or cross-source evidence."""
import copy
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair21_rank import RankWorkerExtension, digest, validate_admission, validate_rank_records


def rank_records():
    return [
        dict(rank=rank,
             pid=200 + rank,
             world_size=2,
             tp_size=2,
             window_size=None,
             ascend_source="/candidate/vllm_ascend/__init__.py",
             draft_graph_inventory=[dict(tokens=7)],
             vllm_source="/pin/vllm/__init__.py",
             target_graph_inventory=[dict(tokens=8)],
             draft_replays=4,
             target_replays=5,
             draft_kv_geometry={"layer/0": dict(shape=[64, 128, 4, 128])},
             submission_uncertain=False) for rank in range(2)
    ]


def test_complete_all_rank_anchor_and_damaged_external_identity():
    rows = rank_records()
    assert validate_rank_records(rows, tp=2, source="/candidate", vllm_source="/pin", window=None)["ranks"] == 2
    mutations = [
        lambda x: x.pop(), lambda x: x[1].update(rank=0), lambda x: x[1].update(pid=200),
        lambda x: x[1].update(ascend_source="/old/vllm_ascend/__init__.py"),
        lambda x: x[1].update(vllm_source="/old/vllm/__init__.py"), lambda x: x[1].update(draft_replays=0),
        lambda x: x[1].update(window_size=1024), lambda x: x[1].update(submission_uncertain=True)
    ]
    for mutate in mutations:
        damaged = copy.deepcopy(rows)
        mutate(damaged)
        with pytest.raises(ValueError):
            validate_rank_records(damaged, tp=2, source="/candidate", vllm_source="/pin", window=None)


def test_real_method_wrapper_preserves_none_and_records_both_roles():
    calls = []

    class Manager:

        def run_fullgraph(self, descriptor):
            calls.append(descriptor)
            return None

    worker = RankWorkerExtension()
    target, draft = Manager(), Manager()
    worker.rank = 1
    worker.model_runner = SimpleNamespace(cudagraph_manager=target,
                                          speculator=SimpleNamespace(query_cudagraph_manager=draft))
    installed = worker.mrv2_rank_install_dispatch_observer()
    desc = SimpleNamespace(num_tokens=7, num_reqs=1, cg_mode=SimpleNamespace(name="FULL"))
    assert target.run_fullgraph(desc) is None and draft.run_fullgraph(desc) is None
    assert len(calls) == 2 and installed["rank"] == 1
    assert all(row["returned"] for row in worker._mrv2_rank_replay_records)
    assert [row["role"] for row in worker._mrv2_rank_replay_records] == ["target", "draft:query_cudagraph_manager"]
    with pytest.raises(ValueError, match="already installed"):
        worker.mrv2_rank_install_dispatch_observer()


def test_async_materialization_observer_wraps_actual_lanes_and_keeps_their_independent_identity():
    calls = []

    class Runtime:
        def __init__(self, lane, block):
            self.lane = lane
            self.capability = SimpleNamespace(inventory=SimpleNamespace(
                groups=[SimpleNamespace(kernel_block_size=block)]))

        def materialize(self, **kwargs):
            calls.append(self.lane)
            identity = SimpleNamespace(generation_id=4, execution_lane=self.lane,
                global_group_id=0, mapping_epoch=100 + self.lane, phase=SimpleNamespace(value="parallel_proposal"),
                step=0, ordered_request_fingerprint=("request",),
                row_phase_fingerprint=("pure_decode",),
                topology_fingerprint=SimpleNamespace(tensor_parallel_size=2, tensor_parallel_rank=1),
                read_descriptor_fingerprint=[SimpleNamespace(source_start_column=3, first_token_offset=0)])
            return SimpleNamespace(identity=identity, actual_request_count=1, padded_request_count=2,
                cpu_window_exact=SimpleNamespace(tolist=lambda: [257, 0]))

    class Manager:
        def run_fullgraph(self, descriptor):
            return None

    unused, first, second = Runtime(99, 128), Runtime(0, 128), Runtime(1, 64)
    worker = RankWorkerExtension()
    worker.rank = 1
    worker.model_runner = SimpleNamespace(cudagraph_manager=Manager(), speculator=SimpleNamespace(
        query_cudagraph_manager=Manager(), _draft_window_runtime_state=unused,
        _draft_window_async_pool=SimpleNamespace(_runtimes=(first, second))))
    worker.mrv2_rank_install_dispatch_observer()
    assert first.materialize().identity.execution_lane == 0
    assert second.materialize().identity.execution_lane == 1
    assert calls == [0, 1]
    rows = worker._mrv2_rank_window_generations
    assert [row["execution_lane"] for row in rows] == [0, 1]
    assert [row["window_starts"] for row in rows] == [[384], [192]]
    assert [row["generation"] for row in rows] == [4, 4]  # Independent local counters.
    assert [row["row_phases"] for row in rows] == [["pure_decode"], ["pure_decode"]]


def admission_fixture(tmp_path, monkeypatch):
    from tools import p7x_graph_local_candidate as local
    from tools import p7x_graph_repair7_device as device
    from tools import p7x_graph_repair21_rank as rank
    monkeypatch.setattr(rank.time, "time", lambda: 1000)
    monkeypatch.setattr(rank, "live_owner", lambda owner: True)
    monkeypatch.setattr(local, "_identity", lambda *a, **k: None)
    inv = dict(hostname="host",
               boot_id="boot",
               namespace="mnt:1",
               visibility=dict(ASCEND_RT_VISIBLE_DEVICES="12,13", ASCEND_VISIBLE_DEVICES=None),
               nodes={
                   "/dev/davinci12": dict(major=236, minor=12),
                   "/dev/davinci13": dict(major=236, minor=13)
               },
               mapping_command=dict(rc=0, stdout="6 0 12 12 Ascend910\n6 1 13 13 Ascend910"))
    monkeypatch.setattr(device, "inspect", lambda: inv)
    monkeypatch.setattr(rank.subprocess, "run",
                        lambda *a, **k: SimpleNamespace(returncode=0, stdout="No running processes found in NPU 6"))
    auth = tmp_path / "auth.json"
    auth.write_text(
        json.dumps(
            dict(schema="mrv2-user-device-authorization-v1",
                 authority="USER_INSTRUCTION_NO_ADMIN_SIGNATURE",
                 hostname="host",
                 boot_id="boot",
                 host_phy_ids=list(range(16)),
                 deadline_epoch_seconds=2000)))
    runtime = tmp_path / "runtime.json"
    runtime.write_text("{}")
    leases, probes = {}, {}
    for phy in [12, 13]:
        path = tmp_path / f"lease{phy}.json"
        path.write_text(
            json.dumps(
                dict(token=f"t{phy}",
                     status="HELD",
                     host="host",
                     session="r6",
                     phy_ids=[12, 13],
                     candidate="sha",
                     lease_deadline="1970-01-01T00:20:00+00:00",
                     heartbeat_at="1970-01-01T00:16:35+00:00")))
        leases[str(phy)] = dict(path=str(path), token=f"t{phy}")
        observation = tmp_path / f"probe{phy}.txt"
        observation.write_text(f"| {phy // 2} {phy % 2} | {500 + phy} | worker | 400 | {400 + phy} |")
        path = tmp_path / f"probe{phy}.json"
        path.write_text(
            json.dumps(
                dict(physical_id=phy,
                     returncode=0,
                     value=1024,
                     logical_device=0,
                     boot_id="boot",
                     namespace="mnt:1",
                     host_pid=500 + phy,
                     container_pid=400 + phy,
                     observations=[dict(path=str(observation), sha256=digest(observation))])))
        probes[str(phy)] = dict(path=str(path), sha256=digest(path))
    receipt = dict(schema="repair21-complete-rank-admission-v1",
                   source_sha="sha",
                   source_tree="tree",
                   tp=2,
                   vllm_checkout="/pin",
                   host="host",
                   boot_id="boot",
                   namespace="mnt:1",
                   issued_at=995,
                   expires_at=1050,
                   authorization=dict(path=str(auth), sha256=digest(auth)),
                   phy_ids=[12, 13],
                   session="r6",
                   nodes={str(p): inv["nodes"][f"/dev/davinci{p}"]
                          for p in [12, 13]},
                   leases=leases,
                   probes=probes,
                   runtime_manifest=dict(path=str(runtime), sha256=digest(runtime)))
    return receipt, inv


def test_complete_set_admission_and_corrupted_contracts(tmp_path, monkeypatch):
    receipt, inv = admission_fixture(tmp_path, monkeypatch)
    path = tmp_path / "receipt.json"
    path.write_text(json.dumps(receipt))
    assert validate_admission(path, source=Path("/candidate"), sha="sha", tp=2)["phy_ids"] == [12, 13]
    mutations = [
        lambda x: x.update(phy_ids=[12, 12]), lambda x: x.update(tp=4), lambda x: x.update(issued_at=800),
        lambda x: x["leases"].pop("13"), lambda x: x["probes"].pop("13"), lambda x: x.update(source_sha="other"),
        lambda x: x.update(boot_id="old")
    ]
    for mutate in mutations:
        damaged = copy.deepcopy(receipt)
        mutate(damaged)
        path.write_text(json.dumps(damaged))
        with pytest.raises(ValueError):
            validate_admission(path, source=Path("/candidate"), sha="sha", tp=2)
    path.write_text(json.dumps(receipt))
    inv["visibility"]["ASCEND_RT_VISIBLE_DEVICES"] = "14,15"
    with pytest.raises(ValueError, match="visibility"):
        validate_admission(path, source=Path("/candidate"), sha="sha", tp=2)


def test_window_off_kwargs_follow_actual_production_policy_not_zero():
    from tools.p7x_graph_repair21_rank import build_rank_kwargs
    from vllm_ascend.worker.v2.spec_decode.draft_window import (DraftWindowPolicyState, resolve_draft_window_policy,
                                                                validate_eligible_window_numbers)
    config = build_rank_kwargs(2)
    decision = resolve_draft_window_policy(requested_window_size=config["additional_config"].get("draft_window_size"),
                                           method=config["speculative_config"]["method"],
                                           target_model_type="qwen3")
    assert decision.state is DraftWindowPolicyState.CONFIG_OFF
    # This exact old baseline value was rejected by both real MP workers.
    old = resolve_draft_window_policy(requested_window_size=0, method="dspark", target_model_type="qwen3")
    assert old.state is DraftWindowPolicyState.ELIGIBLE_ON
    with pytest.raises(ValueError, match="greater than 0"):
        validate_eligible_window_numbers(window_size=old.effective_window_size, future_offset=0)


def test_parallel_dspark_snapshot_uses_shared_context_not_eagle_attributes(monkeypatch):
    import torch
    from collections import namedtuple
    Descriptor = namedtuple("Descriptor", ["cg_mode", "num_tokens", "num_reqs"])
    Mode = namedtuple("Mode", ["name"])
    manager = SimpleNamespace(graphs={Descriptor(Mode("FULL"), 7, 1): object()})

    class Backend:
        pass

    config = SimpleNamespace(parallel_config=SimpleNamespace(world_size=2, tensor_parallel_size=2),
                             additional_config={})
    # Deliberately no draft_vllm_config or single attn_backend: these do not
    # exist on the real pinned parallel DSpark speculator.
    speculator = SimpleNamespace(
        draft_attn_layer_names={"draft"},
        query_cudagraph_manager=manager,
        attn_backends={"draft": Backend},
        speculative_config=SimpleNamespace(draft_parallel_config=SimpleNamespace(tensor_parallel_size=2)),
        draft_model_config=SimpleNamespace(model="/draft"))
    worker = RankWorkerExtension()
    worker.rank = worker.local_rank = 1
    worker.vllm_config = config
    worker.model_runner = SimpleNamespace(
        speculator=speculator,
        cudagraph_manager=manager,
        compilation_config=SimpleNamespace(
            static_forward_context={
                "draft": SimpleNamespace(kv_cache=[torch.empty((32, 128, 4, 128), dtype=torch.bfloat16)])
            }))
    monkeypatch.setattr(torch.npu, "current_device", lambda: 1)
    result = worker.mrv2_rank_snapshot()
    assert result["draft_tp_size"] == 2 and result["window_size"] is None
    assert result["draft_kv_geometry"]["draft/0"]["shape"] == [32, 128, 4, 128]
    assert result["draft_backend"]["draft"].endswith("Backend")


def test_window_on_requires_every_rank_provider_clipping_and_binding():
    rows = rank_records()
    for row in rows:
        row.update(window_size=1024,
                   window_provider_installed=True,
                   heavy_observer_enabled=False,
                   window_generations=[
                       dict(generation=1,
                            epoch=1,
                            requests=["a"],
                            actual=1,
                            padded=1,
                            window_starts=[1024],
                            exact=[1027],
                            tp_size=2,
                            tp_rank=row["rank"])
                   ],
                   window_graph_bindings=[dict(tp_size=2, tp_rank=row["rank"])])
    assert validate_rank_records(rows, tp=2, source="/candidate", vllm_source="/pin", window=1024)["ranks"] == 2
    for damage in (
            lambda x: x[1].update(window_provider_installed=False),
            lambda x: x[1].update(heavy_observer_enabled=True),
            lambda x: x[1]["window_generations"][0].update(tp_rank=0),
            lambda x: x[1]["window_generations"][0].update(window_starts=[0]),
            lambda x: x[1]["window_generations"][0].update(exact=[1000]),
            lambda x: x[1].update(window_graph_bindings=[]),
    ):
        bad = copy.deepcopy(rows)
        damage(bad)
        with pytest.raises(ValueError):
            validate_rank_records(bad, tp=2, source="/candidate", vllm_source="/pin", window=1024)


def test_review_cli_kwargs_keep_off_omitted_and_explicit_on():
    from tools.p7x_graph_repair21_rank import build_rank_kwargs
    assert "draft_window_size" not in build_rank_kwargs(2)["additional_config"]
    on = build_rank_kwargs(2, window_on_review=True)
    assert on["tensor_parallel_size"] == 2
    assert on["additional_config"] == dict(draft_window_size=1024, draft_window_graph_replicated_tp_review=True)
    for tp in (4, 16):
        on = build_rank_kwargs(tp, window_on_review=True)
        assert on["tensor_parallel_size"] == tp and on["additional_config"]["draft_window_graph_replicated_tp_review"]
    for tp in (1, 3, 8, True, 4.0):
        with pytest.raises(ValueError):
            build_rank_kwargs(tp, window_on_review=True)
