# SPDX-License-Identifier: Apache-2.0
"""Explicit all-rank diagnostics preserve TP1 guards and reject broken joins."""
import copy
import json
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair25_rank_numeric import (
    RankContract,
    RankTargetAdapter,
    host_sample_barrier,
    validate_barrier,
    validate_worker_set,
)
from tools.p7x_graph_repair4_target import LiveTargetAdapter


def contract(rank=0):
    return RankContract(world_size=2, rank=rank, nonce="a" * 32, parent_pid=1234, source_sha="b" * 40)


def parallel(tp=2):
    return SimpleNamespace(tensor_parallel_size=tp,
                           world_size=tp,
                           data_parallel_size=1,
                           pipeline_parallel_size=1,
                           prefill_context_parallel_size=1,
                           decode_context_parallel_size=1)


def rank_session(monkeypatch):
    from tests.ut.spec_decode.test_draft_window_graph_characterization import _characterization_owner, _runtime_context
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import install_parallel_draft_window_graph_characterization
    monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE", "0")
    owner, descriptor = _characterization_owner()
    session = install_parallel_draft_window_graph_characterization(owner, runtime_context=_runtime_context())
    assert session.provider.observer is None and not session.recorder.enabled
    return owner, session, descriptor


def test_late_rank_recorder_receives_real_provider_runtime_events(tmp_path, monkeypatch):
    from tools.p7x_graph_repair25_rank_numeric import install_rank_local_recorder
    from tests.ut.spec_decode.test_draft_window_graph_characterization import _materialize, _publish_eager_generation, _install_metadata_builder
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import prepare_parallel_draft_window_graph_characterization
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph import (
        DraftWindowGraphStage, consume_draft_window_graph_metadata, observe_draft_window_graph_source)
    owner, session, descriptor = rank_session(monkeypatch)
    proof = install_rank_local_recorder(owner, tmp_path)
    assert session.provider.observer is session.recorder and proof["recorder_id"] == session.recorder.recorder_id
    assert session.recorder.events == ()  # No synthetic retrospective capture evidence.
    inputs = _materialize(owner._draft_window_runtime_state, mapping_epoch=10)
    _publish_eager_generation(owner, inputs)
    _install_metadata_builder(owner)
    prepare_parallel_draft_window_graph_characterization(owner, descriptor)
    consume_draft_window_graph_metadata(owner, route=session.route, expected_consumer_count=1)
    observe_draft_window_graph_source(owner, DraftWindowGraphStage.REPLAY)
    observe_draft_window_graph_source(owner, DraftWindowGraphStage.UPDATE)
    assert any(event.stage.value == "replay" for event in session.recorder.events)
    assert any(event.stage.value == "update" for event in session.recorder.events)


@pytest.mark.parametrize("damage", ["session", "provider", "recorder", "enabled", "observer", "active", "quarantined", "uncertain"])
def test_late_rank_recorder_rejects_wrong_owner_or_live_scope_before_mutation(tmp_path, monkeypatch, damage):
    from tools.p7x_graph_repair25_rank_numeric import install_rank_local_recorder
    owner, session, _ = rank_session(monkeypatch)
    if damage == "session": session.owner = object()
    elif damage == "provider": owner._draft_window_graph_binding_provider = object()
    elif damage == "recorder": session.recorder._provider = object()
    elif damage == "enabled": session.recorder.enabled = True
    elif damage == "observer": session.provider._observer = object()
    elif damage == "active": owner._draft_window_runtime_state._active_inputs = object()
    elif damage == "quarantined": monkeypatch.setattr(type(owner._draft_window_runtime_state), "quarantined_identity", property(lambda _: object()))
    else: owner._draft_window_graph_submission_uncertain = True
    before = session.provider.observer
    with pytest.raises(ValueError): install_rank_local_recorder(owner, tmp_path)
    assert session.provider.observer is before and not (tmp_path / "rank-characterization.json").exists()


def test_rank_numeric_adapter_preserves_saved_summary_hash_for_unchanged_checker():
    from tools.p7x_graph_repair25_rank_numeric import rank_numeric_campaign
    index = {"numeric-summary.json": dict(bytes=100, sha256="a" * 64),
             "numeric-reference.json": dict(bytes=200, sha256="b" * 64)}
    document = dict(artifact_index=index, numeric_contract=dict(profile="target4"), snapshot=dict(events=[]))
    result = rank_numeric_campaign(document, dict(config_sha256="c" * 64))
    assert result["diagnostic_artifacts"] == index
    assert result["numeric_contract"] == document["numeric_contract"]
    assert result["snapshot"] == document["snapshot"]
    document["artifact_index"] = {}
    with pytest.raises(ValueError, match="summary index"):
        rank_numeric_campaign(document, dict(config_sha256="c" * 64))


def test_default_single_rank_guard_remains_and_explicit_rank_owner_never_masks_parallel_config():
    runner = SimpleNamespace(speculator=SimpleNamespace(method="dspark",
                                                        speculative_config=SimpleNamespace(
                                                            draft_parallel_config=SimpleNamespace(
                                                                tensor_parallel_size=2))))
    default = LiveTargetAdapter(runner, fixture_id="host")
    p = parallel()
    with pytest.raises(ValueError, match="single-rank"):
        default._validate_topology(p)
    explicit = RankTargetAdapter(runner, rank_contract=contract(1), actual_rank=1, fixture_id="host")
    before = vars(p).copy()
    explicit._validate_topology(p)
    assert vars(p) == before and p.tensor_parallel_size == 2
    for attribute in ("world_size", "data_parallel_size", "pipeline_parallel_size", "prefill_context_parallel_size",
                      "decode_context_parallel_size"):
        bad = copy.deepcopy(p)
        setattr(bad, attribute, 4)
        with pytest.raises(ValueError):
            explicit._validate_topology(bad)
    runner.speculator.speculative_config.draft_parallel_config.tensor_parallel_size = 1
    with pytest.raises(ValueError, match="Draft TP"):
        explicit._validate_topology(p)


@pytest.mark.parametrize("change", [
    dict(rank=True),
    dict(rank=2),
    dict(world_size=4),
    dict(nonce="old"),
    dict(parent_pid=0),
    dict(source_sha="unknown")
])
def test_incomplete_or_cross_rank_contract_fails(change):
    values = dict(world_size=2, rank=0, nonce="a" * 32, parent_pid=1234, source_sha="b" * 40)
    values.update(change)
    with pytest.raises(ValueError):
        RankContract(**values).validate(parallel(), 0)


def barrier_rows():
    return [
        dict(rank=r,
             world_size=2,
             nonce="a" * 32,
             source_sha="b" * 40,
             step=1,
             status="COMPLETED_SAMPLE",
             submission_pending=False) for r in (0, 1)
    ]


def test_host_stage_barrier_rejects_old_missing_failed_and_unknown_rank():
    rows = barrier_rows()
    validate_barrier(rows, contract(), 1)
    for damage in ("missing", "duplicate", "old", "source", "failed", "unknown", "boolrank", "step"):
        bad = copy.deepcopy(rows)
        if damage == "missing": bad.pop()
        elif damage == "duplicate": bad[1]["rank"] = 0
        elif damage == "old": bad[1]["nonce"] = "c" * 32
        elif damage == "source": bad[1]["source_sha"] = "c" * 40
        elif damage == "failed": bad[1]["status"] = "FAILED"
        elif damage == "unknown": bad[1]["submission_pending"] = True
        elif damage == "boolrank": bad[0]["rank"] = False
        else: bad[1]["step"] = 2
        with pytest.raises(ValueError):
            validate_barrier(bad, contract(), 1)


def test_local_unknown_stage_exports_host_marker_without_wait_or_device_access(tmp_path, monkeypatch):
    from tools import p7x_graph_repair25_rank_numeric as tool
    monkeypatch.setattr(tool.time, "sleep", lambda _: pytest.fail("failed local submission must not wait"))
    with pytest.raises(RuntimeError, match="Host-only isolation"):
        host_sample_barrier(tmp_path, contract(), 1, status="FAILED", pending=True)
    marker = json.loads((tmp_path / "step-001-rank-0.json").read_text())
    assert marker["submission_pending"] and marker["status"] == "FAILED"


def workers(tp=2):
    from tests.ut.spec_decode.test_graph_repair21_rank import rank_records
    baseline = rank_records()[0]
    rows = [dict(copy.deepcopy(baseline), rank=rank, pid=200+rank, world_size=tp, tp_size=tp) for rank in range(tp)]
    for row in rows:
        layers = [f"draft.layer-{i}" for i in range(5)]
        row.update(window_provider_installed=False,
                   heavy_observer_enabled=False,
                   nonce="a" * 32,
                   process_start_ticks="100",
                   draft_tp_size=tp,
                   parallel_sizes=dict(data_parallel_size=1,
                                       pipeline_parallel_size=1,
                                       prefill_context_parallel_size=1,
                                       decode_context_parallel_size=1),
                   boot_id="boot",
                   mount_namespace="mnt:1",
                   hostname="host",
                   visible="12,13" if tp == 2 else ",".join(map(str, range(tp))),
                   logical_device=row["rank"],
                   local_rank=row["rank"],
                   draft_layers=layers,
                   draft_backend={layer: "vllm_ascend.attention.attention_v1.AscendAttentionBackend" for layer in layers},
                   draft_kv_geometry={f"{layer}/{kind}": dict(shape=[256,128,max(1,8//tp),128], dtype="torch.bfloat16")
                                      for layer in layers for kind in (0,1)})
    return rows


def model_configs():
    return dict(draft=dict(layers=5, kv_heads=8, head_size=128), target=dict(layers=36, kv_heads=8, head_size=128))


def test_real_worker_preflight_requires_full_pid_source_and_mapping_identity():
    rows = workers()
    payload = dict(arm="OFF", world_size=2, model_configs=model_configs(),
                   nonce="a" * 32,
                   parent_pid=1234,
                   source_sha="b" * 40,
                   boot_id="boot",
                   mount_namespace="mnt:1",
                   hostname="host",
                   visible="12,13")
    assert validate_worker_set(rows, payload, "/candidate", "/pin")
    for damage in ("missing", "pid", "source", "rank", "boot", "logical", "visible", "namespace", "parallel"):
        bad = copy.deepcopy(rows)
        if damage == "missing": bad.pop()
        elif damage == "pid": bad[1]["pid"] = bad[0]["pid"]
        elif damage == "source": bad[1]["ascend_source"] = "/old/vllm_ascend/__init__.py"
        elif damage == "rank": bad[1]["rank"] = 0
        elif damage == "boot": bad[1]["boot_id"] = "anotherboot"
        elif damage == "logical": bad[1]["logical_device"] = 0
        elif damage == "visible": bad[1]["visible"] = "8,9"
        elif damage == "namespace": bad[1]["mount_namespace"] = "mnt:other"
        else: bad[1]["parallel_sizes"]["data_parallel_size"] = 2
        with pytest.raises(ValueError):
            validate_worker_set(bad, payload, "/candidate", "/pin")


@pytest.mark.parametrize("tp", [2, 4, 16])
def test_complete_declared_world_keeps_each_actual_rank_and_refuses_partial_set(tp):
    rows = workers(tp)
    payload = dict(world_size=tp, arm="OFF", model_configs=model_configs(), nonce="a"*32, parent_pid=1234, source_sha="b"*40,
                   boot_id="boot", mount_namespace="mnt:1", hostname="host", visible=rows[0]["visible"])
    assert validate_worker_set(rows, payload, "/candidate", "/pin")
    for rank in range(tp):
        RankContract(tp, rank, "a"*32, 1234, "b"*40).validate(parallel(tp), rank)
    for damage in ("missing", "duplicate", "draft", "logical", "world", "declared"):
        bad, changed = copy.deepcopy(rows), dict(payload)
        if damage == "missing": bad.pop()
        elif damage == "duplicate": bad[-1]["rank"] = 0
        elif damage == "draft": bad[-1]["draft_tp_size"] = 1
        elif damage == "logical": bad[-1]["logical_device"] = 0
        elif damage == "world": bad[-1]["world_size"] = 1
        else: changed["world_size"] = 8
        with pytest.raises(ValueError): validate_worker_set(bad, changed, "/candidate", "/pin")


@pytest.mark.parametrize("tp", [2, 4, 16])
def test_real_per_rank_kv_heads_and_backend_cannot_be_relabelled(tp):
    from tools.p7x_graph_repair25_rank_numeric import validate_rank_kv_geometry
    row = workers(tp)[-1]
    payload = dict(world_size=tp, model_configs=model_configs())
    validate_rank_kv_geometry(row, payload)
    for damage in ("heads", "layer", "backend", "missing_v", "dtype"):
        bad = copy.deepcopy(row)
        first = next(iter(bad["draft_kv_geometry"]))
        if damage == "heads": bad["draft_kv_geometry"][first]["shape"][2] += 1
        elif damage == "layer": bad["draft_layers"].pop()
        elif damage == "backend": bad["draft_backend"][bad["draft_layers"][0]] = "unverified.Backend"
        elif damage == "missing_v": bad["draft_kv_geometry"].pop(first)
        else: bad["draft_kv_geometry"][first]["dtype"] = "torch.float32"
        with pytest.raises(ValueError): validate_rank_kv_geometry(bad, payload)


def test_runtime_overlay_requires_current_source_and_real_native_file_hash(tmp_path):
    from tools.p7x_graph_repair25_rank_numeric import digest, validate_runtime_overlay
    source = tmp_path / "candidate"
    source.mkdir()
    native = source / "test-native.so"
    native.write_bytes(b"HOST_FIXTURE_NOT_ACTUAL_NATIVE")
    row = dict(relative_path=native.name, target=str(native), bytes=native.stat().st_size, sha256=digest(native))
    manifest = tmp_path / "runtime.json"
    manifest.write_text(json.dumps(dict(source_sha="a" * 40, source_tree="b" * 40, overlay=[row])))
    assert validate_runtime_overlay(manifest, source, "a" * 40, "b" * 40)["sha256"] == digest(manifest)
    with pytest.raises(ValueError, match="source identity"):
        validate_runtime_overlay(manifest, source, "c" * 40, "b" * 40)
    native.write_bytes(b"MODIFIED-NATIVE")
    with pytest.raises(ValueError, match="overlay changed"):
        validate_runtime_overlay(manifest, source, "a" * 40, "b" * 40)


def test_real_stored_payload_not_equal_producer_pass_controls_independent_write_mask(monkeypatch, tmp_path):
    from tests.ut.spec_decode.test_graph_repair6_numeric_pipeline import produce
    from tools.p7x_graph_repair6_storage import CollectionReader
    from tools.p7x_graph_repair6_numeric_check import validate_sample
    from tools.p7x_graph_repair5_target import case_plan
    from tools.p7x_graph_repair15_eagle_numeric_check import independent_write_deltas
    path, _, _ = produce(monkeypatch, tmp_path, sample_limit=3)
    reader = CollectionReader(path)
    row = reader.record(0)
    assert validate_sample(row, reader.header, case_plan("target4")[0])["status"] == "PASS"
    normalized = dict(
        row, actual_slots={name: row["inputs"]["slot_mapping"]
                           for name in reader.header["provenance"]["draft_layers"]})
    assert independent_write_deltas(normalized, reader.header["provenance"]) == []
    # Graph and reference can agree on the same illegal byte change; independent
    # canonical Full slots still reject it. This is CPU data, not an NPU result.
    # The content-addressed store may deduplicate equal pre/post buffers.
    # Build independent corrupt CPU payloads, keeping the canonical prestate fixed.
    for side in ("graph_post_kv", "reference_post_kv"):
        normalized[side] = {key: value.clone() for key, value in row[side].items()}
    key = next(iter(row["pre_kv"]))
    index = row["selected_blocks"].index(0)
    for side in ("graph_post_kv", "reference_post_kv"):
        normalized[side][key][index, 7, 0, 0] += 1
    assert independent_write_deltas(normalized, reader.header["provenance"])


@pytest.mark.parametrize("external_only", [False, True])
def test_external_join_rechecks_supervisor_pid_device_and_rpc_not_producer_pass(tmp_path, monkeypatch, external_only):
    import hashlib
    from tools import p7x_graph_repair25_rank_numeric as tool
    from tools import p7x_graph_local_candidate as local
    source = tmp_path / "candidate"
    output = tmp_path / "model"
    output.mkdir()
    admission = tmp_path / "admission.json"
    receipt = dict(session="HOST_R6", tp=2,
                   source_sha="b" * 40,
                   source_tree="c" * 40,
                   vllm_checkout="/pin",
                   host="host",
                   boot_id="boot",
                   namespace="mnt:1",
                   phy_ids=[12, 13],
                   runtime_manifest=dict(path="runtime", sha256="runtime-hash"))
    mapping = tmp_path / "mapping-HOST-TEST.json"
    mapping.write_text(json.dumps(dict(mapping_command=dict(rc=0, stdout="6 0 12 12 Ascend910\n6 1 13 13 Ascend910"))))
    receipt["mapping_evidence"] = dict(path=str(mapping), sha256=tool.digest(mapping))
    admission.write_text(json.dumps(receipt))
    argv = [
        "python",
        str(source / "tools/p7x_graph_repair25_rank_numeric.py"), "run", "--admission",
        str(admission), "--expected-sha", "b" * 40, "--rpc-nonce", "a" * 32, "--output",
        str(output), "--fixture",
        str(tmp_path / "fixture"), "--fixture-plan",
        str(tmp_path / "fixture-plan"), "--arm", "OFF", "--repair6-target-prefix", "3"
    ]
    if external_only: argv.append("--external-payload-check-only")
    cfg = tool.build_diagnostic_kwargs("OFF")
    payload = dict(world_size=2, nonce="a" * 32,
                   parent_pid=1234,
                   parent_argv=argv[1:],
                   source_sha="b" * 40,
                   source_tree="c" * 40,
                   output=str(output),
                   sample_limit=3,
                   arm="OFF",
                   scheduler_counts=dict(requests=0, running=0, waiting=0),
                   config_sha256=hashlib.sha256(json.dumps(cfg, sort_keys=True).encode()).hexdigest(),
                   model_configs=model_configs(),
                   fixture_sha256="fixturehash",
                   profile="target4",
                   hostname="host",
                   boot_id="boot",
                   mount_namespace="mnt:1",
                   visible="12,13",
                   run_id="r6-rank-controlled-HOST_R6",
                   runtime_manifest=receipt["runtime_manifest"])
    rows = workers()
    associations = []
    responses = []
    for row in rows:
        rank = row["rank"]
        row.update(ascend_source=str(source / "vllm_ascend/__init__.py"), nspid=[str(row["pid"])])
        evidence = tmp_path / f"management-rank-{rank}-HOST-TEST.txt"
        evidence.write_text("| NPU Chip | Process id | Process name | Process memory(MB) | Process id in container |\n"
                            f"| 6 {rank} | {1000+rank} | HOST-TEST-NOT-NPU | memory | {row['pid']} |\n")
        event = tmp_path / f"process-{rank}.jsonl"
        event.write_text(json.dumps(dict(utc="1970-01-01T00:00:02.500000+00:00", event="HEARTBEAT",
            candidate="b" * 40, node="host", worker_processes=[dict(pid=row["pid"], start_ticks=row["process_start_ticks"])],
            npu_observed_own_pids=[dict(host_pid=str(1000+rank), container_pid=str(row["pid"]), board_chip=f"6 {rank}")])) + "\n")
        from tools.p7x_graph_repair30_device_join import HOST_PID_SOURCE
        associations.append(
            dict(rank=rank,
                 pid=row["pid"],
                 physical_id=12 + rank,
                 host_pid=1000+rank, host_pid_source=HOST_PID_SOURCE,
                 process_start_ticks=row["process_start_ticks"], visible_nspid=row["nspid"],
                 observations=[dict(path=str(evidence), sha256=tool.digest(evidence),
                    process_evidence=dict(path=str(event), offset=0, bytes=event.stat().st_size, sha256=tool.digest(event)))]))
        path = output / f"rank-{rank}" / "rank-execution.json"
        path.parent.mkdir()
        path.write_text("HOST-PAYLOAD-UNIT-STUB-NOT-NPU")
        responses.append(dict(rank=rank, pid=row["pid"], nonce="a" * 32, path=str(path), sha256=tool.digest(path)))
    parent = dict(argv=argv[1:],
                  pid=1234,
                  state="ALL_RANK_ARTIFACTS_COLLECTED_REQUIRES_EXTERNAL_CHECK" if external_only else "ALL_RANK_SCOPED_CONTROLLED_PASS",
                  engine_shutdown_complete=True, payload_validation_mode="EXTERNAL_ONLY_NO_PRODUCER_NUMERIC_PASS",
                  started_at=2,
                  ended_at=3,
                  process_start_ticks="200",
                  admission_sha256=tool.digest(admission),
                  source_sha="b" * 40,
                  source_tree="c" * 40,
                  nonce="a" * 32,
                  payload=payload,
                  kwargs=cfg,
                  fixture_proof={},
                  workers=rows,
                  rpc_results=responses)
    execution = dict(argv=argv,
                     pid=1234,
                     returncode=0,
                     timeout=False,
                     signal=None,
                     start_epoch=1,
                     end_epoch=4,
                     start_ticks="200")
    planned = dict(argv=argv,
                   source_sha="b" * 40,
                   source_tree="c" * 40,
                   rpc_nonce="a" * 32,
                   phy_ids=[12, 13],
                   admission_sha256=tool.digest(admission))
    record = dict(execution=execution, per_rank_device_association=associations)
    monkeypatch.setattr(local, "_identity", lambda *a, **k: None)  # Separate native/source tests above.
    monkeypatch.setattr(tool, "validate_fixture_plan", lambda *a: {})
    monkeypatch.setattr(tool, "validate_runtime_overlay", lambda *a: receipt["runtime_manifest"])
    monkeypatch.setattr(tool, "model_layer_contract", lambda *a: model_configs())
    monkeypatch.setattr(
        tool, "digest", lambda p: "fixturehash" if str(p) == str(tmp_path / "fixture") else hashlib.sha256(
            __import__('pathlib').Path(p).read_bytes()).hexdigest())
    # Tensor payload checking is separately exercised by real CollectionWriter/
    # Reader test above; this test isolates external invocation/device linkage.
    monkeypatch.setattr(tool, "check_rank_payload", lambda p, pay, worker: dict(rank=worker["rank"]))
    pp, ep = tmp_path / "planned.json", tmp_path / "execution.json"
    pp.write_text(json.dumps(planned))
    for damage in (None, "parentpid", "starttime", "timeout", "wrongcard", "missingrank", "nonce", "config", "peerpid") + (("shutdown", "mode", "state") if external_only else ()):
        p, e = copy.deepcopy(parent), copy.deepcopy(record)
        if damage == "shutdown": p["engine_shutdown_complete"] = False
        elif damage == "mode": p["payload_validation_mode"] = "CLAIM_PRODUCER_PASS"
        elif damage == "state": p["state"] = "ALL_RANK_SCOPED_CONTROLLED_PASS"
        elif damage == "parentpid": p["pid"] = 999
        elif damage == "starttime": p["process_start_ticks"] = "old"
        elif damage == "timeout": e["execution"]["timeout"] = True
        elif damage == "wrongcard": e["per_rank_device_association"][1]["physical_id"] = 15
        elif damage == "missingrank": p["rpc_results"].pop()
        elif damage == "nonce": p["payload"]["nonce"] = "d" * 32
        elif damage == "config": p["kwargs"]["additional_config"]["draft_window_size"] = 1024
        elif damage == "peerpid": p["workers"][1]["pid"] = 999
        (output / "parent-execution.json").write_text(json.dumps(p))
        ep.write_text(json.dumps(e))
        result = tool.check_external(pp, ep, allow_external_only=external_only)
        assert (result["status"] == "PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC") is (damage is None), result


def test_target_pair_requires_both_complete_independent_arms_and_each_rank(tmp_path, monkeypatch):
    from tools import p7x_graph_repair25_rank_numeric as tool
    from tools import p7x_graph_repair6 as comparison
    plans = []
    parents = []
    for arm, nonce in (("OFF", "a" * 32), ("ON", "d" * 32)):
        output = tmp_path / arm
        output.mkdir()
        argv = [
            "python", "/candidate/tools/p7x_graph_repair25_rank_numeric.py", "run", "--admission", "/admission",
            "--expected-sha", "b" * 40, "--rpc-nonce", nonce, "--output",
            str(output), "--fixture", "/fixture", "--fixture-plan", "/fixture-plan", "--arm", arm
        ]
        plan = tmp_path / (arm + "-planned.json")
        plan.write_text(json.dumps(dict(argv=argv, source_sha="b" * 40, source_tree="c" * 40)))
        plans.append(plan)
        parent = dict(
            payload=dict(world_size=2, run_id="same-campaign", nonce=nonce, model_configs={}),
            workers=[dict(rank=r, runtime_versions={"python": "HOST-TEST"}, loaded_native_hashes=[]) for r in (0, 1)])
        (output / "parent-execution.json").write_text(json.dumps(parent))
        parents.append(parent)
    external = dict(status="PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC", samples_per_rank=12, ranks=2)
    monkeypatch.setattr(tool, "check_external", lambda *a: copy.deepcopy(external))
    mode = {"bad": False}
    monkeypatch.setattr(
        comparison, "compare",
        lambda *a, **kw: dict(status="NUMERIC_MISMATCH" if mode["bad"] else "SAMPLE_COMPLETE",
                             complete_pairs=12, execution=["EXECUTED_SCOPED_NOT_GATE_CLOSURE"]*2,
                             numerical_scope="CONTROLLED_FULL_TARGET", campaign="REQUIRES_EXTERNAL_EXECUTION_JOIN",
                             pairs=[dict(status="PASS",errors=[]) for _ in range(12)]))
    result = tool.join_target_arms(plans[0], "off-execution", plans[1], "on-execution", tmp_path / "joined.json")
    assert result["status"] == "PASS_SCOPED_TP2_COMPLETE_TARGET_12_PAIRS_PER_RANK", result
    for damage in ("prefix", "external_failed", "source", "same_nonce", "campaign", "native", "pair_failed"):
        left, right = copy.deepcopy(parents[0]), copy.deepcopy(parents[1])
        plan_right = json.loads(plans[1].read_text())
        old_sha = plan_right["source_sha"]
        if damage == "prefix": external["samples_per_rank"] = 3
        elif damage == "external_failed": external["status"] = "INVALID_EVIDENCE"
        elif damage == "source": plan_right["source_sha"] = "e" * 40
        elif damage == "same_nonce": right["payload"]["nonce"] = left["payload"]["nonce"]
        elif damage == "campaign": right["payload"]["run_id"] = "different-campaign"
        elif damage == "native": right["workers"][1]["loaded_native_hashes"] = [dict(path="other.so", sha256="other")]
        else: mode["bad"] = True
        (tmp_path / "ON/parent-execution.json").write_text(json.dumps(right))
        plans[1].write_text(json.dumps(plan_right))
        result = tool.join_target_arms(plans[0], "off-execution", plans[1], "on-execution", tmp_path / "joined.json")
        assert result["status"] != "PASS_SCOPED_TP2_COMPLETE_TARGET_12_PAIRS_PER_RANK", (damage, result)
        external.update(status="PASS_SCOPED_ALL_RANK_SERIAL_DIAGNOSTIC", samples_per_rank=12)
        plan_right["source_sha"] = old_sha
        plans[1].write_text(json.dumps(plan_right))
        mode["bad"] = False


@pytest.mark.parametrize("damage", [None,"old_alias","count","bool_count","partial","failed_pair","errors","uncommitted_arm","scope","campaign","missing"])
def test_actual_c99_complete_comparator_result_has_exact_status_contract(damage):
    from pathlib import Path
    from tools.p7x_graph_repair25_rank_numeric import validate_complete_target_comparison
    path=Path(__file__).with_name("data")/"repair25_tp16_sample_complete_C99.json"
    original=json.loads(path.read_text())
    assert original["producer_commit"] == "a54dda748cd5a66144189674bbcbb77e15f745c1"
    value=copy.deepcopy(original["comparison"])
    if damage == "old_alias": value["status"]="PASS"
    elif damage == "count": value["complete_pairs"]=11
    elif damage == "bool_count": value["complete_pairs"]=True
    elif damage == "partial": value["pairs"].pop()
    elif damage == "failed_pair": value["pairs"][-1]["status"]="FAIL"
    elif damage == "errors": value["pairs"][-1]["errors"]=["KV differs"]
    elif damage == "uncommitted_arm": value["execution"][-1]="IN_PROGRESS"
    elif damage == "scope": value["numerical_scope"]="OUTPUT_HASH_ONLY"
    elif damage == "campaign": value["campaign"]="INCOMPLETE_COVERAGE"
    elif damage == "missing": del value["complete_pairs"]
    if damage is None:
        validate_complete_target_comparison(value)
    else:
        with pytest.raises((ValueError,KeyError)):
            validate_complete_target_comparison(value)


@pytest.mark.parametrize("damage", [None,"unknown","failed","pid","starttime","nonce","worker_unknown","rank_type","missing"])
def test_collection_for_normal_shutdown_is_not_numerical_acceptance(tmp_path,damage):
    from tools.p7x_graph_repair25_rank_numeric import collected_rank_identity,digest
    path=tmp_path/"rank-execution.json"
    worker=dict(rank=0,pid=123,process_start_ticks="77")
    payload=dict(nonce="a"*32,source_sha="b"*40)
    document=dict(state="COMPLETED",graph_submission_uncertain=False,payload=payload,rank=0,
                  identity=dict(process_id=123),worker_start_ticks="77",worker=dict(submission_uncertain=False))
    if damage == "unknown":document["graph_submission_uncertain"]=True
    elif damage == "failed":document["state"]="FAILED"
    elif damage == "pid":document["identity"]["process_id"]=124
    elif damage == "starttime":document["worker_start_ticks"]="old"
    elif damage == "worker_unknown":document["worker"]["submission_uncertain"]=True
    elif damage == "rank_type":document["rank"]=False
    elif damage == "missing":del document["graph_submission_uncertain"]
    path.write_text(json.dumps(document))
    response=dict(path=str(path),sha256=digest(path),pid=123,nonce="a"*32)
    if damage == "nonce":response["nonce"]="c"*32
    if damage is None:
        result=collected_rank_identity(path,response,worker,payload)
        assert result["status"] == "COLLECTED_NOT_NUMERICALLY_ACCEPTED"
        assert result["payload_validation"] == "EXTERNAL_PENDING"
    else:
        with pytest.raises((ValueError,KeyError)):collected_rank_identity(path,response,worker,payload)
