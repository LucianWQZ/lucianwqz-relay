# SPDX-License-Identifier: Apache-2.0
"""Continuing-prefill uses its declared baseline; decode still requires Graph."""

from types import SimpleNamespace

import pytest
from vllm.config.compilation import CUDAGraphMode

from tests.ut.spec_decode.test_draft_window_eager import _harness
from tests.ut.spec_decode.test_graph_repair5_review import actual_candidates
from vllm_ascend.worker.v2.spec_decode.dflash.aclgraph import DFlashAclGraphManager


@pytest.mark.parametrize("width", [7, 8])
@pytest.mark.parametrize("active", [1, 3])
def test_actual_pinned_dispatch_does_not_replay_window_graph_without_prefill_generation(width, active):
    baseline = actual_candidates(width, [7, 14, 28, 32])
    manager = DFlashAclGraphManager.__new__(DFlashAclGraphManager)
    manager.__dict__.update(baseline.__dict__)
    manager.speculator = SimpleNamespace(_draft_window_prefill_bypass_active=True)
    assert baseline.dispatch(active, active * width, width, 0).cg_mode == CUDAGraphMode.FULL
    desc = manager.dispatch(active, active * width, width, 0)
    assert desc.cg_mode == CUDAGraphMode.NONE
    assert (desc.num_reqs, desc.num_tokens) == (active, active * width)
    manager.speculator._draft_window_prefill_bypass_active = False
    # Decode still uses actual registered captures, including active3/padded4.
    assert manager.dispatch(active, active * width, width, 0) == baseline.dispatch(active, active * width, width, 0)


@pytest.mark.parametrize("owner", [None, SimpleNamespace(), SimpleNamespace(_draft_window_prefill_bypass_active=False)])
def test_default_off_and_ordinary_dispatch_unchanged(owner):
    baseline = actual_candidates(7, [7, 14, 28, 32])
    manager = DFlashAclGraphManager.__new__(DFlashAclGraphManager)
    manager.__dict__.update(baseline.__dict__)
    manager.speculator = owner
    assert manager.dispatch(1, 7, 7, 0) == baseline.dispatch(1, 7, 7, 0)


@pytest.mark.parametrize("dummy,profile,continuing", [(False, False, True), (True, False, False), (False, True, False)])
def test_scope_flag_only_for_actual_continuing_prefill_and_clears_on_exception(monkeypatch, dummy, profile, continuing):
    import vllm_ascend.worker.v2.spec_decode.draft_window_eager as module

    owner, batch = _harness(query_width=7)
    monkeypatch.setattr(module, "_requires_prefill_baseline_bypass", lambda batch: True)
    with (
        pytest.raises(RuntimeError, match="host sentinel"),
        owner._draft_window_proposal_scope(batch, dummy_run=dummy, is_profile=profile),
    ):
        assert owner._draft_window_prefill_bypass_active is continuing
        assert owner._draft_window_proposal_context is None
        assert owner._draft_window_live_inputs is None
        raise RuntimeError("host sentinel")
    assert owner._draft_window_prefill_bypass_active is False
    assert owner._draft_window_bypass_active is False
