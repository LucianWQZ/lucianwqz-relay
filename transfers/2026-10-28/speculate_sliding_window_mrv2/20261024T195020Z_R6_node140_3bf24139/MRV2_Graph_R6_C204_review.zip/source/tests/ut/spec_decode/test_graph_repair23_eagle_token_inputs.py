# SPDX-License-Identifier: Apache-2.0
"""Regression for the real pinned first-pass token pointer contract."""
import ast
import inspect
import textwrap
from types import SimpleNamespace

import torch


def test_pinned_request_state_token_fields_have_different_precise_dtypes():
    from vllm.v1.worker.gpu.states import RequestState
    tree = ast.parse(textwrap.dedent(inspect.getsource(RequestState.__init__)))
    found = {}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign) or not isinstance(
                node.value, ast.Call):
            continue
        for target in node.targets:
            if isinstance(target, ast.Attribute) and target.attr in (
                    "last_sampled_tokens", "next_prefill_tokens"):
                found[target.attr] = next(
                    ast.unparse(arg.value) for arg in node.value.keywords
                    if arg.arg == "dtype")
    assert found == dict(last_sampled_tokens="torch.int64",
                         next_prefill_tokens="torch.int32")


def test_actual_controlled_propose_passes_exact_prefill_dtype_without_changing_last_sampled(
        monkeypatch):
    from tools import p7x_graph_repair23_eagle_target as module
    from tools.p7x_graph_repair6_submission import SubmissionState
    calls = []

    def propose(*args):
        # Independent pinned RequestState and Triton branch contract: only
        # next_prefill was wrongly constructed as int64 in the old producer.
        assert args[5].dtype == args[6].dtype == torch.int32
        assert args[7].dtype == torch.int64
        assert args[8].dtype == torch.int32
        assert args[10].dtype == torch.int64
        calls.append("propose")
        return torch.full((1, 3), 17, dtype=torch.int64)

    root = {}
    spec = SimpleNamespace(
        max_num_reqs=4,
        propose=propose,
        update_stream=SimpleNamespace(
            synchronize=lambda: calls.append("update drain")))
    owner = object.__new__(module.EagleControlledTarget)
    owner.runner = SimpleNamespace(
        speculator=spec,
        device=torch.device("cpu"),
        model_state=SimpleNamespace(attn_metadata=root))
    owner.cases, owner.numeric_probe = module.case_plan(), None
    owner.arm = "OFF"
    owner.inventory = dict(target_layers=["target"])
    owner.submission, owner.poisoned = SubmissionState(), False
    owner.probe = SimpleNamespace(max_bytes=1, snapshot=lambda *args: {})
    monkeypatch.setattr(module, "outside_digest", lambda *args: {})
    monkeypatch.setattr(
        torch.npu, "current_stream", lambda: SimpleNamespace(
            synchronize=lambda: calls.append("current drain")))
    record = dict(generation=0, checkpoint={})
    owner._execute_draft_after_target(
        record=record,
        batch=SimpleNamespace(num_reqs=1),
        hidden=torch.zeros((4, 2)),
        inputs={},
        access=lambda: {},
        slots={"target/K": torch.zeros(4, dtype=torch.int64)},
        blocks={})
    assert calls == ["propose", "update drain", "current drain"]
    assert not owner.submission.pending and not owner.poisoned
