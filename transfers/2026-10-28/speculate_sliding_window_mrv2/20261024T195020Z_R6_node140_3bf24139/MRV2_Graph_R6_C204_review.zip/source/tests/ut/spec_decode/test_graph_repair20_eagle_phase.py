# SPDX-License-Identifier: Apache-2.0
"""Completed consumer evidence survives a later first-sample failure."""
from types import SimpleNamespace

import pytest
import torch

from tools.p7x_graph_repair6_storage import CollectionReader, CollectionWriter
from tools.p7x_graph_repair6_submission import SubmissionState
from tools.p7x_graph_repair20_eagle_phase import export_completed_phase, tensor_layout


def test_all_completed_ar_consumers_survive_later_comparison_failure(tmp_path):
    kv = torch.arange(12, dtype=torch.bfloat16).reshape(3, 2, 2)
    states = {
        name:
        SimpleNamespace(
            before=dict(inputs=dict(input_ids=torch.tensor([1], dtype=torch.int32)), kv={"K": kv.clone()}),
            after={"K": kv.clone() + i},
            indices=torch.tensor([0, 1, 2], dtype=torch.int64),
            capture_sources=(kv, ),
            legacy_capture_pool_outputs=(kv.clone() + 20,),
        )
        for i, name in enumerate(("AR1", "AR2"))
    }
    writer = CollectionWriter(tmp_path / "phases.json", dict(scope="CPU_ONLY_NOT_DEVICE"))
    submission = SubmissionState()
    submission.submit("COMPLETED_GRAPH_POSTSTATE_SNAPSHOT_PENDING")
    submission.complete("COMPLETED_GRAPH_POSTSTATE_SNAPSHOT_COMPLETE")
    export_completed_phase(
        writer,
        identity=dict(epoch=7, group="mixed", first=False),
        states=states,
        identities=("AR1", "AR2"),
        identity_records=[dict(step=1), dict(step=2)],
        outputs={
            "AR1": (kv.clone(), ),
            "AR2": (kv.clone() + 1, )
        },
        caches={"K": kv},
        final={"K": kv.clone() + 1},
        selected=[0, 1, 2],
        context=dict(actual_slots=[0, -1]),
        submission=submission,
    )
    # A subsequent strict numeric mismatch must not prevent AR2 persistence.
    with pytest.raises(ValueError, match="first consumer mismatch"):
        raise ValueError("first consumer mismatch")
    writer.close("EXECUTION_FAILED")
    record = CollectionReader(tmp_path / "phases.json").record(0)
    assert len(record["consumers"]) == 2
    assert torch.equal(record["consumers"][1]["post_kv"]["K"], kv + 1)
    assert torch.equal(record["merged_actual_kv"]["K"], kv + 1)
    assert record["selected_physical_blocks"] == [0, 1, 2]
    assert record["completion"]["pending"] is False
    assert torch.equal(record['consumers'][1]['legacy_capture_pool_outputs'][0], kv + 20)
    assert record['consumers'][1]['output_layouts']['owned'][0]['shape'] == list(kv.shape)


def test_pending_submission_rejected_before_any_evidence_write(tmp_path):
    writer = CollectionWriter(tmp_path / "phases.json", dict(scope="CPU_ONLY_NOT_DEVICE"))
    submission = SubmissionState()
    submission.submit("GRAPH_REPLAY_UPDATE_PENDING")
    with pytest.raises(ValueError, match="completed Graph"):
        export_completed_phase(writer,
                               identity={},
                               states={},
                               identities=(),
                               identity_records=[],
                               outputs={},
                               caches={},
                               final={},
                               selected=[],
                               context={},
                               submission=submission)
    assert CollectionReader(tmp_path / "phases.json").samples == []


def test_layout_keeps_storage_owner_and_view_offset():
    owner = torch.arange(12, dtype=torch.int32).reshape(3, 4)
    view = owner[1:]
    layout = tensor_layout(view)
    assert layout["storage_data_ptr"] == owner.untyped_storage().data_ptr()
    assert layout["data_ptr"] == view.data_ptr()
    assert layout["storage_offset"] == 4
    assert layout["stride"] == [4, 1]
    assert layout["npu_format"] == "NOT_APPLICABLE_CPU"
