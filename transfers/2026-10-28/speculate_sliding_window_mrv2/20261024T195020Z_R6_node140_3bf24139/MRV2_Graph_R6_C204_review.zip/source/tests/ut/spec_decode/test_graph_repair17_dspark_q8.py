# SPDX-License-Identifier: Apache-2.0
"""Q8 is an explicit independent fixture; native services mocked in Host UT."""
import copy
import hashlib
import json
from pathlib import Path

import pytest
import torch

from tests.ut.spec_decode.test_graph_repair6_numeric_pipeline import produce, joined
from tools.p7x_graph_repair5_target import case_plan
from tools.p7x_graph_repair6 import joint
from tools.p7x_graph_repair6_storage import CollectionReader
from tools.p7x_graph_repair6_numeric_check import validate_sample
from tools.p7x_graph_repair12_contract import method_for_profile
from tools.p7x_graph_repair17_dspark_q8 import PROFILE, validate_model_view, prepare_cases


def test_actual_python_capture_to_reference_storage_and_full_q8_joint(monkeypatch, tmp_path):
    path, contract, snapshot = produce(monkeypatch, tmp_path, profile=PROFILE)
    result = joint(path, *joined(path, contract, snapshot), "numeric")
    assert result["status"] == "PASS_DIAGNOSTIC_CONTINUOUS_REFERENCE", result
    assert result["aba"] == "PASS_SCOPED"
    reader = CollectionReader(path)
    assert len(reader.samples) == 14
    record = reader.record(10)
    assert record["descriptor"] == record["target_descriptor"] == [4, 32]
    assert record["inputs"]["query_start_loc"].tolist() == [0, 8, 16, 24, 24]
    assert record["sampling_state"]["sample_indices"].tolist() == [r * 8 + i for r in range(3) for i in range(1, 8)]
    assert record["sampling_state"]["sample_idx_mapping"].dtype == torch.int32
    assert method_for_profile("target4").sample_from_anchor is True
    for damage in ("anchor", "offset", "dtype"):
        bad, header = copy.deepcopy(record), copy.deepcopy(reader.header)
        if damage == "anchor": header["provenance"]["method_contract"]["sample_from_anchor"] = True
        if damage == "offset": bad["sampling_state"]["sample_indices"][0] = 0
        if damage == "dtype": bad["inputs"]["input_ids"] = bad["inputs"]["input_ids"].long()
        with pytest.raises(ValueError):
            validate_sample(bad, header, case_plan(PROFILE)[10])
    assert case_plan(PROFILE)[-2]["ends"] == [1016] and case_plan(PROFILE)[-1]["ends"] == [1144]


def model_fixture(tmp_path):
    source = tmp_path / "original.json"
    source.write_text(json.dumps(dict(architectures=["Qwen3DSparkModel"], hidden_size=2)))
    weight = tmp_path / "frozen.safetensors"
    weight.write_bytes(b"host-fixture-not-real-weights")
    model = tmp_path / "model"
    model.mkdir()
    (model / "model.safetensors").symlink_to(weight)
    config = model / "config.json"
    config.write_text(json.dumps(dict(architectures=["Qwen3DSparkModel"], hidden_size=2, sample_from_anchor=False)))
    return dict(schema="r5-dspark-noanchor-q8-fixture-v1",
                method_contract=method_for_profile(PROFILE).document(),
                draft_model=str(model),
                source_config=str(source),
                source_config_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                weight_source=str(weight),
                files=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in (config, weight)])


def test_named_plan_reaches_real_cli_without_changing_original_q7_case(tmp_path):
    from tools.p7x_graph_repair2 import parse_args, build_llm_kwargs
    document = model_fixture(tmp_path)
    (tmp_path / "dspark-k7-noanchor-q8-fixture.json").write_text(json.dumps(document))
    cases = dict(CONFIG=dict(argv=["old-config"], dependencies=[], validation_commands=[]))
    for name in ("NUMERIC_SENTINEL", "NUMERIC_TARGET4", "TARGET4_OFF"):
        argv = [
            "python", "p7x_graph_repair2.py", "run", "--case", "B", "--case-id", name, "--run-id", "host-r",
            "--attempt", "1", "--expected-sha", "a" * 40, "--output",
            str(tmp_path / name)
        ]
        argv += ["--target-model", "host-target", "--vllm-repo", str(tmp_path / "pinned-vllm")]
        cases[name] = dict(argv=argv,
                           launch_argv=["python", "launcher", "--", *argv],
                           acceptance_identity=dict(case_id=name),
                           validation_commands=[],
                           dependencies=[])
    original = copy.deepcopy(cases)
    proof = prepare_cases(cases, tmp_path, tmp_path, tmp_path, "python", "a" * 40, "b" * 40, [])
    assert proof["sha256"] == hashlib.sha256(proof["content"]).hexdigest()
    assert cases["NUMERIC_TARGET4"] == original["NUMERIC_TARGET4"]
    for name in ("DSPARK_Q8_SENTINEL", "NUMERIC_DSPARK_Q8", "DSPARK_Q8_OFF"):
        case = cases[name]
        argv = case["argv"]
        args = parse_args(argv[argv.index("run"):])
        config = build_llm_kwargs(args)
        assert args.case_id == name and args.repair5_capture_profile == PROFILE
        assert config["speculative_config"]["method"] == "dspark"
        assert config["speculative_config"]["num_speculative_tokens"] == 7
        assert config["compilation_config"]["cudagraph_capture_sizes"] == [8, 16, 32]
        assert case["launch_argv"][case["launch_argv"].index("--") + 1:] == argv


@pytest.mark.parametrize("damage", [None, "extra_change", "anchor", "retarget", "extra_file", "source_changed"])
def test_owned_sampling_config_never_mutates_original_or_accepts_retargeted_weights(tmp_path, damage):
    doc = model_fixture(tmp_path)
    directory = Path(doc["draft_model"])
    config = directory / "config.json"
    data = json.loads(config.read_text())
    if damage == "extra_change": data["hidden_size"] = 3
    if damage == "anchor": data["sample_from_anchor"] = True
    if damage in ("extra_change", "anchor"): config.write_text(json.dumps(data))
    if damage == "retarget":
        (directory / "model.safetensors").unlink()
        (directory / "model.safetensors").symlink_to(doc["source_config"])
    if damage == "extra_file": (directory / "undeclared.py").write_text("pass")
    if damage == "source_changed": Path(doc["source_config"]).write_text("{}")
    if damage:
        with pytest.raises(ValueError):
            validate_model_view(doc)
    else:
        validate_model_view(doc)
        assert "sample_from_anchor" not in json.loads(Path(doc["source_config"]).read_text())


def test_q8_life_and_fault_plans_keep_q8_geometry_and_exact_points(tmp_path):
    document = model_fixture(tmp_path)
    (tmp_path / "dspark-k7-noanchor-q8-fixture.json").write_text(json.dumps(document))
    (tmp_path / "requests").mkdir()
    requests = tmp_path / "requests/dspark-q8-lifecycle.json"
    requests.write_text("[]")
    cases = {"CONFIG": dict(argv=["config"], dependencies=[], validation_commands=[])}
    points = ("before_replay", "after_replay", "after_update", "after_completion")
    names = ["NUMERIC_SENTINEL", "NUMERIC_TARGET4", "TARGET4_OFF", "LIFE"]
    names += [f"{kind}_{point}" for kind in ("ABORT", "UNWIND") for point in points]
    for name in names:
        argv = ["python", "p7x_graph_repair2.py", "run", "--requests", str(tmp_path / name)]
        if name.startswith(("ABORT_", "UNWIND_")):
            kind, point = name.split("_", 1)
            argv += ["--repair5-abort-at" if kind == "ABORT" else "--repair8-unwind-at", point]
        cases[name] = dict(argv=argv,
                           launch_argv=["launcher", "--", *argv],
                           lifecycle_coverage=dict(descriptors=[]),
                           acceptance_identity=dict(case_id=name),
                           validation_commands=[dict(argv=["dedicated-checker", name])])
    prepare_cases(cases, tmp_path, tmp_path, tmp_path, "python", "a" * 40, "b" * 40, [])
    life = cases["DSPARK_Q8_LIFE"]
    assert life["lifecycle_coverage"]["descriptors"] == [[1, 8], [2, 16], [4, 32]]
    assert life["normal_request_contract"] == "dspark_k7_noanchor_q8_lifecycle_64"
    assert life["requests_sha256"] == hashlib.sha256(requests.read_bytes()).hexdigest()
    for kind in ("ABORT", "UNWIND"):
        for point in points:
            item = cases[f"{kind}_DSPARK_Q8_{point}"]
            assert item["dependencies"] == ["DSPARK_Q8_LIFE"]
            assert item["launch_argv"][2:] == item["argv"]
            assert item["argv"][item["argv"].index("--requests") + 1] == str(requests)
            assert item["method_contract"]["draft_query"] == 8
            assert item["method_contract"]["sample_from_anchor"] is False
            option = "--repair5-abort-at" if kind == "ABORT" else "--repair8-unwind-at"
            assert item["argv"][item["argv"].index(option) + 1] == point


def test_q8_life_checker_keeps_dedicated_query_token_and_completion_contracts():
    from tests.ut.spec_decode.test_graph_repair12_dflash_lifecycle import actual_structure
    from tools.p7x_graph_repair5_lifecycle import check_lifecycle
    from tools.p7x_graph_repair5_evidence import method_from_expected
    # Synthetic Host structure derived from the excerpt, never device evidence.
    document = actual_structure()
    document["excerpt_provenance"] = "HOST_DERIVED_Q8_NOT_DEVICE_EXECUTION"
    for row in document["records"]:
        row["descriptor"][1] = row["descriptor"][0] * 8
        row["token_shape"][1] = 7
        row["draft_tokens"] = [tokens[:7] for tokens in row["draft_tokens"]]
    assert check_lifecycle(document, profile=PROFILE)["status"] == "STRUCTURE_VALID_NOT_EXECUTION_ACCEPTED"
    assert check_lifecycle(document)["status"] == "INVALID_EVIDENCE"
    expected = dict(capture_profile=PROFILE, method_contract=method_for_profile(PROFILE).document())
    assert method_from_expected(expected).draft_query == 8
    expected["method_contract"]["sample_from_anchor"] = True
    with pytest.raises(ValueError):
        method_from_expected(expected)
    document["records"][0]["completion"] = "HOST_RETURN"
    assert check_lifecycle(document, profile=PROFILE)["status"] == "INVALID_EVIDENCE"


def test_q8_exact_64_token_joint_rejects_shortened_output_and_preserves_frozen16():
    from tests.ut.spec_decode.test_graph_repair5_contracts import token_joint
    from tools.p7x_graph_repair4_acceptance import audit_joint
    campaign, launcher, raw, expected = token_joint()
    requests = json.loads(raw)
    for request, output in zip(requests, campaign["outputs"]):
        request["max_tokens"] = 64
        output["token_ids"] = [[7] * 64 for _ in request["prompts"]]
    raw = json.dumps(requests).encode()
    checksum = hashlib.sha256(raw).hexdigest()
    campaign["request_manifest"] = dict(entries=requests, sha256=checksum)
    launcher["requests_sha256"] = expected["requests_sha256"] = checksum
    assert audit_joint(campaign, launcher, raw, expected)["status"] == "INVALID_EVIDENCE"
    expected["normal_request_contract"] = "dspark_k7_noanchor_q8_lifecycle_64"
    assert audit_joint(campaign, launcher, raw, expected)["status"] == "PASS"
    campaign["outputs"][0]["token_ids"][0].pop()
    assert audit_joint(campaign, launcher, raw, expected)["status"] == "FAIL"
