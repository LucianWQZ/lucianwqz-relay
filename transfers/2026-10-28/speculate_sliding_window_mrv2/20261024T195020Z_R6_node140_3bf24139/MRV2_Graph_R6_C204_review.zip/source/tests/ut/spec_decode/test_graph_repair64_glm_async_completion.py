# SPDX-License-Identifier: Apache-2.0
"""Real CPU pool transitions; fake event counters are never NPU evidence."""
import copy
import importlib.util
from pathlib import Path

import pytest

from tools.p7x_graph_repair64_glm_async_completion import CompletionAudit, serve_argv, validate_completion
from vllm_ascend.worker.v2.spec_decode.draft_window_async import DraftWindowNPUEventCompletionToken


class CPUEvent:
    def __init__(self):
        self.complete=False
        self.records=self.queries=self.waits=0

    def record(self, stream):
        assert stream=='CPU_ONLY'
        self.records+=1

    def query(self):
        self.queries+=1
        return self.complete

    def synchronize(self):
        self.waits+=1
        self.complete=True


def normal_pool(observe):
    path=Path(__file__).with_name('test_draft_window_eager.py')
    loader=importlib.util.spec_from_file_location('normal_eager_pool_fixture',path)
    module=importlib.util.module_from_spec(loader);loader.loader.exec_module(module)
    owner,batch=module._harness(async_scheduling=True)
    pool=owner._draft_window_async_pool
    events=[]
    def factory():
        event=CPUEvent();events.append(event)
        token=DraftWindowNPUEventCompletionToken(event=event)
        token.record('CPU_ONLY')
        return token
    owner._draft_window_completion_token_factory=factory
    audit=CompletionAudit(owner) if observe else None
    if audit is not None:audit.install()
    for _ in range(8):
        with owner._draft_window_proposal_scope(batch,dummy_run=False,is_profile=False):
            owner._build_draft_attn_metadata(num_reqs=batch.num_reqs,num_reqs_padded=4,
                num_tokens_padded=8,seq_lens_cpu_upper_bound=batch.seq_lens_cpu_upper_bound,step=4,causal=False)
            pool.mark_consumer_started(owner._draft_window_async_handle)
    return audit,[(e.records,e.queries,e.waits) for e in events]


def header_surrogate():
    audit,_=normal_pool(True)
    document=audit.snapshot()
    # Explicit Host-only string-header surrogate for the independent parser.
    # The actual CPU fake event must be rejected as native evidence below.
    for row in document['records']:
        if row['kind']=='TOKEN_RECORDED':row['event_class']='torch_npu.npu.streams.Event'
    sources=[dict(epoch=r['after']['epoch'],generation=r['after']['generation'],
        execution_lane=r['after']['lane'],requests=r['after']['requests'])
        for r in document['records'] if r['kind']=='MATERIALIZE_RETURN']
    return document,sources


def test_recording_calls_the_same_event_methods_and_does_not_keep_tensor_owners():
    _,plain=normal_pool(False)
    audit,observed=normal_pool(True)
    assert observed==plain
    assert sum(r[0] for r in observed)==8
    assert sum(r[1] for r in observed)>0 and sum(r[2] for r in observed)>0
    assert audit.snapshot()['retained_tensor_owners']=='NONE_BY_AUDIT'
    # A CPU test does not become a native-event PASS by using the real pool.
    document,sources=header_surrogate()
    raw=audit.snapshot()
    with pytest.raises(ValueError,match='native NPU token'):
        validate_completion(raw,sources)


def test_complete_host_header_sequence_and_real_pool_ownership_rules():
    document,sources=header_surrogate()
    result=validate_completion(document,sources)
    assert result['operations']==8 and result['completed_releases']==6
    assert result['releases_by_lane']=={0:3,1:3}
    assert result['actual_pending_query_returns']>0
    assert result['additional_event_queries']==0
    assert len(result['still_owned_operations'])==2


@pytest.mark.parametrize('damage',['false_completion','early_release','owner_cleared','wrong_epoch',
    'source_missing','source_duplicate','wrong_generation','changed_pointer','truncated',
    'wrong_event','added_device_ops','alias_lanes','missing_event','incomplete_reuse'])
def test_fake_completion_or_early_backing_reuse_is_rejected(damage):
    document,sources=header_surrogate()
    rows=document['records']
    if damage=='false_completion':
        for r in rows:
            if r['kind']=='QUERY_RETURN':r['complete']=False
    elif damage=='early_release':
        next(r for r in rows if r['kind']=='RETIRE_RETURN')['before']['state']='submitted'
    elif damage=='owner_cleared':
        next(r for r in rows if r['kind']=='QUERY_RETURN')['owner']['metadata_owned']=False
    elif damage=='wrong_epoch':
        next(r for r in rows if r['kind']=='TOKEN_RECORDED')['identity']['epoch']+=1
    elif damage=='source_missing':sources.pop()
    elif damage=='source_duplicate':sources.append(copy.deepcopy(sources[0]))
    elif damage=='wrong_generation':sources[0]['generation']+=1
    elif damage=='changed_pointer':
        next(r for r in rows if r['kind']=='SUBMIT_RETURN')['after']['headers']['device_window_exact']['pointer']+=8
    elif damage=='truncated':document['truncated']=True
    elif damage=='wrong_event':
        next(r for r in rows if r['kind']=='TOKEN_RECORDED')['event_class']='fake.Event'
    elif damage=='added_device_ops':document['added_device_operations']='EXTRA_QUERY'
    elif damage=='alias_lanes':
        # Preserve all per-operation headers while making the second lane alias.
        pointers={}
        for r in rows:
            for key in ('before','after','owner','identity'):
                h=r.get(key)
                if h is not None and h.get('headers'):
                    for name,v in h['headers'].items():
                        if name!='cpu_window_exact':
                            pointers.setdefault(name,v['pointer'])
                            v['pointer']=pointers[name]
    elif damage=='missing_event':
        document['records']=[r for r in rows if r['kind']!='TOKEN_RECORDED']
    else:
        document['records']=rows[:next(i for i,r in enumerate(rows) if r['kind']=='RELEASE_RETURN')+1]
        sources=sources[:2]
    with pytest.raises((ValueError,KeyError)):
        validate_completion(document,sources)


def test_normal_completion_cli_keeps_real_async_features_and_target_graph():
    import json
    from tools.p7x_graph_repair59_glm_service_phases import phase_serve_argv
    from tools.p7x_graph_repair64_glm_async_completion import EXTENSION
    a=serve_argv('/python',18503,'normal','E_ON',worker_provenance=True)
    baseline=phase_serve_argv('/python',18503,'normal','E_ON',worker_provenance=True)
    baseline[baseline.index('--worker-extension-cls')+1]=EXTENSION
    assert a==baseline
    assert json.loads(a[a.index('--speculative-config')+1])['enforce_eager'] is True
    assert '--enforce-eager' not in a and '--async-scheduling' in a
    assert '--enable-prefix-caching' in a and '--enable-chunked-prefill' in a
    assert json.loads(a[a.index('--additional-config')+1])['draft_window_size']==1024
