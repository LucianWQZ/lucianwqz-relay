# SPDX-License-Identifier: Apache-2.0
"""Use the pinned framework's descriptor construction and dispatch on Host.

No Graph is captured here. Device capture, metadata and outputs remain separate
acceptance requirements. Historical non-SP evidence keeps its original oracle.
"""
import copy
import json
from types import SimpleNamespace as N

import pytest
from vllm.config import CUDAGraphMode
from vllm.config.vllm import VllmConfig
from vllm.v1.worker.gpu.cudagraph_utils import CudaGraphManager

from tests.ut.spec_decode.test_graph_repair32_glm_rank import glm_evidence
from tests.ut.spec_decode.test_graph_repair39_service_identity import identity  # noqa: F401
from tests.ut.spec_decode.test_graph_repair47_glm_service import rows_from_fixture
from tests.ut.spec_decode.test_graph_repair50_glm_required_baseline import feature_rows
from tools.p7x_graph_repair32_glm_rank import (
    CAPTURE, SP_CAPTURE, SP_CAPTURE_CONTRACT, validate_glm_worker,
)
from tools.p7x_graph_repair50_glm_required_baseline import (
    required_serve_argv, validate_required_features, validate_required_workers,
)
from tools.p7x_graph_repair51_glm_joint_features import joint_serve_argv


def framework_manager(requested_sizes, query):
    config = N(parallel_config=N(tensor_parallel_size=16))
    normalized = VllmConfig.update_sizes_for_sequence_parallelism(config, requested_sizes)
    manager = object.__new__(CudaGraphManager)
    manager.compilation_config = N(cudagraph_capture_sizes=normalized,
                                   max_cudagraph_capture_size=max(normalized))
    manager.cudagraph_mode = CUDAGraphMode.FULL_DECODE_ONLY
    manager.max_num_reqs = 4
    manager.decode_query_len = query
    manager.varlen_decode = False
    manager.lora_capture_cases = [0]
    manager.vllm_config = N(speculative_config=None, cache_config=N(use_kda_recoverssm=False))
    manager._candidates = {}
    manager._capture_descs = {}
    # Enable the actual dispatch selector, without constructing device graphs.
    manager._graphs_captured = True
    manager._lora_dispatch_map = {}
    manager._init_candidates()
    return manager


def inventory(manager):
    return [dict(requests=d.num_reqs, tokens=d.num_tokens, mode=d.cg_mode.name)
            for rows in manager._capture_descs.values() for d in rows]


def test_original_profile_loses_target_three_and_four_request_graphs_under_sp():
    manager = framework_manager(CAPTURE, 9)
    for active in (1, 2):
        assert manager.dispatch(active, active * 9, 9, 0).cg_mode == CUDAGraphMode.FULL
    for active in (3, 4):
        assert manager.dispatch(active, active * 9, 9, 0).cg_mode == CUDAGraphMode.NONE


@pytest.mark.parametrize('query', [8, 9])
@pytest.mark.parametrize('active,padded', [(1, 2), (2, 2), (3, 4), (4, 4)])
def test_sp_profile_covers_all_required_active_rows_in_actual_framework(query, active, padded):
    manager = framework_manager(SP_CAPTURE, query)
    desc = manager.dispatch(active, active * query, query, 0)
    assert desc.cg_mode == CUDAGraphMode.FULL
    assert desc.num_reqs == padded and desc.num_tokens == padded * query


@pytest.mark.parametrize('builder,arm', [(required_serve_argv, 'G_OFF'), (joint_serve_argv, 'G_ON')])
def test_both_arms_request_the_same_aligned_capture_profile(builder, arm):
    argv = builder('/python', 18162, 'sp', arm, worker_provenance=True)
    capture = json.loads(argv[argv.index('--compilation-config') + 1])
    assert capture == dict(cudagraph_capture_sizes=SP_CAPTURE, cudagraph_mode='FULL_DECODE_ONLY')
    assert json.loads(argv[argv.index('--speculative-config') + 1])['num_speculative_tokens'] == 8


def sp_worker():
    worker = copy.deepcopy(glm_evidence(True)[0]['ranks'][0])
    worker['draft_graph_inventory'] = inventory(framework_manager(SP_CAPTURE, 8))
    worker['target_graph_inventory'] = inventory(framework_manager(SP_CAPTURE, 9))
    return worker


def test_sp_inventory_requires_named_contract_and_preserves_historical_strict_oracle():
    worker = sp_worker()
    validate_glm_worker(worker, 16, capture_contract=SP_CAPTURE_CONTRACT)
    with pytest.raises(ValueError, match='inventory missing'):
        validate_glm_worker(worker, 16)
    with pytest.raises(ValueError, match='unknown GLM capture contract'):
        validate_glm_worker(worker, 16, capture_contract='unapproved-alias')
    # Historical full profile still passes the unchanged default contract.
    validate_glm_worker(glm_evidence(True)[0]['ranks'][0], 16)


def test_same_sp_target_inventory_remains_valid_for_draft_eager_control():
    worker = sp_worker()
    worker['draft_graph_inventory'] = []
    validate_glm_worker(worker, 16, draft_graph=False, capture_contract=SP_CAPTURE_CONTRACT)
    with pytest.raises(ValueError, match='inventory missing'):
        validate_glm_worker(worker, 16, capture_contract=SP_CAPTURE_CONTRACT)


def test_full_required_worker_chain_uses_named_sp_inventory_contract(identity):
    source, pin, rows = rows_from_fixture(identity)
    features = feature_rows(graph_window=True)
    for row, feature in zip(rows, features):
        row['required_features'] = feature['required_features']
        for role, query in [('draft_graph_inventory', 8), ('target_graph_inventory', 9)]:
            row['rank_snapshot'][role] = inventory(framework_manager(SP_CAPTURE, query))
    result = validate_required_workers(rows, nonce='a' * 32, source=source, vllm_source=pin, arm='G_ON')
    assert len(result['workers']) == 16
    rows[7]['rank_snapshot']['target_graph_inventory'].pop()
    with pytest.raises(ValueError, match='inventory missing'):
        validate_required_workers(rows, nonce='a' * 32, source=source, vllm_source=pin, arm='G_ON')


@pytest.mark.parametrize('role', ['draft_graph_inventory', 'target_graph_inventory'])
@pytest.mark.parametrize('requests', [2, 4])
def test_sp_inventory_rejects_each_missing_serving_bucket(role, requests):
    worker = sp_worker()
    worker[role] = [row for row in worker[role] if row['requests'] != requests]
    with pytest.raises(ValueError, match='inventory missing'):
        validate_glm_worker(worker, 16, capture_contract=SP_CAPTURE_CONTRACT)


@pytest.mark.parametrize('sizes', [[16, 32], [8, 16, 32, 36], [16.0, 32, 48]])
def test_requested_or_effective_capture_drift_cannot_claim_full_features(sizes):
    rows = feature_rows()
    rows[8]['required_features']['capture_sizes'] = sizes
    with pytest.raises(ValueError, match='capture configuration'):
        validate_required_features(rows, require_execution=True)
