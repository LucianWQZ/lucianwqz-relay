# SPDX-License-Identifier: Apache-2.0
"""Named Full8 geometry and circular-oracle corruption checks; CPU only."""
import copy
import json
from types import SimpleNamespace as N

import pytest
import torch

from tools import p7x_graph_repair74_swa_reference as shared
from tools import p7x_graph_repair77_full8_reference as tool
from tools.p7x_graph_repair6_storage import CollectionReader, CollectionWriter


def sample(active=3):
    padded = 4 if active == 3 else 2
    exact = [1537, 1153, 387][:active] + [0]*(padded-active)
    table = torch.zeros((padded, 32), dtype=torch.int32)
    counts = []
    slots = torch.full((padded*8,), -1, dtype=torch.int32)
    positions = torch.zeros(padded*8, dtype=torch.int64)
    for row, length in enumerate(exact[:active]):
        count = (length+127)//128
        counts.append(count)
        table[row, :count] = torch.arange(1+16*row, 1+16*row+count, dtype=torch.int32)
        pos = torch.arange(length-8, length, dtype=torch.int64)
        positions[row*8:(row+1)*8] = pos
        slots[row*8:(row+1)*8] = table[row].index_select(0, pos//128)*128 + pos%128
    window, lengths, starts = shared.project_full(table, exact, active, padded, 9, window=1024)
    query = torch.tensor([min(i,active)*8 for i in range(padded+1)], dtype=torch.int32)
    actual, reference, caches = {}, {}, {}
    names = [f'draft{i}' for i in range(8)]
    selected = sorted({0} | {v for row,c in enumerate(counts) for v in table[row,:c].tolist()}
                      | {int(v)//128 for v in slots if v >= 0})
    allowed = sorted(int(v) for v in slots if v >= 0)
    for i, name in enumerate(names):
        actual[name] = dict(gid=3, table=window.clone(), exact=list(lengths), slot=slots.clone(), causal=False,
                            positions=positions.clone(), query_start=query.clone(),
                            cumulative_query=[(i+1)*8 for i in range(padded)])
        reference[name] = {k: copy.deepcopy(v) for k,v in actual[name].items()
                           if k not in ('positions','query_start','cumulative_query')}
        for part in (0,1):
            before = torch.zeros((len(selected),128,1,128), dtype=torch.bfloat16)
            after = before.clone()
            for slot in allowed:
                after[selected.index(slot//128), slot%128].fill_(1)
            caches[f'{i}/{part}'] = dict(selected=selected.copy(), slots=allowed.copy(), layers=[f'{name}/{part}'],
                allocation=dict(shape=[64,128,1,128], stride=[16384,128,128,1], storage_offset=0,
                                data_ptr=1_000_000_000+(2*i+part)*10_000_000, dtype='torch.bfloat16', npu_format=2),
                before=before, restored=before.clone(), graph=after, reference=after.clone())
    inputs = dict(input_ids=torch.full((padded*8,),100,dtype=torch.int64), positions=positions,
                  query_start_loc=query)
    return dict(identity=dict(rank=0,generation=17,epoch=8,actual=active,padded=padded,index=0),
        status='CAPTURED_COMPLETE',profile=tool.PROFILE,full_gid=3,native_gids=[],canonical={3:table},
        block_counts={3:counts},full_exact=exact,window_starts=starts,inputs=inputs,
        requests=[f'fixed{i}' for i in range(active)],row_phases=['pure_decode']*active,
        phase_inputs=dict(computed=[0]*active,scheduled=[8]*active,prefill=[0]*active,declared=[False]*active),
        after_inputs=copy.deepcopy(inputs),graph_hidden=torch.zeros((padded*8,2048),dtype=torch.bfloat16),
        reference_hidden=torch.zeros((padded*8,2048),dtype=torch.bfloat16),actual_metadata=actual,
        reference_metadata=reference,caches=caches,
        reference_call='REAL_DFLASH_RUN_MODEL_CUDAGRAPH_NONE_AFTER_EXACT_PRESTATE_RESTORE')


def test_named_profile_and_actual_configuration_keep_full8_different_from_swa6():
    identity = tool.identity()
    assert json.loads(json.dumps(identity)) == identity
    kwargs = tool.build_kwargs(4, window_on_review=True)
    assert kwargs['additional_config']['draft_window_size'] == 1024
    assert kwargs['additional_config']['draft_window_graph_numeric_diagnostic'] is True
    assert kwargs['speculative_config']['num_speculative_tokens'] == 7
    assert kwargs['max_model_len'] == 4096
    assert 'Full8ReferenceWorker' in kwargs['worker_extension_cls']
    with pytest.raises(ValueError):
        tool.build_kwargs(4)


def test_named_failure_discriminator_does_not_borrow_swa_quota_or_acceptance():
    info = tool.identity(True)
    assert info['profile'] == shared.FULL8_FAILURE_PROFILE and info['quota'] == {'1': 1}
    assert tool.Full8ReplayReference.owned_profile_name == shared.FULL8_FAILURE_PROFILE
    assert tool.Full8ReplayReference.owned_quota_entries == ((1, 1),)
    assert tool.build_kwargs(4, window_on_review=True, owned_failure_probe=True)['additional_config'][
        'draft_window_graph_numeric_owned_output'] is True
    raw = sample(1)
    raw['profile'] = shared.FULL8_FAILURE_PROFILE
    with pytest.raises(KeyError):
        shared.validate_sample(raw)  # No invented successful discriminator payload.


@pytest.mark.parametrize('damage', [None, 'gate', 'no_numeric', 'no_review', 'dp', 'tp', 'native_flag', 'mixed_layers'])
def test_owned_dense_factory_keeps_explicit_gate_topology_and_actual_layer_guards(monkeypatch, damage):
    import vllm_ascend.ascend_config as module
    from tests.ut.spec_decode.test_draft_window_graph_tp_review import config

    monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH', '1')
    monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE', '0')
    monkeypatch.setattr(module.SparseKVOffloadConfig, 'from_additional_config', lambda *a: None)
    monkeypatch.setattr(module.KVPPConfig, 'from_vllm_config', lambda *a: module.KVPPConfig())
    monkeypatch.setattr(module.AscendConfig, 'derive_and_validate', lambda *a: None)
    monkeypatch.setattr(module.FinegrainedTPConfig, '_validate_preconditions', lambda *a: None)
    monkeypatch.setattr(module.XliteGraphConfig, '_validate_preconditions', lambda *a: None)
    vc = config(tp=4)
    vc.parallel_config.data_parallel_size = 1
    vc.speculative_config.method = 'dflash'
    hf = N(layer_types=['full_attention']*8, use_sliding_window=False)
    vc.speculative_config.draft_model_config = N(hf_config=hf)
    vc.additional_config.update(refresh=True, draft_window_graph_numeric_diagnostic=True,
                                draft_window_graph_numeric_owned_output=True)
    if damage == 'gate': monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH', '0')
    elif damage == 'no_numeric': vc.additional_config['draft_window_graph_numeric_diagnostic'] = False
    elif damage == 'no_review': vc.additional_config['draft_window_graph_replicated_tp_review'] = False
    elif damage == 'dp': vc.parallel_config.data_parallel_size = 2
    elif damage == 'tp':
        vc.parallel_config.tensor_parallel_size = 2
        vc.speculative_config.draft_parallel_config.tensor_parallel_size = 2
    elif damage == 'native_flag': hf.use_sliding_window = True
    elif damage == 'mixed_layers': hf.layer_types[0] = 'sliding_attention'
    if damage is None:
        assert module.init_ascend_config(vc).draft_window_graph_numeric_owned_output is True
    else:
        with pytest.raises(ValueError): module.init_ascend_config(vc)


def test_graph_target_prefill_enum_selects_a_different_real_eager_kv_branch():
    from vllm_ascend.attention.attention_v1 import AscendAttentionBackendImpl, AscendAttentionState
    impl = AscendAttentionBackendImpl.__new__(AscendAttentionBackendImpl)
    impl.key_cache = torch.zeros(16,128,1,128)
    impl.value_cache = torch.ones_like(impl.key_cache)
    impl.use_bnsd_kv_cache = False
    impl.attn_type = 'decoder'
    query_k = torch.full((8,1,128), 2.)
    query_v = torch.full_like(query_k, 3.)
    metadata = N(attn_state=AscendAttentionState.PrefillNoCache, actual_seq_lengths_q=[8],
                 block_tables=torch.arange(9,dtype=torch.int32).reshape(1,9), seq_lens_list=[1033])
    legacy = impl._get_fia_params(query_k, query_v, metadata)
    metadata.attn_state = None
    cached = impl._get_fia_params(query_k, query_v, metadata)
    assert legacy[0] is query_k and legacy[3] is None and legacy[4] == [8]
    assert cached[0].data_ptr() == impl.key_cache.data_ptr()
    assert cached[3] is metadata.block_tables and cached[4] == [1033]


def test_actual_draft_builder_receives_independent_reads_and_separate_current_upper(monkeypatch):
    from contextlib import nullcontext
    import vllm_ascend.worker.v2.attn_utils as attn
    monkeypatch.setattr(attn, 'build_attn_metadata_wrapper', nullcontext)
    seen = {}
    original_tables = [torch.full((2,32), i, dtype=torch.int32) for i in range(4)]
    projected = torch.arange(18,dtype=torch.int32).reshape(2,9)
    exact, upper = [1033, 0], torch.tensor([1040,0],dtype=torch.int32)
    live = N(identity=object(), cpu_window_upper=upper,
             window_block_table=torch.full((2,9),-999,dtype=torch.int32))
    live.validate_for = lambda ident: None
    def build(**kwargs):
        seen.update(kwargs)
        return {'draft': N(attn_state=None)}
    owner = N(device='cpu',input_batch=N(num_reqs=1),_draft_window_live_inputs=live,
              block_tables=N(input_block_tables=original_tables),_group_causal={3:False},
              _build_ascend_draft_attn_metadata=build)
    owner._update_draft_attn_metadata = lambda metadata,p: seen.update(actual_update_padded=p)
    probe = tool.Full8ReplayReference.__new__(tool.Full8ReplayReference)
    probe.owner = owner
    probe.reader_plan = lambda: N(full_gid=3)
    result = probe.build_eager_reference_metadata(N(num_reqs=2,num_tokens=16), {}, projected, exact)
    read = seen['read_inputs']
    assert torch.equal(read.block_tables[3], projected)
    assert not torch.equal(read.block_tables[3], live.window_block_table)
    assert read.seq_lens_cpu_exact.tolist() == exact
    assert read.seq_lens_cpu_upper_bound.tolist() == [1040,0]
    upper[0] = 9999
    assert read.seq_lens_cpu_upper_bound[0] == 1040
    assert result['draft'].attn_state is None and seen['actual_update_padded'] == 2


@pytest.mark.parametrize('causal', [False, {3: False}])
def test_reader_inventory_comes_from_actual_group_not_a_fake_native_plan(causal):
    spec = N(draft_attn_layer_names=[f'draft{i}' for i in range(8)], _group_causal=causal,
             _draft_window_graph_binding_provider=N(native_swa_graph_plan=None))
    probe = object.__new__(tool.Full8ReplayReference)
    probe.owner = spec
    probe.runner = N(attn_groups=[[N(kv_cache_group_id=3,layer_names=spec.draft_attn_layer_names)]])
    plan = probe.reader_plan()
    assert plan.full_gid == 3 and len(plan.full_layers) == 8 and plan.native_groups == ()
    spec._group_causal = True
    with pytest.raises(ValueError):
        probe.reader_plan()
    spec._group_causal = causal
    spec._draft_window_graph_binding_provider.native_swa_graph_plan = N()
    with pytest.raises(ValueError):
        probe.reader_plan()


@pytest.mark.parametrize('active', [1,3])
def test_raw_full8_checker_checks_all_layers_and_real_padding(active):
    verdict = shared.validate_sample(sample(active))
    assert verdict['errors'] == [] and verdict['readers'] == 8 and verdict['kv_parts'] == 16


@pytest.mark.parametrize('damage', ['hidden','nan','kv','restore','shared_wrong_write','shared_wrong_slot',
                                  'shared_wrong_read','missing_layer','swa_geometry','changed_input','fake_native',
                                  'missing_page','wrong_dtype'])
def test_full8_corruption_cannot_be_hidden_by_agreeing_producer_and_reference(damage):
    record = sample()
    cache = record['caches']['0/0']
    if damage == 'hidden': record['reference_hidden'][0,0] = 1
    elif damage == 'nan': record['graph_hidden'][0,0] = float('nan')
    elif damage == 'kv': cache['reference'][0,0,0,0] = 1
    elif damage == 'restore': cache['restored'][0,0,0,0] = 1
    elif damage == 'shared_wrong_write': cache['graph'][0,0,0,0] = cache['reference'][0,0,0,0] = 1
    elif damage == 'shared_wrong_slot':
        record['actual_metadata']['draft0']['slot'][0] += 1
        record['reference_metadata']['draft0']['slot'][0] += 1
    elif damage == 'shared_wrong_read':
        record['actual_metadata']['draft0']['table'][0,0] += 1
        record['reference_metadata']['draft0']['table'][0,0] += 1
    elif damage == 'missing_layer':
        del record['actual_metadata']['draft7']
        del record['reference_metadata']['draft7']
    elif damage == 'swa_geometry': cache['allocation']['shape'][2] = 2
    elif damage == 'changed_input': record['after_inputs']['positions'][0] += 1
    elif damage == 'fake_native': record['native_gids'] = [4]
    elif damage == 'missing_page': cache['selected'].pop()
    elif damage == 'wrong_dtype': cache['graph'] = cache['graph'].float()
    try:
        verdict = shared.validate_sample(record)
    except (ValueError,KeyError,RuntimeError):
        return
    assert verdict['errors']


def test_full8_storage_roundtrip_keeps_all_raw_parts(tmp_path):
    record = sample(1)
    writer = CollectionWriter(tmp_path/'numeric.json', dict(profile=tool.PROFILE), max_bytes=64<<20)
    writer.start(record['identity'])
    writer.finish(record)
    writer.close('COMPLETE')
    restored = CollectionReader(writer.path).record(0)
    assert shared.validate_sample(restored)['errors'] == []
    assert len(restored['caches']) == 16


def test_only_unused_padded_hidden_is_descriptive_but_active_rows_stay_exact():
    record = sample(1)
    record['reference_hidden'][8,0] = float('nan')
    verdict = shared.validate_sample(record)
    assert not verdict['errors'] and verdict['checked_hidden_rows'] == 8
    assert verdict['padded_hidden_differences'] == 1
    record['reference_hidden'][7,0] = 1
    assert shared.validate_sample(record)['errors'] == ['continuous hidden differs']


@pytest.mark.parametrize('active', [1, 3])
@pytest.mark.parametrize('damage', [None, 'absolute_as_window', 'wrong_exact', 'metadata_exact',
                                  'request', 'phase', 'epoch', 'duplicate', 'bucket',
                                  'group', 'pad_end', 'missing_start', 'unaligned_start'])
def test_generation_join_distinguishes_full_ends_from_window_exact(active, damage):
    record = sample(active)
    ident = record['identity']
    expected = next(iter(record['actual_metadata'].values()))['exact'].copy()
    generation = dict(generation=ident['generation'], epoch=ident['epoch'], actual=active,
                      padded=ident['padded'], requests=record['requests'].copy(),
                      row_phases=record['row_phases'].copy(), global_group_id=record['full_gid'],
                      window_starts=record['window_starts'].copy(), exact=expected)
    binding = dict(generation=ident['generation'], epoch=ident['epoch'],
                   global_group_id=record['full_gid'], capture_bucket=[ident['padded'], ident['padded']*8])
    worker = dict(window_generations=[generation], window_graph_bindings=[binding])
    if damage == 'absolute_as_window': generation['exact'] = record['full_exact'].copy()
    elif damage == 'wrong_exact': generation['exact'][0] += 1
    elif damage == 'metadata_exact': record['actual_metadata']['draft7']['exact'][0] += 1
    elif damage == 'request': generation['requests'][0] = 'another-request'
    elif damage == 'phase': generation['row_phases'][0] = 'another-phase'
    elif damage == 'epoch': generation['epoch'] += 1
    elif damage == 'duplicate': worker['window_graph_bindings'].append(binding.copy())
    elif damage == 'bucket': binding['capture_bucket'][1] += 8
    elif damage == 'group': binding['global_group_id'] += 1
    elif damage == 'pad_end': record['full_exact'][-1] = 1
    elif damage == 'missing_start': record['window_starts'].pop()
    elif damage == 'unaligned_start': record['window_starts'][0] += 1
    if damage is None:
        tool.validate_generation_binding(record, worker)
        assert generation['exact'] != record['full_exact']
    else:
        with pytest.raises(ValueError): tool.validate_generation_binding(record, worker)
