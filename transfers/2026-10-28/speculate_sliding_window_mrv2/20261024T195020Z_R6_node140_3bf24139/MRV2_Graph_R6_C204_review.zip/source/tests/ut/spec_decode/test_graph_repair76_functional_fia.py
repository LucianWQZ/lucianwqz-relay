# SPDX-License-Identifier: Apache-2.0
"""Standalone input/scalar/snapshot checks; no device correctness claim."""
import json

import pytest
import torch
from safetensors.torch import save_file

from tools import p7x_graph_repair76_functional_fia_repro as tool


@pytest.mark.parametrize('damage',[None,'input_hash','page','readback','scalar','output','format'])
@pytest.mark.parametrize('view',['current-window','canonical-off'])
def test_standalone_raw_checks_preserve_effective_output_and_reject_corrupt_evidence(tmp_path,damage,view):
    data=dict(query=torch.zeros((32,8,128),dtype=torch.bfloat16),
              key=torch.zeros((2,128,2,128),dtype=torch.bfloat16),
              value=torch.zeros((2,128,2,128),dtype=torch.bfloat16),
              table=torch.zeros((4,320),dtype=torch.int32),selected=torch.tensor([0,1]))
    if damage=='page':data['table'][1,0]=2
    file=tmp_path/'operands.safetensors';save_file(data,str(file))
    manifest=dict(data=dict(path=str(file),sha256=tool.digest(file)),
                  metadata=dict(kv_lengths=[32793,8201,395,0],query_lengths=[8,16,24,32]),
                  canonical_off=dict(table=data['table'].tolist(),table_dtype='torch.int32',
                    full_lengths=[36889,8201,395,0],attention_call_and_cached_view_equal_to_official_base=True))
    if damage=='input_hash':manifest['data']['sha256']='0'*64
    inp=tmp_path/'input.json';tool.write(inp,manifest)
    if damage in ('input_hash','page'):
        with pytest.raises(ValueError):tool.inputs(inp,view)
        return
    values={f'{when}_{part}':data[part].reshape(-1,128,256).clone()
            for when in ('before','after')for part in ('key','value')}
    for when in ('before','after'):
        values[when+'_query']=data['query'][:24].clone();values[when+'_table']=data['table'][:3].clone()
    values.update({f'output_{i}':torch.zeros((24,8,128),dtype=torch.bfloat16)for i in range(5)})
    if damage=='readback':values['after_value'][0,0,0]=1
    elif damage=='output':values['output_3'][14,7,35]=24
    raw=tmp_path/'raw.safetensors';save_file(values,str(raw))
    selected,_,_=tool.inputs(inp,view)
    result=dict(input=str(inp),input_manifest_sha256=tool.digest(inp),view=view,pending=False,
                raw=dict(path=str(raw),sha256=tool.digest(raw)),
                tool_sha256=tool.digest(tool.__file__),scalar=tool.parameters(selected),
                shape=[2,128,256],strides=[32768,256,1],format=2)
    if damage=='scalar':result['scalar']['next_tokens']=0
    elif damage=='format':result['format']=0
    path=tmp_path/'result.json';tool.write(path,result)
    if damage in ('readback','scalar','format'):
        with pytest.raises(ValueError):tool.check(path)
    else:
        x=tool.check(path)
        assert x['input_readbacks_exact'] is True
        assert x['status']==('NATIVE_ACTIVE_FUNCTIONAL_REPEAT_DIFFERENCE'if damage=='output'
                              else'NOT_REPRODUCED_FRESH_FUNCTIONAL_ACTIVE3_COMPACT')
