# SPDX-License-Identifier: Apache-2.0
"""Explicit eager controls and the original Graph pair remain distinct contracts."""
import copy
import json
from types import SimpleNamespace as N

import pytest

from tools import p7x_graph_repair40_glm_performance as perf
from tools.p7x_graph_repair32_glm_rank import validate_glm_worker
from tests.ut.spec_decode.test_graph_repair40_glm_performance import rank_rows, workload
from tests.ut.spec_decode.test_graph_repair32_glm_rank import glm_evidence
from tests.ut.spec_decode.test_draft_window import _attention_group, _block_tables, _p2_policy, _p2_runtime_context, _p2_vllm_config
from vllm_ascend.worker.v2.spec_decode import draft_window as source


def test_all_six_balanced_cycles_and_original_pair_identity():
    positions = {arm:[] for arm in ('G_OFF', 'G_ON', 'E_ON')}
    for repetition, order in enumerate(perf.THREE_ARM_ORDERS, 1):
        for position, arm in enumerate(order, 1):
            perf.validate_workload(arm,4096,workload(),repetition,position,False,
                                   comparison_contract=perf.THREE_ARM_CONTRACT)
            positions[arm].append(position)
            with pytest.raises(ValueError):
                perf.validate_workload(arm,4096,workload(),repetition,position%3+1,False,
                                       comparison_contract=perf.THREE_ARM_CONTRACT)
        with pytest.raises(ValueError,match='eager'):
            perf.validate_workload('E_ON',4096,workload(),repetition,1,False)
    assert all(sorted(values)==[1,1,2,2,3,3] for values in positions.values())


def test_eager_configuration_retains_target_graph_and_actual_glm_tp16(tmp_path):
    p=tmp_path/'requests.json';p.write_text(json.dumps(workload()))
    args=N(requests=p,arm='E_ON',max_model_len=4096,repetition=1,order_position=3,profile=False,
           comparison_contract=perf.THREE_ARM_CONTRACT)
    _,kwargs=perf.configuration(args)
    assert kwargs['tensor_parallel_size']==16 and kwargs['enable_expert_parallel'] is True
    assert kwargs['speculative_config']['enforce_eager'] is True
    assert kwargs['speculative_config']['num_speculative_tokens']==8
    assert kwargs['enforce_eager'] is False
    assert kwargs['compilation_config']['cudagraph_mode']=='FULL_DECODE_ONLY'
    assert kwargs['additional_config']==dict(draft_window_size=1024)


@pytest.mark.parametrize('tp',[2,4,16])
def test_existing_p7_source_already_retains_eager_rank_and_full_owner(monkeypatch,tp):
    tables=_block_tables();context=_p2_runtime_context(tensor_parallel_size=tp,tensor_parallel_rank=tp-1)
    monkeypatch.setattr(source,'build_draft_window_runtime_context',lambda *a:context)
    capability=source.build_draft_window_source_capability(policy=_p2_policy('dspark'),runtime_route='dspark',
        attn_groups=[[_attention_group()]],block_tables=tables,causal=False,vllm_config=_p2_vllm_config(configured_k=7))
    assert capability.eager_topology_fingerprint.tensor_parallel_size==tp
    assert capability.eager_topology_fingerprint.tensor_parallel_rank==tp-1
    assert capability.eager_topology_fingerprint.graph_mode=='NONE'
    assert capability.full_source.references_input_block_table(0,tables.input_block_tables[0])
    tables.input_block_tables[0]=tables.input_block_tables[0].clone()
    with pytest.raises(RuntimeError,match='replaced'):capability.full_source.validate_owner_bindings()


def test_eager_actual_geometry_still_requires_all_target_buckets():
    campaign,_,_,_=glm_evidence(True);row=copy.deepcopy(campaign['ranks'][0]);row['draft_graph_inventory']=[]
    validate_glm_worker(row,16,draft_graph=False)
    with pytest.raises(ValueError):validate_glm_worker(row,16)
    row['target_graph_inventory'].pop()
    with pytest.raises(ValueError):validate_glm_worker(row,16,draft_graph=False)


@pytest.mark.parametrize('damage',[None,'no_eager','fake_graph','provider','no_clip','skew','missing'])
def test_eager_dispatch_requires_real_forward_and_current_rank_owned_window(monkeypatch,tmp_path,damage):
    monkeypatch.setattr(perf,'validate_glm_worker',lambda row,tp,**kw:None)
    rows=rank_rows(tmp_path/'source',tmp_path/'pin','G_ON',128)
    for row in rows:
        row.update(draft_replays=0,draft_eager_forward_returns=44,window_provider_installed=False,
                   window_graph_bindings=[])
    if damage=='no_eager':rows[0]['draft_eager_forward_returns']=0
    elif damage=='fake_graph':rows[0]['draft_replays']=1
    elif damage=='provider':rows[0]['window_provider_installed']=True
    elif damage=='no_clip':rows[0]['window_generations'][0]['window_starts']=[0]
    elif damage=='skew':rows[0]['draft_eager_forward_returns']+=1
    elif damage=='missing':rows.pop()
    kwargs=dict(source=tmp_path/'source',pin=tmp_path/'pin',arm='E_ON',need_clip=True)
    if damage is None:
        result=perf.validate_ranks(rows,**kwargs)
        assert result['Draft']==0 and result['Draft_eager']==44 and result['Target']==43
    else:
        with pytest.raises(ValueError):perf.validate_ranks(rows,**kwargs)


def test_eager_forward_counter_preserves_none_and_counts_only_success(monkeypatch):
    monkeypatch.setattr(perf.GLMRankWorker,'mrv2_rank_install_dispatch_observer',lambda self:dict(rank=3))
    calls=[]
    class Spec:
        speculative_config=N(enforce_eager=True)
        def _run_model(self,value):
            calls.append(value)
            if value=='fail':raise RuntimeError('real error')
            return None
    worker=object.__new__(perf.GLMPerformanceWorker);worker.model_runner=N(speculator=Spec())
    worker.mrv2_rank_install_dispatch_observer()
    assert worker.model_runner.speculator._run_model('input') is None
    with pytest.raises(RuntimeError):worker.model_runner.speculator._run_model('fail')
    assert worker._mrv2_draft_eager_returns==1 and calls==['input','fail']
