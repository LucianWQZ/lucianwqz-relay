# SPDX-License-Identifier: Apache-2.0
"""Real Host call boundaries for idle DP Graph; no DP model acceptance."""
from types import SimpleNamespace

import pytest
import torch

from tests.ut.spec_decode.test_draft_window_graph_characterization import _characterization_owner, _runtime_context
from vllm_ascend.worker.v2.spec_decode.dflash.speculator import AscendDFlashSpeculator
from vllm_ascend.worker.v2.spec_decode.draft_window_eager import DraftWindowEagerMixin, DraftWindowProposalEpochSource
from vllm_ascend.worker.v2.spec_decode.draft_window_graph import DraftWindowGraphRoute
from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import install_parallel_draft_window_graph_characterization
from vllm_ascend.worker.v2.spec_decode.draft_window_graph_metadata import is_parallel_graph_dp_dummy


def owner():
    result, _ = _characterization_owner(method="dflash", causal=False)
    install_parallel_draft_window_graph_characterization(result, runtime_context=_runtime_context())
    result.dp_size = 2
    result._draft_window_epoch_source = DraftWindowProposalEpochSource()
    result._draft_window_async_pool = None
    result._draft_window_proposal_context = None
    result._draft_window_live_inputs = None
    result._draft_window_bypass_active = False
    result._draft_window_prefill_bypass_active = False
    result._draft_window_dp_dummy_active = False
    return result


@pytest.mark.parametrize("dp,profile,expected", [(2, False, True), (2, True, False), (1, False, False)])
def test_dummy_scope_does_not_allocate_a_generation_and_resets_flags(dp, profile, expected):
    spec = owner(); spec.dp_size = dp
    with DraftWindowEagerMixin._draft_window_proposal_scope(spec, spec.input_batch, dummy_run=True, is_profile=profile):
        assert is_parallel_graph_dp_dummy(spec) is expected
        assert spec._draft_window_live_inputs is spec._draft_window_proposal_context is None
    assert spec._draft_window_epoch_source._next_epoch == 0
    assert not spec._draft_window_bypass_active and not spec._draft_window_dp_dummy_active


def test_dummy_uses_actual_baseline_metadata_without_consuming_or_mutating_window_carriers(monkeypatch):
    import vllm_ascend.worker.v2.spec_decode.dflash.speculator as module

    spec = owner(); provider = spec._draft_window_graph_binding_provider
    identity, = provider.registered_capture_identities(route=DraftWindowGraphRoute.DFLASH)
    backing = provider.startup_capture_read_inputs(identity)
    before = backing.window_block_table.clone(), backing.device_window_exact.clone()
    baseline = {"baseline-layer": SimpleNamespace()}; calls = []; upper = object()
    def build(**kwargs):
        calls.append(kwargs)
        assert kwargs["seq_lens_cpu_upper_bound"] is upper
        return baseline
    spec._build_draft_attn_metadata = build
    spec._update_draft_attn_metadata = lambda metadata, padded: AscendDFlashSpeculator._update_draft_attn_metadata(spec, metadata, padded)
    monkeypatch.setattr(module, "consume_draft_window_graph_metadata", lambda *a, **k: pytest.fail("dummy consumed a real Window generation"))
    with DraftWindowEagerMixin._draft_window_proposal_scope(spec, spec.input_batch, dummy_run=True, is_profile=False):
        assert AscendDFlashSpeculator.build_draft_attn_metadatas(spec, 4, upper) == [baseline]
    assert len(calls) == 1 and baseline["baseline-layer"].actual_seq_lengths_q == [2, 4, 6, 8]
    assert torch.equal(before[0], backing.window_block_table) and torch.equal(before[1], backing.device_window_exact)
    assert spec._draft_window_epoch_source._next_epoch == 0


def test_dummy_exception_quarantines_before_another_scope_without_device_recovery():
    spec = owner()
    with pytest.raises(RuntimeError, match="original preparation failure"):
        with DraftWindowEagerMixin._draft_window_proposal_scope(spec, spec.input_batch, dummy_run=True, is_profile=False):
            assert is_parallel_graph_dp_dummy(spec)
            raise RuntimeError("original preparation failure")
    assert spec._draft_window_graph_submission_uncertain is True
    assert not spec._draft_window_dp_dummy_active and not spec._draft_window_bypass_active
    assert spec._draft_window_epoch_source._next_epoch == 0
    with pytest.raises(RuntimeError, match="quarantined"):
        with DraftWindowEagerMixin._draft_window_proposal_scope(spec, spec.input_batch, dummy_run=True, is_profile=False):
            pytest.fail("second body must not be entered")


def test_idle_scope_between_two_host_generations_preserves_backing_and_next_row_mapping():
    from tests.ut.spec_decode.test_draft_window_graph_carrier import _materialize
    from tests.ut.spec_decode.test_draft_window_graph_characterization import _descriptor, _install_metadata_builder, _publish_eager_generation
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import prepare_parallel_draft_window_graph_characterization

    spec = owner(); runtime = spec._draft_window_runtime_state; provider = spec._draft_window_graph_binding_provider
    _install_metadata_builder(spec)
    a = _materialize(runtime, mapping_epoch=10, start=0)
    _publish_eager_generation(spec, a)
    carrier = prepare_parallel_draft_window_graph_characterization(spec, _descriptor())
    address = carrier.read_inputs.window_block_table.data_ptr()
    table = carrier.read_inputs.window_block_table.clone()
    provider.discard_bound_carriers(); runtime.retire_generation(a.identity)
    spec._draft_window_live_inputs = spec._draft_window_proposal_context = None
    with DraftWindowEagerMixin._draft_window_proposal_scope(spec, spec.input_batch, dummy_run=True, is_profile=False):
        assert is_parallel_graph_dp_dummy(spec)
        assert torch.equal(table, carrier.read_inputs.window_block_table)
    b = _materialize(runtime, mapping_epoch=11, request_ids=("C", "A"),
                     idx_mapping=torch.tensor([4, 1], dtype=torch.int32), start=1,
                     exact=(32, 48, 0, 0), upper=(64, 64, 0, 0))
    _publish_eager_generation(spec, b)
    next_carrier = prepare_parallel_draft_window_graph_characterization(spec, _descriptor())
    assert b.identity != a.identity
    assert next_carrier.runtime_identity.generation_id == b.identity.generation_id
    assert next_carrier.runtime_identity.mapping_epoch == b.identity.mapping_epoch
    assert next_carrier.runtime_identity.ordered_request_fingerprint == b.identity.ordered_request_fingerprint
    assert next_carrier.read_inputs.window_block_table.data_ptr() == address
    assert not torch.equal(table, next_carrier.read_inputs.window_block_table)
    with pytest.raises(RuntimeError, match="stale runtime binding"):
        provider.require_runtime_identity(a.identity)


@pytest.mark.parametrize("damage", ["marker", "dp", "bypass", "prefill", "context", "inputs", "provider"])
def test_dummy_marker_never_hides_a_live_or_ambiguous_generation(damage):
    spec = owner(); spec._draft_window_dp_dummy_active = True; spec._draft_window_bypass_active = True
    if damage == "marker": spec._draft_window_dp_dummy_active = "true"
    elif damage == "dp": spec.dp_size = True
    elif damage == "bypass": spec._draft_window_bypass_active = False
    elif damage == "prefill": spec._draft_window_prefill_bypass_active = True
    elif damage == "context": spec._draft_window_proposal_context = object()
    elif damage == "inputs": spec._draft_window_live_inputs = object()
    else: spec._draft_window_graph_binding_provider = object()
    with pytest.raises(RuntimeError): is_parallel_graph_dp_dummy(spec)
