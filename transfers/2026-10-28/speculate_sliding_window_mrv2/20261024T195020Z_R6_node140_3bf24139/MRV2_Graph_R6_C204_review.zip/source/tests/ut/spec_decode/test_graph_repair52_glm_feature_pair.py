# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair21_rank import digest
from tools.p7x_graph_repair50_glm_required_baseline import PROFILE as OFF_PROFILE
from tools.p7x_graph_repair51_glm_joint_features import PROFILE as ON_PROFILE
from tools.p7x_graph_repair52_glm_feature_pair import PASS, check, streamed_tokens


SHA = "5ee6c3547a160ce944edcd2d5ffa0a4ace25f9d3"
TREE = "306071997c63c4bb63bf23f27772e0ecd82f06c1"


def test_absolute_checker_cli_does_not_shadow_standard_library_bisect():
    source = Path(__file__).resolve().parents[3]
    tool = source / "tools/p7x_graph_repair52_glm_feature_pair.py"
    process = subprocess.run([sys.executable, str(tool), "--help"], cwd=source,
                             text=True, capture_output=True, timeout=30)
    assert process.returncode == 0, process.stderr
    assert "--producer-sha" in process.stdout and "--checker-sha" in process.stdout


def dump(path: Path, value) -> Path:
    path.write_text(json.dumps(value))
    return path


def event(tokens, *, finish=None):
    return {
        "received_ns": 3,
        "data": {
            "choices": [
                {"index": 0, "token_ids": tokens, "finish_reason": finish}
            ]
        },
    }


def records():
    def result(prompt, token):
        return {
            "request": {
                "model": "arm-specific-name",
                "prompt": prompt,
                "temperature": 0,
                "seed": 0,
                "max_tokens": 3,
                "min_tokens": 3,
                "ignore_eos": True,
                "stream": True,
                "return_token_ids": True,
            },
            "events": [event([token, token + 1]), event([token + 2], finish="length")],
        }

    return {
        "status": "COMPLETE",
        "groups": [
            {"phase": "warmup", "label": "short", "results": [result([1, 2], 10)]},
            {
                "phase": "measured",
                "label": "mixed",
                "results": [result([3], 20), result([4, 5, 6], 30)],
            },
        ],
    }


def accepted_result():
    return {
        "scoped_accepted": True,
        "source_sha": SHA,
        "source_tree": TREE,
        "device_ranks_associated": 16,
        "artifact": {"status": "PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS"},
    }


def args(tmp_path: Path):
    request_path = dump(tmp_path / "requests.json", [{"label": "short"}])
    common = {
        "source_sha": SHA,
        "source_tree": TREE,
        "execution_tp": 16,
        "requests_sha256": digest(request_path),
    }
    off_campaign = dict(common, arm="G_OFF", required_feature_profile=OFF_PROFILE)
    on_campaign = dict(common, arm="G_ON", combined_feature_profile=ON_PROFILE)
    return SimpleNamespace(
        producer_sha=SHA,
        checker_sha="checker",
        requests=request_path,
        off_campaign=dump(tmp_path / "off-campaign.json", off_campaign),
        off_records=dump(tmp_path / "off-records.json", records()),
        off_result=dump(tmp_path / "off-result.json", accepted_result()),
        on_campaign=dump(tmp_path / "on-campaign.json", on_campaign),
        on_records=dump(tmp_path / "on-records.json", records()),
        on_result=dump(tmp_path / "on-result.json", accepted_result()),
        output=tmp_path / "joint.json",
    )


def test_complete_same_source_streamed_token_pair_passes(tmp_path):
    result = check(args(tmp_path))
    assert result["status"] == PASS
    assert result["pair_count"] == 3
    assert [row["output_tokens"] for row in result["pairs"]] == [3, 3, 3]
    assert result["independent_draft_numeric"] == "NOT_ASSESSED"
    assert result["normal_completion"] == "NOT_PROVEN_BY_HTTP_RETURN"


@pytest.mark.parametrize(
    "damage",
    (
        "candidate",
        "tree",
        "standalone",
        "rank",
        "status",
        "request",
        "tokens",
        "missing",
        "reorder",
        "nonterminal",
    ),
)
def test_cross_arm_damage_is_rejected(tmp_path, damage):
    value = args(tmp_path)
    if damage in ("candidate", "tree"):
        doc = json.loads(value.on_campaign.read_text())
        doc["source_sha" if damage == "candidate" else "source_tree"] = "wrong"
        dump(value.on_campaign, doc)
    elif damage in ("standalone", "rank"):
        doc = json.loads(value.on_result.read_text())
        if damage == "standalone":
            doc["scoped_accepted"] = False
        else:
            doc["device_ranks_associated"] = 15
        dump(value.on_result, doc)
    else:
        doc = json.loads(value.on_records.read_text())
        if damage == "status":
            doc["status"] = "PARTIAL"
        elif damage == "request":
            doc["groups"][1]["results"][0]["request"]["prompt"] = [99]
        elif damage == "tokens":
            doc["groups"][1]["results"][0]["events"][0]["data"]["choices"][0]["token_ids"] = [99]
        elif damage == "missing":
            doc["groups"][1]["results"].pop()
        elif damage == "reorder":
            doc["groups"].reverse()
        else:
            doc["groups"][1]["results"][0]["events"][-1]["data"]["choices"][0]["finish_reason"] = None
        dump(value.on_records, doc)
    with pytest.raises(ValueError):
        check(value)


def test_streamed_token_parser_rejects_multiple_choices():
    row = {"events": [event([1]), event([2], finish="length")]}
    row["events"][0]["data"]["choices"].append(copy.deepcopy(row["events"][0]["data"]["choices"][0]))
    with pytest.raises(ValueError):
        streamed_tokens(row)


def test_real_terminal_usage_event_is_validated_without_becoming_a_choice():
    row = records()["groups"][0]["results"][0]
    row["events"].append({"data": {"choices": [], "usage": {
        "prompt_tokens": 2, "completion_tokens": 3, "total_tokens": 5}}})
    assert streamed_tokens(row) == [10, 11, 12]


@pytest.mark.parametrize("damage", ("missing", "wrong_count", "wrong_prompt", "early", "duplicate", "extra_choice"))
def test_empty_choices_are_only_allowed_for_one_consistent_terminal_usage(damage):
    row = records()["groups"][0]["results"][0]
    usage = {"data": {"choices": [], "usage": {
        "prompt_tokens": 2, "completion_tokens": 3, "total_tokens": 5}}}
    if damage == "missing":
        usage["data"].pop("usage")
    elif damage == "wrong_count":
        usage["data"]["usage"]["completion_tokens"] = 2
    elif damage == "wrong_prompt":
        usage["data"]["usage"]["prompt_tokens"] = 3
    row["events"].append(usage)
    if damage == "early":
        row["events"].insert(0, row["events"].pop())
    elif damage == "duplicate":
        row["events"].append(copy.deepcopy(usage))
    elif damage == "extra_choice":
        row["events"].append(event([99], finish="length"))
    with pytest.raises(ValueError):
        streamed_tokens(row)
