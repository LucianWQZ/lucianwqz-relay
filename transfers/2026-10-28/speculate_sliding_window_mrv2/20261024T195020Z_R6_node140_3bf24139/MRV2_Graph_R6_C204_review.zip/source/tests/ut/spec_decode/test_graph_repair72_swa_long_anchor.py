# SPDX-License-Identifier: Apache-2.0
import copy
import hashlib
import json

import pytest

from tools import p7x_graph_repair72_qwen36_swa_long_anchor as tool
from tools.p7x_graph_repair28_rank_anchor_check import validate_payload
from tests.ut.spec_decode.test_graph_repair68_qwen36_dflash_anchor import evidence
from tests.ut.spec_decode.test_graph_repair70_qwen36_swa_anchor import worker


def long_evidence():
    c,p,e,r = evidence(False)
    c['kwargs'] = tool.build_kwargs(4)
    c['config_sha256'] = hashlib.sha256(json.dumps(c['kwargs'],sort_keys=True).encode()).hexdigest()
    prototype = worker()
    for row in c['ranks']:
        for key in ('draft_layers','draft_backend','draft_kv_geometry','qwen36_profile',
                    'window_provider_installed','heavy_observer_enabled','speculator_class'):
            row[key] = copy.deepcopy(prototype[key])
    for row, (label,lengths) in zip(c['requests'],tool.REQUESTS):
        row.update(label=label,prompts=[dict(prompt_token_ids=[100+i]*n) for i,n in enumerate(lengths)],
                   outputs=[dict(finished=True,token_ids=[17]*tool.OUTPUT_TOKENS) for _ in lengths])
    return c,p,e,r


@pytest.mark.parametrize('damage',[None,'old_short','missing_group','wrong_length','unfinished','short_output'])
def test_long_contract_does_not_accept_old_short_baseline_or_partial_outputs(damage):
    c,p,e,r = long_evidence()
    if damage == 'old_short':c['requests'] = evidence(False)[0]['requests']
    elif damage == 'missing_group':c['requests'].pop()
    elif damage == 'wrong_length':c['requests'][0]['prompts'][0]['prompt_token_ids'].pop()
    elif damage == 'unfinished':c['requests'][0]['outputs'][0]['finished'] = False
    elif damage == 'short_output':c['requests'][1]['outputs'][-1]['token_ids'].pop()
    def check():
        return validate_payload(c,p,e,r,'/source',kwargs_factory=tool.build_kwargs,
                                worker_validator=tool.validate_worker,request_plan=tool.REQUESTS,
                                output_tokens=tool.OUTPUT_TOKENS)
    if damage is None:assert check()['ranks'] == 4
    else:
        with pytest.raises(ValueError):check()


def test_long_original_graph_keeps_k_causality_and_no_extra_window():
    kw = tool.build_kwargs(4)
    assert kw['max_model_len'] == 40960 and kw['max_num_batched_tokens'] == 4096
    assert kw['speculative_config']['num_speculative_tokens'] == 7 and kw['additional_config'] == {}
    assert max(n for _,ns in tool.REQUESTS for n in ns) > 32768 > 4096
    assert not kw['speculative_config']['enforce_eager']
    with pytest.raises(ValueError):tool.build_kwargs(4,window_on_review=True)
