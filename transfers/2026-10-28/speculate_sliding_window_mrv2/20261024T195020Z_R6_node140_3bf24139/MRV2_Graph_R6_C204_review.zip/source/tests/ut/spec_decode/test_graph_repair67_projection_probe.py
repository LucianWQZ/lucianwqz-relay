# SPDX-License-Identifier: Apache-2.0
"""Host byte-slice and unknown-submission guards for the small native math probe."""
import json
import struct

import pytest
import torch

from tools.p7x_graph_repair6_submission import SubmissionState
from tools.p7x_graph_repair67_dspark_projection_probe import (
    completed_forward, export_failure_and_isolate, read_header, read_rows,
)


def checkpoint(tmp_path):
    data=torch.arange(24,dtype=torch.bfloat16).reshape(6,4)
    header=json.dumps(dict(weight=dict(dtype="BF16",shape=[6,4],data_offsets=[0,48]))).encode()
    path=tmp_path/"small.safetensors"
    path.write_bytes(struct.pack('<Q',len(header))+header+bytes(data.view(torch.uint8).numpy()))
    return path,data


def test_real_bf16_byte_rows_match_the_installed_independent_safetensors_reader(tmp_path):
    from safetensors import safe_open
    path,data=checkpoint(tmp_path);header,base,_=read_header(path)
    actual,proof=read_rows(path,header,base,"weight",2,4,[6,4])
    with safe_open(str(path),framework="pt",device="cpu") as reader:
        assert torch.equal(actual,reader.get_slice("weight")[2:4])
    assert torch.equal(actual,data[2:4]) and proof['bytes']==16


@pytest.mark.parametrize("damage",["dtype","shape","size","truncate","start","boolean"])
def test_bad_model_slice_is_rejected_before_any_native_call(tmp_path,damage):
    path,_=checkpoint(tmp_path);header,base,_=read_header(path);a,b=2,4
    if damage=="dtype":header['weight']['dtype']='F16'
    elif damage=="shape":header['weight']['shape']=[3,8]
    elif damage=="size":header['weight']['data_offsets'][1]=50
    elif damage=="truncate":path.write_bytes(path.read_bytes()[:-1])
    elif damage=="start":a=-1
    else:a=True
    with pytest.raises(ValueError):read_rows(path,header,base,'weight',a,b,[6,4])


def test_complete_native_call_has_one_existing_diagnostic_drain():
    state=SubmissionState();drains=[]
    x=torch.ones(4,3);weight=torch.ones(2,3)
    normed,out=completed_forward(x,torch.ones(3),weight,4,norm=lambda *a:(a[0],None),
        linear=torch.nn.functional.linear,drain=lambda:drains.append('complete'),state=state)
    assert torch.equal(out,torch.full((4,2),3.0)) and normed is not None
    assert drains==['complete'] and state.pending is False


@pytest.mark.parametrize("point",['norm','linear','drain'])
def test_unknown_native_failure_never_calls_a_followup_drain_or_clears_pending(point):
    state=SubmissionState();seen=[]
    def norm(*args):
        seen.append('norm')
        if point=='norm':raise RuntimeError('partial norm')
        return args[0],None
    def linear(*args):
        seen.append('linear')
        if point=='linear':raise RuntimeError('partial linear')
        return args[0]
    def drain():
        seen.append('drain');raise RuntimeError('unconfirmed completion')
    with pytest.raises(RuntimeError):completed_forward(torch.ones(4,3),None,None,4,
        norm=norm,linear=linear,drain=drain,state=state)
    assert state.pending is True
    assert seen==(['norm'] if point=='norm' else ['norm','linear'] if point=='linear' else ['norm','linear','drain'])


def test_unknown_submission_is_isolated_even_if_host_failure_export_fails(monkeypatch,tmp_path):
    import tools.p7x_graph_repair67_dspark_projection_probe as module
    state=SubmissionState();state.submit('NATIVE_PENDING');exits=[];error=RuntimeError('first native failure')
    def broken(*args):raise OSError('shared storage failed')
    monkeypatch.setattr(module,'write',broken)
    export_failure_and_isolate(tmp_path,state,error,exit_fn=exits.append)
    assert exits==[74] and state.pending and state.failure['message']=='first native failure'
    assert 'shared storage failed' in error.__notes__[0]
