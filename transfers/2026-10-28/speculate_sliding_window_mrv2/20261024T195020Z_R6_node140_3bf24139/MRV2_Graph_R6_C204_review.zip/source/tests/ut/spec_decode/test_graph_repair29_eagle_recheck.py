# SPDX-License-Identifier: Apache-2.0
import copy
import hashlib
import json

import pytest

from tools.p7x_graph_repair23_eagle_target import expected_layer_counts
from tools.p7x_graph_repair29_eagle_recheck import receipt


def configured_fixture(tmp_path, draft):
    fixture = dict(target_model=str(tmp_path / "target"), draft_model=str(tmp_path / "draft"), files=[])
    for role, config in (("target", dict(num_hidden_layers=36)), ("draft", draft)):
        p = tmp_path / role / "config.json"
        p.parent.mkdir(exist_ok=True)
        p.write_text(json.dumps(config))
        fixture["files"].append(dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    p = tmp_path / "fixture.json"
    p.write_text(json.dumps(fixture))
    return dict(argv=["run", "--fixture", str(p)], method_fixture_sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def wrapped():
    return dict(architectures=["Eagle3Speculator"],
                speculators_model_type="eagle3",
                transformer_layer_config=dict(num_hidden_layers=1))


def test_real_speculators_wrapper_uses_independently_hashed_nested_layer_config(tmp_path):
    assert expected_layer_counts(configured_fixture(tmp_path, wrapped())) == dict(target=36, draft=1)


@pytest.mark.parametrize(
    "damage",
    ["conflict", "outer_bool", "nested_bool", "missing", "wrong_method", "wrong_arch", "wrong_object", "two_layers"])
def test_nested_config_cannot_silently_override_conflict_or_relax_complete_layers(tmp_path, damage):
    draft = wrapped()
    if damage == "conflict": draft["num_hidden_layers"] = 2
    if damage == "outer_bool": draft["num_hidden_layers"] = True
    if damage == "nested_bool":
        draft["transformer_layer_config"]["num_hidden_layers"] = True
    if damage == "missing":
        draft["transformer_layer_config"].pop("num_hidden_layers")
    if damage == "wrong_method": draft["speculators_model_type"] = "other"
    if damage == "wrong_arch": draft["architectures"] = ["UnverifiedModel"]
    if damage == "wrong_object": draft["transformer_layer_config"] = []
    if damage == "two_layers":
        draft["transformer_layer_config"]["num_hidden_layers"] = 2
    with pytest.raises(ValueError):
        expected_layer_counts(configured_fixture(tmp_path, draft))


def test_reanalysis_receipt_preserves_old_producer_and_new_checker_identity():
    plan = dict(run_id="old-run",
                commit="a" * 40,
                tree="b" * 40,
                cases={"PREFIX": dict(eagle3_target=True, eagle3_target_prefix=1)})
    original = dict(source_identity=["old-run", "a" * 40, "b" * 40], status="INVALID_EVIDENCE")
    checker = dict(sha="c" * 40, tree="d" * 40)
    joined = dict(status="PASS_SCOPED_EAGLE3_TARGET_PREFIX")
    result = receipt(plan, "PREFIX", joined, checker_identity=checker, original=original)
    assert result["dependency_satisfied"] and result["producer_commit"] == "a" * 40
    assert result["checker_identity"]["sha"] == "c" * 40
    assert result["device_validation_of_checker_commit"] == "NOT_PERFORMED"
    assert result["result_scope"] == "OLD_DEVICE_ARTIFACT_NEW_CHECKER_NO_NEW_NPU"
    for status in ("PASS", "COMPLETE", "PASS_SCOPED_EAGLE3_TARGET_ARM", "INVALID_EVIDENCE", "FAIL"):
        with pytest.raises(ValueError):
            receipt(plan, "PREFIX", dict(status=status), checker_identity=checker, original=original)
    wrong = copy.deepcopy(original)
    wrong["source_identity"][0] = "different-run"
    with pytest.raises(ValueError):
        receipt(plan, "PREFIX", joined, checker_identity=checker, original=wrong)
