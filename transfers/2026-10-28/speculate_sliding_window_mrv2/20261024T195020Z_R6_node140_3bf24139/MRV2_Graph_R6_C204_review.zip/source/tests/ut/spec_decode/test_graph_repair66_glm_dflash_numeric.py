# SPDX-License-Identifier: Apache-2.0
"""Named GLM DFlash diagnostics keep the legacy DSpark and Qwen ABIs strict."""
import copy
import json
from types import SimpleNamespace

import pytest
import torch

from tools.p7x_graph_repair12_contract import method_for_profile
from tools.p7x_graph_repair5_target import case_plan
from tools.p7x_graph_repair37_glm_target import heterogeneous_resource_plan, validate_components
from tests.ut.spec_decode.test_graph_repair37_glm_target import components
from tools.p7x_graph_repair4_target import FullForwardCheckpointer, _snapshot, _snapshot_value
from tools.p7x_graph_repair5_target import sample_identity
from tools.p7x_graph_repair66_glm_dflash_numeric import (
    GLMDFlashNumericWorker, GLMDFlashRankControlledTarget, build_kwargs,
    check_external, isolation_errors, validate_fixture, validate_record,
)


PROFILE = "glm52_dflash_k15_q16_sfa"


def test_named_dflash_uses_its_own_k_query_offset_and_fourteen_boundaries():
    method = method_for_profile(PROFILE)
    assert (method.method, method.k, method.draft_query, method.target_query) == ("dflash", 15, 16, 16)
    assert method.sample_from_anchor is False and method.sample_offset == 1 and method.causal is False
    cases = case_plan(PROFILE)
    assert len(cases) == 14 and all(case["query_width"] == 16 for case in cases)
    assert cases[-2]["ends"] == [1008] and cases[-1]["ends"] == [1136]
    assert cases[10]["ends"] == [32, 1025, 1153] and cases[10]["padded"] == 4
    assert all(case["query_width"] == 9 for case in case_plan("glm52_dspark_k8_q8_sfa"))


def test_q16_heterogeneous_budget_requires_explicit_method_width():
    caches = validate_components(components())
    cases = [dict(scenario="one", ends=[32], padded=1, query_width=16)]
    budget = heterogeneous_resource_plan(cases, caches, hidden_size=6144, vocab_size=154880,
                                         metadata_bytes=1024, sample_limit=1, target_query=16)
    assert budget["component_count"] == 177 and len(budget["samples"]) == 1
    with pytest.raises(ValueError):
        heterogeneous_resource_plan(cases, caches, hidden_size=6144, vocab_size=154880, metadata_bytes=1024)


@pytest.mark.parametrize("arm", ["OFF", "ON"])
def test_actual_named_rank_factory_retains_independent_method_and_models(arm):
    from tools.p7x_graph_repair25_rank_numeric import RankNumericWorker, RankControlledTarget
    from tools.p7x_graph_repair37_glm_target import GLMControlledTarget
    from tools.p7x_graph_repair62_glm_dflash_anchor import DRAFT, GLMDFlashWorker
    assert GLMDFlashNumericWorker.mrv2_rank_snapshot is GLMDFlashWorker.mrv2_rank_snapshot
    assert GLMDFlashNumericWorker.mrv2_rank_controlled is RankNumericWorker.mrv2_rank_controlled
    assert GLMDFlashRankControlledTarget._save is RankControlledTarget._save
    assert GLMDFlashRankControlledTarget._resource_plan is GLMControlledTarget._resource_plan
    kwargs = build_kwargs(arm, 16)
    assert kwargs["speculative_config"]["method"] == "dflash"
    assert kwargs["speculative_config"]["num_speculative_tokens"] == 15
    assert kwargs["speculative_config"]["model"] == str(DRAFT)
    assert kwargs["compilation_config"]["cudagraph_capture_sizes"] == [16, 32, 64]
    assert kwargs["quantization"] == "ascend" and kwargs["enable_expert_parallel"]
    assert kwargs["additional_config"].get("draft_window_graph_numeric_diagnostic", False) == (arm == "ON")
    assert kwargs["async_scheduling"] is False and kwargs["enable_prefix_caching"] is False
    assert "causal" not in kwargs.get("hf_overrides", {})
    for tp in (True, 1, 2, 4, 8):
        with pytest.raises(ValueError): build_kwargs(arm, tp)


@pytest.mark.parametrize("damage", ["method", "k", "query", "anchor", "causal", "group"])
def test_owner_cannot_relabel_dspark_or_infer_method_from_output(damage):
    worker = GLMDFlashNumericWorker.__new__(GLMDFlashNumericWorker)
    owner = SimpleNamespace(method="dflash", requires_non_causal=True, num_speculative_steps=15,
                            num_query_per_req=16, sample_from_anchor=False, draft_kv_cache_group_id=0)
    worker._validate_method_owner(owner)
    if damage == "method": owner.method = "dspark"
    elif damage == "k": owner.num_speculative_steps = 8
    elif damage == "query": owner.num_query_per_req = 8
    elif damage == "anchor": owner.sample_from_anchor = True
    elif damage == "causal": owner.requires_non_causal = False
    else: owner.draft_kv_cache_group_id = 1
    with pytest.raises(ValueError): worker._validate_method_owner(owner)


@pytest.fixture(scope="module")
def q16_target_record():
    from tools.p7x_graph_repair37_glm_target import ORIGIN
    rows = components(); caches = validate_components(rows)
    table = torch.tensor([[1]], dtype=torch.int32)
    slots = torch.arange(144, 160, dtype=torch.int32)
    names = [row["name"] for row in rows]
    layers = {row["name"]:dict(metadata_class=row["metadata_class"], num_actual_tokens=16, block_size=128,
              seq_lens=torch.tensor([32], dtype=torch.int32), declared_exact_lengths=[32],
              cum_query_lens=torch.tensor([16], dtype=torch.int32), slot_mapping=slots, block_table=table)
              for row in rows}
    inputs = dict(input_ids=torch.full((16,),17,dtype=torch.int32), positions=torch.arange(16,32),
        query_start_loc=torch.tensor([0,16],dtype=torch.int32), seq_lens=torch.tensor([32],dtype=torch.int32),
        is_padding=torch.zeros(16,dtype=torch.bool), req_ids=["row-0"], num_reqs=1, num_tokens=16,
        descriptor=(16,1,16,16), layers=layers, target_layer_names=names)
    blocks = {key:torch.tensor([1]) for key in caches}
    writes = {key:slots for key in caches}
    reads = {key:dict(table=table,lengths=[32]) for key in caches}
    probe = FullForwardCheckpointer(fixture_id="host",max_bytes=200*1024**2,max_records=1)
    hidden = torch.ones((16,2),dtype=torch.bfloat16)
    def forward():
        for value in caches.values(): value[1,16:32].fill_(1)
        return hidden
    probe.run(forward, inputs=inputs, kv_access=lambda:caches, write_slots=writes, synchronize=lambda:None,
              origin=ORIGIN, block_ids=blocks, declared_reads=reads)
    checkpoint = probe.records[0]
    case = dict(case_plan(PROFILE)[3], step=0)
    record = dict(identity=sample_identity(case,"host"), generation=0, checkpoint=checkpoint,
        hidden=hidden.clone(), logits=torch.ones(16,4), block_owners={1:("row-0",0)},
        outside_before={"host":"same"}, outside_after={"host":"same"})
    record["target_after_draft"] = dict(root_same=True, outside=record["outside_after"], kv=checkpoint["kv_after"],
        inputs=checkpoint["inputs"], draft_slots=torch.arange(160,176,dtype=torch.int32),
        draft_positions=torch.arange(32,48), draft_query=torch.tensor([0,16],dtype=torch.int32))
    record["target_post_forward_inputs"] = checkpoint["inputs"]
    record["target_metadata_owner_after_target"] = {"host-owner":1}
    record["target_metadata_owner_after_draft"] = {"host-owner":1}
    return record


def test_q16_full_target_forward_has_all_components_and_its_own_full_write_contract(q16_target_record):
    from tools.p7x_graph_repair37_glm_target import validate_record as old_q9
    assert len(validate_record(q16_target_record)) == 99
    assert isolation_errors(q16_target_record) == []
    with pytest.raises(ValueError): old_q9(q16_target_record)


@pytest.mark.parametrize("damage", ["dtype", "slot", "position", "query", "kv_write", "outside",
                                   "hidden", "metadata_owner", "draft_slot", "draft_query"])
def test_q16_valid_collection_does_not_hide_wrong_full_slots_or_target_pollution(q16_target_record, damage):
    bad = copy.deepcopy(q16_target_record); checkpoint = bad["checkpoint"]
    if damage in ("dtype", "slot", "position", "query"):
        data = _snapshot_value(checkpoint["inputs"])
        name = data["target_layer_names"][-1]
        if damage == "dtype": data["input_ids"] = data["input_ids"].long()
        elif damage == "slot": data["layers"][name]["slot_mapping"] = torch.arange(16,dtype=torch.int32)
        elif damage == "position": data["positions"][0] += 1
        else: data["query_start_loc"][-1] = 9
        checkpoint["inputs"] = _snapshot(data,[200*1024**2])
    elif damage == "kv_write": next(iter(checkpoint["kv_after"]["tensors"].values()))["data"][0,0,0,0] = 1
    elif damage == "outside": bad["outside_after"] = {"host":"changed"}
    elif damage == "hidden": bad["hidden"][0,0] = 2
    elif damage == "metadata_owner": bad["target_metadata_owner_after_draft"] = {"host-owner":2}
    elif damage == "draft_slot": bad["target_after_draft"]["draft_slots"][0] += 1
    else: bad["target_after_draft"]["draft_query"][-1] = 8
    with pytest.raises(ValueError):
        validate_record(bad); isolation_errors(bad)


@pytest.mark.parametrize("limit", [3, None])
def test_real_python_reference_chunked_store_checker_keeps_all_declared_states(monkeypatch,tmp_path,limit):
    from tests.ut.spec_decode.test_graph_repair6_numeric_pipeline import produce, joined
    from tools.p7x_graph_repair6 import joint
    from tools.p7x_graph_repair6_storage import CollectionReader
    path, contract, snapshot = produce(monkeypatch,tmp_path,sample_limit=limit,profile=PROFILE)
    campaign, launcher, plan = joined(path,contract,snapshot)
    if limit:
        plan["numeric_samples"] = 3
        for field in ("argv", "launch_argv"): plan[field] += ["--repair6-target-prefix","3"]
        launcher["argv"] = plan["argv"]
    result = joint(path,campaign,launcher,plan,"numeric")
    assert result["status"] == ("PASS_NUMERIC_SENTINEL_ONLY" if limit else "PASS_DIAGNOSTIC_CONTINUOUS_REFERENCE"), result
    assert result["aba"] == "PASS_SCOPED"
    reader = CollectionReader(path)
    assert len(reader.samples) == (3 if limit else 14)
    if not limit:
        assert reader.record(10)["descriptor"] == [4,64]
        assert reader.record(10)["target_descriptor"] == [4,64]


def test_actual_reference_numerical_failure_is_durable_and_stops_dependent_samples(monkeypatch,tmp_path):
    from tests.ut.spec_decode.test_graph_repair6_numeric_pipeline import produce
    from tools.p7x_graph_repair6_numeric import NumericMismatch
    from tools.p7x_graph_repair6_storage import CollectionReader
    with pytest.raises(NumericMismatch): produce(monkeypatch,tmp_path,fault="numeric",profile=PROFILE)
    reader = CollectionReader(tmp_path/"numeric-reference.json")
    assert reader.execution == "EXECUTION_FAILED" and len(reader.samples) == 2
    assert reader.record(1)["status"] == "NUMERIC_MISMATCH"


def test_named_fixture_requires_source_model_and_header_not_an_old_dspark_receipt(monkeypatch,tmp_path):
    import tools.p7x_graph_repair66_glm_dflash_numeric as module
    import tools.p7x_graph_local_candidate as local
    seen=[];monkeypatch.setattr(local,"_identity",lambda *a,**k:seen.append(a))
    identity=dict(profile="named-DFlash",files=[dict(path="config",sha256="f"*64,bytes=3)])
    monkeypatch.setattr(module,"profile_identity",lambda:identity)
    fixture=tmp_path/"fixture.json";fixture.write_text(json.dumps(dict(schema="glm66-model-identity-v1",profile=PROFILE,profile_identity=identity)))
    from tools.p7x_graph_repair21_rank import digest
    plan=tmp_path/"plan.json";data=dict(schema="glm66-frozen-diagnostic-plan-v1",profile=PROFILE,
        fixture_manifest=str(fixture),fixture_sha256=digest(fixture),profile_identity=identity,
        source="/fixed-DFlash",source_sha="a"*40,source_tree="b"*40)
    plan.write_text(json.dumps(data));assert validate_fixture(plan,fixture)["source_sha"] == "a"*40
    assert seen[0][1:] == ("a"*40,"b"*40)
    for key,value in (("schema","glm38-frozen-diagnostic-plan-v1"),("profile","glm52_dspark_k8_q8_sfa"),("fixture_sha256","0"*64)):
        bad=dict(data);bad[key]=value;plan.write_text(json.dumps(bad))
        with pytest.raises(ValueError): validate_fixture(plan,fixture)


def test_external_invalid_execution_cannot_become_an_accepted_new_method(monkeypatch):
    import tools.p7x_graph_repair66_glm_dflash_numeric as module
    seen={}
    def common(*args,**kwargs):
        seen.update(kwargs);return dict(status="INVALID_EVIDENCE",error="broken all-rank association")
    monkeypatch.setattr(module,"common_check",common)
    result=check_external("/missing-plan","/missing-execution")
    assert result["status"] == "INVALID_EVIDENCE" and result["error"] == "broken all-rank association"
    assert seen["profile"] == PROFILE and seen["payload_checker"] is module.check_payload
