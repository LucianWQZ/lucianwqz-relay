# SPDX-License-Identifier: Apache-2.0
"""Counterexamples for actual timing boundaries and repeat ownership."""
import asyncio
import copy
import json
import subprocess
import sys
from types import SimpleNamespace

import pytest

from tools import p7x_graph_repair71_glm_matched_performance as tool
from tests.ut.spec_decode.test_graph_repair56_glm_joint_performance import result


def test_instances_are_balanced_without_claiming_six_independent_boots():
    positions = {arm: [] for arm in ('G_OFF', 'G_ON', 'E_ON')}
    for block, order in enumerate(tool.ORDERS, 1):
        for position, arm in enumerate(order, 1):
            tool.validate_position(arm, block, position)
            positions[arm].append(position)
    assert all(sum(v) == 4 for v in positions.values())
    assert len(tool.ORDERS) == 2 and tool.REPEATS == 3
    with pytest.raises(ValueError):tool.validate_position('G_OFF', True, 1)
    with pytest.raises(ValueError):tool.validate_position('G_ON', 1, 3)


@pytest.mark.parametrize('arm',['G_OFF','G_ON','E_ON'])
def test_32k_pilot_preserves_three_arm_semantics_and_declares_actual_capacity(arm):
    original=tool.server_argv(sys.executable,18001,'model',arm,worker_provenance=True)
    pilot=tool.server_argv(sys.executable,18001,'model',arm,worker_provenance=True,product32k_pilot=True)
    assert original[original.index('--max-model-len')+1]=='24576'
    assert pilot[pilot.index('--max-model-len')+1]=='36864'
    assert pilot[pilot.index('--worker-extension-cls')+1]==tool.PRODUCT_EXTENSION
    restored=pilot.copy()
    for key in ['--max-model-len','--worker-extension-cls']:
        restored[restored.index(key)+1]=original[original.index(key)+1]
    assert restored==original
    assert tool.Product32kPerformanceWorker._mrv2_phase_record_limit==16384


@pytest.mark.parametrize('damage',[None,'length','output','concurrency','concurrency_bool','count','token_bool'])
def test_product_pilot_cannot_silently_change_workload(damage):
    groups=[dict(label='product32k-out2000-n4-c1',max_tokens=2000,concurrency=1,
                 prompts=[dict(prompt_token_ids=[17]*32000)for _ in range(4)])]
    if damage=='length':groups[0]['prompts'][0]['prompt_token_ids'].pop()
    elif damage=='output':groups[0]['max_tokens']=512
    elif damage=='concurrency':groups[0]['concurrency']=4
    elif damage=='concurrency_bool':groups[0]['concurrency']=True
    elif damage=='count':groups[0]['prompts'].pop()
    elif damage=='token_bool':groups[0]['prompts'][0]['prompt_token_ids'][0]=True
    if damage is None:tool.validate_product32k_groups(groups)
    else:
        with pytest.raises(ValueError):tool.validate_product32k_groups(groups)


@pytest.mark.parametrize('pilot', [False, True])
def test_actual_service_start_boundary_admits_only_named_32k_profile(monkeypatch, tmp_path, pilot):
    from tools import p7x_graph_repair33_service as service
    groups = [dict(label='product32k-out2000-n4-c1', max_tokens=2000, concurrency=1,
                   prompts=[dict(prompt_token_ids=[17] * 32000) for _ in range(4)])]
    requests = tmp_path / 'requests.json'
    requests.write_text(json.dumps(groups))
    target = tmp_path / 'target'
    target.mkdir()
    (target / 'config.json').write_text(json.dumps(dict(vocab_size=32)))
    monkeypatch.setattr(service, 'validate_admission', lambda *a, **kw: dict(source_tree='test'))
    args = SimpleNamespace(admission=None, expected_sha='test', output=tmp_path / 'output',
                           requests=requests, port=18001, arm='G_OFF', worker_provenance=True)
    reached = []
    def builder(*args, **kwargs):
        reached.append(True)
        raise RuntimeError('BEFORE_SERVER_LAUNCH')
    expected = 'BEFORE_SERVER_LAUNCH' if pilot else 'bounded workload'
    with pytest.raises((ValueError, RuntimeError), match=expected):
        service.run_service(args, server_argv_builder=builder, target_model=str(target), tp=16,
                            workload_profile='glm32k_2000_n4_c1' if pilot else 'legacy24k')
    assert bool(reached) is pilot


@pytest.mark.parametrize('damage', ['token_oob', 'token_bool', 'length', 'concurrency', 'output', 'profile'])
def test_shared_service_pilot_limits_still_reject_damaged_input(damage):
    from tools.p7x_graph_repair33_service import validate_service_workload
    groups = [dict(max_tokens=2000, concurrency=1,
                   prompts=[dict(prompt_token_ids=[17] * 32000) for _ in range(4)])]
    profile = 'glm32k_2000_n4_c1'
    if damage == 'token_oob': groups[0]['prompts'][0]['prompt_token_ids'][0] = 32
    elif damage == 'token_bool': groups[0]['prompts'][0]['prompt_token_ids'][0] = True
    elif damage == 'length': groups[0]['prompts'][0]['prompt_token_ids'].pop()
    elif damage == 'concurrency': groups[0]['concurrency'] = True
    elif damage == 'output': groups[0]['max_tokens'] = 512
    elif damage == 'profile': profile = 'arbitrary_unbounded'
    with pytest.raises(ValueError): validate_service_workload(groups, 32, profile=profile)


@pytest.mark.parametrize('sequential',[True,False])
def test_client_really_serializes_c1_without_changing_default_concurrency(monkeypatch,tmp_path,sequential):
    running=maximum=0
    async def request(*args,**kwargs):
        nonlocal running,maximum
        running+=1;maximum=max(maximum,running)
        await asyncio.sleep(0)
        running-=1
        return result()
    monkeypatch.setattr(tool,'request',request)
    monkeypatch.setattr(tool,'post_json',lambda *a,**kw:dict(success=True,results=[]))
    monkeypatch.setattr(tool,'worker_identity_rpc',lambda *a:[])
    group=dict(label='one',max_tokens=256,prompts=[dict(prompt_token_ids=[17])for _ in range(3)])
    if sequential:group['concurrency']=1
    asyncio.run(tool.client('http://localhost','model',[group],tmp_path))
    assert maximum==(1 if sequential else 3)


def test_host_reset_does_not_retire_or_replace_production_owners():
    worker = object.__new__(tool.MatchedPerformanceWorker)
    worker.rank = 7
    for name in ('_mrv2_rank_replay_records', '_mrv2_rank_window_generations',
                 '_mrv2_rank_window_bindings', '_mrv2_service_phases'):
        setattr(worker, name, [object()])
    worker._mrv2_service_phases_truncated = True
    runtime = SimpleNamespace(pending_reader=object(), generation=47)
    worker.model_runner = SimpleNamespace(speculator=SimpleNamespace(_draft_window_runtime_state=runtime))
    assert worker.mrv2_glm_perf_reset()['phase_audit_reset'] == 'HOST_LISTS_ONLY'
    assert worker._mrv2_service_phases == [] and worker._mrv2_service_phases_truncated is False
    assert worker.model_runner.speculator._draft_window_runtime_state is runtime and runtime.generation == 47


def test_absolute_cli_works_outside_the_repository(tmp_path):
    result = subprocess.run([sys.executable,tool.__file__,'--help'],cwd=tmp_path,
                            capture_output=True,text=True,timeout=30)
    assert result.returncode == 0,result.stderr
    assert '--instance-block' in result.stdout and '--order-position' in result.stdout


def test_official_idle_cache_reset_and_snapshots_are_outside_all_timing(monkeypatch, tmp_path):
    events = []
    async def request(*args, **kwargs):
        events.append('request');return result(str(len(events)))
    def post(base, route, body=None):
        events.append('cache' if route == '/reset_prefix_cache' else 'counter')
        if route == '/reset_prefix_cache':return {'success': True}
        return dict(results=[dict(rank=i, pid=1000+i, reset='HOST_COUNTERS_ONLY_NO_DEVICE_OPERATION',
                                  phase_audit_reset='HOST_LISTS_ONLY') for i in range(16)])
    def snapshot(base, nonce):
        events.append('snapshot')
        return [dict(pid=1000+i, rank_snapshot=dict(rank=i)) for i in range(16)]
    monkeypatch.setattr(tool, 'request', request);monkeypatch.setattr(tool, 'post_json', post)
    monkeypatch.setattr(tool, 'worker_identity_rpc', snapshot)
    groups = [dict(label='one', max_tokens=256, prompts=[dict(prompt_token_ids=[17])])]
    rows = asyncio.run(tool.client('http://localhost', 'model', groups, tmp_path))
    assert events == ['request']+['cache', 'counter', 'request', 'snapshot']*3
    views = tool.repeat_slices(dict(status='COMPLETE', groups=rows), groups)
    assert all(view[0] is rows[0] for view in views)  # Same real warmup, not invented repetitions.
    previous = rows[0]['group_end_ns'];pids={i:1000+i for i in range(16)}
    boundaries = json.loads((tmp_path/'repeat-boundaries.json').read_text())
    for view, boundary in zip(views, boundaries):
        tool.validate_boundary(boundary, view[1:], previous, pids)
        previous = boundary['after']['end_ns']
    for damage in ('missing', 'duplicate', 'wrong_phase', 'boolean_repeat'):
        bad = copy.deepcopy(rows)
        if damage == 'missing':bad.pop()
        elif damage == 'duplicate':bad[-1] = copy.deepcopy(bad[-2])
        elif damage == 'wrong_phase':bad[-1]['phase'] = 'warmup'
        else:bad[1]['repeat'] = True
        with pytest.raises(ValueError):tool.repeat_slices(dict(status='COMPLETE', groups=bad), groups)
    for damage in ('overlap', 'reset_false', 'reset_integer', 'missing_worker', 'snapshot_overlap'):
        bad = copy.deepcopy(boundaries[0])
        if damage == 'overlap':bad['end_ns'] = rows[1]['group_end_ns']
        elif damage == 'reset_false':bad['prefix_reset']['success'] = False
        elif damage == 'reset_integer':bad['prefix_reset']['success'] = 1
        elif damage == 'missing_worker':bad['counter_reset'].pop()
        else:bad['after']['start_ns'] = rows[1]['group_start_ns']
        with pytest.raises(ValueError):tool.validate_boundary(bad, rows[1:2], rows[0]['group_end_ns'], pids)


@pytest.mark.parametrize('response',[{'success':False},{'success':1},{}])
def test_refused_cache_reset_does_not_force_reset_or_start_measured_request(monkeypatch,tmp_path,response):
    calls=[]
    async def request(*args,**kwargs):calls.append('warmup');return result()
    def post(*args,**kwargs):calls.append('reset');return response
    monkeypatch.setattr(tool,'request',request);monkeypatch.setattr(tool,'post_json',post)
    groups=[dict(label='one',max_tokens=256,prompts=[dict(prompt_token_ids=[17])])]
    with pytest.raises(ValueError):asyncio.run(tool.client('http://localhost','model',groups,tmp_path))
    assert calls==['warmup','reset']


def test_shared_prefix_groups_are_reset_separately_and_receipts_remain_outside_timing(monkeypatch,tmp_path):
    cached=set();events=[]
    async def request(*args,**kwargs):
        tokens=tuple(kwargs['prompt']);salt=kwargs['cache_salt']
        hits=sum(1 for block in range(0,len(tokens)//128*128,128) if (salt,tokens[:block+128]) in cached)
        for block in range(0,len(tokens)//128*128,128):cached.add((salt,tokens[:block+128]))
        events.append(('request',hits));return dict(result(),request=dict(cache_salt=salt))
    def post(base,route,body=None):
        if route=='/reset_prefix_cache':cached.clear();events.append(('reset',None));return {'success':True}
        return dict(results=[dict(rank=i,pid=1000+i,reset='HOST_COUNTERS_ONLY_NO_DEVICE_OPERATION',
            phase_audit_reset='HOST_LISTS_ONLY') for i in range(16)])
    monkeypatch.setattr(tool,'request',request);monkeypatch.setattr(tool,'post_json',post)
    monkeypatch.setattr(tool,'worker_identity_rpc',lambda *a:[dict(pid=1000+i,rank_snapshot=dict(rank=i)) for i in range(16)])
    groups=[dict(label=label,max_tokens=256,prompts=[dict(prompt_token_ids=[17]*n)])
            for label,n in [('short',257),('long',8193)]]
    rows=asyncio.run(tool.client('http://localhost','model',groups,tmp_path))
    calls=[v for v in events if v[0]=='request'];assert all(v[1]==0 for v in calls)
    tool.validate_request_salts(dict(groups=rows),groups)
    bad=copy.deepcopy(rows);bad[0]['results'][0]['request']['cache_salt']=bad[1]['results'][0]['request']['cache_salt']
    with pytest.raises(ValueError):tool.validate_request_salts(dict(groups=bad),groups)
    boundaries=json.loads((tmp_path/'repeat-boundaries.json').read_text())
    views=tool.repeat_slices(dict(status='COMPLETE',groups=rows),groups);pids={i:1000+i for i in range(16)}
    previous=rows[1]['group_end_ns']
    for view,boundary in zip(views,boundaries):
        tool.validate_boundary(boundary,view[2:],previous,pids);previous=boundary['after']['end_ns']
    for damage in ('missing','foreign','overlap','refused'):
        bad=copy.deepcopy(boundaries[0]);section=views[0][2:]
        if damage=='missing':bad['group_prefix_resets']=[]
        elif damage=='foreign':bad['group_prefix_resets'][0]['label']='other'
        elif damage=='overlap':bad['group_prefix_resets'][0]['end_ns']=section[1]['group_end_ns']
        else:bad['group_prefix_resets'][0]['prefix_reset']['success']=False
        with pytest.raises(ValueError):tool.validate_boundary(bad,section,rows[1]['group_end_ns'],pids)
