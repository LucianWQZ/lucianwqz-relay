# SPDX-License-Identifier: Apache-2.0
"""Real file sources and observer-off ownership, without importing any NPU code."""
import copy
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace

import pytest

from tools.p7x_graph_repair33_service import serve_argv
from tools.p7x_graph_repair39_service_identity import host_worker_identity, validate_worker_identity


@pytest.fixture
def identity(tmp_path, monkeypatch):
    source, pin = tmp_path/'ascend', tmp_path/'vllm'
    names = ['vllm', 'vllm_ascend', 'vllm_ascend.worker', 'vllm_ascend.runner', 'vllm_ascend.spec',
             'vllm_ascend.provider']
    for name in names:
        p = (pin if name == 'vllm' else source)/name.replace('.', '/')/'__init__.py'
        p.parent.mkdir(parents=True, exist_ok=True);p.write_text('# fixed source '+name+'\n')
        module = ModuleType(name);module.__file__ = str(p);monkeypatch.setitem(sys.modules, name, module)
    spec = type('Spec', (), {'__module__': 'vllm_ascend.spec'})()
    provider = type('Provider', (), {'__module__': 'vllm_ascend.provider', 'observer': None})()
    spec._draft_window_graph_binding_provider = provider
    spec._draft_window_graph_characterization = SimpleNamespace(owner=spec, provider=provider,
                                                                recorder=SimpleNamespace(enabled=False))
    runner = type('Runner', (), {'__module__': 'vllm_ascend.runner', 'speculator': spec})()
    worker = type('Worker', (), {'__module__': 'vllm_ascend.worker', 'model_runner': runner})()
    row = host_worker_identity(worker, 'a'*32)
    row['loaded_native'] = [str(source/'vllm_ascend/vllm_ascend_C.so')]
    return source, pin, row, spec


def test_host_only_actual_loaded_modules_and_safety_owner(identity):
    source, pin, row, _ = identity
    result = validate_worker_identity([row], nonce='a'*32, source=source, vllm_source=pin, arm='G_ON')
    assert result['status'].startswith('PASS_SCOPED_DIRECT_WORKER_PYTHON')
    assert result['device_execution_occurrence'] == result['normal_completion'] == 'NOT_PROVEN'
    assert row['provider_installed'] is True and row['heavy_observer_enabled'] is False


def test_method_capture_and_update_export_only_reads_existing_host_objects(identity):
    _,_,_,spec=identity
    mode=type('Mode',(),{'name':'FULL'})()
    desc=type('Descriptor',(),dict(cg_mode=mode,num_reqs=1,num_tokens=4,uniform_token_count=4))()
    spec.method='eagle3';spec.speculative_config=SimpleNamespace(num_speculative_tokens=3)
    spec.prefill_cudagraph_manager=SimpleNamespace(graphs={desc:object()})
    capture=SimpleNamespace(fingerprint=SimpleNamespace(capture_bucket=(1,4)),consumer_ordinal=0)
    spec._draft_window_graph_binding_provider._carriers={'bank':SimpleNamespace(capture_identity=capture,
        runtime_identity=SimpleNamespace(generation_id=12,mapping_epoch=4),
        backend_attribution=SimpleNamespace(update_function_path='real_source.update'))}
    runner=type('Runner',(),{'__module__':'vllm_ascend.runner','speculator':spec,
                          'cudagraph_manager':SimpleNamespace(graphs={desc:object()})})()
    worker=type('Worker',(),{'__module__':'vllm_ascend.worker','model_runner':runner})()
    row=host_worker_identity(worker,'a'*32)
    assert row['actual_method']=='eagle3' and row['actual_k']==3
    assert row['graph_inventory']['target']['graphs'][0]['num_tokens']==4
    assert row['latest_provider_bindings']==[dict(bucket=[1,4],ordinal=0,generation=12,epoch=4,
                                               update_function='real_source.update')]
    assert row['graph_state_scope']=='HOST_CAPTURE_REGISTRY_AND_UPDATE_ATTRIBUTION_NOT_EXECUTION_OCCURRENCE'


@pytest.mark.parametrize('damage', ['nonce', 'pid_bool', 'start', 'foreign_source', 'hash', 'bytes_bool',
                                   'duplicate', 'class_module', 'missing_vllm', 'observer', 'provider_bool',
                                   'no_provider', 'native', 'scope', 'wrong_arm'])
def test_corrupt_or_cross_candidate_provenance_rejected(identity, damage):
    source, pin, original, _ = identity;row = copy.deepcopy(original);arm='G_ON'
    if damage == 'nonce':row['nonce']='b'*32
    elif damage == 'pid_bool':row['pid']=True
    elif damage == 'start':row['process_start_ticks']='unknown'
    elif damage == 'foreign_source':row['modules'][1]['path']=str(pin/'vllm/__init__.py')
    elif damage == 'hash':row['modules'][0]['sha256']='0'*64
    elif damage == 'bytes_bool':row['modules'][0]['bytes']=True
    elif damage == 'duplicate':row['modules'].append(row['modules'][0])
    elif damage == 'class_module':row['runner_class']='unloaded.Runner'
    elif damage == 'missing_vllm':row['modules']=row['modules'][1:]
    elif damage == 'observer':row['heavy_observer_enabled']=True
    elif damage == 'provider_bool':row['provider_installed']=1
    elif damage == 'no_provider':row['provider_installed']=False
    elif damage == 'native':row['loaded_native']=['/old/ascend/vllm_ascend_C.so']
    elif damage == 'scope':row['scope']='DEVICE_COMPLETE'
    else:arm='E_ON'
    with pytest.raises(ValueError):validate_worker_identity([row],nonce='a'*32,source=source,vllm_source=pin,arm=arm)


def test_observer_disabled_cannot_hide_wrong_provider_owner(identity):
    _, _, _, spec = identity
    spec._draft_window_graph_characterization.provider = object()
    with pytest.raises(ValueError,match='ownership'):
        host_worker_identity(SimpleNamespace(model_runner=SimpleNamespace(speculator=spec)), 'a'*32)


@pytest.mark.parametrize('arm', ['G_OFF', 'G_ON', 'E_ON'])
def test_extension_is_explicit_and_keeps_vanilla_controls(arm):
    normal = serve_argv('/python',18140,'name',arm)
    observed = serve_argv('/python',18140,'name',arm,worker_provenance=True)
    assert '--worker-extension-cls' not in normal
    assert observed[:-2] == normal and observed[-2:] == ['--worker-extension-cls',
        'tools.p7x_graph_repair39_service_identity.ServiceWorkerIdentity']


def test_identity_query_does_not_import_device_or_tensor_libraries():
    # The collection is allowed to read files/Host objects only. No hidden
    # synchronize/query/D2H can be introduced via this helper's imports.
    import ast
    from tools import p7x_graph_repair39_service_identity as module
    tree = ast.parse(Path(module.__file__).read_text())
    imports = [n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))]
    assert not any('torch' in ast.unparse(n) or 'vllm' in ast.unparse(n) for n in imports)
    assert len([n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]) == 1


@pytest.mark.parametrize('damage', [None, 'overlap', 'pid_changed', 'nonce', 'phase', 'source_claim',
                                  'unbound_root', 'extension', 'boolean'])
def test_full_http_and_host_identity_joint_rejects_cross_invocation(identity, damage):
    from tools.p7x_graph_repair33_service import stream_summary, validate_requests
    source, pin, row, _ = identity
    groups=[dict(label='short',max_tokens=3,prompts=[dict(prompt_token_ids=[7,8])])]
    argv=serve_argv('/python',18140,'fixed-model','G_ON',worker_provenance=True)
    records=[]
    for phase,shift in [('warmup',0),('measured',100)]:
        events=[dict(received_ns=120+shift,data=dict(id=phase,model='fixed-model',choices=[dict(index=0,prompt_token_ids=[7,8],token_ids=[10,11])])),
                dict(received_ns=140+shift,data=dict(id=phase,model='fixed-model',choices=[dict(index=0,token_ids=[12])])),
                dict(received_ns=150+shift,data=dict(id=phase,model='fixed-model',choices=[],usage=dict(prompt_tokens=2,completion_tokens=3,total_tokens=5)))]
        result=dict(request=dict(model='fixed-model',prompt=[7,8],max_tokens=3,min_tokens=3,temperature=0,
                                 seed=0,ignore_eos=True,stream=True,return_token_ids=True),
                    start_ns=100+shift,end_ns=160+shift,events=events,terminal_done=True,
                    summary=stream_summary(events,start_ns=100+shift,end_ns=160+shift,
                                           expected_prompt=[7,8],expected_output=3,expected_model='fixed-model'))
        records.append(dict(phase=phase,label='short',group_start_ns=90+shift,group_end_ns=170+shift,
                            results=[result]))
    after=copy.deepcopy(row);after['nonce']='b'*32
    states=[dict(phase='BEFORE_REQUESTS',nonce='a'*32,start_ns=60,end_ns=80,results=[row]),
            dict(phase='AFTER_REQUESTS',nonce='b'*32,start_ns=280,end_ns=290,results=[after])]
    campaign=dict(status='OFFICIAL_CLI_HTTP_REQUESTS_COMPLETE_NOT_NUMERIC_OR_COMPLETION_PROOF',server_rc=0,
                  server_argv=argv,start_monotonic_ns=40,end_monotonic_ns=300,measured_requests=1,
                  worker_provenance_enabled=True,worker_provenance=states,source_root=str(source),
                  vllm_source_root=str(pin),arm='G_ON')
    roots=dict(expected_source=source,expected_vllm_source=pin)
    if damage == 'overlap':states[0]['end_ns']=120
    elif damage == 'pid_changed':after['pid']+=1
    elif damage == 'nonce':after['nonce']='c'*32
    elif damage == 'phase':states[1]['phase']='BEFORE_REQUESTS'
    elif damage == 'source_claim':campaign['source_root']=str(pin)
    elif damage == 'unbound_root':roots={}
    elif damage == 'extension':argv=argv[:-2];campaign['server_argv']=argv
    elif damage == 'boolean':campaign['worker_provenance_enabled']='false'
    def check():
        return validate_requests(campaign,dict(status='COMPLETE',groups=records),groups,
                                 expected_server_argv=argv,**roots)
    if damage is None:assert check()['status']=='PASS_SCOPED_OFFICIAL_CLI_HTTP_REQUESTS'
    else:
        with pytest.raises(ValueError):check()
