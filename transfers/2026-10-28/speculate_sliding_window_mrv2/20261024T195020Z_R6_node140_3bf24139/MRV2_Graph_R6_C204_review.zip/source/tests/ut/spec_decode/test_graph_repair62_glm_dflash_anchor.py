# SPDX-License-Identifier: Apache-2.0
"""DFlash's named contract must not inherit DSpark query/weight evidence."""
import hashlib
import json
import struct

import pytest

from tools.p7x_graph_repair28_rank_anchor_check import validate_payload
from tools.p7x_graph_repair32_glm_rank import validate_glm_worker
from tools.p7x_graph_repair62_glm_dflash_anchor import (
    AUX_LAYERS, CAPTURE, DRAFT, PROFILE, SPECULATOR, build_kwargs,
    validate_model_configs, validate_worker, weight_headers,
)
from tests.ut.spec_decode.test_graph_repair32_glm_rank import actual_configs, glm_evidence


def configs():
    target, _ = actual_configs()
    draft = dict(architectures=["DFlashDraftModel"], model_type="qwen3",
        num_hidden_layers=5, hidden_size=6144, target_hidden_size=6144,
        num_attention_heads=64, num_key_value_heads=64, head_dim=64, num_target_layers=78,
        dtype="bfloat16", vocab_size=154880, max_position_embeddings=1048576,
        layer_types=["full_attention"] * 5, use_sliding_window=False, sliding_window=None,
        dflash_config=dict(target_layer_ids=list(AUX_LAYERS), mask_token_id=154821))
    return target, draft


def evidence(review):
    campaign, planned, execution, receipt = glm_evidence(review)
    kwargs = build_kwargs(16, window_on_review=review)
    campaign.update(kwargs=kwargs,
        config_sha256=hashlib.sha256(json.dumps(kwargs, sort_keys=True).encode()).hexdigest())
    for row in campaign["ranks"]:
        row["speculator_class"] = SPECULATOR
        row["glm_profile"].update(profile=PROFILE, k=15, draft_query=16,
            sample_from_anchor=False, draft_model=str(DRAFT))
        row["dflash_method"] = dict(method="dflash", target_layer_ids=list(AUX_LAYERS),
            mask_token_id=154821, fc_weight_shape=[6144, 30720])
        for value in row["draft_kv_geometry"].values():
            value["shape"] = [64, 128, 4, 64]
        for key in ("draft_graph_inventory", "target_graph_inventory"):
            row[key] = [dict(requests=n, tokens=n * 16, mode="FULL") for n in (1, 2, 4)]
    return campaign, planned, execution, receipt


def test_fixed_dflash_contract_is_distinct_and_preserves_off_on_semantics():
    validate_model_configs(*configs())
    off, on = build_kwargs(16), build_kwargs(16, window_on_review=True)
    assert off["speculative_config"]["method"] == "dflash"
    assert off["speculative_config"]["num_speculative_tokens"] == 15
    assert off["speculative_config"]["model"] == str(DRAFT)
    assert off["compilation_config"]["cudagraph_capture_sizes"] == list(CAPTURE)
    assert off["additional_config"] == {} and on["additional_config"]["draft_window_size"] == 1024
    assert not off["speculative_config"]["enforce_eager"]
    assert not off["async_scheduling"] and not off["enable_prefix_caching"]
    for tp in (True, 1, 2, 4, 8):
        with pytest.raises(ValueError):
            build_kwargs(tp)


def test_worker_snapshot_reads_actual_method_and_fc_headers_without_device_values(monkeypatch):
    from types import SimpleNamespace as N
    from tools.p7x_graph_repair62_glm_dflash_anchor import GLMDFlashWorker
    from tools.p7x_graph_repair32_glm_rank import GLMRankWorker

    # A pure Host double exercises the real snapshot method, not a producer
    # self-reported PASS. Real model execution remains a separate device gate.
    monkeypatch.setattr(GLMRankWorker, "mrv2_rank_snapshot",
                        lambda self: dict(glm_profile=dict(profile="parent", k=15, draft_query=16)))
    spec = N(speculative_config=N(method="dflash"), parallel_drafting_token_id=154821,
        draft_model_config=N(hf_config=N(dflash_config=dict(target_layer_ids=list(AUX_LAYERS)))),
        model=N(model=N(fc=N(weight=N(shape=(6144, 30720))))))
    worker = GLMDFlashWorker()
    worker.model_runner = N(speculator=spec)
    row = worker.mrv2_rank_snapshot()
    assert row["glm_profile"] == dict(profile=PROFILE, k=15, draft_query=16)
    assert row["dflash_method"]["method"] == "dflash"
    assert row["dflash_method"]["fc_weight_shape"] == [6144, 30720]
    assert row["dflash_method"]["target_layer_ids"] == list(AUX_LAYERS)


@pytest.mark.parametrize("damage", ["method", "dtype", "aux", "fc_width", "anchor", "mask", "causal", "swa"])
def test_raw_model_contract_rejects_lookalike_or_incompatible_checkpoint(damage):
    target, draft = configs()
    if damage == "method": draft["architectures"] = ["DSparkDraftModel"]
    elif damage == "dtype": draft["dtype"] = "float8_e4m3fn"
    elif damage == "aux": draft["dflash_config"]["target_layer_ids"][-1] = 77
    elif damage == "fc_width": draft["target_hidden_size"] = 2048
    elif damage == "anchor": draft["dflash_config"]["sample_from_anchor"] = True
    elif damage == "mask": draft["dflash_config"]["mask_token_id"] = 154820
    elif damage == "causal": draft["dflash_config"]["causal"] = True
    else: draft["layer_types"][-1] = "sliding_attention"
    with pytest.raises(ValueError):
        validate_model_configs(target, draft)


@pytest.mark.parametrize("review", [False, True])
def test_allrank_legal_dflash_evidence_passes_its_own_checker_only(review):
    c, p, e, r = evidence(review)
    result = validate_payload(c, p, e, r, "/source", kwargs_factory=build_kwargs,
                              worker_validator=validate_worker)
    assert result["ranks"] == 16
    with pytest.raises(ValueError):
        validate_glm_worker(c["ranks"][0], 16)
    with pytest.raises(ValueError):
        validate_worker(glm_evidence(review)[0]["ranks"][0], 16)


@pytest.mark.parametrize("damage", ["rank", "method", "query", "sample", "model", "class", "dtype",
    "head", "missing_kv", "bucket", "target_q9", "target_owner", "indexer", "mask", "aux", "fc",
    "causal", "untyped_causal", "untyped_group", "window_group"])
def test_one_rank_or_method_contradiction_is_not_silently_normalized(damage):
    c, p, e, r = evidence(True)
    w = c["ranks"][-1]
    if damage == "rank": c["ranks"].pop()
    elif damage == "method": w["dflash_method"]["method"] = "dspark"
    elif damage == "query": w["glm_profile"]["draft_query"] = 15
    elif damage == "sample": w["glm_profile"]["sample_from_anchor"] = True
    elif damage == "model": w["glm_profile"]["draft_model"] = "/other/DFlash"
    elif damage == "class": w["speculator_class"] = SPECULATOR.replace("DFlash", "DSpark")
    elif damage == "dtype": next(iter(w["draft_kv_geometry"].values()))["dtype"] = "torch.float16"
    elif damage == "head": next(iter(w["draft_kv_geometry"].values()))["shape"][-1] = 192
    elif damage == "missing_kv": w["draft_kv_geometry"].pop(next(iter(w["draft_kv_geometry"])))
    elif damage == "bucket": w["draft_graph_inventory"].pop()
    elif damage == "target_q9": w["target_graph_inventory"][-1]["tokens"] = 36
    elif damage == "target_owner": w["glm_profile"]["target_groups"][0]["layers"].pop()
    elif damage == "indexer": w["glm_profile"]["target_groups"][1]["layers"].pop()
    elif damage == "mask": w["dflash_method"]["mask_token_id"] = 154820
    elif damage == "aux": w["dflash_method"]["target_layer_ids"][-1] = 76
    elif damage == "fc": w["dflash_method"]["fc_weight_shape"][-1] = 18432
    elif damage == "causal": w["glm_profile"]["actual_layer_causal"][-1] = True
    elif damage == "untyped_causal": w["glm_profile"]["actual_layer_causal"][-1] = 0
    elif damage == "untyped_group": w["glm_profile"]["group_causal"][0]["causal"] = 0
    else: w["window_graph_bindings"][0]["global_group_id"] = 0
    with pytest.raises(ValueError):
        validate_payload(c, p, e, r, "/source", kwargs_factory=build_kwargs, worker_validator=validate_worker)


@pytest.mark.parametrize("damage", [None, "dtype", "fc", "embed", "oversized", "truncated"])
def test_small_safetensors_header_contract_without_reading_weight_data(tmp_path, damage):
    header = {"fc.weight": dict(dtype="BF16", shape=[6144, 30720]),
              "embed_tokens.weight": dict(dtype="BF16", shape=[154880, 6144])}
    if damage == "dtype": header["fc.weight"]["dtype"] = "F8_E4M3"
    elif damage == "fc": header["fc.weight"]["shape"][-1] = 18432
    elif damage == "embed": header["embed_tokens.weight"]["shape"][0] = 151936
    raw = json.dumps(header).encode()
    length = (1 << 20) + 1 if damage == "oversized" else len(raw)
    path = tmp_path / "header-only-host-fixture.safetensors"
    path.write_bytes(struct.pack("<Q", length) + (raw[:-1] if damage == "truncated" else raw))
    if damage:
        with pytest.raises(ValueError):
            weight_headers(path)
    else:
        result = weight_headers(path)
        assert result["header_bytes"] == len(raw)
        assert result["header_sha256"] == hashlib.sha256(raw).hexdigest()
        assert result["scope"].startswith("HEADER_ONLY")
