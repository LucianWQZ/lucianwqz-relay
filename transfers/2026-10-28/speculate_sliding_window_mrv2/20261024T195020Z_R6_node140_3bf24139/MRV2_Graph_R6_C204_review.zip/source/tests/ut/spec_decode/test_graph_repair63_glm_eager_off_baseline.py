# SPDX-License-Identifier: Apache-2.0
"""The new original eager OFF baseline cannot inherit a Graph/Window PASS."""
import copy
import hashlib
import json

import pytest

from tools.p7x_graph_repair63_glm_eager_off_baseline import (
    EXTENSION, baseline_serve_argv, prefix_hits, validate_dispatch, validate_workers,
)
from tests.ut.spec_decode.test_graph_repair32_glm_rank import glm_evidence
from tests.ut.spec_decode.test_graph_repair39_service_identity import identity
from tests.ut.spec_decode.test_graph_repair50_glm_required_baseline import feature_rows
from tests.ut.spec_decode.test_graph_repair59_glm_service_phases import workers as phase_workers


def evidence(identity):
    source, pin, header, _ = identity
    extension = source / 'tools/p7x_graph_repair63_glm_eager_off_baseline.py'
    extension.parent.mkdir(parents=True)
    extension.write_text('# Host-only fixed extension identity fixture\n')
    module = 'vllm_ascend.worker.v2.spec_decode.dspark.speculator'
    path = source / (module.replace('.', '/') + '.py')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text('# Host-only DSpark class module identity fixture\n')
    class_name = module + '.AscendDSparkSpeculator'
    snapshots = glm_evidence(False)[0]['ranks']
    features, phases = feature_rows(), phase_workers('G_OFF')
    rows = []
    for i, snapshot in enumerate(snapshots):
        row = copy.deepcopy(header)
        row.update(pid=snapshot['pid'], process_start_ticks=snapshot['process_start_ticks'],
            provider_installed=False, actual_method='dspark', actual_k=8, actual_query_width=8,
            actual_sample_from_anchor=True, speculator_class=class_name,
            effective_prefix_caching=True,
            eager_off_extension=dict(path=str(extension), sha256=hashlib.sha256(extension.read_bytes()).hexdigest()))
        row['modules'].append(dict(module=module, path=str(path), bytes=path.stat().st_size,
                                   sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        snapshot.update(ascend_source=str(source/'vllm_ascend/__init__.py'),
            vllm_source=str(pin/'vllm/__init__.py'), speculator_class=class_name,
            draft_graph_inventory=[], draft_replays=0, draft_eager_forward_returns=4,
            window_provider_installed=False, heavy_observer_enabled=False,
            window_generations=[], window_graph_bindings=[],
            eager_async_pool=None, dispatch_records=[dict(role='target', mode='FULL', returned=True,
                host_start_ns=100, host_return_ns=200)])
        for phase in phases[i]['proposal_phases']:
            phase['manager_calls'] = []
        row.update(features[i])
        row.update({k:v for k,v in phases[i].items() if k != 'rank_snapshot'})
        row['rank_snapshot'] = snapshot
        rows.append(row)
    return source, pin, rows


def test_cli_changes_only_draft_execution_and_keeps_original_off_features():
    argv = baseline_serve_argv('/python', 18501, 'baseline', 'E_OFF', worker_provenance=True)
    spec = json.loads(argv[argv.index('--speculative-config')+1])
    additional = json.loads(argv[argv.index('--additional-config')+1])
    assert spec['enforce_eager'] is True and spec['method'] == 'dspark'
    assert spec['num_speculative_tokens'] == 8 and '--enforce-eager' not in argv
    assert not any(k.startswith('draft_window') for k in additional)
    assert all(additional[k] is True for k in ('enable_dsa_cp','enable_flashcomm1'))
    assert '--async-scheduling' in argv and '--enable-prefix-caching' in argv
    assert '--enable-chunked-prefill' in argv and argv[argv.index('--max-num-batched-tokens')+1] == '256'
    assert json.loads(argv[argv.index('--compilation-config')+1])['cudagraph_mode'] == 'FULL_DECODE_ONLY'
    assert argv[argv.index('--worker-extension-cls')+1] == EXTENSION
    for wrong in ('G_OFF', 'G_ON', 'E_ON'):
        with pytest.raises(ValueError):
            baseline_serve_argv('/python', 18501, 'baseline', wrong, worker_provenance=True)


def test_allrank_off_eager_surrogate_has_separate_actual_mode_checks(identity):
    source, pin, rows = evidence(identity)
    result = validate_workers(rows, nonce='a'*32, source=source, vllm_source=pin, arm='E_OFF')
    assert len(result['workers']) == 16
    actual = validate_dispatch(rows)
    assert actual['Draft_Graph'] == 0 and actual['Draft_eager_Host_returns'] == 4
    assert actual['Target_Graph_Host_calls'] == 1
    assert actual['phases']['physical_read'] == 'NOT_OBSERVED'


@pytest.mark.parametrize('damage', ['missing_rank','bool_rank','duplicate_pid','bad_source','wrong_method',
    'window','provider','pool','hidden_graph','no_eager','no_target','uncertain','wrong_extension',
    'wrong_phase','hidden_proposal_graph','cp_disabled'])
def test_wrong_mode_window_or_incomplete_baseline_cannot_be_accepted(identity, damage):
    source, pin, rows = evidence(identity)
    row = rows[-1]
    snapshot = row['rank_snapshot']
    if damage == 'missing_rank': rows.pop()
    elif damage == 'bool_rank': snapshot['rank'] = True
    elif damage == 'duplicate_pid': snapshot['pid'] = rows[0]['rank_snapshot']['pid']
    elif damage == 'bad_source': row['modules'][0]['sha256'] = '0'*64
    elif damage == 'wrong_method': row['actual_method'] = 'dflash'
    elif damage == 'window': snapshot['window_size'] = 1024
    elif damage == 'provider': snapshot['window_provider_installed'] = True
    elif damage == 'pool': snapshot['eager_async_pool'] = dict(capacity=2)
    elif damage == 'hidden_graph': snapshot['draft_graph_inventory'] = [dict(requests=2,tokens=16,mode='FULL')]
    elif damage == 'no_eager': snapshot['draft_eager_forward_returns'] = 0
    elif damage == 'no_target': snapshot['target_replays'] = 0
    elif damage == 'uncertain': snapshot['submission_uncertain'] = True
    elif damage == 'wrong_extension': row['eager_off_extension']['sha256'] = '0'*64
    elif damage == 'wrong_phase': row['proposal_phases'][-1]['batch_phase'] = 'pure_decode'
    elif damage == 'hidden_proposal_graph': row['proposal_phases'][-1]['manager_calls'] = [dict(role='draft:query')]
    else: row['required_features']['dsa_cp'] = False
    with pytest.raises((ValueError, KeyError)):
        validate_workers(rows, nonce='a'*32, source=source, vllm_source=pin, arm='E_OFF')
        validate_dispatch(rows)


def test_actual_prefix_usage_is_required_even_on_the_original_off_baseline():
    doc = dict(groups=[dict(phase='measured',label='same',results=[dict(summary=dict(
        usage=dict(prompt_tokens=8193,prompt_tokens_details=dict(cached_tokens=8064))))])])
    rows = [dict(effective_prefix_caching=True) for _ in range(16)]
    assert prefix_hits(doc, rows)[0]['cached_tokens'] == 8064
    doc['groups'][0]['results'][0]['summary']['usage']['prompt_tokens_details']['cached_tokens'] = 0
    with pytest.raises(ValueError, match='no actual'):
        prefix_hits(doc, rows)
