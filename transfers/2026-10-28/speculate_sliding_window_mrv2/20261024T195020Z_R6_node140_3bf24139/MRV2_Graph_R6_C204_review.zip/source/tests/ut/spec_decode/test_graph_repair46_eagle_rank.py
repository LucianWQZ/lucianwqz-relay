# SPDX-License-Identifier: Apache-2.0
"""Reject incomplete/cross-rank evidence; synthetic Host rows never prove NPU."""
import copy
import json
import os
from pathlib import Path
import socket
from types import SimpleNamespace

import pytest

from tools import p7x_graph_repair46_eagle_rank as tool
from tools.p7x_graph_repair13_eagle import CONTRACT


@pytest.fixture
def args(tmp_path):
    for name in ('target','draft'):
        path=tmp_path/name;path.mkdir();(path/'config.json').write_text('{"max_position_embeddings":40960}')
    fixture=tmp_path/'fixture.json'
    fixture.write_text(json.dumps(dict(schema='r5-eagle3-k3-fixture-v1',method_contract=CONTRACT,
        target_model=str(tmp_path/'target'),draft_model=str(tmp_path/'draft'))))
    receipt=tmp_path/'receipt.json';receipt.write_text('{}')
    admission=tmp_path/'admission.json';admission.write_text('{}')
    return SimpleNamespace(tp=2,arm='G_ON',fixture=fixture,fixture_sha256=tool.digest(fixture),
        expected_sha='a'*40,vllm_repo=tmp_path/'pin',output=tmp_path/'output',run_id='host-only',
        case_id='EAGLE_TP2',fixture_receipt=receipt,fixture_receipt_sha256=tool.digest(receipt),admission=admission)


@pytest.mark.parametrize('arm',['G_OFF','G_ON'])
def test_real_method_factory_keeps_target_graph_and_explicit_actual_draft_tp(args,arm):
    args.arm=arm
    _,kwargs=tool.configuration(args)
    assert kwargs['tensor_parallel_size']==2
    assert kwargs['speculative_config']['draft_tensor_parallel_size']==2
    assert kwargs['speculative_config']['num_speculative_tokens']==3
    assert kwargs['speculative_config']['enforce_eager'] is False and kwargs['enforce_eager'] is False
    assert kwargs['compilation_config']==dict(cudagraph_mode='FULL_DECODE_ONLY',cudagraph_capture_sizes=[1,2,4,8,16])
    assert kwargs['additional_config']==({} if arm=='G_OFF' else
        dict(draft_window_size=1024,draft_window_graph_replicated_tp_review=True))
    assert kwargs['worker_extension_cls']=='tools.p7x_graph_repair46_eagle_rank.EagleRankWorker'
    assert kwargs['max_model_len']==4096 and not kwargs['async_scheduling'] and not kwargs['enable_prefix_caching']


@pytest.mark.parametrize('tp,arm',[(True,'G_ON'),(1,'G_ON'),(4,'G_ON'),(16,'G_ON'),(2,'E_ON')])
def test_named_anchor_cannot_substitute_topology_or_eager(args,tp,arm):
    args.tp=tp;args.arm=arm
    with pytest.raises(ValueError):tool.configuration(args)


@pytest.mark.parametrize('arm',['G_OFF','G_ON'])
def test_designated_qwen_pair_has_its_own_model_proof_and_first_ar_capture_sizes(args,arm):
    args.qwen36_model_pair=True;args.arm=arm
    fixture,kwargs=tool.configuration(args)
    assert fixture is None and kwargs['model']==str(tool.QWEN36_TARGET)
    assert kwargs['speculative_config']['model']==str(tool.QWEN36_DRAFT)
    assert kwargs['speculative_config']['num_speculative_tokens']==3
    assert kwargs['compilation_config']['cudagraph_capture_sizes']==[1,2,4,8,16]
    identity=tool.qwen36_identity()
    assert json.loads(json.dumps(identity))==identity
    assert (identity['k'],identity['first_query'],identity['ar_query'],identity['ar_consumers'])==(3,4,1,2)
    assert kwargs['additional_config']==({} if arm=='G_OFF' else
        dict(draft_window_size=1024,draft_window_graph_replicated_tp_review=True))


@pytest.fixture
def rows(tmp_path):
    source=tmp_path/'ascend';pin=tmp_path/'pin'
    names=['vllm','vllm_ascend','tools.p7x_graph_repair46_eagle_rank',
           'vllm_ascend.worker.v2.model_runner','vllm_ascend.worker.v2.spec_decode.eagle.speculator']
    modules=[]
    for name in names:
        path=(pin if name=='vllm' else source)/(name.replace('.','/')+'.py')
        path.parent.mkdir(parents=True,exist_ok=True);path.write_text('# fixed Host source '+name)
        modules.append(dict(module=name,path=str(path),bytes=path.stat().st_size,sha256=tool.digest(path)))
    inventory={name:dict(graphs=[dict(mode='FULL',num_reqs=1,num_tokens=4 if name!='decode_cudagraph_manager' else 1)])
        for name in ['target','prefill_cudagraph_manager','decode_cudagraph_manager']}
    values=[]
    for rank in [0,1]:
        values.append(dict(rank=rank,local_rank=rank,world_size=2,tp_size=2,draft_tp_size=2,
            logical_device=rank,nspid=[str(100+rank)],pid=100+rank,process_start_ticks=str(200+rank),
            nonce='a'*32,hostname=socket.gethostname(),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
            namespace=os.readlink('/proc/self/ns/mnt'),
            worker_class='tools.p7x_graph_repair46_eagle_rank.EagleRankWorker',
            runner_class='vllm_ascend.worker.v2.model_runner.NPUModelRunner',
            speculator_class='vllm_ascend.worker.v2.spec_decode.eagle.speculator.AscendEagleSpeculator',
            actual_method='eagle3',actual_k=3,provider_installed=True,heavy_observer_enabled=False,
            submission_uncertain=False,draft_backend='vllm_ascend.attention.attention_v1.AscendAttentionBackend',
            draft_layers=['layer'],normalized_kv_heads=4,head_size=128,
            draft_kv_geometry={'layer':[dict(shape=[2,32,128,4,128],stride=[2097152,65536,512,128,1],
                dtype='torch.bfloat16',data_ptr=123+rank,storage_offset=0,device='npu:'+str(rank))]},
            modules=copy.deepcopy(modules),loaded_native=[str(source/'vllm_ascend/vllm_ascend_C.so')],
            graph_inventory=copy.deepcopy(inventory),
            topology=dict(tp_size=2,tp_rank=rank,read_semantics='replicated',graph_mode='FULL_DECODE_ONLY'),
            latest_provider_bindings=[dict(ordinal=0),dict(ordinal=1)],
            window_generations=[dict(tp_size=2,tp_rank=rank,global_group_id=0,requests=['one'],actual=1,padded=1,
                window_starts=[1024],exact=[1027],generation=1000+rank,epoch=100+rank)],
            window_graph_bindings=[dict(tp_size=2,tp_rank=rank)],
            dispatch_records=[dict(role=role,mode='FULL',returned=True) for role in
                ['target','draft:prefill_cudagraph_manager','draft:decode_cudagraph_manager']]))
    return source,pin,values


def test_explicit_rank_namespace_counters_need_not_equal_but_logical_views_must(rows):
    source,pin,values=rows
    assert tool.validate_ranks(values,arm='G_ON',nonce='a'*32,source=source,pin=pin,after=True)['ranks']==[0,1]
    values[1]['window_generations'][0]['exact']=[1026]
    with pytest.raises(ValueError,match='logical'):tool.validate_ranks(values,arm='G_ON',nonce='a'*32,source=source,pin=pin,after=True)


@pytest.mark.parametrize('damage',[None,'legacy_heads','legacy_geometry','aux','projection','norms','model','ar_bucket'])
def test_qwen3_6_loaded_rank_contract_cannot_be_replaced_by_legacy_shapes_or_config_only(rows,damage):
    source,pin,values=rows
    for row in values:
        row.update(normalized_kv_heads=1,head_size=256,draft_model=str(tool.QWEN36_DRAFT),
            qwen36_loaded_pair=dict(profile=tool.QWEN36_PROFILE,target=str(tool.QWEN36_TARGET),
                draft=str(tool.QWEN36_DRAFT),aux_layers=[3,19,35],fc_shape=[2048,6144],fc_norm_shapes=[[2048]]*3))
        header=row['draft_kv_geometry']['layer'][0]
        header.update(shape=[2,32,128,1,256],stride=[1048576,32768,256,256,1])
        for name,width in [('prefill_cudagraph_manager',4),('decode_cudagraph_manager',1)]:
            row['graph_inventory'][name]['graphs']=[dict(mode='FULL',num_reqs=n,num_tokens=n*width) for n in (1,2,4)]
    row=values[0]
    if damage=='legacy_heads':row['normalized_kv_heads']=4
    elif damage=='legacy_geometry':row['draft_kv_geometry']['layer'][0]['shape']=[2,32,128,4,128]
    elif damage=='aux':row['qwen36_loaded_pair']['aux_layers']=[1,20,38]
    elif damage=='projection':row['qwen36_loaded_pair']['fc_shape']=[2048,10240]
    elif damage=='norms':row['qwen36_loaded_pair']['fc_norm_shapes'].pop()
    elif damage=='model':row['draft_model']='/another/model'
    elif damage=='ar_bucket':row['graph_inventory']['decode_cudagraph_manager']['graphs'].pop()
    if damage is None:
        assert tool.validate_ranks(values,arm='G_ON',nonce='a'*32,source=source,pin=pin,after=True,qwen36=True)['ranks']==[0,1]
    else:
        with pytest.raises(ValueError):
            tool.validate_ranks(values,arm='G_ON',nonce='a'*32,source=source,pin=pin,after=True,qwen36=True)


@pytest.mark.parametrize('damage',[None,'snapshots_missing','normal_claim','provider_observer','uncertain'])
def test_numeric_capture_is_explicitly_distinct_from_observer_off_anchor(rows,damage):
    source,pin,values=rows
    for row in values:
        row.update(normalized_kv_heads=1,head_size=256,draft_model=str(tool.QWEN36_DRAFT),
                   heavy_observer_enabled=True,numeric_capture_enabled=True,provider_observer_enabled=False,
                   qwen36_loaded_pair=dict(profile=tool.QWEN36_PROFILE,target=str(tool.QWEN36_TARGET),
                       draft=str(tool.QWEN36_DRAFT),aux_layers=[3,19,35],fc_shape=[2048,6144],fc_norm_shapes=[[2048]]*3))
        row['draft_kv_geometry']['layer'][0].update(shape=[2,32,128,1,256],stride=[1048576,32768,256,256,1])
        for manager,width in [('prefill_cudagraph_manager',4),('decode_cudagraph_manager',1)]:
            row['graph_inventory'][manager]['graphs']=[dict(mode='FULL',num_reqs=n,num_tokens=n*width)for n in (1,2,4)]
    if damage=='snapshots_missing':values[0]['numeric_capture_enabled']=False
    elif damage=='normal_claim':values[0]['heavy_observer_enabled']=False
    elif damage=='provider_observer':values[0]['provider_observer_enabled']=True
    elif damage=='uncertain':values[0]['submission_uncertain']=True
    if damage is None:
        assert tool.validate_ranks(values,arm='G_ON',nonce='a'*32,source=source,pin=pin,after=True,
                                   qwen36=True,numeric_diagnostic=True)['ranks']==[0,1]
        with pytest.raises(ValueError):
            tool.validate_ranks(values,arm='G_ON',nonce='a'*32,source=source,pin=pin,after=True,qwen36=True)
    else:
        with pytest.raises(ValueError):
            tool.validate_ranks(values,arm='G_ON',nonce='a'*32,source=source,pin=pin,after=True,
                                qwen36=True,numeric_diagnostic=True)


@pytest.mark.parametrize('damage',['missing_rank','rank_bool','duplicate_pid','world','draft_tp','method',
    'uncertain','observer','provider','heads','shape','kv_device','import','module_hash','module_missing',
    'module_duplicate','native','inventory','dispatch','topology','window_rank','binding_rank','device','nspid'])
def test_incomplete_corrupt_cross_source_or_non_graph_rank_evidence_rejected(rows,damage):
    source,pin,values=rows;row=values[1]
    if damage=='missing_rank':values.pop()
    elif damage=='rank_bool':row['rank']=True
    elif damage=='duplicate_pid':row['pid']=values[0]['pid'];row['process_start_ticks']=values[0]['process_start_ticks']
    elif damage=='world':row['world_size']=1
    elif damage=='draft_tp':row['draft_tp_size']=1
    elif damage=='method':row['actual_method']='dspark'
    elif damage=='uncertain':row['submission_uncertain']=True
    elif damage=='observer':row['heavy_observer_enabled']=True
    elif damage=='provider':row['provider_installed']=False
    elif damage=='heads':row['normalized_kv_heads']=8
    elif damage=='shape':row['draft_kv_geometry']['layer'][0]['shape'][3]=8
    elif damage=='kv_device':row['draft_kv_geometry']['layer'][0]['device']='npu:0'
    elif damage=='import':row['modules'][1]['path']=str(pin/'vllm.py')
    elif damage=='module_hash':row['modules'][0]['sha256']='0'*64
    elif damage=='module_missing':row['modules']=row['modules'][1:]
    elif damage=='module_duplicate':row['modules'].append(row['modules'][0])
    elif damage=='native':row['loaded_native']=[]
    elif damage=='inventory':row['graph_inventory']['decode_cudagraph_manager']['graphs']=[]
    elif damage=='dispatch':row['dispatch_records']=row['dispatch_records'][:-1]
    elif damage=='topology':row['topology']['tp_rank']=0
    elif damage=='window_rank':row['window_generations'][0]['tp_rank']=0
    elif damage=='binding_rank':row['window_graph_bindings'][0]['tp_rank']=0
    elif damage=='device':row['logical_device']=0
    else:row['nspid']=['other']
    with pytest.raises(ValueError):tool.validate_ranks(values,arm='G_ON',nonce='a'*32,source=source,pin=pin,after=True)


def test_saved_checker_does_not_accept_producer_pass_instead_of_actual_execution(args):
    with pytest.raises(ValueError,match='execution'):
        tool.validate_saved(dict(status='PASS'),dict(returncode=2,signal=None,timeout=False),
            args=args,source=Path('.'),pin=args.vllm_repo,admission={})


def test_named_request_anchor_records_real_pinned_missing_metrics_without_invented_acceptance():
    metric = dict(request_id='0', finished=True, finish_reason='length',
                  speculative_decoding=None, timing=None,
                  unavailable_reason='PINNED_RESPONSE_METRICS_NOT_PRESENT')
    assert tool.validate_request_metrics(metric, allow_unavailable=True).startswith('NOT_AVAILABLE')
    with pytest.raises(ValueError):
        tool.validate_request_metrics(metric)  # Legacy fixture keeps its counter requirement.
    for key, value in [('finished', False), ('unavailable_reason', 'unknown'), ('timing', 1)]:
        damaged = dict(metric, **{key: value})
        with pytest.raises(ValueError):
            tool.validate_request_metrics(damaged, allow_unavailable=True)
    damaged = dict(metric)
    del damaged['speculative_decoding']
    with pytest.raises(ValueError):
        tool.validate_request_metrics(damaged, allow_unavailable=True)


@pytest.mark.parametrize('damage',[None,'pid','start','config','sampling','input','missing_group',
    'output','metric','worker','nonce','order','fixture','producer_pass'])
def test_saved_complete_payload_recomputed_and_corruptions_rejected(args,rows,damage):
    import hashlib
    source,pin,ranks=rows
    tool_path=source/'tools/p7x_graph_repair46_eagle_rank.py'
    # The worker module and producer are the same immutable file. Retain the
    # fixture's original bytes so this legal case does not invalidate its hash.
    assert tool_path.exists()
    _,kwargs=tool.configuration(args)
    metric=dict(num_spec_tokens=3,per_step_drafted=[3]*31,per_step_accepted=[0]*31,
        acceptance_histogram=[31,0,0,0],num_draft_tokens=93,num_accepted_draft_tokens=0,
        num_spec_steps=31,draft_acceptance_rate=0,mean_acceptance_length=1)
    campaign=dict(pid=10,start_ticks='20',started_at=100,ended_at=110,tp=2,arm='G_ON',
        source_sha=args.expected_sha,source_tree='b'*40,
        status='ALL_TWO_RANK_EAGLE_REQUEST_ANCHOR_COMPLETE_NOT_NUMERIC_VALIDATION',
        kwargs=kwargs,config_sha256=hashlib.sha256(json.dumps(kwargs,sort_keys=True).encode()).hexdigest(),
        sampling=dict(tool.SAMPLING),fixture_sha256=tool.digest(args.fixture),
        fixture_receipt_sha256=tool.digest(args.fixture_receipt),admission_sha256=tool.digest(args.admission),
        script_sha256=tool.digest(tool_path),before=dict(nonce='a'*32,ranks=copy.deepcopy(ranks)),requests=[])
    for n,(label,lengths) in enumerate(tool.GROUPS):
        nonce='bcd'[n]*32;actual=copy.deepcopy(ranks)
        for row in actual:row['nonce']=nonce
        campaign['requests'].append(dict(label=label,start_ns=100+n*10,end_ns=105+n*10,
            prompts=[dict(prompt_token_ids=[100+i]*length) for i,length in enumerate(lengths)],
            token_ids=[[1]*32 for _ in lengths],finished=[True]*len(lengths),
            metrics=[dict(finished=True,speculative_decoding=copy.deepcopy(metric)) for _ in lengths],
            nonce=nonce,ranks=actual,check=dict(status='UNTRUSTED_PRODUCER_SELF_REPORT')))
    execution=dict(returncode=0,signal=None,timeout=False,pid=10,start_ticks='20',start_epoch=99,end_epoch=111)
    admission=dict(source_sha=args.expected_sha,source_tree='b'*40)
    first=campaign['requests'][0]
    if damage=='pid':execution['pid']=11
    elif damage=='start':execution['start_ticks']='21'
    elif damage=='config':campaign['kwargs']=dict(tensor_parallel_size=1)
    elif damage=='sampling':campaign['sampling']['temperature']=0.5
    elif damage=='input':first['prompts'][0]['prompt_token_ids'][0]=99
    elif damage=='missing_group':campaign['requests'].pop()
    elif damage=='output':first['token_ids'][0].pop()
    elif damage=='metric':first['metrics'][0]['speculative_decoding']['num_accepted_draft_tokens']=1
    elif damage=='worker':first['ranks'][0]['process_start_ticks']='300'
    elif damage=='nonce':first['nonce']='a'*32
    elif damage=='order':first['end_ns']=200
    elif damage=='fixture':campaign['fixture_sha256']='0'*64
    elif damage=='producer_pass':campaign['status']='PASS'
    def check():return tool.validate_saved(campaign,execution,args=args,source=source,pin=pin,admission=admission)
    if damage is None:
        result=check()
        assert result['ranks']==[0,1] and result['numeric']=='NOT_ASSESSED'
        assert result['physical_read']=='NOT_PROVEN'
    else:
        with pytest.raises(ValueError):check()


def test_worker_rpc_only_reads_headers_without_new_tensor_reads_or_sync():
    import ast
    import inspect
    import textwrap
    tree=ast.parse(textwrap.dedent(inspect.getsource(tool.EagleRankWorker.mrv2_eagle_rank_identity)))
    names={node.func.attr for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute)}
    assert not names & {'synchronize','query','cpu','numpy','to','copy_','item','index_select','index_copy_'}
