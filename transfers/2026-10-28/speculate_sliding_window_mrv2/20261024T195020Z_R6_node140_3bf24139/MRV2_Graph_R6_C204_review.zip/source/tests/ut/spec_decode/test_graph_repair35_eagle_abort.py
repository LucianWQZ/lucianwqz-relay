# SPDX-License-Identifier: Apache-2.0
"""Pure Host counterexamples; these do not count as native/model evidence."""
import copy
import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair35_eagle_abort import POINTS, EagleAbort, check
from tools.p7x_graph_repair5_evidence import file_sha
from tools.p7x_graph_repair6_runner import adjudicate_records


def fixture(tmp_path, point):
    identity = dict(run_id="host-test", case_id="ABORT_EAGLE3_" + point, attempt_id="1",
                    source_sha="a" * 40, source_tree="b" * 40, driver_mode="B-observer-off",
                    process_id=42, engine_id=43)
    first = point in POINTS[:2]
    banks = []
    for step in ([0] if first else [0, 1, 2]):
        q = 4 if step == 0 else 1
        banks.append(dict(step=step, generation=30 + step, epoch=11,
            capture=dict(fingerprint=dict(method="eagle3", query_width=q,
                route="eagle3_first_pass" if step == 0 else "eagle3_ar_step", capture_bucket=[1, q]),
                consumer_ordinal=0 if step == 0 else step - 1,
                backing_identity=dict(window_block_table=dict(data_ptr=1000 + step * 100))),
            runtime=dict(generation_id=30 + step, mapping_epoch=11, step=step,
                         ordered_request_fingerprint=["r"]),
            state="SUBMITTED" if first else "UPDATED"))
    selected = banks[0 if first else -1]
    document = dict(schema="r6-eagle-abort-v1", identity=identity,
        record=dict(point=point, ns=20, epoch=11, request_ids=["r"],
            descriptor=selected["capture"]["fingerprint"]["capture_bucket"],
            manager_route="first" if first else "merged_ar", banks=banks,
            selected_generation=selected["generation"],
            selected_backing=selected["capture"]["backing_identity"]["window_block_table"]["data_ptr"],
            first_graph_replay_returned=point != "before_replay", current_manager_update_returned=not first,
            explicit_diagnostic_drain_complete=point == "after_completion",
            host_materialize_stream=101, update_stream=102, submission_scope="HOST_TEST_ONLY"),
        process_isolation_required=True, host_quarantined=True,
        post_fault_device_operations="NONE_BY_PROBE", reuse="FORBIDDEN_PROCESS_EXIT_73",
        python_exception_unfolding="NOT_EXERCISED", native_corruption="NOT_SIMULATED", normal_overlap="NOT_PROVEN")
    p = tmp_path / "eagle-abort.json"
    p.write_text(json.dumps(document))
    campaign = dict(identity=identity, status="ABORT_PARTIAL", startup_complete=True,
        request_manifest=dict(sha256="c" * 64), abort_point=point, isolation="PROCESS_EXIT_73_NO_REUSE",
        abort_artifact=dict(path=str(p), bytes=p.stat().st_size, sha256=file_sha(p)))
    launcher = dict(identity, argv=["python", "producer"], pid=42, requests_sha256="c" * 64,
                    host_start_ns=10, host_end_ns=40, status="EXITED", signal=None, timeout=False, returncode=73)
    expected = dict(acceptance_identity=identity, argv=launcher["argv"],
        launch_argv=["launch", "--", *launcher["argv"]], outputs=str(tmp_path),
        requests_sha256="c" * 64, eagle3_abort_point=point)
    return document, campaign, launcher, expected, p


@pytest.mark.parametrize("point", POINTS)
def test_named_partial_child_and_per_consumer_banks(tmp_path, point):
    assert check(*fixture(tmp_path, point))["status"] == "PASS_SCOPED_EAGLE3_ABORT_PROCESS_ISOLATION"


@pytest.mark.parametrize("damage", ["rc", "signal", "timeout", "pid", "point", "hash", "bytes", "epoch",
    "generation", "route", "ordinal", "state", "bank", "missing", "alias", "request", "complete", "replay",
    "update", "quarantine", "postfault"])
def test_exit_code_alone_or_self_consistent_wrong_bank_does_not_pass(tmp_path, damage):
    d, c, l, e, p = fixture(tmp_path, "after_update")
    if damage == "rc": l["returncode"] = 0
    if damage == "signal": l["signal"] = 9
    if damage == "timeout": l["timeout"] = True
    if damage == "pid": l["pid"] = 99
    if damage == "point": d["record"]["point"] = "after_completion"
    if damage == "hash": c["abort_artifact"]["sha256"] = "0" * 64
    if damage == "bytes": c["abort_artifact"]["bytes"] += 1
    if damage == "epoch": d["record"]["banks"][1]["runtime"]["mapping_epoch"] = 9
    if damage == "generation": d["record"]["banks"][2]["generation"] += 5
    if damage == "route": d["record"]["banks"][1]["capture"]["fingerprint"]["route"] = "eagle3_first_pass"
    if damage == "ordinal": d["record"]["banks"][2]["capture"]["consumer_ordinal"] = 0
    if damage == "state": d["record"]["banks"][1]["state"] = "SUBMITTED"
    if damage == "bank": d["record"]["selected_backing"] = 2000
    if damage == "missing": d["record"]["banks"].pop()
    if damage == "alias": d["record"]["banks"][1]["capture"]["backing_identity"]["window_block_table"]["data_ptr"] = 1000
    if damage == "request": d["record"]["banks"][0]["runtime"]["ordered_request_fingerprint"] = ["other"]
    if damage == "complete": d["record"]["explicit_diagnostic_drain_complete"] = True
    if damage == "replay": d["record"]["first_graph_replay_returned"] = False
    if damage == "update": d["record"]["current_manager_update_returned"] = False
    if damage == "quarantine": d["host_quarantined"] = False
    if damage == "postfault": d["post_fault_device_operations"] = "SYNC_AND_RECOVERY"
    # Update stored bytes/hash for deliberate semantic counterexamples, so
    # rejection cannot be attributed merely to an unchanged file checksum.
    if damage not in ("hash", "bytes"):
        p.write_text(json.dumps(d));c["abort_artifact"].update(bytes=p.stat().st_size, sha256=file_sha(p))
    assert check(d, c, l, e, p)["status"] != "PASS_SCOPED_EAGLE3_ABORT_PROCESS_ISOLATION"


def test_runner_dedicated_checker_and_exact_case_point_are_required():
    name = "ABORT_EAGLE3_after_replay"
    plan = dict(cases={name: dict(eagle3_abort_point="after_replay")})
    records = [dict(returncode=73, timeout=False, kind="launch", status="EXITED", argv=["producer"]),
        dict(returncode=0, timeout=False, kind="read_only_acceptance", status="EXITED",
             argv=["python", "p7x_graph_repair35_eagle_abort.py"])]
    assert adjudicate_records(plan, name, records)["dependency_satisfied"]
    assert not adjudicate_records(plan, name, records[:1])["dependency_satisfied"]
    wrong = copy.deepcopy(records);wrong[1]["argv"] = ["python", "p7x_graph_repair5.py", "check-diagnostic", "--kind", "abort"]
    assert not adjudicate_records(plan, name, wrong)["dependency_satisfied"]
    plan["cases"][name]["eagle3_abort_point"] = "after_update"
    with pytest.raises(ValueError, match="identity mismatch"):
        adjudicate_records(plan, name, records)


@pytest.mark.parametrize("point", POINTS)
def test_actual_first_graph_and_merged_ar_seams_host_only(tmp_path, monkeypatch, point):
    import tools.p7x_graph_repair35_eagle_abort as module
    import vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization as characterization
    monkeypatch.setattr(characterization, "_json_safe", copy.deepcopy)
    d, campaign, _, _, path = fixture(tmp_path, point)
    bankrows = fixture(tmp_path, "after_update")[0]["record"]["banks"]
    calls, states, transfers = [], {}, []
    controller = SimpleNamespace(_first_pass_is_graph=True, _stream=101, transfers=transfers, quarantined=False)
    def quarantine(reason):
        controller.quarantined = True;calls.append("quarantine")
    controller.quarantine = quarantine
    def add(step, state):
        b = bankrows[step]
        capture = b["capture"]
        transfer = SimpleNamespace(step=step, generation=b["generation"], mapping_epoch=11, capture_identity=capture)
        transfers.append(transfer)
        states[step] = SimpleNamespace(capture_identity=capture, runtime_identity=b["runtime"], state=SimpleNamespace(name=state))
    def lookup(capture):
        return states[next(i for i, b in enumerate(bankrows) if b["capture"] == capture)]
    session = SimpleNamespace(controller=controller, provider=SimpleNamespace(_require_registered_capture=lookup))
    graph = SimpleNamespace(replay=lambda: calls.append("first_replay"))
    desc = SimpleNamespace(cg_mode=SimpleNamespace(name="FULL"), num_reqs=1, num_tokens=4)
    # Real descriptors are hashable; use a tiny identity-keyed graph mapping.
    class Graphs:
        def values(self): return [graph]
        def __getitem__(self, key): assert key is desc;return graph
    def first_run(value):
        add(0, "SUBMITTED");graph.replay();states[0].state.name = "UPDATED";calls.append("first_update")
    def ar_run(value):
        add(1, "UPDATED");add(2, "UPDATED");calls.append("ar_update")
    sync = lambda: calls.append("diagnostic_sync")
    first = SimpleNamespace(graphs=Graphs(), run_fullgraph=first_run, update_stream=SimpleNamespace(synchronize=sync, npu_stream=102))
    ar = SimpleNamespace(run_fullgraph=ar_run, update_stream=SimpleNamespace(synchronize=sync, npu_stream=102))
    owner = SimpleNamespace(_eagle3_graph_session=session, prefill_cudagraph_manager=first, decode_cudagraph_manager=ar,
        _eagle3_window_proposal_context=SimpleNamespace(mapping_epoch=11, ordered_request_ids=["r"]),
        _eagle3_window_bypass_active=False)
    class Exit73(BaseException): pass
    def exit73(code):
        assert code == 73;calls.append("exit73");raise Exit73
    monkeypatch.setattr(module.os, "_exit", exit73)
    if point == "after_completion":
        import torch
        monkeypatch.setattr(torch.npu, "current_stream", lambda: SimpleNamespace(synchronize=sync))
    with pytest.raises(Exit73):
        with EagleAbort(owner, path, d["identity"], point, campaign):
            first.run_fullgraph(desc)
            ar.run_fullgraph(SimpleNamespace(cg_mode=SimpleNamespace(name="FULL"), num_reqs=1, num_tokens=1))
    produced = json.loads(path.read_text())
    assert produced["record"]["point"] == point and owner._draft_window_graph_submission_uncertain
    assert calls[-2:] == ["quarantine", "exit73"]
    assert ("first_replay" in calls) is (point != "before_replay")
    assert ("first_update" in calls) is (point not in POINTS[:2])
    assert calls.count("diagnostic_sync") == (3 if point == "after_completion" else 0)
    assert first.run_fullgraph is first_run and graph.replay.__name__ == "<lambda>"
    assert json.loads(path.with_name("abort-campaign.json").read_text())["status"] == "ABORT_PARTIAL"


def test_direct_cli_uses_stdlib_bisect_and_documents_scope(tmp_path):
    script = Path(__file__).resolve().parents[3] / "tools/p7x_graph_repair35_eagle_abort.py"
    result = subprocess.run([sys.executable, str(script), "--help"], cwd=tmp_path, capture_output=True, text=True, timeout=60)
    assert result.returncode == 0 and "--artifact" in result.stdout


def test_plan_retains_life_dependency_and_exact_child_argv(tmp_path):
    from tools.p7x_graph_repair35_eagle_abort import add_cases
    source = dict(argv=["python", "eagle", "run", "--case-id", "EAGLE3_G_ON"],
                  launch_argv=["launch", "--", "python", "eagle", "run", "--case-id", "EAGLE3_G_ON"],
                  acceptance_identity=dict(case_id="EAGLE3_G_ON"))
    cases = {"EAGLE3_G_ON": source}
    add_cases(cases, tmp_path, tmp_path, "python")
    for point in POINTS:
        name = "ABORT_EAGLE3_" + point
        case = cases[name]
        assert case["dependencies"] == ["CONFIG_EAGLE3", "EAGLE3_G_ON", "EAGLE3_LIFE"]
        assert case["acceptance_identity"]["case_id"] == name
        assert case["argv"][-2:] == ["--eagle3-abort", point]
        assert case["launch_argv"][case["launch_argv"].index("--") + 1:] == case["argv"]
        checker = case["validation_commands"][0]["argv"]
        assert any(value.endswith("p7x_graph_repair35_eagle_abort.py") for value in checker)
        assert checker[checker.index("--campaign") + 1].endswith("/" + name + "/abort-campaign.json")
    assert source["argv"][-1] == "EAGLE3_G_ON"
