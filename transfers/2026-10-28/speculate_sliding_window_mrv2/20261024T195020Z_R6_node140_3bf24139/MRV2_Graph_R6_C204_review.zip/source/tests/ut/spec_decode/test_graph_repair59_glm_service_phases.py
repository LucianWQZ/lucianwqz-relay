# SPDX-License-Identifier: Apache-2.0
"""Host-only raw phase and association counterexamples; no NPU execution."""
import copy
import json
from types import SimpleNamespace

import numpy as np
import pytest

from tools.p7x_graph_repair47_glm_service import install_phase_audit
from tools.p7x_graph_repair59_glm_service_phases import phase_serve_argv, validate_actual_phases


def workers(arm='G_ON'):
    entries = [
        dict(request_ids=['long'], computed=[0], scheduled=[256], prefill=[8193], is_prefilling=[True]),
        dict(request_ids=['short'], computed=[256], scheduled=[1], prefill=[257], is_prefilling=[True]),
        dict(request_ids=['short'], computed=[257], scheduled=[9], prefill=[257], is_prefilling=[False]),
        dict(request_ids=['long', 'short'], computed=[256, 257], scheduled=[247, 9],
             prefill=[8193, 257], is_prefilling=[True, False]),
    ]
    from tools.p7x_graph_repair16_scheduler import phase_from_rows
    result = []
    for rank in range(16):
        rows, epoch = [], 0
        for index, raw in enumerate(entries):
            phases, batch = phase_from_rows(raw)
            continuing = all(value == 'prefill_continuing' for value in phases)
            sources = []
            if arm != 'G_OFF' and not continuing:
                n = len(phases)
                sources = [dict(epoch=epoch, tp_rank=rank, tp_size=16, requests=raw['request_ids'],
                    actual=n, padded=2, row_phases=phases,
                    window_starts=[0] * n, exact=[512] * n + [0] * (2-n))]
                epoch += 1
            graphs = [] if arm == 'E_ON' or (arm == 'G_ON' and continuing) else [dict(
                role='draft:query_cudagraph_manager', num_reqs=2, num_tokens=16, mode='FULL',
                returned=True, host_start_ns=index*10+2, host_return_ns=index*10+8)]
            rows.append(dict(returned=True, batch_phase=batch, row_phases=phases,
                requests=raw['request_ids'], raw_cpu_rows=copy.deepcopy(raw),
                start_ns=index*10+1, end_ns=index*10+9,
                flags_after=dict(_draft_window_bypass_active=False, _draft_window_prefill_bypass_active=False),
                window_materializations=sources, manager_calls=graphs))
        result.append(dict(rank_snapshot=dict(rank=rank), proposal_phase_detail_schema=2,
                           proposal_phases_truncated=False, proposal_phases=rows))
    return result


@pytest.mark.parametrize('arm', ['G_OFF', 'G_ON', 'E_ON'])
def test_complete_raw_counter_and_source_association_surrogate(arm):
    result = validate_actual_phases(workers(arm), arm)
    assert result['status'] == 'PASS_SCOPED_ACTUAL_GLM_PHASES_AND_SOURCE_ASSOCIATION'
    assert len(result['ranks']) == 16
    assert result['execution_operand'] == 'NOT_OBSERVED'


@pytest.mark.parametrize('damage', ['missing', 'boolean_rank', 'truncated', 'old_schema', 'relabel',
    'raw_counter', 'source_request', 'source_phase', 'source_rank', 'source_missing', 'crop_prefill',
    'graph_missing', 'wrong_bucket', 'unreturned', 'leaked_flag', 'missing_flags', 'stale_epoch',
    'cross_rank', 'no_mixed'])
def test_damaged_or_old_evidence_cannot_become_mixed_coverage(damage):
    rows = workers()
    worker = rows[-1]
    sample = worker['proposal_phases'][-1]
    if damage == 'missing':
        rows.pop()
    elif damage == 'boolean_rank':
        worker['rank_snapshot']['rank'] = True
    elif damage == 'truncated':
        worker['proposal_phases_truncated'] = True
    elif damage == 'old_schema':
        worker['proposal_phase_detail_schema'] = 1
    elif damage == 'relabel':
        sample['batch_phase'] = 'pure_decode'
    elif damage == 'raw_counter':
        sample['raw_cpu_rows']['computed'][0] = 8193
    elif damage in ('source_request', 'source_phase', 'source_rank'):
        source = sample['window_materializations'][0]
        source[dict(source_request='requests', source_phase='row_phases', source_rank='tp_rank')[damage]] = (
            ['another'] if damage != 'source_rank' else 0)
    elif damage == 'source_missing':
        sample['window_materializations'] = []
    elif damage == 'crop_prefill':
        sample['window_materializations'][0]['window_starts'][0] = 128
    elif damage == 'graph_missing':
        sample['manager_calls'] = []
    elif damage == 'wrong_bucket':
        sample['manager_calls'][0]['num_tokens'] = 32
    elif damage == 'unreturned':
        sample['returned'] = False
    elif damage == 'leaked_flag':
        sample['flags_after']['_draft_window_bypass_active'] = True
    elif damage == 'missing_flags':
        sample['flags_after'] = {}
    elif damage == 'stale_epoch':
        sample['window_materializations'][0]['epoch'] = 0
    elif damage == 'cross_rank':
        sample['raw_cpu_rows']['scheduled'][0] += 1
    else:
        worker['proposal_phases'].pop()
    with pytest.raises((ValueError, KeyError, TypeError)):
        validate_actual_phases(rows, 'G_ON')


def test_eager_source_cannot_hide_a_draft_graph():
    rows = workers('E_ON')
    rows[0]['proposal_phases'][-1]['manager_calls'] = workers()[0]['proposal_phases'][-1]['manager_calls']
    with pytest.raises(ValueError):
        validate_actual_phases(rows, 'E_ON')


@pytest.mark.parametrize('detailed', [False, True])
def test_existing_proposal_hook_preserves_result_and_details_are_explicit(monkeypatch, detailed):
    # The actual production classifier reads only these CPU InputBatch arrays.
    batch = SimpleNamespace(num_reqs=2, req_ids=['long', 'short'],
        num_computed_prefill_tokens_np=np.array([256, 257], np.int32),
        num_scheduled_tokens=np.array([247, 9], np.int32),
        prefill_len_np=np.array([8193, 257], np.int32),
        is_prefilling_np=np.array([True, False]), has_prefill=True)
    sentinel = object()
    worker = SimpleNamespace(_mrv2_rank_window_generations=[], _mrv2_rank_replay_records=[])
    class Spec:
        def propose(self, input_batch, dummy_run=False, is_profile=False):
            worker._mrv2_rank_window_generations.append(dict(epoch=0))
            worker._mrv2_rank_replay_records.append(dict(returned=True))
            return sentinel
    spec = Spec()
    worker.model_runner = SimpleNamespace(speculator=spec)
    install_phase_audit(worker, detailed=detailed)
    assert spec.propose(batch) is sentinel
    row = worker._mrv2_service_phases[0]
    assert row['batch_phase'] == 'mixed' and row['returned'] is True
    assert ('raw_cpu_rows' in row) is detailed
    if detailed:
        assert row['raw_cpu_rows']['computed'] == [256, 257]
        assert row['window_materializations'] == [dict(epoch=0)]
        assert row['manager_calls'] == [dict(returned=True)]
        assert row['start_ns'] < row['end_ns']


def test_optional_cpu_detail_hook_does_not_replace_original_exception():
    batch = SimpleNamespace(num_reqs=1, req_ids=['a'],
        num_computed_prefill_tokens_np=np.array([1], np.int32), num_scheduled_tokens=np.array([9], np.int32),
        prefill_len_np=np.array([1], np.int32), is_prefilling_np=np.array([False]), has_prefill=False)
    class Spec:
        def propose(self, input_batch):
            raise RuntimeError('original execution failed')
    worker = SimpleNamespace(model_runner=SimpleNamespace(speculator=Spec()),
        _mrv2_rank_window_generations=[], _mrv2_rank_replay_records=[])
    install_phase_audit(worker, detailed=True)
    with pytest.raises(RuntimeError, match='original execution failed'):
        worker.model_runner.speculator.propose(batch)
    assert worker._mrv2_service_phases[0]['returned'] is False
    assert 'end_ns' in worker._mrv2_service_phases[0]


def test_phase_arm_keeps_real_target_graph_and_all_features_separate_from_timing():
    for arm in ('G_OFF', 'G_ON', 'E_ON'):
        argv = phase_serve_argv('/python', 18001, 'phase', arm, worker_provenance=True)
        assert argv[argv.index('--max-num-batched-tokens') + 1] == '256'
        spec = json.loads(argv[argv.index('--speculative-config') + 1])
        assert spec['method'] == 'dspark' and spec['num_speculative_tokens'] == 8
        assert spec['enforce_eager'] is (arm == 'E_ON') and '--enforce-eager' not in argv
        assert '--async-scheduling' in argv and '--enable-prefix-caching' in argv
        additional = json.loads(argv[argv.index('--additional-config') + 1])
        assert all(additional[key] is True for key in ('enable_dsa_cp', 'enable_flashcomm1'))
