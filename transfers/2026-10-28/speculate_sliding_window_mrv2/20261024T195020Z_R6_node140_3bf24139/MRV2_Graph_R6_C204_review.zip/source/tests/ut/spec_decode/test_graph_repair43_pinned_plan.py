# SPDX-License-Identifier: Apache-2.0
"""CPU plan contracts; neither pinned memory nor NPU completion is simulated as proof."""

import copy
import json

import pytest

from tools.p7x_graph_local_candidate import _validate_review_binding
from tools.p7x_graph_repair13_eagle import CONTRACT, add_cases, parse_args


def plan_with_eagle(tmp_path, enabled):
    (tmp_path / "eagle3-k3-fixture.json").write_text(
        json.dumps(dict(schema="r5-eagle3-k3-fixture-v1", method_contract=CONTRACT))
    )
    (tmp_path / "requests").mkdir()
    (tmp_path / "requests/eagle3-k3-anchor.json").write_text("[]")
    from tools.p7x_graph_repair23_eagle_target import case_plan

    (tmp_path / "requests/eagle3-controlled-target.json").write_text(json.dumps(case_plan()))
    common = dict(
        acceptance_identity=dict(run_id="pinned-plan-host", driver_mode="A0", case_id="A0"),
        argv=["python", "driver", "run", "--vllm-repo", "/fixed-vllm"],
        dependencies=[],
        requires_device_admission=True,
    )
    cases = dict(A0=copy.deepcopy(common), CONFIG=copy.deepcopy(common))
    cases["CONFIG"].pop("acceptance_identity")
    add_cases(cases, tmp_path, tmp_path, tmp_path, "python", "a" * 40,
              tmp_path / "proof.json", "b" * 64, pinned_h2d_review=enabled)
    review = {"eagle_owned_pinned_h2d": enabled}
    return dict(cases=cases, review_experiments=review), dict(review_experiments=copy.deepcopy(review))


@pytest.mark.parametrize("enabled", [False, True])
def test_explicit_policy_reaches_every_actual_on_entry_and_no_other_arm(tmp_path, enabled):
    plan, manifest = plan_with_eagle(tmp_path, enabled)
    assert _validate_review_binding(plan, manifest) is enabled
    for case in plan["cases"].values():
        if "eagle3_arm" not in case:
            continue
        args = parse_args(case["argv"][case["argv"].index("run"):])
        assert args.eagle3_pinned_h2d_review is (enabled and args.arm == "G_ON")
        assert case["launch_argv"][case["launch_argv"].index("--") + 1:] == case["argv"]
    assert plan["cases"]["EAGLE3_LIFE"]["eagle3_life"]
    assert plan["cases"]["EAGLE3_NUMERIC"]["eagle3_numeric"]
    assert plan["cases"]["EAGLE3_TARGET_ON"]["eagle3_target"]


@pytest.mark.parametrize("damage", ["policy", "manifest", "float", "manifest_int", "missing_argv",
                                     "extra_argv", "launch", "off", "case_type", "duplicate", "unknown"])
def test_changed_policy_or_child_cannot_pass_even_if_rehashed_by_caller(tmp_path, damage):
    plan, manifest = plan_with_eagle(tmp_path, True)
    case = plan["cases"]["EAGLE3_G_ON"]
    if damage == "policy":
        plan["review_experiments"]["eagle_owned_pinned_h2d"] = False
    elif damage == "manifest":
        manifest["review_experiments"] = {}
    elif damage == "float":
        plan["review_experiments"]["eagle_owned_pinned_h2d"] = 1.0
    elif damage == "manifest_int":
        manifest["review_experiments"]["eagle_owned_pinned_h2d"] = 1
    elif damage == "missing_argv":
        case["argv"].remove("--eagle3-pinned-h2d-review")
    elif damage == "extra_argv":
        plan["cases"]["CONFIG"]["argv"].append("--eagle3-pinned-h2d-review")
    elif damage == "launch":
        case["launch_argv"].remove("--eagle3-pinned-h2d-review")
    elif damage == "off":
        plan["cases"]["EAGLE3_G_OFF"]["argv"].append("--eagle3-pinned-h2d-review")
    elif damage == "case_type":
        case["eagle3_pinned_h2d_review"] = 1
    elif damage == "duplicate":
        case["argv"].append("--eagle3-pinned-h2d-review")
    else:
        plan["review_experiments"]["unreviewed_policy"] = True
        manifest["review_experiments"]["unreviewed_policy"] = True
    with pytest.raises(ValueError):
        _validate_review_binding(plan, manifest)


def test_legacy_default_plan_stays_valid_and_enabled_empty_plan_is_rejected():
    assert _validate_review_binding({"cases": {}}, {}) is False
    review = {"eagle_owned_pinned_h2d": True}
    with pytest.raises(ValueError, match="no actual Eagle"):
        _validate_review_binding({"cases": {}, "review_experiments": review}, {"review_experiments": review})
