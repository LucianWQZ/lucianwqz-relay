# SPDX-License-Identifier: Apache-2.0
"""Reject incomplete Host evidence even when extra labels make sets incomparable."""

import pytest

from tools.p7x_graph_local_candidate import _validate_host_evidence, digest


def records(tmp_path, labels):
    log = tmp_path / "host.log"
    log.write_text("scoped Host checks passed\n")
    return [dict(label=label, status="PASS", path=str(log), sha256=digest(log)) for label in labels]


@pytest.mark.parametrize(
    "labels",
    [
        [],
        ["native_binding"],
        ["graph_quarantine", "native_binding"],
        ["local_admission", "native_binding"],
        ["graph_quarantine", "graph_quarantine"],
    ],
)
def test_missing_required_coverage_is_rejected(tmp_path, labels):
    with pytest.raises(ValueError, match="Host evidence"):
        _validate_host_evidence(records(tmp_path, labels))


def test_complete_coverage_allows_additional_diagnostics(tmp_path):
    _validate_host_evidence(records(tmp_path, ["native_binding", "local_admission", "graph_quarantine"]))


@pytest.mark.parametrize("damage", ["bytes", "status"])
def test_complete_labels_cannot_hide_changed_or_failed_evidence(tmp_path, damage):
    evidence = records(tmp_path, ["local_admission", "graph_quarantine"])
    if damage == "bytes":
        (tmp_path / "host.log").write_text("changed after validation\n")
    else:
        evidence[0]["status"] = "FAIL"
    with pytest.raises(ValueError, match="Host evidence missing or changed"):
        _validate_host_evidence(evidence)


@pytest.mark.parametrize("scope", [list(range(8)), list(range(8, 16))])
def test_planned_scope_binding_accepts_explicit_groups(scope):
    from tools.p7x_graph_local_candidate import _planned_device_scope, _validate_scope_binding

    assert _planned_device_scope(scope) == scope
    _validate_scope_binding({"authorized_host_phy_ids": scope}, {"authorized_host_phy_ids": scope})
    _validate_scope_binding({}, {})  # Legacy manifests remain front-eight only.


@pytest.mark.parametrize("scope", [[], [8], list(range(16)), [True, *range(1, 8)], "8-15", None])
def test_planned_scope_rejects_ambiguous_or_expanded_groups(scope):
    from tools.p7x_graph_local_candidate import _planned_device_scope

    with pytest.raises(ValueError, match="physical scope"):
        _planned_device_scope(scope)


def test_planned_scope_cannot_change_after_manifest():
    from tools.p7x_graph_local_candidate import _validate_scope_binding

    with pytest.raises(ValueError, match="scope changed"):
        _validate_scope_binding({"authorized_host_phy_ids": list(range(8, 16))}, {})
