# SPDX-License-Identifier: Apache-2.0
"""Raw checker corruption cases, including real hybrid-cache alias geometry."""
import copy
import json
from types import SimpleNamespace as N

import pytest
import torch

from tools import p7x_graph_repair74_swa_reference as tool
from tools.p7x_graph_repair6_storage import CollectionReader, CollectionWriter


def test_fixed_profile_survives_json_and_retains_explicit_diag_scope():
    assert json.loads(json.dumps(tool.identity()))==tool.identity()
    kw=tool.build_kwargs(4,window_on_review=True)
    assert kw['additional_config']['draft_window_graph_numeric_diagnostic'] is True
    assert kw['additional_config']['draft_window_size']==32768


def test_owned_probe_is_separately_named_bounded_and_keeps_the_primary_oracle():
    profile=tool.identity(True)
    assert json.loads(json.dumps(profile))==profile
    assert profile['profile']==tool.OWNED_PROFILE and profile['quota']=={'3':1}
    assert tool.identity()['quota']=={'1':2,'3':1}
    assert tool.build_kwargs(4,window_on_review=True,owned_failure_probe=True)[
        'additional_config']['draft_window_graph_numeric_owned_output'] is True
    for damaged in (False,True):
        record=sample();record['profile']=tool.OWNED_PROFILE
        if damaged:record['reference_hidden'][0,0]=1
        assert bool(tool.validate_sample(record)['errors']) is damaged


def test_owned_probe_cannot_be_claimed_by_original_acceptance_checker(tmp_path):
    p=tmp_path/'planned.json';p.write_text(json.dumps({'argv':['run','--owned-failure-probe']}))
    with pytest.raises(ValueError,match='raw analysis'):tool.check(p,tmp_path/'missing.json')


def test_failed_probe_cannot_bypass_into_an_uncovered_batch_shape(tmp_path):
    calls=[]
    manager=N(run_fullgraph=lambda d:calls.append(d))
    owner=N(query_cudagraph_manager=manager,_draft_graph_output_references=N(frozen=True),
            vllm_config=N(parallel_config=None),input_batch=N(num_reqs=2))
    worker=N(rank=0,model_runner=N(speculator=owner))
    probe=tool.SWAReplayReference(worker,tmp_path,N(validate=lambda *a:None))
    probe.failed=True
    with pytest.raises(ValueError,match='failed numerical branch'):manager.run_fullgraph(None)
    assert not calls


def sample():
    names=[f'draft{i}' for i in range(6)]
    canonical,counts,actual,reference={}, {}, {}, {}
    positions=torch.cat((torch.arange(249,257),torch.zeros(8,dtype=torch.int64)))
    query=torch.tensor([0,8,8],dtype=torch.int32)
    for i,name in enumerate(names):
        gid=10+i;table=torch.zeros((2,300),dtype=torch.int32)
        table[0,:3]=torch.arange(1+3*i,4+3*i,dtype=torch.int32)
        slot=torch.full((16,),-1,dtype=torch.int32)
        slot[:8]=table[0].index_select(0,positions[:8]//128)*128+positions[:8]%128
        canonical[gid]=table;counts[gid]=[3]
        actual[name]=dict(gid=gid,table=table.clone(),exact=[257,0],slot=slot,causal=i<5,
                          positions=positions.clone(),query_start=query.clone(),cumulative_query=[8,16])
        reference[name]={k:copy.deepcopy(v) for k,v in actual[name].items() if k not in ('positions','query_start','cumulative_query')}
    caches={}
    for part in range(2):
        for label,layers,base in [('native',names[:5],1_000_000_000+part*1_000_000_000),
                                  ('full',names[5:],3_000_000_000+part*1_000_000_000)]:
            selected={0};slots=set()
            for name in layers:
                meta=actual[name];selected.update(canonical[meta['gid']][0,:3].tolist())
                slots.update(v for v in meta['slot'].tolist() if v>=0)
            selected=sorted(selected);before=torch.zeros((len(selected),128,2,128),dtype=torch.bfloat16)
            after=before.clone()
            for slot in slots:after[selected.index(slot//128),slot%128].fill_(1)
            caches[f'{label}{part}']=dict(selected=selected,slots=sorted(slots),layers=[f'{name}/{part}' for name in layers],
                allocation=dict(shape=[64,128,2,128],stride=[32768,256,128,1],storage_offset=0,
                                data_ptr=base,dtype='torch.bfloat16',npu_format=2),
                before=before,restored=before.clone(),graph=after,reference=after.clone())
    inputs=dict(input_ids=torch.full((16,),100,dtype=torch.int64),positions=positions,query_start_loc=query)
    return dict(identity=dict(rank=0,generation=17,epoch=8,actual=1,padded=2,index=0),
        status='CAPTURED_COMPLETE',profile=tool.PROFILE,full_gid=15,native_gids=list(range(10,15)),
        canonical=canonical,block_counts=counts,full_exact=[257,0],window_starts=[0],inputs=inputs,
        requests=['fixed'],row_phases=['pure_decode'],phase_inputs=dict(computed=[0],scheduled=[8],prefill=[0],declared=[False]),
        after_inputs=copy.deepcopy(inputs),graph_hidden=torch.zeros((16,8),dtype=torch.bfloat16),
        reference_hidden=torch.zeros((16,8),dtype=torch.bfloat16),actual_metadata=actual,
        reference_metadata=reference,caches=caches,
        reference_call='REAL_DFLASH_RUN_MODEL_CUDAGRAPH_NONE_AFTER_EXACT_PRESTATE_RESTORE')


def test_long_full_projection_is_independent_and_keeps_padding_zero():
    full=torch.arange(4*512,dtype=torch.int32).reshape(4,512)
    table,lengths,starts=tool.project_full(full,[37000,8193,387,0],3,4,257)
    assert starts==[4224,0,0] and lengths==[32776,8193,387,0]
    assert torch.equal(table[0,:257],full[0,33:290])
    assert torch.count_nonzero(table[3])==0
    with pytest.raises(ValueError):tool.project_full(full,[37000,8193,387,0],3,4,256)
    baseline,lengths,starts=tool.project_full(full,[37000,8193,387,0],3,4,320,
                                             ['prefill_continuing','pure_decode','prefill_terminal'])
    assert starts==[0,0,0] and lengths==[37000,8193,387,0]
    assert torch.equal(baseline[0,:290],full[0,:290])


@pytest.mark.parametrize('damage',[None,'hidden','nan','kv','shared_wrong_write','restore','allowed_slot',
                                  'omit_block','missing_part','slot','position','query','causal','dtype','packed'])
def test_raw_values_and_declared_writes_cannot_be_replaced_by_producer_pass(damage):
    record=sample();cache=record['caches']['native0']
    if damage=='hidden':record['reference_hidden'][0,0]=1
    elif damage=='nan':record['graph_hidden'][0,0]=float('nan')
    elif damage=='kv':cache['reference'][0,0,0,0]=1
    elif damage=='shared_wrong_write':cache['graph'][0,0,0,0]=cache['reference'][0,0,0,0]=1
    elif damage=='restore':cache['restored'][0,0,0,0]=1
    elif damage=='allowed_slot':cache['slots'].append(0);cache['slots'].sort()
    elif damage=='omit_block':cache['selected'].pop()
    elif damage=='missing_part':cache['layers'].pop()
    elif damage=='slot':
        record['actual_metadata']['draft5']['slot'][0]+=1
        record['reference_metadata']['draft5']['slot'][0]+=1
    elif damage=='position':record['actual_metadata']['draft0']['positions'][0]+=1
    elif damage=='query':record['actual_metadata']['draft0']['cumulative_query']=[8,8]
    elif damage=='causal':record['actual_metadata']['draft0']['causal']=False
    elif damage=='dtype':cache['graph']=cache['graph'].float()
    elif damage=='packed':cache['allocation']['npu_format']=29
    try:verdict=tool.validate_sample(record)
    except (ValueError,KeyError,RuntimeError):
        assert damage is not None
    else:
        assert bool(verdict['errors']) is (damage is not None)


def test_partial_native_full_alias_authorizes_only_real_query_bytes():
    record=sample();native=record['caches']['native0'];full=record['caches']['full1']
    native['allocation']['data_ptr']=full['allocation']['data_ptr']+16*65536
    addresses={c['allocation']['data_ptr']+slot*512 for c in record['caches'].values() for slot in c['slots']}
    for cache in record['caches'].values():
        for index,block in enumerate(cache['selected']):
            for token in range(128):
                value=1 if cache['allocation']['data_ptr']+block*65536+token*512 in addresses else 0
                cache['graph'][index,token].fill_(value);cache['reference'][index,token].fill_(value)
    assert not tool.validate_sample(record)['errors']
    # An allowed Full write is visible through the overlapping native pool.
    assert torch.count_nonzero(native['graph'][native['selected'].index(1)])>0
    # An inconsistent captured alias is still rejected, even if restore agrees.
    native['before'][native['selected'].index(1),0,0,0]=1
    native['restored'][native['selected'].index(1),0,0,0]=1
    with pytest.raises(ValueError,match='overlapping'):tool.validate_sample(record)


def test_saved_raw_roundtrip_preserves_integer_group_ids_and_checksums(tmp_path):
    record=sample();writer=CollectionWriter(tmp_path/'numeric.json',dict(profile=tool.PROFILE),max_bytes=64<<20)
    writer.start(record['identity']);writer.finish(record);writer.close('COMPLETE')
    reader=CollectionReader(writer.path)
    restored=reader.record(0)
    assert set(restored['canonical'])==set(range(10,16))
    assert not tool.validate_sample(restored)['errors']
    blob=next((tmp_path/'numeric-tensors').glob('*.bin'))
    with blob.open('r+b') as stream:
        byte=stream.read(1);stream.seek(0);stream.write(bytes([byte[0]^1]))
    with pytest.raises(ValueError,match='hash'):CollectionReader(writer.path).record(0)
