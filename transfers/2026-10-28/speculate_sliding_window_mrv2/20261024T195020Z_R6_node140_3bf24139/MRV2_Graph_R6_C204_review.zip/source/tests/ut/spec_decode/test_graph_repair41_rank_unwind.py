# SPDX-License-Identifier: Apache-2.0
"""Host contract counterexamples only; synthetic rows never count as NPU evidence."""
import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as N

import pytest

from tools import p7x_graph_repair41_rank_unwind as tool


def payload(tmp_path, mode='python_unwind', point='after_update'):
    return dict(mode=mode, point=point if mode == 'python_unwind' else None,
                selected_rank=None if mode == 'python_unwind' else 1,
                profile='qwen_target4', tp=2, nonce='b'*32, source_sha='a'*40,
                parent_pid=99, root=str(tmp_path),host='fixture-node',boot_id='fixture-boot',namespace='mnt:[fixture]')


@pytest.mark.parametrize('damage', ['single_native_rank', 'missing_selected', 'bool_selected',
                                  'tp1', 'bool_tp', 'glm_tp2', 'wrong_point', 'source', 'nonce'])
def test_rank_fault_cannot_turn_into_an_unmatched_native_injection(tmp_path, damage):
    row = payload(tmp_path)
    if damage == 'single_native_rank': row['selected_rank'] = 1
    elif damage == 'missing_selected': row.update(mode='preparation_reject', point=None)
    elif damage == 'bool_selected': row.update(mode='preparation_reject', point=None, selected_rank=True)
    elif damage == 'tp1': row['tp'] = 1
    elif damage == 'bool_tp': row['tp'] = True
    elif damage == 'glm_tp2': row['profile'] = 'glm_k8'
    elif damage == 'wrong_point': row['point'] = 'during_native_kernel'
    elif damage == 'source': row['source_sha'] = 'not-a-commit'
    else: row['nonce'] = 'old'
    with pytest.raises(ValueError):
        tool.validate_payload(row)


@pytest.mark.parametrize('tp', [2, 4, 16])
def test_fixed_qwen_profile_preserves_real_topology_and_review_gate(tp):
    kwargs = tool.fault_kwargs('qwen_target4', tp)
    assert kwargs['tensor_parallel_size'] == tp
    assert kwargs['compilation_config']['cudagraph_capture_sizes'] == [7, 14, 28, 32]
    assert kwargs['speculative_config']['num_speculative_tokens'] == 7
    assert kwargs['additional_config'] == dict(draft_window_size=1024, draft_window_graph_replicated_tp_review=True)
    assert kwargs['worker_extension_cls'].endswith('.RankUnwindWorker')
    assert kwargs['async_scheduling'] is False and kwargs['enable_prefix_caching'] is False


def test_glm_profile_keeps_its_actual_model_backend_and_complete_tp16():
    kwargs = tool.fault_kwargs('glm_k8',16)
    assert kwargs['tensor_parallel_size'] == 16
    assert kwargs['speculative_config']['num_speculative_tokens'] == 8
    assert kwargs['compilation_config']['cudagraph_capture_sizes'] == [8,16,32,36]
    assert kwargs['quantization'] == 'ascend'
    assert kwargs['hf_overrides']['use_index_cache'] is True
    with pytest.raises(ValueError):tool.fault_kwargs('glm_k8',2)


def test_soc_api_never_initializes_an_unallocated_default_device():
    calls=[]
    npu=N(is_initialized=lambda:False,get_soc_version=lambda:calls.append('DEVICE_QUERY'))
    with pytest.raises(ValueError):tool.already_initialized_soc_version(npu)
    assert calls==[]
    npu.is_initialized=lambda:True;npu.get_soc_version=lambda:253
    result=tool.already_initialized_soc_version(npu)
    assert result['value']==253 and result['already_initialized'] is True
    assert 'NOT_RUNTIME_BRANCH' in result['scope']


def worker(rank, row, source, pin):
    modules=[]
    for name in ['vllm','vllm_ascend','vllm_ascend.worker.worker','vllm_ascend.worker.v2.model_runner',
                 'vllm_ascend.worker.v2.spec_decode.dspark.speculator']:
        root=pin if name=='vllm' else source
        rel=Path(*name.split('.'))/('__init__.py') if name in ['vllm','vllm_ascend'] else Path(*name.split('.')).with_suffix('.py')
        path=root/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('# synthetic Host module fixture '+name+'\n')
        modules.append(dict(module=name,path=str(path),bytes=path.stat().st_size,sha256=tool.digest(path)))
    return dict(rank=rank, pid=201+rank, process_start_ticks=str(900+rank),
                hostname=row['host'],boot_id=row['boot_id'],namespace=row['namespace'],
                logical_device=rank, world_size=row['tp'], tp_size=row['tp'], draft_tp_size=row['tp'],
                nonce=row['nonce'], source_sha=row['source_sha'], ascend_source=str(source/'vllm_ascend/__init__.py'),
                vllm_source=str(pin/'vllm/__init__.py'), window_size=1024, window_provider_installed=True,
                heavy_observer_enabled=False, submission_uncertain=False,
                worker_class='vllm_ascend.worker.worker.Worker',
                runner_class='vllm_ascend.worker.v2.model_runner.NPUModelRunner',module_sources=modules,
                speculator_class='vllm_ascend.worker.v2.spec_decode.dspark.speculator.AscendDSparkSpeculator',
                draft_model_config=tool.fault_kwargs(row['profile'], row['tp'])['speculative_config']['model'],
                draft_graph_inventory=[dict(mode='FULL', tokens=7, requests=1)],
                target_graph_inventory=[dict(mode='FULL', tokens=8, requests=1)])


def fault_identity(w, row):
    return dict(rank=w['rank'], world_size=row['tp'], pid=w['pid'], process_start_ticks=w['process_start_ticks'],
                nonce=row['nonce'], source_sha=row['source_sha'], mode=row['mode'], point=row['point'])


def host_documents(w, row):
    # Explicit synthetic checker fixture, not a producer/device PASS claim.
    generation = dict(generation_id=3, mapping_epoch=7, ordered_request_fingerprint=['request-1'],
        actual_request_count=1, padded_request_count=1, normalized_method='dspark', global_group_id=0,
        read_descriptor_fingerprint=[dict(source_start_column=1)], provider_id=123, provider_version=1,
        source_identity=dict(block_tables_owner_id=456), execution_lane=0, phase='proposal', step=0,
        topology_fingerprint=dict(tensor_parallel_size=row['tp'], tensor_parallel_rank=w['rank'],
                                 parallel_read_semantics='replicated', graph_mode='FULL_DECODE_ONLY'),
        row_phase_fingerprint=['decode'])
    binding = dict(generation_id=3, mapping_epoch=7, tensor_parallel_size=row['tp'], tensor_parallel_rank=w['rank'],
                   ordered_request_fingerprint=['request-1'], actual_request_count=1, padded_request_count=1)
    point = row['point']
    record = dict(generation=3, epoch=7, generation_identity=generation, carrier_binding=binding,
        descriptor=[1,7], backing=dict(window_block_table=dict(data_ptr=4096, device=f"npu:{w['logical_device']}", shape=[1,32])),
        injected_point=point, before_replay_ns=10, injected_ns=20,
        quarantine_calls=[dict(identity=copy.deepcopy(generation))],
        replay_called=point!='before_replay', replay_returned=point!='before_replay',
        update_returned=point in ('after_update','after_completion'), completion='UNPROVEN')
    if point == 'after_completion':
        record.update(completion='DIAGNOSTIC_STREAM_DRAIN_BEFORE_EXCEPTION', update_return_ns=14, complete_ns=16)
    document = dict(schema='repair8-python-unwind-v1', identity=fault_identity(w,row), point=point,
        record=record, state=dict(quarantined_identity=copy.deepcopy(generation), active_backing_retained=True,
            live_inputs_cleared=True, proposal_context_cleared=True, graph_submission_uncertain=True),
        next_scope_guard=dict(rejected=True, body_entered=False, exception='backing is quarantined', ns=30),
        post_fault_device_operations='NONE_BY_THIS_PROBE', status='HOST_EXPORTED_ISOLATION_REQUIRED',
        isolated_exit_required=74)
    terminal = dict(identity=fault_identity(w,row), exception_type='InjectedGraphUnwindError',
                    exception_message='REPAIR8_PYTHON_UNWIND:'+point, caught_ns=25,
                    post_fault_device_operations='NONE_BY_THIS_WRAPPER')
    return document, terminal


@pytest.mark.parametrize('point', tool.POINTS)
def test_each_submit_state_requires_actual_quarantine_and_host_rejection(tmp_path, point):
    row = payload(tmp_path, point=point)
    w = worker(1,row,tmp_path/'source',tmp_path/'pin')
    document, terminal = host_documents(w,row)
    result = tool.validate_unwind_document(document,terminal,w,row)
    assert result['point'] == point and result['rank'] == 1
    assert result['status'].endswith('EXTERNAL_PROCESS_DEVICE_JOIN_REQUIRED')


@pytest.mark.parametrize('damage', ['rank', 'pid', 'nonce', 'epoch', 'bool_generation', 'old_binding_rank',
    'bool_topology', 'missing_source', 'requests', 'quarantine', 'not_retained', 'scope_entered',
    'unexpected_error', 'export_failed', 'post_device', 'host_return_completion', 'wrong_query', 'old_device'])
def test_invalid_raw_unwind_is_not_rescued_by_expected_exit_code(tmp_path, damage):
    row = payload(tmp_path)
    w = worker(0,row,tmp_path/'source',tmp_path/'pin')
    d,t = host_documents(w,row)
    if damage == 'rank': d['identity']['rank'] = 1
    elif damage == 'pid': t['identity']['pid'] += 1
    elif damage == 'nonce': d['identity']['nonce'] = 'c'*32
    elif damage == 'epoch': d['record']['epoch'] = 8
    elif damage == 'bool_generation': d['record']['generation_identity']['generation_id'] = True
    elif damage == 'old_binding_rank': d['record']['carrier_binding']['tensor_parallel_rank'] = 1
    elif damage == 'bool_topology': d['record']['generation_identity']['topology_fingerprint']['tensor_parallel_rank'] = False
    elif damage == 'missing_source': del d['record']['generation_identity']['source_identity']
    elif damage == 'requests': d['record']['carrier_binding']['ordered_request_fingerprint'] = ['another']
    elif damage == 'quarantine': d['record']['quarantine_calls'] = []
    elif damage == 'not_retained': d['state']['active_backing_retained'] = False
    elif damage == 'scope_entered': d['next_scope_guard']['body_entered'] = True
    elif damage == 'unexpected_error': t['exception_type'] = 'RuntimeError'
    elif damage == 'export_failed': t['probe_export_error'] = 'disk error'
    elif damage == 'post_device': t['post_fault_device_operations'] = 'D2H'
    elif damage == 'host_return_completion': d['record']['completion'] = 'DONE_FROM_UPDATE_RETURN'
    elif damage == 'wrong_query': d['record']['descriptor'] = [1,8]
    else: d['record']['backing']['window_block_table']['device'] = 'npu:1'
    with pytest.raises((ValueError,KeyError)):
        tool.validate_unwind_document(d,t,w,row)


def test_execute_error_export_preserves_original_error_and_restores_host_wrapper(tmp_path):
    failure = RuntimeError('original unrelated/native error must remain first')
    calls = []
    def original(*args,**kwargs):
        raise failure
    original_sample = lambda *args, **kwargs: 'sample result'
    runner = N(execute_model=original, sample_tokens=original_sample)
    class Probe:
        def __exit__(self,*args):
            calls.append(args[1])
            raise OSError('Host export failure')
    path = tmp_path/'terminal.json'
    tool.install_execute_error_export(runner,Probe(),path,dict(rank=0))
    with pytest.raises(RuntimeError) as caught:
        runner.execute_model('real-input')
    assert caught.value is failure and calls == [failure]
    assert runner.execute_model is original and runner.sample_tokens is original_sample
    row = json.loads(path.read_text())
    assert row['exception_message'] == str(failure) and 'Host export failure' in row['probe_export_error']
    assert row['post_fault_device_operations'] == 'NONE_BY_THIS_WRAPPER'
    assert row['entrypoint'] == 'execute_model'
    assert row['guarded_entrypoints'] == ['execute_model', 'sample_tokens']


@pytest.mark.parametrize('nested', [False, True])
def test_proposal_in_sample_tokens_exports_once_after_python_unwind(tmp_path, monkeypatch, nested):
    failure = RuntimeError('proposal failed after execute_model forward')
    events = []
    runner = N()

    def propose():
        try:
            raise failure
        finally:
            events.append('proposal scope unwound')

    def sample(*args, **kwargs):
        assert args == ('sampling input',) and kwargs == dict(flag=True)
        return propose()

    def execute():
        events.append('forward returned')
        return runner.sample_tokens('sampling input', flag=True) if nested else 'forward result'

    runner.execute_model, runner.sample_tokens = execute, sample

    class Probe:
        def __exit__(self, kind, error, traceback):
            assert error is failure and events[-1] == 'proposal scope unwound'
            events.append('Host export')

    writes = []
    original_write = tool.write

    def write(path, row):
        writes.append(Path(path).name)
        original_write(path, row)

    monkeypatch.setattr(tool, 'write', write)
    monkeypatch.setattr(tool, 'rank_host_error_export_barrier', lambda payload: dict(status='Host only'))
    path = tmp_path/'terminal.json'
    tool.install_execute_error_export(runner, Probe(), path, dict(rank=0), payload={})
    if not nested:
        assert runner.execute_model() == 'forward result' and not path.exists()
    with pytest.raises(RuntimeError) as caught:
        if nested:
            runner.execute_model()
        else:
            runner.sample_tokens('sampling input', flag=True)
    assert caught.value is failure
    assert events == ['forward returned', 'proposal scope unwound', 'Host export']
    assert writes == ['terminal.json', 'host-error-barrier.json']
    assert runner.execute_model is execute and runner.sample_tokens is sample
    row = json.loads(path.read_text())
    assert row['entrypoint'] == 'sample_tokens' and 'probe_export_error' not in row


def test_successful_split_runner_preserves_results_without_export(tmp_path):
    runner = N(execute_model=lambda value: value+1, sample_tokens=lambda value: value*2)
    class Probe:
        def __exit__(self, *args):
            pytest.fail('successful runner must not export the probe')
    path = tmp_path/'terminal.json'
    tool.install_execute_error_export(runner, Probe(), path, dict(rank=0))
    assert runner.execute_model(3) == 4 and runner.sample_tokens(5) == 10
    assert not path.exists()


def test_missing_sampling_entrypoint_does_not_partially_install_guard(tmp_path):
    original = lambda: None
    runner = N(execute_model=original)
    with pytest.raises(AttributeError):
        tool.install_execute_error_export(runner, object(), tmp_path/'terminal.json', dict(rank=0))
    assert runner.execute_model is original


def test_initialized_failed_parent_has_no_post_fault_rpc_or_device_cleanup():
    tree = ast.parse(Path(tool.__file__).read_text())
    run = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
    handler = next(n for n in ast.walk(run) if isinstance(n,ast.ExceptHandler))
    calls = [ast.unparse(n.func) for n in ast.walk(handler) if isinstance(n,ast.Call)]
    assert 'isolate_failed_parent' in calls
    assert not any(x.startswith(('llm.','torch.')) for x in calls)
    assert any(isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='initialization_attempted'
               for t in n.targets) and isinstance(n.value,ast.Constant) and n.value.value is True for n in ast.walk(run))


def test_saved_preparation_peer_contradiction_and_timeout_are_rejected(tmp_path):
    row=payload(tmp_path,mode='preparation_reject');source=tmp_path/'source';pin=tmp_path/'pin'
    workers=[worker(rank,row,source,pin) for rank in range(2)]
    for w in workers:
        root=tmp_path/f"rank-{w['rank']}";root.mkdir();(root/'identity.json').write_text(json.dumps(w))
        record=dict(identity=fault_identity(w,row), status='INJECTED_BEFORE_NEW_PROPOSAL' if w['rank']==1
                    else 'PEER_HOST_PREPARATION_RETURNED', new_proposal_submitted=False,
                    exception='REPAIR41_PREPARATION:'+row['nonce'] if w['rank']==1 else None)
        (root/'preparation.json').write_text(json.dumps(record))
    kwargs=tool.fault_kwargs(row['profile'],row['tp'])
    campaign=dict(payload=row,kwargs=kwargs,config_sha256=hashlib.sha256(json.dumps(kwargs,sort_keys=True).encode()).hexdigest(),
        status='FAILED',startup_complete=True,failure_action='PARENT_EXIT74_NO_DEVICE_RECOVERY',
        post_failure_device_RPC='FORBIDDEN',native_partial_submission='NOT_SIMULATED',stage='ARM_RPC_PENDING',
        arm_rpc_returned=False,exception_type='RuntimeError',exception_message='Worker propagated selected rejection',workers=workers)
    execution=dict(returncode=74,signal=None,timeout=False)
    result=tool.check_saved_fault(campaign,execution,source=source,pin=pin)
    assert result['status'].startswith('PASS_RAW_') and result['ranks']==2
    campaign['arm_rpc_returned']=True
    with pytest.raises(ValueError):tool.check_saved_fault(campaign,execution,source=source,pin=pin)
    campaign['arm_rpc_returned']=False
    campaign['exception_type']='TimeoutError'
    with pytest.raises(ValueError):tool.check_saved_fault(campaign,execution,source=source,pin=pin)
    campaign['exception_type']='RuntimeError'
    peer=tmp_path/'rank-0/preparation.json';saved=peer.read_text();d=json.loads(saved);d['identity']['nonce']='c'*32;peer.write_text(json.dumps(d))
    with pytest.raises(ValueError):tool.check_saved_fault(campaign,execution,source=source,pin=pin)
    peer.write_text(saved);execution['timeout']=True
    with pytest.raises(ValueError):tool.check_saved_fault(campaign,execution,source=source,pin=pin)


def test_actual_absolute_rank_fault_cli_help_does_not_start_a_model(tmp_path):
    import subprocess
    import sys
    result=subprocess.run([sys.executable,str(Path(tool.__file__).resolve()),'--help'],cwd=tmp_path,
                          capture_output=True,text=True,timeout=30)
    assert result.returncode==0,result.stderr
    assert '--selected-rank' in result.stdout and '--model-profile' in result.stdout
    assert 'SAME point on ALL ranks' in ' '.join(result.stdout.split())


def test_host_error_export_index_is_bounded_and_rejects_another_invocation(tmp_path):
    row=payload(tmp_path);source=tmp_path/'source';pin=tmp_path/'pin'
    workers=[worker(rank,row,source,pin) for rank in range(2)]
    row['worker_processes']=[{key:w[key] for key in ['rank','pid','process_start_ticks']} for w in workers]
    for w in workers:
        root=tmp_path/f"rank-{w['rank']}";root.mkdir()
        (root/'terminal.json').write_text(json.dumps(dict(identity=fault_identity(w,row))))
    index=tool.rank_host_error_export_barrier(row,timeout=.01)
    assert index['status']=='ALL_RANK_HOST_ERROR_EXPORTS_PRESENT_NOT_DEVICE_COMPLETION'
    assert [p['rank'] for p in index['proofs']]==[0,1] and index['native_completion']=='NOT_PROVEN'
    path=tmp_path/'rank-1/terminal.json';original=path.read_text();bad=json.loads(original);bad['identity']['nonce']='c'*32
    path.write_text(json.dumps(bad))
    with pytest.raises(ValueError):tool.rank_host_error_export_barrier(row,timeout=.01)
    path.unlink()
    result=tool.rank_host_error_export_barrier(row,timeout=.001)
    assert result['status']=='HOST_EXPORT_TIMEOUT_ISOLATION_REQUIRED'


def test_all_rank_c1_artifacts_need_every_state_but_not_a_fabricated_duplicate_index(tmp_path):
    row=payload(tmp_path);source=tmp_path/'source';pin=tmp_path/'pin'
    workers=[worker(rank,row,source,pin) for rank in range(2)]
    row['worker_processes']=[{key:w[key] for key in ['rank','pid','process_start_ticks']} for w in workers]
    for w in workers:
        root=tmp_path/f"rank-{w['rank']}";root.mkdir()
        d,t=host_documents(w,row)
        for name,value in [('identity.json',w),('unwind.json',d),('terminal.json',t),
                           ('armed.json',dict(status='ALL_RANK_SAME_POINT_ARMED',identity=fault_identity(w,row)))]:
            (root/name).write_text(json.dumps(value))
    index=tool.rank_host_error_export_barrier(row,timeout=.01)
    index_path=tmp_path/'rank-0/host-error-barrier.json';index_path.write_text(json.dumps(index))
    kwargs=tool.fault_kwargs(row['profile'],row['tp'])
    campaign=dict(payload=row,kwargs=kwargs,config_sha256=hashlib.sha256(json.dumps(kwargs,sort_keys=True).encode()).hexdigest(),
        status='FAILED',startup_complete=True,failure_action='PARENT_EXIT74_NO_DEVICE_RECOVERY',
        post_failure_device_RPC='FORBIDDEN',native_partial_submission='NOT_SIMULATED',stage='GENERATE_PENDING',
        arm_rpc_returned=True,generate_returned=False,exception_type='RuntimeError',exception_message='Worker model error',
        workers=workers,generate_ns=5,end_ns=40)
    execution=dict(returncode=74,signal=None,timeout=False)
    result=tool.check_saved_fault(campaign,execution,source=source,pin=pin)
    assert result['ranks']==2 and all(c['status'].startswith('PASS_RAW_C1') for c in result['checks'])
    campaign['generate_returned']=True
    with pytest.raises(ValueError):tool.check_saved_fault(campaign,execution,source=source,pin=pin)
    campaign['generate_returned']=False
    damaged=copy.deepcopy(index);damaged['proofs'][1]=damaged['proofs'][0];index_path.write_text(json.dumps(damaged))
    with pytest.raises(ValueError):tool.check_saved_fault(campaign,execution,source=source,pin=pin)
    index_path.write_text(json.dumps(index));(tmp_path/'rank-1/unwind.json').unlink()
    with pytest.raises(OSError):tool.check_saved_fault(campaign,execution,source=source,pin=pin)
