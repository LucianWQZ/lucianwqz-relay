# SPDX-License-Identifier: Apache-2.0
"""Named real-CLI contracts. Fake configs/HTTP tests are never NPU evidence."""
import json

import pytest

from tools.p7x_graph_repair21_rank import digest
from tools.p7x_graph_repair44_method_service import method_configuration, method_serve_argv


def fixture(tmp_path, method):
    target=tmp_path/'target'; draft=tmp_path/'draft'; target.mkdir(); draft.mkdir()
    for directory in (target,draft):
        (directory/'config.json').write_text(json.dumps(dict(max_position_embeddings=32768,vocab_size=64)))
    if method=='eagle3':
        from tools.p7x_graph_repair13_eagle import CONTRACT
        schema='r5-eagle3-k3-fixture-v1'; contract=CONTRACT
    else:
        from tools.p7x_graph_repair12_contract import method_for_profile
        schema='r4-dflash-k15-q16-fixture-v1';contract=method_for_profile('dflash_k15_q16').document()
    path=tmp_path/'fixture.json';path.write_text(json.dumps(dict(schema=schema,method_contract=contract,
        target_model=str(target),draft_model=str(draft),files=[])))
    if method=='dflash':
        doc=json.loads(path.read_text());doc.update(method='dflash',K=15,Q=16,capture_sizes=[16,32,64],W=1024,block=128,TP=1)
        path.write_text(json.dumps(doc))
    return path


def test_actual_r4_dflash_schema_without_later_method_contract_is_not_modified(tmp_path):
    path=fixture(tmp_path,'dflash');doc=json.loads(path.read_text());del doc['method_contract']
    path.write_text(json.dumps(doc));before=path.read_bytes()
    result,_=method_configuration('dflash',path,digest(path),'G_ON')
    assert 'method_contract' not in result and path.read_bytes()==before
    from tools.p7x_graph_repair44_method_service import declared_method_contract
    contract=declared_method_contract('dflash',result)
    assert contract['k']==15 and contract['draft_query']==contract['target_query']==16
    assert contract['sample_from_anchor'] is False and contract['sample_offset']==1


@pytest.mark.parametrize('key,value',[('K',7),('Q',True),('TP',True),('W',2048),('capture_sizes',[16,32])])
def test_r4_native_fields_remain_exact_even_without_an_embedded_method_contract(tmp_path,key,value):
    path=fixture(tmp_path,'dflash');doc=json.loads(path.read_text());del doc['method_contract'];doc[key]=value
    path.write_text(json.dumps(doc))
    with pytest.raises((ValueError,KeyError)):method_configuration('dflash',path,digest(path),'G_ON')


@pytest.mark.parametrize('method,k,capture',[('dflash',15,[16,32,64]),('eagle3',3,[1,2,4,8,16])])
@pytest.mark.parametrize('arm',['G_OFF','G_ON','E_ON'])
def test_method_goes_through_standard_cli_with_its_own_contract(tmp_path,method,k,capture,arm):
    path=fixture(tmp_path,method)
    argv=method_serve_argv('python',8123,'named-model',arm,method=method,fixture=path,
                         fixture_sha256=digest(path),worker_provenance=True)
    assert argv[:4]==['python','-m','vllm.entrypoints.cli.main','serve']
    assert argv[4]==str(tmp_path/'target')
    spec=json.loads(argv[argv.index('--speculative-config')+1])
    assert spec['model']==str(tmp_path/'draft') and spec['method']==method
    assert spec['num_speculative_tokens']==k and spec['enforce_eager'] is (arm=='E_ON')
    compilation=json.loads(argv[argv.index('--compilation-config')+1])
    assert compilation==dict(cudagraph_mode='FULL_DECODE_ONLY',cudagraph_capture_sizes=capture)
    assert argv[argv.index('--max-model-len')+1]=='24576'
    additional=json.loads(argv[argv.index('--additional-config')+1])
    assert additional==({} if arm=='G_OFF' else dict(draft_window_size=1024))
    assert '--enforce-eager' not in argv
    assert argv[argv.index('--worker-extension-cls')+1].endswith('ServiceWorkerIdentity')
    assert '--no-async-scheduling' in argv and '--no-enable-prefix-caching' in argv


@pytest.mark.parametrize('damage',['fixture_hash','other_method','schema','causal_int','capacity','rope'])
def test_unreviewed_method_config_or_model_capacity_cannot_be_smuggled_into_service(tmp_path,damage):
    path=fixture(tmp_path,'dflash'); doc=json.loads(path.read_text());method='dflash';h=digest(path)
    if damage=='fixture_hash':h='0'*64
    elif damage=='other_method':method='eagle3'
    elif damage=='schema':doc['schema']='dspark-fallback';path.write_text(json.dumps(doc));h=digest(path)
    elif damage=='causal_int':doc['method_contract']['causal']=0;path.write_text(json.dumps(doc));h=digest(path)
    else:
        cfg=dict(max_position_embeddings=16384 if damage=='capacity' else 32768)
        if damage=='rope':cfg['rope_scaling']=dict(type='linear',factor=4)
        (tmp_path/'draft/config.json').write_text(json.dumps(cfg))
    with pytest.raises(ValueError):method_configuration(method,path,h,'G_ON')


def test_method_metadata_cannot_replace_source_identity_or_launch_a_server_first(tmp_path,monkeypatch):
    from types import SimpleNamespace
    from tools import p7x_graph_repair33_service as common

    path=fixture(tmp_path,'eagle3')
    requests=tmp_path/'requests.json'
    requests.write_text(json.dumps([dict(label='host-only',prompts=[dict(prompt_token_ids=[1])],max_tokens=256)]))
    admission=tmp_path/'admission.json';admission.write_text('{}')
    args=SimpleNamespace(admission=admission,expected_sha='a'*40,output=tmp_path/'output',requests=requests,
                         arm='G_ON',port=8123,worker_provenance=True)
    monkeypatch.setattr(common,'validate_admission',lambda *a,**k:dict(source_tree='b'*40,vllm_checkout='/fixed-pin'))

    def builder(python,port,name,arm,**kwargs):
        return method_serve_argv(python,port,name,arm,method='eagle3',fixture=path,
                                fixture_sha256=digest(path),**kwargs)

    def no_server(*a,**k):
        raise AssertionError('invalid identity metadata must be refused before server/model startup')

    monkeypatch.setattr(common.subprocess,'Popen',no_server)
    with pytest.raises(ValueError,match='must not replace'):
        common.run_service(args,server_argv_builder=builder,target_model=str(tmp_path/'target'),
                           extra_metadata=dict(source_sha='forged'))
