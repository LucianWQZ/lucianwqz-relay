# SPDX-License-Identifier: Apache-2.0
"""Requested flags cannot replace actual per-rank CP execution evidence."""
import copy
import json
from types import SimpleNamespace as N

import pytest

from tools import p7x_graph_repair50_glm_required_baseline as tool


def feature_rows(*, graph_window=False):
    feature = dict(profile=tool.PROFILE, async_scheduling=True, prefix_caching=True,
        chunked_prefill=True, sequence_parallel=True, dsa_cp=True, expert_parallel=True,
        flashcomm_requested=True, flashcomm_effective=True,
        draft_graph_flashcomm=True if graph_window else None,
        all2all_backend='allgather_reducescatter',
        capture_sizes=tool.SP_CAPTURE.copy(),
        pcp_size=1, dcp_size=1, target_layers=[dict(layer=f'target.{i}',
            builder=tool.CP_MODULE+'AscendSFADSACPMetadataBuilder',
            impl=tool.CP_MODULE+'AscendSFADSACPImpl') for i in range(78)],
        actual_metadata_audit=dict(calls=3, cp_context_returns=3,
            samples=[dict(metadata=tool.CP_MODULE+'AscendSFADSACPMetadata',dsa_cp_context_present=True)]))
    return [dict(required_features=copy.deepcopy(feature)) for _ in range(16)]


def test_only_official_window_off_all_feature_graph_baseline_can_be_requested():
    argv=tool.required_serve_argv('/python',18152,'required','G_OFF',worker_provenance=True)
    assert argv[:4]==['/python','-m','vllm.entrypoints.cli.main','serve']
    assert '--async-scheduling' in argv and '--no-async-scheduling' not in argv
    assert '--enable-prefix-caching' in argv and '--enable-chunked-prefill' in argv
    assert json.loads(argv[argv.index('--additional-config')+1])==dict(
        enable_dsa_cp=True,enable_flashcomm1=True,multistream_overlap_shared_expert=True)
    assert json.loads(argv[argv.index('--speculative-config')+1])['enforce_eager'] is False
    assert argv[argv.index('--tensor-parallel-size')+1]=='16'
    assert argv[argv.index('--worker-extension-cls')+1]==tool.EXTENSION
    for arm in ('G_ON','E_ON'):
        with pytest.raises(ValueError,match='Window OFF'):
            tool.required_serve_argv('/python',18152,'required',arm,worker_provenance=True)


def test_registered_cp_inventory_is_separate_from_actual_non_capture_builds():
    rows=feature_rows()
    assert tool.validate_required_features(rows,require_execution=True)['actual_metadata_execution_required'] is True
    rows[-1]['required_features']['actual_metadata_audit']=dict(calls=0,cp_context_returns=0,samples=[])
    tool.validate_required_features(rows,require_execution=False)
    with pytest.raises(ValueError,match='execution evidence'):
        tool.validate_required_features(rows,require_execution=True)


@pytest.mark.parametrize('damage',['missing_rank','disabled_async','disabled_sp','disabled_cp',
    'wrong_backend','flashcomm_not_requested','flashcomm_not_effective','unexpected_graph_flashcomm',
    'bool_pcp','pcp_substitution','dcp_substitution','missing_layer','duplicate_layer','ordinary_builder',
    'ordinary_impl','bool_count','unknown_cp','wrong_return','observation_error'])
def test_partial_flags_or_wrong_actual_cp_path_cannot_claim_required_features(damage):
    rows=feature_rows();f=rows[-1]['required_features'];audit=f['actual_metadata_audit']
    if damage=='missing_rank':rows.pop()
    elif damage=='disabled_async':f['async_scheduling']=False
    elif damage=='disabled_sp':f['sequence_parallel']=False
    elif damage=='disabled_cp':f['dsa_cp']=False
    elif damage=='wrong_backend':f['all2all_backend']='flashinfer_all2allv'
    elif damage=='flashcomm_not_requested':f['flashcomm_requested']=False
    elif damage=='flashcomm_not_effective':f['flashcomm_effective']=False
    elif damage=='unexpected_graph_flashcomm':f['draft_graph_flashcomm']=True
    elif damage=='bool_pcp':f['pcp_size']=True
    elif damage=='pcp_substitution':f['pcp_size']=16
    elif damage=='dcp_substitution':f['dcp_size']=16
    elif damage=='missing_layer':f['target_layers'].pop()
    elif damage=='duplicate_layer':f['target_layers'][-1]['layer']=f['target_layers'][0]['layer']
    elif damage=='ordinary_builder':f['target_layers'][-1]['builder']='AscendSFAMetadataBuilder'
    elif damage=='ordinary_impl':f['target_layers'][-1]['impl']='AscendSFAImpl'
    elif damage=='bool_count':audit['calls']=True
    elif damage=='unknown_cp':audit['cp_context_returns']=2
    elif damage=='wrong_return':audit['samples'][0]['metadata']='AscendSFAMetadata'
    else:audit['samples'][0]['host_observation_error']='wrong signature'
    with pytest.raises(ValueError):tool.validate_required_features(rows,require_execution=True)


def test_metadata_observer_preserves_real_return_and_exception_without_tensor_access():
    cp=object();error=RuntimeError('real builder failure')
    class Builder:
        def build(self,common_prefix_len,common_attn_metadata):
            if common_prefix_len==-1:raise error
            return N(dsa_cp_context=cp)
    builder=Builder();worker=N();tool.install_metadata_audit(worker,[builder])
    common=N(num_reqs=3,num_actual_tokens=4011,num_input_tokens=4096,max_query_len=2049)
    for _ in range(20):assert builder.build(0,common).dsa_cp_context is cp
    with pytest.raises(RuntimeError) as caught:builder.build(-1,common)
    assert caught.value is error
    audit=worker._mrv2_required_metadata
    assert audit['calls']==audit['cp_context_returns']==20 and len(audit['samples'])==16
    assert audit['samples'][0]['num_actual_tokens']==4011
