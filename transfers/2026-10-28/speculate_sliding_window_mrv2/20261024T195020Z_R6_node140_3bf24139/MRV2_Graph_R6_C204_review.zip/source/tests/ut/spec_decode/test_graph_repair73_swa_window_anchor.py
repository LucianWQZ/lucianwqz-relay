# SPDX-License-Identifier: Apache-2.0
"""Finite current-generation SWA/Full headers; these are CPU contracts only."""
import copy
import json
import subprocess
import sys

import pytest

from tests.ut.spec_decode.test_graph_repair70_qwen36_swa_anchor import worker
from tools import p7x_graph_repair73_qwen36_swa_window_anchor as anchor


def evidence():
    row = worker()
    names = row['draft_layers']
    row.update(window_size=32768, window_provider_installed=True, submission_uncertain=False)
    profile = row['qwen36_profile']
    profile['draft_groups'] = [dict(global_group_id=10+i, layers=[name]) for i, name in enumerate(names)]
    profile['group_causal'] = [dict(global_group_id=10+i, causal=i < 5) for i in range(6)]
    profile['actual_draft_kernel_blocks'] = [dict(global_group_id=10+i, block_size=128) for i in range(6)]
    plan = dict(window=32768, query_width=8, full_gid=15, full_layers=names[-1:],
                native_groups=[dict(gid=10+i, layers=[name], window=4096, table_ptr=1000+i)
                               for i, name in enumerate(names[:-1])], truncated=False)
    record = dict(kind='WINDOW_CURRENT', generation=12, epoch=6, carrier_generation=12, carrier_epoch=6,
                  requests=['fixed-request'], row_phases=['pure_decode'], actual=1, padded=2,
                  descriptor=dict(mode='FULL', requests=2, tokens=16), block_span=128,
                  full_exact=[37000, 0], window_exact=[32776, 0], window_starts=[4224],
                  full_gid=15, positions_ptr=9000, query_ptr=9100,
                  full_read=dict(layer=names[-1], table_ptr=3000, bank_table_ptr=3000,
                                 seq_lens=[32776, 0], causal=False, slot_ptr=4000,
                                 canonical_slot_ptr=4000, positions_ptr=9000, query_ptr=9100),
                  native_layers=[dict(layer=name, gid=10+i, native_window=4096, causal=True,
                                      table_ptr=1000+i, canonical_table_ptr=1000+i,
                                      seq_lens=[37000, 0], slot_ptr=5000+i, canonical_slot_ptr=5000+i,
                                      positions_ptr=9000, query_ptr=9100)
                                 for i, name in enumerate(names[:-1])])
    plan['records'] = [record]
    row['swa_extra_window'] = plan
    return row, record


@pytest.mark.parametrize('damage', [None, 'native_exact', 'native_table', 'native_slot', 'native_causal',
                                  'full_bank', 'full_exact', 'stale', 'missing', 'duplicate',
                                  'bool_padding', 'missed_crop', 'continuing_crop', 'query', 'request'])
def test_actual_bound_rows_preserve_native_and_window_contract(damage):
    row, record = evidence()
    native = record['native_layers'][0]
    if damage == 'native_exact': native['seq_lens'] = record['window_exact'][:]
    elif damage == 'native_table': native['table_ptr'] = record['full_read']['bank_table_ptr']
    elif damage == 'native_slot': native['slot_ptr'] = 4000
    elif damage == 'native_causal': native['causal'] = False
    elif damage == 'full_bank': record['full_read']['table_ptr'] += 1
    elif damage == 'full_exact': record['full_read']['seq_lens'] = record['full_exact'][:]
    elif damage == 'stale': record['carrier_generation'] -= 1
    elif damage == 'missing': record['native_layers'].pop()
    elif damage == 'duplicate': record['native_layers'][-1] = copy.deepcopy(native)
    elif damage == 'bool_padding': record['full_exact'][-1] = False
    elif damage == 'missed_crop':
        record['window_starts'] = [0]
        record['window_exact'] = record['full_exact'][:]
        record['full_read']['seq_lens'] = record['window_exact'][:]
    elif damage == 'continuing_crop': record['row_phases'] = ['prefill_continuing']
    elif damage == 'query': native['query_ptr'] += 1
    elif damage == 'request': record['requests'].append('extra-row')
    if damage is None:
        anchor.validate_worker(row, 4)
    else:
        with pytest.raises(ValueError): anchor.validate_worker(row, 4)


def test_snapshot_replay_generation_cannot_repeat_or_skip_a_reader_group():
    row, record = evidence()
    row['swa_extra_window']['records'].append(copy.deepcopy(record))
    with pytest.raises(ValueError, match='stale'): anchor.validate_worker(row, 4)
    row, _ = evidence()
    row['swa_extra_window']['native_groups'].append(copy.deepcopy(row['swa_extra_window']['native_groups'][0]))
    with pytest.raises(ValueError, match='selection'): anchor.validate_worker(row, 4)


def test_fixed_on_load_matches_original_long_request_contract():
    kw = anchor.build_kwargs(4, window_on_review=True)
    assert kw['additional_config'] == dict(draft_window_size=32768, draft_window_graph_replicated_tp_review=True)
    assert kw['speculative_config']['num_speculative_tokens'] == 7
    assert not kw['speculative_config']['enforce_eager']
    assert kw['compilation_config']['cudagraph_capture_sizes'] == [8, 16, 32]
    assert kw['max_model_len'] == 40960
    assert anchor.REQUESTS == (('long-one', (36865,)), ('mixed-three', (36865, 8193, 387)))
    assert anchor.OUTPUT_TOKENS == 256
    with pytest.raises(ValueError): anchor.build_kwargs(4)


def test_continuing_prefill_is_saved_as_baseline_not_stale_window_carrier():
    from types import SimpleNamespace as N
    from tests.ut.spec_decode.test_draft_window_eager import _input_batch
    batch = _input_batch(req_ids=('continuing',), mapping=(0,), upper=(4000,))
    batch.num_computed_prefill_tokens_np[:] = 0
    batch.num_scheduled_tokens[:] = 128
    batch.prefill_len_np[:] = 36865
    batch.is_prefilling_np[:] = True
    batch.has_prefill = True
    spec = N(input_batch=batch, _draft_window_bypass_active=True, _draft_window_prefill_bypass_active=True)
    record = anchor.bound_record(spec, N(cg_mode=N(name='FULL'), num_reqs=1, num_tokens=8))
    row, _ = evidence()
    row['swa_extra_window']['records'].insert(0, record)
    anchor.validate_worker(row, 4)
    assert 'generation' not in record and 'epoch' not in record
    record['generation'] = 12
    with pytest.raises(ValueError, match='relabelled'): anchor.validate_worker(row, 4)


def test_offline_phase_vocabulary_matches_fixed_worker_and_no_native_import(tmp_path):
    from vllm_ascend.worker.v2.spec_decode.draft_window_nongraph import DraftWindowRowPhase
    assert anchor.ROW_PHASES == {p.value for p in DraftWindowRowPhase}
    row, _ = evidence()
    path = tmp_path/'worker.json'
    path.write_text(json.dumps(row))
    code = ('import json,sys;from tools.p7x_graph_repair73_qwen36_swa_window_anchor import validate_worker;'
            'validate_worker(json.load(open(sys.argv[1])),4);'
            'assert "vllm_ascend.device.device_op" not in sys.modules;print("PASS_CPU_ONLY_WORKER_HEADERS")')
    result = subprocess.run([sys.executable, '-c', code, str(path)], capture_output=True, text=True, timeout=45)
    assert result.returncode == 0, result.stderr
    assert 'PASS_CPU_ONLY_WORKER_HEADERS' in result.stdout


@pytest.mark.parametrize('damage',[None,'scope','live','prefill','generation','requests','bucket'])
def test_explicit_dp_dummy_never_becomes_a_business_window_generation(damage):
    row,_=evidence()
    record=dict(kind='BASELINE_DP_DUMMY',dp_size=2,scope_marker=True,no_live_generation=True,
                prefill_bypass=False,descriptor=dict(mode='FULL',requests=1,tokens=8))
    row['swa_extra_window']['records'].insert(0,record)
    if damage=='scope':record['scope_marker']=False
    elif damage=='live':record['no_live_generation']=False
    elif damage=='prefill':record['prefill_bypass']=True
    elif damage=='generation':record['generation']=12
    elif damage=='requests':record['requests']=['business']
    elif damage=='bucket':record['descriptor']['tokens']=16
    with pytest.raises(ValueError):anchor.validate_worker(row,4)  # DP1 remains strict.
    if damage is None:anchor.validate_worker(row,4,allow_dp_dummy=True)
    else:
        with pytest.raises(ValueError):anchor.validate_worker(row,4,allow_dp_dummy=True)
