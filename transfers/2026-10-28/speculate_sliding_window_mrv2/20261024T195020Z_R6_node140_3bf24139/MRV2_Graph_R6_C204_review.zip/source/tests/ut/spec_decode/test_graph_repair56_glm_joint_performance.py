# SPDX-License-Identifier: Apache-2.0
import asyncio
import copy
import io
import json
from pathlib import Path
import subprocess
import sys

import pytest

from tools import p7x_graph_repair56_glm_joint_performance as tool
from tests.ut.spec_decode.test_graph_repair40_glm_performance import metrics


def test_absolute_performance_cli_bootstraps_before_asyncio_import():
    source = Path(__file__).resolve().parents[3]
    result = subprocess.run([sys.executable, str(source / "tools/p7x_graph_repair56_glm_joint_performance.py"),
                             "--help"], cwd=source, capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stderr
    assert "--repetition" in result.stdout and "--order-position" in result.stdout


@pytest.mark.parametrize("arm", ["G_OFF", "G_ON", "E_ON"])
def test_joint_three_arm_configuration_keeps_target_graph_and_all_features(arm):
    argv = tool.joint_serve_argv("/python", 18170, "measured", arm, worker_provenance=True)
    spec = json.loads(argv[argv.index("--speculative-config") + 1])
    additional = json.loads(argv[argv.index("--additional-config") + 1])
    capture = json.loads(argv[argv.index("--compilation-config") + 1])
    assert spec["num_speculative_tokens"] == 8 and spec["method"] == "dspark"
    assert spec["enforce_eager"] is (arm == "E_ON")
    assert "--enforce-eager" not in argv
    assert capture == dict(cudagraph_mode="FULL_DECODE_ONLY", cudagraph_capture_sizes=[16, 32, 48])
    assert all(additional[key] is True for key in (
        "enable_dsa_cp", "enable_flashcomm1", "multistream_overlap_shared_expert"))
    assert additional.get("draft_window_size") == (None if arm == "G_OFF" else 1024)
    assert additional.get("draft_window_graph_replicated_tp_review") is (True if arm == "G_ON" else None)
    assert additional.get("draft_window_parallel_eager_review") is (True if arm == "E_ON" else None)
    assert "--async-scheduling" in argv and "--enable-prefix-caching" in argv
    assert "--enable-chunked-prefill" in argv and "--enable-per-request-metrics" in argv
    assert argv[argv.index("--per-request-spec-decode-metrics") + 1] == "detailed"


def test_six_orders_are_balanced_and_wrong_or_boolean_order_is_rejected():
    positions = {arm: [] for arm in ("G_OFF", "G_ON", "E_ON")}
    for repetition, order in enumerate(tool.THREE_ARM_ORDERS, 1):
        for position, arm in enumerate(order, 1):
            tool.validate_order(arm, repetition, position)
            positions[arm].append(position)
            with pytest.raises(ValueError):
                tool.validate_order(arm, repetition, position % 3 + 1)
    assert all(sorted(values) == [1, 1, 2, 2, 3, 3] for values in positions.values())
    with pytest.raises(ValueError):
        tool.validate_order("G_OFF", True, 1)


def result(ident="one"):
    return dict(events=[dict(data=dict(usage={"completion_tokens": 256},
        metrics=dict(speculative_decoding=metrics(), ttft_ms=10)))],
        summary=dict(response_id=ident, usage=dict(prompt_tokens=257, completion_tokens=256,
            prompt_tokens_details=dict(cached_tokens=128)), elapsed_seconds=2,
            ttft_seconds=.01, mean_tpot_seconds=.007, tpot_definition="client first-to-last span",
            token_itl_distribution="NOT_AVAILABLE_SSE_BURSTS"))


def test_concurrent_elapsed_and_framework_acceptance_are_not_summed_over_ranks():
    document = dict(groups=[dict(phase="measured", label="mixed2", group_start_ns=10**9,
        group_end_ns=3 * 10**9, results=[result(), result("two")])])
    group = tool.performance_groups(document)[0]
    assert group["elapsed_seconds"] == 2  # Two concurrent request spans are not added.
    assert group["output_tokens_per_second"] == 256
    assert (group["accepted"], group["proposed"], group["verification_request_steps"]) == (22, 38, 6)
    assert group["requests"][0]["framework_metrics"]["ttft_ms"] == 10


@pytest.mark.parametrize("damage", ["missing", "duplicate", "bonus", "histogram", "proposal", "padding"])
def test_terminal_metrics_missing_or_inconsistent_counters_are_rejected(damage):
    row = copy.deepcopy(result())
    m = row["events"][0]["data"]["metrics"]["speculative_decoding"]
    if damage == "missing":
        row["events"][0]["data"].pop("metrics")
    elif damage == "duplicate":
        row["events"].append(copy.deepcopy(row["events"][0]))
    elif damage == "bonus":
        m["num_accepted_draft_tokens"] += 3
    elif damage == "histogram":
        m["acceptance_histogram"][0] += 1
    elif damage == "proposal":
        m["per_step_drafted"][-1] = 8
    else:
        m["num_draft_tokens"] *= 16
    with pytest.raises(ValueError):
        tool.terminal_metrics(row)


def test_host_counter_reset_is_between_full_warmup_and_measured_requests(monkeypatch, tmp_path):
    events = []

    async def request(*args, **kwargs):
        events.append("request")
        return result()

    class Response(io.BytesIO):
        status = 200

    def rpc(*args, **kwargs):
        events.append("reset")
        return Response(json.dumps(dict(results=[dict(rank=i, pid=1000 + i,
            reset="HOST_COUNTERS_ONLY_NO_DEVICE_OPERATION") for i in range(16)])).encode())

    monkeypatch.setattr(tool, "request", request)
    monkeypatch.setattr(tool.urllib.request, "urlopen", rpc)
    groups = [dict(label="one", max_tokens=256, prompts=[dict(prompt_token_ids=[17])])]
    rows = asyncio.run(tool.measured_client_groups("http://localhost", "model", groups, tmp_path))
    assert events == ["request", "reset", "request"]
    reset = json.loads((tmp_path / "measurement-counter-reset.json").read_text())
    assert rows[0]["group_end_ns"] <= reset["start_ns"] < reset["end_ns"] <= rows[1]["group_start_ns"]


def test_pending_eager_feature_source_is_not_assumed_from_argv(monkeypatch):
    from tests.ut.spec_decode.test_draft_window import (
        _attention_group, _block_tables, _p2_policy, _p2_vllm_config,
    )
    from tests.ut.spec_decode.test_draft_window_graph_characterization import _runtime_context
    from vllm_ascend.worker.v2.spec_decode import draft_window as source

    context = _runtime_context(graph_mode="NONE", tensor_parallel_size=16,
        async_scheduling=True, sequence_parallel=True, dsa_context_parallel=True,
        flashcomm=True, prefix_caching=True)
    monkeypatch.setattr(source, "build_draft_window_runtime_context", lambda *args: context)
    config = _p2_vllm_config(configured_k=8)
    with pytest.raises(NotImplementedError, match="SP|DSA|Async|async|sequence"):
        source.build_draft_window_source_capability(policy=_p2_policy("dspark"), runtime_route="dspark",
            attn_groups=[[_attention_group()]], block_tables=_block_tables(), causal=False,
            vllm_config=config)


def async_rank_sources():
    from types import SimpleNamespace
    from tools.p7x_graph_repair21_rank import eager_async_pool_snapshot

    rows = []
    for rank in range(16):
        runtimes = []
        for lane in range(2):
            topology = SimpleNamespace(tensor_parallel_rank=rank, tensor_parallel_size=16,
                graph_mode="NONE", async_scheduling=True, sequence_parallel=True,
                dsa_context_parallel=True, flashcomm=True, prefix_caching=True)
            runtimes.append(SimpleNamespace(execution_lane=lane, topology_fingerprint=topology,
                workspace=SimpleNamespace(window_block_table=SimpleNamespace(data_ptr=lambda lane=lane: 1000 + lane))))
        pool = eager_async_pool_snapshot(SimpleNamespace(
            _draft_window_async_pool=SimpleNamespace(capacity=2, _runtimes=runtimes)))
        generations = []
        for ordinal in range(3):
            lane = (rank + ordinal) % 2
            generations.append(dict(global_group_id=0, epoch=17 + ordinal, generation=40 + ordinal,
                execution_lane=lane, phase="parallel_proposal", step=0,
                requests=["request"], actual=1, padded=2, window_starts=[128], exact=[257, 0],
                tp_size=16, tp_rank=rank))
        rows.append(dict(rank=rank, eager_async_pool=pool, window_generations=generations))
    return rows


def test_async_rank_local_lane_counters_are_checked_without_becoming_global_generations():
    from tools.p7x_graph_repair40_glm_performance import validate_joint_eager_async_sources
    rows = async_rank_sources()
    assert rows[0]["window_generations"][0]["execution_lane"] != rows[1]["window_generations"][0]["execution_lane"]
    rows[1]["window_generations"][0]["generation"] = 0
    validate_joint_eager_async_sources(rows)


@pytest.mark.parametrize("damage", ["missing_pool", "shared_table", "shared_owner", "missing_lane",
    "foreign_rank", "hidden_async", "hidden_sp", "stale_epoch", "stale_generation", "foreign_lane"])
def test_async_owner_and_generation_damage_still_rejected(damage):
    from tools.p7x_graph_repair40_glm_performance import validate_joint_eager_async_sources
    rows = async_rank_sources()
    row = rows[1]
    if damage == "missing_pool":
        row.pop("eager_async_pool")
    elif damage == "shared_table":
        row["eager_async_pool"]["lanes"][1]["table_address"] = row["eager_async_pool"]["lanes"][0]["table_address"]
    elif damage == "shared_owner":
        row["eager_async_pool"]["lanes"][1]["runtime_id"] = row["eager_async_pool"]["lanes"][0]["runtime_id"]
    elif damage == "missing_lane":
        row["eager_async_pool"]["lanes"].pop()
    elif damage == "foreign_rank":
        row["eager_async_pool"]["lanes"][0]["tp_rank"] = 0
    elif damage in ("hidden_async", "hidden_sp"):
        row["eager_async_pool"]["lanes"][0]["async_scheduling" if damage == "hidden_async" else "sequence_parallel"] = False
    elif damage == "stale_epoch":
        row["window_generations"][1]["epoch"] = row["window_generations"][0]["epoch"]
    elif damage == "stale_generation":
        row["window_generations"][2]["generation"] = row["window_generations"][0]["generation"]
    else:
        row["window_generations"][0]["execution_lane"] = 2
    with pytest.raises(ValueError):
        validate_joint_eager_async_sources(rows)
