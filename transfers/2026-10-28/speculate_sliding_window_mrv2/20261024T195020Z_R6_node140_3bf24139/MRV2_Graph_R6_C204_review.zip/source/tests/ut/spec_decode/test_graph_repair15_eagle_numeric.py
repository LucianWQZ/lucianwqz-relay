# SPDX-License-Identifier: Apache-2.0
"""Independent literal boundary fixtures and damaged numerical/storage evidence."""
import copy

import pytest
import torch

from tools.p7x_graph_repair15_eagle_numeric import canonical_window, canonical_slots
from tools.p7x_graph_repair15_eagle_numeric_check import validate_sample, check_collection
from tools.p7x_graph_repair6_storage import CollectionWriter


def specimen():
    identity = dict(source_sha="a" * 40,
                    source_tree="b" * 40,
                    process_id=12,
                    engine_id=13,
                    run_id="host-test-not-device",
                    case_id="EAGLE3_NUMERIC",
                    attempt_id="1",
                    driver_mode="B-observer-off")
    layer = "draft.layer"
    full = torch.arange(1, 65, dtype=torch.int32).reshape(1, 64)
    table = torch.tensor([[1, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)
    inputs = dict(input_ids=torch.tensor([11, 12, 13, 14], dtype=torch.int32),
                  positions=torch.tensor([60, 61, 62, 63], dtype=torch.int64),
                  hidden_states=torch.ones((4, 8), dtype=torch.bfloat16),
                  full_exact=torch.tensor([64], dtype=torch.int32),
                  query_start_loc=torch.tensor([0, 4], dtype=torch.int32),
                  target_positions=torch.tensor([60, 61, 62, 63], dtype=torch.int64),
                  last_token_indices=torch.tensor([3], dtype=torch.int64))
    slots = torch.tensor([188, 189, 190, 191], dtype=torch.int64)
    output = torch.arange(32, dtype=torch.bfloat16).reshape(4, 8)
    kv = {f"draft.layer/{i}": torch.zeros((3, 128, 1, 1), dtype=torch.bfloat16) for i in (0, 1)}
    header = dict(
        identity=identity,
        groups=dict(short=1, long=3, returned=4),
        layers=[layer],
        max_model_len=8192,
        slot_dtype="torch.int64",
        expected_samples=9,
        numeric_schema="r5-eagle3-continuous-v5",
        gpu_query_contract="CAPTURE_AND_RUNTIME_OWNED_FULL_INPUT_QUERY_FIA_HOST_PADDED_SEPARATE",
        first_pass_input_contract="PINNED_ACCEPTED_PREFIX_WITH_TARGET_FULL_WRITE_GRID",
        global_group_id=0,
        kv_write_contract=dict(backend="vllm_ascend.attention.attention_v1.AscendAttentionBackend",
                               forward_includes_kv_cache_update=True,
                               consumed_field="AscendMetadata.slot_mapping",
                               forward_context_slot_mapping="RETAINED_BUT_UNUSED_BY_THIS_BACKEND"),
        tolerance=dict(atol=0.0, rtol=0.0),
        hidden_contract=dict(width=8, dtype="torch.bfloat16"),
        kv_inventory={f"draft.layer/{i}": dict(shape=[100, 128, 1, 1], dtype="torch.bfloat16")
                      for i in (0, 1)},
        scope="CAPTURED_D2D_SNAPSHOTS_AND_SERIAL_EAGER_REFERENCE")
    record = dict(status="PASS_SCOPED_EAGLE3_CONTINUOUS",
                  group="short",
                  active=1,
                  first_pass=True,
                  descriptor=[1, 4],
                  identity=dict(identity, generation=6, epoch=2, step=0),
                  runtime_identity=dict(generation_id=6,
                                        mapping_epoch=2,
                                        step=0,
                                        method="eagle3",
                                        actual_request_count=1,
                                        padded_request_count=1,
                                        ordered_request_fingerprint=["req"]),
                  l0=[64],
                  ends=[64],
                  valid=[2],
                  canonical_table=full,
                  selected_blocks=[0, 1, 2],
                  oracle=[dict(L0=64, H=67, S=0, E=64, V=64, columns=[0, 1])],
                  inputs=inputs,
                  reference_inputs=copy.deepcopy(inputs),
                  actual_reads={layer: dict(table=table, exact=torch.tensor([64], dtype=torch.int32))},
                  reference_metadata={
                      layer:
                      dict(table=table.clone(),
                           exact=torch.tensor([64], dtype=torch.int32),
                           slot=slots.clone(),
                           query=inputs["query_start_loc"].clone(),
                           fia_query=[4],
                           causal=True,
                           table_address=300)
                  },
                  capture_identity=dict(backing_identity=dict(window_block_table=dict(data_ptr=200)),
                                        fingerprint=dict(global_group_id=0)),
                  actual_slots={layer: slots},
                  forward_context_slots={layer: torch.zeros(4, dtype=torch.int64)},
                  captured_full_input_queries={layer: torch.tensor([0, 4], dtype=torch.int32)},
                  runtime_queries={layer: inputs["query_start_loc"]},
                  actual_fia_query={layer: [4]},
                  actual_causal={layer: True},
                  graph=(output, output.clone()),
                  reference=(output.clone(), output.clone()),
                  pre_kv=kv,
                  reference_pre_kv=copy.deepcopy(kv),
                  graph_post_kv=copy.deepcopy(kv),
                  reference_post_kv=copy.deepcopy(kv),
                  reference_call=dict(mode="NONE",
                                      function="pinned AutoRegressiveSpeculator._run_model",
                                      start_ns=10,
                                      end_ns=20,
                                      input_pointers={
                                          k: 1000 + i
                                          for i, k in enumerate(inputs)
                                      },
                                      captured_input_pointers={
                                          k: 2000 + i
                                          for i, k in enumerate(inputs)
                                      }))
    return record, header


def test_frozen_proposal_horizon_differs_from_per_step_last_window():
    full = torch.arange(100, 164, dtype=torch.int32).reshape(1, 64)
    for end, visible in [(1149, 1021), (1150, 1022), (1151, 1023)]:
        table, lengths, rows = canonical_window(full, [1149], [end], [10], 1, 1, 9)
        assert rows == [dict(L0=1149, H=1152, S=128, E=end, V=visible, columns=[1, 9])]
        assert lengths == [visible]
        assert table.tolist() == [[101, 102, 103, 104, 105, 106, 107, 108, 0]]
        assert max(end - 1024, 0) // 128 == 0  # Wrong per-step rule would choose another bank.
    assert canonical_slots(full, torch.tensor([129, 130], dtype=torch.int64), torch.tensor([0, 2], dtype=torch.int32),
                           1, 2).tolist() == [12929, 12930]


def test_complete_literal_sample_and_content_address_dedup_are_valid():
    record, header = specimen()
    assert validate_sample(record, header)["numeric_match"] is True
    # Identical bytes are allowed; reference provenance remains a separate call.
    assert torch.equal(record["graph"][0], record["reference"][0])


def test_pinned_rejected_tail_does_not_redefine_full_write_grid():
    record, header = specimen()
    for inputs in (record["inputs"], record["reference_inputs"]):
        inputs["positions"] = torch.tensor([60, 1, 2, 3], dtype=torch.int64)
        inputs["last_token_indices"] = torch.tensor([0], dtype=torch.int64)
    # Old diagnostic reconstructed writes from the unrefreshed tail, and
    # rejected this legitimate pinned prefix. All four actual slots still
    # have to match the Target Full grid, including the rejected tail.
    old = canonical_slots(record["canonical_table"], record["inputs"]["positions"], record["inputs"]["query_start_loc"],
                          1, 4)
    assert old.tolist() == [188, 129, 130, 131]
    assert old.tolist() != record["actual_slots"]["draft.layer"].tolist()
    assert validate_sample(record, header)["numeric_match"] is True
    damaged = copy.deepcopy(record)
    damaged["actual_slots"]["draft.layer"][1] = 129
    with pytest.raises(ValueError, match="Full absolute write slots"):
        validate_sample(damaged, header)


def test_literal_c52_failed_grid_is_not_draft_rejected_tail():
    full = torch.tensor([[27, 22, 23]], dtype=torch.int32)
    query = torch.tensor([0, 4], dtype=torch.int32)
    target = torch.tensor([257, 258, 259, 260], dtype=torch.int64)
    draft = torch.tensor([257, 1, 2, 3], dtype=torch.int64)
    assert canonical_slots(full, target, query, 1, 4, dtype=torch.int32).tolist() == [2945, 2946, 2947, 2948]
    assert canonical_slots(full, draft, query, 1, 4, dtype=torch.int32).tolist() == [2945, 3457, 3458, 3459]


@pytest.mark.parametrize("damage", ["valid_prefix", "target_grid", "last_index", "missing", "dtype"])
def test_prefix_contract_rejects_damaged_evidence(damage):
    r, h = specimen()
    if damage == "valid_prefix": r["inputs"]["positions"][0] = 1
    if damage == "target_grid": r["inputs"]["target_positions"][3] = 1
    if damage == "last_index": r["inputs"]["last_token_indices"][0] = 4
    if damage == "missing": del r["inputs"]["last_token_indices"]
    if damage == "dtype":
        r["inputs"]["target_positions"] = r["inputs"]["target_positions"].int()
    r["reference_inputs"] = copy.deepcopy(r["inputs"])
    with pytest.raises(ValueError):
        validate_sample(r, h)


@pytest.mark.parametrize("damage", ["write_path", "slot_dtype", "group"])
def test_exact_consumed_write_operand_contract_rejects_wrong_metadata(damage):
    record, header = specimen()
    if damage == "write_path":
        header["kv_write_contract"]["forward_includes_kv_cache_update"] = False
    if damage == "slot_dtype":
        record["actual_slots"]["draft.layer"] = record["actual_slots"]["draft.layer"].int()
    if damage == "group":
        record["capture_identity"]["fingerprint"]["global_group_id"] = 1
    with pytest.raises(ValueError):
        validate_sample(record, header)


@pytest.mark.parametrize(
    "damage", ["dtype", "epoch", "read", "slots", "causal", "reference_graph", "alias", "pre_kv", "nonfinite"])
def test_contract_damage_is_rejected_even_if_output_bytes_match(damage):
    r, h = specimen()
    if damage == "dtype":
        r["inputs"]["input_ids"] = r["inputs"]["input_ids"].long()
    if damage == "epoch": r["runtime_identity"]["mapping_epoch"] += 1
    if damage == "read": r["actual_reads"]["draft.layer"]["table"][0, 0] = 2
    if damage == "slots": r["actual_slots"]["draft.layer"][0] = 0
    if damage == "causal": r["actual_causal"]["draft.layer"] = False
    if damage == "reference_graph": r["reference_call"]["mode"] = "FULL"
    if damage == "alias":
        r["reference_call"]["input_pointers"] = r["reference_call"]["captured_input_pointers"]
    if damage == "pre_kv":
        r["reference_pre_kv"]["draft.layer/0"][0, 0, 0, 0] = 1
    if damage == "nonfinite": r["graph"][0][0, 0] = float("nan")
    with pytest.raises(ValueError):
        validate_sample(r, h)


def test_durable_numeric_mismatch_is_not_overwritten_by_missing_later_samples(tmp_path):
    record, header = specimen()
    record["graph"][0][0, 0] += 1
    record["status"] = "NUMERIC_MISMATCH"
    path = tmp_path / "numeric.json"
    writer = CollectionWriter(path, header, max_bytes=8 << 20)
    writer.start(record["identity"])
    writer.finish(record)
    writer.close("EXECUTION_FAILED")
    result = check_collection(path, header["identity"])
    assert result["status"] == "NUMERIC_MISMATCH" and len(result["samples"]) == 1


def test_one_valid_sample_cannot_claim_complete_nine_consumer_acceptance(tmp_path):
    r, h = specimen()
    path = tmp_path / "numeric.json"
    writer = CollectionWriter(path, h, max_bytes=8 << 20)
    writer.start(r["identity"])
    writer.finish(r)
    writer.close("COMPLETE")
    result = check_collection(path, h["identity"])
    assert result["status"] == "INVALID_EVIDENCE" and "nine-consumer" in result["error"]


def test_shared_graph_and_reference_error_cannot_hide_illegal_kv_write():
    record, header = specimen()
    # Both arms carry the identical wrong outside-slot byte change. Numerical
    # equality alone would pass; the independently computed Full-slot mask fails.
    for side in ("graph_post_kv", "reference_post_kv"):
        record[side]["draft.layer/0"][0, 7, 0, 0] = 1
    result = validate_sample(record, header)
    assert result["numeric_match"] is True
    assert result["write_scope_match"] is False
    assert result["write_scope_violations"][0]["first_physical_slots"] == [7]


def test_full_slot_write_mask_allows_only_declared_token_offsets():
    record, header = specimen()
    # Physical slot188 is selected block1 offset60, explicitly declared.
    for side in ("graph_post_kv", "reference_post_kv"):
        record[side]["draft.layer/0"][1, 60, 0, 0] = 1
    result = validate_sample(record, header)
    assert result["numeric_match"] and result["write_scope_match"]
    for side in ("graph_post_kv", "reference_post_kv"):
        record[side]["draft.layer/1"][1, 59, 0, 0] = 1
    assert not validate_sample(record, header)["write_scope_match"]
