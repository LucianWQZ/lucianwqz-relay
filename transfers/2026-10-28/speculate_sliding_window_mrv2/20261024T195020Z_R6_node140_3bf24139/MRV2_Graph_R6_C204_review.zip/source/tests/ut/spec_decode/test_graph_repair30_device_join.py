# SPDX-License-Identifier: Apache-2.0
import json

import pytest

from tools.p7x_graph_repair30_device_join import (
    collect_association, validate_association, validate_service_process_environment,
)


def fixture(tmp_path):
    worker = dict(rank=0, pid=201, process_start_ticks="999", nspid=["201"], hostname="node")
    execution = dict(start_epoch=1, end_epoch=4)
    smi = tmp_path / "smi.txt"
    smi.write_text("| NPU Chip | Process id | Process name | Process memory(MB) | Process id in container |\n"
                   "| 4 0 | 601 | model | 100 | 201 |\n")
    event = dict(utc="1970-01-01T00:00:02+00:00",
                 event="HEARTBEAT",
                 candidate="a" * 40,
                 node="node",
                 worker_processes=[dict(pid=201, start_ticks="999")],
                 npu_observed_own_pids=[dict(host_pid="601", container_pid="201", board_chip="4 0")])
    events = tmp_path / "events.jsonl"
    events.write_text(json.dumps(event) + "\n")
    result = collect_association(worker, 8, ["4", "0"], [smi], events, source_sha="a" * 40, execution=execution)
    return worker, execution, smi, events, result


def test_single_visible_nspid_is_container_id_not_host_and_append_log_keeps_proof(tmp_path):
    worker, execution, _, events, result = fixture(tmp_path)
    assert result["host_pid"] == 601 and result["visible_nspid"] == ["201"]
    with events.open("a") as stream:
        stream.write(json.dumps(dict(unrelated="later event")) + "\n")
    assert validate_association(worker, 8, result, ["4", "0"], source_sha="a" * 40, execution=execution)


@pytest.mark.parametrize("damage", [
    "wrong_host", "wrong_container", "wrong_chip", "wrong_starttime", "wrong_namespace", "different_source",
    "outside_execution", "changed_management", "changed_event", "missing_process_proof"
])
def test_broken_or_unassociated_device_evidence_rejected(tmp_path, damage):
    worker, execution, smi, events, result = fixture(tmp_path)
    source = "a" * 40
    if damage == "wrong_host": result["host_pid"] = 201
    if damage == "wrong_container": result["pid"] = 202
    if damage == "wrong_chip": result["physical_id"] = 9
    if damage == "wrong_starttime": worker["process_start_ticks"] = "old"
    if damage == "wrong_namespace": worker["nspid"] = ["another"]
    if damage == "different_source": source = "b" * 40
    if damage == "outside_execution": execution["start_epoch"] = 3
    if damage == "changed_management": smi.write_text(smi.read_text().replace("601", "999"))
    if damage == "changed_event": events.write_text(events.read_text().replace("999", "998"))
    if damage == "missing_process_proof": result["observations"][0].pop("process_evidence")
    with pytest.raises((ValueError, KeyError)):
        validate_association(worker, 8, result, ["4", "0"], source_sha=source, execution=execution)


@pytest.mark.parametrize('pythonpath', [None, '/fixed/candidate:/pinned/vllm'])
def test_service_proc_environment_is_not_a_python_module_identity_claim(pythonpath):
    row = dict(environment={'ASCEND_RT_VISIBLE_DEVICES': '14'},
               actual_loaded_native=['/fixed/candidate/vllm_ascend/_C.cpython-311-aarch64-linux-gnu.so'])
    if pythonpath is not None:
        row['environment']['PYTHONPATH'] = pythonpath
    result = validate_service_process_environment(row, source='/fixed/candidate', physical=14)
    assert result['pythonpath'] == ('NOT_AVAILABLE_IN_PROC_ENVIRONMENT' if pythonpath is None else 'MATCH_FIXED_SOURCE')
    assert result['python_module_provenance'] == 'NOT_PROVEN_BY_ENVIRONMENT_OR_NATIVE_MAPPING'
    assert result['required_python_provenance'] == 'SEPARATE_HOST_WORKER_MODULE_IDENTITY_RPC'


@pytest.mark.parametrize('damage', ['old_source', 'empty_path', 'null_path', 'wrong_phy',
                                  'integer_phy', 'old_native', 'no_native'])
def test_service_missing_optional_env_does_not_accept_contradictions(damage):
    row = dict(environment={'ASCEND_RT_VISIBLE_DEVICES': '14'},
               actual_loaded_native=['/fixed/candidate/vllm_ascend/_C.so'])
    if damage == 'old_source': row['environment']['PYTHONPATH'] = '/old/candidate:/fixed/candidate'
    elif damage == 'empty_path': row['environment']['PYTHONPATH'] = ''
    elif damage == 'null_path': row['environment']['PYTHONPATH'] = None
    elif damage == 'wrong_phy': row['environment']['ASCEND_RT_VISIBLE_DEVICES'] = '8'
    elif damage == 'integer_phy': row['environment']['ASCEND_RT_VISIBLE_DEVICES'] = 14
    elif damage == 'old_native': row['actual_loaded_native'] = ['/old/candidate/vllm_ascend/_C.so']
    else: row['actual_loaded_native'] = []
    with pytest.raises(ValueError):
        validate_service_process_environment(row, source='/fixed/candidate', physical=14)
