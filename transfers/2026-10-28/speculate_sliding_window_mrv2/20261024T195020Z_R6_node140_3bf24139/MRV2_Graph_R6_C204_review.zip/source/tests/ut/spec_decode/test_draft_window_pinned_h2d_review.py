# SPDX-License-Identifier: Apache-2.0
"""Host logic only. Pinning/DMA are simulated here; actual NPU proof is separate."""
from types import SimpleNamespace as N
import copy
import gc
import weakref

import pytest
import torch

from vllm_ascend.ascend_config import (
    AscendConfig, validate_draft_window_eagle_pinned_h2d_review,
)
from vllm_ascend.worker.v2.spec_decode.draft_window import DraftWindowWorkspace
from tools.p7x_graph_repair13_eagle import validate_pinned_h2d_state


def workspace():
    return DraftWindowWorkspace(max_num_reqs=4, table_capacity_columns=9,
        table_template=torch.zeros(4, 32, dtype=torch.int32),
        valid_count_template=torch.zeros(4, dtype=torch.int32))


def simulate_pin_allocator(monkeypatch, *, pinned=True, alias=None):
    original = torch.empty
    def allocate(*args, **kwargs):
        assert kwargs.pop('pin_memory') is True
        return alias if alias is not None else original(*args, **kwargs)
    monkeypatch.setattr(torch, 'empty', allocate)
    monkeypatch.setattr(torch.Tensor, 'is_pinned', lambda self, *args, **kwargs: pinned)


def test_default_off_preserves_original_copy_and_never_allocates_pinned_source(monkeypatch):
    owner = workspace()
    source = torch.tensor([1024, 513], dtype=torch.int32)
    destination = torch.zeros_like(source)
    def forbidden(*args, **kwargs):
        raise AssertionError('default-off must not allocate a staging snapshot')
    monkeypatch.setattr(torch, 'empty', forbidden)
    owner._copy_length_source(destination, source, N(generation_id=3, mapping_epoch=4))
    assert torch.equal(source, destination)
    state = owner.pinned_h2d_review_state()
    assert state['enabled'] is False and state['submitted_copies'] == 0 and state['pending_sources'] == []
    owner.configure_pinned_h2d_staging_review(False)
    with pytest.raises(TypeError):owner.configure_pinned_h2d_staging_review('false')
    with pytest.raises(ValueError):owner.configure_pinned_h2d_staging_review(True)


def test_each_generation_gets_independent_exact_source_before_async_submission(monkeypatch):
    owner = workspace()
    # Bypass NPU-device admission explicitly for this CPU API simulation only.
    owner._pinned_h2d_staging_review = True
    source = torch.tensor([1024, 513], dtype=torch.int32)
    destination = torch.zeros_like(source)
    simulate_pin_allocator(monkeypatch)
    original_copy = torch.Tensor.copy_
    queue = []  # Simulates the framework allocator/stream holding the source.
    def enqueue(self, value, non_blocking=False):
        if self is destination:
            assert non_blocking is True
            queue.append(value)
            return self
        return original_copy(self, value, non_blocking=non_blocking)
    monkeypatch.setattr(torch.Tensor, 'copy_', enqueue)
    owner._copy_length_source(destination, source, N(generation_id=1, mapping_epoch=10))
    source.fill_(777)
    owner._copy_length_source(destination, source, N(generation_id=2, mapping_epoch=11))
    source.zero_()
    assert queue[0].tolist() == [1024, 513] and queue[1].tolist() == [777, 777]
    assert all(t.untyped_storage().data_ptr() != source.untyped_storage().data_ptr() for t in queue)
    assert owner._pinned_h2d_submissions == 2 and owner._pending_pinned_h2d_sources == []
    assert owner.pinned_h2d_review_state()['completion'] == 'NOT_INFERRED_FROM_COPY_RETURN'


@pytest.mark.parametrize('damage', ['unpinned', 'alias', 'dtype', 'shape'])
def test_staging_never_silently_casts_aliases_or_falls_back_after_bad_allocation(monkeypatch, damage):
    owner = workspace();owner._pinned_h2d_staging_review = True
    source = torch.tensor([1024, 513], dtype=torch.int32)
    destination = torch.zeros_like(source)
    if damage == 'dtype':destination = torch.zeros(2, dtype=torch.int64)
    if damage == 'shape':destination = torch.zeros(3, dtype=torch.int32)
    simulate_pin_allocator(monkeypatch, pinned=damage != 'unpinned', alias=source if damage == 'alias' else None)
    with pytest.raises((ValueError, RuntimeError)):
        owner._copy_length_source(destination, source, N(generation_id=1, mapping_epoch=10))
    assert owner._pinned_h2d_submissions == 0 and owner._pending_pinned_h2d_sources == []


def test_possible_partial_submission_retains_cpu_source_and_blocks_reset_or_second_use(monkeypatch):
    owner = workspace();owner._pinned_h2d_staging_review = True
    source = torch.tensor([1001, 1024], dtype=torch.int32);destination = torch.zeros_like(source)
    simulate_pin_allocator(monkeypatch);original_copy = torch.Tensor.copy_;calls=[];failure=RuntimeError('after possible submit')
    def uncertain(self, value, non_blocking=False):
        if self is destination:
            calls.append(weakref.ref(value))
            raise failure
        return original_copy(self, value, non_blocking=non_blocking)
    monkeypatch.setattr(torch.Tensor, 'copy_', uncertain)
    identity=N(generation_id=9, mapping_epoch=12)
    with pytest.raises(RuntimeError) as caught:owner._copy_length_source(destination, source, identity)
    assert caught.value is failure
    gc.collect();source.zero_()
    assert calls[0]() is owner._pending_pinned_h2d_sources[0][1]
    assert calls[0]().tolist() == [1001, 1024]
    assert owner.pinned_h2d_review_state()['pending_sources'][0]['generation'] == 9
    assert owner.pinned_h2d_review_state()['pending_sources'][0]['epoch'] == 12
    for action in [owner._zero_all, lambda:owner.configure_pinned_h2d_staging_review(False),
        lambda:owner.materialize(identity=identity,full_source=None,read_descriptors=(),device_window_exact=None,
                                 cpu_window_exact=source,cpu_window_upper=source,preserve_on_failure=True)]:
        with pytest.raises(RuntimeError):action()
    assert len(calls) == 1  # No second device submission or cleanup API.
    assert len(owner._pending_pinned_h2d_sources) == 1


def test_async_copy_is_rejected_without_failure_preserving_graph_owner():
    owner=workspace();owner._pinned_h2d_staging_review=True
    with pytest.raises(RuntimeError,match='failure-preserving'):
        owner.materialize(identity=None,full_source=None,read_descriptors=(),device_window_exact=None,
                          cpu_window_exact=None,cpu_window_upper=None,preserve_on_failure=False)


def config(value=True):
    return N(additional_config=dict(draft_window_size=1024,draft_window_graph_eagle_pinned_h2d_review=value),
        speculative_config=N(method='eagle3',enforce_eager=False,num_speculative_tokens=3,
                             uses_dynamic_speculative_decoding=lambda:False),
        parallel_config=N(tensor_parallel_size=1),compilation_config=N(cudagraph_mode=N(name='FULL_DECODE_ONLY')))


@pytest.mark.parametrize('value',[False,'false','0',0])
def test_real_schema_and_early_reader_do_not_enable_false_values(value):
    cfg=AscendConfig(sparse_kv_offload_config=N(enabled=False),draft_window_graph_eagle_pinned_h2d_review=value)
    assert cfg.draft_window_graph_eagle_pinned_h2d_review is False
    assert validate_draft_window_eagle_pinned_h2d_review(N(additional_config=dict(
        draft_window_graph_eagle_pinned_h2d_review=value))) is False


@pytest.mark.parametrize('damage',['none','other_method','eager','dynamic','k1','bool_k','tp2','bool_tp','window','mode','gate'])
def test_review_flag_does_not_open_gate_or_admit_another_method_topology(monkeypatch,damage):
    monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH','1')
    cfg=config()
    assert validate_draft_window_eagle_pinned_h2d_review(cfg) is True
    if damage=='none':cfg.speculative_config=None
    elif damage=='other_method':cfg.speculative_config.method='dspark'
    elif damage=='eager':cfg.speculative_config.enforce_eager=True
    elif damage=='dynamic':cfg.speculative_config.uses_dynamic_speculative_decoding=lambda:True
    elif damage=='k1':cfg.speculative_config.num_speculative_tokens=1
    elif damage=='bool_k':cfg.speculative_config.num_speculative_tokens=True
    elif damage=='tp2':cfg.parallel_config.tensor_parallel_size=2
    elif damage=='bool_tp':cfg.parallel_config.tensor_parallel_size=True
    elif damage=='window':cfg.additional_config['draft_window_size']=2048
    elif damage=='mode':cfg.compilation_config.cudagraph_mode.name='FULL'
    else:monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH','0')
    with pytest.raises(ValueError):validate_draft_window_eagle_pinned_h2d_review(cfg)


@pytest.mark.parametrize('damage',['missing','disabled','bool_count','zero_count','pending','owner','completion'])
def test_enabled_checker_needs_real_submission_and_rejects_unknown_ownership(damage):
    good=dict(enabled=True,submitted_copies=6,pending_sources=[],
        successful_source_owner='FRAMEWORK_PINNED_ALLOCATOR_STREAM_RECORD',completion='NOT_INFERRED_FROM_COPY_RETURN')
    assert validate_pinned_h2d_state(good,True)==good
    bad=copy.deepcopy(good)
    if damage=='missing':bad=None
    elif damage=='disabled':bad['enabled']=False
    elif damage=='bool_count':bad['submitted_copies']=True
    elif damage=='zero_count':bad['submitted_copies']=0
    elif damage=='pending':bad['pending_sources']=[dict(generation=9,epoch=10)]
    elif damage=='owner':bad['successful_source_owner']='HOST_RETURN_MEANS_COMPLETED'
    else:bad['completion']='COMPLETED'
    with pytest.raises((ValueError,KeyError)):validate_pinned_h2d_state(bad,True)
    assert validate_pinned_h2d_state(None,False)['enabled'] is False  # Explicit old/default-off scope only.
