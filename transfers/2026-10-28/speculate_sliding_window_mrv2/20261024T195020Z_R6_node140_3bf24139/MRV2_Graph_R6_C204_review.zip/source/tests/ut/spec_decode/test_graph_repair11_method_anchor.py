# SPDX-License-Identifier: Apache-2.0
"""Method-specific geometry and strict external evidence; no device execution."""

import json
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair11_method_anchor import add_cases, configuration, validate_counts


def counts():
    return dict(
        per_step_drafted=[15, 15, 2],
        per_step_accepted=[15, 3, 1],
        num_spec_tokens=15,
        acceptance_histogram=[0, 1, 0, 1] + [0] * 11 + [1],
        num_draft_tokens=32,
        num_accepted_draft_tokens=19,
        num_spec_steps=3,
        draft_acceptance_rate=19 / 32,
        mean_acceptance_length=1 + 19 / 3,
    )


@pytest.mark.parametrize("damage", [None, "old_k", "padding", "bonus", "hist", "missing", "total"])
def test_k15_real_metrics_not_dspark_or_padded_counts(damage):
    d = counts()
    if damage == "old_k":
        d["num_spec_tokens"] = 7
    elif damage == "padding":
        d["per_step_drafted"][0] = 16
    elif damage == "bonus":
        d["per_step_accepted"][2] = 3
    elif damage == "hist":
        d["acceptance_histogram"][0] += 1
    elif damage == "missing":
        d["per_step_accepted"].pop()
    elif damage == "total":
        d["num_draft_tokens"] += 1
    if damage:
        with pytest.raises(ValueError):
            validate_counts(d)
    else:
        assert validate_counts(d) == dict(proposed=32, accepted=19, verification_request_steps=3)


@pytest.mark.parametrize("arm", ["G_OFF", "G_ON", "E_ON"])
def test_independent_dflash_config_uses_real_cli_preserving_target_policy(tmp_path, arm):
    from vllm.engine.arg_utils import EngineArgs

    fixture = tmp_path / "fixture.json"
    fixture.write_text(json.dumps(dict(target_model="separate-target", draft_model="separate-dflash")))
    args = SimpleNamespace(
        fixture=fixture,
        fixture_sha256=__import__("hashlib").sha256(fixture.read_bytes()).hexdigest(),
        case="A0" if arm == "G_OFF" else "B-observer-off",
        case_id="method",
        run_id="r",
        attempt="1",
        expected_sha="a" * 40,
        vllm_repo=tmp_path,
        output=tmp_path,
        arm=arm,
    )
    _, config = configuration(args)
    actual = EngineArgs(**config)
    assert actual.speculative_config["method"] == "dflash"
    assert actual.speculative_config["num_speculative_tokens"] == 15
    assert actual.speculative_config["enforce_eager"] is (arm == "E_ON")
    assert actual.enforce_eager is False
    assert config["compilation_config"]["cudagraph_capture_sizes"] == [16, 32, 64]
    assert config["additional_config"] == ({} if arm == "G_OFF" else {"draft_window_size": 1024})


def test_method_plans_separate_manifest_request_and_exact_external_argv(tmp_path):
    output = tmp_path / "out"
    (tmp_path / "requests").mkdir()
    (tmp_path / "requests/dflash-k15-q16-anchor.json").write_text("[]")
    fixture = tmp_path / "dflash-k15-q16-fixture.json"
    fixture.write_text("{}")
    cases = dict(
        A0=dict(
            argv=["python", "p7x_graph_repair2.py", "--vllm-repo", "pin"],
            acceptance_identity=dict(run_id="r", source_sha="a" * 40),
            launch_argv=[
                "python",
                "launch",
                "--output",
                str(output / "launchers/A0"),
                "--case-id",
                "A0",
                "--mode",
                "A0",
                "--timeout",
                "1800",
                "--",
                "old",
            ],
        )
    )
    add_cases(cases, tmp_path, output, tmp_path, "python")
    for arm in ["G_OFF", "G_ON", "E_ON"]:
        name = "METHOD_DFLASH_" + arm
        case = cases[name]
        assert case["launch_argv"][case["launch_argv"].index("--") + 1 :] == case["argv"]
        assert case["launch_argv"][case["launch_argv"].index("--output") + 1] == str(output / "launchers" / name)
        assert case["dependencies"] == ["CONFIG_DFLASH"] and case["timeout_seconds"] == 900
        assert case["method_fixture_sha256"] and case["requests_sha256"]
        assert case["acceptance_identity"]["case_id"] == name
        assert "p7x_graph_repair11_method_anchor.py" in case["validation_commands"][0]["argv"][1]


@pytest.mark.parametrize(
    "damage",
    [
        None,
        "method",
        "width",
        "fixture",
        "observer",
        "capture",
        "request",
        "counter",
        "crop",
        "retire",
        "exit",
        "signal",
        "pid",
        "hash",
        "arm",
    ],
)
def test_method_checker_rejects_wrong_scope_or_broken_execution(tmp_path, damage):
    # Explicit synthetic checker fixture, never a producer or NPU test.
    import hashlib

    from tools.p7x_graph_repair11_method_anchor import check

    identity = dict(
        run_id="r",
        case_id="METHOD_DFLASH_G_ON",
        attempt_id="1",
        driver_mode="B-observer-off",
        source_sha="a" * 40,
        source_tree="b" * 40,
        process_id=123,
        engine_id=456,
    )
    requests = [dict(label=str(i), prompts=["test"], max_tokens=64) for i in range(3)]
    request_path = tmp_path / "requests.json"
    request_path.write_text(json.dumps(requests))
    request_sha = hashlib.sha256(request_path.read_bytes()).hexdigest()
    state = dict(generation=5, epoch=6, read_descriptors=[dict(source_start_column=1, first_token_offset=0)])
    document = dict(
        identity=identity,
        calls=[
            dict(active=True, label="Draft_REPLAY_SUBMIT", descriptor=[1, 16]),
            dict(active=True, label="Draft_REPLAY_SUBMIT", descriptor=[4, 64]),
            dict(active=True, label="Target_REPLAY_SUBMIT", descriptor=[1, 16]),
            dict(active=True, label="Target_REPLAY_SUBMIT", descriptor=[4, 64]),
            dict(
                active=True,
                label="Draft_retire_host",
                generation=5,
                mapping_epoch=6,
                request_group="2",
                start_ns=230,
                end_ns=240,
            ),
        ],
    )
    artifact = tmp_path / "profile.json"
    config = dict(
        speculative_config=dict(method="dflash", num_speculative_tokens=15, enforce_eager=False),
        enforce_eager=False,
        compilation_config=dict(cudagraph_capture_sizes=[16, 32, 64]),
        additional_config=dict(draft_window_size=1024),
    )
    campaign = dict(
        identity=identity,
        status="OK",
        startup_complete=True,
        method="dflash",
        query_width=16,
        speculator="vllm_ascend.worker.v2.spec_decode.dflash.speculator.AscendDFlashSpeculator",
        arm="G_ON",
        llm_kwargs=config,
        fixture_sha256="f" * 64,
        observer_enabled=False,
        observer_installation=dict(installed=True, enabled=False),
        request_manifest=dict(sha256=request_sha, entries=requests),
        draft_inventory=dict(graphs=[dict(num_reqs=n, num_tokens=n * 16) for n in (1, 2, 4)]),
        target_inventory=dict(graphs=[dict(num_reqs=n, num_tokens=n * 16) for n in (1, 2, 4)]),
        outputs=[
            dict(
                label=r["label"],
                prompts=r["prompts"],
                token_ids=[[1] * 64],
                start_ns=200,
                end_ns=300,
                metrics=[dict(speculative_decoding=counts())],
                window_identity=state,
            )
            for r in requests
        ],
    )
    argv = ["python", "run"]
    expected = dict(
        acceptance_identity=identity,
        argv=argv,
        launch_argv=["launch", "--", *argv],
        requests_sha256=request_sha,
        request_path=str(request_path),
        outputs=str(tmp_path),
        method_anchor_arm="G_ON",
        method_fixture_sha256="f" * 64,
    )
    launcher = dict(
        identity,
        pid=123,
        argv=argv,
        requests_sha256=request_sha,
        host_start_ns=100,
        host_end_ns=400,
        status="EXITED",
        returncode=0,
        signal=None,
        timeout=False,
    )
    if damage == "method":
        campaign["method"] = "dspark"
    elif damage == "width":
        campaign["query_width"] = 7
    elif damage == "fixture":
        campaign["fixture_sha256"] = "old DSpark"
    elif damage == "observer":
        campaign["observer_installation"]["enabled"] = True
    elif damage == "capture":
        campaign["draft_inventory"]["graphs"].pop()
    elif damage == "request":
        campaign["outputs"][0]["prompts"] = ["wrong"]
    elif damage == "counter":
        campaign["outputs"][0]["metrics"][0]["speculative_decoding"]["num_spec_tokens"] = 7
    elif damage == "crop":
        state["read_descriptors"][0]["source_start_column"] = 0
    elif damage == "retire":
        document["calls"][-1]["generation"] = 4
    elif damage == "exit":
        launcher["returncode"] = 2
    elif damage == "signal":
        launcher["signal"] = 9
    elif damage == "pid":
        launcher["pid"] += 1
    elif damage == "arm":
        campaign["arm"] = "G_OFF"
    artifact.write_text(json.dumps(document))
    campaign["diagnostic_artifacts"] = {
        artifact.name: dict(bytes=artifact.stat().st_size, sha256=hashlib.sha256(artifact.read_bytes()).hexdigest())
    }
    if damage == "hash":
        artifact.write_text("corrupted")
    assert (
        check(document, campaign, launcher, expected, artifact)["status"] == "PASS_SCOPED_DFLASH_K15_Q16_ANCHOR"
    ) is (damage is None)
