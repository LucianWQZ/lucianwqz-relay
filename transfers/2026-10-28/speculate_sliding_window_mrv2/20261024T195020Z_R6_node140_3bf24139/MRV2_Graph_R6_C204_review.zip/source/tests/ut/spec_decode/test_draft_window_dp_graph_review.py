# SPDX-License-Identifier: Apache-2.0
"""Private rank-local DP admission, not multi-rank execution evidence."""
from dataclasses import replace

import pytest

from tests.ut.spec_decode.test_draft_window import _attention_group, _block_tables, _p2_policy
from tests.ut.spec_decode.test_draft_window_graph_characterization import _runtime_context
from tests.ut.spec_decode.test_draft_window_graph_tp_review import config, gate
from vllm_ascend.ascend_config import validate_draft_window_replicated_tp_review
from vllm_ascend.worker.v2.spec_decode.draft_window import (
    build_draft_window_inventory, resolve_draft_window_policy,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import validate_parallel_graph_characterization_context
from vllm_ascend.worker.v2.spec_decode.draft_window_nongraph import P7XCapabilityStatus, evaluate_p7x_nongraph_capability


def reviewed():
    vc=config(tp=4)
    vc.speculative_config.method='dflash';vc.speculative_config.num_speculative_tokens=7
    vc.parallel_config.data_parallel_size=2;vc.parallel_config.enable_expert_parallel=True
    vc.speculative_config.draft_parallel_config.data_parallel_size=1
    return vc


@pytest.mark.parametrize('rank',range(4))
def test_actual_tp_rank_and_dp_size_survive_source_factory(monkeypatch,rank):
    import vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization as module

    vc=reviewed();context=_runtime_context(tensor_parallel_size=4,tensor_parallel_rank=rank,data_parallel_size=2,
                                         graph_mode='FULL_DECODE_ONLY')
    assert validate_draft_window_replicated_tp_review(vc)
    assert validate_parallel_graph_characterization_context(context,vc)
    monkeypatch.setattr(module,'build_draft_window_runtime_context',lambda *a:context)
    policy=resolve_draft_window_policy(requested_window_size=1024,method='dflash',target_model_type='qwen3')
    cap,actual=module.build_parallel_draft_window_graph_characterization_source(policy=policy,
        runtime_route='dflash',attn_groups=[[_attention_group()]],block_tables=_block_tables(),causal=False,vllm_config=vc)
    assert actual is context
    assert cap.eager_topology_fingerprint.tensor_parallel_size==4
    assert cap.eager_topology_fingerprint.tensor_parallel_rank==rank
    assert cap.eager_topology_fingerprint.data_parallel_size==2
    assert cap.eager_topology_fingerprint.graph_mode=='FULL_DECODE_ONLY'


@pytest.mark.parametrize('damage',['not_review','dspark','tp2','dp3','bool_dp','no_ep','draft_dp','wrong_context_dp'])
def test_private_review_rejects_other_or_ambiguous_domains(damage):
    vc=reviewed();context=_runtime_context(tensor_parallel_size=4,data_parallel_size=2,graph_mode='FULL_DECODE_ONLY')
    if damage=='not_review':vc.additional_config['draft_window_graph_replicated_tp_review']=False
    elif damage=='dspark':vc.speculative_config.method='dspark'
    elif damage=='tp2':
        vc.parallel_config.tensor_parallel_size=2;vc.speculative_config.draft_parallel_config.tensor_parallel_size=2
    elif damage=='dp3':vc.parallel_config.data_parallel_size=3
    elif damage=='bool_dp':vc.parallel_config.data_parallel_size=True
    elif damage=='no_ep':vc.parallel_config.enable_expert_parallel=False
    elif damage=='draft_dp':vc.speculative_config.draft_parallel_config.data_parallel_size=2
    else:context=replace(context,data_parallel_size=1)
    with pytest.raises((ValueError,NotImplementedError)):
        validate_parallel_graph_characterization_context(context,vc)


@pytest.mark.parametrize('feature',['async_scheduling','sequence_parallel','dsa_context_parallel','flashcomm','prefix_caching'])
def test_uncombined_dp_review_does_not_admit_unverified_feature_combinations(feature):
    context=_runtime_context(tensor_parallel_size=4,data_parallel_size=2,graph_mode='FULL_DECODE_ONLY',**{feature:True})
    with pytest.raises(NotImplementedError,match='uncombined'):
        validate_parallel_graph_characterization_context(context,reviewed())


def test_source_allowance_does_not_open_normal_eager_dp_or_other_methods():
    context=_runtime_context(tensor_parallel_size=4,data_parallel_size=2,graph_mode='NONE')
    policy=_p2_policy('dflash')
    kwargs=dict(policy=policy,runtime_route='dflash',attn_groups=[[_attention_group()]],block_tables=_block_tables(),
                causal=False,runtime_context=context,allow_replicated_tp_graph_source=True)
    inventory=build_draft_window_inventory(**kwargs,allow_parallel_dp_graph_source=True)
    assert not inventory.groups[0].capability_failures
    args=dict(policy=policy,inventory=inventory,runtime_context=context,uses_dynamic_k=False,provider_version=3,execution_lane=0)
    assert evaluate_p7x_nongraph_capability(**args).status is P7XCapabilityStatus.REPORT1_RUNTIME_DEPENDENT
    assert evaluate_p7x_nongraph_capability(**args,allow_parallel_dp_graph_source=True).status is P7XCapabilityStatus.LOCAL_STATIC_READY
    rejected=build_draft_window_inventory(**kwargs)
    assert any('DP=2' in error for error in rejected.capability_failures)
    with pytest.raises(NotImplementedError,match='DP=2'):
        rejected.require_single_group_direct_prefix()
    with pytest.raises(NotImplementedError,match='DFlash TP4/DP2'):
        build_draft_window_inventory(**dict(kwargs,runtime_route='dspark'),allow_parallel_dp_graph_source=True)
    with pytest.raises(TypeError,match='explicit boolean'):
        build_draft_window_inventory(**kwargs,allow_parallel_dp_graph_source='true')


def test_official_pinned_draft_factory_retains_tp_only_descriptor_for_two_engine_replicas():
    from vllm.config import ParallelConfig,SpeculativeConfig

    vc=reviewed()
    vc.parallel_config=ParallelConfig(tensor_parallel_size=4,data_parallel_size=2,data_parallel_size_local=2,
                                      enable_expert_parallel=True,distributed_executor_backend='mp')
    draft=SpeculativeConfig.create_draft_parallel_config(vc.parallel_config,4)
    assert draft.tensor_parallel_size==4 and draft.data_parallel_size==1
    assert vc.parallel_config.data_parallel_size==2
    vc.speculative_config.draft_parallel_config=draft
    assert validate_draft_window_replicated_tp_review(vc)
    context=_runtime_context(tensor_parallel_size=4,tensor_parallel_rank=3,data_parallel_size=2,
                             graph_mode='FULL_DECODE_ONLY')
    assert validate_parallel_graph_characterization_context(context,vc)
    with pytest.raises(NotImplementedError):
        validate_parallel_graph_characterization_context(replace(context,data_parallel_size=1),vc)


@pytest.mark.parametrize('rank',range(4))
def test_actual_source_factory_installs_all_real_q8_capture_buckets(monkeypatch,rank):
    import torch
    from vllm.config.compilation import CUDAGraphMode
    from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor
    from tests.ut.spec_decode.test_draft_window_graph_characterization import _characterization_owner
    from vllm_ascend.worker.v2.spec_decode.draft_window import build_draft_window_runtime_state
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph import DraftWindowGraphRoute
    import vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization as module

    owner,_=_characterization_owner(method='dflash',causal=False,window_size=1024,block_size=128,row_width=32)
    vc=reviewed();owner.vllm_config=vc;owner.dp_size=2
    context=_runtime_context(tensor_parallel_size=4,tensor_parallel_rank=rank,data_parallel_size=2,
                             graph_mode='FULL_DECODE_ONLY')
    monkeypatch.setattr(module,'build_draft_window_runtime_context',lambda *a:context)
    policy=resolve_draft_window_policy(requested_window_size=1024,method='dflash',target_model_type='qwen3')
    cap,_=module.build_parallel_draft_window_graph_characterization_source(policy=policy,runtime_route='dflash',
        attn_groups=[[_attention_group(block_size=128)]],block_tables=owner.block_tables,causal=False,vllm_config=vc)
    owner._draft_window_source_capability=cap;owner._draft_window_runtime_state=build_draft_window_runtime_state(cap)
    owner.speculative_config.num_speculative_tokens=7;owner.num_query_per_req=8
    owner.query_cudagraph_manager._capture_descs={CUDAGraphMode.FULL:[
        BatchExecutionDescriptor(cg_mode=CUDAGraphMode.FULL,num_tokens=n*8,num_reqs=n,uniform_token_count=8)
        for n in (1,2,4)]}
    session=module.install_parallel_draft_window_graph_characterization(owner,runtime_context=context)
    identities=session.provider.registered_capture_identities(route=DraftWindowGraphRoute.DFLASH)
    assert len(identities)==3
    for identity in identities:
        fp=identity.fingerprint
        assert (fp.tensor_parallel_size,fp.tensor_parallel_rank,fp.data_parallel_size)==(4,rank,2)
        assert fp.query_width==8 and fp.static_k==7 and fp.window_size==1024
        read=session.provider.startup_capture_read_inputs(identity)
        assert read.window_block_table.dtype==torch.int32
        assert read.window_block_table.shape[0]==fp.padded_request_count


@pytest.mark.parametrize('rank',range(4))
def test_dp2_carrier_materializes_binds_and_rejects_replica_domain_drift(rank):
    from types import SimpleNamespace
    from tests.ut.spec_decode.test_draft_window_graph_rank_identity import rank_runtime
    from tests.ut.spec_decode.test_draft_window_graph_carrier import (
        _runtime_fixture,_fingerprint,_materialize,_register,_bind_read_carrier,_target_metadata,
    )
    from vllm_ascend.worker.v2.spec_decode.draft_window import build_draft_window_runtime_state
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph import DraftWindowGraphRoute,install_draft_window_graph_binding_provider

    rank_state,_,_=rank_runtime(4,rank)
    _,cap,_=_runtime_fixture(method='dflash',causal=False)
    topology=replace(rank_state.capability.eager_topology_fingerprint,normalized_method='dflash',
                     runtime_route='dflash',data_parallel_size=2)
    runtime=build_draft_window_runtime_state(replace(cap,eager_topology_fingerprint=topology))
    provider=install_draft_window_graph_binding_provider(SimpleNamespace(_draft_window_runtime_state=runtime))
    fp=replace(_fingerprint(method='dflash',route=DraftWindowGraphRoute.DFLASH,query_width=2),
               tensor_parallel_size=4,tensor_parallel_rank=rank,data_parallel_size=2)
    capture=_register(provider,fingerprint=fp);inputs=_materialize(runtime,mapping_epoch=10)
    bound=_bind_read_carrier(provider,runtime,capture,inputs,_target_metadata())
    assert bound.runtime_identity.tensor_parallel_rank==rank
    assert bound.read_inputs.cpu_window_exact.tolist()==[96,64,0,0]
    with pytest.raises(RuntimeError,match='DP identity'):
        provider._validate_capture_topology(replace(fp,data_parallel_size=1))
    runtime.capability=replace(runtime.capability,eager_topology_fingerprint=replace(topology,data_parallel_size=1))
    with pytest.raises(RuntimeError,match='DP identity'):
        provider._validate_capture_topology(fp)


@pytest.mark.parametrize('field,value',[('data_parallel_size',3),('tensor_parallel_size',2),
    ('sequence_parallel',True),('async_scheduling',True),('prefix_caching',True),('graph_mode','PIECEWISE')])
def test_internal_dp2_key_does_not_admit_other_unverified_domains(field,value):
    from tests.ut.spec_decode.test_draft_window_graph_carrier import _fingerprint
    from vllm_ascend.worker.v2.spec_decode.draft_window_graph import DraftWindowGraphRoute
    fp=replace(_fingerprint(method='dflash',route=DraftWindowGraphRoute.DFLASH,query_width=2),
               tensor_parallel_size=4,data_parallel_size=2)
    with pytest.raises(ValueError,match='single-lane topology'):replace(fp,**{field:value})
