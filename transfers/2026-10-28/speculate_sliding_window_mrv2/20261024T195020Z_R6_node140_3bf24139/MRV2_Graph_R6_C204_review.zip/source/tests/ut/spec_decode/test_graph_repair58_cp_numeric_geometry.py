# SPDX-License-Identifier: Apache-2.0
"""Fixed SP capture geometry with complete numeric checks, not relaxed rows."""
import copy

import pytest

from tools.p7x_graph_repair6 import joint
from tools.p7x_graph_repair6_numeric_check import expected_draft_padding, validate_sample
from tools.p7x_graph_repair6_storage import CollectionReader
from tests.ut.spec_decode.test_graph_repair6_numeric_pipeline import joined, produce

PROFILE = 'glm52_dspark_k8_q8_sfa_cp'


@pytest.mark.parametrize('limit', [3, None])
def test_actual_pipeline_contract_with_two_row_minimum_and_independent_reference(monkeypatch, tmp_path, limit):
    path, contract, snapshot = produce(monkeypatch, tmp_path, sample_limit=limit, profile=PROFILE)
    campaign, launcher, plan = joined(path, contract, snapshot)
    if limit:
        plan['numeric_samples'] = 3
        plan['argv'] += ['--repair6-target-prefix', '3']
        plan['launch_argv'] += ['--repair6-target-prefix', '3']
        launcher['argv'] = plan['argv']
    result = joint(path, campaign, launcher, plan, 'numeric')
    assert result['status'] == ('PASS_NUMERIC_SENTINEL_ONLY' if limit else 'PASS_DIAGNOSTIC_CONTINUOUS_REFERENCE'), result
    assert result['aba'] == 'PASS_SCOPED'


@pytest.mark.parametrize('damage', ['descriptor', 'runtime_rows', 'padding_slot', 'query', 'active_numeric'])
def test_sp_bucket_support_keeps_complete_padding_ownership_and_numerical_guards(monkeypatch, tmp_path, damage):
    from tools.p7x_graph_repair5_target import case_plan
    path, _, _ = produce(monkeypatch, tmp_path, sample_limit=3, profile=PROFILE)
    reader = CollectionReader(path)
    sample = reader.record(0)
    if damage == 'descriptor':
        sample['descriptor'] = [1, 8]
    elif damage == 'runtime_rows':
        sample['runtime_identity']['padded_request_count'] = 1
    elif damage == 'padding_slot':
        sample['inputs']['slot_mapping'][8] = 0
    elif damage == 'query':
        sample['inputs']['query_start_loc'][-1] = 16
    else:
        sample['reference'][0, 0] += 1
        assert validate_sample(sample, reader.header, case_plan(PROFILE)[0])['status'] == 'NUMERIC_MISMATCH'
        return
    with pytest.raises(ValueError):
        validate_sample(sample, reader.header, case_plan(PROFILE)[0])


@pytest.mark.parametrize('damage', ['missing', 'one_row', 'duplicate', 'width', 'query'])
def test_profile_or_results_cannot_invent_an_arbitrary_capture_inventory(damage):
    provenance = dict(profile=PROFILE, hidden_contract=dict(width=6144, dtype='torch.bfloat16'),
        hidden_capture_inventory=[dict(tokens=n * 8, requests=n, query=8, width=6144,
                                       dtype='torch.bfloat16') for n in (2, 4)])
    assert expected_draft_padding(provenance, 1) == 2
    assert expected_draft_padding(provenance, 3) == 4
    if damage == 'missing':
        provenance.pop('hidden_capture_inventory')
    elif damage == 'one_row':
        provenance['hidden_capture_inventory'][0].update(tokens=8, requests=1)
    elif damage == 'duplicate':
        provenance['hidden_capture_inventory'][1] = copy.deepcopy(provenance['hidden_capture_inventory'][0])
    else:
        provenance['hidden_capture_inventory'][0][damage] += 1
    with pytest.raises(ValueError):
        expected_draft_padding(provenance, 1)
    # Explicit legacy profiles retain their one-row ABI.
    assert expected_draft_padding(dict(profile='glm52_dspark_k8_q8_sfa'), 1) == 1
