# SPDX-License-Identifier: Apache-2.0
"""Host token-join counterexamples, separate from actual phase/NPU validation."""
import json
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair60_glm_phase_pair import compare_documents, recheck_case


def document():
    def result(prompt, token):
        return dict(request=dict(model='arm-alias', prompt=prompt, temperature=0, seed=0,
            max_tokens=3, min_tokens=3, ignore_eos=True, stream=True, return_token_ids=True),
            events=[dict(data=dict(choices=[dict(index=0, token_ids=[token, token+1, token+2],
                                                 finish_reason='length')]))])
    return dict(status='COMPLETE', groups=[
        dict(phase='warmup', label='cold-short-long', results=[result([1, 2], 10)]),
        dict(phase='measured', label='replacement', results=[result([3], 20), result([4, 5], 30)])])


def test_three_complete_request_streams_match_despite_aliases():
    docs = {arm: document() for arm in ('G_OFF', 'G_ON', 'E_ON')}
    for arm, doc in docs.items():
        for group in doc['groups']:
            for row in group['results']:
                row['request']['model'] = arm
    assert len(compare_documents(docs)) == 3


@pytest.mark.parametrize('damage', ['missing_arm', 'extra_arm', 'missing_request', 'request_order',
    'input', 'seed', 'output', 'summary_only', 'incomplete', 'missing_terminal', 'phase'])
def test_damage_to_whole_request_or_raw_tokens_is_rejected(damage):
    docs = {arm: document() for arm in ('G_OFF', 'G_ON', 'E_ON')}
    doc = docs['E_ON']
    row = doc['groups'][-1]['results'][0]
    if damage == 'missing_arm':
        del docs['G_OFF']
    elif damage == 'extra_arm':
        docs['E_OFF'] = document()
    elif damage == 'missing_request':
        doc['groups'][-1]['results'].pop()
    elif damage == 'request_order':
        doc['groups'][-1]['results'].reverse()
    elif damage == 'input':
        row['request']['prompt'] = [999]
    elif damage == 'seed':
        row['request']['seed'] = 1
    elif damage == 'output':
        row['events'][0]['data']['choices'][0]['token_ids'][1] += 1
    elif damage == 'summary_only':
        row['summary'] = dict(output_token_ids=[20, 21, 22])
        del row['events']
    elif damage == 'incomplete':
        doc['status'] = 'IN_PROGRESS'
    elif damage == 'missing_terminal':
        row['events'][0]['data']['choices'][0]['finish_reason'] = None
    else:
        doc['groups'][-1]['phase'] = 'warmup'
    with pytest.raises((ValueError, KeyError)):
        compare_documents(docs)


def test_standalone_pass_does_not_allow_wrong_producer_without_independent_check(tmp_path):
    (tmp_path / 'model').mkdir()
    (tmp_path / 'model/campaign.json').write_text(json.dumps(dict(source_sha='old')))
    (tmp_path / 'result.json').write_text(json.dumps(dict(scoped_accepted=True, source_sha='old')))
    with pytest.raises(ValueError, match='producer'):
        recheck_case(tmp_path, 'G_ON', SimpleNamespace(producer_sha='new'), tmp_path)
