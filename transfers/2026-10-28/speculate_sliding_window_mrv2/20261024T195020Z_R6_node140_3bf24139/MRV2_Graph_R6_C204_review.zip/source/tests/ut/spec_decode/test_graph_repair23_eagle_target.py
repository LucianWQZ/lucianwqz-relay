# SPDX-License-Identifier: Apache-2.0
"""CPU contract/negative checks, not real model or NPU acceptance."""
import copy
import json
from types import SimpleNamespace

import pytest
import torch

from tools.p7x_graph_repair23_eagle_target import EagleTargetContract, case_plan, check_numeric_aba


def test_controlled_v6_schema_reaches_existing_strict_per_consumer_checks():
    from tools.p7x_graph_repair15_eagle_numeric_check import validate_binding_schema, validate_sample
    from tests.ut.spec_decode.test_graph_repair15_eagle_numeric import specimen
    cases = case_plan()
    h = dict(numeric_schema="r6-eagle3-controlled-continuous-v6", controlled_cases=cases,
             groups={case["scenario"]: len(case["ends"]) for case in cases}, expected_samples=42,
             tolerance=dict(atol=0.0, rtol=0.0))
    validate_binding_schema(h)
    # A v5 sample cannot be made valid by renaming its schema: L0 and all
    # existing input/KV/write-set/generation checks remain enforced.
    record, original = specimen()
    original.update(h)
    record["group"] = "A"
    with pytest.raises(ValueError, match="controlled L0"):
        validate_sample(record, original)
    for damage in ("schema", "cases", "groups", "coverage", "tolerance"):
        bad = copy.deepcopy(h)
        if damage == "schema": bad["numeric_schema"] = "r6-eagle3-unknown"
        elif damage == "cases": bad["controlled_cases"][0]["ends"][0] += 1
        elif damage == "groups": bad["groups"]["A"] = 4
        elif damage == "coverage": bad["expected_samples"] = 3
        else: bad["tolerance"]["atol"] = 1e-2
        with pytest.raises(ValueError): validate_binding_schema(bad)


def test_explicit_eagle_cases_have_distinct_query_padding_and_horizon_contracts():
    cases = case_plan()
    assert len(cases) == len({case["scenario"] for case in cases}) == 14
    assert [case["scenario"] for case in cases[:3]] == ["A", "B", "A_prime"]
    assert all(case["query_width"] == 4 and case["num_sampled"] + case["num_rejected"] == 4 for case in cases)
    assert cases[9]["padded"] == 2 and len(cases[9]["ends"]) == 1
    assert cases[11]["padded"] == 4 and len(cases[11]["ends"]) == 3
    assert cases[-1]["num_rejected"] == 3
    method = EagleTargetContract()
    assert method.ar_query == 1 and method.ar_consumers == 2 and method.k == 3
    assert method.document()["method"] == "eagle3"


def aba_records():
    records = []
    for epoch, label in enumerate(("A", "B", "A_prime")):
        for step in range(3):
            value = torch.tensor([2.0 if label == "B" else 1.0], dtype=torch.bfloat16)
            item = dict(group=label,
                        identity=dict(epoch=epoch, generation=3 * epoch + step),
                        runtime_identity=dict(step=step))
            for key in ("inputs", "pre_kv", "canonical_table", "actual_slots", "graph", "reference", "graph_post_kv",
                        "reference_post_kv"):
                item[key] = (value.clone(), value.clone()) if key in ("graph", "reference") else {"x": value.clone()}
            records.append(item)
    return records


class Reader:

    def __init__(self, records):
        self.records = records
        self.samples = records

    def record(self, index):
        return copy.deepcopy(self.records[index])


def test_real_three_proposal_contract_uses_continuous_outputs_not_token_equality():
    rows = aba_records()
    result = check_numeric_aba(Reader(rows))
    assert result["status"] == "PASS_SCOPED_CONTINUOUS_ABA"
    assert len(result["consumers"]) == 3
    for step in range(3):
        rows[step + 3]["graph"] = copy.deepcopy(rows[step]["graph"])
    assert check_numeric_aba(Reader(rows))["status"] == "OPEN_NONDISCRIMINATING"
    rows = aba_records()
    rows[6]["pre_kv"]["x"][0] = 9
    with pytest.raises(ValueError, match="A-prime"):
        check_numeric_aba(Reader(rows))
    with pytest.raises(ValueError, match="all three"):
        check_numeric_aba(Reader(aba_records()[:-1]))


def test_target_plan_reaches_actual_cli_and_preserves_launch_timeout(tmp_path):
    from tools.p7x_graph_repair13_eagle import CONTRACT, add_cases, parse_args
    (tmp_path / "eagle3-k3-fixture.json").write_text(
        json.dumps(dict(schema="r5-eagle3-k3-fixture-v1", method_contract=CONTRACT)))
    (tmp_path / "requests").mkdir()
    (tmp_path / "requests/eagle3-k3-anchor.json").write_text("[]")
    (tmp_path / "requests/eagle3-controlled-target.json").write_text(json.dumps(case_plan()))
    common = dict(acceptance_identity=dict(run_id="host", driver_mode="A0", case_id="A0"),
                  argv=["python", "driver", "run", "--vllm-repo", "/fixed-vllm"],
                  dependencies=[],
                  requires_device_admission=True)
    cases = dict(A0=copy.deepcopy(common), CONFIG=copy.deepcopy(common))
    cases["CONFIG"].pop("acceptance_identity")
    add_cases(cases, tmp_path, tmp_path, tmp_path, "python", "a" * 40, tmp_path / "proof", "b" * 64)
    for prefix in (True, False):
        for arm in ("ON", "OFF"):
            name = "EAGLE3_TARGET_" + ("PREFIX_" if prefix else "") + arm
            item = cases[name]
            argv = item["argv"]
            parsed = parse_args(argv[argv.index("run"):])
            assert parsed.eagle3_target and not parsed.eagle3_numeric and not parsed.eagle3_life
            assert parsed.eagle3_target_prefix == (1 if prefix else None)
            launch = item["launch_argv"]
            assert launch[launch.index("--") + 1:] == argv
            assert int(launch[launch.index("--timeout") + 1]) < item["timeout_seconds"]
            assert item["eagle3_target_prefix"] == (1 if prefix else None)
            if not prefix:
                assert item["dependencies"] == ["EAGLE3_TARGET_PREFIX_OFF", "EAGLE3_TARGET_PREFIX_ON"]
    repro = cases["EAGLE3_TARGET_PADDING_REPRO_ON"]
    argv = repro["argv"]
    parsed = parse_args(argv[argv.index("run"):])
    assert parsed.eagle3_target and parsed.eagle3_padding_repro and parsed.eagle3_target_prefix is None
    assert repro["eagle3_target_repro"] is True
    assert repro["dependencies"] == ["CONFIG_EAGLE3", "EAGLE3_G_ON"]
    assert repro["launch_argv"][repro["launch_argv"].index("--")+1:] == argv


def test_resource_bound_tracks_declared_target_width_without_changing_base_default():
    from tools.p7x_graph_repair6_storage import resource_plan
    options = dict(layers=1, kv_heads=1, head_dim=2, element_bytes=2, hidden_size=8, vocab_size=16, mask_bytes=0)
    base = dict(scenario="host", ends=[32], padded=1)
    budgets = [resource_plan([dict(base, query_width=query)], **options)["one_arm_bytes"] for query in (4, 8, 16)]
    assert budgets[0] < budgets[1] < budgets[2]
    assert resource_plan([base], **options)["one_arm_bytes"] == budgets[1]
    with pytest.raises(ValueError):
        resource_plan([dict(base, query_width=True)], **options)


def test_q4_target_real_python_stage_boundary_and_checkpoint_keep_legacy_guard(monkeypatch, tmp_path):
    from tests.ut.spec_decode.test_graph_repair5_producers import controlled_runner
    from tests.ut.spec_decode.test_graph_repair4_target import tool as base
    from tools.p7x_graph_repair5_target import ControlledTarget, validate_controlled_record
    from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor
    import vllm_ascend.attention.attention_v1 as backend
    runner = controlled_runner(monkeypatch, padded_sizes=(1, ))
    import tools.p7x_graph_repair5_target as target_module
    monkeypatch.setattr(target_module, "_base", lambda: base)
    manager = runner.cudagraph_manager
    original = next(iter(manager.graphs))
    desc = BatchExecutionDescriptor(original.cg_mode, num_tokens=4, num_reqs=1, uniform_token_count=4)
    manager.graphs = {desc: manager.graphs[original]}
    params = backend.get_graph_params()
    params.attn_params[4], params.handles[4], params.events[4] = [], [], []
    params.workspaces[4] = object()
    layer = runner.compilation_config.static_forward_context["target"]
    metadata = SimpleNamespace(block_tables=runner.block_tables.input_block_tables[0][:1],
                               seq_lens_list=[4],
                               actual_seq_lengths_q=[4],
                               attn_mask=None,
                               attn_state=backend.AscendAttentionState.DecodeOnly,
                               causal=True)
    query = torch.zeros(4, 1, 2)
    layer.impl.full_graph_fia(query, *layer.kv_cache, metadata, query.clone())
    diagnostic = ControlledTarget(runner,
                                  fixture_id="HOST-Q4-NOT-NPU",
                                  arm="OFF",
                                  scheduler=SimpleNamespace(requests={}, running=[], waiting=[]),
                                  identity=dict(run_id="host",
                                                case_id="OFF",
                                                attempt_id="1",
                                                source_sha="host",
                                                source_tree="host",
                                                process_id=1),
                                  profile="eagle3_static_k3_controlled",
                                  method_contract=EagleTargetContract(),
                                  declared_cases=case_plan()[:1])
    result = diagnostic.execute(tmp_path / "cpu-q4.pt")
    record = result["records"][0]
    assert validate_controlled_record(record, expected_target_query=4)
    with pytest.raises(ValueError, match="Target query"):
        validate_controlled_record(record)
    bad = copy.deepcopy(record)
    entries = bad["checkpoint"]["inputs"]["tensors"]
    pos = next(key for key in entries if key.endswith("/positions"))
    entries[pos]["data"][0] += 1
    with pytest.raises(ValueError):
        validate_controlled_record(bad, expected_target_query=4)


def test_eagle_propose_exception_has_no_postfault_drain_or_device_read(monkeypatch):
    from tools.p7x_graph_repair23_eagle_target import EagleControlledTarget
    from tools.p7x_graph_repair6_submission import SubmissionState
    calls = []

    def fail(*args, **kwargs):
        calls.append("propose")
        raise RuntimeError("HOST_INJECTED_UNKNOWN_SUBMISSION_NOT_DEVICE")

    spec = SimpleNamespace(max_num_reqs=4,
                           propose=fail,
                           update_stream=SimpleNamespace(synchronize=lambda: calls.append("forbidden drain")))
    target = {}
    runner = SimpleNamespace(speculator=spec,
                             device=torch.device("cpu"),
                             model_state=SimpleNamespace(attn_metadata=target))
    observer = object.__new__(EagleControlledTarget)
    observer.runner, observer.cases = runner, case_plan()
    observer.numeric_probe, observer.inventory = None, dict(target_layers=["target"])
    observer.submission, observer.poisoned = SubmissionState(), False
    monkeypatch.setattr(torch.npu, "current_stream", lambda: calls.append("forbidden current_stream"))
    with pytest.raises(RuntimeError, match="HOST_INJECTED"):
        observer._execute_draft_after_target(record=dict(generation=0, checkpoint={}),
                                             batch=SimpleNamespace(num_reqs=1),
                                             hidden=torch.zeros((4, 2)),
                                             inputs={},
                                             access=lambda: calls.append("forbidden read"),
                                             slots={"target/K": torch.zeros(4, dtype=torch.int64)},
                                             blocks={})
    assert calls == ["propose"]
    assert observer.poisoned and spec._draft_window_graph_submission_uncertain
    assert observer.submission.pending and observer.submission.failure["uncertain_submission"]



def test_real_qwen_36_layers_not_guessed_32_and_missing_or_duplicate_rejected():
    from tools.p7x_graph_repair23_eagle_target import validate_layer_inventory
    runner = SimpleNamespace(model=SimpleNamespace(config=SimpleNamespace(num_hidden_layers=36)),
                             speculator=SimpleNamespace(draft_attn_layer_names=["eagle.layer.0"]))
    inventory = dict(target_layers=[f"model.layer.{i}" for i in range(36)], draft_layers=["eagle.layer.0"])
    assert validate_layer_inventory(runner, inventory)["target"] == 36
    for damage in ("old32", "missing", "duplicate", "wrong_draft", "cross_owner"):
        bad = copy.deepcopy(inventory)
        if damage == "old32": bad["target_layers"] = bad["target_layers"][:32]
        elif damage == "missing": bad["target_layers"].pop()
        elif damage == "duplicate": bad["target_layers"][-1] = bad["target_layers"][0]
        elif damage == "wrong_draft": bad["draft_layers"] = ["another.layer"]
        else: bad["target_layers"][0] = "eagle.layer.0"
        with pytest.raises(ValueError):
            validate_layer_inventory(runner, bad)
    runner.model.config.num_hidden_layers = True
    with pytest.raises(ValueError):
        validate_layer_inventory(runner, inventory)



def test_checker_layer_counts_use_frozen_config_hashes_not_header_claims(tmp_path):
    import hashlib
    from tools.p7x_graph_repair23_eagle_target import expected_layer_counts
    fixture = dict(target_model=str(tmp_path / "target"), draft_model=str(tmp_path / "draft"), files=[])
    for role, count in (("target", 36), ("draft", 1)):
        directory = tmp_path / role
        directory.mkdir()
        path = directory / "config.json"
        path.write_text(json.dumps(dict(num_hidden_layers=count)))
        fixture["files"].append(dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    manifest = tmp_path / "fixture.json"
    manifest.write_text(json.dumps(fixture))
    expected = dict(argv=["run", "--fixture", str(manifest)],
                    method_fixture_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest())
    assert expected_layer_counts(expected) == dict(target=36, draft=1)
    # A self-consistent new producer count does not authorize changing frozen config.
    (tmp_path / "target/config.json").write_text(json.dumps(dict(num_hidden_layers=32)))
    with pytest.raises(ValueError, match="hash mismatch"):
        expected_layer_counts(expected)
    manifest.write_text(json.dumps(dict(fixture, target_model="/different-model")))
    with pytest.raises(ValueError, match="fixture identity changed"):
        expected_layer_counts(expected)



def test_actual_campaign_index_includes_target_producer_outputs_and_rejects_changes(tmp_path):
    from tools.p7x_graph_repair13_eagle import diagnostic_artifact_index, validate_artifact_index
    names = ("eagle-target.json", "eagle-target-run.json", "eagle-numeric.json")
    for name in names:
        (tmp_path / name).write_text(json.dumps(dict(kind=name, evidence="HOST_INDEX_TEST_NOT_MODEL")))
    campaign = dict(diagnostic_artifacts=diagnostic_artifact_index(tmp_path))
    validate_artifact_index(tmp_path, campaign, names)
    old = copy.deepcopy(campaign)
    del old["diagnostic_artifacts"]["eagle-target.json"]
    with pytest.raises(KeyError):
        validate_artifact_index(tmp_path, old, names)
    wrong = copy.deepcopy(campaign)
    wrong["diagnostic_artifacts"]["eagle-target-run.json"]["bytes"] += 1
    with pytest.raises(ValueError, match="artifact changed"):
        validate_artifact_index(tmp_path, wrong, names)
    (tmp_path / "eagle-target.json").write_text("{changed}")
    with pytest.raises(ValueError, match="artifact changed"):
        validate_artifact_index(tmp_path, campaign, names)



def test_controlled_checker_command_accepts_only_explicit_fully_checked_verdicts():
    from tools.p7x_graph_repair13_eagle import checker_exit_status
    for status in ("PASS_SCOPED_EAGLE3_TARGET_PREFIX", "PASS_SCOPED_EAGLE3_TARGET_ARM",
                   "PASS_SCOPED_EAGLE3_BASELINE_ANCHOR", "PASS_SCOPED_EAGLE3_GRAPH_WINDOW_ANCHOR"):
        assert checker_exit_status(dict(status=status)) == 0
    for status in ("INVALID_EVIDENCE", "OPEN_NONDISCRIMINATING", "NUMERIC_MISMATCH", "FAIL", "PARTIAL",
                   "COMPLETE_DECLARED_PREFIX", "COMPLETE_DECLARED_TARGET_ARM", "PASS", "PASS_NEW_UNREVIEWED"):
        assert checker_exit_status(dict(status=status)) == 4
    assert checker_exit_status({}) == 4
