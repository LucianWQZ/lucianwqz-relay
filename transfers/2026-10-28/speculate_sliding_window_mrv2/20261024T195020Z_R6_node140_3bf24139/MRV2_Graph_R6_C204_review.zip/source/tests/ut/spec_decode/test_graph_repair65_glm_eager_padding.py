# SPDX-License-Identifier: Apache-2.0
"""Host-only strict padding-contrast evidence and real metadata-seam checks."""
import copy
import importlib.util
from pathlib import Path
from types import SimpleNamespace as N

import pytest
import torch

from tools.p7x_graph_repair65_glm_eager_padding import active_eager_metadata, check_contrast, build_kwargs


def test_active_reference_uses_real_eager_seam_without_publishing_another_generation():
    path=Path(__file__).with_name('test_draft_window_eager.py')
    loader=importlib.util.spec_from_file_location('padding_eager_fixture',path)
    fixtures=importlib.util.module_from_spec(loader);loader.loader.exec_module(fixtures)
    owner,_=fixtures._harness(query_width=8)
    owner.input_batch=fixtures._input_batch(req_ids=('A',),mapping=(1,),upper=(190,))
    owner.input_buffers.query_start_loc=torch.tensor([0,8,8,8,8],dtype=torch.int32)
    owner.block_tables.slot_mappings=owner.block_tables.slot_mappings.to(torch.int32)
    owner.device=torch.device('cpu');owner._group_causal={0:False}
    owner._draft_window_live_inputs=N(identity=N(global_group_id=0),cpu_window_upper=torch.tensor([193,0],dtype=torch.int32))
    live=owner._draft_window_live_inputs
    table=torch.tensor([[1,2,3],[0,0,0]],dtype=torch.int32)
    reference={'draft.layer':N(causal=False,actual_seq_lengths_q=[8,16],seq_lens_list=[193,0],block_tables=table)}
    before=owner.block_tables.slot_mappings.clone()
    result=active_eager_metadata(owner,reference)
    kwargs=owner.captured_builder_kwargs
    assert kwargs['num_reqs']==1 and kwargs['num_tokens']==8
    assert kwargs['query_start_loc_cpu'].tolist()==[0,8]
    assert kwargs['causal']=={0:False}
    assert kwargs['seq_lens_cpu'].tolist()==[193] and kwargs['block_tables'][0].tolist()==[[1,2,3]]
    assert owner._draft_window_live_inputs is live and owner._draft_window_selected_metadata is None
    assert torch.equal(before,owner.block_tables.slot_mappings) and set(result)=={'draft.layer'}


def metadata(tensor_values,rows):
    result=dict(causal=False,actual_seq_lengths_q=[8*i for i in range(1,rows+1)],
        seq_lens_list=[40]+[0]*(rows-1),num_actual_tokens=rows*8,num_prefills=0,num_decodes=rows)
    result.update(tensor_values)
    for key,value in tensor_values.items():
        result[key+'_header']=dict(shape=list(value.shape),dtype=str(value.dtype),stride=list(value.stride()),
                                  storage_offset=0,data_ptr=value.data_ptr())
    return result


def evidence():
    full=torch.tensor([[3],[0]],dtype=torch.int32)
    slots=torch.tensor(list(range(416,424))+[-1]*8,dtype=torch.int32)
    inp=dict(input_ids=torch.full((16,),17,dtype=torch.int32),
             positions=torch.tensor(list(range(32,40))+[0]*8,dtype=torch.int64))
    output=torch.zeros((16,6144),dtype=torch.bfloat16)
    before={f'draft.layer{i}/{j}':torch.full((2,128,4,192),float(i+j),dtype=torch.bfloat16)
            for i in range(5) for j in (0,1)}
    post={key:value.clone() for key,value in before.items()}
    for value in post.values():value[1,32:40]=.5
    padded={};unpad={}
    for i in range(5):
        values=dict(block_tables=full.clone(),seq_lens=torch.tensor([40,0],dtype=torch.int32),
            seq_lens_cpu=torch.tensor([40,0],dtype=torch.int32),slot_mapping=slots.clone(),
            query_start_loc=torch.tensor([0,8,8],dtype=torch.int32))
        padded[f'draft.layer{i}']=metadata(values,2)
        values={k:v[:1].clone() if k!='query_start_loc' and k!='slot_mapping' else
                v[:2].clone() if k=='query_start_loc' else v[:8].clone() for k,v in values.items()}
        unpad[f'draft.layer{i}']=metadata(values,1)
    record=dict(status='COMPLETED_PADDING_COMPARISON',descriptor=[1,2,16,8],
        submission=dict(pending=False,failure=None),completion='EXPLICIT_DIAGNOSTIC_CURRENT_STREAM_DRAINS',
        native_paths='TWO_ACTUAL_EAGER_BACKBONE_CALLS_NO_SAMPLING',actual_group=0,
        native_calls=[dict(tokens=16,mode='NONE',start_ns=1,return_ns=2,diagnostic_complete_ns=3),
                      dict(tokens=8,mode='NONE',start_ns=4,return_ns=5,diagnostic_complete_ns=6)],
        selected_blocks=[0,3],padded_output=output,unpadded_output=output[:8].clone(),
        identity=dict(generation=3,epoch=9),valid=[1],canonical_table=full,full_slots=slots,inputs=inp,
        original_query_layout=torch.tensor([0,8,8],dtype=torch.int32),
        pre_kv=before,restored_pre_kv=copy.deepcopy(before),padded_post_kv=post,
        unpadded_post_kv=copy.deepcopy(post),final_restored_kv=copy.deepcopy(post),
        padded_metadata=padded,unpadded_metadata=unpad)
    reference=dict(selected_blocks=[0,3],reference=output.clone(),generation=3,epoch=9,valid=[1],
        canonical_table=full.tolist(),reference_inputs={**inp,'slot_mapping':slots,
            'query_start_loc':record['original_query_layout'].clone()},
        runtime_identity=dict(global_group_id=0),reference_pre_kv=copy.deepcopy(before),reference_post_kv=copy.deepcopy(post))
    return record,reference


def test_legal_complete_host_surrogate_passes_with_zero_tolerance():
    result=check_contrast(*evidence())
    assert result['status']=='PASS' and result['finite'] is True
    assert result['hidden_different_elements']==0 and not result['changed_blocks']


@pytest.mark.parametrize('field',['hidden','padding_block0','valid_written_block','nonfinite'])
def test_real_numeric_differences_are_retained_and_never_hidden_by_padding(field):
    record,reference=evidence()
    if field=='hidden':record['unpadded_output'][0,0]=1
    elif field=='nonfinite':record['unpadded_output'][0,0]=float('nan')
    else:
        block=0 if field=='padding_block0' else 1
        record['unpadded_post_kv']['draft.layer0/0'][block,0,0,0]+=1
    result=check_contrast(record,reference)
    assert result['status']=='FAIL'
    if field=='padding_block0':assert result['changed_blocks'][0]['physical_block']==0


@pytest.mark.parametrize('damage',['prestate','restore','slot','position','canonical','generation','pending',
    'one_call','overlap','wrong_mode','missing_layer','metadata_row','causal','query','cpu_exact',
    'fake_header','wrong_group','hidden_dtype'])
def test_missing_or_contradictory_prestate_and_call_evidence_is_rejected(damage):
    record,reference=evidence()
    if damage=='prestate':record['restored_pre_kv']['draft.layer0/0'][0,0,0,0]+=1
    elif damage=='restore':record['final_restored_kv']['draft.layer0/0'][0,0,0,0]+=1
    elif damage=='slot':record['full_slots']=record['full_slots'].clone();record['full_slots'][0]+=1
    elif damage=='position':record['inputs']=copy.deepcopy(record['inputs']);record['inputs']['positions'][0]+=1
    elif damage=='canonical':record['canonical_table']=record['canonical_table'].clone();record['canonical_table'][0,0]=4
    elif damage=='generation':record['identity']['generation']+=1
    elif damage=='pending':record['submission']['pending']=True
    elif damage=='one_call':record['native_calls'].pop()
    elif damage=='overlap':record['native_calls'][1]['start_ns']=2
    elif damage=='wrong_mode':record['native_calls'][1]['mode']='FULL'
    elif damage=='missing_layer':record['unpadded_post_kv'].pop('draft.layer0/0')
    elif damage=='wrong_group':record['actual_group']=1
    elif damage=='hidden_dtype':record['unpadded_output']=record['unpadded_output'].float()
    else:
        m=record['unpadded_metadata']['draft.layer0']
        if damage=='metadata_row':m['block_tables']=torch.tensor([[4]],dtype=torch.int32)
        elif damage=='causal':m['causal']=True
        elif damage=='query':m['actual_seq_lengths_q']=[7]
        elif damage=='cpu_exact':m['seq_lens_cpu'][0]=41
        else:m['seq_lens_header']['dtype']='torch.int64'
    with pytest.raises((ValueError,KeyError)):
        check_contrast(record,reference)


def test_extra_padding_probe_keeps_the_existing_cp_model_and_capture_contract():
    kwargs=build_kwargs('ON',16)
    assert kwargs['speculative_config']['num_speculative_tokens']==8
    assert kwargs['additional_config']['draft_window_size']==1024
    assert kwargs['async_scheduling'] and kwargs['enable_prefix_caching']
    assert kwargs['compilation_config']['cudagraph_capture_sizes']==[16,32,48]
    for arm,tp in [('OFF',16),('ON',8)]:
        with pytest.raises(ValueError):build_kwargs(arm,tp)


def cpu_native_owner(monkeypatch,fail_second):
    import numpy as np
    from types import MethodType
    import tools.p7x_graph_repair65_glm_eager_padding as tool
    record,_=evidence()
    layers=sorted(record['padded_metadata'])
    caches={name:N(kv_cache=(torch.zeros((4,128,4,192),dtype=torch.bfloat16),
                           torch.zeros((4,128,4,192),dtype=torch.bfloat16))) for name in layers}
    owner=N(method='dspark',num_query_per_req=8,num_speculative_steps=8,draft_kv_cache_group_id=0,
        draft_attn_layer_names=set(layers),device=torch.device('cpu'),
        input_batch=N(num_reqs=1,idx_mapping_np=np.array([0],dtype=np.intp)),
        input_buffers=N(**record['inputs'],query_start_loc=record['original_query_layout']),
        block_tables=N(input_block_tables=[record['canonical_table']],
            num_blocks=N(cpu=torch.tensor([[1]],dtype=torch.int32)),slot_mappings=record['full_slots'].reshape(1,16)),
        kv_cache_config=N(kv_cache_groups=[N(layer_names=layers)]),
        _draft_window_live_inputs=N(identity=N(global_group_id=0,generation_id=3,mapping_epoch=9)))
    counters=dict(calls=0,drains=0,failed=False)
    shared_output=torch.zeros((16,6144),dtype=torch.bfloat16)
    def native(_owner,tokens,*args):
        counters['calls']+=1
        for cache in caches.values():
            cache.kv_cache[0][3,32:40]=counters['calls']
            cache.kv_cache[1][3,32:40]=counters['calls']
        shared_output.fill_(counters['calls'])
        if fail_second and counters['calls']==2:
            counters['failed']=True
            raise RuntimeError('CPU_SIMULATED_UNKNOWN_PARTIAL_CALL')
        return shared_output[:tokens]
    owner._run_model=MethodType(native,owner)
    class Stream:
        def synchronize(self):
            assert not counters['failed'],'no drain allowed after unknown submission'
            counters['drains']+=1
    monkeypatch.setattr(torch.npu,'current_stream',lambda:Stream())
    def active(_owner,metadata):
        return {name:N(**{k:v for k,v in row.items() if not k.endswith('_header')},num_decode_tokens=8)
                for name,row in record['unpadded_metadata'].items()}
    monkeypatch.setattr(tool,'active_eager_metadata',active)
    padded={name:N(**{k:v for k,v in row.items() if not k.endswith('_header')},num_decode_tokens=8)
            for name,row in record['padded_metadata'].items()}
    runner=N(speculator=owner,compilation_config=N(static_forward_context=caches))
    return runner,padded,counters


def test_actual_probe_preserves_first_output_before_second_call_overwrites_shared_storage(tmp_path,monkeypatch):
    from tools.p7x_graph_repair65_glm_eager_padding import PaddingContrast
    from tools.p7x_graph_repair6_storage import CollectionReader
    from vllm.config.compilation import CUDAGraphMode
    runner,metadata,counters=cpu_native_owner(monkeypatch,False)
    payload=dict(output=str(tmp_path),source_sha='a'*40,source_tree='b'*40,nonce='c'*32)
    with PaddingContrast(runner,payload,0) as probe:
        result=runner.speculator._run_model(16,metadata,{},None,CUDAGraphMode.NONE)
    saved=CollectionReader(probe.output).record(0)
    assert counters['calls']==2
    assert bool((result==1).all()) and bool((saved['padded_output']==1).all())
    assert bool((saved['unpadded_output']==2).all())
    assert torch.equal(saved['final_restored_kv']['draft.layer0/0'],saved['padded_post_kv']['draft.layer0/0'])
    assert CollectionReader(probe.output).execution=='EXECUTION_FAILED' # one Host sample is not the declared three


def test_actual_probe_never_drains_restores_or_exports_device_values_after_unknown_second_call(tmp_path,monkeypatch):
    import json
    from tools.p7x_graph_repair65_glm_eager_padding import PaddingContrast
    from vllm.config.compilation import CUDAGraphMode
    runner,metadata,counters=cpu_native_owner(monkeypatch,True)
    payload=dict(output=str(tmp_path),source_sha='a'*40,source_tree='b'*40,nonce='c'*32)
    with pytest.raises(RuntimeError,match='CPU_SIMULATED_UNKNOWN_PARTIAL_CALL'):
        with PaddingContrast(runner,payload,0) as probe:
            runner.speculator._run_model(16,metadata,{},None,CUDAGraphMode.NONE)
    assert counters['calls']==2 and counters['failed']
    saved=json.loads(probe.output.with_name('failure.json').read_text())
    assert saved['pending'] is True
    assert saved['phase']=='UNPADDED_RESTORE_BUILD_AND_FORWARD_PENDING'
    cache=runner.compilation_config.static_forward_context['draft.layer0'].kv_cache[0]
    assert float(cache[3,32,0,0])==2 # unknown partial write not overwritten by a finally restore
