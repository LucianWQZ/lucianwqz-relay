# SPDX-License-Identifier: Apache-2.0
"""Real P2/P6 Host seams for named Eagle TP2; never device completion proof."""
from dataclasses import replace
from types import SimpleNamespace

import pytest
import torch
from vllm.config.compilation import CUDAGraphMode
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor

from tests.ut.spec_decode.test_draft_window_graph_carrier import _runtime_fixture
from tests.ut.spec_decode.test_draft_window_graph_characterization import _runtime_context
from tests.ut.spec_decode.test_draft_window_graph_rank_identity import rank_runtime
from tests.ut.spec_decode.test_draft_window_graph_tp_review import config
from vllm_ascend.ascend_config import validate_draft_window_replicated_tp_review
from vllm_ascend.worker.v2.spec_decode.draft_window import build_draft_window_runtime_state
from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_capture import Eagle3GraphSession, build_eagle3_graph_source


@pytest.fixture(autouse=True)
def gate(monkeypatch):
    monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH','1')
    monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE','0')


def eagle_config(raw=True,tp=2):
    value=config(raw,tp)
    value.speculative_config.method='eagle3'
    value.speculative_config.num_speculative_tokens=3
    return value


def rank_owner(rank,raw=True):
    _,capability,tables=_runtime_fixture(method='eagle3',max_num_reqs=4,row_width=32,
                                         block_size=128,window_size=1024)
    tables.input_block_tables[0].add_(rank*1000)
    reference,_,_=rank_runtime(2,rank)
    topology=replace(reference.capability.eager_topology_fingerprint,
                     graph_mode='FULL_DECODE_ONLY',block_geometry=((128,128,128),))
    capability=replace(capability,eager_topology_fingerprint=topology)
    runtime=build_draft_window_runtime_state(capability)
    owner=SimpleNamespace(_draft_window_runtime_state=runtime,num_speculative_steps=3,max_model_len=4096,
        vllm_config=eagle_config(raw),block_tables=tables,method='eagle3',_draft_window_policy=object(),
        attn_groups=object())
    owner.speculative_config=owner.vllm_config.speculative_config
    for name,query in [('prefill_cudagraph_manager',4),('decode_cudagraph_manager',1)]:
        setattr(owner,name,SimpleNamespace(max_num_reqs=4,_capture_descs={CUDAGraphMode.FULL:[
            BatchExecutionDescriptor(cg_mode=CUDAGraphMode.FULL,num_reqs=4,num_tokens=4*query,
                                     uniform_token_count=query)]}))
    return owner,_runtime_context(tensor_parallel_size=2,tensor_parallel_rank=rank,
                                  graph_mode='FULL_DECODE_ONLY')


@pytest.mark.parametrize('rank',[0,1])
def test_real_source_builder_passes_actual_rank_and_explicit_review_to_p2(monkeypatch,rank):
    from vllm_ascend.worker.v2.spec_decode import draft_window_eagle3_capture as module
    owner,context=rank_owner(rank);calls=[]
    monkeypatch.setattr(module,'build_draft_window_runtime_context',lambda *a:context)
    def build(**kwargs):
        calls.append(kwargs)
        assert kwargs['allow_replicated_tp_graph_source'] is True
        assert kwargs['runtime_context'].tensor_parallel_size==2
        assert kwargs['runtime_context'].tensor_parallel_rank==rank
        assert kwargs['runtime_context'].graph_mode=='NONE'
        assert kwargs['runtime_route']=='eagle3' and kwargs['causal'] is True
        assert kwargs['attn_groups'] is owner.attn_groups
        return owner._draft_window_runtime_state.capability
    monkeypatch.setattr(module,'_build_draft_window_source_capability_for_context',build)
    capability,actual=build_eagle3_graph_source(owner)
    assert len(calls)==1 and actual is context
    assert capability.eager_topology_fingerprint.tensor_parallel_rank==rank
    assert capability.eager_topology_fingerprint.graph_mode=='FULL_DECODE_ONLY'


def test_each_rank_registers_all_actual_first_and_ar_consumers_in_its_own_banks():
    all_addresses=[]
    owners=[]
    for rank in [0,1]:
        owner,context=rank_owner(rank);owners.append(owner)
        session=Eagle3GraphSession(owner,context)
        assert len(session._captures)==3
        for identity in session._captures.values():
            fp=identity.fingerprint
            assert (fp.tensor_parallel_size,fp.tensor_parallel_rank,fp.parallel_read_semantics)==(2,rank,'replicated')
            assert fp.window_size==1024 and fp.query_width in [1,4]
            read=session.provider.startup_capture_read_inputs(identity)
            assert read.cpu_window_exact.tolist()==[1151]*4
            all_addresses.append(read.window_block_table.data_ptr())
    # Keep owners/sessions alive: no Python allocator id reuse may fake this check.
    assert len(set(all_addresses))==6


@pytest.mark.parametrize('raw',[False,'false'])
def test_eagle_tp2_without_review_is_still_rejected_before_registration(raw):
    owner,context=rank_owner(1,raw)
    with pytest.raises(NotImplementedError,match='TP=1'):Eagle3GraphSession(owner,context)


@pytest.mark.parametrize('world,k,dynamic',[(4,3,False),(16,3,False),(2,True,False),(2,2,False),(2,3,True)])
def test_eagle_review_does_not_widen_other_worlds_dynamic_k_or_malformed_contract(world,k,dynamic):
    value=eagle_config(tp=world);value.speculative_config.num_speculative_tokens=k
    value.speculative_config.uses_dynamic_speculative_decoding=lambda:dynamic
    with pytest.raises(ValueError):validate_draft_window_replicated_tp_review(value)


def test_rank_zero_p2_cannot_register_a_rank_one_session():
    owner,context=rank_owner(0)
    with pytest.raises(RuntimeError,match='capture/P2 TP'):
        Eagle3GraphSession(owner,replace(context,tensor_parallel_rank=1))
