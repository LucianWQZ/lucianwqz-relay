# SPDX-License-Identifier: Apache-2.0
"""CPU rank-contract/peer-failure checks; not numerical device evidence."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
import json
from types import SimpleNamespace as N

import pytest

from tools import p7x_graph_repair78_eagle_rank_numeric as tool
from tools.p7x_graph_repair25_rank_numeric import RankContract


def contract(rank=0):
    return RankContract(2,rank,'a'*32,123,'b'*40)


def test_actual_named_configuration_keeps_method_shape_and_normal_path_separate():
    _, kwargs=tool.configuration(N(arm='G_ON',tp=2,qwen36_model_pair=True))
    assert kwargs['speculative_config']['method']=='eagle3'
    assert kwargs['speculative_config']['num_speculative_tokens']==3
    assert kwargs['speculative_config']['enforce_eager'] is False
    assert kwargs['additional_config']['draft_window_size']==1024
    assert kwargs['additional_config']['draft_window_graph_numeric_diagnostic'] is True
    assert 'draft_window_graph_numeric_owned_output' not in kwargs['additional_config']
    assert kwargs['async_scheduling'] is False and kwargs['enable_prefix_caching'] is False
    assert [len(lengths) for _,lengths in tool.GROUPS]==[1,3,4]
    with pytest.raises(ValueError):tool.configuration(N(arm='G_OFF',tp=2,qwen36_model_pair=True))


@pytest.mark.parametrize('damage',[None,'busy','groups','nonce','world','dp','cp','engine'])
def test_idle_authority_is_actual_parent_snapshot_and_exact_rank_contract(damage):
    payload=dict(profile=tool.PROFILE,nonce='a'*32,parent_pid=123,source_sha='b'*40,engine_id=456,
                 scheduler_counts=dict(requests=0,running=0,waiting=0),
                 groups=[[label,list(lengths)]for label,lengths in tool.GROUPS])
    parallel=N(tensor_parallel_size=2,world_size=2,data_parallel_size=1,pipeline_parallel_size=1,
               prefill_context_parallel_size=1,decode_context_parallel_size=1)
    if damage=='busy':payload['scheduler_counts']['running']=1
    elif damage=='groups':payload['groups'][-1][1].pop()
    elif damage=='nonce':payload['nonce']='old'
    elif damage=='world':parallel.world_size=1
    elif damage=='dp':parallel.data_parallel_size=2
    elif damage=='cp':parallel.decode_context_parallel_size=2
    elif damage=='engine':payload['engine_id']=0
    if damage is None:assert tool.validate_idle_payload(payload,parallel,1)==contract(1)
    else:
        with pytest.raises(ValueError):tool.validate_idle_payload(payload,parallel,1)


def test_two_real_host_participants_reach_same_consumer_stage(tmp_path):
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs=[pool.submit(tool.checkpoint,tmp_path,contract(rank),'reference-ready',4,timeout=2)
              for rank in (0,1)]
        for job in jobs:job.result(timeout=4)
    rows=[json.loads(p.read_text())for p in tmp_path.glob('step-*.json')]
    assert len(rows)==2 and {r['rank']for r in rows}=={0,1}
    assert all(r['stage']=='reference-ready' and r['consumer']==4 for r in rows)


def test_peer_failure_prevents_even_a_previously_complete_stage(tmp_path):
    for rank in (0,1):
        row=dict(**asdict(contract(rank)),step=0,stage='graph-ready',consumer=0,
                 status='COMPLETED_SAMPLE',submission_pending=False)
        tool.write(tmp_path/f'step-000-rank-{rank}.json',row)
    tool.publish_failure(tmp_path,contract(1),RuntimeError('known failed peer'),True)
    original=(tmp_path/'failed-rank-1.json').read_text()
    tool.publish_failure(tmp_path,contract(1),RuntimeError('later error'),False)
    assert (tmp_path/'failed-rank-1.json').read_text()==original
    with pytest.raises(ValueError,match='peer diagnostic failed'):
        tool.checkpoint(tmp_path,contract(),'graph-ready',0,timeout=.1)


@pytest.mark.parametrize('damage',['nonce','stage','rank','pending'])
def test_corrupt_peer_checkpoint_does_not_authorize_next_consumer(tmp_path,damage):
    row=dict(**asdict(contract(1)),step=1,stage='reference-ready',consumer=0,
             status='COMPLETED_SAMPLE',submission_pending=False)
    if damage=='nonce':row['nonce']='c'*32
    elif damage=='stage':row['stage']='sample-done'
    elif damage=='rank':row['rank']=0
    else:row['submission_pending']=True
    tool.write(tmp_path/'step-001-rank-1.json',row)
    with pytest.raises(ValueError):tool.checkpoint(tmp_path,contract(),'reference-ready',0,timeout=.1)


def test_missing_peer_is_bounded_and_cannot_advance(tmp_path):
    with pytest.raises(TimeoutError):tool.checkpoint(tmp_path,contract(),'sample-done',8,timeout=.01)


def test_legacy_rankless_reference_has_no_added_device_or_host_checkpoint_behavior():
    from tools.p7x_graph_repair15_eagle_numeric import EagleContinuousReference
    reference=EagleContinuousReference.__new__(EagleContinuousReference)
    assert reference._rank_checkpoint('graph-ready',0) is None
    assert reference._record_rank_failure(RuntimeError('not installed')) is None


def test_completed_numeric_failure_is_published_before_peer_can_advance(tmp_path):
    from tools.p7x_graph_repair6_submission import NumericMismatch
    reference=tool.RankEagleReference.__new__(tool.RankEagleReference)
    reference.rank_contract,reference.checkpoint_root=contract(),tmp_path
    reference.submission=N(pending=False)
    with pytest.raises(NumericMismatch):reference._rank_checkpoint('sample-done',0,success=False)
    row=json.loads((tmp_path/'failed-rank-0.json').read_text())
    assert row['submission_pending'] is False and row['exception_type']=='NumericMismatch'


def test_unknown_submission_cannot_be_exported_as_a_completed_checkpoint(tmp_path):
    reference=tool.RankEagleReference.__new__(tool.RankEagleReference)
    reference.rank_contract,reference.checkpoint_root=contract(),tmp_path
    reference.submission=N(pending=True)
    with pytest.raises(ValueError,match='incomplete diagnostic'):
        reference._rank_checkpoint('reference-ready',0)
    assert not list(tmp_path.iterdir())
