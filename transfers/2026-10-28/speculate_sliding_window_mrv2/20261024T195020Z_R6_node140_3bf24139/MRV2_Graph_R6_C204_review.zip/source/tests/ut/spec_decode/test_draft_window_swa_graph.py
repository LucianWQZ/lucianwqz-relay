# SPDX-License-Identifier: Apache-2.0
"""Native-group operands, generation ownership and unchanged Full writes.

CPU implementation contracts only. These do not claim an NPU reader finished.
"""
from dataclasses import replace
from types import MethodType, SimpleNamespace as N

import pytest
import torch
from vllm.config.compilation import CUDAGraphMode
from vllm.v1.kv_cache_interface import FullAttentionSpec, SlidingWindowSpec
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor
from vllm.v1.worker.gpu.input_batch import InputBuffers

from tests.ut.spec_decode.test_draft_window import _attention_group
from tests.ut.spec_decode.test_draft_window_dp_graph_review import reviewed
from tests.ut.spec_decode.test_draft_window_graph_characterization import _runtime_context
from tests.ut.spec_decode.test_draft_window_graph_carrier import _Metadata, _target_metadata
from tests.ut.spec_decode.test_draft_window_eager import _input_batch
from vllm_ascend.ascend_config import validate_draft_window_replicated_tp_review
from vllm_ascend.attention.attention_v1 import (
    AscendAttentionBackend, AscendAttentionBackendImpl, AscendAttentionMetadataBuilder,
)
from vllm_ascend.worker.v2.spec_decode.draft_window import (
    DraftWindowExecutionPhase, build_draft_window_runtime_state, resolve_draft_window_policy,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_eager import (
    DraftWindowEagerMixin, build_eager_window_materialization_plan,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_graph import DraftWindowGraphRoute
from vllm_ascend.worker.v2.spec_decode import draft_window_graph_characterization as graph
from vllm_ascend.worker.v2.spec_decode.draft_window_swa_graph import (
    NativeSWAFullSnapshot, contains_native_band, partition_source,
)


@pytest.fixture(autouse=True)
def gate(monkeypatch):
    monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH','1')
    monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE','0')


def source_parts(split=True):
    names=[f'model.layers.{40+i}.self_attn.attn' for i in range(6)]
    groups=[[] for _ in range(16)]
    if split:
        for i in range(5):
            groups[10+i]=[_attention_group(global_group_id=10+i,layer_names=(names[i],),block_size=128,
                spec=SlidingWindowSpec(block_size=128,num_kv_heads=2,head_size=128,
                                       dtype=torch.bfloat16,sliding_window=4096))]
    else:
        groups[10]=[_attention_group(global_group_id=10,layer_names=tuple(names[:5]),block_size=128,
            spec=SlidingWindowSpec(block_size=128,num_kv_heads=2,head_size=128,
                                   dtype=torch.bfloat16,sliding_window=4096))]
    groups[15]=[_attention_group(global_group_id=15,layer_names=(names[5],),block_size=1024,
        spec=FullAttentionSpec(block_size=1024,num_kv_heads=2,head_size=128,dtype=torch.bfloat16))]
    logical=[128]*16;logical[15]=1024
    tables=N(block_sizes=logical,kernel_block_sizes=[128]*16,
             input_block_tables=[torch.arange(4*512,dtype=torch.int32).reshape(4,512)+10000*i for i in range(16)],
             num_blocks=N(cpu=torch.full((16,4),512,dtype=torch.int32),gpu=torch.full((16,4),512,dtype=torch.int32)),
             cp_size=1,cp_rank=0,cp_interleave=1,slot_mappings=torch.arange(16*64,dtype=torch.int32).reshape(16,64))
    buffers=InputBuffers(4,64,torch.device('cpu'))
    buffers.seq_lens[:4].copy_(torch.tensor([37000,8193,387,0],dtype=torch.int32))
    buffers.positions[:32].copy_(torch.arange(32,dtype=torch.int64)+40000)
    buffers.query_start_loc[:5].copy_(torch.tensor([0,8,16,24,24],dtype=torch.int32))
    causal={gid:gid!=15 for gid,members in enumerate(groups) if members}
    return groups,tables,buffers,causal


def owner(monkeypatch,split=True):
    groups,tables,buffers,causal=source_parts(split)
    vc=reviewed();vc.additional_config['draft_window_size']=32768
    vc.speculative_config.draft_model_config=N(hf_config=N(sliding_window=4096,use_sliding_window=True,
        layer_types=['sliding_attention']*5+['full_attention']))
    context=_runtime_context(tensor_parallel_size=4,tensor_parallel_rank=1,data_parallel_size=2,
                             graph_mode='FULL_DECODE_ONLY')
    monkeypatch.setattr(graph,'build_draft_window_runtime_context',lambda *args:context)
    policy=resolve_draft_window_policy(requested_window_size=32768,method='dflash',target_model_type='qwen3_5_moe')
    cap,_=graph.build_parallel_draft_window_graph_characterization_source(policy=policy,runtime_route='dflash',
        attn_groups=groups,block_tables=tables,input_buffers=buffers,causal=causal,vllm_config=vc)
    obj=N(vllm_config=vc,_draft_window_source_capability=cap,_draft_window_runtime_state=build_draft_window_runtime_state(cap),
          input_buffers=buffers,block_tables=tables,attn_groups=groups,_group_causal=causal,
          model_state=N(attn_metadata=_target_metadata()),num_query_per_req=8,arange=torch.arange(5,dtype=torch.int32),
          speculative_config=vc.speculative_config,query_cudagraph_manager=N(max_num_reqs=4,
            _capture_descs={CUDAGraphMode.FULL:[BatchExecutionDescriptor(cg_mode=CUDAGraphMode.FULL,
                num_tokens=n*8,num_reqs=n,uniform_token_count=8) for n in (1,2,4)]}),kv_cache_config=N())
    obj._build_ascend_draft_attn_metadata=MethodType(DraftWindowEagerMixin._build_ascend_draft_attn_metadata,obj)
    def build(_self,*,read_inputs,builder_kwargs):
        out={}
        for members in builder_kwargs['attn_groups']:
            for group in members:
                for name in group.layer_names:
                    gid=group.kv_cache_group_id;c=builder_kwargs['causal'];c=c if type(c) is bool else c[gid]
                    out[name]=_Metadata(block_tables=read_inputs.block_tables[gid],seq_lens=read_inputs.seq_lens,
                        seq_lens_cpu=read_inputs.seq_lens_cpu_exact,seq_lens_list=read_inputs.seq_lens_cpu_exact.tolist(),
                        slot_mapping=tables.slot_mappings[gid,:32],positions=buffers.positions[:32],
                        query_start_loc=buffers.query_start_loc[:5],actual_seq_lengths_q=[8,16,24,32],
                        nested={},attn_state=obj.model_state.attn_metadata[next(iter(obj.model_state.attn_metadata))].attn_state,
                        num_actual_tokens=32,causal=c)
        return out
    obj._call_ascend_draft_attn_metadata_builder=MethodType(build,obj)
    return obj,context


def bind_inputs(obj):
    runtime=obj._draft_window_runtime_state;cap=runtime.capability
    full=obj.input_buffers.seq_lens[:4].clone();upper=full.clone();upper[:3]+=7
    plan=build_eager_window_materialization_plan(provider=cap.provider,cpu_full_exact=full,
        cpu_apply_time_full_upper=upper,cpu_valid_num_blocks=torch.tensor([512]*3+[0],dtype=torch.int32),
        actual_request_count=3,padded_request_count=4)
    inputs=runtime.materialize(mapping_epoch=19,ordered_request_ids=('long','middle','short'),
        idx_mapping=torch.tensor([0,1,2],dtype=torch.int32),read_descriptors=plan.read_descriptors,
        device_window_exact=None,cpu_window_exact=plan.cpu_window_exact,cpu_window_upper=plan.cpu_window_upper,
        cpu_valid_num_blocks=plan.cpu_valid_num_blocks,num_reqs_padded=4,phase=DraftWindowExecutionPhase.PROPOSAL,
        step=0,execution_lane=0,quarantine_on_failure=True)
    obj._draft_window_live_inputs=inputs
    obj._draft_window_native_full_snapshot=NativeSWAFullSnapshot(inputs.identity,full,upper,obj.input_buffers.seq_lens[:4])
    return inputs


def test_band_bound_includes_parallel_offset_and_alignment_counterexample():
    assert not contains_native_band(4096,4096,8)
    assert not contains_native_band(4102,4096,8) and contains_native_band(4103,4096,8)
    e,w=8198,4102
    assert max(e-w,0)//128*128 > max(e-8-4096+1,0)  # First query loses one valid native token.
    for e in (257,4095,4096,4103,32768,32769,36865,40959):
        s=max(e-32768,0)//128*128
        assert all(s <= max(e-8+q-4096+1,0) for q in range(8))
    with pytest.raises(ValueError):contains_native_band(True,4096,8)


@pytest.mark.parametrize('damage',[None,'narrow','eager','wrong_tp','missing_swa','second_full'])
def test_review_window_config_does_not_open_a_different_route(damage):
    vc=reviewed();vc.additional_config['draft_window_size']=32768
    hf=N(sliding_window=4096,use_sliding_window=True,layer_types=['sliding_attention']*5+['full_attention'])
    vc.speculative_config.draft_model_config=N(hf_config=hf)
    if damage=='narrow':vc.additional_config['draft_window_size']=4102
    elif damage=='eager':vc.speculative_config.enforce_eager=True
    elif damage=='wrong_tp':
        vc.parallel_config.tensor_parallel_size=16;vc.speculative_config.draft_parallel_config.tensor_parallel_size=16
    elif damage=='missing_swa':hf.use_sliding_window=False
    elif damage=='second_full':hf.layer_types[0]='full_attention'
    if damage is None:assert validate_draft_window_replicated_tp_review(vc)
    else:
        with pytest.raises(ValueError):validate_draft_window_replicated_tp_review(vc)


@pytest.mark.parametrize('split',[False,True])
def test_real_source_keeps_all_native_groups_and_only_full_p3_source(monkeypatch,split):
    obj,_=owner(monkeypatch,split);cap=obj._draft_window_source_capability
    assert cap.inventory.consumer_global_group_ids==(15,)
    assert set(cap.native_swa_graph.native_layers)=={f'model.layers.{40+i}.self_attn.attn' for i in range(5)}
    assert len(cap.native_swa_graph.native_groups)==(5 if split else 1)
    assert cap.eager_topology_fingerprint.data_parallel_size==2
    assert cap.eager_topology_fingerprint.tensor_parallel_rank==1


def test_native_program_contract_cannot_drift_behind_the_same_full_carrier(monkeypatch):
    obj,context=owner(monkeypatch)
    session=graph.install_parallel_draft_window_graph_characterization(obj,runtime_context=context)
    cap=obj._draft_window_runtime_state.capability
    obj._draft_window_runtime_state.capability=replace(cap,native_swa_graph=replace(cap.native_swa_graph,window_size=40000))
    with pytest.raises(RuntimeError,match='contract changed'):session.provider.native_swa_graph_plan


@pytest.mark.parametrize('damage',['narrow','foreign_gid','overlap','wrong_cp','wrong_builder','wrong_block'])
def test_native_admission_rejects_unproved_or_changed_source(damage):
    groups,tables,buffers,causal=source_parts();window=32768
    if damage=='narrow':window=4096
    elif damage=='foreign_gid':groups[10][0].kv_cache_group_id=9
    elif damage=='overlap':groups[15][0].layer_names=groups[10][0].layer_names
    elif damage=='wrong_cp':tables.cp_size=2
    elif damage=='wrong_builder':groups[10][0].metadata_builders=[N()]
    else:tables.block_sizes[10]=256
    with pytest.raises(RuntimeError):partition_source(attn_groups=groups,block_tables=tables,input_buffers=buffers,
                                                       causal=causal,window_size=window,query_width=8)


@pytest.mark.parametrize('damage',[None,'native_window_table','native_window_exact','native_wrong_slot',
                                  'native_noncausal','missing_reader','stale_snapshot'])
def test_real_bind_and_backend_keep_native_operands_and_reject_corruption(monkeypatch,damage):
    obj,context=owner(monkeypatch);session=graph.install_parallel_draft_window_graph_characterization(obj,runtime_context=context)
    inputs=bind_inputs(obj);capture=session.resolve_capture_identity(obj.query_cudagraph_manager._capture_descs[CUDAGraphMode.FULL][-1])
    write=graph._build_write_side_reference(obj,capture,obj.model_state.attn_metadata)
    def build(read):
        result=graph._build_private_graph_metadata(obj,read_inputs=read,write_side=write,
            target_metadata=obj.model_state.attn_metadata,fingerprint=capture.fingerprint)
        native=obj._draft_window_source_capability.native_swa_graph.native_layers[0];meta=result.metadata[native]
        if damage=='native_window_table':meta.block_tables=read.window_block_table
        elif damage=='native_window_exact':meta.seq_lens_list=read.cpu_window_exact.tolist()
        elif damage=='native_wrong_slot':meta.slot_mapping=write.slot_mapping
        elif damage=='native_noncausal':meta.causal=False
        elif damage=='missing_reader':result.metadata.pop(native);result.private_isolation_view.pop(native)
        elif damage=='stale_snapshot':result=replace(result,native_full_snapshot=replace(result.native_full_snapshot,
                                                identity=replace(inputs.identity,mapping_epoch=20)))
        return result
    def bind():
        return session.provider.bind_read_carrier(capture_identity=capture,inputs=inputs,proposal_id=19,
            metadata_builder=build,target_metadata=obj.model_state.attn_metadata,write_side_reference=write)
    if damage:
        with pytest.raises(RuntimeError):bind()
        return
    carrier=bind();metadata=session.provider.consume_metadata(route=DraftWindowGraphRoute.DFLASH,expected_consumer_count=1)
    binding=session.provider.prepare_update_binding(route=DraftWindowGraphRoute.DFLASH,draft_attn_metadatas=metadata)
    session.provider.validate_backend_update(binding,attn_backend=AscendAttentionBackend,
        impl_cls=AscendAttentionBackendImpl,builder_cls=AscendAttentionMetadataBuilder,draft_attn_metadatas=metadata,
        update_function_path='vllm_ascend.compilation.acl_graph.update_full_graph_params')
    plan=obj._draft_window_source_capability.native_swa_graph
    assert metadata[0][plan.full_layers[0]].seq_lens_list[0] < 37000
    assert all(metadata[0][n].seq_lens_list==[37000,8193,387,0] for n in plan.native_layers)
    assert carrier.native_full_snapshot is obj._draft_window_native_full_snapshot
    assert carrier.backend_attribution.global_group_id==15


@pytest.mark.parametrize('fail',[False,True])
def test_existing_snapshot_is_owned_once_and_unknown_submission_retains_it(monkeypatch,fail):
    obj,context=owner(monkeypatch)
    graph.install_parallel_draft_window_graph_characterization(obj,runtime_context=context)
    DraftWindowEagerMixin._initialize_draft_window_eager_state(obj)
    obj.max_model_len=40960
    obj._require_current_draft_window_proposal=MethodType(DraftWindowEagerMixin._require_current_draft_window_proposal,obj)
    snapshots=[]
    def snapshot(_self,n):
        value=DraftWindowEagerMixin._snapshot_prepared_draft_seq_lens(obj,n);snapshots.append(value);return value
    obj._snapshot_prepared_draft_seq_lens=MethodType(snapshot,obj)
    batch=_input_batch(req_ids=('long','middle','short'),mapping=(0,1,2),upper=(37000,8193,387))
    def scope():
        with DraftWindowEagerMixin._draft_window_proposal_scope(obj,batch,dummy_run=False,is_profile=False):
            obj.input_batch=batch
            inputs=DraftWindowEagerMixin._materialize_draft_window_read_inputs(obj,num_reqs=3,num_reqs_padded=4)
            obj._draft_window_live_inputs=inputs
            native=obj._draft_window_native_full_snapshot
            assert native.cpu_exact is snapshots[0] and native.cpu_exact.data_ptr()!=obj.input_buffers.seq_lens.data_ptr()
            assert native.identity==inputs.identity and native.cpu_exact.tolist()==[37000,8193,387,0]
            if fail:raise RuntimeError('injected unknown submission')
    if fail:
        with pytest.raises(RuntimeError,match='unknown submission'):scope()
        assert obj._draft_window_native_full_snapshot.cpu_exact is snapshots[0]
        assert obj._draft_window_runtime_state.quarantined_identity is not None
        with pytest.raises(RuntimeError,match='quarantined'):
            with DraftWindowEagerMixin._draft_window_proposal_scope(obj,batch,dummy_run=False,is_profile=False):
                pytest.fail('quarantined native state reused')
    else:
        scope();assert obj._draft_window_native_full_snapshot is None
        obj.input_buffers.seq_lens[:3].fill_(1000)
        assert snapshots[0].tolist()==[37000,8193,387,0]
    assert len(snapshots)==1  # Reuse the existing controlled snapshot, not an added D2H.


def test_capture_uses_window_only_for_full_and_original_native_tables(monkeypatch):
    from vllm_ascend.worker.v2.spec_decode.dflash import capture as module
    from vllm.v1.worker.gpu.block_table import BlockTables

    obj,context=owner(monkeypatch)
    graph.install_parallel_draft_window_graph_characterization(obj,runtime_context=context)
    plan=obj._draft_window_source_capability.native_swa_graph
    # Exercise the fixed upstream zero/null initialization itself; the Window
    # adapter must not substitute a new native capture allocation.
    obj.block_tables.get_dummy_block_tables=MethodType(BlockTables.get_dummy_block_tables,obj.block_tables)
    obj.block_tables.get_dummy_slot_mappings=MethodType(BlockTables.get_dummy_slot_mappings,obj.block_tables)
    observed=[]
    def build(**kw):
        observed.append(kw)
        return {name:N(block_tables=kw['block_tables'][g.kv_cache_group_id],seq_lens=kw['seq_lens'])
                for members in kw['attn_groups'] for g in members for name in g.layer_names}
    monkeypatch.setattr(module,'build_attn_metadata',build)
    monkeypatch.setattr(module,'build_slot_mappings_by_layer',lambda slots,cfg:{
        name:slots[g.kv_cache_group_id] for members in obj.attn_groups for g in members for name in g.layer_names})
    with module.draft_window_dflash_capture_scope(obj,obj.input_buffers,
             obj.query_cudagraph_manager._capture_descs,max_num_reqs=4):
        state=module.ascend_prepare_dflash_inputs_to_capture(4,32,obj.input_buffers,obj.block_tables,
            obj.attn_groups,obj.kv_cache_config,40960,False,obj._group_causal)
    assert len(observed)==2
    full,native=observed
    assert full['seq_lens'].data_ptr()!=obj.input_buffers.seq_lens.data_ptr()
    assert native['seq_lens'].data_ptr()==obj.input_buffers.seq_lens.data_ptr()
    for group in plan.native_groups:
        assert native['block_tables'][group.gid].data_ptr()==obj.block_tables.input_block_tables[group.gid].data_ptr()
        assert all(native['causal'][group.gid] is True for _ in group.layers)
    assert full['causal'][plan.full_gid] is False
    assert set(state.attn_metadata)==set(plan.full_layers+plan.native_layers)
    assert all(torch.count_nonzero(t)==0 for t in obj.block_tables.input_block_tables)
    assert torch.all(obj.block_tables.slot_mappings==-1)
