# SPDX-License-Identifier: Apache-2.0
"""Raw streaming tokens/usage/time must agree; bursts are never fake token ITL."""
import copy
import asyncio
import json

import pytest

from tools.p7x_graph_repair33_service import serve_argv, stream_summary


def stream():
    return [dict(received_ns=120,data=dict(id="response-1",choices=[dict(index=0,prompt_token_ids=[7,8],token_ids=[10,11])])),
            dict(received_ns=140,data=dict(id="response-1",choices=[dict(index=0,token_ids=[12])])),
            dict(received_ns=150,data=dict(id="response-1",choices=[],usage=dict(prompt_tokens=2,completion_tokens=3,total_tokens=5)))]


def test_true_token_bursts_do_not_invent_per_token_latency():
    result=stream_summary(stream(),start_ns=100,end_ns=160,expected_prompt=[7,8],expected_output=3)
    assert result["token_ids"] == [10,11,12]
    assert result["ttft_seconds"] == 20/1e9 and result["mean_tpot_seconds"] == 10/1e9
    assert result["observed_inter_chunk_intervals"] == [dict(interval_ns=20,delivered_tokens=1)]
    assert result["token_itl_distribution"].startswith("NOT_AVAILABLE")


@pytest.mark.parametrize("damage",["prompt","missing_usage","wrong_count","float_count","bool_token","empty_token","clock","unordered","duplicate_prompt","duplicate_usage","choice","response"])
def test_corrupt_or_incomplete_raw_stream_is_rejected(damage):
    rows=copy.deepcopy(stream())
    if damage == "prompt": rows[0]["data"]["choices"][0]["prompt_token_ids"]=[9,8]
    elif damage == "missing_usage": rows.pop()
    elif damage == "wrong_count": rows[-1]["data"]["usage"]["completion_tokens"]=2
    elif damage == "float_count": rows[-1]["data"]["usage"]["completion_tokens"]=3.0
    elif damage == "bool_token": rows[0]["data"]["choices"][0]["token_ids"]=[True,11]
    elif damage == "empty_token": rows[0]["data"]["choices"][0]["token_ids"]=[]
    elif damage == "clock": rows[0]["received_ns"]=99
    elif damage == "unordered": rows[1]["received_ns"]=110
    elif damage == "duplicate_prompt": rows[1]["data"]["choices"][0]["prompt_token_ids"]=[7,8]
    elif damage == "duplicate_usage": rows.append(copy.deepcopy(rows[-1]))
    elif damage == "response": rows[1]["data"]["id"]="another-response"
    else: rows[1]["data"]["choices"][0]["index"]=False
    with pytest.raises(ValueError):
        stream_summary(rows,start_ns=100,end_ns=160,expected_prompt=[7,8],expected_output=3)


@pytest.mark.parametrize("arm,eager,window",[("G_OFF",False,{}),("G_ON",False,{"draft_window_size":1024}),("E_ON",True,{"draft_window_size":1024})])
def test_official_user_cli_keeps_target_graph_and_has_no_private_worker_or_driver(arm,eager,window):
    argv=serve_argv("/actual/python",18140,"fixed-model",arm)
    assert argv[:5] == ["/actual/python","-m","vllm.entrypoints.cli.main","serve","/mnt/share/wql/Qwen3-8B"]
    assert json.loads(argv[argv.index("--speculative-config")+1])["enforce_eager"] is eager
    assert json.loads(argv[argv.index("--additional-config")+1]) == window
    assert json.loads(argv[argv.index("--compilation-config")+1])["cudagraph_mode"] == "FULL_DECODE_ONLY"
    assert "--enforce-eager" not in argv and "--worker-cls" not in argv and "--worker-extension-cls" not in argv
    assert "--no-async-scheduling" in argv and "--no-enable-prefix-caching" in argv


def test_independent_reader_rejects_missing_warmup_or_forged_latency():
    from tools.p7x_graph_repair33_service import validate_requests
    groups=[dict(label="short",max_tokens=3,prompts=[dict(prompt_token_ids=[7,8])])]
    body=dict(model="fixed-model",prompt=[7,8],max_tokens=3,min_tokens=3,temperature=0,seed=0,ignore_eos=True,stream=True,return_token_ids=True)
    result=dict(request=body,start_ns=100,end_ns=160,events=stream(),terminal_done=True,
                summary=stream_summary(stream(),start_ns=100,end_ns=160,expected_prompt=[7,8],expected_output=3))
    for event in result["events"]:event["data"]["model"]="fixed-model"
    doc=dict(status="COMPLETE",groups=[dict(phase=phase,label="short",group_start_ns=90,group_end_ns=170,
                                          results=[copy.deepcopy(result)]) for phase in ("warmup","measured")])
    measured=doc["groups"][1];measured["group_start_ns"]+=100;measured["group_end_ns"]+=100
    for res in measured["results"]:
        res["start_ns"]+=100;res["end_ns"]+=100
        for event in res["events"]:
            event["received_ns"]+=100;event["data"]["id"]="response-2"
        res["summary"]=stream_summary(res["events"],start_ns=res["start_ns"],end_ns=res["end_ns"],
                                      expected_prompt=[7,8],expected_output=3,expected_model="fixed-model")
    campaign=dict(start_monotonic_ns=80,end_monotonic_ns=280,status="OFFICIAL_CLI_HTTP_REQUESTS_COMPLETE_NOT_NUMERIC_OR_COMPLETION_PROOF",server_rc=0,
                  server_argv=["official","serve","--served-model-name","fixed-model"],measured_requests=1)
    assert validate_requests(campaign,doc,groups,expected_server_argv=campaign["server_argv"])["measured_requests"] == 1
    bad=copy.deepcopy(doc);bad["groups"].pop(0)
    with pytest.raises(ValueError):validate_requests(campaign,bad,groups,expected_server_argv=campaign["server_argv"])
    bad=copy.deepcopy(doc);bad["groups"][1]["results"][0]["summary"]["ttft_seconds"]=0
    with pytest.raises(ValueError):validate_requests(campaign,bad,groups,expected_server_argv=campaign["server_argv"])
    bad=copy.deepcopy(doc);bad["groups"][1]["results"][0]["terminal_done"]=False
    with pytest.raises(ValueError,match="terminal event"):
        validate_requests(campaign,bad,groups,expected_server_argv=campaign["server_argv"])


def test_real_absolute_cli_bootstraps_before_urllib_random_bisect(tmp_path):
    import subprocess
    import sys
    from pathlib import Path
    tool=Path(__file__).resolve().parents[3]/"tools/p7x_graph_repair33_service.py"
    assert (tool.parent/"bisect/__init__.py").is_file()
    result=subprocess.run([sys.executable,str(tool),"run","--help"],cwd=tmp_path,
                          capture_output=True,text=True,timeout=30)
    assert result.returncode==0,result.stderr
    assert "--admission" in result.stdout and "--port" in result.stdout
    assert "cannot import name 'bisect'" not in result.stderr


@pytest.mark.parametrize('cache_salt',[None,'fixed-benchmark-cache-namespace'])
def test_actual_http_stream_is_not_consumed_by_success_status_message(cache_salt):
    """Exercise the client against a real HTTP socket, including terminal SSE."""
    from aiohttp import ClientSession, web
    from tools.p7x_graph_repair33_service import request

    async def run():
        async def respond(incoming):
            body = await incoming.json()
            assert body['prompt'] == [7, 8] and body['stream'] is True
            assert body.get('cache_salt')==cache_salt
            response = web.StreamResponse(headers={'Content-Type': 'text/event-stream'})
            await response.prepare(incoming)
            for row in stream():
                value = dict(row['data'], model='actual-http-model')
                frame = ('data: ' + json.dumps(value) + '\n\n').encode()
                await response.write(frame[:9])
                await asyncio.sleep(0)
                await response.write(frame[9:])
            await response.write(b'data: [DONE]\n\n')
            await response.write_eof()
            return response

        application = web.Application()
        application.router.add_post('/v1/completions', respond)
        runner = web.AppRunner(application)
        await runner.setup()
        site = web.TCPSite(runner, '127.0.0.1', 0)
        try:
            await site.start()
            port = site._server.sockets[0].getsockname()[1]
            async with ClientSession() as session:
                result = await request(session, f'http://127.0.0.1:{port}/v1/completions',
                                       model='actual-http-model', prompt=[7, 8], output=3,cache_salt=cache_salt)
            assert result['summary']['token_ids'] == [10, 11, 12]
            assert result['summary']['usage']['completion_tokens'] == 3
            assert len(result['events']) == 3
            assert result['terminal_done'] is True
        finally:
            await runner.cleanup()

    asyncio.run(run())


@pytest.mark.parametrize('http_status,terminal,expected', [
    (200, False, 'stream lacks DONE'),
    (503, False, 'HTTP completion status 503: temporarily unavailable'),
])
def test_actual_http_failure_keeps_partial_events_and_still_rejects(tmp_path, http_status, terminal, expected):
    from aiohttp import ClientSession, web
    from tools.p7x_graph_repair33_service import request

    async def run():
        async def respond(incoming):
            if http_status != 200:
                return web.Response(status=http_status, text='temporarily unavailable')
            response = web.StreamResponse(headers={'Content-Type': 'text/event-stream'})
            await response.prepare(incoming)
            for row in stream():
                await response.write(('data: '+json.dumps(dict(row['data'], model='actual-http-model'))+'\n\n').encode())
            if terminal:
                await response.write(b'data: [DONE]\n\n')
            await response.write_eof()
            return response

        application = web.Application()
        application.router.add_post('/v1/completions', respond)
        runner = web.AppRunner(application)
        await runner.setup()
        site = web.TCPSite(runner, '127.0.0.1', 0)
        try:
            await site.start()
            port = site._server.sockets[0].getsockname()[1]
            failure = tmp_path/'partial.json'
            async with ClientSession() as session:
                with pytest.raises(ValueError, match=expected):
                    await request(session, f'http://127.0.0.1:{port}/v1/completions',
                                  model='actual-http-model', prompt=[7, 8], output=3, failure_path=failure)
            partial = json.loads(failure.read_text())
            assert partial['status'] == 'FAILED_PARTIAL_CLIENT_EVENTS'
            assert partial['terminal_done'] is False
            assert len(partial['events']) == (3 if http_status == 200 else 0)
        finally:
            await runner.cleanup()

    asyncio.run(run())
