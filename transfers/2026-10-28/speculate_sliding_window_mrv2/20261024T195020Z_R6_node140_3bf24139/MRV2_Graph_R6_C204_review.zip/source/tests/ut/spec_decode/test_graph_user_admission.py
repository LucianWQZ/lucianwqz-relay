"""Host checks for the user authorized, machine observed TP1 admission path."""

import copy
import json
from types import SimpleNamespace

import pytest


@pytest.mark.parametrize(
    "damage",
    [None, "owner_claim", "visibility", "mapping", "stale", "expired", "occupied"],
)
def test_user_admission_keeps_authorization_and_mapping_separate(tmp_path, monkeypatch, damage):
    from tools.p7x_graph_repair5_evidence import file_sha
    from tools.p7x_graph_repair7_device import validate_receipt

    authorization = tmp_path / "user-authorization.json"
    authorization.write_text(
        json.dumps(
            dict(
                schema="mrv2-user-device-authorization-v1",
                authority="USER_INSTRUCTION_NO_ADMIN_SIGNATURE",
                host_phy_ids=list(range(8)),
                deadline_epoch_seconds=100,
            )
        )
    )
    mapping = tmp_path / "mapping.txt"
    mapping.write_text("0 0 0 0 Ascend910\n")
    resources = tmp_path / "resources.txt"
    resources.write_text("No running processes found in NPU 0\n")
    probe = tmp_path / "probe.json"
    probe.write_text(
        json.dumps(
            dict(
                pid=42,
                rc=0,
                visibility="0",
                stdout='{"value": 1024.0, "logical_device": 0}',
                observations=[dict(smi_mentions_pid=True)],
            )
        )
    )
    process = tmp_path / "process.txt"
    process.write_text("| 0       0 | 42 | probe | 123 | 42 |\n")

    def evidence(path):
        return dict(path=str(path), sha256=file_sha(path))

    state = dict(
        namespace="mnt:test",
        boot_id="host",
        visibility={"ASCEND_RT_VISIBLE_DEVICES": "0", "ASCEND_VISIBLE_DEVICES": None},
        nodes={"/dev/davinci0": dict(major=234, minor=0)},
        mapping_command=dict(rc=0, stdout=mapping.read_text()),
    )
    receipt = dict(
        schema="repair7-user-authorized-device-v1",
        run_id="r",
        user_authorization=evidence(authorization),
        issued_at=1,
        expires_at=99,
        host_phy_id=0,
        tp=1,
        allocated_nodes=state["nodes"],
        namespace=state["namespace"],
        boot_id=state["boot_id"],
        visibility=state["visibility"],
        mapping_evidence=[evidence(mapping)],
        resource_evidence=[evidence(resources)],
        resource_observed_at=10,
        probe=dict(
            host_pid=42,
            container_pid=42,
            command=["probe"],
            start_ns=1,
            end_ns=2,
            host_phy_id=0,
            status="EXITED",
            returncode=0,
            host_process_evidence=evidence(process),
            pid_namespace_evidence=evidence(probe),
        ),
    )
    receipt, state = copy.deepcopy(receipt), copy.deepcopy(state)
    live = resources.read_text() if damage != "occupied" else "Process id 999 in NPU 0"
    monkeypatch.setattr(
        "tools.p7x_graph_repair7_device.subprocess.run",
        lambda *args, **kwargs: SimpleNamespace(returncode=0, stdout=live),
    )
    if damage == "owner_claim":
        receipt["allocation_owner"] = "fake admin"
    elif damage == "visibility":
        state["visibility"]["ASCEND_RT_VISIBLE_DEVICES"] = "1"
    elif damage == "mapping":
        state["mapping_command"]["stdout"] = "0 0 1 1 Ascend910"
    elif damage == "stale":
        receipt["resource_observed_at"] = -100
    elif damage == "expired":
        receipt["expires_at"] = 101
    if damage:
        with pytest.raises(ValueError):
            validate_receipt(receipt, state, "r", now=50)
    else:
        result = validate_receipt(receipt, state, "r", now=50)
        assert result["status"] == "ADMITTED_BY_USER_AUTHORIZATION_AND_MACHINE_EVIDENCE"


@pytest.mark.parametrize(
    "damage",
    [
        None,
        "scope",
        "physical",
        "host",
        "boot",
        "missing_host",
        "missing_boot",
        "mapping",
        "probe_physical",
        "owner_claim",
        "expired",
        "occupied",
    ],
)
def test_back_eight_user_scope_is_node_bound(tmp_path, monkeypatch, damage):
    from tools.p7x_graph_repair5_evidence import file_sha
    from tools.p7x_graph_repair7_device import validate_receipt

    authorization = dict(
        schema="mrv2-user-device-authorization-v1",
        authority="USER_INSTRUCTION_NO_ADMIN_SIGNATURE",
        host_phy_ids=list(range(8, 16)),
        hostname="node-25-140",
        boot_id="boot140",
        deadline_epoch_seconds=100,
    )
    if damage == "scope":
        authorization["host_phy_ids"] = list(range(16))
    if damage == "host":
        authorization["hostname"] = "node-39-101"
    if damage == "boot":
        authorization["boot_id"] = "old-boot"
    if damage == "missing_host":
        authorization.pop("hostname")
    if damage == "missing_boot":
        authorization.pop("boot_id")
    auth_path = tmp_path / "authorization.json"
    auth_path.write_text(json.dumps(authorization))
    resources = tmp_path / "resources.txt"
    resources.write_text("No running processes found in NPU 4\n")
    mapping = tmp_path / "mapping.txt"
    mapping.write_text("4 0 8 8 Ascend910\n")
    observed = tmp_path / "observed.txt"
    observed.write_text("| 4 0 | 42 | probe | 123 | 42 |\n")
    probe = tmp_path / "probe.json"
    probe.write_text(
        json.dumps(
            dict(
                pid=42,
                rc=0,
                visibility="8",
                stdout='{"value": 1024.0, "logical_device": 0}',
                observations=[dict(smi_mentions_pid=True)],
            )
        )
    )

    def evidence(path):
        return dict(path=str(path), sha256=file_sha(path))

    state = dict(
        hostname="node-25-140",
        boot_id="boot140",
        namespace="mnt:140",
        visibility={"ASCEND_RT_VISIBLE_DEVICES": "8", "ASCEND_VISIBLE_DEVICES": None},
        nodes={"/dev/davinci8": dict(major=234, minor=8)},
        mapping_command=dict(rc=0, stdout=mapping.read_text()),
    )
    receipt = dict(
        schema="repair7-user-authorized-device-v1",
        run_id="r",
        user_authorization=evidence(auth_path),
        issued_at=1,
        expires_at=99,
        host_phy_id=8,
        tp=1,
        allocated_nodes=state["nodes"],
        namespace=state["namespace"],
        boot_id=state["boot_id"],
        visibility=state["visibility"],
        mapping_evidence=[evidence(mapping)],
        resource_evidence=[evidence(resources)],
        resource_observed_at=10,
        probe=dict(
            host_pid=42,
            container_pid=42,
            command=["probe"],
            start_ns=1,
            end_ns=2,
            host_phy_id=8,
            status="EXITED",
            returncode=0,
            host_process_evidence=evidence(observed),
            pid_namespace_evidence=evidence(probe),
        ),
    )
    if damage == "physical":
        receipt["host_phy_id"] = 0
    if damage == "mapping":
        state["mapping_command"]["stdout"] = "4 1 9 9 Ascend910"
    if damage == "probe_physical":
        receipt["probe"]["host_phy_id"] = 9
    if damage == "owner_claim":
        receipt["allocation_owner"] = "not-an-admin"
    if damage == "expired":
        receipt["expires_at"] = 101
    live = resources.read_text() if damage != "occupied" else "Process id 999 in NPU 4"
    monkeypatch.setattr(
        "tools.p7x_graph_repair7_device.subprocess.run", lambda *a, **kw: SimpleNamespace(returncode=0, stdout=live)
    )
    if damage:
        with pytest.raises(ValueError):
            validate_receipt(receipt, state, "r", now=50)
    else:
        result = validate_receipt(receipt, state, "r", now=50)
        assert result["physical_id"] == 8
        assert result["status"] == "ADMITTED_BY_USER_AUTHORIZATION_AND_MACHINE_EVIDENCE"
