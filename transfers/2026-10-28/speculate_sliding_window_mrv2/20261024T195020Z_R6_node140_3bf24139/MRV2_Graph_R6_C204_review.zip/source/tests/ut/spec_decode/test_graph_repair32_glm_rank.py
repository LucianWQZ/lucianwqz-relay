# SPDX-License-Identifier: Apache-2.0
"""GLM's named profile cannot inherit Qwen model/backend/capture claims."""
import hashlib
import json

import pytest

from tools.p7x_graph_repair28_rank_anchor_check import validate_payload
from tools.p7x_graph_repair32_glm_rank import (CAPTURE, DRAFT, PROFILE, TARGET, build_glm_kwargs,
                                              validate_glm_worker, validate_model_configs, actual_draft_mask)
from tests.ut.spec_decode.test_graph_repair28_rank_anchor_check import evidence


def actual_configs():
    return (dict(architectures=["GlmMoeDsaForCausalLM"], model_type="glm_moe_dsa", num_hidden_layers=78,
                 hidden_size=6144, max_position_embeddings=1048576),
            dict(architectures=["DSparkDraftModel"], block_size=8, sample_from_anchor=True,
                 sliding_window_non_causal=False,
                 transformer_layer_config=dict(model_type="qwen3", num_hidden_layers=5, hidden_size=6144,
                                               num_attention_heads=64, num_key_value_heads=64, head_dim=192,
                                               max_position_embeddings=1048576)))


def glm_evidence(review=False):
    c, p, e, r = evidence(16, review=review)
    kwargs = build_glm_kwargs(16, window_on_review=review)
    c.update(kwargs=kwargs, config_sha256=hashlib.sha256(json.dumps(kwargs, sort_keys=True).encode()).hexdigest())
    for worker in c["ranks"]:
        worker["draft_graph_inventory"] = [dict(requests=n, tokens=n*8, mode="FULL") for n in (1,2,4)]
        worker["target_graph_inventory"] = [dict(requests=n, tokens=n*9, mode="FULL") for n in (1,2,4)]
        for geometry in worker["draft_kv_geometry"].values(): geometry["shape"] = [64,128,4,192]
        worker["glm_profile"] = dict(profile=PROFILE, k=8, draft_query=8, sample_from_anchor=True, noncausal=True,
            normalized_layer_types=["full_attention"]*5,normalized_causal_override=None,
            actual_layer_causal=[False]*5,group_causal=[dict(global_group_id=2,causal=False)],
            mask_source="NORMALIZED_CONFIG_ACTUAL_MODEL_AND_SPECULATOR_GROUP_MASKS",
            draft_groups=[dict(global_group_id=2,layers=worker["draft_layers"],backend="attention_v1.AscendAttentionBackend")],
            target_model=str(TARGET), draft_model=str(DRAFT), target_groups=[dict(global_group_id=0,
            layers=[f"target.layer{i}" for i in range(78)], backend="vllm_ascend.attention.sfa_v1.AscendSFABackend"), dict(global_group_id=1,
            layers=[f"target.indexer{i}" for i in range(21)], backend="vllm_ascend.attention.indexer.AscendSFAIndexerBackend")])
        for item in worker.get("window_generations", []) + worker.get("window_graph_bindings", []):
            item["global_group_id"] = 2
    return c,p,e,r


def test_fixed_profile_has_independent_k_query_causal_and_no_pr_pin_inheritance():
    validate_model_configs(*actual_configs())
    off, on = build_glm_kwargs(16), build_glm_kwargs(16, window_on_review=True)
    assert off["model"] == str(TARGET) and off["speculative_config"]["model"] == str(DRAFT)
    assert off["speculative_config"]["num_speculative_tokens"] == 8
    assert off["compilation_config"]["cudagraph_capture_sizes"] == CAPTURE
    assert off["additional_config"] == {} and on["additional_config"]["draft_window_size"] == 1024
    assert off["quantization"] == "ascend" and off["max_model_len"] == 4096
    assert not off["async_scheduling"] and not off["enable_prefix_caching"]
    for tp in (True,1,2,4,8):
        with pytest.raises(ValueError): build_glm_kwargs(tp)


@pytest.mark.parametrize("damage",["method","sample","causal","head","layers","maxlen"])
def test_mismatched_model_semantics_cannot_be_silently_cast_to_glm_profile(damage):
    target,draft=actual_configs()
    if damage == "method": draft["architectures"]=["DFlashDraftModel"]
    elif damage == "sample": draft["sample_from_anchor"]=False
    elif damage == "causal": draft["sliding_window_non_causal"]=True
    elif damage == "head": draft["transformer_layer_config"]["head_dim"]=128
    elif damage == "layers": target["num_hidden_layers"]=77
    else: target["max_position_embeddings"]=2048
    with pytest.raises(ValueError): validate_model_configs(target,draft)


@pytest.mark.parametrize("review",[False,True])
def test_real_all_rank_contract_is_specific_to_target_sfa_and_dense_draft(review):
    c,p,e,r=glm_evidence(review)
    result=validate_payload(c,p,e,r,"/source",kwargs_factory=build_glm_kwargs,worker_validator=validate_glm_worker)
    assert result["ranks"] == 16
    with pytest.raises(ValueError): validate_payload(c,p,e,r,"/source")


@pytest.mark.parametrize("damage",["missing_rank","qwen_geometry","target_dense","target_layer","indexer","bucket","query","causal","model","kv_missing","group","wrong_arm"])
def test_corrupt_profile_or_one_rank_is_independently_rejected(damage):
    c,p,e,r=glm_evidence(True);w=c["ranks"][-1]
    if damage == "missing_rank": c["ranks"].pop()
    elif damage == "qwen_geometry": next(iter(w["draft_kv_geometry"].values()))["shape"]=[64,128,1,128]
    elif damage == "target_dense": w["glm_profile"]["target_groups"][0]["backend"]="attention_v1.AscendAttentionBackend"
    elif damage == "target_layer": w["glm_profile"]["target_groups"][0]["layers"].pop()
    elif damage == "indexer": w["glm_profile"]["target_groups"][1]["layers"].pop()
    elif damage == "bucket": w["target_graph_inventory"].pop()
    elif damage == "query": w["glm_profile"]["draft_query"]=7
    elif damage == "causal": w["glm_profile"]["noncausal"]=False
    elif damage == "model": w["glm_profile"]["target_model"]="/Qwen3-8B"
    elif damage == "kv_missing": w["draft_kv_geometry"].pop(next(iter(w["draft_kv_geometry"])))
    elif damage == "group": w["window_graph_bindings"][0]["global_group_id"]=0
    else: c["kwargs"]["additional_config"]={}
    with pytest.raises(ValueError):
        validate_payload(c,p,e,r,"/source",kwargs_factory=build_glm_kwargs,worker_validator=validate_glm_worker)


def test_actual_full_attention_worker_mask_does_not_read_swa_only_raw_attribute():
    from types import SimpleNamespace as N
    spec=N(draft_model_config=N(hf_config=N(layer_types=["full_attention"]*5)),
           model=N(get_draft_attn_causal=lambda:[False]*5),
           requires_non_causal=True,_group_causal={2:False})
    assert not hasattr(spec.draft_model_config.hf_config,"sliding_window_non_causal")
    got=actual_draft_mask(spec,[dict(global_group_id=2)])
    assert got["noncausal"] is True and got["actual_layer_causal"]==[False]*5
    assert got["group_causal"]==[dict(global_group_id=2,causal=False)]
    spec._group_causal={2:True}
    with pytest.raises(ValueError,match="global group"):actual_draft_mask(spec,[dict(global_group_id=2)])
    spec._group_causal={2:False};spec.requires_non_causal=False
    with pytest.raises(ValueError,match="noncausal"):actual_draft_mask(spec,[dict(global_group_id=2)])
    spec.requires_non_causal=True;spec.draft_model_config.hf_config.dflash_config={"causal":True}
    with pytest.raises(ValueError,match="global causal override"):actual_draft_mask(spec,[dict(global_group_id=2)])


@pytest.mark.parametrize("damage",["normalized","layer_mask","actual_group","untyped_group","source"])
def test_effective_masks_cannot_be_replaced_by_the_raw_swa_flag(damage):
    c,p,e,r=glm_evidence(True);profile=c["ranks"][-1]["glm_profile"]
    if damage=="normalized":profile["normalized_causal_override"]=True
    elif damage=="layer_mask":profile["actual_layer_causal"][-1]=True
    elif damage=="actual_group":profile["group_causal"][0]["causal"]=True
    elif damage=="untyped_group":profile["group_causal"][0]["causal"]=0
    else:profile["mask_source"]="RAW_CONFIG_ONLY"
    with pytest.raises(ValueError,match="masks disagree"):
        validate_payload(c,p,e,r,"/source",kwargs_factory=build_glm_kwargs,worker_validator=validate_glm_worker)


def test_target_layout_headers_do_not_read_or_copy_tensor_contents(monkeypatch):
    import torch
    from tools.p7x_graph_repair32_glm_rank import cache_headers
    tensor=torch.zeros((3,128,4,192),dtype=torch.bfloat16);view=tensor[1:]
    for name in ['cpu','numpy','tolist','item','clone']:
        monkeypatch.setattr(torch.Tensor,name,lambda *args,**kwargs:pytest.fail('headers must not read/clone tensor data'))
    result=cache_headers([tensor,view,None]);a,b,_=result['items']
    assert a['shape']==[3,128,4,192] and b['shape']==[2,128,4,192]
    assert a['storage_data_ptr']==b['storage_data_ptr'] and a['data_ptr']!=b['data_ptr']
    assert b['storage_offset']==128*4*192 and a['dtype']=='torch.bfloat16'
    assert a['native_format']=='NOT_QUERIED_NO_ADDITIONAL_DEVICE_API'
    assert cache_headers([object()]*17)['kind']=='NOT_AVAILABLE'


def test_actual_target_owner_and_metadata_header_availability_are_distinct():
    import torch
    from types import SimpleNamespace as N
    from tools.p7x_graph_repair32_glm_rank import target_cache_headers
    tensor=torch.zeros((2,128,1,64));metadata=N(slot_mapping=torch.zeros(4,dtype=torch.int64))
    runner=N(compilation_config=N(static_forward_context={'target.a':N(kv_cache=[tensor])}),
             model_state=N(attn_metadata={'target.a':metadata}),block_tables=N(kernel_block_sizes=[128]))
    groups=[dict(global_group_id=0,layers=['target.a','target.missing'],backend='sfa.actual')]
    result=target_cache_headers(runner,groups);a,b=result['layers']
    assert a['kv_cache']['items'][0]['shape']==[2,128,1,64]
    assert a['metadata_tensor_headers']['slot_mapping']['dtype']=='torch.int64'
    assert b['status']=='NOT_AVAILABLE_HOST_INSPECTION'
    assert result['scope']=='POST_REQUEST_HOST_HEADERS_ONLY_NOT_TARGET_KV_NUMERIC_ISOLATION_OR_COMPLETION'


def test_target_header_never_coerces_a_possible_device_scalar():
    from types import SimpleNamespace as N
    from tools.p7x_graph_repair32_glm_rank import target_cache_headers
    class NoInt:
        def __int__(self):pytest.fail('no scalar extraction/device synchronization allowed')
    runner=N(compilation_config=N(static_forward_context={'target.a':N(kv_cache=None)}),
             model_state=N(attn_metadata={}),block_tables=N(kernel_block_sizes=[NoInt()]))
    result=target_cache_headers(runner,[dict(global_group_id=0,layers=['target.a'],backend='sfa.actual')])
    assert result['layers'][0]['status']=='NOT_AVAILABLE_HOST_INSPECTION'
