# SPDX-License-Identifier: Apache-2.0
"""The joint GLM arm preserves Window and requires effective features."""

import copy
import json

import pytest

from tests.ut.spec_decode.test_graph_repair50_glm_required_baseline import (
    feature_rows,
)
from tools import p7x_graph_repair51_glm_joint_features as tool


def test_joint_argv_keeps_window_and_enables_required_service_features():
    argv = tool.joint_serve_argv(
        "/python", 18153, "joint", "G_ON", worker_provenance=True
    )
    assert argv[:4] == ["/python", "-m", "vllm.entrypoints.cli.main", "serve"]
    assert "--async-scheduling" in argv and "--no-async-scheduling" not in argv
    assert "--enable-prefix-caching" in argv and "--enable-chunked-prefill" in argv
    assert json.loads(argv[argv.index("--speculative-config") + 1])["enforce_eager"] is False
    additional = json.loads(argv[argv.index("--additional-config") + 1])
    assert additional["draft_window_size"] == 1024
    assert additional["draft_window_graph_replicated_tp_review"] is True
    assert additional["enable_dsa_cp"] is True
    assert additional["enable_flashcomm1"] is True
    assert additional["multistream_overlap_shared_expert"] is True
    assert argv[argv.index("--tensor-parallel-size") + 1] == "16"
    assert argv[argv.index("--data-parallel-size") + 1] == "1"
    assert argv[argv.index("--worker-extension-cls") + 1] == tool.EXTENSION


@pytest.mark.parametrize("arm", ["G_OFF", "E_ON"])
def test_joint_argv_rejects_non_window_graph_arms(arm):
    with pytest.raises(ValueError, match="Window ON"):
        tool.joint_serve_argv(
            "/python", 18153, "joint", arm, worker_provenance=True
        )


def test_joint_required_feature_validation_rejects_disabled_effective_sp():
    rows = feature_rows(graph_window=True)
    assert tool.validate_required_features(
        rows, require_execution=True, require_graph_window=True
    )["status"] == (
        "ALL16_EFFECTIVE_FEATURES_AND_TARGET_DSA_CP"
    )
    damaged = copy.deepcopy(rows)
    damaged[7]["required_features"]["sequence_parallel"] = False
    with pytest.raises(ValueError, match="sequence_parallel"):
        tool.validate_required_features(
            damaged, require_execution=True, require_graph_window=True
        )


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("all2all_backend", "flashinfer_all2allv"),
        ("flashcomm_requested", False),
        ("flashcomm_effective", False),
        ("draft_graph_flashcomm", None),
    ],
)
def test_joint_required_feature_validation_rejects_false_flashcomm_evidence(
    field, value
):
    rows = feature_rows(graph_window=True)
    rows[9]["required_features"][field] = value
    with pytest.raises(ValueError):
        tool.validate_required_features(
            rows, require_execution=True, require_graph_window=True
        )
