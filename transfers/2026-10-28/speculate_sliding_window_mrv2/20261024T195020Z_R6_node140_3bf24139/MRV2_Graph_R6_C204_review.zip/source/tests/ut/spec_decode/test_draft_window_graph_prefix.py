# SPDX-License-Identifier: Apache-2.0
"""Prefix Graph uses the real P7 source and rejects capture/runtime identity drift."""
from dataclasses import replace

import pytest
import torch
import numpy as np

from tests.ut.spec_decode.test_draft_window import _attention_group, _block_tables, _p2_policy, _p2_vllm_config
from tests.ut.spec_decode.test_draft_window_graph_characterization import _runtime_context
from tests.ut.spec_decode.test_draft_window_graph_tp_review import config
from tests.ut.spec_decode.test_draft_window_graph_carrier import _fingerprint
from tests.ut.spec_decode.test_draft_window_nongraph import _capability
from vllm_ascend.worker.v2.spec_decode import draft_window_graph_characterization as graph
from vllm_ascend.worker.v2.spec_decode.draft_window import build_draft_window_runtime_state, build_draft_window_inventory
from vllm_ascend.worker.v2.spec_decode.draft_window_graph import DraftWindowGraphBindingProvider, DraftWindowGraphRoute
from vllm_ascend.worker.v2.spec_decode.draft_window_nongraph import build_prefix_resident_snapshot


@pytest.fixture(autouse=True)
def experimental_gate(monkeypatch):
    monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH','1')
    monkeypatch.setenv('VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE','0')


@pytest.mark.parametrize('method',['dspark','dflash'])
def test_source_keeps_true_prefix_identity_and_canonical_full_owner(monkeypatch,method):
    vc=_p2_vllm_config(configured_k=7,additional_config=dict(draft_window_size=128))
    vc.speculative_config.method=method;vc.speculative_config.enforce_eager=False
    vc.compilation_config.cudagraph_mode.name='FULL_DECODE_ONLY'
    context=_runtime_context(graph_mode='FULL_DECODE_ONLY',prefix_caching=True)
    monkeypatch.setattr(graph,'build_draft_window_runtime_context',lambda *a:context)
    tables=_block_tables(row_width=32)
    capability,actual=graph.build_parallel_draft_window_graph_characterization_source(
        policy=_p2_policy(method),runtime_route=method,attn_groups=[[_attention_group()]],
        block_tables=tables,causal=False,vllm_config=vc)
    assert actual is context and actual.prefix_caching is True
    assert capability.eager_topology_fingerprint.prefix_caching is True
    assert capability.eager_topology_fingerprint.graph_mode=='FULL_DECODE_ONLY'
    assert capability.full_source.references_input_block_table(0,tables.input_block_tables[0])
    tables.input_block_tables[0]=tables.input_block_tables[0].clone()
    with pytest.raises(RuntimeError,match='replaced'):capability.full_source.validate_owner_bindings()


def test_parallel_tp_prefix_admission_keeps_eagle_closed_and_admits_reviewed_service_features():
    vc=config(tp=16);context=_runtime_context(tensor_parallel_size=16,tensor_parallel_rank=15,
                                             graph_mode='FULL_DECODE_ONLY',prefix_caching=True)
    assert graph.validate_parallel_graph_characterization_context(context,vc) is True
    reviewed=replace(context,async_scheduling=True,sequence_parallel=True,
                     dsa_context_parallel=True,flashcomm=True)
    assert graph.validate_parallel_graph_characterization_context(reviewed,vc) is True
    with pytest.raises(NotImplementedError,match='async'):
        graph.validate_base_graph_characterization_context(
            _runtime_context(async_scheduling=True))
    with pytest.raises(NotImplementedError,match='prefix'):
        graph.validate_base_graph_characterization_context(_runtime_context(prefix_caching=True))
    vc=config(tp=2);vc.speculative_config.method='eagle3';vc.speculative_config.num_speculative_tokens=3
    with pytest.raises(NotImplementedError,match='prefix'):
        graph.validate_parallel_graph_characterization_context(replace(context,tensor_parallel_size=2,
            tensor_parallel_rank=1),vc)


def test_source_keeps_reviewed_service_features_in_graph_identity(monkeypatch):
    vc=_p2_vllm_config(configured_k=7,additional_config=dict(draft_window_size=128))
    vc.speculative_config.method='dspark';vc.speculative_config.enforce_eager=False
    vc.compilation_config.cudagraph_mode.name='FULL_DECODE_ONLY'
    context=_runtime_context(graph_mode='FULL_DECODE_ONLY',tensor_parallel_size=16,
        tensor_parallel_rank=7,async_scheduling=True,sequence_parallel=True,
        dsa_context_parallel=True,flashcomm=True)
    monkeypatch.setattr(graph,'build_draft_window_runtime_context',lambda *a:context)
    reviewed_config=config(tp=16)
    reviewed_config.speculative_config.num_speculative_tokens=7
    capability,actual=graph.build_parallel_draft_window_graph_characterization_source(
        policy=_p2_policy('dspark'),runtime_route='dspark',attn_groups=[[_attention_group()]],
        block_tables=_block_tables(),causal=False,vllm_config=reviewed_config)
    topology=capability.eager_topology_fingerprint
    assert actual is context and topology is not None
    assert topology.tensor_parallel_size==16 and topology.tensor_parallel_rank==7
    assert topology.graph_mode=='FULL_DECODE_ONLY'
    assert topology.async_scheduling is topology.sequence_parallel is True
    assert topology.dsa_context_parallel is topology.flashcomm is True

    fingerprint=replace(_fingerprint(method='dspark',route=DraftWindowGraphRoute.DSPARK,
        query_width=8,padded_tokens=32),tensor_parallel_size=16,tensor_parallel_rank=7,
        sequence_parallel=True,dsa_context_parallel=True,flashcomm=True,
        async_scheduling=True)
    assert fingerprint.parallel_read_semantics=='replicated'


def test_inventory_allowance_is_explicit_and_does_not_hide_other_source_failures():
    context=_runtime_context(graph_mode='NONE',prefix_caching=True)
    kwargs=dict(policy=_p2_policy('dflash'),runtime_route='dflash',attn_groups=[[_attention_group()]],
                block_tables=_block_tables(),causal=False,runtime_context=context)
    with pytest.raises(NotImplementedError,match='prefix'):
        build_draft_window_inventory(**kwargs).require_single_group_direct_prefix()
    assert build_draft_window_inventory(**kwargs,allow_parallel_prefix_graph_source=True).require_single_group_direct_prefix()
    kwargs['runtime_context']=replace(context,async_scheduling=True)
    with pytest.raises(NotImplementedError,match='Async'):
        build_draft_window_inventory(**kwargs,allow_parallel_prefix_graph_source=True).require_single_group_direct_prefix()
    kwargs['runtime_route']='eagle3'
    with pytest.raises(NotImplementedError,match='parallel Draft'):
        build_draft_window_inventory(**kwargs,allow_parallel_prefix_graph_source=True)


def test_capture_cannot_misstate_prefix_and_resident_counts_remain_fresh():
    capability,tables=_capability(prefix=True)
    capability=replace(capability,eager_topology_fingerprint=replace(capability.eager_topology_fingerprint,
                                                                    graph_mode='FULL'))
    runtime=build_draft_window_runtime_state(capability)
    provider=DraftWindowGraphBindingProvider(runtime_state=runtime)
    fingerprint=replace(_fingerprint(method='dflash',route=DraftWindowGraphRoute.DFLASH,query_width=8),
                        prefix_caching=True)
    capture=provider.register_capture_identity(fingerprint=fingerprint,execution_lane=0,consumer_ordinal=0)
    assert capture.fingerprint.prefix_caching is True
    with pytest.raises(RuntimeError,match='prefix caching identity'):
        provider.register_capture_identity(fingerprint=replace(fingerprint,prefix_caching=False),
                                            execution_lane=0,consumer_ordinal=1)
    def snapshot():
        return build_prefix_resident_snapshot(full_source=capability.full_source,global_group_id=0,
            idx_mapping_np=np.array([3,5],dtype='int32'),ordered_request_ids=('A','B'),
            num_reqs=2,num_reqs_padded=2)
    tables.num_blocks.cpu[0,3]=7;tables.num_blocks.cpu[0,5]=6
    before=snapshot();tables.num_blocks.cpu[0,3]=4;after=snapshot()
    assert before.valid_num_blocks.tolist()==[7,6] and after.valid_num_blocks.tolist()==[4,6]
    assert before.mapping_fingerprint==after.mapping_fingerprint==(3,5)
    assert not torch.equal(before.valid_num_blocks,after.valid_num_blocks)


def test_eagle_carrier_cannot_inherit_parallel_prefix_contract():
    with pytest.raises(ValueError,match='parallel Draft'):
        replace(_fingerprint(),prefix_caching=True)
