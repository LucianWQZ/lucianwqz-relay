# SPDX-License-Identifier: Apache-2.0
"""Real P3/P6 CPU ownership; no mock retirement or fabricated device completion."""

from types import SimpleNamespace
from dataclasses import replace

import pytest
import torch

from tests.ut.spec_decode.test_draft_window_graph_carrier import (
    _descriptor,
    _fingerprint,
    _materialize,
    _metadata_builder,
    _runtime_fixture,
    _target_metadata,
    _write_side_reference,
)
from vllm_ascend.attention.attention_v1 import (
    AscendAttentionBackend,
    AscendAttentionBackendImpl,
    AscendAttentionMetadataBuilder,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_eagle3_graph import Eagle3GraphStagingOwner
from vllm_ascend.worker.v2.spec_decode.draft_window_graph import (
    DraftWindowGraphCarrierState,
    DraftWindowGraphRoute,
    install_draft_window_graph_binding_provider,
)


def setup():
    runtime, _, _ = _runtime_fixture(method="eagle3", max_num_reqs=4)
    owner = SimpleNamespace(_draft_window_runtime_state=runtime)
    provider = install_draft_window_graph_binding_provider(owner)
    stream = [101]
    controller = Eagle3GraphStagingOwner(runtime, provider, static_k=3, current_stream_identity=lambda: stream[0])
    captures = []
    for step in range(3):
        route = DraftWindowGraphRoute.EAGLE3_FIRST_PASS if step == 0 else DraftWindowGraphRoute.EAGLE3_AR_STEP
        captures.append(
            provider.register_capture_identity(
                fingerprint=_fingerprint(method="eagle3", route=route, query_width=4 if step == 0 else 1),
                execution_lane=0,
                consumer_ordinal=max(step - 1, 0),
            )
        )
    return runtime, provider, controller, captures, stream, torch.tensor([1, 3], dtype=torch.int32)


def next_inputs(runtime, previous, step, mapping):
    return runtime.materialize_serialized_step(
        previous_identity=previous,
        ordered_request_ids=("A", "B"),
        idx_mapping=mapping,
        read_descriptors=(_descriptor(start=step), _descriptor(start=step)),
        device_window_exact=None,
        cpu_window_exact=torch.tensor([96 + step, 64 + step, 0, 0], dtype=torch.int32),
        cpu_window_upper=torch.tensor([128, 128, 0, 0], dtype=torch.int32),
        num_reqs_padded=4,
        step=step,
        execution_lane=0,
    )


def stage(runtime, controller, capture, inputs, *, builder=None):
    target = _target_metadata()
    write = _write_side_reference(runtime, capture)
    return controller.bind_and_release_scratch(
        capture_identity=capture,
        inputs=inputs,
        metadata_builder=builder or _metadata_builder(target, write_side=write),
        target_metadata=target,
        write_side_reference=write,
    )


def attribute_update(provider, route, count):
    # This is the real Host binding validator with a CPU backend stand-in;
    # it is not an NPU completion or physical operand observation.
    metadata = provider.consume_metadata(route=route, expected_consumer_count=count)
    binding = provider.prepare_update_binding(route=route, draft_attn_metadatas=metadata)
    return provider.validate_backend_update(
        binding,
        attn_backend=AscendAttentionBackend,
        impl_cls=AscendAttentionBackendImpl,
        builder_cls=AscendAttentionMetadataBuilder,
        draft_attn_metadatas=metadata,
        update_function_path="vllm_ascend.compilation.acl_graph.update_full_graph_params",
    )


def test_each_ar_consumer_keeps_owning_state_when_p3_scratch_is_reused():
    runtime, provider, controller, captures, stream, mapping = setup()
    controller.begin(10, ("A", "B"))
    inputs = _materialize(runtime, mapping_epoch=10, idx_mapping=mapping)
    for step in range(3):
        previous = inputs.identity
        if step:
            inputs = next_inputs(runtime, previous, step, mapping)
        transfer = stage(runtime, controller, captures[step], inputs)
        assert transfer.step == step and "NOT_GRAPH_COMPLETION" in transfer.observation
        assert provider._carriers[captures[step]].state is DraftWindowGraphCarrierState.BOUND
        assert runtime._active_inputs is None
    banks = [provider._carriers[c].read_inputs for c in captures]
    assert len({b.window_block_table.untyped_storage().data_ptr() for b in banks}) == 3
    assert [b.cpu_window_exact.tolist() for b in banks] == [[96, 64, 0, 0], [97, 65, 0, 0], [98, 66, 0, 0]]
    assert not torch.equal(banks[0].window_block_table, banks[1].window_block_table)
    attribute_update(provider, DraftWindowGraphRoute.EAGLE3_FIRST_PASS, 1)
    attribute_update(provider, DraftWindowGraphRoute.EAGLE3_AR_STEP, 2)
    assert len(controller.finish()) == 3
    with pytest.raises(ValueError, match="strictly increase"):
        controller.begin(10, ("replacement",))
    stream[0] += 1
    with pytest.raises(RuntimeError, match="cross-proposal stream change"):
        controller.begin(11, ("replacement",))
    assert controller.quarantined


def test_smaller_ar_bucket_preserves_larger_first_pass_bank_and_logical_owner():
    runtime, provider, controller, captures, _, mapping = setup()
    smaller = []
    for ordinal in (0, 1):
        fingerprint = replace(captures[ordinal+1].fingerprint,
                              padded_request_count=2, padded_token_count=2, capture_bucket=(2,2),
                              capture_descriptor="tokens=2,reqs=2,mode=FULL")
        smaller.append(provider.register_capture_identity(fingerprint=fingerprint, execution_lane=0,
                                                          consumer_ordinal=ordinal))
    controller.begin(10, ("A", "B"))
    first = _materialize(runtime, mapping_epoch=10, idx_mapping=mapping)
    stage(runtime, controller, captures[0], first)
    bank = provider._carriers[captures[0]].read_inputs
    saved = bank.window_block_table.clone(), bank.cpu_window_exact.clone()
    previous = first.identity
    for step, capture in enumerate(smaller, 1):
        inputs = runtime.materialize_serialized_step(previous_identity=previous, ordered_request_ids=("A","B"),
            idx_mapping=mapping,read_descriptors=(_descriptor(start=step),_descriptor(start=step)),
            device_window_exact=None,cpu_window_exact=torch.tensor([96+step,64+step],dtype=torch.int32),
            cpu_window_upper=torch.tensor([128,128],dtype=torch.int32),num_reqs_padded=2,step=step,execution_lane=0)
        stage(runtime,controller,capture,inputs)
        assert inputs.identity.mapping_epoch == first.identity.mapping_epoch
        assert inputs.identity.ordered_request_fingerprint == first.identity.ordered_request_fingerprint
        assert torch.equal(bank.window_block_table,saved[0]) and torch.equal(bank.cpu_window_exact,saved[1])
        assert provider._carriers[capture].read_inputs.window_block_table.data_ptr() != bank.window_block_table.data_ptr()
        previous = inputs.identity
    attribute_update(provider,DraftWindowGraphRoute.EAGLE3_FIRST_PASS,1)
    attribute_update(provider,DraftWindowGraphRoute.EAGLE3_AR_STEP,2)
    assert len(controller.finish()) == 3


@pytest.mark.parametrize("damage", ["stream", "ordinal", "metadata_builder"])
def test_failed_handoff_retains_active_scratch_and_rejects_next_scope(damage):
    runtime, provider, controller, captures, stream, mapping = setup()
    controller.begin(10, ("A", "B"))
    inputs = _materialize(runtime, mapping_epoch=10, idx_mapping=mapping)
    stage(runtime, controller, captures[0], inputs)
    inputs = next_inputs(runtime, inputs.identity, 1, mapping)
    before = inputs.window_block_table.clone()
    builder = None
    capture = captures[1]
    if damage == "stream":
        stream[0] += 1
    elif damage == "ordinal":
        capture = captures[2]
    else:

        def builder(_):
            raise RuntimeError("synthetic Python error after legal bank copies; no native fault")

    with pytest.raises(RuntimeError):
        stage(runtime, controller, capture, inputs, builder=builder)
    assert controller.quarantined and runtime.quarantined_identity == inputs.identity
    assert torch.equal(inputs.window_block_table, before)
    assert runtime._active_inputs is inputs
    with pytest.raises(RuntimeError, match="quarantined"):
        controller.begin(11, ("replacement",))
    assert provider._carriers[captures[0]].state is DraftWindowGraphCarrierState.BOUND


def test_host_staging_without_actual_update_attribution_cannot_finish():
    runtime, _, controller, captures, _, mapping = setup()
    controller.begin(10, ("A", "B"))
    inputs = _materialize(runtime, mapping_epoch=10, idx_mapping=mapping)
    for step in range(3):
        if step:
            inputs = next_inputs(runtime, inputs.identity, step, mapping)
        stage(runtime, controller, captures[step], inputs)
    with pytest.raises(RuntimeError, match="actual backend UPDATE"):
        controller.finish()
    assert controller.quarantined


def test_real_eager_first_pass_is_not_relabelled_as_a_graph_consumer():
    runtime, provider, controller, captures, _, mapping = setup()
    controller.begin(10, ("A", "B"), first_pass_is_graph=False)
    inputs = _materialize(runtime, mapping_epoch=10, idx_mapping=mapping)
    runtime.retire_generation(inputs.identity)  # Actual P3 Host retirement; no device completion claim.
    controller.adopt_eager_first_pass(inputs.identity)
    for step in (1, 2):
        inputs = next_inputs(runtime, inputs.identity, step, mapping)
        stage(runtime, controller, captures[step], inputs)
    assert provider._carriers[captures[0]].state is DraftWindowGraphCarrierState.EMPTY
    attribute_update(provider, DraftWindowGraphRoute.EAGLE3_AR_STEP, 2)
    assert [t.step for t in controller.finish()] == [1, 2]
