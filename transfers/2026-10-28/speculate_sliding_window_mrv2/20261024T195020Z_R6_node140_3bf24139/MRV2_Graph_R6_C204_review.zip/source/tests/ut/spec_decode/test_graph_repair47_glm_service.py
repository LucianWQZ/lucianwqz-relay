# SPDX-License-Identifier: Apache-2.0
"""Host counterexamples for the official GLM service arm; not NPU evidence."""
import copy
import json
from types import SimpleNamespace

import pytest

from tools import p7x_graph_repair33_service as service
from tools import p7x_graph_repair47_glm_service as glm
from tests.ut.spec_decode.test_graph_repair32_glm_rank import glm_evidence
from tests.ut.spec_decode.test_graph_repair39_service_identity import identity


@pytest.mark.parametrize('arm', ['G_OFF', 'G_ON'])
def test_official_glm_cli_uses_actual_tp16_k8_target_q9_and_frozen_gate(arm):
    argv = glm.glm_serve_argv('/python', 18147, 'glm-service', arm, worker_provenance=True)
    assert argv[:5] == ['/python', '-m', 'vllm.entrypoints.cli.main', 'serve', str(glm.TARGET)]
    assert argv[argv.index('--tensor-parallel-size')+1] == '16'
    spec = json.loads(argv[argv.index('--speculative-config')+1])
    assert spec['method'] == 'dspark' and spec['num_speculative_tokens'] == 8
    assert spec['enforce_eager'] is False and spec['enable_adaptive_verification'] is False
    capture = json.loads(argv[argv.index('--compilation-config')+1])
    assert capture == dict(cudagraph_capture_sizes=[8, 16, 32, 36], cudagraph_mode='FULL_DECODE_ONLY')
    additional = json.loads(argv[argv.index('--additional-config')+1])
    assert additional == (dict(draft_window_size=1024, draft_window_graph_replicated_tp_review=True)
                          if arm == 'G_ON' else {})
    assert argv[argv.index('--worker-extension-cls')+1] == glm.EXTENSION
    assert '--no-async-scheduling' in argv and '--no-enable-prefix-caching' in argv
    assert '--enable-expert-parallel' in argv and '--quantization' in argv
    assert '--enforce-eager' not in argv


def test_service_eager_control_is_explicit_and_keeps_target_graph():
    argv = glm.glm_serve_argv('/python', 18147, 'glm-service', 'E_ON', worker_provenance=True)
    assert json.loads(argv[argv.index('--speculative-config')+1])['enforce_eager'] is True
    assert json.loads(argv[argv.index('--additional-config')+1]) == dict(draft_window_size=1024)
    assert '--enforce-eager' not in argv and argv[argv.index('--tensor-parallel-size')+1] == '16'
    with pytest.raises(ValueError, match='named GLM'):
        glm.glm_serve_argv('/python', 18147, 'glm-service', 'unknown', worker_provenance=True)
    with pytest.raises(ValueError, match='provenance'):
        glm.glm_serve_argv('/python', 18147, 'glm-service', 'G_ON')


def test_generic_service_passes_complete_tp16_to_existing_admission(monkeypatch):
    seen = []
    class StopBeforeStartingAProcess(Exception):
        pass
    def admit(path, **kwargs):
        seen.append(kwargs['tp'])
        raise StopBeforeStartingAProcess
    monkeypatch.setattr(service, 'validate_admission', admit)
    args = SimpleNamespace(admission='unused', expected_sha='a'*40)
    with pytest.raises(StopBeforeStartingAProcess):
        service.run_service(args, tp=16, ready_timeout_seconds=1800)
    assert seen == [16]
    for invalid in (True, 8, '16'):
        with pytest.raises(ValueError):
            service.run_service(args, tp=invalid)
    assert seen == [16]


def rows_from_fixture(identity):
    source, pin, header, _ = identity
    campaign, _, _, _ = glm_evidence(True)
    rows = []
    for snapshot in campaign['ranks']:
        row = copy.deepcopy(header)
        row.update(pid=snapshot['pid'], process_start_ticks=snapshot['process_start_ticks'],
                   rank_snapshot=copy.deepcopy(snapshot))
        rows.append(row)
    return source, pin, rows


def test_all16_actual_worker_identities_are_required_even_when_http_succeeded(identity):
    source, pin, rows = rows_from_fixture(identity)
    result = glm.validate_service_workers(rows, nonce='a'*32, source=source, vllm_source=pin, arm='G_ON')
    assert len(result['workers']) == 16
    assert [row['rank'] for row in result['workers']] == list(range(16))
    assert all(row['device_execution_occurrence'] == 'NOT_PROVEN' for row in result['workers'])


@pytest.mark.parametrize('damage', ['missing', 'duplicate_rank', 'duplicate_pid', 'pid_join',
                                  'source', 'observer', 'wrong_model', 'wrong_query', 'target_bucket'])
def test_wrong_rank_source_geometry_or_capture_cannot_be_hidden_by_http(identity, damage):
    source, pin, rows = rows_from_fixture(identity)
    if damage == 'missing':
        rows.pop()
    elif damage == 'duplicate_rank':
        rows[-1]['rank_snapshot']['rank'] = 0
    elif damage == 'duplicate_pid':
        rows[-1]['rank_snapshot']['pid'] = rows[0]['rank_snapshot']['pid']
    elif damage == 'pid_join':
        rows[-1]['pid'] += 1
    elif damage == 'source':
        rows[-1]['modules'][0]['sha256'] = '0'*64
    elif damage == 'observer':
        rows[-1]['heavy_observer_enabled'] = True
    elif damage == 'wrong_model':
        rows[-1]['rank_snapshot']['glm_profile']['draft_model'] = '/another-draft'
    elif damage == 'wrong_query':
        rows[-1]['rank_snapshot']['glm_profile']['draft_query'] = 7
    else:
        rows[-1]['rank_snapshot']['target_graph_inventory'].pop()
    with pytest.raises(ValueError):
        glm.validate_service_workers(rows, nonce='a'*32, source=source, vllm_source=pin, arm='G_ON')
