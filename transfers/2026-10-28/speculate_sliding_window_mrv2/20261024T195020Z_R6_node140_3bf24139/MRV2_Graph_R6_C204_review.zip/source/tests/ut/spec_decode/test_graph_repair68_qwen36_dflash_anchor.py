# SPDX-License-Identifier: Apache-2.0
"""The designated hybrid Target/Full8 Draft profile cannot borrow GLM evidence."""
import hashlib
import json
import struct
from types import SimpleNamespace as N

import pytest

from tools.p7x_graph_repair21_rank import RankWorkerExtension
from tools.p7x_graph_repair28_rank_anchor_check import validate_payload
from tools.p7x_graph_repair68_qwen36_dflash_anchor import (
    AUX_LAYERS, DRAFT, PROFILE, SPECULATOR, TARGET, Qwen36DFlashWorker,
    build_kwargs, validate_model_configs, validate_worker, weight_headers,
)
from tests.ut.spec_decode.test_graph_repair28_rank_anchor_check import evidence as base_evidence


def configs():
    target = dict(architectures=["Qwen3_5MoeForConditionalGeneration"], model_type="qwen3_5_moe",
                  text_config=dict(num_hidden_layers=40, hidden_size=2048, vocab_size=248320,
                                   max_position_embeddings=262144,
                                   layer_types=["linear_attention"]*3+["full_attention"]))
    target["text_config"]["layer_types"] *= 10
    draft = dict(architectures=["DFlashDraftModel"], model_type="qwen3", num_hidden_layers=8,
                 hidden_size=2048, num_target_layers=40, vocab_size=248320, num_attention_heads=32,
                 num_key_value_heads=4, head_dim=128, dtype="bfloat16", layer_types=["full_attention"]*8,
                 sliding_window=None, use_sliding_window=False, max_position_embeddings=262144,
                 block_size=16, dflash_config=dict(target_layer_ids=list(AUX_LAYERS), mask_token_id=248070))
    return target, draft


def evidence(review):
    campaign, expected, execution, receipt = base_evidence(4, review)
    kwargs = build_kwargs(4, window_on_review=review)
    campaign.update(kwargs=kwargs, config_sha256=hashlib.sha256(json.dumps(kwargs, sort_keys=True).encode()).hexdigest())
    for w in campaign["ranks"]:
        layers = [f"draft{i}" for i in range(8)]
        w.update(speculator_class=SPECULATOR, draft_layers=layers,
                 draft_backend={n:"vllm_ascend.attention.attention_v1.AscendAttentionBackend" for n in layers},
                 draft_kv_geometry={n+"/"+str(i):dict(shape=[64,128,1,128], dtype="torch.bfloat16")
                                    for n in layers for i in (0,1)})
        w["qwen36_profile"] = dict(profile=PROFILE, target_model=str(TARGET), draft_model=str(DRAFT),
            method="dflash", k=7, query=8, anchor=False, noncausal=True, layer_types=["full_attention"]*8,
            target_layer_ids=list(AUX_LAYERS), mask_token_id=248070, fc_shape=[2048,10240],
            model_layer_causal=[False]*8, draft_groups=[dict(global_group_id=2,layers=layers)],
            group_causal=[dict(global_group_id=2,causal=False)],
            target_groups=[dict(backend="vllm_ascend.attention.attention_v1.AscendAttentionBackend",
                                layers=[f"targetfull{i}" for i in range(10)]),
                           dict(backend="vllm_ascend.ops.gdn_attn_builder.AscendGDNAttentionBackend",
                                layers=[f"targetlinear{i}" for i in range(30)])])
        for key in ("target_graph_inventory","draft_graph_inventory"):
            w[key] = [dict(mode="FULL",requests=n,tokens=8*n) for n in (1,2,4)]
        if review:
            for row in w["window_generations"]+w["window_graph_bindings"]:
                row["global_group_id"] = 2
    return campaign, expected, execution, receipt


def test_k_is_explicit_and_weight_block_size_is_not_inferred_as_k():
    validate_model_configs(*configs())
    off, on = build_kwargs(4), build_kwargs(4, window_on_review=True)
    assert off["speculative_config"]["num_speculative_tokens"] == 7
    assert off["compilation_config"]["cudagraph_capture_sizes"] == [8,16,32]
    assert off["additional_config"] == {} and on["additional_config"]["draft_window_size"] == 1024
    assert off["data_parallel_size"] == 1 and not off["speculative_config"]["enforce_eager"]
    for tp in (True,1,2,8,16):
        with pytest.raises(ValueError): build_kwargs(tp)


@pytest.mark.parametrize("damage", ["target", "swa", "layers", "aux", "vocab", "dtype", "causal"])
def test_raw_pair_contradictions_are_rejected(damage):
    target, draft = configs()
    if damage == "target": target["text_config"]["layer_types"][0] = "full_attention"
    elif damage == "swa": draft["layer_types"][0] = "sliding_attention"
    elif damage == "layers": draft["num_hidden_layers"] = 6
    elif damage == "aux": draft["dflash_config"]["target_layer_ids"][-1] = 38
    elif damage == "vocab": draft["vocab_size"] = 154880
    elif damage == "dtype": draft["dtype"] = "float8"
    else: draft["dflash_config"]["causal"] = True
    with pytest.raises(ValueError): validate_model_configs(target, draft)


@pytest.mark.parametrize("review", [False,True])
def test_complete_named_rank_payload_passes_its_own_contract(review):
    c,p,e,r = evidence(review)
    assert validate_payload(c,p,e,r,"/source", kwargs_factory=build_kwargs, worker_validator=validate_worker)["ranks"] == 4


@pytest.mark.parametrize("damage", ["rank", "method", "query", "group", "target_missing", "target_alias",
                                   "backend", "causal", "untyped_causal", "untyped_group", "untyped_gid",
                                   "kv", "bucket", "model", "aux"])
def test_missing_or_inconsistent_real_rank_contract_fails(damage):
    c,p,e,r = evidence(True)
    w = c["ranks"][-1]; q = w["qwen36_profile"]
    if damage == "rank": c["ranks"].pop()
    elif damage == "method": q["method"] = "dspark"
    elif damage == "query": q["query"] = 16
    elif damage == "group": w["window_graph_bindings"][0]["global_group_id"] = 0
    elif damage == "target_missing": q["target_groups"][1]["layers"].pop()
    elif damage == "target_alias": q["target_groups"][1]["layers"][0] = q["target_groups"][0]["layers"][0]
    elif damage == "backend": q["target_groups"][1]["backend"] = "unknown"
    elif damage == "causal": q["model_layer_causal"][0] = True
    elif damage == "untyped_causal": q["model_layer_causal"][0] = 0
    elif damage == "untyped_group": q["group_causal"][0]["causal"] = 0
    elif damage == "untyped_gid": q["group_causal"][0]["global_group_id"] = 2.0
    elif damage == "kv": w["draft_kv_geometry"].pop(next(iter(w["draft_kv_geometry"])))
    elif damage == "bucket": w["target_graph_inventory"][-1]["tokens"] = 64
    elif damage == "model": q["draft_model"] = str(DRAFT)+"-SWA"
    else: q["target_layer_ids"][-1] = 39
    with pytest.raises(ValueError):
        validate_payload(c,p,e,r,"/source",kwargs_factory=build_kwargs,worker_validator=validate_worker)


def test_snapshot_reads_actual_owner_config_and_not_a_declared_test_profile(monkeypatch):
    monkeypatch.setattr(RankWorkerExtension,"mrv2_rank_snapshot",lambda self: dict(actual="base"))
    backend = type("Backend",(),{})
    spec = N(draft_attn_layer_names={"draft"}, _group_causal={2:False},
             draft_model_config=N(model=str(DRAFT),hf_config=N(layer_types=["full_attention"]*8,
                                   dflash_config=dict(target_layer_ids=list(AUX_LAYERS)))),
             speculative_config=N(method="dflash"),num_speculative_steps=7,num_query_per_req=8,
             sample_from_anchor=False,requires_non_causal=True,parallel_drafting_token_id=248070,
             model=N(model=N(fc=N(weight=N(shape=(2048,10240)))),get_draft_attn_causal=lambda:[False]*8))
    worker = Qwen36DFlashWorker()
    worker.vllm_config = N(model_config=N(model=str(TARGET)))
    worker.model_runner = N(speculator=spec,attn_groups=[[N(layer_names=["draft"],kv_cache_group_id=2,backend=backend)]])
    value = worker.mrv2_rank_snapshot()
    assert value["actual"] == "base" and value["qwen36_profile"]["query"] == 8
    assert value["qwen36_profile"]["fc_shape"] == [2048,10240]
    assert value["qwen36_profile"]["draft_groups"][0]["global_group_id"] == 2


@pytest.mark.parametrize("damage", [None,"dtype","fc","truncated"])
def test_bounded_header_distinguishes_aux_geometry(tmp_path,damage):
    value={"fc.weight":dict(dtype="BF16",shape=[2048,10240]),"hidden_norm.weight":dict(dtype="BF16",shape=[2048])}
    if damage == "dtype": value["fc.weight"]["dtype"] = "F8_E4M3"
    if damage == "fc": value["fc.weight"]["shape"][-1] = 16384
    raw=json.dumps(value).encode();p=tmp_path/"header.safetensors"
    p.write_bytes(struct.pack("<Q",len(raw))+(raw[:-1] if damage == "truncated" else raw))
    if damage:
        with pytest.raises(ValueError): weight_headers(p)
    else: assert weight_headers(p)["sha256"] == hashlib.sha256(raw).hexdigest()
