# SPDX-License-Identifier: Apache-2.0
"""Named SWA model/bucket ownership counterexamples; no NPU claims."""
import copy
import json
import subprocess
import sys

import pytest

from tests.ut.spec_decode.test_graph_repair68_qwen36_dflash_anchor import configs,evidence
from tools import p7x_graph_repair70_qwen36_swa_anchor as swa


def model_configs():
    target,draft=configs()
    draft.update(num_hidden_layers=6,num_key_value_heads=8,layer_types=list(swa.LAYERS),
                 sliding_window=4096,use_sliding_window=True,
                 dflash_config=dict(target_layer_ids=list(swa.AUX),mask_token_id=248077))
    return target,draft


def worker():
    row=copy.deepcopy(evidence(False)[0]['ranks'][0]);layers=[f'draft{i}' for i in range(6)]
    row.update(draft_layers=layers,window_provider_installed=False,heavy_observer_enabled=False,
               draft_backend={n:'vllm_ascend.attention.attention_v1.AscendAttentionBackend' for n in layers},
               draft_kv_geometry={n+'/'+str(i):dict(shape=[64,128,2,128],dtype='torch.bfloat16')
                                  for n in layers for i in (0,1)})
    row['qwen36_profile'].update(profile=swa.PROFILE,draft_model=str(swa.DRAFT),layer_types=list(swa.LAYERS),
        target_layer_ids=list(swa.AUX),mask_token_id=248077,fc_shape=[2048,16384],
        model_layer_causal=[True]*5+[False],model_layer_native_windows=[4096]*5+[None],
        actual_draft_layer_names=layers,
        actual_draft_kernel_blocks=[dict(global_group_id=2,block_size=128),dict(global_group_id=3,block_size=128)],
        draft_groups=[dict(global_group_id=2,layers=layers[:5]),dict(global_group_id=3,layers=layers[5:])],
        group_causal=[dict(global_group_id=2,causal=True),dict(global_group_id=3,causal=False)])
    return row


@pytest.mark.parametrize('damage',[None,'full8','kv_heads','causal','aux','mask','native_window','target_layers'])
def test_designated_config_is_not_the_existing_full8_checkpoint(damage):
    target,draft=model_configs()
    if damage=='full8':draft['num_hidden_layers']=8
    elif damage=='kv_heads':draft['num_key_value_heads']=4
    elif damage=='causal':draft['dflash_config']['causal']=False
    elif damage=='aux':draft['dflash_config']['target_layer_ids'].pop()
    elif damage=='mask':draft['dflash_config']['mask_token_id']=248070
    elif damage=='native_window':draft['sliding_window']=32768
    elif damage=='target_layers':target['text_config']['layer_types']=['full_attention']*40
    if damage is None:swa.validate_configs(target,draft)
    else:
        with pytest.raises(ValueError):swa.validate_configs(target,draft)


@pytest.mark.parametrize('damage',[None,'window','eager','head','layer','causal','native_window','merged',
                                   'group_causal','target_alias','bucket','aux','swapped_member','kernel_block',
                                   'untyped_causal','missing_layer_order'])
def test_real_worker_contract_rejects_wrong_causality_group_or_geometry(damage):
    row=worker();p=row['qwen36_profile']
    if damage=='window':row['window_size']=1024
    elif damage=='eager':row['draft_graph_inventory']=[]
    elif damage=='head':next(iter(row['draft_kv_geometry'].values()))['shape'][2]=1
    elif damage=='layer':row['draft_layers'].pop()
    elif damage=='causal':p['model_layer_causal'][0]=False
    elif damage=='native_window':p['model_layer_native_windows'][0]=None
    elif damage=='merged':p['draft_groups']=[dict(global_group_id=2,layers=row['draft_layers'])]
    elif damage=='group_causal':p['group_causal'][0]['causal']=False
    elif damage=='target_alias':p['target_groups'][0]['layers'][0]=row['draft_layers'][0]
    elif damage=='bucket':row['target_graph_inventory'].pop()
    elif damage=='aux':p['fc_shape'][1]=10240
    elif damage=='swapped_member':
        p['draft_groups'][0]['layers'][0],p['draft_groups'][1]['layers'][0]=p['draft_groups'][1]['layers'][0],p['draft_groups'][0]['layers'][0]
    elif damage=='kernel_block':p['actual_draft_kernel_blocks'][0]['block_size']=64
    elif damage=='untyped_causal':p['model_layer_causal'][0]=1
    elif damage=='missing_layer_order':p['actual_draft_layer_names']=[]
    if damage is None:swa.validate_worker(row,4)
    else:
        with pytest.raises(ValueError):swa.validate_worker(row,4)


def test_baseline_is_explicit_off_and_k_is_not_weight_block_size():
    kwargs=swa.build_kwargs(4)
    assert kwargs['speculative_config']['num_speculative_tokens']==7
    assert kwargs['speculative_config']['model']==str(swa.DRAFT)
    assert kwargs['additional_config']=={} and kwargs['data_parallel_size']==1
    assert not kwargs['speculative_config']['enforce_eager']
    assert kwargs['compilation_config']['cudagraph_capture_sizes']==[8,16,32]
    with pytest.raises(ValueError):swa.build_kwargs(4,window_on_review=True)
    with pytest.raises(ValueError):swa.build_kwargs(8)


@pytest.mark.parametrize('damage',[None,'missing','duplicate_member','duplicate_gid','mixed_causal',
                                  'wrong_causal','duplicate_causal','wrong_block','duplicate_block'])
def test_actual_hybrid_cache_singleton_partition_preserves_every_layer_owner(damage):
    row=worker();p=row['qwen36_profile'];names=p['actual_draft_layer_names']
    p['draft_groups']=[dict(global_group_id=10+i,layers=[name]) for i,name in enumerate(names)]
    p['group_causal']=[dict(global_group_id=10+i,causal=i<5) for i in range(6)]
    p['actual_draft_kernel_blocks']=[dict(global_group_id=10+i,block_size=128) for i in range(6)]
    if damage=='missing':p['draft_groups'].pop()
    elif damage=='duplicate_member':p['draft_groups'][-1]['layers']=[names[0]]
    elif damage=='duplicate_gid':p['draft_groups'][-1]['global_group_id']=10
    elif damage=='mixed_causal':
        p['draft_groups'][0]['layers'].append(names[-1]);p['draft_groups'].pop()
    elif damage=='wrong_causal':p['group_causal'][0]['causal']=False
    elif damage=='duplicate_causal':p['group_causal'].append(copy.deepcopy(p['group_causal'][0]))
    elif damage=='wrong_block':p['actual_draft_kernel_blocks'][0]['block_size']=1024
    elif damage=='duplicate_block':p['actual_draft_kernel_blocks'].append(copy.deepcopy(p['actual_draft_kernel_blocks'][0]))
    if damage is None:swa.validate_worker(row,4)
    else:
        with pytest.raises(ValueError):swa.validate_worker(row,4)


def test_absolute_cli_bootstraps_without_shadowing_python_bisect(tmp_path):
    result=subprocess.run([sys.executable,swa.__file__,'--help'],cwd=tmp_path,
                          capture_output=True,text=True,timeout=30)
    assert result.returncode==0,result.stderr
    assert '--admission' in result.stdout and '--planned' in result.stdout


def test_post_capture_preflight_saves_all_workers_before_rejecting_wrong_group(tmp_path):
    rows=[]
    for rank in range(4):
        row=worker();row.update(rank=rank,pid=100+rank);rows.append(row)
    rows[-1]['qwen36_profile']['group_causal'][0]['causal']=False
    class Engine:
        def collective_rpc(self,name,*,timeout):
            assert name=='mrv2_rank_snapshot' and timeout==90
            return rows
    record=dict(status='STARTING')
    with pytest.raises(ValueError,match='group causality'):
        swa.preflight_workers(Engine(),record,tmp_path)
    saved=json.loads((tmp_path/'campaign.json').read_text())
    assert saved['swa_post_capture_preflight']==rows and len(rows)==4
