# SPDX-License-Identifier: Apache-2.0
"""Host-only LIFE fixtures and no-device-actions after an unknown submission."""
import copy
import json
from types import SimpleNamespace as NS

import pytest
import torch

from tools.p7x_graph_repair22_eagle_life import EagleLifecycle, check_rows


def complete_fixture():
    records = []
    for group, active, padded in (("short-one", 1, 1), ("long-three", 3, 4), ("return-short-four", 4, 4)):
        for _ in range(7):
            epoch = len(records) // 3 + 1
            for step in range(3):
                generation = len(records) + 10
                query = 4 if step == 0 else 1
                exact = [32] * active + [0] * (padded - active)
                records.append(
                    dict(group=group,
                         runtime=dict(step=step,
                                      mapping_epoch=epoch,
                                      ordered_request_fingerprint=[group + str(i) for i in range(active)],
                                      generation_id=generation),
                         capture=dict(fingerprint=dict(method="eagle3",
                                                       query_width=query,
                                                       capture_descriptor=f"{'first' if step==0 else 'ar'}:{padded}"),
                                      consumer_ordinal=0 if step == 0 else step - 1,
                                      backing_identity=dict(window_block_table=dict(data_ptr=1000 + padded * 100 +
                                                                                    step * 10))),
                         state="UPDATED",
                         completion="UPDATE_STREAM_AND_CURRENT_STREAM_SYNCHRONIZED",
                         completion_ns=200,
                         retire=dict(identity=dict(generation_id=generation), ns=100, source_cpu_exact=exact),
                         layers={
                             "draft":
                             dict(device_exact=exact,
                                  cpu_exact=exact,
                                  metadata_exact=exact,
                                  device_table=[[1]],
                                  metadata_table=[[1]],
                                  slot_dtype="torch.int32",
                                  causal=True,
                                  exact_dtype="torch.int32",
                                  cpu_exact_dtype="torch.int32",
                                  metadata_exact_dtype="torch.int32",
                                  table_dtype="torch.int32")
                         }))
    return dict(schema="r6-eagle-life-v1",
                complete=True,
                records=records,
                completed_proposals=21,
                layers=["draft"],
                slot_dtype="torch.int32",
                pending_epoch=None,
                quarantined=False,
                normal_overlap="NOT_PROVEN",
                extra_synchronization=True)


def test_complete_life_and_damaged_generation_source_completion_or_layer():
    document = complete_fixture()
    assert check_rows(document)["consumers"] == 63
    changes = [
        lambda d: d["records"].pop(), lambda d: d["records"][1]["runtime"].update(step=2),
        lambda d: d["records"][1]["runtime"].update(mapping_epoch=999),
        lambda d: d["records"][0].update(completion="HOST_RETURN_ONLY"),
        lambda d: d["records"][0]["retire"].update(source_cpu_exact=[999]), lambda d: d["records"][0]["layers"].clear(),
        lambda d: d["records"][0]["layers"]["draft"].update(exact_dtype="torch.int64"),
        lambda d: d.update(normal_overlap="PASS"), lambda d: d.update(quarantined=True)
    ]
    for change in changes:
        damaged = copy.deepcopy(document)
        change(damaged)
        with pytest.raises(ValueError):
            check_rows(damaged)


def test_manager_failure_never_synchronizes_or_reads_device_and_isolates(tmp_path, monkeypatch):

    class Runtime:

        def retire_generation(self, identity):
            pass

    class Controller:
        runtime = Runtime()
        quarantined = False

        def quarantine(self, reason):
            self.quarantined = True

    class Manager:

        def run_fullgraph(self, desc):
            raise RuntimeError("injected unknown native boundary")

    owner = NS(prefill_cudagraph_manager=Manager(),
               decode_cudagraph_manager=Manager(),
               _eagle3_window_proposal_context=NS(mapping_epoch=1),
               _eagle3_graph_session=NS(controller=Controller()),
               draft_attn_layer_names={"draft"},
               block_tables=NS(slot_mappings=torch.empty(1, dtype=torch.int32)))

    def forbidden():
        raise AssertionError("post-fault device operation forbidden")

    monkeypatch.setattr(torch.npu, "current_stream", forbidden)
    path = tmp_path / 'life.json'
    with pytest.raises(RuntimeError, match="unknown native"):
        with EagleLifecycle(owner, path, dict(source="HOST_FIXTURE_NOT_DEVICE")) as probe:
            probe.group = "short-one"
            owner.prefill_cudagraph_manager.run_fullgraph(NS(cg_mode=NS(name="FULL")))
    result = json.loads(path.read_text())
    assert result["uncertain"] and result["quarantined"] and not result["complete"]
    assert owner._draft_window_graph_submission_uncertain
