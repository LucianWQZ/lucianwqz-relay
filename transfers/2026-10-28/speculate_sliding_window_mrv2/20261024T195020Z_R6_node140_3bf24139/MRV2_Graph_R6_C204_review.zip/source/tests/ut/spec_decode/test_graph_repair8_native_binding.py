# SPDX-License-Identifier: Apache-2.0
"""CANN9.1 observed folded-layout contract; synthetic addresses, no device.

The relocation positions/list header are taken from the C15 native JSON format.
These tests do not assert that synthetic layer labels were observed on an NPU.
"""
import json
from types import SimpleNamespace

import pytest

from tools import p7x_graph_repair8_task_dump as tool


def native(requests=1, key=0x30000, value=0x40000):
    words = [0] * (368 + 2 * requests)
    data = {0: 37, 1: 353, 2: 359, 3: 365, 4: 365 + requests}
    addr = {0: 35, 1: 2, 2: 3, 3: 6, 4: 7}
    labels = {}
    for i in data:
        words[addr[i]] = 0x900000 + data[i] * 8
        labels[addr[i]], labels[data[i]] = f"(placeHolderAddr{i})", f"(placeHolderData{i})"
    words[1], words[15], words[32] = 0x10000, 0x20000, 0x50000
    words[353:359] = [40, 0x100000003, 8, 128, 1024, key]
    words[359:365] = [40, 0x100000003, 8, 128, 1024, value]
    words[365:365 + requests] = [7 * (i + 1) for i in range(requests)]
    words[365 + requests:365 + 2 * requests] = [28] * requests
    return dict(name=tool.FIA_KERNEL, pid="123 aclGraph", args={
        "Kernel Args": " ".join(labels.get(i, "") + f"0x{v:016x}" for i, v in enumerate(words)),
        "Task Type": "KERNEL_MIX_AIC", "Kernel Args Size": len(words) * 8, "Model Id": 45, "Stream Id": 9, "Task Id": 16})


@pytest.mark.parametrize("requests", [1, 2, 4])
def test_observed_relocation_and_list_layout(requests):
    d = tool.decode_native_fia(native(requests), requests)
    assert d["argument_block_base"] == 0x900000
    assert d["key"] == dict(data_ptr=0x30000, shape=[8, 128, 1024])
    assert d["value"]["data_ptr"] == 0x40000
    assert d["table_ptr"] == 0x20000
    assert d["query_lengths"] == [7 * (i + 1) for i in range(requests)]
    assert d["kv_lengths"] == [28] * requests


@pytest.mark.parametrize("damage", ["size", "extra_bytes", "duplicate_label", "relocation", "kernel", "list_header"])
def test_native_layout_damage_rejected(damage):
    e = native()
    if damage == "size":
        e["args"]["Kernel Args Size"] += 8
    elif damage == "extra_bytes":
        e["args"]["Kernel Args"] += " corrupted"
    elif damage == "duplicate_label":
        e["args"]["Kernel Args"] += " (placeHolderData0)0x0000000000000000"
    elif damage == "relocation":
        e["args"]["Kernel Args"] = e["args"]["Kernel Args"].replace("0x0000000000900128", "0x0000000000900130")
    elif damage == "kernel":
        e["name"] = "OtherKernel"
    else:
        e["args"]["Kernel Args"] = e["args"]["Kernel Args"].replace("(placeHolderData1)0x0000000000000028", "(placeHolderData1)0x0000000000000020")
    with pytest.raises(ValueError):
        tool.decode_native_fia(e, 1)


class MetadataOnlyTensor:
    def __init__(self, pointer, shape, dtype="torch.bfloat16"):
        self.pointer, self.shape, self.dtype, self.device = pointer, shape, dtype, "npu:0"

    def data_ptr(self):
        return self.pointer

    def __getitem__(self, key):
        raise AssertionError("must not index device tensor")

    def __len__(self):
        raise AssertionError("must not treat device tensor as a sequence")

    def __iter__(self):
        raise AssertionError("must not iterate device tensor")

    def to(self, *args, **kwargs):
        raise AssertionError("must not copy/synchronize device tensor")


def binding_fixture():
    handle, event = object(), object()
    param = [None] * 22
    param[0] = MetadataOnlyTensor(0x10000, [7, 32, 128])
    # Match full_graph_fia + pinned weak_ref_tensors: retain single Tensors.
    param[1] = MetadataOnlyTensor(0x30000, [8, 128, 1024])
    param[2] = MetadataOnlyTensor(0x40000, [8, 128, 1024])
    param[3] = MetadataOnlyTensor(0x20000, [1, 32], "torch.int32")
    param[6], param[7] = [1151], [7]
    param[11] = MetadataOnlyTensor(0x50000, [7, 32, 128])
    # Generic DSpark capture tuple has no layer-aware name; use explicit IDs.
    params = SimpleNamespace(attn_params={7: [tuple(param)]}, handles={7: [handle]}, events={7: [event]})
    observed = dict(stage="capture_operator", num_tokens=7, handle_identity=id(handle),
                    event_identity=id(event), layer_name="layer0", actual_table_address=0x20000,
                    length_values=[1151])
    return SimpleNamespace(draft_attn_layer_names={"layer0"}), params, observed


@pytest.mark.parametrize("container", [None, list, tuple])
def test_host_capture_uses_real_handle_event_not_list_order(container):
    spec, params, observed = binding_fixture()
    if container is not None:
        param = list(params.attn_params[7][0])
        param[1], param[2] = container([param[1]]), container([param[2]])
        params.attn_params[7] = [tuple(param)]
    result = tool.capture_fia_bindings(spec, SimpleNamespace(num_tokens=7), params, [observed])
    assert result[0]["layer_name"] == "layer0"
    assert result[0]["key"][0]["data_ptr"] == 0x30000
    assert result[0]["key_parameter_form"] == ("SINGLE_TENSOR" if container is None else "TENSOR_SEQUENCE")
    bad = dict(observed, event_identity=0)
    with pytest.raises(ValueError):
        tool.capture_fia_bindings(spec, SimpleNamespace(num_tokens=7), params, [bad])


@pytest.mark.parametrize("count", [0, 2])
def test_host_capture_rejects_other_tensor_list_sizes(count):
    spec, params, observed = binding_fixture()
    param = list(params.attn_params[7][0])
    param[1] = [param[1]] * count
    params.attn_params[7] = [tuple(param)]
    with pytest.raises(ValueError, match="only one K/V tensor"):
        tool.capture_fia_bindings(spec, SimpleNamespace(num_tokens=7), params, [observed])


@pytest.mark.parametrize("damage", [None, "kv_pointer", "last_generation", "native_length", "capture_handle", "process", "same_as_capture", "repeated_generation"])
def test_join_requires_pointer_layer_and_distinct_generation(tmp_path, damage):
    spec, params, capture = binding_fixture()
    binding = tool.capture_fia_bindings(spec, SimpleNamespace(num_tokens=7), params, [capture])[0]
    binding["host_observed_ns"] = 2
    update = dict(capture, stage="update_operator", generation_id=6, mapping_epoch=6, length_values=[28])
    life = dict(draft_layer_names=["layer0"], recorder=dict(operand_events=[capture, update]))
    event = native()
    if damage == "kv_pointer":
        event = native(key=0x30008)
    elif damage == "last_generation":
        update["generation_id"] = 5
    elif damage == "native_length":
        event["args"]["Kernel Args"] = event["args"]["Kernel Args"].replace("(placeHolderData4)0x000000000000001c", "(placeHolderData4)0x000000000000001b")
    elif damage == "capture_handle":
        binding["handle_identity"] = 0
    elif damage == "process":
        event["pid"] = "999 aclGraph"
    elif damage == "same_as_capture":
        capture["length_values"] = [28]
        binding["retained_capture_kv_lengths"] = [28]
    elif damage == "repeated_generation":
        life["recorder"]["operand_events"].append(dict(update, generation_id=5, mapping_epoch=5))
    path = tmp_path / "native.json"
    path.write_text(json.dumps([event]))
    doc = dict(schema="repair8-native-graph-json-v2", host_binding_scope="AFTER_SUCCESSFUL_LIFE_DRAINS_METADATA_ONLY",
               identity=dict(process_id=123), records=[dict(descriptor=[1, 7], captured_fia_bindings=[binding],
               path=path.name, last_life_generation=6, last_life_epoch=6, start_ns=1, end_ns=3)])
    if damage in (None, "same_as_capture", "repeated_generation"):
        result = tool.native_parameter_bindings(doc, life, tmp_path / "task-dump-index.json")
        assert result["tasks"][0]["parameter_values_match_host_generation"] == 6
        if damage is None:
            assert result["tasks"][0]["capture_values_distinguishable"]
            assert result["status"] == "DIAGNOSTIC_POST_DRAIN_NATIVE_PARAMETER_BINDING"
        else:
            assert result["status"] == "OPEN_NATIVE_GENERATION_NOT_DISTINGUISHABLE"
        assert result["execution_occurrence_generation"] == "UNPROVEN"
    else:
        with pytest.raises(ValueError):
            tool.native_parameter_bindings(doc, life, tmp_path / "task-dump-index.json")


def test_deep_binding_failure_cannot_retain_collection_pass(monkeypatch, tmp_path):
    from tools.p7x_graph_repair6_storage import digest
    import tools.p7x_graph_repair5_evidence as evidence

    monkeypatch.setattr(evidence, "audit_execution", lambda *a, **kw: dict(status="EXECUTION_ASSOCIATED"))
    records, graphs = [], {}
    from typing import NamedTuple

    class Descriptor(NamedTuple):
        num_reqs: int
        num_tokens: int

    for n in (1, 2, 4):
        def dump(path):
            from pathlib import Path
            Path(path).write_text("{}")
        graphs[Descriptor(n, n * 7)] = SimpleNamespace(debug_dump=dump)
        records.append(dict(descriptor=[n, n * 7], completion="DIAGNOSTIC_COMPLETE", retired=True,
                            generation=n, epoch=n, backing={}, complete_ns=1))
    spec = SimpleNamespace(query_cudagraph_manager=SimpleNamespace(graphs=graphs))
    life = SimpleNamespace(records=records, poisoned=False)
    path = tmp_path / "task-dump-index.json"
    doc = tool.completed_graph_dump(spec, life, path, dict(process_id=123))
    saved = tmp_path / "mrv2-lifecycle.json"
    saved.write_text(json.dumps(dict(identity=doc["identity"], records=records)))
    campaign = dict(diagnostic_artifacts={saved.name: dict(bytes=saved.stat().st_size, sha256=digest(saved))})
    launcher = dict(host_start_ns=0, host_end_ns=10**30)
    assert tool.check(doc, campaign, launcher, {}, path)["status"] == "PASS_SCOPED_NATIVE_JSON_COLLECTION"
    assert tool.check(doc, campaign, launcher, {}, path, native_bindings=True)["status"] == "INVALID_EVIDENCE"


def test_poisoned_life_never_reads_capture_parameters(monkeypatch, tmp_path):
    def forbidden():
        raise AssertionError("must not inspect uncertain native/capture state")

    monkeypatch.setattr(tool, "_captured_parameters", forbidden)
    with pytest.raises(ValueError):
        tool.completed_graph_dump(SimpleNamespace(), SimpleNamespace(poisoned=True),
                                  tmp_path / "task-dump-index.json", {}, host_bindings=True)
    assert not list(tmp_path.iterdir())


@pytest.mark.parametrize("ambiguous", [False, True])
def test_native_layer_match_is_by_kv_pair_not_task_order(tmp_path, ambiguous):
    spec, params, capture = binding_fixture()
    a = tool.capture_fia_bindings(spec, SimpleNamespace(num_tokens=7), params, [capture])[0]
    import copy
    b = copy.deepcopy(a)
    b.update(layer_name="layer1", handle_identity=a["handle_identity"] + 1, event_identity=a["event_identity"] + 1)
    b["key"][0]["data_ptr"] += 8
    b["value"][0]["data_ptr"] += 8
    for x in (a, b):
        x["host_observed_ns"] = 2
    cap_b = dict(capture, layer_name="layer1", handle_identity=b["handle_identity"], event_identity=b["event_identity"])
    updates = [dict(x, stage="update_operator", generation_id=6, mapping_epoch=6, length_values=[28]) for x in (capture, cap_b)]
    life = dict(draft_layer_names=["layer0", "layer1"], recorder=dict(operand_events=[capture, cap_b, *updates]))
    second = native(key=0x30008, value=0x40008)
    second["args"]["Task Id"] = 36
    path = tmp_path / "native.json"
    path.write_text(json.dumps([second, native()]))
    doc = dict(schema="repair8-native-graph-json-v2", host_binding_scope="AFTER_SUCCESSFUL_LIFE_DRAINS_METADATA_ONLY",
               identity=dict(process_id=123), records=[dict(descriptor=[1, 7], captured_fia_bindings=[a, b],
               path=path.name, last_life_generation=6, last_life_epoch=6, start_ns=1, end_ns=3)])
    if ambiguous:
        b["key"], b["value"] = a["key"], a["value"]
        with pytest.raises(ValueError):
            tool.native_parameter_bindings(doc, life, tmp_path / "index.json")
    else:
        result = tool.native_parameter_bindings(doc, life, tmp_path / "index.json")
        assert [r["layer_name"] for r in result["tasks"]] == ["layer1", "layer0"]
