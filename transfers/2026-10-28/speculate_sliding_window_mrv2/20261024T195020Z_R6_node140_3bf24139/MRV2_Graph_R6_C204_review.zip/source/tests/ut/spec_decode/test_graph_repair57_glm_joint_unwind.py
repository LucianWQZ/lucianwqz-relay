# SPDX-License-Identifier: Apache-2.0
"""Host counterexamples; no generated row is treated as actual rank evidence."""
import copy
import json
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair41_rank_unwind import fault_kwargs, install_execute_error_export
from tools.p7x_graph_repair55_glm_cp_numeric import build_kwargs
from tools.p7x_graph_repair57_glm_joint_unwind import validate_joint_features
from tests.ut.spec_decode.test_graph_repair50_glm_required_baseline import feature_rows


def fixture():
    workers = []
    terminals = []
    for rank, row in enumerate(feature_rows(graph_window=True)):
        worker = dict(rank=rank, pid=1000 + rank, process_start_ticks=str(500 + rank), **row)
        final = copy.deepcopy(row['required_features'])
        worker['required_features']['actual_metadata_audit'] = dict(calls=0, cp_context_returns=0, samples=[])
        workers.append(worker)
        terminals.append(dict(required_feature_host_evidence=dict(
            rank=rank, pid=1000 + rank, process_start_ticks=str(500 + rank), required_features=final,
            scope='EXISTING_CPU_HEADERS_AND_BUILDER_RETURNS_NOT_DEVICE_COMPLETION')))
    return workers, terminals


def test_joint_fault_kwargs_preserve_full_real_glm_model_query_and_topology():
    base, current = build_kwargs('ON', 16), fault_kwargs('glm_k8_required', 16)
    extension = current.pop('worker_extension_cls')
    base.pop('worker_extension_cls')
    assert base == current
    assert extension == 'tools.p7x_graph_repair57_glm_joint_unwind.GLMJointUnwindWorker'
    for tp in (2, 4, 8):
        with pytest.raises(ValueError):
            fault_kwargs('glm_k8_required', tp)
    assert fault_kwargs('glm_k8', 16)['async_scheduling'] is False


def test_initial_identity_has_no_invented_execution_but_terminal_needs_actual_cp_returns():
    workers, terminals = fixture()
    assert validate_joint_features(workers)['actual_metadata_execution_required'] is False
    assert validate_joint_features(workers, terminals=terminals)['actual_metadata_execution_required'] is True


@pytest.mark.parametrize('damage', ['missing_rank', 'duplicate_rank', 'foreign_terminal', 'pid', 'ticks',
                                    'missing_terminal', 'no_cp_calls', 'flag_drift', 'ordinary_builder',
                                    'export_error', 'missing_feature', 'false_observation_scope'])
def test_expected_exit_code_cannot_rescue_missing_or_foreign_joint_feature_facts(damage):
    workers, terminals = fixture()
    evidence = terminals[-1]['required_feature_host_evidence']
    if damage == 'missing_rank':
        workers.pop()
    elif damage == 'duplicate_rank':
        workers[-1]['rank'] = 0
    elif damage == 'foreign_terminal':
        evidence['rank'] = 0
    elif damage == 'pid':
        evidence['pid'] += 1
    elif damage == 'ticks':
        evidence['process_start_ticks'] += '1'
    elif damage == 'missing_terminal':
        terminals.pop()
    elif damage == 'no_cp_calls':
        evidence['required_features']['actual_metadata_audit'] = dict(calls=0, cp_context_returns=0, samples=[])
    elif damage == 'flag_drift':
        evidence['required_features']['async_scheduling'] = False
    elif damage == 'ordinary_builder':
        for feature in (workers[-1]['required_features'], evidence['required_features']):
            feature['target_layers'][-1]['builder'] = 'ordinary'
    elif damage == 'export_error':
        terminals[-1]['required_feature_export_error'] = 'not JSON'
    elif damage == 'missing_feature':
        evidence['required_features'].pop('prefix_caching')
    else:
        evidence['scope'] = 'DEVICE_COMPLETION'
    with pytest.raises((ValueError, KeyError)):
        validate_joint_features(workers, terminals=terminals)


def test_error_export_saves_existing_plain_host_audit_without_masking_primary_error(tmp_path):
    primary = RuntimeError('actual sample_tokens exception')
    def fail():
        raise primary
    runner = SimpleNamespace(execute_model=lambda: 'ok', sample_tokens=fail)
    evidence = dict(rank=0, pid=1000, required_features=dict(actual_metadata_audit=dict(calls=1)))
    probe = SimpleNamespace(required_feature_host_evidence=evidence, __exit__=lambda *args: None)
    path = tmp_path / 'terminal.json'
    install_execute_error_export(runner, probe, path, dict(rank=0))
    with pytest.raises(RuntimeError) as error:
        runner.sample_tokens()
    assert error.value is primary
    saved = json.loads(path.read_text())
    assert saved['required_feature_host_evidence'] == evidence
    assert saved['post_fault_device_operations'] == 'NONE_BY_THIS_WRAPPER'
