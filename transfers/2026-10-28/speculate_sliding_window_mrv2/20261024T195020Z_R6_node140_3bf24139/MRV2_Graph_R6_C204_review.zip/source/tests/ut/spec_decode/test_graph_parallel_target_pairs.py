# SPDX-License-Identifier: Apache-2.0
"""CPU work placement must preserve every Target rank and a failed comparison."""
import json
import os

import pytest
import torch

from tools.p7x_graph_repair38_glm_numeric import ordered_target_comparisons


def record_validator(record):
    if not record['valid']: raise ValueError('damaged saved Target record')


def isolation_validator(record):
    return []


def small_pair(off_path,on_path,*,progress,profile,record_validator,isolation_validator):
    off,on=[json.loads(p.read_text()) for p in (off_path,on_path)]
    for row in (off,on):record_validator(row)
    assert not isolation_validator(off) and not isolation_validator(on)
    result=dict(rank=off['rank'],status='PASS' if torch.equal(torch.tensor(off['values']),torch.tensor(on['values']))
                else 'FAIL',pid=os.getpid())
    progress.write_text(json.dumps(result))
    return result


def tasks(tmp_path):
    rows=[]
    for rank in (3,1,2,0):
        paths=[tmp_path/f'{arm}-{rank}.json' for arm in ('off','on')]
        for path in paths:path.write_text(json.dumps(dict(rank=rank,valid=True,values=[rank,rank+3])))
        rows.append(dict(off_path=paths[0],on_path=paths[1],progress=tmp_path/f'progress-{rank}.json',
                         profile='HOST_ONLY',record_validator=record_validator,isolation_validator=isolation_validator))
    return rows


@pytest.mark.parametrize('damage',[None,'numeric','invalid'])
def test_real_cpu_children_preserve_order_and_never_drop_failed_target_rank(tmp_path,damage):
    rows=tasks(tmp_path)
    if damage:
        path=rows[2]['on_path'];row=json.loads(path.read_text())
        if damage=='numeric':row['values'][0]+=1
        else:row['valid']=False
        path.write_text(json.dumps(row))
    if damage=='invalid':
        for count in (1,2):
            with pytest.raises(ValueError,match='damaged saved Target'):
                list(ordered_target_comparisons(rows,cpu_workers=count,compare=small_pair))
    else:
        serial=list(ordered_target_comparisons(rows,compare=small_pair))
        parallel=list(ordered_target_comparisons(rows,cpu_workers=2,compare=small_pair))
        assert [{k:v for k,v in row.items() if k!='pid'} for row in serial] == [
            {k:v for k,v in row.items() if k!='pid'} for row in parallel]
        assert [r['rank'] for r in parallel] == [3,1,2,0]
        assert all(r['pid'] != os.getpid() for r in parallel)
        assert [r['status'] for r in parallel] == (['PASS','PASS','FAIL','PASS'] if damage else ['PASS']*4)


@pytest.mark.parametrize('count',[False,0,-1,5])
def test_unbounded_or_untyped_target_parallelism_rejected(tmp_path,count):
    with pytest.raises(ValueError,match='bounded explicit Target CPU worker'):
        list(ordered_target_comparisons(tasks(tmp_path),cpu_workers=count,compare=small_pair))
