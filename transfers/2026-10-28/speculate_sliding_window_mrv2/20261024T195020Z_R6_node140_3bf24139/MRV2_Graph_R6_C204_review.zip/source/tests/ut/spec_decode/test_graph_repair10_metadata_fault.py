# SPDX-License-Identifier: Apache-2.0
"""Real CPU proposal scope and quarantine; checker fixtures are not NPU proof."""

import hashlib
import json
import os
from types import SimpleNamespace

import pytest

from tests.ut.spec_decode.test_draft_window_eager import _harness
from tools.p7x_graph_repair10_metadata_fault import (
    InjectedMetadataPublishUnwindError,
    MetadataPublishUnwindProbe,
    check,
)


def actual_artifact(tmp_path, point="metadata_before_publish"):
    owner, batch = _harness(query_width=7)
    owner._draft_window_graph_characterization = SimpleNamespace(recorder=SimpleNamespace(enabled=False))
    owner.query_cudagraph_manager = SimpleNamespace(graphs={})
    identity = dict(
        run_id="cpu-only",
        case_id="UNWIND_" + point,
        attempt_id="1",
        source_sha="a" * 40,
        source_tree="b" * 40,
        driver_mode="B-observer-off",
        process_id=os.getpid(),
        engine_id=123,
    )
    artifact = tmp_path / "metadata-publish-unwind.json"
    probe = MetadataPublishUnwindProbe(owner, artifact, identity, point=point)
    with (
        pytest.raises(InjectedMetadataPublishUnwindError),
        probe,
        owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False),
    ):
        inputs = owner._materialize_draft_window_read_inputs(num_reqs=2, num_reqs_padded=4)
        owner._draft_window_live_inputs = inputs
        owner._draft_window_runtime_state.publish_metadata(
            inputs, {"draft": object()}, target_metadata=owner.model_state.attn_metadata
        )
    assert not probe.saved
    assert owner._draft_window_runtime_state.quarantined_identity == inputs.identity
    assert owner._draft_window_runtime_state._active_inputs is inputs
    data = json.loads(artifact.read_text())
    assert data["next_scope_guard"]["rejected"] and not data["post_fault_clear_attempts"]
    return artifact, data


@pytest.mark.parametrize(
    "damage",
    [
        None,
        "generation",
        "target",
        "guard",
        "lease",
        "active",
        "clear",
        "replay",
        "exit",
        "timeout",
        "pid",
        "hash",
        "cause",
        "handler",
        "store",
    ],
)
@pytest.mark.parametrize("point", ["metadata_before_publish", "metadata_store_publish"])
def test_actual_proposal_exception_and_external_execution_join_reject_damage(tmp_path, damage, point):
    artifact, data = actual_artifact(tmp_path, point)
    data["record"]["device"] = "npu:0"  # Explicit checker fixture; actual Host test above ran CPU.
    identity = data["identity"]
    argv = ["python", "run"]
    expected = dict(
        acceptance_identity=identity,
        argv=argv,
        launch_argv=["launch", "--", *argv],
        requests_sha256="c" * 64,
        outputs=str(tmp_path),
        unwind_point=point,
    )
    launcher = dict(
        identity,
        pid=identity["process_id"],
        argv=argv,
        requests_sha256="c" * 64,
        host_start_ns=data["record"]["ns"] - 1,
        host_end_ns=data["next_scope_guard"]["ns"] + 1,
        status="EXITED",
        returncode=74,
        signal=None,
        timeout=False,
    )
    campaign = dict(
        identity=identity,
        status="EXCEPTION",
        startup_complete=True,
        diagnostic_quarantine="PROCESS_EXIT_74_NO_REUSE",
        exception_type="InjectedMetadataPublishUnwindError",
        exception_message=("REPAIR10_METADATA_UNWIND:"
                           + ("store_publish" if point == "metadata_store_publish" else "before_publish")),
        request_manifest=dict(sha256="c" * 64),
    )
    if damage == "generation":
        data["record"]["generation"] += 1
    elif damage == "target":
        data["record"]["target_separate"] = False
    elif damage == "guard":
        data["next_scope_guard"]["body_entered"] = True
    elif damage == "lease":
        data["state"]["lease_identity"]["mapping_epoch"] += 1
    elif damage == "active":
        data["state"]["active_inputs_retained"] = False
    elif damage == "clear":
        data["post_fault_clear_attempts"].append(1)
    elif damage == "replay":
        data["replays_after_record"] = 1
    elif damage == "exit":
        launcher["returncode"] = 0
    elif damage == "timeout":
        launcher["timeout"] = True
    elif damage == "pid":
        launcher["pid"] += 1
    elif damage == "handler":
        data["internal_failure_handler"] = [] if point == "metadata_store_publish" else [dict(returned=True)]
    elif damage == "store":
        data["record"]["store_called"] = point != "metadata_store_publish"
    elif damage == "cause":
        campaign["exception_type"] = "OtherError"
    artifact.write_text(json.dumps(data))
    campaign["diagnostic_artifacts"] = {
        artifact.name: dict(bytes=artifact.stat().st_size, sha256=hashlib.sha256(artifact.read_bytes()).hexdigest())
    }
    if damage == "hash":
        artifact.write_text("tampered")
    result = check(data, campaign, launcher, expected, artifact)
    assert (result["status"] == "PASS_SCOPED_METADATA_PUBLISH_UNWIND") is (damage is None), result


@pytest.mark.parametrize("point", ["metadata_before_publish", "metadata_store_publish"])
def test_runner_requires_dedicated_metadata_checker_and_exact_outcome(point):
    from tools.p7x_graph_repair6_runner import adjudicate_records

    name = "UNWIND_" + point
    plan = dict(cases={name: dict(unwind_point=point)}, run_id="r", commit="s", tree="t")
    launch = dict(argv=["launch"], returncode=74, timeout=False, kind="launch", status="EXECUTION_FAILED")
    good = dict(
        argv=["p7x_graph_repair10_metadata_fault.py"],
        returncode=0,
        timeout=False,
        kind="read_only_acceptance",
        status="COMMAND_COMPLETED_NOT_GATE_PASS",
    )
    assert adjudicate_records(plan, name, [launch, good])["dependency_satisfied"]
    assert not adjudicate_records(plan, name, [launch])["dependency_satisfied"]
    assert not adjudicate_records(plan, name, [dict(launch, returncode=0), good])["dependency_satisfied"]
    assert not adjudicate_records(plan, name, [launch, dict(good, argv=["unrelated.py"])])["dependency_satisfied"]
