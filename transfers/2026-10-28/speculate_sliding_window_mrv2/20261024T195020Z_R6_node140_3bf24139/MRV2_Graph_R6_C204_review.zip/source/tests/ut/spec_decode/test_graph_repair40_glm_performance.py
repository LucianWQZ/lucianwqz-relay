# SPDX-License-Identifier: Apache-2.0
"""GLM K8, balanced controls and all-rank scope cannot inherit TP1 counters."""
import copy
import hashlib
import json
from types import SimpleNamespace

import pytest

from tools import p7x_graph_repair40_glm_performance as perf


def metrics():
    drafted, accepted = [8, 8, 3], [8, 2, 1]
    return dict(num_spec_tokens=8, per_step_drafted=drafted, per_step_accepted=accepted,
                acceptance_histogram=[accepted.count(i) for i in range(9)], num_draft_tokens=19,
                num_accepted_draft_tokens=11, num_spec_steps=3, draft_acceptance_rate=11/19,
                mean_acceptance_length=1+11/3)


def test_exact_K8_and_last_short_proposal_not_padding_or_bonus():
    checked = perf.acceptance(metrics())
    assert checked['proposed'] == 19 and checked['accepted'] == 11
    assert checked['mean_acceptance_length_including_bonus'] == 1+11/3
    assert checked['proposed_per_position'] == [3, 3, 3, 2, 2, 2, 2, 2]


@pytest.mark.parametrize('damage', ['K7', 'bool_k', 'bool_count', 'histogram', 'padding', 'rate', 'bonus'])
def test_wrong_method_or_inconsistent_framework_counts_rejected(damage):
    m = metrics()
    if damage == 'K7':m['num_spec_tokens']=7
    elif damage == 'bool_k':m['num_spec_tokens']=True
    elif damage == 'bool_count':m['num_spec_steps']=True
    elif damage == 'histogram':m['acceptance_histogram'][0]+=1
    elif damage == 'padding':m['per_step_drafted'][-1]=8
    elif damage == 'rate':m['draft_acceptance_rate']=1.
    else:m['num_accepted_draft_tokens']+=3
    with pytest.raises(ValueError):perf.acceptance(m)


def workload():
    return [dict(label='short-real',prompts=[dict(prompt_token_ids=[100]*257)],max_tokens=256)]


@pytest.mark.parametrize('repeat', range(1, 7))
def test_balanced_pair_order_does_not_invent_standalone_eager_support(repeat):
    order = ('G_OFF', 'G_ON') if repeat % 2 else ('G_ON', 'G_OFF')
    for index, arm in enumerate(order, 1):
        perf.validate_workload(arm,4096,workload(),repeat,index,False)
        with pytest.raises(ValueError):perf.validate_workload(arm,4096,workload(),repeat,3-index,False)
    with pytest.raises(ValueError,match='eager'):perf.validate_workload('E_ON',4096,workload(),repeat,1,False)


def test_profiler_is_separate_from_normal_repeats_and_capacity_is_bounded():
    perf.validate_workload('G_ON',4096,workload(),0,0,True)
    with pytest.raises(ValueError):perf.validate_workload('G_ON',4096,workload(),1,1,True)
    with pytest.raises(ValueError):perf.validate_workload('G_OFF',4096,workload(),0,0,True)
    with pytest.raises(ValueError):perf.validate_workload('G_OFF',4096,workload(),True,1,False)
    rows=workload();rows[0]['prompts'][0]['prompt_token_ids']=[100]*4096
    with pytest.raises(ValueError):perf.validate_workload('G_OFF',4096,rows,1,1,False)


def rank_rows(source, pin, arm, start):
    rows=[]
    for rank in range(16):
        g=dict(generation=41,epoch=17,requests=['real-a'],actual=1,padded=1,window_starts=[start],exact=[257],
               tp_size=16,tp_rank=rank)
        rows.append(dict(rank=rank,pid=2000+rank,tp_size=16,world_size=16,draft_tp_size=16,
                         ascend_source=str(source/'vllm_ascend/__init__.py'),vllm_source=str(pin/'vllm/__init__.py'),
                         heavy_observer_enabled=False,submission_uncertain=False,draft_replays=44,target_replays=43,
                         window_size=1024 if arm=='G_ON' else None,window_provider_installed=arm=='G_ON',
                         window_generations=[g] if arm=='G_ON' else [],
                         window_graph_bindings=[dict(tp_rank=rank,tp_size=16)] if arm=='G_ON' else []))
    return rows


def test_short_S0_is_valid_and_long_requires_actual_clipping(monkeypatch,tmp_path):
    # Full GLM geometry/backend checks have their existing independent tests;
    # isolate the new per-cell topology/phase/counter rules here.
    monkeypatch.setattr(perf,'validate_glm_worker',lambda row,tp:None)
    source,pin=tmp_path/'source',tmp_path/'pin';rows=rank_rows(source,pin,'G_ON',0)
    result=perf.validate_ranks(rows,source=source,pin=pin,arm='G_ON',need_clip=False)
    assert result['ranks']==16 and result['Draft']==44  # Never sum sixteen replicas as useful work.
    with pytest.raises(ValueError,match='clip'):
        perf.validate_ranks(rows,source=source,pin=pin,arm='G_ON',need_clip=True)


@pytest.mark.parametrize('damage',['missing','duplicate','pid_bool','source','count_bool','count_skew',
                                   'logical_skew','rank_binding','provider','observer','unknown','off_polluted'])
def test_partial_or_cross_rank_performance_evidence_rejected(monkeypatch,tmp_path,damage):
    monkeypatch.setattr(perf,'validate_glm_worker',lambda row,tp:None)
    source,pin=tmp_path/'source',tmp_path/'pin';arm='G_ON';rows=rank_rows(source,pin,arm,128)
    if damage=='missing':rows.pop()
    elif damage=='duplicate':rows[-1]['rank']=0
    elif damage=='pid_bool':rows[0]['pid']=True
    elif damage=='source':rows[0]['ascend_source']='/old/vllm_ascend/__init__.py'
    elif damage=='count_bool':rows[0]['draft_replays']=True
    elif damage=='count_skew':rows[0]['target_replays']+=1
    elif damage=='logical_skew':rows[0]['window_generations'][0]['epoch']+=1
    elif damage=='rank_binding':rows[0]['window_graph_bindings'][0]['tp_rank']=1
    elif damage=='provider':rows[0]['window_provider_installed']=False
    elif damage=='observer':rows[0]['heavy_observer_enabled']=True
    elif damage=='unknown':rows[0]['submission_uncertain']=True
    else:
        arm='G_OFF';rows=rank_rows(source,pin,arm,0);rows[0]['window_provider_installed']=True
    with pytest.raises(ValueError):perf.validate_ranks(rows,source=source,pin=pin,arm=arm,need_clip=arm=='G_ON')


def test_worker_counter_reset_is_host_only_and_preserves_runtime_owners():
    worker=object.__new__(perf.GLMPerformanceWorker)
    worker.rank=3
    worker._mrv2_rank_replay_records=[object()]
    worker._mrv2_rank_window_generations=[object()]
    worker._mrv2_rank_window_bindings=[object()]
    sentinel=object();worker.model_runner=sentinel
    row=worker.mrv2_glm_perf_reset()
    assert row['rank']==3 and row['reset']=='HOST_COUNTERS_ONLY_NO_DEVICE_OPERATION'
    assert worker.model_runner is sentinel and worker._mrv2_rank_replay_records==[]


@pytest.mark.parametrize('damage',[None,'input','output','warmup','source','order','profile','clock','counter','arm',
                                   'profile_valid','profile_missing_rank','profile_duplicate_rank',
                                   'profile_bool_rank','profile_native_owner','profile_not_restored','profile_range_list'])
def test_full_artifact_joint_binds_workload_and_repetition(monkeypatch,tmp_path,damage):
    monkeypatch.setattr(perf,'validate_glm_worker',lambda row,tp:None)
    source,pin=tmp_path/'source',tmp_path/'pin'
    groups=workload();req=tmp_path/'requests.json';req.write_text(json.dumps(groups));kwargs={'fixed':'kwargs'}
    monkeypatch.setattr(perf,'configuration',lambda args:(groups,kwargs))
    monkeypatch.setattr(perf,'profile_identity',lambda:{'frozen':'model'})
    args=SimpleNamespace(requests=req,expected_sha='a'*40,arm='G_ON',repetition=1,order_position=2,
                         profile=False,producer_source=source)
    n=255;m=dict(num_spec_tokens=8,acceptance_histogram=[n]+[0]*8,per_step_drafted=[8]*n,
                 per_step_accepted=[0]*n,num_draft_tokens=8*n,num_accepted_draft_tokens=0,
                 num_spec_steps=n,draft_acceptance_rate=0,mean_acceptance_length=1)
    campaign=dict(status='NORMAL_REQUEST_COMPLETE',startup_complete=True,startup_end_ns=12,
                  source_sha='a'*40,kwargs=kwargs,requests=copy.deepcopy(groups),
                  requests_sha256=perf.digest(req),profile_identity={'frozen':'model'},repetition=1,order_position=2,
                  profile=False,heavy_diagnostics=False,arm='G_ON',start_monotonic_ns=10,end_monotonic_ns=100,
                  config_sha256=hashlib.sha256(json.dumps(kwargs,sort_keys=True).encode()).hexdigest(),
                  vllm_checkout=str(pin),warmup_outputs=[[9]*256],warmup_input_ids=[[100]*257],
                  warmup_finished=[True],warmup_start_ns=15,warmup_end_ns=25,
                  ranks=rank_rows(source,pin,'G_ON',0),
                  measured=dict(input_ids=[[100]*257],tokens=[[9]*256],metrics=[dict(finished=True,speculative_decoding=m)],
                                finished=[True],start_ns=30,end_ns=90))
    if damage and damage.startswith('profile_'):
        args.profile=True
        args.repetition=args.order_position=0
        campaign.update(profile=True,repetition=0,order_position=0,
                        host_range_start=[dict(rank=r,scope='HOST_RANGES_ONLY_OFFICIAL_WORKER_IS_SOLE_NATIVE_PROFILER')
                                          for r in range(16)],
                        host_range_stop=[dict(rank=r,restored=True,ranges=[
                            'Draft_materialize','Draft_exact_length_snapshot','Draft_metadata_bind',
                            'Draft_UPDATE_CALL','Draft_retire_host']) for r in range(16)])
        if damage=='profile_missing_rank':campaign['host_range_start'].pop()
        elif damage=='profile_duplicate_rank':campaign['host_range_stop'][-1]['rank']=0
        elif damage=='profile_bool_rank':campaign['host_range_start'][0]['rank']=False
        elif damage=='profile_native_owner':campaign['host_range_start'][0]['scope']='SECOND_NATIVE_PROFILER'
        elif damage=='profile_not_restored':campaign['host_range_stop'][0]['restored']=False
        elif damage=='profile_range_list':campaign['host_range_stop'][0]['ranges'].pop()
    if damage=='input':campaign['measured']['input_ids'][0][0]=101
    elif damage=='output':campaign['measured']['tokens'][0].pop()
    elif damage=='warmup':campaign['warmup_outputs']=[]
    elif damage=='source':campaign['source_sha']='b'*40
    elif damage=='order':campaign['order_position']=True
    elif damage=='profile':campaign['profile']=True
    elif damage=='clock':campaign['measured']['end_ns']=101
    elif damage=='counter':m['num_draft_tokens']+=1
    elif damage=='arm':campaign['arm']='G_OFF'
    if damage in (None,'profile_valid'):
        result=perf.check_campaign(campaign,args)
        assert result['output_tokens']==256 and result['all_rank_host_dispatch']['ranks']==16
        assert result['standalone_eager_comparison'].startswith('NOT_AVAILABLE')
        if args.profile:
            assert result['measurement']=='PROFILED_NOT_NORMAL_REPEAT'
            assert result['profiling_collection']=='REQUIRES_RAW_ALL_RANK_TRACE_AUDIT'
    else:
        with pytest.raises(ValueError):perf.check_campaign(campaign,args)


def test_real_absolute_cli_keeps_tools_bisect_outside_stdlib_search(tmp_path):
    import subprocess
    import sys
    from pathlib import Path
    tool=Path(perf.__file__).resolve()
    result=subprocess.run([sys.executable,str(tool),'--help'],cwd=tmp_path,capture_output=True,text=True,timeout=30)
    assert result.returncode==0,result.stderr
    assert '--max-model-len' in result.stdout and '--profile' in result.stdout


def test_host_ranges_preserve_return_and_exception_without_native_collection():
    owner=SimpleNamespace()
    sentinel=object()
    def compute(x):
        if x:raise RuntimeError('actual-error')
        return sentinel
    owner.fn=compute
    hooks=perf.HostRangeHooks([(owner,'fn','Draft_test_range')]);hooks.install()
    assert owner.fn(False) is sentinel
    with pytest.raises(RuntimeError,match='actual-error'):owner.fn(True)
    assert hooks.restore()==['Draft_test_range'] and owner.fn is compute


def test_missing_host_range_does_not_partially_install_hooks():
    owner=SimpleNamespace(fn=lambda:7)
    original=owner.fn
    with pytest.raises(AttributeError):perf.HostRangeHooks([(owner,'fn','ok'),(owner,'missing','bad')])
    assert owner.fn is original
