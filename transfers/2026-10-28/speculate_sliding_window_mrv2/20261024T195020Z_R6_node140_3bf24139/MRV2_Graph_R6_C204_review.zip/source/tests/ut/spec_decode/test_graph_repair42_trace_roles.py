# SPDX-License-Identifier: Apache-2.0
"""Explicit source-role recognition and exact interval/flow counterexamples."""
from decimal import Decimal
import random

import pytest

from tools.p7x_graph_repair6_trace import Intervals, analyze


ROLE_NAMES = {
    'Draft': 'Draft', 'Eagle_first': 'Draft_first_pass', 'Eagle_AR': 'Draft_AR', 'Target': 'Target',
}


def role_events(role, offset=0, flow_id=1):
    name = ROLE_NAMES[role]
    return [
        dict(ph='X', name=f'repair5/{name}_REPLAY_PLUS_UPDATE', pid=1, tid=2, ts=offset, dur=9),
        dict(ph='X', name=f'repair5/{name}_REPLAY_SUBMIT', pid=1, tid=2, ts=offset+1, dur=3),
        dict(ph='s', name='torch_to_npu', cat='flow', id=flow_id, pid=1, tid=2, ts=offset+2),
        dict(ph='f', name='torch_to_npu', cat='flow', id=flow_id, pid=5, tid=6, ts=offset+11),
        dict(ph='X', name='EVENT_RECORD', pid=5, tid=6, ts=offset+10, dur=3),
    ]


@pytest.mark.parametrize('role', ROLE_NAMES)
def test_named_host_role_does_not_promote_device_event_to_model_occurrence(role):
    result = analyze(role_events(role), replay_roles=(role,))
    assert result['coverage'] == dict(total_replays=1, direct_matched=1)
    replay = result['replays'][0]
    assert replay['host_role'] == role
    assert replay['direct_flow_kinds'] == {'DEVICE_EVENT_FLOW': 1}
    assert replay['manager_association'] == 'UNIQUE_SAME_THREAD_FULL_CONTAINMENT'
    assert result['classified_coverage']['model_execution_context_flow_replays'] == 0
    assert result['coverage_by_role'][role]['generation_bound_execution_flow'].startswith('NOT_AVAILABLE')


def test_eagle_roles_are_explicit_and_legacy_default_is_preserved():
    events = role_events('Eagle_first') + role_events('Eagle_AR', 20, 2) + role_events('Target', 40, 3)
    assert analyze(events)['coverage']['total_replays'] == 0
    result = analyze(events, replay_roles=('Eagle_first', 'Eagle_AR', 'Target'))
    assert result['coverage']['total_replays'] == 3
    assert all(v['observed_Host_replay_ranges'] == 1 for v in result['coverage_by_role'].values())
    assert [r['host_role'] for r in result['replays']] == ['Eagle_first', 'Eagle_AR', 'Target']
    # An unknown label is not silently renamed as a known role.
    events[1]['name'] = 'repair5/FIA_same_shape_and_nearby_time'
    assert analyze(events, replay_roles=('Eagle_first',))['coverage']['total_replays'] == 0


@pytest.mark.parametrize('roles', [(), ('Eagle_AR', 'Eagle_AR'), ('same-shape-FIA',), [True], 'Eagle_AR'])
def test_invalid_or_duplicate_role_contract_is_rejected(roles):
    with pytest.raises(ValueError):
        analyze([], replay_roles=roles)


@pytest.mark.parametrize('damage', ['wrong_thread', 'wrong_role', 'truncated_parent', 'duplicate_parent'])
def test_parent_context_requires_unique_full_same_thread_containment(damage):
    events = role_events('Eagle_AR')
    if damage == 'wrong_thread':
        events[0]['tid'] = 99
    elif damage == 'wrong_role':
        events[0]['name'] = 'repair5/Draft_REPLAY_PLUS_UPDATE'
    elif damage == 'truncated_parent':
        events[0]['dur'] = 2
    else:
        events.append(dict(events[0]))
    result = analyze(events, replay_roles=('Eagle_AR',))
    replay = result['replays'][0]
    assert replay['manager_association'] == 'MISSING_OR_AMBIGUOUS_NO_MANAGER_FLOW_CLAIM'
    assert replay['replay_plus_update_flow_indices'] == []
    # The explicitly matched direct event flow remains only an event flow.
    assert replay['direct_flow_kinds'] == {'DEVICE_EVENT_FLOW': 1}


def test_duplicate_or_local_flow_endpoints_remain_unresolved_for_eagle():
    events = role_events('Eagle_first')
    assert analyze(events+[dict(events[3])], replay_roles=('Eagle_first',))['coverage']['direct_matched'] == 0
    for event in events:
        if event['ph'] in ['s', 'f']:
            event['id2'] = {'local': event.pop('id')}
    assert analyze(events, replay_roles=('Eagle_first',))['flow_counts'] == {'UNMATCHED': 2}


def brute(events, point):
    at = Decimal(str(point['ts']))
    matches = []
    for index, event in enumerate(events):
        if event.get('ph') != 'X' or (event['pid'], event['tid']) != (point['pid'], point['tid']):
            continue
        lo = Decimal(str(event['ts']))
        hi = lo+Decimal(str(event['dur']))
        if lo <= at <= hi:
            matches.append((hi-lo, index))
    return [index for _, index in sorted(matches)]


def test_interval_tree_matches_independent_inclusive_scan_on_nested_decimal_and_threads():
    rng = random.Random(42)
    events = [dict(ph='X', name='long-request', pid=1, tid=1, ts='0.1', dur='10000.2')]
    for i in range(300):
        events.append(dict(ph='X', name='operator', pid=i % 3, tid=i % 5,
                           ts=str(Decimal(rng.randrange(-50, 10000))/10),
                           dur=str(Decimal(rng.randrange(0, 1000))/10)))
    intervals = Intervals(events, lambda e: True)
    for event in events:
        for at in [Decimal(str(event['ts'])), Decimal(str(event['ts']))+Decimal(str(event['dur']))]:
            point = dict(pid=event['pid'], tid=event['tid'], ts=str(at))
            assert intervals.containing(point) == brute(events, point)
    assert intervals.containing(dict(pid=99, tid=99, ts=0)) == []
    assert intervals.containing(dict(pid=1, tid=1, ts=-1000)) == []


def test_long_enclosing_scope_and_thousands_of_expired_disjoint_operators():
    events = [dict(ph='X', pid=1, tid=1, ts=0, dur=20000)]
    events += [dict(ph='X', pid=1, tid=1, ts=3*i, dur=1) for i in range(5000)]
    intervals = Intervals(events, lambda e: True)
    for at in [0, 14997, 14998, 14999, 20000, 20001]:
        point = dict(pid=1, tid=1, ts=at)
        assert intervals.containing(point) == brute(events, point)
