# SPDX-License-Identifier: Apache-2.0
"""Measured mixed-request history; no model, NPU or completion claim."""
import copy
from pathlib import Path
from types import SimpleNamespace

import pytest

from tools.p7x_graph_repair34_method_perf import RequestIdCapture,validate_window_history,digest
from tools.p7x_graph_repair5_profile import RequestProfiler
from vllm_ascend.worker.v2.spec_decode.draft_window import DraftWindowReadDescriptor


class HostInputProcessor:
    calls=0

    @staticmethod
    def assign_request_id(request):
        HostInputProcessor.calls+=1
        request.external_req_id=request.request_id
        request.request_id+='-actual-assigned'


def test_capture_observes_actual_assignment_once_excludes_warmup_and_restores_instance():
    processor=HostInputProcessor();HostInputProcessor.calls=0
    capture=RequestIdCapture(processor)
    warm=SimpleNamespace(request_id='warm',external_req_id=None);processor.assign_request_id(warm)
    assert capture.rows==[]
    capture.begin();actual=SimpleNamespace(request_id='not-guessed',external_req_id=None)
    processor.assign_request_id(actual);saved=capture.finish()
    assert HostInputProcessor.calls==2
    assert saved['rows'][0]['external_id']=='not-guessed'
    assert saved['rows'][0]['internal_id']==actual.request_id=='not-guessed-actual-assigned'
    assert saved['scope']=='ACTUAL_INPUT_PROCESSOR_ASSIGNMENT_HOST'
    assert capture.restore() is True and 'assign_request_id' not in vars(processor)
    capture.begin();assert capture.finish()['rows']==[]


def test_hook_replacement_is_not_silently_overwritten():
    processor=HostInputProcessor();capture=RequestIdCapture(processor)
    replacement=lambda request:None;processor.assign_request_id=replacement
    assert capture.restore() is False and processor.assign_request_id is replacement


@pytest.fixture
def evidence(tmp_path):
    pin=tmp_path/'pin';source=pin/'vllm/v1/engine/input_processor.py'
    source.parent.mkdir(parents=True);source.write_text('# Host fixture, not real pinned source\n')
    out=dict(label='mixed',start_ns=100,end_ns=200,metrics=[dict(request_id=x) for x in ['long','short']],
        window_identity=dict(active=1,read_descriptors=[dict(source_start_column=0,first_token_offset=0)]),
        request_id_mapping=dict(scope='ACTUAL_INPUT_PROCESSOR_ASSIGNMENT_HOST',source=dict(
            class_path='vllm.v1.engine.input_processor.InputProcessor',path=str(source),sha256=digest(source)),
            rows=[dict(external_id=x,internal_id=x+'-actual',assigned_ns=101) for x in ['long','short']]))
    def record(generation,ids,start):
        return dict(active=True,label='Draft_retire_host',request_group='mixed',start_ns=110+generation*10,
            end_ns=111+generation*10,generation=generation,mapping_epoch=20+generation,
            window_scope='ACTUAL_RETIRED_HOST_IDENTITY_NOT_DEVICE_COMPLETION_OR_OPERAND',
            window_request_ids=[x+'-actual' for x in ids],window_active=len(ids),window_padded=len(ids),
            window_read_descriptors=[dict(global_group_id=0,source_start_column=start,first_token_offset=0,
                required_columns=8,safe_extent_tokens=1024,valid_num_blocks=20,source_row_width=32) for _ in ids])
    profile=dict(window_history_enabled=True,calls=[record(1,['long','short'],8),record(2,['short'],0)])
    return pin,out,profile


def test_long_then_finished_short_history_is_not_the_terminal_single_request(evidence):
    pin,out,profile=evidence
    # The legacy final-only contract cannot describe this valid request order.
    assert out['window_identity']['active']!=len(out['metrics'])
    assert not any(d['source_start_column']*128+d['first_token_offset']>0
                   for d in out['window_identity']['read_descriptors'])
    result=validate_window_history(profile,out,arm='G_ON',pin=pin)
    assert result['clipped'] is True and result['max_window_start']==1024
    assert result['active_padded']==[[1,1],[2,2]]
    assert result['request_ids']==['long-actual','short-actual']
    assert 'NOT_COMPLETION' in result['scope']


@pytest.mark.parametrize('damage',['missing_request','foreign_request','mapping_duplicate','mapping_source',
    'mapping_hash','mapping_time','mapping_scope','time','phase','untyped_generation','untyped_epoch',
    'untyped_active','padded','descriptor_type','descriptor_offset','descriptor_missing','descriptor_extent','scope'])
def test_corrupt_cross_group_or_untyped_history_rejected(evidence,damage):
    pin,output,profile=evidence;out=copy.deepcopy(output);p=copy.deepcopy(profile);call=p['calls'][0]
    if damage=='missing_request':p['calls']=p['calls'][1:]
    elif damage=='foreign_request':call['window_request_ids'][0]='another-actual'
    elif damage=='mapping_duplicate':out['request_id_mapping']['rows'][1]['internal_id']='long-actual'
    elif damage=='mapping_source':out['request_id_mapping']['source']['path']='/old/input_processor.py'
    elif damage=='mapping_hash':out['request_id_mapping']['source']['sha256']='0'*64
    elif damage=='mapping_time':out['request_id_mapping']['rows'][0]['assigned_ns']=99
    elif damage=='mapping_scope':out['request_id_mapping']['scope']='PREFIX_GUESS'
    elif damage=='time':call['start_ns']=99
    elif damage=='phase':call['active']=False
    elif damage=='untyped_generation':call['generation']=True
    elif damage=='untyped_epoch':call['mapping_epoch']=True
    elif damage=='untyped_active':call['window_active']=True
    elif damage=='padded':call['window_padded']=1
    elif damage=='descriptor_type':call['window_read_descriptors'][0]['source_start_column']=True
    elif damage=='descriptor_offset':call['window_read_descriptors'][0]['first_token_offset']=128
    elif damage=='descriptor_missing':call['window_read_descriptors'][0].pop('safe_extent_tokens')
    elif damage=='descriptor_extent':call['window_read_descriptors'][0]['valid_num_blocks']=2
    else:call['window_scope']='DEVICE_COMPLETED'
    with pytest.raises(ValueError):validate_window_history(p,out,arm='G_ON',pin=pin)


def test_warmup_clipping_and_unchanged_generation_do_not_fake_measured_clipping(evidence):
    pin,out,profile=evidence
    warm=copy.deepcopy(profile['calls'][0]);warm.update(active=False,request_group='warmup',start_ns=10,end_ns=20)
    for call in profile['calls']:
        for d in call['window_read_descriptors']:d['source_start_column']=0
    profile['calls'].insert(0,warm)
    result=validate_window_history(profile,out,arm='E_ON',pin=pin)
    assert result['clipped'] is False and result['max_window_start']==0


def test_window_off_cannot_borrow_any_window_retirement(evidence):
    pin,out,profile=evidence
    with pytest.raises(ValueError,match='OFF'):validate_window_history(profile,out,arm='G_OFF',pin=pin)
    profile['calls']=[]
    assert validate_window_history(profile,out,arm='G_OFF',pin=pin)['clipped'] is False


def test_real_existing_retire_wrapper_uses_argument_not_a_stale_live_alias(tmp_path):
    def identity(gen,request):
        return SimpleNamespace(generation_id=gen,mapping_epoch=10+gen,
            ordered_request_fingerprint=(request,),actual_request_count=1,padded_request_count=1,
            read_descriptor_fingerprint=(DraftWindowReadDescriptor(0,8,0,8,1024,20,32),))
    old=identity(1,'old');actual=identity(2,'actual')
    runtime=SimpleNamespace(retire_generation=lambda expected_identity:None)
    original=runtime.retire_generation
    spec=SimpleNamespace(_draft_window_live_inputs=SimpleNamespace(identity=old))
    probe=RequestProfiler(SimpleNamespace(speculator=spec),tmp_path,{},enabled=False,window_history=True)
    probe._wrap(runtime,'retire_generation','Draft_retire_host');probe.begin_active()
    with probe.group('measured'):runtime.retire_generation(actual)
    row=probe.calls[-1]
    assert row['generation']==2 and row['mapping_epoch']==12
    assert row['window_request_ids']==['actual'] and row['window_active']==1
    assert row['window_scope']=='ACTUAL_RETIRED_HOST_IDENTITY_NOT_DEVICE_COMPLETION_OR_OPERAND'
    probe._restore();assert runtime.retire_generation is original


@pytest.mark.parametrize('raw',['false',0,None])
def test_history_is_not_enabled_by_untyped_boolean_values(tmp_path,raw):
    with pytest.raises(ValueError,match='history'):
        RequestProfiler(SimpleNamespace(speculator=None),tmp_path,{},enabled=False,window_history=raw)
