# SPDX-License-Identifier: Apache-2.0
import copy

import pytest
import torch

from tools.p7x_graph_repair4_target import FullForwardCheckpointer, _snapshot, _snapshot_value
from tools.p7x_graph_repair5_target import case_plan, sample_identity
from tools.p7x_graph_repair37_glm_target import (
    CP_ORIGIN, CP_PROFILE, INDEXER, PROFILE, SFA, SFA_CP,
    component_contract, isolation_errors, validate_components, validate_record,
)
from tools.p7x_graph_repair38_glm_numeric import build_kwargs as old_kwargs
from tools.p7x_graph_repair55_glm_cp_numeric import build_kwargs, component_keys


def test_named_cp_profile_preserves_old_cases_and_changes_only_declared_diagnostic():
    old = case_plan(PROFILE)
    new = case_plan(CP_PROFILE)
    assert len(old) == len(new) == 14
    assert old[0]["padded"] == 1 and new[0]["padded"] == 2
    assert [(c["scenario"], c["ends"], c["query_width"]) for c in old] == [
        (c["scenario"], c["ends"], c["query_width"]) for c in new]
    for arm in ("OFF", "ON"):
        baseline, current = old_kwargs(arm, 16), build_kwargs(arm, 16)
        assert baseline["async_scheduling"] is False and current["async_scheduling"] is True
        assert current["enable_prefix_caching"] and current["enable_chunked_prefill"]
        assert current["additional_config"]["enable_dsa_cp"]
        assert current["additional_config"]["enable_flashcomm1"]
        assert current["compilation_config"]["cudagraph_capture_sizes"] == [16, 32, 48]
        for key in ("model", "speculative_config", "tensor_parallel_size", "max_model_len"):
            assert baseline[key] == current[key]
    with pytest.raises(ValueError):
        component_contract(1)


def make_record(rank):
    specs = component_contract(True)
    rows = [dict(name=f"target.{kind}.{i}", metadata_class=kind, global_group_id=0,
                 caches=tuple(torch.zeros(2, 128, 1, dim, dtype=torch.bfloat16)
                              for _, dim in specs[kind]))
            for kind, count in ((SFA_CP, 78), (INDEXER, 21)) for i in range(count)]
    kv = validate_components(rows, cp=True)
    slots = torch.tensor(list(range(151, 160)) + [-1] * 9, dtype=torch.int32)
    table = torch.tensor([[1], [0]], dtype=torch.int32)
    case = dict(case_plan(CP_PROFILE)[3], step=0)
    layers = {}
    for row in rows:
        kind = row["metadata_class"]
        metadata = dict(metadata_class=kind, num_actual_tokens=9, block_size=128,
            seq_lens=torch.tensor([32, 1], dtype=torch.int32), declared_exact_lengths=[32, 1],
            cum_query_lens=torch.tensor([9, 18], dtype=torch.int32),
            slot_mapping=slots.clone(), block_table=table)
        if kind == SFA_CP:
            # Independent explicit token-owner intersections on CPU.
            begin, end = rank * 2, (rank + 1) * 2
            shard = set(range(begin, end))
            cumulative, query, keys = 0, [], []
            for owner, exact in ((range(9), 32), (range(9, 18), 1)):
                owned = sorted(shard.intersection(owner))
                cumulative += len(owned)
                query.append(cumulative)
                keys.append(max(0, exact - (owner.stop - 1 - owned[-1])) if owned else 0)
            padded_slots = torch.cat([slots, torch.full((14,), -1, dtype=torch.int32)])
            metadata["slot_mapping"] = padded_slots
            metadata["dsa_cp_context"] = dict(num_tokens=18, num_tokens_pad=32,
                local_start=begin, local_end=min(end, 9), local_end_with_pad=end,
                slot_mapping_cp=padded_slots[begin:end],
                actual_seq_lengths_query=torch.tensor(query, dtype=torch.int32),
                actual_seq_lengths_key=torch.tensor(keys, dtype=torch.int32))
        else:
            # The actual legacy-CP indexer also owns a TP-aligned Full view.
            metadata["slot_mapping"] = torch.cat([slots, torch.full((14,), -1, dtype=torch.int32)])
        layers[row["name"]] = metadata
    inputs = dict(input_ids=torch.full((18,), 17, dtype=torch.int32),
        positions=torch.tensor(list(range(23, 32)) + [0] * 9, dtype=torch.int64),
        query_start_loc=torch.tensor([0, 9, 18], dtype=torch.int32),
        seq_lens=torch.tensor([32, 1], dtype=torch.int32),
        is_padding=torch.tensor([False] * 9 + [True] * 9), req_ids=["row-0"],
        num_reqs=1, num_tokens=9, descriptor=(18, 2, 9, 9),
        layers=layers, target_layer_names=list(layers), completed_cp_rank=rank)
    probe = FullForwardCheckpointer(fixture_id="host", max_bytes=200 * 1024**2, max_records=1)
    hidden = torch.ones((18, 2), dtype=torch.bfloat16)

    def forward():
        for tensor in kv.values():
            tensor[1, 23:32].fill_(1)
        return hidden

    probe.run(forward, inputs=inputs, kv_access=lambda: kv,
        write_slots={key: slots for key in kv}, synchronize=lambda: None,
        origin=CP_ORIGIN, block_ids={key: torch.tensor([0, 1], dtype=torch.int64) for key in kv},
        declared_reads={key: dict(table=table, lengths=[32, 1]) for key in kv})
    checkpoint = probe.records[0]
    record = dict(identity=sample_identity(case, "host"), generation=0, checkpoint=checkpoint,
        hidden=hidden[:9].clone(), logits=torch.ones(9, 4),
        block_owners={0: ("padding", 0), 1: ("row-0", 0)},
        outside_before={"host": "same"}, outside_after={"host": "same"},
        target_post_forward_inputs=checkpoint["inputs"],
        target_metadata_owner_after_target={"cp-owner": 1},
        target_metadata_owner_after_draft={"cp-owner": 1})
    record["target_after_draft"] = dict(root_same=True, outside=record["outside_after"],
        kv=checkpoint["kv_after"], inputs=checkpoint["inputs"],
        draft_slots=torch.arange(160, 168, dtype=torch.int64),
        draft_positions=torch.arange(32, 40, dtype=torch.int64),
        draft_query=torch.tensor([0, 8], dtype=torch.int32))
    return record, rows


@pytest.fixture(scope="module")
def record():
    return make_record(0)[0]


@pytest.mark.parametrize("rank", [0, 4, 8, 15])
def test_completed_cp_checkpoint_checks_all_177_components_and_full_writes(rank):
    record, rows = make_record(rank)
    assert len(validate_record(record, cp_rank=rank)) == 99
    assert len(component_keys(record)) == 177
    assert isolation_errors(record) == []
    with pytest.raises(ValueError):
        validate_record(record)  # Old ABI never accepts CP by inferred shape.
    with pytest.raises(ValueError):
        validate_components(rows)


@pytest.mark.parametrize("damage", ["rank", "context", "stale_exact", "slot", "padding_write",
                                    "indexer_padding", "metadata_slot_dtype",
                                    "component", "owner", "target_metadata", "input_dtype"])
def test_cp_status_cannot_hide_wrong_rank_metadata_or_isolation(record, damage):
    bad = copy.deepcopy(record)
    inputs = _snapshot_value(bad["checkpoint"]["inputs"])
    name = next(key for key, value in inputs["layers"].items() if value["metadata_class"] == SFA_CP)
    context = inputs["layers"][name]["dsa_cp_context"]
    if damage == "rank":
        inputs["completed_cp_rank"] = 1
    elif damage == "context":
        context.pop("local_start")
    elif damage == "stale_exact":
        context["actual_seq_lengths_key"][0] += 1
    elif damage == "slot":
        context["slot_mapping_cp"][0] += 1
    elif damage == "padding_write":
        inputs["layers"][name]["slot_mapping"][-1] = 0
    elif damage == "indexer_padding":
        indexer = next(value for value in inputs["layers"].values() if value["metadata_class"] == INDEXER)
        indexer["slot_mapping"][-1] = 0
    elif damage == "metadata_slot_dtype":
        inputs["layers"][name]["slot_mapping"] = inputs["layers"][name]["slot_mapping"].long()
    elif damage == "component":
        bad["checkpoint"]["kv_keys"].pop()
    elif damage == "owner":
        bad["target_metadata_owner_after_draft"] = {"cp-owner": 2}
    elif damage == "target_metadata":
        after = _snapshot_value(bad["target_after_draft"]["inputs"])
        after["layers"][name]["dsa_cp_context"]["actual_seq_lengths_key"][0] += 1
        bad["target_after_draft"]["inputs"] = _snapshot(after, [200 * 1024**2])
    else:
        inputs["input_ids"] = inputs["input_ids"].long()
    bad["checkpoint"]["inputs"] = _snapshot(inputs, [200 * 1024**2])
    with pytest.raises(ValueError):
        validate_record(bad, cp_rank=0)
        assert not isolation_errors(bad)
