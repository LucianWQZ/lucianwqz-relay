# SPDX-License-Identifier: Apache-2.0
"""Matched eager control keeps the real topology and completion-lane owner."""
from dataclasses import replace
from types import SimpleNamespace as N

import pytest

from tests.ut.spec_decode.test_draft_window import _attention_group, _block_tables, _p2_vllm_config
from tests.ut.spec_decode.test_draft_window_graph_characterization import _runtime_context
from vllm_ascend.ascend_config import AscendConfig, validate_draft_window_parallel_eager_review
from vllm_ascend.worker.v2.spec_decode import draft_window as source
from vllm_ascend.worker.v2.spec_decode.draft_window_async import DraftWindowEagerAsyncPool


def config(enabled=True, method="dspark", tp=16):
    vc = _p2_vllm_config(configured_k=8, additional_config=dict(
        draft_window_size=1024, draft_window_parallel_eager_review=enabled))
    vc.speculative_config.method = method
    vc.speculative_config.draft_parallel_config = N(tensor_parallel_size=tp)
    vc.parallel_config.tensor_parallel_size = tp
    vc.compilation_config.cudagraph_mode.name = "FULL_DECODE_ONLY"
    return vc


@pytest.fixture(autouse=True)
def experimental_gate(monkeypatch):
    monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH", "1")
    monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE", "0")


def runtime(tp=16, rank=0, **changes):
    return _runtime_context(graph_mode="NONE", tensor_parallel_size=tp, tensor_parallel_rank=rank,
        async_scheduling=True, sequence_parallel=True, dsa_context_parallel=True,
        flashcomm=True, prefix_caching=True, **changes)


def capability(monkeypatch, vc, context, *, tables=None, groups=None):
    monkeypatch.setattr(source, "build_draft_window_runtime_context", lambda *args: context)
    return source.build_draft_window_source_capability(
        policy=source.resolve_draft_window_policy(requested_window_size=1024,
            method=vc.speculative_config.method, target_model_type="test_dense_target"),
        runtime_route=vc.speculative_config.method,
        attn_groups=groups or [[_attention_group()]], block_tables=tables or _block_tables(),
        causal=False, vllm_config=vc)


@pytest.mark.parametrize("raw,enabled", [(False, False), ("false", False), (True, True), ("true", True)])
def test_real_schema_and_early_reader_agree(raw, enabled):
    parsed = AscendConfig(sparse_kv_offload_config=None, draft_window_parallel_eager_review=raw)
    assert parsed.draft_window_parallel_eager_review is enabled
    assert validate_draft_window_parallel_eager_review(config(raw)) is enabled


@pytest.mark.parametrize("enabled", [False, "false"])
def test_default_route_still_rejects_executor_features(monkeypatch, enabled):
    with pytest.raises(NotImplementedError, match="SP|DSA|Async|async|sequence"):
        capability(monkeypatch, config(enabled), runtime())


@pytest.mark.parametrize("method", ["dspark", "dflash"])
@pytest.mark.parametrize("tp", [2, 4, 16])
def test_actual_rank_and_all_executor_features_survive_source_construction(monkeypatch, method, tp):
    vc = config(method=method, tp=tp)
    context = runtime(tp=tp, rank=tp - 1)
    tables = _block_tables(row_width=32)
    cap = capability(monkeypatch, vc, context, tables=tables)
    topology = cap.eager_topology_fingerprint
    assert topology.tensor_parallel_size == tp and topology.tensor_parallel_rank == tp - 1
    assert topology.graph_mode == "NONE"
    for name in ("async_scheduling", "sequence_parallel", "dsa_context_parallel", "flashcomm", "prefix_caching"):
        assert getattr(topology, name) is True
    assert topology.parallel_read_semantics == "replicated"  # Dense Draft, independent of Target DSA-CP.
    assert cap.full_source.references_input_block_table(0, tables.input_block_tables[0])
    assert cap.inventory.require_single_group_direct_prefix().kernel_block_size == 64
    pool = DraftWindowEagerAsyncPool(capability=cap, topology_template=topology, capacity=2)
    assert pool.capacity == 2 and pool._runtimes[0] is not pool._runtimes[1]
    assert cap.eager_topology_fingerprint is topology


@pytest.mark.parametrize("damage", ["graph_draft", "dynamic", "method", "window", "draft_tp", "tp",
    "dp", "pcp", "target_mode", "gate", "observer"])
def test_review_rejects_undeclared_configuration_before_source_allocation(monkeypatch, damage):
    vc = config()
    if damage == "graph_draft":
        vc.speculative_config.enforce_eager = False
    elif damage == "dynamic":
        vc.speculative_config.uses_dynamic_speculative_decoding = lambda: True
    elif damage == "method":
        vc.speculative_config.method = "eagle3"
    elif damage == "window":
        vc.additional_config["draft_window_size"] = 512
    elif damage == "draft_tp":
        vc.speculative_config.draft_parallel_config.tensor_parallel_size = 8
    elif damage == "tp":
        vc.parallel_config.tensor_parallel_size = True
    elif damage == "dp":
        vc.parallel_config.data_parallel_size = 2
    elif damage == "pcp":
        vc.parallel_config.prefill_context_parallel_size = 2
    elif damage == "target_mode":
        vc.compilation_config.cudagraph_mode.name = "NONE"
    elif damage == "gate":
        monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH", "0")
    else:
        monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE", "1")
    with pytest.raises(ValueError):
        validate_draft_window_parallel_eager_review(vc)


@pytest.mark.parametrize("rank", [-1, 16, False, 0.0])
def test_actual_invalid_rank_is_not_hidden_by_source_normalization(monkeypatch, rank):
    with pytest.raises((ValueError, NotImplementedError), match="rank"):
        capability(monkeypatch, config(), runtime(rank=rank))


def test_source_rejects_real_cp_sharding_even_if_configuration_says_single_cp(monkeypatch):
    with pytest.raises(NotImplementedError, match="topology"):
        capability(monkeypatch, config(), replace(runtime(), decode_context_parallel_size=2))


def test_real_source_geometry_and_borrowed_full_owner_are_still_validated(monkeypatch):
    tables = _block_tables()
    tables.kernel_block_sizes = [96]
    with pytest.raises((ValueError, RuntimeError, NotImplementedError)):
        capability(monkeypatch, config(), runtime(), tables=tables)

    tables = _block_tables()
    cap = capability(monkeypatch, config(), runtime(), tables=tables)
    tables.input_block_tables[0] = tables.input_block_tables[0].clone()
    with pytest.raises(RuntimeError, match="replaced"):
        cap.full_source.validate_owner_bindings()


def test_real_config_factory_applies_review_before_admission(monkeypatch):
    import vllm_ascend.ascend_config as module
    monkeypatch.setattr(module.SparseKVOffloadConfig, "from_additional_config", lambda *args: None)
    monkeypatch.setattr(module.KVPPConfig, "from_vllm_config", lambda *args: module.KVPPConfig())
    monkeypatch.setattr(module.AscendConfig, "derive_and_validate", lambda *args: None)
    monkeypatch.setattr(module.FinegrainedTPConfig, "_validate_preconditions", lambda *args: None)
    monkeypatch.setattr(module.XliteGraphConfig, "_validate_preconditions", lambda *args: None)
    vc = config()
    vc.additional_config["refresh"] = True
    assert module.init_ascend_config(vc).draft_window_parallel_eager_review is True
    vc.speculative_config.draft_parallel_config.tensor_parallel_size = 1
    with pytest.raises(ValueError, match="matching actual Target/Draft TP"):
        module.init_ascend_config(vc)
