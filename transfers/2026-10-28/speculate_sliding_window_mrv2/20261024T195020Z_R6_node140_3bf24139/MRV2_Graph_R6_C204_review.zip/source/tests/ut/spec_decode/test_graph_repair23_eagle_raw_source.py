# SPDX-License-Identifier: Apache-2.0
"""Eagle AR reads canonical raw state rows, not the gathered attention view."""
from types import SimpleNamespace

import numpy as np
import pytest
import torch

from tools.p7x_graph_repair23_eagle_target import EagleControlledTarget, ControlledTarget, case_plan


@pytest.mark.parametrize("damage", [None, "missing_block", "wrong_units", "wrong_request_row"])
def test_controlled_stage_initializes_real_raw_source_before_ar_slot_recompute(monkeypatch, damage):
    view = torch.zeros((4, 32), dtype=torch.int32)
    raw = torch.zeros_like(view)
    slots = torch.tensor([[9468, 9469, 9470, 9471]], dtype=torch.int32)
    writes, calls = [], []

    def append(index, groups, overwrite):
        assert overwrite is True
        writes.append((index, groups[0]))

    def apply():
        calls.append("apply staged canonical source")
        for row, values in writes:
            raw[row, :len(values)] = torch.tensor(values, dtype=torch.int32)

    tables = SimpleNamespace(input_block_tables=[view],
                             block_sizes=[128],
                             kernel_block_sizes=[128],
                             blocks_per_kv_block=[1],
                             append_block_ids=append,
                             apply_staged_writes=apply,
                             block_tables=[SimpleNamespace(gpu=raw)])
    owner = object.__new__(EagleControlledTarget)
    owner.runner = SimpleNamespace(block_tables=tables)
    owners = {0: ("padding", 0), **{65 + i: ("row-0", i) for i in range(10)}}
    batch = SimpleNamespace(num_reqs=1, idx_mapping_np=np.array([0], dtype=np.int64))
    if damage == "missing_block": owners.pop(74)
    if damage == "wrong_units": tables.block_sizes = [256]
    if damage == "wrong_request_row": batch.idx_mapping_np[0] = 2

    def base_stage(self, case):
        view[0, :10] = torch.arange(65, 75, dtype=torch.int32)
        return "descriptor", batch, owners

    monkeypatch.setattr(ControlledTarget, "_stage", base_stage)
    if damage is not None:
        with pytest.raises(ValueError): owner._stage(case_plan()[0])
        assert not calls and not writes
        return
    before_slots = slots.clone()
    result = owner._stage(case_plan()[0])
    # This source distinction produced actual slot0 in C78; the canonical
    # absolute position1152 maps to physical block74, slot9472.
    pos = 1152
    assert int(raw[0, pos // 128]) * 128 + pos % 128 == 9472
    assert torch.equal(raw[0, :10], view[0, :10])
    assert torch.equal(slots, before_slots)
    assert calls == ["apply staged canonical source"] and result[1] is batch
