# SPDX-License-Identifier: Apache-2.0
"""Explicit TP review retains default rejection, real ranks and source guards."""
from dataclasses import replace
from types import SimpleNamespace

import pytest

from tests.ut.spec_decode.test_draft_window import _attention_group, _block_tables, _p2_policy
from tests.ut.spec_decode.test_draft_window_graph_characterization import _runtime_context
from vllm_ascend.ascend_config import AscendConfig, validate_draft_window_replicated_tp_review
from vllm_ascend.worker.v2.spec_decode.draft_window import (
    build_draft_window_inventory,
    _runtime_capability_failures,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import (
    validate_base_graph_characterization_context,
    validate_parallel_graph_characterization_context,
)


def config(raw=True, tp=2):
    return SimpleNamespace(
        additional_config=dict(draft_window_size=1024, draft_window_graph_replicated_tp_review=raw),
        speculative_config=SimpleNamespace(method="dspark",
                                           enforce_eager=False,
                                           uses_dynamic_speculative_decoding=lambda: False,
                                           draft_parallel_config=SimpleNamespace(tensor_parallel_size=tp)),
        parallel_config=SimpleNamespace(tensor_parallel_size=tp),
        compilation_config=SimpleNamespace(cudagraph_mode=SimpleNamespace(name="FULL_DECODE_ONLY")),
    )


@pytest.fixture(autouse=True)
def gate(monkeypatch):
    monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH", "1")
    monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE", "0")


@pytest.mark.parametrize("raw,expected", [(False, False), ("false", False), (True, True), ("true", True)])
def test_real_schema_and_early_reader_agree(raw, expected):
    parsed = AscendConfig(sparse_kv_offload_config=None, draft_window_graph_replicated_tp_review=raw)
    assert parsed.draft_window_graph_replicated_tp_review is expected
    assert validate_draft_window_replicated_tp_review(config(raw)) is expected


@pytest.mark.parametrize("raw", [False, "false"])
def test_default_profile_keeps_tp2_rejected(raw):
    with pytest.raises(NotImplementedError, match="TP=1"):
        validate_parallel_graph_characterization_context(
            _runtime_context(tensor_parallel_size=2, graph_mode="FULL_DECODE_ONLY"), config(raw))


@pytest.mark.parametrize("tp", [2, 4, 16])
def test_every_actual_rank_is_retained_and_invalid_rank_rejected(tp):
    for rank in range(tp):
        context = _runtime_context(tensor_parallel_size=tp, tensor_parallel_rank=rank, graph_mode="FULL_DECODE_ONLY")
        assert validate_parallel_graph_characterization_context(context, config(tp=tp))
        assert context.tensor_parallel_size == tp and context.tensor_parallel_rank == rank
        with pytest.raises(NotImplementedError, match="TP=1"):
            validate_base_graph_characterization_context(context)
    for rank in (-1, tp, False, 0.0):
        with pytest.raises(ValueError, match="integer TP rank"):
            validate_parallel_graph_characterization_context(
                _runtime_context(tensor_parallel_size=tp, tensor_parallel_rank=rank, graph_mode="FULL_DECODE_ONLY"),
                config(tp=tp))
    with pytest.raises(NotImplementedError, match=f"TP={tp}"):
        validate_parallel_graph_characterization_context(_runtime_context(tensor_parallel_size=1), config(tp=tp))


@pytest.mark.parametrize(
    "field", ["async_scheduling", "sequence_parallel", "flashcomm", "dsa_context_parallel"])
def test_review_admits_service_features_but_base_route_remains_closed(field):
    context = _runtime_context(tensor_parallel_size=2, graph_mode="FULL_DECODE_ONLY", **{field: True})
    assert validate_parallel_graph_characterization_context(context, config()) is True
    with pytest.raises(NotImplementedError):
        validate_base_graph_characterization_context(
            _runtime_context(graph_mode="FULL_DECODE_ONLY", **{field: True}))


def test_review_rejects_wrong_method_world_mode_gate_and_shared_observer(monkeypatch):
    vc = config()
    vc.speculative_config.method = "eagle"
    with pytest.raises(ValueError, match="static parallel"):
        validate_draft_window_replicated_tp_review(vc)
    vc = config()
    vc.speculative_config.draft_parallel_config.tensor_parallel_size = 1
    with pytest.raises(ValueError, match="matching actual Target/Draft TP"):
        validate_draft_window_replicated_tp_review(vc)
    vc = config()
    vc.compilation_config.cudagraph_mode.name = "FULL"
    with pytest.raises(ValueError, match="FULL_DECODE_ONLY"):
        validate_draft_window_replicated_tp_review(vc)
    monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE", "1")
    with pytest.raises(ValueError, match="observer OFF"):
        validate_draft_window_replicated_tp_review(config())
    monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH_OBSERVE", "0")
    monkeypatch.setenv("VLLM_ASCEND_EXPERIMENTAL_DRAFT_WINDOW_GRAPH", "0")
    with pytest.raises(ValueError, match="experimental Graph gate"):
        validate_draft_window_replicated_tp_review(config())


def test_inventory_keeps_source_geometry_and_actual_rank_contract():
    context = _runtime_context(tensor_parallel_size=2, tensor_parallel_rank=1, graph_mode="NONE")

    def inventory(**extra):
        return build_draft_window_inventory(policy=_p2_policy("dspark"),
                                            runtime_route="dspark",
                                            attn_groups=[[_attention_group()]],
                                            block_tables=_block_tables(),
                                            causal=False,
                                            runtime_context=context,
                                            **extra)

    assert any("TP=2" in message for message in _runtime_capability_failures(context))
    accepted = inventory(allow_replicated_tp_graph_source=True)
    assert accepted.groups and not accepted.groups[0].capability_failures
    with pytest.raises(NotImplementedError, match="TP=2"):
        inventory().require_single_group_direct_prefix()
    malformed = replace(context, tensor_parallel_rank=False)
    assert any("integer rank" in message
               for message in _runtime_capability_failures(malformed, allow_replicated_tp_graph_source=True))
    assert any("DP=2" in message for message in _runtime_capability_failures(replace(context, data_parallel_size=2),
                                                                             allow_replicated_tp_graph_source=True))


def test_real_factory_applies_review_admission(monkeypatch):
    import vllm_ascend.ascend_config as module
    monkeypatch.setattr(module.SparseKVOffloadConfig, "from_additional_config", lambda *a: None)
    monkeypatch.setattr(module.KVPPConfig, "from_vllm_config", lambda *a: module.KVPPConfig())
    monkeypatch.setattr(module.AscendConfig, "derive_and_validate", lambda *a: None)
    monkeypatch.setattr(module.FinegrainedTPConfig, "_validate_preconditions", lambda *a: None)
    monkeypatch.setattr(module.XliteGraphConfig, "_validate_preconditions", lambda *a: None)
    vc = config()
    vc.additional_config["refresh"] = True
    assert module.init_ascend_config(vc).draft_window_graph_replicated_tp_review is True
    vc.speculative_config.draft_parallel_config.tensor_parallel_size = 1
    with pytest.raises(ValueError, match="matching actual Target/Draft TP"):
        module.init_ascend_config(vc)


@pytest.mark.parametrize("tp", [0, 1, 3, 8, True, 4.0])
def test_review_refuses_undeclared_or_noninteger_topology(tp):
    with pytest.raises(ValueError, match="matching actual Target/Draft TP"):
        validate_draft_window_replicated_tp_review(config(tp=tp))


@pytest.mark.parametrize("tp", [4, 16])
def test_rank_local_source_geometry_is_not_divided_or_masked_by_review(tp):
    context = _runtime_context(tensor_parallel_size=tp, tensor_parallel_rank=tp-1, graph_mode="NONE")
    tables = _block_tables()
    accepted = build_draft_window_inventory(policy=_p2_policy("dspark"), runtime_route="dspark",
        attn_groups=[[_attention_group()]], block_tables=tables, causal=False, runtime_context=context,
        allow_replicated_tp_graph_source=True)
    assert not accepted.groups[0].capability_failures
    assert context.tensor_parallel_size == tp and context.tensor_parallel_rank == tp-1
    assert any(f"TP={tp}" in item for item in _runtime_capability_failures(context))
