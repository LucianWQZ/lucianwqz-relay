"""The committed runner must boot from its script path without shadowing stdlib."""

import json
import os
import subprocess
import sys
from pathlib import Path


def test_direct_runner_imports_torch_and_executes_host_case(tmp_path):
    source = Path(__file__).resolve().parents[3]
    plan = tmp_path / "plan.json"
    plan.write_text(
        json.dumps(
            {
                "schema": "host-entrypoint-fixture",
                "publication_status": "VERIFIED",
                "run_id": "host-bootstrap",
                "commit": "host",
                "tree": "host",
                "cases": {
                    "P0": {
                        "argv": [sys.executable, "-c", "print('host bootstrap ok')"],
                        "timeout_seconds": 10,
                        "resource_policy": {"minimum_launch_free_bytes": 0},
                    }
                },
            }
        )
    )
    env = os.environ.copy()
    env["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    result = subprocess.run(
        [sys.executable, str(source / "tools/p7x_graph_repair6_runner.py"),
         "--plan", str(plan), "--case-id", "P0", "--output", str(tmp_path / "out")],
        env=env,
        cwd=tmp_path,
        capture_output=True,
        text=True,
        timeout=90,
    )
    assert result.returncode == 0, result.stderr
    record = json.loads((tmp_path / "out/P0/runner-result.json").read_text())
    assert record["status"] == "SCOPED_COMMANDS_ACCEPTED"
