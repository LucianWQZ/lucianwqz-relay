# SPDX-License-Identifier: Apache-2.0
"""CPU HTTP routing and durable all-replica evidence; not DP model tests."""
import asyncio
import copy
import json
from pathlib import Path

import pytest

from tools.p7x_graph_repair33_service import request, service_device_count
from tools.p7x_graph_repair69_qwen36_dp_service import (
    EXTENSION, TARGET, export_identity, read_all_exports, server_argv, validate_groups,
)


def exported(tmp_path):
    nonce = 'a'*32
    root = tmp_path/nonce
    root.mkdir()
    (root/'attempt-nonce').write_text(nonce)
    for dp in range(2):
        for tp in range(4):
            export_identity(dict(dp_rank=dp,tp_rank=tp,nonce=nonce,pid=100+dp*4+tp),root,nonce)
    return root,nonce


def test_each_replica_requires_its_own_exclusive_worker_file(tmp_path):
    root,nonce = exported(tmp_path)
    rows = read_all_exports(root,nonce)
    assert [(r['dp_rank'],r['tp_rank']) for r in rows] == [(d,t) for d in range(2) for t in range(4)]
    assert len({r['pid'] for r in rows}) == 8
    with pytest.raises(FileExistsError):
        export_identity(dict(dp_rank=0,tp_rank=0,nonce=nonce,pid=999),root,nonce)


@pytest.mark.parametrize('damage',['first_replica_only','missing','extra','nonce','coordinate','directory'])
def test_saved_exports_reject_partial_dp_and_contradictions(tmp_path,damage):
    root,nonce = exported(tmp_path)
    if damage in ('first_replica_only','missing'):
        for path in (list(root.glob('dp-1-*.json')) if damage == 'first_replica_only' else [root/'dp-1-tp-3.json']):
            path.unlink()
    elif damage == 'extra': (root/'dp-2-tp-0.json').write_text('{}')
    elif damage in ('nonce','coordinate'):
        path=root/'dp-1-tp-2.json';row=json.loads(path.read_text())
        row.update(nonce='b'*32) if damage == 'nonce' else row.update(tp_rank=3)
        path.write_text(json.dumps(row))
    else:
        (root/'attempt-nonce').write_text('b'*32)
        with pytest.raises(ValueError):
            export_identity(dict(dp_rank=1,tp_rank=2,nonce=nonce,pid=999),root,nonce)
        return
    with pytest.raises(ValueError):read_all_exports(root,nonce)


def test_explicit_model_tp4_dp2_uses_eight_devices_without_claiming_tp8():
    assert service_device_count(4,2) == 8 and service_device_count(16,1) == 16
    argv=server_argv('/actual/python',18141,'model','G_OFF',worker_provenance=True)
    assert argv[argv.index('serve')+1] == str(TARGET)
    assert argv[argv.index('--tensor-parallel-size')+1] == '4'
    assert argv[argv.index('--data-parallel-size')+1] == '2'
    assert argv[argv.index('--worker-extension-cls')+1] == EXTENSION
    assert json.loads(argv[argv.index('--additional-config')+1]) == {}
    assert json.loads(argv[argv.index('--speculative-config')+1])['num_speculative_tokens'] == 7
    assert json.loads(argv[argv.index('--compilation-config')+1])['cudagraph_capture_sizes'] == [8,16,32]
    for tp,dp in [(True,1),(4,True),(8,1),(16,2),(4,3)]:
        with pytest.raises(ValueError):service_device_count(tp,dp)
    on=server_argv('/python',18141,'model','G_ON',worker_provenance=True)
    assert json.loads(on[on.index('--additional-config')+1]) == dict(
        draft_window_size=1024,draft_window_graph_replicated_tp_review=True)
    assert on[on.index('--data-parallel-size')+1]=='2'
    with pytest.raises(ValueError):server_argv('/python',18141,'model','E_ON',worker_provenance=True)


def test_real_absolute_cli_bootstraps_before_asyncio_bisect_import(tmp_path):
    import subprocess
    import sys
    import tools.p7x_graph_repair69_qwen36_dp_service as module
    result=subprocess.run([sys.executable,module.__file__,'--help'],cwd=tmp_path,
                          capture_output=True,text=True,timeout=30)
    assert result.returncode == 0,result.stderr
    assert '--admission' in result.stdout and '--expected-sha' in result.stdout


@pytest.mark.parametrize('damage',['single_replica','overlength','token','budget','duplicate'])
def test_request_plan_never_silently_skips_replica_or_exceeds_model(damage):
    group=dict(label='short',max_tokens=256,prompts=[dict(prompt_token_ids=[17]*257) for _ in range(2)])
    validate_groups([group]);groups=[copy.deepcopy(group)]
    if damage == 'single_replica':groups[0]['prompts'].pop()
    elif damage == 'overlength':groups[0]['prompts'][0]['prompt_token_ids']=[17]*4096
    elif damage == 'token':groups[0]['prompts'][0]['prompt_token_ids'][0]=True
    elif damage == 'budget':groups[0]['max_tokens']=16
    else:groups.append(copy.deepcopy(group))
    with pytest.raises(ValueError):validate_groups(groups)


def test_real_http_header_routes_each_request_and_saved_client_record_agrees():
    from aiohttp import ClientSession,web
    from tests.ut.spec_decode.test_graph_repair33_service import stream
    async def run():
        observed=[]
        async def respond(incoming):
            observed.append(incoming.headers['X-data-parallel-rank'])
            response=web.StreamResponse(headers={'Content-Type':'text/event-stream'})
            await response.prepare(incoming)
            for row in stream():
                await response.write(('data: '+json.dumps(dict(row['data'],model='model'))+'\n\n').encode())
                await asyncio.sleep(0)
            await response.write(b'data: [DONE]\n\n');await response.write_eof();return response
        application=web.Application();application.router.add_post('/v1/completions',respond)
        runner=web.AppRunner(application);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0)
        try:
            await site.start();port=site._server.sockets[0].getsockname()[1]
            async with ClientSession() as session:
                for dp in (0,1):
                    result=await request(session,f'http://127.0.0.1:{port}/v1/completions',model='model',
                                         prompt=[7,8],output=3,data_parallel_rank=dp)
                    assert result['routing_headers'] == {'X-data-parallel-rank':str(dp)}
                    assert result['summary']['token_ids'] == [10,11,12]
            assert observed == ['0','1']
        finally:await runner.cleanup()
    asyncio.run(run())


@pytest.mark.parametrize('damage',[None,'replica_size','bool_rank','snapshot_pid','window','target_group','replaced',
                                   'global_rank','ep_size','ep_roster','dp_roster','tp_roster','missing_shard','local_experts','weight_shard'])
@pytest.mark.parametrize('arm',['G_OFF','G_ON'])
def test_complete_saved_rank_geometry_and_campaign_binding_remain_strict(tmp_path,monkeypatch,damage,arm):
    import tools.p7x_graph_repair69_qwen36_dp_service as module
    from tools.p7x_graph_repair21_rank import digest
    from tests.ut.spec_decode.test_graph_repair68_qwen36_dflash_anchor import evidence

    # Only file provenance is mocked; the real named eight-layer Draft and
    # 40-layer mixed Target validator is exercised, including damaged records.
    def host_identity(rows,**kwargs):
        row=rows[0]
        assert kwargs['nonce'] == row['nonce'] and kwargs['arm'] == arm
        return dict(pid=row['pid'],process_start_ticks=row['process_start_ticks'])
    monkeypatch.setattr(module,'validate_worker_identity',host_identity)
    nonce='c'*32;root=tmp_path/nonce;root.mkdir();(root/'attempt-nonce').write_text(nonce)
    base=evidence(arm=='G_ON')[0]['ranks']
    for dp in range(2):
        for tp in range(4):
            snapshot=copy.deepcopy(base[tp]);snapshot.update(pid=100+dp*4+tp,process_start_ticks='1234',
                window_provider_installed=arm=='G_ON',heavy_observer_enabled=False)
            row=dict(dp_rank=dp,tp_rank=tp,dp_size=2,tp_size=4,nonce=nonce,pid=snapshot['pid'],
                     engine_rank=snapshot['rank'],
                     global_rank=dp*4+tp,global_world=8,world_ranks=list(range(8)),
                     ep_rank=dp*4+tp,ep_world=8,ep_ranks=list(range(8)),ep_enabled=True,
                     tp_ranks=list(range(dp*4,dp*4+4)),dp_group_rank=dp,dp_ranks=[tp,tp+4],
                     target_moe_shards=[dict(name=f'layer-{i}',global_experts=256,local_experts=32,
                         ep_size=8,ep_rank=dp*4+tp,
                         weights={name:dict(shape=[32,128,256],dtype='torch.int8',device=f'npu:{tp}')
                                  for name in ('w13_weight','w2_weight')}) for i in range(40)],
                     process_start_ticks='1234',rank_snapshot=snapshot,
                     audit_tool=dict(path=module.__file__,sha256=digest(module.__file__)))
            if (dp,tp) == (1,3):
                if damage == 'replica_size':row['dp_size']=1
                elif damage == 'snapshot_pid':snapshot['pid']+=1
                elif damage == 'window':snapshot['window_size']=None if arm=='G_ON' else 1024
                elif damage == 'target_group':snapshot['qwen36_profile']['target_groups'].pop()
                elif damage == 'global_rank':row['global_rank']=0
                elif damage == 'ep_size':row['ep_world']=4
                elif damage == 'ep_roster':row['ep_ranks']=[7,6,5,4,3,2,1,0]
                elif damage == 'dp_roster':row['dp_ranks']=[2,6]
                elif damage == 'tp_roster':row['tp_ranks']=[0,1,2,3]
                elif damage == 'missing_shard':row['target_moe_shards'].pop()
                elif damage == 'local_experts':row['target_moe_shards'][0]['local_experts']=64
                elif damage == 'weight_shard':row['target_moe_shards'][0]['weights']['w2_weight']['shape'][0]=64
            export_identity(row,root,nonce)
    rows=read_all_exports(root,nonce)
    if damage == 'bool_rank':
        rows[0]['dp_rank']=False
        path=Path(rows[0]['durable_export']['path']);path.write_text(json.dumps({k:v for k,v in rows[0].items() if k!='durable_export'}))
        rows[0]['durable_export']['sha256']=digest(path)
    elif damage == 'replaced':rows[-1]['pid']+=999
    kwargs=dict(nonce=nonce,source=Path(module.__file__).parents[1],vllm_source='/unused',arm=arm)
    if damage is None:
        assert len(module.validate_workers(rows,**kwargs)['workers']) == 8
    else:
        with pytest.raises(ValueError):module.validate_workers(rows,**kwargs)


@pytest.mark.parametrize('damage',[None,'dummy_only','wrong_route','eager','peer_shape','truncated',
                                   'missing_suffix','short_suffix','nonhex_suffix','duplicate_internal'])
def test_routed_http_requests_require_real_non_dummy_graphs_on_all_peers(damage):
    from tools.p7x_graph_repair69_qwen36_dp_service import validate_dispatch
    from tools.p7x_graph_repair16_scheduler import phase_from_rows
    records=dict(groups=[dict(results=[dict(summary=dict(response_id=f'cmpl-dp{d}')) for d in range(2)])])
    rows=[]
    for dp in range(2):
        for tp in range(4):
            raw=dict(request_ids=[f'cmpl-dp{dp}-0-0123abcd'],computed=[100],scheduled=[1],prefill=[32],is_prefilling=[False])
            row_phases,batch_phase=phase_from_rows(raw)
            phase=dict(raw_cpu_rows=raw,row_phases=row_phases,batch_phase=batch_phase,returned=True,
                       start_ns=10,end_ns=30,requests=raw['request_ids'],window_materializations=[],
                       flags_after=dict(_draft_window_bypass_active=False,_draft_window_prefill_bypass_active=False),
                       manager_calls=[dict(role='draft:query',returned=True,mode='FULL',num_tokens=8,num_reqs=1,
                                           host_start_ns=11,host_return_ns=29)])
            rows.append(dict(dp_rank=dp,tp_rank=tp,proposal_phases=[phase],proposal_phases_truncated=False))
    if damage == 'dummy_only': rows[-1]['proposal_phases']=[]
    elif damage == 'wrong_route': records['groups'][0]['results'][1]['summary']['response_id']='cmpl-other'
    elif damage == 'eager': rows[-1]['proposal_phases'][0]['manager_calls']=[]
    elif damage == 'peer_shape':rows[-1]['proposal_phases'][0]['manager_calls'][0].update(num_tokens=16,num_reqs=2)
    elif damage == 'truncated':rows[-1]['proposal_phases_truncated']=True
    elif damage in ('missing_suffix','short_suffix','nonhex_suffix'):
        phase=rows[-1]['proposal_phases'][0]
        identity={'missing_suffix':'cmpl-dp1-0','short_suffix':'cmpl-dp1-0-abcd',
                  'nonhex_suffix':'cmpl-dp1-0-zzzzabcd'}[damage]
        phase['requests']=[identity];phase['raw_cpu_rows']['request_ids']=[identity]
    elif damage == 'duplicate_internal':
        extra=copy.deepcopy(rows[-1]['proposal_phases'][0])
        extra['requests']=['cmpl-dp1-0-87654321'];extra['raw_cpu_rows']['request_ids']=extra['requests']
        rows[-1]['proposal_phases'].append(extra)
    if damage is None: assert len(validate_dispatch(rows,records)['workers']) == 8
    else:
        with pytest.raises(ValueError):validate_dispatch(rows,records)


@pytest.mark.parametrize('damage',[None,'missing_replica','duplicate_global','same_device','management',
                                   'starttime','mapping','namespace','source','outside_execution'])
def test_complete_dp_device_join_uses_real_management_columns_and_exact_process_events(tmp_path,damage):
    from tools.p7x_graph_repair21_rank import digest
    from tools.p7x_graph_repair30_device_join import collect_association
    from tools.p7x_graph_repair69_qwen36_dp_service import validate_device_join

    # Host fixtures exercise the real association validator. They do not claim
    # eight devices or a model were executed by this unit test.
    source='a'*40;execution=dict(start_epoch=1,end_epoch=4);rows=[];associations=[]
    physicals=list(range(8,16));mapping=tmp_path/'mapping.json'
    mapping.write_text(json.dumps(dict(mapping_command=dict(rc=0,stdout='\n'.join(
        f'{p//2} {p%2} {p} {p} 0000:{p:02X}:00.0' for p in physicals)))))
    receipt=dict(phy_ids=physicals,host='node',boot_id='boot',namespace='ns',
                 mapping_evidence=dict(path=str(mapping),sha256=digest(mapping)))
    for rank,physical in enumerate(physicals):
        pid=201+rank;host_pid=601+rank;chip=[str(physical//2),str(physical%2)]
        worker=dict(rank=rank%4,pid=pid,process_start_ticks=str(999+rank),nspid=[str(pid)],hostname='node')
        rows.append(dict(global_rank=rank,rank_snapshot=worker,hostname='node',boot_id='boot',namespace='ns'))
        smi=tmp_path/f'smi-{rank}.txt';events=tmp_path/f'events-{rank}.jsonl'
        smi.write_text('| NPU Chip | Process id | Process name | Process memory(MB) | Process id in container |\n'
                       f'| {chip[0]} {chip[1]} | {host_pid} | model | 100 | {pid} |\n')
        event=dict(utc='1970-01-01T00:00:02+00:00',event='HEARTBEAT',candidate=source,node='node',
                   worker_processes=[dict(pid=pid,start_ticks=worker['process_start_ticks'])],
                   npu_observed_own_pids=[dict(host_pid=str(host_pid),container_pid=str(pid),board_chip=' '.join(chip))])
        events.write_text(json.dumps(event)+'\n')
        associations.append(collect_association(dict(worker,rank=rank),physical,chip,[smi],events,
                                                source_sha=source,execution=execution))
    if damage == 'missing_replica':associations=associations[:4]
    elif damage == 'duplicate_global':rows[-1]['global_rank']=0
    elif damage == 'same_device':physicals[-1]=physicals[0]
    elif damage == 'management':smi.write_text(smi.read_text().replace(str(host_pid),'9999'))
    elif damage == 'starttime':rows[-1]['rank_snapshot']['process_start_ticks']='old'
    elif damage == 'mapping':mapping.write_text('{}')
    elif damage == 'namespace':rows[-1]['namespace']='other'
    elif damage == 'source':source='b'*40
    elif damage == 'outside_execution':execution['start_epoch']=3
    if damage is None:
        assert validate_device_join(rows,associations,physicals,receipt,source_sha=source,execution=execution)['physical_devices']==physicals
    else:
        with pytest.raises((ValueError,KeyError)):
            validate_device_join(rows,associations,physicals,receipt,source_sha=source,execution=execution)


def test_external_checker_without_saved_invocation_rejects_with_explicit_evidence_error():
    from types import SimpleNamespace
    from tools.p7x_graph_repair69_qwen36_dp_service import check_external_saved
    with pytest.raises(ValueError,match='planned invocation'):
        check_external_saved(SimpleNamespace(planned=None,execution=None))


@pytest.mark.parametrize('damage',[None,'wrong_row','stale_epoch','missing_binding','duplicate_binding',
                                   'wrong_bucket','wrong_group','no_clip','nonzero_padding','peer_exact'])
def test_window_dp2_requires_current_rows_generation_and_real_graph_bucket(damage):
    from tools.p7x_graph_repair16_scheduler import phase_from_rows
    from tools.p7x_graph_repair69_qwen36_dp_service import validate_dispatch
    records=dict(groups=[dict(results=[dict(summary=dict(response_id=f'cmpl-dp{d}')) for d in range(2)])])
    rows=[]
    for dp in range(2):
        for tp in range(4):
            phases=[];bindings=[]
            for step in (1,2):
                raw=dict(request_ids=[f'cmpl-dp{dp}-0-0123abcd'],computed=[2100+step],scheduled=[1],
                         prefill=[2049],is_prefilling=[False])
                row_phases,batch_phase=phase_from_rows(raw)
                materialized=dict(requests=raw['request_ids'],row_phases=row_phases,actual=1,padded=2,
                    tp_size=4,tp_rank=tp,generation=step,epoch=step,exact=[1050+step,0],
                    window_starts=[1024],global_group_id=0)
                phases.append(dict(raw_cpu_rows=raw,row_phases=row_phases,batch_phase=batch_phase,returned=True,
                    start_ns=10,end_ns=30,requests=raw['request_ids'],window_materializations=[materialized],
                    flags_after=dict(_draft_window_bypass_active=False,_draft_window_prefill_bypass_active=False),
                    manager_calls=[dict(role='draft:query',returned=True,mode='FULL',num_tokens=16,num_reqs=2,
                                        host_start_ns=11,host_return_ns=29)]))
                bindings.append(dict(generation=step,epoch=step,tp_rank=tp,tp_size=4,
                                     global_group_id=0,capture_bucket=[2,16]))
            rows.append(dict(dp_rank=dp,tp_rank=tp,proposal_phases=phases,proposal_phases_truncated=False,
                             rank_snapshot=dict(window_graph_bindings=bindings)))
    row=rows[-1];value=row['proposal_phases'][-1]['window_materializations'][0]
    if damage=='wrong_row':value['requests']=['unrelated']
    elif damage=='stale_epoch':value['epoch']=1
    elif damage=='missing_binding':row['rank_snapshot']['window_graph_bindings'].pop()
    elif damage=='duplicate_binding':row['rank_snapshot']['window_graph_bindings'].append(copy.deepcopy(row['rank_snapshot']['window_graph_bindings'][-1]))
    elif damage=='wrong_bucket':row['rank_snapshot']['window_graph_bindings'][-1]['capture_bucket']=[1,8]
    elif damage=='wrong_group':row['rank_snapshot']['window_graph_bindings'][-1]['global_group_id']=1
    elif damage=='no_clip':
        for phase in row['proposal_phases']:phase['window_materializations'][0]['window_starts']=[0]
    elif damage=='nonzero_padding':value['exact'][1]=1
    elif damage=='peer_exact':value['exact'][0]+=1
    if damage is None:assert len(validate_dispatch(rows,records,window_on_review=True)['workers'])==8
    else:
        with pytest.raises(ValueError):validate_dispatch(rows,records,window_on_review=True)


@pytest.mark.parametrize('damage',[None,'baseline_generation','missing_active_generation','no_clip'])
def test_explicit_long_context_review_separates_continuing_prefill_from_current_window(damage):
    from tools.p7x_graph_repair16_scheduler import phase_from_rows
    from tools.p7x_graph_repair69_qwen36_dp_service import validate_dispatch
    records=dict(groups=[dict(results=[dict(summary=dict(response_id=f'cmpl-dp{d}')) for d in range(2)])])
    rows=[]
    for dp in range(2):
        for tp in range(4):
            phases=[]
            value=None
            for continuing in (True,False):
                raw=dict(request_ids=[f'cmpl-dp{dp}-0-0123abcd'],computed=[4096 if continuing else 37000],
                         scheduled=[4096 if continuing else 1],prefill=[36865],is_prefilling=[continuing])
                row_phases,batch_phase=phase_from_rows(raw)
                value=dict(requests=raw['request_ids'],row_phases=row_phases,actual=1,padded=2,
                    tp_size=4,tp_rank=tp,generation=1,epoch=1,exact=[32800,0],window_starts=[4224],global_group_id=15)
                phases.append(dict(raw_cpu_rows=raw,row_phases=row_phases,batch_phase=batch_phase,returned=True,
                    start_ns=10,end_ns=30,requests=raw['request_ids'],window_materializations=[] if continuing else [value],
                    flags_after=dict(_draft_window_bypass_active=False,_draft_window_prefill_bypass_active=False),
                    manager_calls=[dict(role='draft:query',returned=True,mode='FULL',num_tokens=16,num_reqs=2,
                                       host_start_ns=11,host_return_ns=29)]))
            if (dp,tp)==(1,3):
                if damage=='baseline_generation':phases[0]['window_materializations']=[copy.deepcopy(value)]
                elif damage=='missing_active_generation':phases[1]['window_materializations']=[]
                elif damage=='no_clip':value['window_starts']=[0]
            rows.append(dict(dp_rank=dp,tp_rank=tp,proposal_phases=phases,proposal_phases_truncated=False,
                rank_snapshot=dict(window_graph_bindings=[dict(generation=1,epoch=1,tp_rank=tp,tp_size=4,
                    global_group_id=15,capture_bucket=[2,16])])))
    with pytest.raises(ValueError):validate_dispatch(rows,records,window_on_review=True)
    if damage is None:assert len(validate_dispatch(rows,records,window_on_review=True,allow_continuing_prefill=True)['workers'])==8
    else:
        with pytest.raises(ValueError):validate_dispatch(rows,records,window_on_review=True,allow_continuing_prefill=True)


def test_long_model_context_is_explicit_and_does_not_widen_original_full8_profile():
    groups=[dict(label='fixed-long',max_tokens=256,prompts=[dict(prompt_token_ids=[100]*36865)]*2)]
    with pytest.raises(ValueError):validate_groups(groups)
    validate_groups(groups,max_model_len=40960)
    with pytest.raises(ValueError):validate_groups(groups,max_model_len=True)


@pytest.mark.parametrize('arm',['G_OFF','G_ON'])
def test_named_structural_swa_dp2_retains_model_and_method_specific_contract(arm):
    from tools.p7x_graph_repair69_qwen36_dp_service import (
        SWA_EXTENSION,SWA_WINDOW_EXTENSION,build_parser,
    )
    from tools.p7x_graph_repair70_qwen36_swa_anchor import DRAFT
    argv=server_argv('/python',19320,'swa',arm,worker_provenance=True,structural_swa=True)
    get=lambda flag:argv[argv.index(flag)+1]
    spec=json.loads(get('--speculative-config'))
    assert get('--tensor-parallel-size')=='4' and get('--data-parallel-size')=='2'
    assert get('--data-parallel-size-local')=='2' and '--enable-expert-parallel' in argv
    assert get('--max-model-len')=='40960' and get('--max-num-batched-tokens')=='4096'
    assert get('--worker-extension-cls')==(SWA_WINDOW_EXTENSION if arm=='G_ON' else SWA_EXTENSION)
    assert spec['model']==str(DRAFT) and spec['method']=='dflash' and spec['num_speculative_tokens']==7
    assert spec.get('enforce_eager',False) is False
    assert json.loads(get('--compilation-config'))['cudagraph_capture_sizes']==[8,16,32]
    assert json.loads(get('--additional-config'))==(
        dict(draft_window_size=32768,draft_window_graph_replicated_tp_review=True) if arm=='G_ON' else {})
    required=['run','--expected-sha','a'*40,'--arm',arm,'--port','19320','--output','/saved']
    assert build_parser().parse_args(required+['--structural-swa']).structural_swa is True
    assert build_parser().parse_args(required).structural_swa is False
    with pytest.raises(ValueError):server_argv('/python',19320,'swa',arm,worker_provenance=True,structural_swa=1)


def test_swa_dp_workers_compose_actual_native_and_window_snapshots_without_replacing_dp_export():
    from tools.p7x_graph_repair69_qwen36_dp_service import (
        Qwen36DPServiceWorker,Qwen36SWADPServiceWorker,SWAWindowDPServiceWorker,
    )
    from tools.p7x_graph_repair70_qwen36_swa_anchor import Qwen36SWAWorker
    from tools.p7x_graph_repair73_qwen36_swa_window_anchor import SWAWindowWorker
    assert Qwen36SWADPServiceWorker.mrv2_rank_snapshot is Qwen36SWAWorker.mrv2_rank_snapshot
    assert SWAWindowDPServiceWorker.mrv2_rank_snapshot is SWAWindowWorker.mrv2_rank_snapshot
    assert SWAWindowDPServiceWorker.mrv2_rank_install_dispatch_observer is SWAWindowWorker.mrv2_rank_install_dispatch_observer
    for cls in (Qwen36SWADPServiceWorker,SWAWindowDPServiceWorker):
        assert cls.mrv2_qwen_dp_identity is Qwen36DPServiceWorker.mrv2_qwen_dp_identity
    assert SWAWindowDPServiceWorker.swa_allow_dp_dummy is True


@pytest.mark.parametrize('damage',[None,'no_marker','live_generation','new_generation','window_update','missing_update',
                                   'leaked_flag','truncated','uncertain','not_returned'])
def test_dummy_host_audit_retains_baseline_update_and_rejects_generation_reuse(damage):
    from tools.p7x_graph_repair69_qwen36_dp_service import validate_dummy_records
    graph=dict(returned=True,mode='FULL',scope_marker=True,no_live_generation=True,
               generations_before=4,generations_after=4,updates=[dict(window_binding=False)])
    dummy=dict(returned=True,submission_uncertain=False,graphs=[graph],flags_after=dict(
        _draft_window_dp_dummy_active=False,_draft_window_bypass_active=False,_draft_window_prefill_bypass_active=False))
    row=dict(dp_dummy_records=[dummy],dp_dummy_records_truncated=False)
    if damage=='no_marker':graph['scope_marker']=False
    elif damage=='live_generation':graph['no_live_generation']=False
    elif damage=='new_generation':graph['generations_after']=5
    elif damage=='window_update':graph['updates'][0]['window_binding']=True
    elif damage=='missing_update':graph['updates']=[]
    elif damage=='leaked_flag':dummy['flags_after']['_draft_window_dp_dummy_active']=True
    elif damage=='truncated':row['dp_dummy_records_truncated']=True
    elif damage=='uncertain':dummy['submission_uncertain']=True
    elif damage=='not_returned':dummy['returned']=False
    if damage is None:
        assert validate_dummy_records([row])['graph_calls']==1
        row['dp_dummy_records']=[]
        assert validate_dummy_records([row])['status']=='NOT_OBSERVED'
    else:
        with pytest.raises(ValueError):validate_dummy_records([row])


def test_real_bound_wrappers_preserve_phase_signature_and_do_not_relabel_dummy_carriers():
    import inspect
    import numpy as np
    from types import SimpleNamespace as N
    from tools.p7x_graph_repair21_rank import RankWorkerExtension
    from tools.p7x_graph_repair47_glm_service import install_phase_audit
    from tools.p7x_graph_repair69_qwen36_dp_service import install_dp_dummy_audit,validate_dummy_records

    calls=[]
    class Manager:
        def run_fullgraph(self,desc):
            calls.append('replay');self._update_full_graph_params(draft_window_graph_update_binding=None)
        def _update_full_graph_params(self,**kwargs):calls.append(kwargs)
    class Spec:
        def propose(self,input_batch,*,dummy_run=False,is_profile=False):
            self._draft_window_dp_dummy_active=dummy_run and not is_profile
            self._draft_window_bypass_active=self._draft_window_dp_dummy_active
            try:return self.query_cudagraph_manager.run_fullgraph(desc)
            finally:self._draft_window_dp_dummy_active=self._draft_window_bypass_active=False
    desc=N(cg_mode=N(name='FULL'),num_tokens=8,num_reqs=1)
    spec=Spec();spec.query_cudagraph_manager=Manager()
    # Iterating this old provider for a dummy would fail, exposing the audit bug.
    spec._draft_window_graph_binding_provider=N(submitted_carriers=[N(runtime_identity=None)])
    worker=RankWorkerExtension();worker.rank=0;worker.model_runner=N(cudagraph_manager=Manager(),speculator=spec)
    worker.mrv2_rank_install_dispatch_observer();install_dp_dummy_audit(worker)
    assert 'input_batch' in inspect.signature(spec.propose).parameters
    install_phase_audit(worker,detailed=True)
    batch=N(num_reqs=1,req_ids=['request'],num_computed_prefill_tokens_np=np.array([100]),
            num_scheduled_tokens=np.array([1]),prefill_len_np=np.array([32]),is_prefilling_np=np.array([False]))
    spec.propose(batch,dummy_run=True)
    assert not worker._mrv2_service_phases and not worker._mrv2_rank_window_bindings
    assert validate_dummy_records([dict(dp_dummy_records=worker._mrv2_dp_dummy_records,
                                       dp_dummy_records_truncated=False)])['graph_calls']==1
    spec._draft_window_graph_binding_provider.submitted_carriers=[]
    spec.propose(batch)
    assert len(worker._mrv2_service_phases)==1 and worker._mrv2_service_phases[0]['returned']
    assert 'classification_error' not in worker._mrv2_service_phases[0]
    assert calls==['replay',dict(draft_window_graph_update_binding=None)]*2
