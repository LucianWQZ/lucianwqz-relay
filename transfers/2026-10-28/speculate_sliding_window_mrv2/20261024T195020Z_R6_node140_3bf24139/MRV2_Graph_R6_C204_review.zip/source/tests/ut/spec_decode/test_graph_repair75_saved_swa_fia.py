# SPDX-License-Identifier: Apache-2.0
"""CPU raw-operand and repeat verdicts, never an NPU reproduction."""
import copy
import json
from types import SimpleNamespace as N

import pytest
import torch

from tools import p7x_graph_repair75_saved_swa_fia as tool
from tools.p7x_graph_repair6_storage import CollectionWriter


def saved_sample():
    full = 'model.layers.45.self_attn.attn'
    q = torch.zeros((32, 8, 128), dtype=torch.bfloat16)
    cache = torch.zeros((5, 128, 2, 128), dtype=torch.bfloat16)
    headers = dict(gid=15, table=torch.tensor([[0, 1, 2, 0], [3, 4, 0, 0], [1, 0, 0, 0], [0, 0, 0, 0]], dtype=torch.int32),
                   exact=[263, 137, 19, 0], cumulative_query=[8, 16, 24, 32])
    return dict(status='CAPTURED_COMPLETE', identity=dict(rank=0, actual=3, padded=4, generation=35, epoch=35), full_gid=15,
        requests=['a', 'b', 'c'], row_phases=['pure_decode', 'prefill_terminal', 'prefill_terminal'],
        actual_metadata={full: headers},
        caches={str(i): dict(layers=[full+'/'+str(i)], selected=list(range(5)), graph=cache.clone(),
            allocation=dict(shape=[20, 128, 2, 128], stride=[32768, 256, 128, 1], npu_format=2)) for i in (0, 1)},
        owned_failure_probe=dict(graph_attention=dict(query=q.clone(), output=q.clone(),
            metadata=dict(seq_lens_list=[390]*4)), reference_attention=dict(output=q.clone())))


@pytest.mark.parametrize('damage', [None, 'query', 'format', 'missing_block', 'zero_active', 'nonzero_padding', 'nan', 'capture_short'])
def test_original_operand_geometry_and_all_needed_full_blocks_remain_strict(damage):
    record = saved_sample()
    if damage == 'query': record['owned_failure_probe']['graph_attention']['query'] = torch.zeros((24, 8, 128), dtype=torch.bfloat16)
    elif damage == 'format': record['caches']['0']['allocation']['npu_format'] = 29
    elif damage == 'missing_block':
        for c in record['caches'].values(): c['selected'] = c['selected'][:-1]; c['graph'] = c['graph'][:-1]
    elif damage == 'zero_active': record['actual_metadata']['model.layers.45.self_attn.attn']['exact'][1] = 0
    elif damage == 'nonzero_padding': record['actual_metadata']['model.layers.45.self_attn.attn']['exact'][3] = 1
    elif damage == 'nan': record['caches']['0']['graph'][0, 0, 0, 0] = float('nan')
    elif damage == 'capture_short': record['owned_failure_probe']['graph_attention']['metadata']['seq_lens_list'][0] = 100
    if damage is None:
        values, meta = tool.operands(record); tool.validate_operands(values, meta)
    else:
        with pytest.raises(ValueError): tool.operands(record)


def evidence(tmp_path):
    from safetensors.torch import save_file
    path = tmp_path/'original/numeric.json'; path.parent.mkdir()
    writer = CollectionWriter(path, dict(source_sha='c'*40), max_bytes=8 << 20)
    record = saved_sample(); writer.start(record['identity']); writer.finish(record); writer.close('FAILED')
    (path.parent/'failure.json').write_text(json.dumps(dict(submission=dict(pending=False))))
    prepared = tmp_path/'input'; tool.prepare(N(collection=path, output=prepared))
    manifest = json.loads((prepared/'input.json').read_text())
    outputs = {f'{name}_{phase}_{i}': torch.zeros((padded*8, 8, 128), dtype=torch.bfloat16)
               for name, padded in tool.CASES for phase in tool.PHASES for i in range(tool.REPEATS)}
    output = tmp_path/'outputs.safetensors'; save_file(outputs, str(output))
    result = dict(schema=tool.SCHEMA, tool_sha256=manifest['tool_sha256'], source_sha='d'*40,
        input_manifest_sha256=tool.digest(prepared/'input.json'), submission=dict(pending=False, failure=None),
        actual_device_world_size=1, model_loaded=False, records=tool.summaries(outputs),
        output=dict(path=str(output), sha256=tool.digest(output)))
    result_path = tmp_path/'result.json'; result_path.write_text(json.dumps(result))
    return N(input=prepared, result=result_path), outputs, result


@pytest.mark.parametrize('damage', [None, 'unstable', 'phase_difference', 'summary_only', 'data_hash', 'pending', 'tool'])
def test_native_repeat_verdict_is_recomputed_from_raw_values_and_preserves_failure(tmp_path, damage):
    from safetensors.torch import save_file
    args, outputs, result = evidence(tmp_path)
    if damage == 'unstable': outputs['original_padded4_functional_4'][9, 1, 0] = 1
    elif damage == 'phase_difference':
        for i in range(tool.REPEATS): outputs[f'original_padded4_graph_update_{i}'][9, 1, 0] = 1
    if damage in ('unstable', 'phase_difference'):
        save_file(outputs, result['output']['path']); result['output']['sha256'] = tool.digest(result['output']['path'])
        result['records'] = tool.summaries(outputs)
    elif damage == 'summary_only': result['records'][0]['changed_elements'][0] = 3
    elif damage == 'data_hash': result['output']['sha256'] = '0'*64
    elif damage == 'pending': result['submission']['pending'] = True
    elif damage == 'tool': result['tool_sha256'] = '0'*64
    args.result.write_text(json.dumps(result))
    if damage in ('summary_only', 'data_hash', 'pending', 'tool'):
        with pytest.raises(ValueError): tool.check(args)
    else:
        verdict = tool.check(args)
        assert verdict['status'] == {None: 'NOT_REPRODUCED_WITH_ISOLATED_READONLY_KV',
            'unstable': 'REPRODUCED_FIA_REPEAT_DIVERGENCE_ON_FIXED_OPERANDS',
            'phase_difference': 'STABLE_NATIVE_GRAPH_EAGER_DIFFERENCE_ON_FIXED_OPERANDS'}[damage]
        assert verdict['original_model_failure'] == 'UNCHANGED_NO_WAIVER'


def test_unknown_submission_cannot_be_prepared_for_device_replay(tmp_path):
    args, _, _ = evidence(tmp_path)
    manifest = json.loads((args.input/'input.json').read_text()); path = tool.Path(manifest['collection']['path'])
    (path.parent/'failure.json').write_text(json.dumps(dict(submission=dict(pending=True))))
    with pytest.raises(ValueError): tool.prepare(N(collection=path, output=tmp_path/'forbidden'))


@pytest.mark.parametrize('damage', [None, 'upload', 'mutation', 'view_shape', 'view_pointer', 'compact_alias'])
def test_capacity_contrast_requires_actual_unchanged_inputs_and_named_layouts(tmp_path,damage):
    from safetensors.torch import load_file,save_file
    args,_,result=evidence(tmp_path)
    manifest=json.loads((args.input/'input.json').read_text());data=load_file(manifest['data']['path'])
    specs=tool.case_specs(True);cases=tuple((name,padded) for name,padded,_ in specs);bound=5
    readbacks={f'{owner}_{when}_{part}':data[part].reshape(-1,128,256).clone()
               for owner in ('full','compact') for when in ('before','after') for part in ('key','value')}
    for name,padded,_ in specs:
        for when in ('before','after'):
            readbacks[name+'_query_'+when]=data['query'][:padded*8].clone()
            readbacks[name+'_table_'+when]=data['table'][:padded].clone()
    if damage=='upload':readbacks['full_before_key'][0,0,0]=1
    elif damage=='mutation':readbacks['compact_after_value'][0,0,0]=1
    file=tmp_path/'readbacks.safetensors';save_file(readbacks,str(file))
    outputs={f'{name}_{phase}_{i}':torch.zeros((padded*8,8,128),dtype=torch.bfloat16)
             for name,padded in cases for phase in tool.PHASES for i in range(tool.REPEATS)}
    save_file(outputs,result['output']['path']);result['output']['sha256']=tool.digest(result['output']['path'])
    layouts=[]
    for index,(name,_,mode) in enumerate(specs):
        layouts.append(dict(case=name,mode=mode,operands=[dict(shape=[20 if index==0 else bound,128,256],
            stride=[32768,256,1],format=2,storage_bytes=(bound if index==2 else 20)*128*256*2,
            data_ptr=1000+part*1000+(2000 if index==2 else 0)) for part in (0,1)]))
    if damage=='view_shape':layouts[1]['operands'][0]['shape'][0]=20
    elif damage=='view_pointer':layouts[1]['operands'][0]['data_ptr']+=1
    elif damage=='compact_alias':layouts[2]['operands'][0]['data_ptr']=1000
    result.update(capacity_contrast=True,cache_operand_headers=layouts,input_readback=dict(path=str(file),sha256=tool.digest(file)),
                  records=tool.summaries(outputs,cases));args.result.write_text(json.dumps(result))
    if damage is None:assert tool.check(args)['device_inputs_readback_exact'] is True
    else:
        with pytest.raises(ValueError):tool.check(args)
