# SPDX-License-Identifier: Apache-2.0
"""Single-case diagnostic cannot masquerade as complete numerical/Target data."""
import copy

import pytest

from tools.p7x_graph_repair23_eagle_target import PROFILE, case_plan, selected_reproduction_cases
from tools.p7x_graph_repair31_eagle_padding import REPRO, PASS, validate_headers
from tools.p7x_graph_repair13_eagle import checker_exit_status


def headers():
    identity = dict(source_sha="a"*40, process_id=123, engine_id=456)
    selected = selected_reproduction_cases(REPRO)
    summary = dict(identity=identity,status="COMPLETE_DECLARED_REPRODUCTION",reproduction=REPRO,
                   expected_cases=selected,samples=1,sample_limit=None,profile=PROFILE,
                   extra_sync=True,numerical_reference=True)
    target = dict(identity=identity,cases=selected,capture_profile=PROFILE)
    numeric = dict(identity=identity,numeric_schema="r6-eagle3-controlled-continuous-v6",
                   controlled_cases=case_plan(),expected_samples=42,tolerance=dict(atol=0.0,rtol=0.0),
                   groups={c["scenario"]:len(c["ends"]) for c in case_plan()})
    return summary,target,numeric,identity


def test_distinct_single_case_preserves_original_index_and_full_blueprint():
    s,t,n,i = headers()
    selected = validate_headers(s,t,n,i)
    assert selected["step"] == 9 and selected["scenario"] == REPRO and selected["padded"] == 2
    assert len(n["controlled_cases"]) == 14 and n["expected_samples"] == 42
    assert selected_reproduction_cases() == case_plan()
    assert checker_exit_status(dict(status=PASS)) == 0
    assert checker_exit_status(dict(status="PASS_SCOPED_EAGLE3_PADDING_REPRODUCTION_FULL_MATRIX")) != 0


@pytest.mark.parametrize("damage", ["source","scope","full","relabel","count","prefix","sync","samples","schema","tolerance"])
def test_relabelled_missing_or_relaxed_single_case_is_rejected(damage):
    s,t,n,i = copy.deepcopy(headers())
    if damage == "source": n["identity"] = dict(i,source_sha="b"*40)
    elif damage == "scope": s["status"] = "COMPLETE_DECLARED_TARGET_ARM"
    elif damage == "full": s["expected_cases"] = t["cases"] = case_plan()
    elif damage == "relabel": t["cases"] = [dict(t["cases"][0],step=0)]
    elif damage == "count": n["expected_samples"] = 3
    elif damage == "prefix": s["sample_limit"] = 1
    elif damage == "sync": s["extra_sync"] = False
    elif damage == "samples": s["samples"] = 14
    elif damage == "schema": n["numeric_schema"] = "unknown"
    else: n["tolerance"]["atol"] = 1e-2
    with pytest.raises(ValueError): validate_headers(s,t,n,i)


def test_unknown_scenario_cannot_use_the_reproduction_entry():
    with pytest.raises(ValueError): selected_reproduction_cases("short")


def test_selected_case_uses_original_generation_without_list_offset_relabel():
    from tools.p7x_graph_repair23_eagle_target import original_case_for_generation
    selected = selected_reproduction_cases(REPRO)
    assert original_case_for_generation(selected,9) == case_plan()[9]
    for cases, generation in [(selected,0),(selected,True),(selected+selected,9)]:
        with pytest.raises(ValueError): original_case_for_generation(cases,generation)
    for case in case_plan():
        assert original_case_for_generation(case_plan(),case["step"]) == case
