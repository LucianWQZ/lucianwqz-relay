# SPDX-License-Identifier: Apache-2.0
import copy

import pytest
import torch

from tools.p7x_graph_repair54_glm_cp_contract import validate_cp_context


def snapshot(rank, active=3, padded=4):
    tokens = 9 * padded
    aligned = ((tokens + 15) // 16) * 16
    width = aligned // 16
    begin, end = rank * width, (rank + 1) * width
    slots = torch.tensor(list(range(active * 9)) + [-1] * ((padded - active) * 9), dtype=torch.int32)
    layout = [9 * row for row in range(padded + 1)]
    exact = [32, 1025, 1153, 2049][:active] + [1] * (padded - active)
    # Construct this fixture from intersections of explicit token-owner sets,
    # rather than calling the production CP metadata helper or the oracle.
    shard = set(range(begin, end))
    totals, keys, total = [], [], 0
    for row in range(padded):
        owned = sorted(shard.intersection(range(layout[row], layout[row + 1])))
        total += len(owned)
        totals.append(total)
        keys.append(max(0, exact[row] - (layout[row + 1] - 1 - owned[-1])) if owned else 0)
    context = dict(num_tokens=tokens, num_tokens_pad=aligned, local_start=begin,
                   local_end=min(end, active * 9), local_end_with_pad=end,
                   slot_mapping_cp=torch.tensor((slots.tolist() + [-1] * (aligned - tokens))[begin:end], dtype=torch.int32),
                   actual_seq_lengths_query=torch.tensor(totals, dtype=torch.int32),
                   actual_seq_lengths_key=torch.tensor(keys, dtype=torch.int32))
    args = dict(canonical_slots=slots, query_layout=layout, exact_lengths=exact,
                actual_tokens=active * 9, rank=rank)
    return context, args


@pytest.mark.parametrize("rank", range(16))
@pytest.mark.parametrize("active,padded", [(1, 2), (2, 2), (3, 4), (4, 4)])
def test_each_real_rank_partition_handles_active_and_padding_rows(rank, active, padded):
    context, args = snapshot(rank, active, padded)
    assert validate_cp_context(context, **args)["rank"] == rank


@pytest.mark.parametrize("damage", ["rank", "missing", "headers", "bool_header", "slots", "slot_dtype",
                                    "query", "query_dtype", "keys", "old_exact", "padding_write"])
def test_inconsistent_metadata_or_stale_lengths_are_rejected(damage):
    context, args = snapshot(0)
    context = copy.deepcopy(context)
    if damage == "rank":
        args["rank"] = 1
    elif damage == "missing":
        context.pop("num_tokens_pad")
    elif damage == "headers":
        context["num_tokens_pad"] -= 16
    elif damage == "bool_header":
        context["local_start"] = False
    elif damage == "slots":
        context["slot_mapping_cp"][0] += 1
    elif damage == "slot_dtype":
        context["slot_mapping_cp"] = context["slot_mapping_cp"].to(torch.int64)
    elif damage == "query":
        context["actual_seq_lengths_query"][0] += 1
    elif damage == "query_dtype":
        context["actual_seq_lengths_query"] = context["actual_seq_lengths_query"].to(torch.int64)
    elif damage == "keys":
        context["actual_seq_lengths_key"][0] += 1
    elif damage == "old_exact":
        args["exact_lengths"][0] += 1
    else:
        args["canonical_slots"][-1] = 0
    with pytest.raises(ValueError):
        validate_cp_context(context, **args)
