# SPDX-License-Identifier: Apache-2.0
import copy
import json
from collections import Counter

import pytest

from tools import p7x_graph_repair27_balanced_perf as balanced


def fixture(tmp_path, labels=("short1", "short3")):
    declaration = dict(
        schema=balanced.SCHEMA,
        repetitions=6,
        workloads=[dict(label=label, template="short") for label in labels])
    (tmp_path / "balanced-performance27.json").write_text(
        json.dumps(declaration))
    (tmp_path / "requests").mkdir()
    for label in labels:
        rows = [
            dict(label=label,
                 max_tokens=256,
                 prompts=[dict(prompt_token_ids=[17] * 257)] *
                 (3 if label == "short3" else 1))
        ]
        (tmp_path / f"requests/performance27-{label}.json").write_text(
            json.dumps(rows))
    cases = {}
    for arm in balanced.ARMS:
        name = f"PERF10_{arm}_short_01"
        argv = [
            "python", "driver", "run", "--case-id", name, "--requests",
            "old-request", "--repair5-profile", "control"
        ]
        cases[name] = dict(
            argv=argv,
            launch_argv=["python", "launch", "--", *argv],
            request_path="old-request",
            performance_arm=arm,
            performance_workload="short",
            validation_commands=[
                dict(argv=[
                    "python", "p7x_graph_repair10_performance.py", "--case-id",
                    name
                ])
            ])
    return declaration, cases


def test_every_order_balanced_and_concurrency_separate_without_mutating_old_cases(
        tmp_path):
    _, cases = fixture(tmp_path)
    old = copy.deepcopy(cases)
    names = balanced.add_cases(cases, tmp_path, tmp_path / "output", tmp_path,
                               "python")
    assert len(names) == 36 and all(cases[k] == value
                                    for k, value in old.items())
    for label in ("short1", "short3"):
        rows = [
            cases[name] for name in names
            if cases[name]["balanced_performance"]["label"] == label
        ]
        assert Counter((row["performance_arm"],
                        row["balanced_performance"]["order_position"])
                       for row in rows) == Counter({
                           (arm, position): 2
                           for arm in balanced.ARMS
                           for position in (1, 2, 3)
                       })
        assert len({row["requests_sha256"] for row in rows}) == 1
        for row in rows:
            assert row["launch_argv"][row["launch_argv"].index("--") +
                                      1:] == row["argv"]
            assert "p7x_graph_repair27_balanced_perf.py" in row[
                "validation_commands"][0]["argv"]
    assert cases[names[0]]["requests_sha256"] != cases[
        names[-1]]["requests_sha256"]


@pytest.mark.parametrize(
    "damage", ["five", "boolean", "duplicate", "path", "unknown_template"])
def test_bad_declarations_do_not_silently_change_order_or_scope(
        tmp_path, damage):
    declaration, cases = fixture(tmp_path)
    if damage == "five": declaration["repetitions"] = 5
    if damage == "boolean": declaration["repetitions"] = True
    if damage == "duplicate":
        declaration["workloads"].append(declaration["workloads"][0])
    if damage == "path": declaration["workloads"][0]["label"] = "../escape"
    if damage == "unknown_template":
        declaration["workloads"][0]["template"] = "eagle"
    (tmp_path / "balanced-performance27.json").write_text(
        json.dumps(declaration))
    with pytest.raises(ValueError):
        balanced.add_cases(cases, tmp_path, tmp_path / "output", tmp_path,
                           "python")


def test_control_cannot_be_replaced_with_profiled_template(tmp_path):
    _, cases = fixture(tmp_path)
    row = cases["PERF10_G_OFF_short_01"]
    row["argv"][row["argv"].index("--repair5-profile") + 1] = "normal"
    with pytest.raises(ValueError, match="profiler"):
        balanced.add_cases(cases, tmp_path, tmp_path / "output", tmp_path,
                           "python")


@pytest.mark.parametrize(
    "damage", [None, "order", "marker", "max_length", "underlying_failure"])
def test_new_metadata_checks_preserve_underlying_checker_failure(
        tmp_path, monkeypatch, damage):
    _, cases = fixture(tmp_path)
    names = balanced.add_cases(cases, tmp_path, tmp_path / "output", tmp_path,
                               "python")
    expected = cases[names[0]]
    campaign = dict(llm_kwargs=dict(max_model_len=12288))
    original = dict(status="PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE")
    if damage == "underlying_failure":
        original.update(status="INVALID_EVIDENCE",
                        error="actual output mismatch")
    monkeypatch.setattr(balanced, "check_performance",
                        lambda *args: copy.deepcopy(original))
    if damage == "order":
        expected["balanced_performance"]["arm_order"].reverse()
    if damage == "marker":
        (tmp_path / "balanced-performance27.json").write_text("{}")
    if damage == "max_length": campaign["llm_kwargs"]["max_model_len"] = 24576
    result = balanced.check(campaign, {}, {}, expected,
                            tmp_path / "profile.json")
    assert result["status"] == ("PASS_SCOPED_PERFORMANCE_AND_ACCEPTANCE"
                                if damage is None else "INVALID_EVIDENCE")
    if damage == "underlying_failure":
        assert result["error"] == "actual output mismatch"


def test_profile_sidecars_preserve_all_normal_controls_and_use_their_real_requests(tmp_path):
    _,cases=fixture(tmp_path,labels=('short1',));old=copy.deepcopy(cases)
    (tmp_path/'request-profile27.json').write_text(json.dumps(dict(schema='r6-dspark-short-request-profile-v1',labels=['short1'])))
    names=balanced.add_cases(cases,tmp_path,tmp_path/'out',tmp_path,'python')
    normal=[k for k in names if k.startswith('PERF27_')];profiles=[k for k in names if k.startswith('PROFILE27_')]
    assert len(normal)==18 and len(profiles)==3 and all(cases[k]==v for k,v in old.items())
    for name in profiles:
        row=cases[name]
        assert row['request_profile_sidecar']['measurement']=='PROFILED_NOT_NORMAL_CONTROL'
        assert 'balanced_performance' not in row
        assert row['launch_argv'][row['launch_argv'].index('--')+1:]==row['argv']
        assert row['argv'][row['argv'].index('--repair5-profile')+1]=='normal'
        assert '--repair8-materialize-ranges' in row['argv']
        assert 'p7x_graph_repair10_performance.py' in row['validation_commands'][0]['argv']
        assert row['requests_sha256']==cases[normal[0]]['requests_sha256']
    assert all(cases[k]['argv'][cases[k]['argv'].index('--repair5-profile')+1]=='control' for k in normal)


@pytest.mark.parametrize('damage',['schema','path','duplicate','output','dtype','length'])
def test_profile_sidecars_cannot_silently_change_workload_scope(tmp_path,damage):
    _,cases=fixture(tmp_path,labels=('short1',))
    declaration=dict(schema='r6-dspark-short-request-profile-v1',labels=['short1'])
    path=tmp_path/'requests/performance27-short1.json';rows=json.loads(path.read_text())
    if damage=='schema':declaration['schema']='normal-control'
    elif damage=='path':declaration['labels']=['../escape']
    elif damage=='duplicate':declaration['labels']*=2
    elif damage=='output':rows[0]['max_tokens']=16
    elif damage=='dtype':rows[0]['prompts'][0]['prompt_token_ids']=[True]
    else:rows[0]['prompts'][0]['prompt_token_ids']=[10]*12288
    path.write_text(json.dumps(rows));(tmp_path/'request-profile27.json').write_text(json.dumps(declaration))
    with pytest.raises(ValueError):balanced.add_cases(cases,tmp_path,tmp_path/'out',tmp_path,'python')
