# SPDX-License-Identifier: Apache-2.0
"""Host-only real pool unwind and saved-record corruption checks."""
import copy
import importlib.util
import json
from pathlib import Path
from types import MethodType, SimpleNamespace

import pytest

from tools.p7x_graph_repair61_glm_eager_unwind import (
    EagerAfterForwardProbe, InjectedEagerAfterForward, InjectedEagerAfterMaterialization,
    fault_contract, validate_unwind, validate_error_exports,
)
from tools.p7x_graph_repair41_rank_unwind import install_execute_error_export


@pytest.mark.parametrize('point', ['after_eager_forward', 'after_eager_materialization'])
def test_probe_observes_real_pool_quarantine_without_reentering_epoch_or_device(tmp_path, point):
    # Reuse the existing CPU runtime/metadata fixture, not a fake lifecycle.
    path = Path(__file__).with_name('test_draft_window_eager.py')
    spec = importlib.util.spec_from_file_location('eager_unwind_fixture', path)
    fixtures = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fixtures)
    owner, batch = fixtures._harness(async_scheduling=True)
    pool = owner._draft_window_async_pool
    calls = []

    def forward(_owner, *args, **kwargs):
        pool.mark_consumer_started(_owner._draft_window_async_handle)
        calls.append('simulated_native_return')
        return object()

    owner._run_model = MethodType(forward, owner)
    identity = dict(nonce='a'*32)
    probe = EagerAfterForwardProbe(owner, tmp_path, identity, [], point=point)
    owner._draft_window_completion_token_factory = lambda: pytest.fail('fault must not record a completion')
    probe.__enter__()
    def sample_tokens():
        with owner._draft_window_proposal_scope(batch, dummy_run=False, is_profile=False):
            owner._build_draft_attn_metadata(num_reqs=batch.num_reqs, num_reqs_padded=4,
                num_tokens_padded=8, seq_lens_cpu_upper_bound=batch.seq_lens_cpu_upper_bound,
                step=4, causal=False)
            owner._run_model()
    runner = SimpleNamespace(sample_tokens=sample_tokens, execute_model=lambda: None)
    install_execute_error_export(runner, probe, tmp_path/'terminal.json', identity)
    with pytest.raises(InjectedEagerAfterForward if point == 'after_eager_forward'
                       else InjectedEagerAfterMaterialization):
        runner.sample_tokens()
    report = json.loads((tmp_path/'eager-unwind.json').read_text())
    terminal = json.loads((tmp_path/'terminal.json').read_text())
    assert report['pool_quarantined'] and report['handle_still_owned'] and report['runtime_quarantined']
    assert report['observation']['before'] == report['after']
    assert report['next_scope_reached_epoch'] is False
    assert 'quarantin' in report['next_scope_error']
    assert calls == (['simulated_native_return'] if point == 'after_eager_forward' else [])
    assert report['metadata_still_owned'] is (point == 'after_eager_forward')
    assert report['native_output_retained'] is (point == 'after_eager_forward')
    assert report['prepared_inputs_retained'] is (point == 'after_eager_materialization')
    if point == 'after_eager_materialization':
        assert owner.builder_events == []
    assert report['observation']['native_host_return_ns'] < terminal['caught_ns'] <= report['caught_after_unwind_ns']


def records(point='after_eager_forward'):
    _, message, exception, _, _ = fault_contract(point)
    is_forward = point == 'after_eager_forward'
    identity = dict(rank=0, world_size=16, pid=1234, process_start_ticks='45', source_sha='a'*40,
                    nonce='b'*32, mode='python_unwind', point=point)
    worker = dict(rank=0, pid=1234, process_start_ticks='45')
    payload = dict(tp=16, source_sha='a'*40, nonce='b'*32, mode='python_unwind', point=point)
    headers = {name: dict(pointer=100+index*64, shape=[2, 9] if index == 0 else [2], dtype='torch.int32')
               for index, name in enumerate(('window_block_table', 'device_window_exact', 'cpu_window_exact'))}
    report = dict(identity=identity, exception_type=exception.__name__,
        exception_message=message+payload['nonce'], pool_quarantined=True, handle_state='quarantined',
        handle_still_owned=True, inputs_still_owned=True, metadata_still_owned=is_forward,
        runtime_quarantined=True, completion_token_absent=True, caught_after_unwind_ns=3,
        native_output_retained=is_forward, prepared_inputs_retained=not is_forward,
        next_scope_reached_epoch=False, next_scope_error='quarantined', after=copy.deepcopy(headers),
        post_fault_device_operations='NONE_BY_THIS_PROBE', native_completion='UNKNOWN_NOT_QUERIED',
        native_partial_failure='NOT_INJECTED', observation=dict(native_host_return_ns=1,
            point=point, preparation_started=True,
            generation=3, epoch=9, execution_lane=0, requests=['A'], tp_rank=0, tp_size=16,
            before=headers, consumer_started=is_forward),
        source_rows=[dict(generation=3, epoch=9, execution_lane=0, requests=['A'], tp_rank=0,
                          tp_size=16, window_starts=[7168])])
    terminal = dict(identity=copy.deepcopy(identity), exception_type=report['exception_type'],
        exception_message=report['exception_message'], entrypoint='sample_tokens',
        guarded_entrypoints=['execute_model', 'sample_tokens'], caught_ns=2)
    return report, terminal, worker, payload


@pytest.mark.parametrize('point', ['after_eager_forward', 'after_eager_materialization'])
def test_complete_host_surrogate_is_limited_to_isolation(point):
    expected = ('SCOPED_EAGER_UNCERTAIN_READER_ISOLATION' if point == 'after_eager_forward' else
                'SCOPED_EAGER_UNCERTAIN_PREPARATION_ISOLATION')
    assert validate_unwind(*records(point))['status'] == expected


@pytest.mark.parametrize('point', ['after_eager_forward', 'after_eager_materialization'])
@pytest.mark.parametrize('damage', ['released', 'metadata', 'state', 'epoch', 'rank', 'clip',
    'cleared_pointer', 'missing_header', 'early_time', 'completion', 'next_epoch', 'wrong_exception',
    'forward_output', 'prepared_inputs', 'point', 'preparation', 'consumer'])
def test_broken_ownership_or_fake_completion_is_rejected(damage, point):
    report, terminal, worker, payload = records(point)
    if damage == 'released':
        report['handle_still_owned'] = False
    elif damage == 'metadata':
        report['metadata_still_owned'] = not report['metadata_still_owned']
    elif damage == 'state':
        report['handle_state'] = 'free'
    elif damage == 'epoch':
        report['source_rows'][0]['epoch'] += 1
    elif damage == 'rank':
        report['source_rows'][0]['tp_rank'] = 1
    elif damage == 'clip':
        report['source_rows'][0]['window_starts'] = [0]
    elif damage == 'cleared_pointer':
        report['after']['window_block_table']['pointer'] += 1
    elif damage == 'missing_header':
        report['observation']['before'] = {}
    elif damage == 'early_time':
        report['caught_after_unwind_ns'] = 0
    elif damage == 'completion':
        report['native_completion'] = 'PROVEN'
    elif damage == 'next_epoch':
        report['next_scope_reached_epoch'] = True
    elif damage == 'forward_output':
        report['native_output_retained'] = not report['native_output_retained']
    elif damage == 'prepared_inputs':
        report['prepared_inputs_retained'] = not report['prepared_inputs_retained']
    elif damage == 'point':
        report['observation']['point'] = 'different_boundary'
    elif damage == 'preparation':
        report['observation']['preparation_started'] = False
    elif damage == 'consumer':
        report['observation']['consumer_started'] = not report['observation']['consumer_started']
    else:
        terminal['exception_message'] = 'some unrelated failure'
    with pytest.raises((ValueError, KeyError)):
        validate_unwind(report, terminal, worker, payload)


def error_export_files(root):
    from tools.p7x_graph_repair41_rank_unwind import rank_host_error_export_barrier
    _, terminal, _, payload = records('after_eager_materialization')
    payload.update(root=str(root), worker_processes=[])
    for rank in range(16):
        row = copy.deepcopy(terminal)
        row['identity'].update(rank=rank, pid=1234+rank)
        payload['worker_processes'].append(dict(rank=rank, pid=1234+rank, process_start_ticks='45'))
        path = root / f'rank-{rank}/terminal.json'
        path.parent.mkdir()
        path.write_text(json.dumps(row))
    index = rank_host_error_export_barrier(payload, timeout=.01)
    (root/'rank-0/host-error-barrier.json').write_text(json.dumps(index))
    return payload


def test_all_actual_terminals_and_one_hashed_index_do_not_require_duplicate_acknowledgements(tmp_path):
    payload = error_export_files(tmp_path)
    checked = validate_error_exports(tmp_path, payload)
    assert checked['terminals'] == 16 and checked['missing_duplicate_indexes'] == 15
    assert len(checked['complete_indexes']) == 1
    assert checked['device_completion'] == 'NOT_PROVEN'


@pytest.mark.parametrize('damage', ['missing_terminal', 'other_invocation', 'duplicate_proof',
    'bad_hash', 'wrong_path', 'no_index', 'timed_out', 'fake_completion', 'bool_rank',
    'malformed_peer_index', 'changed_terminal_bytes'])
def test_missing_peer_or_contradictory_error_export_index_is_still_rejected(tmp_path, damage):
    payload = error_export_files(tmp_path)
    index_path = tmp_path/'rank-0/host-error-barrier.json'
    index = json.loads(index_path.read_text())
    terminal = tmp_path/'rank-15/terminal.json'
    if damage == 'missing_terminal':
        terminal.unlink()
    elif damage == 'other_invocation':
        row = json.loads(terminal.read_text())
        row['identity']['nonce'] = 'c'*32
        terminal.write_text(json.dumps(row))
    elif damage == 'duplicate_proof':
        index['proofs'][-1] = copy.deepcopy(index['proofs'][0])
    elif damage == 'bad_hash':
        index['proofs'][-1]['sha256'] = '0'*64
    elif damage == 'wrong_path':
        index['proofs'][-1]['path'] = str(index_path)
    elif damage == 'no_index':
        index_path.unlink()
    elif damage == 'timed_out':
        index['status'] = 'HOST_EXPORT_TIMEOUT_ISOLATION_REQUIRED'
    elif damage == 'fake_completion':
        index['native_completion'] = 'PROVEN'
    elif damage == 'bool_rank':
        index['proofs'][0]['rank'] = False
    elif damage == 'malformed_peer_index':
        (tmp_path/'rank-1/host-error-barrier.json').write_text('{}')
    else:
        terminal.write_text(terminal.read_text()+'\n')
    if index_path.exists():
        index_path.write_text(json.dumps(index))
    with pytest.raises((ValueError, KeyError, OSError)):
        validate_error_exports(tmp_path, payload)
