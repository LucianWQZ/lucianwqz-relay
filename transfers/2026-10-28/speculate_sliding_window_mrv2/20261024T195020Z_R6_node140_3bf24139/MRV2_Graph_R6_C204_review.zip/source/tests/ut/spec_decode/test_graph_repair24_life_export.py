# SPDX-License-Identifier: Apache-2.0
"""Host-only export buffering keeps the real scope/manager/event sequence."""
import json
import os
from types import SimpleNamespace

import pytest
import torch

from tests.ut.spec_decode import test_graph_repair5_producers as old


def setup_probe(monkeypatch, tmp_path, interval):
    tool = old.load("p7x_graph_repair5_lifecycle")
    owner, session, manager, descriptors, calls = old.integration._lifetime_fixture(monkeypatch)
    owner.query_cudagraph_manager = manager
    owner.draft_attn_layer_names = [old.integration.LAYER]
    owner.draft_tokens = torch.zeros(8, 7, dtype=torch.int64)
    manager.max_num_reqs, manager.update_stream.npu_stream = 8, 2
    events = []

    class Event(old.OrdinaryEvent):

        def record(self, stream):
            events.append(("record", stream.npu_stream))
            super().record(stream)

        def synchronize(self):
            events.append(("sync", self.stream.npu_stream))
            super().synchronize()

        def query(self):
            events.append(("query", self.stream.npu_stream))
            return super().query()

    monkeypatch.setattr(torch.npu, "current_stream", lambda: SimpleNamespace(npu_stream=1))
    monkeypatch.setattr(torch.npu, "Event", Event)
    old.install_native_update_observation(monkeypatch, session, manager, calls)
    identity = dict(run_id="r",
                    case_id="life",
                    attempt_id="1",
                    source_sha="a" * 40,
                    source_tree="b" * 40,
                    process_id=os.getpid(),
                    engine_id=123,
                    driver_mode="B")
    path = tmp_path / "life.json"
    probe = tool.MRV2LifecycleProbe(owner, path, identity, host_export_interval=interval)
    return tool, owner, session, manager, descriptors, calls, events, path, probe


@pytest.mark.parametrize("interval", [1, 16])
def test_all_generations_and_device_event_order_preserved(monkeypatch, tmp_path, interval):
    tool, owner, session, manager, descriptors, calls, events, path, probe = setup_probe(
        monkeypatch, tmp_path, interval)
    writer = session.recorder.write_artifact
    with probe:
        for generation in range(17):
            active = (1, 2, 4, 3)[generation % 4]
            padded = 4 if active == 3 else active
            old.integration._batch(owner, active)
            with owner._draft_window_proposal_scope(owner.input_batch, dummy_run=False, is_profile=False):
                old.integration._publish_in_scope(owner, descriptors[padded])
                assert manager.run_fullgraph(descriptors[padded]) is None
            if interval == 16:
                assert path.exists() is (generation >= 15)
                if generation == 15:
                    partial = json.loads(path.read_text())
                    assert len(partial["records"]) == 16 and all(r["retired"] for r in partial["records"])
    doc = json.loads(path.read_text())
    assert len(doc["records"]) == 17 and all(r["retired"] for r in doc["records"])
    assert tool.check_lifecycle(doc)["status"] == "STRUCTURE_VALID_NOT_EXECUTION_ACCEPTED"
    evidence = old.load("p7x_graph_repair5_evidence")
    assert evidence.correlate_lifecycle(doc, session.recorder.snapshot())["status"] == "RECORDER_ASSOCIATED"
    assert calls == ["native_replay", "native_update"] * 17
    assert events == [("record", 1), ("record", 2), ("sync", 2), ("sync", 1), ("query", 2), ("query", 1)] * 17
    assert session.recorder.write_artifact == writer
    assert probe.saved == []
    if interval == 16:
        assert probe.deferred_exports > 17


def test_unknown_update_exception_forces_host_export_without_device_recovery(monkeypatch, tmp_path):
    _, owner, session, manager, descriptors, calls, events, path, probe = setup_probe(monkeypatch, tmp_path, 16)
    writer = session.recorder.write_artifact

    def unknown_update(*_args, **_kwargs):
        raise RuntimeError("simulated submission unknown")

    monkeypatch.setattr(old.integration.AscendAttentionBackendImpl, "update_graph_params", staticmethod(unknown_update))
    with pytest.raises(RuntimeError, match="simulated submission unknown"), probe:
        old.integration._batch(owner, 1)
        with owner._draft_window_proposal_scope(owner.input_batch, dummy_run=False, is_profile=False):
            old.integration._publish_in_scope(owner, descriptors[1])
            manager.run_fullgraph(descriptors[1])
    doc = json.loads(path.read_text())
    assert doc["quarantined"] and len(doc["records"]) == 1
    assert doc["records"][0]["completion"] == "UNPROVEN"
    assert events == [("record", 1)]  # No post-fault sync/query, recovery or extra device operation.
    assert calls == ["native_replay"]
    assert session.recorder.write_artifact == writer


@pytest.mark.parametrize("interval", [True, False, 0, 2, "16"])
def test_export_interval_is_an_exact_explicit_contract(tmp_path, interval):
    with pytest.raises(ValueError, match="exactly 1 or 16"):
        old.load("p7x_graph_repair5_lifecycle").MRV2LifecycleProbe(None,
                                                                   tmp_path / "bad.json", {},
                                                                   host_export_interval=interval)


def test_abort_cannot_defer_required_partial_export(tmp_path):
    with pytest.raises(ValueError, match="exclusive"):
        old.load("p7x_graph_repair5_lifecycle").MRV2LifecycleProbe(None,
                                                                   tmp_path / "bad.json", {},
                                                                   host_export_interval=16,
                                                                   abort_at="after_replay")


@pytest.mark.parametrize(
    "extra",
    [[], ["--repair5-abort-at", "after_update"], ["--repair5-profile", "life"], ["--repair6-numeric-reference"]])
def test_real_cli_buffering_is_exclusive_to_normal_life(tmp_path, extra):
    from tools.p7x_graph_repair2 import parse_args
    argv = [
        "run", "--case", "B", "--case-id", "life", "--run-id", "host", "--attempt", "1", "--expected-sha", "a" * 40,
        "--output",
        str(tmp_path), "--target-model", "host-target", "--draft-model", "host-draft", "--vllm-repo",
        str(tmp_path), "--fixture-manifest",
        str(tmp_path / "fixture.json"), "--repair5-lifecycle", "--repair24-life-host-export-interval", "16"
    ]
    if extra:
        with pytest.raises(SystemExit) as error:
            parse_args(argv + extra)
        assert error.value.code == 2
    else:
        assert parse_args(argv).repair24_life_host_export_interval == 16
        argv.remove("--repair5-lifecycle")
        with pytest.raises(SystemExit):
            parse_args(argv)


def test_named_q8_plan_keeps_all_requests_and_never_buffers_faults(tmp_path):
    import hashlib
    from tests.ut.spec_decode.test_graph_repair17_dspark_q8 import model_fixture
    from tools.p7x_graph_repair17_dspark_q8 import prepare_cases
    document = model_fixture(tmp_path)
    (tmp_path / "dspark-k7-noanchor-q8-fixture.json").write_text(json.dumps(document))
    (tmp_path / "requests").mkdir()
    request = tmp_path / "requests/dspark-q8-lifecycle.json"
    request.write_text('[{"max_tokens":64,"prompts":["unchanged-full-workload"]}]')
    policy = dict(schema="r6-life-host-export-v1",
                  interval=16,
                  requests_sha256=hashlib.sha256(request.read_bytes()).hexdigest())
    config = tmp_path / "dspark-q8-lifecycle-host-export.json"
    config.write_text(json.dumps(policy))

    def templates():
        cases = {"CONFIG": dict(argv=["config"], validation_commands=[])}
        for name in ("NUMERIC_SENTINEL", "NUMERIC_TARGET4", "TARGET4_OFF", "LIFE", "ABORT_after_update"):
            argv = ["python", "run", "--requests", "old"]
            cases[name] = dict(argv=argv,
                               launch_argv=["launch", "--", *argv],
                               validation_commands=[],
                               acceptance_identity=dict(case_id=name),
                               lifecycle_coverage=dict(descriptors=[]))
        return cases

    cases = templates()
    prepare_cases(cases, tmp_path, tmp_path, tmp_path, "python", "a" * 40, "b" * 40, [])
    life = cases["DSPARK_Q8_LIFE"]
    assert life["argv"][-2:] == ["--repair24-life-host-export-interval", "16"]
    assert life["launch_argv"][2:] == life["argv"]
    assert life["requests_sha256"] == policy["requests_sha256"]
    assert life["dependencies"] == ["CONFIG_DSPARK_Q8", "NUMERIC_DSPARK_Q8"]
    assert "--repair24-life-host-export-interval" not in cases["ABORT_DSPARK_Q8_after_update"]["argv"]
    assert cases["ABORT_DSPARK_Q8_after_update"]["dependencies"] == ["DSPARK_Q8_LIFE"]
    policy["requests_sha256"] = "0" * 64
    config.write_text(json.dumps(policy))
    with pytest.raises(ValueError, match="unchanged full lifecycle requests"):
        prepare_cases(templates(), tmp_path, tmp_path, tmp_path, "python", "a" * 40, "b" * 40, [])
