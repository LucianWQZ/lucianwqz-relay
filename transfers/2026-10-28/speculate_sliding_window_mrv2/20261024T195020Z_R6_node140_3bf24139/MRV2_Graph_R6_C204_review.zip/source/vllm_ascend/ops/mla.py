# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
# Copyright 2023 The vLLM team.
# Copyright 2023 DeepSeek-AI and the HuggingFace Inc. team. All rights reserved.
#
# This code is based on EleutherAI's GPT-NeoX library and the GPT-NeoX
# and OPT implementations in this library. It has been modified from its
# original forms to accommodate minor architectural differences compared
# to GPT-NeoX and OPT used by the Meta AI team that trained the model.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
from torch import nn
from vllm.compilation.breakable_cudagraph import eager_break_during_capture
from vllm.config import CacheConfig, get_current_vllm_config
from vllm.distributed import get_tensor_model_parallel_world_size
from vllm.forward_context import ForwardContext, get_forward_context
from vllm.model_executor.layers.attention import MLAAttention
from vllm.model_executor.layers.mla import MLAModules, MultiHeadLatentAttentionWrapper
from vllm.model_executor.layers.quantization import QuantizationConfig
from vllm.utils.torch_utils import direct_register_custom_op
from vllm.v1.attention.backend import AttentionMetadata  # type: ignore

from vllm_ascend.attention.indexer import AscendSFAIndexerBackend


class IndexerWrapper(nn.Module):
    """Model-facing wrapper owning the per-layer indexer backend.

    Mirrors the wrapper/backend split of AscendMultiHeadLatentAttention: the
    wrapper wires the upstream weight module into the model tree and
    dispatches; all compute and cache persistence live in the
    ``AscendSFAIndexerBackend`` instance it owns.
    """

    def __init__(self, vllm_indexer: nn.Module, qk_rope_head_dim: int) -> None:
        super().__init__()
        # Register the indexer weights directly on the wrapper so module-tree
        # paths keep the pre-backend layout ("...indexer.<name>") that weight
        # loading and quant name mapping key off. The backend shares the same
        # module objects; nn.Module deduplicates shared submodules by object.
        self.n_head: int = vllm_indexer.n_head
        self.topk_tokens: int = vllm_indexer.topk_tokens
        self.q_lora_rank: int = vllm_indexer.q_lora_rank
        self.wq_b = vllm_indexer.wq_b
        self.wk_weights_proj = vllm_indexer.wk_weights_proj
        self.k_norm = vllm_indexer.k_norm
        self.softmax_scale = vllm_indexer.softmax_scale
        # Preserve checkpoint-visible direct Parameters for every indexer
        # family. Registering them here keeps paths at ``...indexer.<name>``
        # rather than adding an implementation segment.
        if isinstance(vllm_indexer, nn.Module):
            for name, parameter in vllm_indexer.named_parameters(recurse=False):
                self.register_parameter(name, parameter)

        backend_factory = getattr(type(vllm_indexer), "get_ascend_indexer_backend_cls", None)
        backend_cls = backend_factory(vllm_indexer) if backend_factory is not None else AscendSFAIndexerBackend
        self.impl = backend_cls(vllm_indexer, qk_rope_head_dim)

    # Interface consumed by the SFA impl - delegated to the backend impl.
    @property
    def k_cache(self):
        return self.impl.k_cache

    @property
    def head_dim(self) -> int:
        return self.impl.head_dim

    @property
    def enable_sparse_li_c8(self) -> bool:
        return self.impl.enable_sparse_li_c8

    @property
    def num_cache_tensors(self) -> int:
        return self.impl.num_cache_tensors

    @property
    def topk_output_width(self) -> int:
        return self.impl.topk_output_width

    def get_topk_lengths(self, positions: torch.Tensor) -> torch.Tensor:
        """Return model-defined visible index counts for attention planning."""
        return self.impl.get_topk_lengths(positions)

    def process_weights_after_loading(self) -> None:
        self.impl.process_weights_after_loading()

    def forward(
        self,
        hidden_states: torch.Tensor,
        q_c: torch.Tensor | tuple[torch.Tensor, torch.Tensor],
        k_hidden_states: torch.Tensor,
        indexer_metadata: AttentionMetadata,
        compute_topk: bool = True,
    ) -> torch.Tensor | None:
        return self.impl(hidden_states, q_c, k_hidden_states, indexer_metadata, compute_topk)


class AscendMultiHeadLatentAttention(MultiHeadLatentAttentionWrapper):
    # IndexCache (index_share_for_mtp_iteration): the spec-decode proposer
    # toggles ``skip_topk`` on this wrapper at runtime (set_skip_topk) and
    # compacts the shared top-k buffer (compact_topk_indices). The actual
    # indexer gate and buffer live in the inner impl (e.g. AscendSFAImpl),
    # which is not an nn.Module and is therefore invisible to
    # named_modules(). Expose both as properties forwarding to the impl so
    # the upstream DeepSeekMultiTokenPredictor hooks keep working on Ascend.
    @property
    def skip_topk(self) -> bool:
        return self.__dict__.get("_skip_topk", False)

    @skip_topk.setter
    def skip_topk(self, value: bool) -> None:
        self.__dict__["_skip_topk"] = bool(value)
        impl = getattr(getattr(self, "mla_attn", None), "impl", None)
        if impl is not None and hasattr(impl, "skip_topk"):
            impl.skip_topk = self.__dict__["_skip_topk"]

    @property
    def topk_indices_buffer(self) -> torch.Tensor | None:
        impl = getattr(getattr(self, "mla_attn", None), "impl", None)
        if impl is None:
            return None
        return getattr(impl, "topk_indices_buffer", None)

    @topk_indices_buffer.setter
    def topk_indices_buffer(self, value: torch.Tensor | None) -> None:
        impl = getattr(getattr(self, "mla_attn", None), "impl", None)
        if impl is not None and hasattr(impl, "topk_indices_buffer"):
            impl.topk_indices_buffer = value

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        scale: float,
        qk_nope_head_dim: int,
        qk_rope_head_dim: int,
        v_head_dim: int,
        q_lora_rank: int | None,
        kv_lora_rank: int,
        mla_modules: MLAModules,
        cache_config: CacheConfig | None = None,
        quant_config: QuantizationConfig | None = None,
        prefix: str = "",
        skip_topk: bool = False,
        non_causal_multi_token_decode: bool = False,
        allow_short_prefill_indexer_scoring_skip: bool = False,
        # Upstream fuses the q_a/kv_a RMSNorms on the CUDA path. On Ascend the
        # whole MLA preprocess runs inside the attention impl, which receives
        # both layernorms as extra args, so this flag has no effect here and is
        # accepted for signature compatibility only.
        fuse_qkv_rmsnorm: bool = False,
    ) -> None:
        nn.Module.__init__(self)
        self.hidden_size = hidden_size
        self.kv_lora_rank = kv_lora_rank
        self.qk_rope_head_dim = qk_rope_head_dim
        self.q_lora_rank = q_lora_rank
        self.qk_nope_head_dim = qk_nope_head_dim
        self.qk_head_dim = qk_nope_head_dim + qk_rope_head_dim
        self.v_head_dim = v_head_dim
        self.prefix = prefix
        # Goes through the property setter above; mla_attn is not created yet,
        # so only the backing value is stored here. MLAAttention below receives
        # the same value and initializes the impl consistently.
        self.skip_topk = skip_topk
        # This is an upstream CUDA indexer hint. Ascend accepts it to preserve
        # constructor compatibility, but its indexer does not consume it.
        del allow_short_prefill_indexer_scoring_skip
        hf_config = get_current_vllm_config().model_config.hf_text_config
        self.tp_size = get_tensor_model_parallel_world_size()
        self.layers = hf_config.num_hidden_layers
        if mla_modules.indexer is not None:
            ascend_indexer = IndexerWrapper(mla_modules.indexer, self.qk_rope_head_dim)
        else:
            ascend_indexer = None
        self.mla_attn = MLAAttention(
            num_heads=num_heads,
            scale=scale,
            qk_nope_head_dim=self.qk_nope_head_dim,
            qk_rope_head_dim=self.qk_rope_head_dim,
            v_head_dim=self.v_head_dim,
            q_lora_rank=self.q_lora_rank,
            kv_lora_rank=self.kv_lora_rank,
            kv_b_proj=mla_modules.kv_b_proj,
            cache_config=cache_config,
            quant_config=quant_config,
            prefix=f"{prefix}.attn",
            use_sparse=mla_modules.is_sparse,
            indexer=ascend_indexer,
            skip_topk=skip_topk,
            topk_indices_buffer=getattr(mla_modules, "topk_indices_buffer", None),
            non_causal_multi_token_decode=non_causal_multi_token_decode,
            # extra args
            rotary_emb=mla_modules.rotary_emb,
            fused_qkv_a_proj=mla_modules.fused_qkv_a_proj,
            q_b_proj=mla_modules.q_b_proj,
            q_a_layernorm=mla_modules.q_a_layernorm,
            q_proj=mla_modules.q_proj,
            kv_a_proj_with_mqa=mla_modules.kv_a_proj_with_mqa,
            kv_a_layernorm=mla_modules.kv_a_layernorm,
            o_proj=mla_modules.o_proj,
            g_proj=mla_modules.g_proj,
            use_mla_rope=mla_modules.rotary_emb is not None,
            layer_name=f"{prefix}.attn",
        )

        # Fused preprocess (mlapo/prolog_v3) owns transpose+NZ for these
        # layers, so quant methods must skip their own NZ conversion.
        # Mark before VLLM calls process_weights_after_loading on submodules.
        impl = self.mla_attn.impl
        if getattr(impl, "_fused_preprocess_type", None) and impl._fused_preprocess_type() is not None:
            for _layer in (impl.fused_qkv_a_proj, impl.q_proj):
                if _layer is not None:
                    _layer._fused_preprocess_managed = True

        original_process_weights = self.mla_attn.process_weights_after_loading

        def wrapped_process_weights(act_dtype: torch.dtype):
            from vllm_ascend.attention.sfa_v1 import AscendSFAImpl

            if not isinstance(self.mla_attn.impl, AscendSFAImpl):
                original_process_weights(act_dtype)
            self.mla_attn.impl.process_weights_after_loading(act_dtype)

        self.mla_attn.process_weights_after_loading = wrapped_process_weights

        vllm_config = get_current_vllm_config()
        compilation_config = vllm_config.compilation_config
        if prefix in compilation_config.static_forward_context:
            raise ValueError(f"Duplicate layer name: {prefix}")
        compilation_config.static_forward_context[prefix] = self

    def forward(
        self,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        kv_cache: torch.Tensor | None = None,
        attn_metadata: AttentionMetadata | None = None,
    ) -> torch.Tensor:
        hidden_dim = self.hidden_size
        output = torch.empty(
            (hidden_states.shape[0], hidden_dim), dtype=hidden_states.dtype, device=hidden_states.device
        )

        torch.ops.vllm.mla_forward(hidden_states, output, self.prefix)
        output = output.view(-1, hidden_dim)
        return output


@eager_break_during_capture
def mla_forward(
    hidden_states: torch.Tensor,
    output: torch.Tensor,
    layer_name: str,
) -> None:
    forward_context: ForwardContext = get_forward_context()
    self = forward_context.no_compile_layers[layer_name]
    if forward_context.attn_metadata:
        attn_metadata = forward_context.attn_metadata[self.mla_attn.layer_name]
    else:
        attn_metadata = forward_context.attn_metadata
    kv_cache = self.mla_attn.kv_cache
    self.mla_attn.impl.forward(self.mla_attn.layer_name, hidden_states, kv_cache, attn_metadata, output)
    return


def mla_forward_fake(
    hidden_states: torch.Tensor,
    output: torch.Tensor,
    layer_name: str,
) -> None:
    return


direct_register_custom_op(
    op_name="mla_forward",
    op_func=mla_forward,
    mutates_args=["output"],
    fake_impl=mla_forward_fake,
    dispatch_key="PrivateUse1",
)
