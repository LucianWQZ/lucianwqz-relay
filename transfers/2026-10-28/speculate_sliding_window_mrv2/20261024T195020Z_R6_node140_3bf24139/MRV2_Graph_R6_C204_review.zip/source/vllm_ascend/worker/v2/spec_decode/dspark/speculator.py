#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
# Copyright 2023 The vLLM team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#
from typing import Any, cast

import torch
from vllm.config import VllmConfig, get_layers_from_vllm_config, set_current_vllm_config
from vllm.config.compilation import CUDAGraphMode
from vllm.model_executor.layers.attention_layer_base import AttentionLayerBase
from vllm.v1.attention.backend import AttentionBackend
from vllm.v1.worker.gpu.input_batch import InputBatch
from vllm.v1.worker.gpu.spec_decode.dspark.speculator import (
    DSparkSpeculator,
)

from vllm_ascend.ascend_config import validate_additional_config_bool
from vllm_ascend.utils import (
    get_rotation_path,
    vllm_version_is,
)
from vllm_ascend.worker.v2.attn_utils import (
    build_attn_metadata_wrapper,
    build_draft_attn_metadata_factory,
)
from vllm_ascend.worker.v2.spec_decode.draft_window import (
    DraftWindowPolicyDecision,
    DraftWindowPolicyState,
    build_draft_window_runtime_state,
    build_draft_window_source_capability,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_eager import (
    DraftWindowEagerMixin,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_graph import (
    DraftWindowGraphRoute,
    consume_draft_window_graph_metadata,
)
from vllm_ascend.worker.v2.spec_decode.draft_window_graph_characterization import (
    build_parallel_draft_window_graph_characterization_source,
    experimental_draft_window_graph_characterization_enabled,
    install_parallel_draft_window_graph_characterization,
)
from vllm_ascend.worker.v2.spec_decode.pcp_utils import prepare_replicated_pcp_config


class AscendDSparkSpeculator(DraftWindowEagerMixin, DSparkSpeculator):
    _speculator_name = "DSpark"

    def _configure_draft_window(self, decision: DraftWindowPolicyDecision) -> None:
        """Attach the eligible P1 policy contract without enabling a window."""
        if decision.state is not DraftWindowPolicyState.ELIGIBLE_ON:
            raise ValueError("draft-window owner requires an ELIGIBLE_ON policy decision")
        if hasattr(self, "_draft_window_policy"):
            raise RuntimeError("draft-window policy is already configured")
        self._draft_window_policy = decision

    def _initialize_draft_window_source_capability(self) -> None:
        """Atomically bind eligible P2 source and P3 ownership state."""
        policy = getattr(self, "_draft_window_policy", None)
        if policy is None:
            return
        if hasattr(self, "_draft_window_source_capability") or hasattr(
            self,
            "_draft_window_runtime_state",
        ):
            raise RuntimeError("draft-window runtime ownership is already initialized")
        graph_context = None
        if experimental_draft_window_graph_characterization_enabled():
            from vllm_ascend.worker.v2.spec_decode.draft_window import (
                build_draft_window_runtime_context,
            )

            runtime_context = build_draft_window_runtime_context(
                self.vllm_config,
                self.block_tables,
            )
        else:
            runtime_context = None
        if runtime_context is not None and runtime_context.graph_mode != "NONE":
            capability, graph_context = build_parallel_draft_window_graph_characterization_source(
                policy=policy,
                runtime_route=self._speculator_name.lower(),
                attn_groups=self.attn_groups,
                block_tables=self.block_tables,
                causal=self._group_causal,
                vllm_config=self.vllm_config,
            )
        else:
            capability = build_draft_window_source_capability(
                policy=policy,
                runtime_route=self._speculator_name.lower(),
                attn_groups=self.attn_groups,
                block_tables=self.block_tables,
                causal=self._group_causal,
                vllm_config=self.vllm_config,
            )
        runtime_state = build_draft_window_runtime_state(capability)
        self._draft_window_source_capability = capability
        self._draft_window_runtime_state = runtime_state
        self._initialize_draft_window_eager_state()
        if graph_context is not None:
            self._draft_window_graph_characterization_context = graph_context

    def __init__(self, vllm_config: VllmConfig, device: torch.device):
        vllm_config, self.replicated_pcp = prepare_replicated_pcp_config(vllm_config)
        super().__init__(vllm_config, device)
        self.input_batch: InputBatch | None = None

    def capture(self) -> None:
        diagnostic = validate_additional_config_bool(
            self.vllm_config.additional_config.get("draft_window_graph_numeric_diagnostic", False),
            "additional_config.draft_window_graph_numeric_diagnostic",
        )
        if diagnostic:
            if not experimental_draft_window_graph_characterization_enabled():
                raise RuntimeError("numeric capture diagnostic requires the experimental Graph gate")
            from vllm_ascend.worker.v2.spec_decode.draft_window_graph_diagnostics import DraftGraphOutputReferences

            if hasattr(self, "_draft_graph_output_references"):
                raise RuntimeError("numeric capture diagnostic already installed")
            self._draft_graph_output_references = DraftGraphOutputReferences(self)
            self._draft_graph_output_references.collecting = True
        try:
            super().capture()
        finally:
            if diagnostic:
                self._draft_graph_output_references.collecting = False
        if diagnostic:
            self._draft_graph_output_references.freeze(d.num_tokens for d in self.query_cudagraph_manager.graphs)

    def _run_model(
        self, num_tokens, attn_metadata, slot_mappings, num_tokens_across_dp, cudagraph_runtime_mode=CUDAGraphMode.NONE
    ):
        self._mark_draft_window_async_reader_started()
        output = super()._run_model(
            num_tokens, attn_metadata, slot_mappings, num_tokens_across_dp, cudagraph_runtime_mode
        )
        sink = getattr(self, "_draft_graph_output_references", None)
        if sink is not None and (sink.collecting or cudagraph_runtime_mode == CUDAGraphMode.FULL):
            sink.retain(self, num_tokens, output)
        return output

    def load_draft_model(
        self,
        target_model: torch.nn.Module,
        target_attn_layer_names: set[str],
    ) -> torch.nn.Module:
        # Upstream replaces quant_config with None for a BF16 draft. Pass only
        # the target QuaRot path so the draft's existing load_weights can fold
        # input inverse rotation into FC (W @ R) and align fallback embedding /
        # lm_head before upstream decides weight sharing. Do not rotate again
        # after loading or replace the draft's own quantization configuration.
        draft_hf_config = self.draft_model_config.hf_config
        rotation_path = get_rotation_path(self.vllm_config)
        draft_hf_config._ascend_target_rotation_path = str(rotation_path) if rotation_path is not None else None
        model = super().load_draft_model(target_model, target_attn_layer_names)
        if hasattr(model, "configure_target_aux_hidden_capture"):
            model.configure_target_aux_hidden_capture(target_model)

        return model

    def init_cudagraph_manager(self, cudagraph_mode: CUDAGraphMode) -> None:
        if self.speculative_config.enforce_eager:
            cudagraph_mode = CUDAGraphMode.NONE
        super().init_cudagraph_manager(cudagraph_mode)
        # The Ascend graph manager is patched onto the upstream module and
        # created by super().init_cudagraph_manager without a speculator ref.
        # It needs this speculator to update full-graph params, so set it here.
        self.query_cudagraph_manager.speculator = self
        self.query_cudagraph_manager.update_stream = self.update_stream
        graph_context = getattr(
            self,
            "_draft_window_graph_characterization_context",
            None,
        )
        if graph_context is not None:
            if not experimental_draft_window_graph_characterization_enabled():
                raise RuntimeError("Graph characterization flag changed during initialization")
            install_parallel_draft_window_graph_characterization(
                self,
                runtime_context=graph_context,
            )

    def set_attn(
        self,
        model_state: Any,
        kv_cache_config: Any,
        block_tables: Any,
        target_input_buffers: Any,
        target_attn_groups: Any,
    ) -> None:
        # Initialize the draft attention backend with its PCP=1 config.
        with set_current_vllm_config(self.attn_vllm_config):
            super().set_attn(
                model_state,
                kv_cache_config,
                block_tables,
                target_input_buffers,
                target_attn_groups,
            )
            self._context_slot_mappings = self._context_slot_mappings.to(torch.int32)  # type: ignore[has-type]
            # npu needs attn_backends to update full graph params in run_fullgraph.
            attn_backends: dict[str, type[AttentionBackend]] = {}
            active_layer_names = self.draft_attn_layer_names
            for kv_cache_group_spec in kv_cache_config.kv_cache_groups:
                layer_names = kv_cache_group_spec.layer_names
                if active_layer_names is not None:
                    # Preserve cache-group order so captured graph tasks and
                    # runtime metadata stay aligned.
                    layer_names = [name for name in layer_names if name in active_layer_names]

                layer_type = cast(type[Any], AttentionLayerBase)
                attn_layers = get_layers_from_vllm_config(self.vllm_config, layer_type, layer_names)

                for layer_name in layer_names:
                    attn_backends[layer_name] = attn_layers[layer_name].get_attn_backend()

            self.attn_backends = attn_backends
        self._initialize_draft_window_source_capability()

    def build_draft_attn_metadatas(self, num_reqs_padded, seq_lens_cpu_upper_bound):
        graph_metadata = consume_draft_window_graph_metadata(
            self,
            route=DraftWindowGraphRoute.DSPARK,
            expected_consumer_count=1,
        )
        if graph_metadata is not None:
            return list(graph_metadata)
        num_tokens_padded = num_reqs_padded * self.num_query_per_req
        assert self.input_batch is not None
        # The draft attention metadata is built through the generic
        # (Ascend) build_attn_metadata path; the factory forwards the draft
        # query positions that the DSA metadata builder needs for RoPE.
        with (
            build_attn_metadata_wrapper(),
            build_draft_attn_metadata_factory(
                self.input_buffers.positions,
                num_tokens_padded,
                torch.from_numpy(self.input_batch.is_prefilling_np),
            ),
        ):
            attn_metadata = self._build_draft_attn_metadata(
                num_reqs=self.input_batch.num_reqs,
                num_reqs_padded=num_reqs_padded,
                num_tokens_padded=num_tokens_padded,
                seq_lens_cpu_upper_bound=seq_lens_cpu_upper_bound,
                step=self.num_query_per_req,
                causal=self._group_causal,
            )
        return [self._update_draft_attn_metadata(attn_metadata, num_reqs_padded)]

    def _update_draft_attn_metadata(self, attn_metadata, num_reqs_padded):
        """Rebuild ``actual_seq_lengths_q`` from the padded request count,
        mirroring Eagle's ``_update_decode_attn_metadata``.

        DSpark inherits DFlash's full-graph path, and upstream
        ``Speculator._build_draft_attn_metadata`` clamps ``query_start_loc`` at
        the real ``num_reqs`` to keep the cumulative series non-decreasing, so
        when a batch is padded to a capture size (``num_reqs_padded >
        num_reqs``) the cumulative query lengths stop at
        ``num_reqs * num_query_per_req`` instead of ``num_tokens_padded``. The
        Ascend FIA operator requires, in TND layout, that the last element of
        ``actual_seq_lengths_q`` equals the query token count of the graph
        being replayed; otherwise tiling fails with
        ``queryT != last element of actualSequenceLengthQ``.
        """
        query_lens_list = [(i + 1) * self.num_query_per_req for i in range(num_reqs_padded)]
        for metadata in attn_metadata.values():
            metadata.actual_seq_lengths_q = query_lens_list
        return attn_metadata

    def propose(
        self,
        input_batch: InputBatch,
        attn_metadata: dict[str, Any],
        slot_mappings: dict[str, torch.Tensor],
        last_hidden_states: torch.Tensor,
        aux_hidden_states: list[torch.Tensor] | None,
        num_sampled: torch.Tensor,
        num_rejected: torch.Tensor,
        last_sampled: torch.Tensor,
        next_prefill_tokens: torch.Tensor,
        temperature: torch.Tensor,
        seeds: torch.Tensor,
        num_tokens_across_dp: torch.Tensor | None = None,
        dummy_run: bool = False,
        skip_attn_for_dummy_run: bool = False,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
        is_profile: bool = False,
        # vLLM #53694 replaced num_tokens_across_dp with the DP sync state.
        dp_sync: Any = None,
    ) -> torch.Tensor:
        self.input_batch = input_batch
        assert self.input_batch is not None
        sync_state = num_tokens_across_dp if vllm_version_is("0.28.0") else dp_sync
        if dummy_run and skip_attn_for_dummy_run:
            # Profiling runs the draft with its own query token count, which
            # can differ from the target batch. Let forward_context coordinate
            # the actual draft counts instead of reusing the target DP state.
            # TODO: Remove this guard once main2main includes upstream vLLM
            # #54856 (facd9a74a1), which resets the profiling DP counts.
            sync_state = None
        with (
            build_attn_metadata_wrapper(),
            build_draft_attn_metadata_factory(
                self.input_buffers.positions, self.max_num_tokens, torch.from_numpy(self.input_batch.is_prefilling_np)
            ),
            self._draft_window_proposal_scope(
                input_batch,
                dummy_run=dummy_run,
                is_profile=is_profile,
            ),
        ):
            return super().propose(
                input_batch,
                attn_metadata,
                slot_mappings,
                last_hidden_states,
                aux_hidden_states,
                num_sampled,
                num_rejected,
                last_sampled,
                next_prefill_tokens,
                temperature,
                seeds,
                sync_state,
                dummy_run,
                skip_attn_for_dummy_run,
                mm_inputs,
                is_profile=is_profile,
            )
