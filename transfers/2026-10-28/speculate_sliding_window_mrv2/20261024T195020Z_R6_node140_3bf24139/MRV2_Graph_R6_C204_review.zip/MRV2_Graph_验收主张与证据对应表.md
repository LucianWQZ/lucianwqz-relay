# 主张→依据→前提→反例→风险→建议

|主张|依据/原件|适用前提|反例与风险|建议裁决|
|---|---|---|---|---|
|Draft Window不污染Full写/Target|C147、C159/C164完整224对join和原始执行关联|指定模型、TP16、串行诊断|不等于全部自然轨迹/正常overlap；C151另有失败|接受限定证据，不扩大候选/模型|
|正常UPDATE/backing排序合理|固定API/Source流和ExternalEvent、实际runtime_v100身份|全部consumer/辅助流尾notify、每代wait-current与vector owner前提|无新缺边但直接operand/最后consumer观测有限|审查适用性；需要更强要求时明确接口/负责人|
|Eagle旧K差异是取证链路问题|C60相邻AR状态与实际final、C61/C91复验|旧profile/capture程序|非通用allocator缺陷或指定Qwen3.6通过|保留旧PASS及范围|
|当前Eagle输出不是简单旧引用造成|C203同Graph owned=legacy，仍max0.3125；KV精确|本样本/两rank/诊断程序|真实计算/绑定或参考未区分|保留FAIL，补一次实际attention Q/输出，不放宽|
|Full8参考已纠正|C195正确eager零差、旧copy复现31.75；C196离线三样本joint|actual builder/canonical独立前态|共享native共同失效；Target/reader未闭|承认工具修正的限定证据|
|C184可复现异常|输出独立完成后快照/固定输入回读、canonical/native counterpart|已保存参数范围|准确API与完整官方模型尚未证明合法，不是平台归属证据|分类D；交接口维护者确认参数组合|
|性能已测|C185全部样本、C204 raw/counts|负载/缓存/重复单位固定|负收益、轨迹/质量与合同限制，C204不平衡且缺EON|测量与达标/质量分别裁决|

来源层级：用户/Frozen Design不变式；真实平台API必要条件；调查用诊断方法；旧Agent建议。团队/维护者是否明确要求特定physical-read证明原文若未找到，标来源待确认，不编造不可改变的发布规则；用户已明确没有批准降低现有门槛。
