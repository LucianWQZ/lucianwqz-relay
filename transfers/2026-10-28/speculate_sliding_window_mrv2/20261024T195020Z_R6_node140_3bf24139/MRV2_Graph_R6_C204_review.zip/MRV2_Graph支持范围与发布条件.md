# 支持范围与发布条件（当前权威摘要）

目标没有缩为DSpark TP1。顺序：GLM5.2 DSpark及全部适用基础特性→GLM/Qwen3.6 DFlash与约定SWA→指定Qwen3.6 Eagle3和既定policy。不做所有理论开关笛卡尔积，未验证不自动改成“不支持”。

|路线|当前真实范围|未完成/限制|
|---|---|---|
|GLM GQA DSpark K8/Q8 anchor=true，W1024/B128，TP16/DP1/EP|真实服务、Draft Graph、CP数值/Full写/Target、Async/FlashComm/legacy DSA-CP/适用SP/chunked/prefix、匹配三臂有限测量|C151/C158自然轨迹/跨padding合同、Graph正常reader适用性、最终产品性能与组合|
|历史DSpark Q7 anchor=true与Q8非anchor|各自旧Qwen/候选数值/Target证据|不等同GLM K8/Q8，也不当最终候选新NPU|
|GLM DFlash K15/Q16|TP16完整14数值/ABA/Full写/Target224|正常服务/reader/性能及Q023加载质量固定组合未闭|
|Qwen3.6 DFlash Full8 K7/Q8|TP4/DP1/DP2服务，TP4三样本实际eager数值|扩展/Target/reader/性能仍缺|
|Qwen3.6 DFlash SWA6、native4096+Full、额外W32768|真实模型Graph锚点；原数值/native异常已具名|C184D/API/归属未清，正确性与正式性能阻塞；未取消此路线|
|指定Qwen3.6 Eagle K3 firstQ4/ARQ1|TP2两臂请求锚点、6consumer/rank限定数值|第7有效输出FAIL、后续Target/ABA/normal-life/perf未闭|
|MTP、内置/共训DeepSeek-V4 DSpark|遵既定warning/effective Window OFF|不扩ON、不将基线不支持方法变可用|
|其他方法/模式/并行|按既定拒绝/忽略/资格，不泛化|FULL_DECODE_ONLY不覆盖整个FULL/PIECEWISE；MLA Draft/其他组合须有需求依据，不从Target SFA推额外Draft搜索|

可直接复用：未变普通路径下原Source/Host、明确同方法同配置设备证据；差异核对后复用：固定版本API/Native/overlay、历史方法框架；必须补测：实际consumer/模型/backend/生产时序变化；历史诊断：串行LIFE/快照/原native参数导出；独立PR集成未验，不拼两边PASS。

**PRODUCT_SCOPE_READY=NO，FORMAL_RELEASE_DECISION=NOT_APPROVED，public Gate FROZEN。** 有效局部证据不作废，也不以多次启动/Host数量计完成率。最终发布前必须解决具体失败、关闭必需功能/合同/性能与固定源码组合；工程/设备/性能测量/性能达标/发布审批分开。

## 模型身份

|模型|完整路径|realpath|身份/运行状态|
|---|---|---|---|
|GLM Target|`/mnt/share/weights/GLM-5.2-w4a8`|`/mnt/share/weights/GLM-5.2-w4a8`|ACTUALLY_LOADED_TP16|
|GLM DSpark GQA|`/mnt/share/l00887471/graph_vllm/dspark_test/sw-aspark/GLM5.2_dspark`|`/mnt/share/l00887471/graph_vllm/dspark_test/sw-aspark/GLM5.2_dspark`|ACTUALLY_LOADED_TP16_K8_Q8|
|GLM DSpark MLA|`/mnt/share/weights/GLM-5.2-DSpark-MLA-NPU`|`/mnt/share/weights/GLM-5.2-DSpark-MLA-NPU`|EXISTS_PR_REPORTED_NOT_GRAPH_VERIFIED|
|GLM DFlash|`/mnt/weight/GLM-5.2-FP8-DFlash`|`/mnt/weight/GLM-5.2-FP8-DFlash`|ACTUALLY_LOADED_TP16_BF16_K15_Q16|
|Qwen3.6 Target|`/mnt/share/weight/Qwen3.6-35B-A3B-w8a8`|`/mnt/share/weight/Qwen3.6-35B-A3B-w8a8`|ACTUALLY_LOADED_TP4_DP2_TP2|
|Qwen3.6 Full8|`/mnt/weight/Qwen3.6-35B-A3B-DFlash`|`/mnt/weight/Qwen3.6-35B-A3B-DFlash`|ACTUALLY_LOADED_TP4_DP1_DP2_K7_Q8|
|Qwen3.6 SWA6|`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/models/hf_drafts/Qwen3.6-35B-A3B-DFlash-SWA_f181eece646a`|`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/models/hf_drafts/Qwen3.6-35B-A3B-DFlash-SWA_f181eece646a`|ACTUALLY_LOADED_TP4_NUMERIC_BLOCKED|
|Qwen3.6 Eagle3|`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/models/hf_drafts/specdrift-qwen3.6-35b-a3b-eagle3_cda3d86f3681_fc_norm_aux`|`/mnt/share/z00937950/project/speculate_sliding_window_mrv2/models/hf_drafts/specdrift-qwen3.6-35b-a3b-eagle3_cda3d86f3681_fc_norm_aux`|ACTUALLY_LOADED_TP2_K3_Q4_AR1|

详model_identities.json；只核既有config和已固定manifest，未重新下载或全量权重hash。GLM GQA路径与PR报告相同，MLA路径不同不能混同；GLM DFlash目录名FP8但实际BF16。原生SWA不关闭，block_size不冒充K。
