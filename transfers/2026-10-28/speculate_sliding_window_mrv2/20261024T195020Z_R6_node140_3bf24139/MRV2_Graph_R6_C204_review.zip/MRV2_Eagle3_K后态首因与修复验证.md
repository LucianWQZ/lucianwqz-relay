# Eagle：已关闭的快照缺陷与尚未关闭的有效输出差异

## 旧K后态：C59→C61（历史模型）

C59/C60 long-three AR1、generation367/epoch122、active3/padded4：输出一致，K块1/2异常；实际写slot对应块16/6/3。同一merged Graph内AR1后快照K块1/2为零，AR2前有原值；AR2后与独立最终缓存一致，restore roundtrip正确。简化Tensor实验未复现，不能据此宣布通用allocator/kernel缺陷。

C61 `730a295674e742d28c2479e13755e5a9abeb6226`在capture之前预分配post目的地，以index_select(out=...)记录。原9消费者严格K/V检查通过；C91随后14proposal/42consumer、每consumer ABA和Target14通过；C100受影响路径LIFE、ABORT、真实Python异常/调度有实际证据。完整旧报告和Target join附在evidence，保留其旧模型/SHA，不当指定Qwen3.6通过。

## 指定Qwen3.6：C199→C200

C199第5 long-three AR1参考V前态出现NaN、Graph实际V有限。C200外部固定pre目的地，同时保留原capture池副本；同一Graph内owned前态独立参考通过短/长共6consumer/rank，旧AR1 V仍28751/28752元素差并含NaN、旧AR2差17663。因此修复范围是诊断prestate所有权，不是底层KV写kernel或普通路径同步。

## C200→C203：仍未解决

C200第7 boundary-four/first：active4/padded4、generation105/epoch35、descriptor[4,16]、L0/end[1029,517,133,131]、start全0；7009/32768有效hidden元素差、max0.5（−35.25/−34.75），集中第二个有效请求4个query，KV写/前态精确。

C203预分配两个owned输出、保留旧引用同Graph比较。实际Phy14/15、两rank、producer74，前6仍通过，第7两个输出各7296/32768元素不同、max0.3125（−15.0625/−15.375），全部finite。**owned与legacy完全相同，K/V前态恢复与后态零差。** 输出引用覆盖不能解释这次反例；C200原0.5不重写为0.3125。没有放宽0容差，没有排除请求或block，没有归Q017或确认平台缺陷。

当前候选保留默认关闭取证代码，不称数值修复成功；正常Graph未因它增加D2D。源代码/Host42/真实保存几何检查、result/execution/全部已完成consumer原件与标准库输出复算均附。

## 下一最小动作

一次有界采证，保存同一样本真实attention Q/输出及完整FIA参数，owned独立完成后快照；保留同前态eager调用与canonical full来源，区分attention前投影/Rope、task绑定、eager上下文。必要时再以合法官方OFF对应调用区分来源。先Host约1–2小时，TP2采证约10–20分钟，仅估计；不从此跳到通用BF16/CANN修复，不重复完整矩阵。尚未实施，须新资源窗口。
